# AC78 — Intégration HyperTriangle au solver maître

AC78 prend comme parent le **SC_SOLVER AC77** autonome. Le projet DD094/PASS117 n'est pas le parent logique d'AC78; son archive a uniquement servi à récupérer la sous-arborescence runtime AC77 autoportante.

Le HyperTriangle AUX v1.0.0 est intégré comme provider pré-ALL-AUX gelé. L'entrée est explicite (`hypertriangle_request`) et peut aussi être appelée directement par `SovereignSolver.hypertriangle(request)`. Aucun texte libre ou champ ordinaire n'est transformé automatiquement en F001..F144.

La chaîne ajoutée est :

`data typée -> invariant canonique déclaré -> mémoire 144 -> activation déclarée -> capability typée -> reçu de provenance`

Les sorties HyperTriangle ont zéro crédit ROOT, aucune capacité d'écriture ROOT/RETURN et aucune autorité de mutation du solver. Les 99 mécanismes historiques restent inchangés.
