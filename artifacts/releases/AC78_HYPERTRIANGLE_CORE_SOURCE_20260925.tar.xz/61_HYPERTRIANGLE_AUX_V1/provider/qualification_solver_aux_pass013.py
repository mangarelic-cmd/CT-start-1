import copy, json, random
import hypertriangle_solver_aux as h


def route_payload(tag, rng):
    n=2+rng.randrange(5)
    return {'trace_id':tag,'contracts':{'additive':True,'common_ledger':True,'positivity_certified':True,'grounded':True},'cells':[{'occurrence_id':f'c{k}','weight':1+rng.randrange(1000)} for k in range(n)]}


def case_events(case, rng):
    base=f'Q13-{case:04d}'
    return [
        {'event_id':base+'-1','sequence':1,'type':'MEMORY_DROP','datum_id':base+'-D1','signals':[{'operator':'IDENTITY_SEED','certified':True,'projection':base+'-F1'}]},
        {'event_id':base+'-2','sequence':2,'type':'ACTIVATE','contracts':[{'contract_id':base+'-CR','capability':'route_simplex','requires_all':['F001']}]},
        {'event_id':base+'-3','sequence':3,'type':'CAPABILITY','capability':'route_simplex','contract_id':base+'-CR','capability_payload':route_payload(base,rng)},
        {'event_id':base+'-4','sequence':4,'type':'MEMORY_DROP','datum_id':base+'-D2','signals':[{'operator':'DIRECTED_ONSET','certified':True,'projection':base+'-F3'}]},
        {'event_id':base+'-5','sequence':5,'type':'ACTIVATE','contracts':[{'contract_id':base+'-CP','capability':'signed_polarity','requires_all':['F003']}]},
        {'event_id':base+'-6','sequence':6,'type':'CAPABILITY','capability':'signed_polarity','contract_id':base+'-CP','capability_payload':{'values':[rng.randrange(-20,21) for _ in range(1+rng.randrange(8))]}},
    ]


def main():
    rng=random.Random(13013); checks=0
    random_cases=72
    for case in range(random_cases):
        events=case_events(case,rng)
        split=1+rng.randrange(5)
        prefix=events[:split]; suffix=events[split:]
        # A split immediately after MEMORY_DROP may make the suffix start with ACTIVATE and is valid;
        # a split before CAPABILITY keeps the required activation in the checkpoint.
        full=h.memory_144_pipeline_replay({'events':events}); assert full['unified_valid']; checks+=1
        made=h.memory_144_create_unified_checkpoint({'events':prefix}); assert made['checkpoint_valid']; checks+=1
        assert h.validate_memory_144_unified_checkpoint({'checkpoint':made['checkpoint']})['checkpoint_valid']; checks+=1
        resumed=h.memory_144_resume_unified_checkpoint({'checkpoint':made['checkpoint'],'sidecar_snapshot':made['sidecar_snapshot'],'events':suffix}); assert resumed['resume_valid']; checks+=1
        assert resumed['projection']==full['projection']; checks+=1
        if suffix:
            rotated=h.memory_144_rotate_unified_checkpoint({'checkpoint':made['checkpoint'],'sidecar_snapshot':made['sidecar_snapshot'],'events':suffix}); assert rotated['checkpoint_valid']; checks+=1
            assert rotated['projection']==full['projection']; checks+=1
            tv=h.validate_memory_144_unified_transition({'parent_checkpoint':made['checkpoint'],'parent_sidecar_snapshot':made['sidecar_snapshot'],'events':suffix,'child_checkpoint':rotated['checkpoint'],'child_sidecar_snapshot':rotated['sidecar_snapshot']}); assert tv['transition_valid']; checks+=1
            assert rotated['checkpoint']['sidecar_chain_state']['snapshot_count']==2; checks+=1
        assert full['projection']['typed_request_count']==2 and full['projection']['capability_execution_count']==2; checks+=1
        assert full['event_receipts'][2]['outcome']['memory_feedback_performed'] is False; checks+=1
        assert full['event_receipts'][5]['outcome']['activation_reentry_performed'] is False; checks+=1

    # Long-lived rotation witness: one initial certified memory state, then repeated fresh activations.
    first=[{'event_id':'LONG-0001','sequence':1,'type':'MEMORY_DROP','signals':[{'operator':'IDENTITY_SEED','certified':True,'projection':'seed'}]}]
    root=h.memory_144_create_unified_checkpoint({'events':first}); assert root['checkpoint_valid']; checks+=1
    cp=root['checkpoint']; snap=root['sidecar_snapshot']; all_events=list(first)
    rotations=12
    for j in range(rotations):
        seq=len(all_events)+1
        ev={'event_id':f'LONG-{seq:04d}','sequence':seq,'type':'ACTIVATE','contracts':[{'contract_id':f'LONG-C{j:03d}','capability':'route_simplex','requires_all':['F001']}]}
        all_events.append(ev)
        rr=h.memory_144_rotate_unified_checkpoint({'checkpoint':cp,'sidecar_snapshot':snap,'events':[ev]}); assert rr['checkpoint_valid']; checks+=1
        cp,snap=rr['checkpoint'],rr['sidecar_snapshot']
        assert cp['rotation_index']==j+1; checks+=1
        assert cp['event_id_count']==len(all_events); checks+=1
        assert h.validate_receipt_id_sidecar_snapshot_chain(cp['sidecar_chain_state'])['chain_valid']; checks+=1
    full_long=h.memory_144_pipeline_replay({'events':all_events}); assert full_long['unified_valid']; checks+=1
    assert h.validate_memory_144_unified_checkpoint({'checkpoint':cp})['projection']==full_long['projection']; checks+=1
    assert len(cp['sidecar_chain_state']['anchors'])<=8 and cp['sidecar_chain_state']['compacted_snapshot_count']>0; checks+=2

    print(json.dumps({'status':'PASS','checks':checks,'random_checkpoint_suffix_cases':random_cases,'long_rotations':rotations,'long_event_count':len(all_events),'sidecar_anchor_count':len(cp['sidecar_chain_state']['anchors']),'sidecar_compacted_snapshots':cp['sidecar_chain_state']['compacted_snapshot_count'],'memory_feedback_events':0,'ac77_integration':'NOT_PERFORMED','dd094_integration':'NOT_PERFORMED','truth_credit':0},sort_keys=True))

if __name__=='__main__': main()
