#!/usr/bin/env python3
from __future__ import annotations
import random, tempfile
from pathlib import Path
import hypertriangle_solver_aux as h
import receipt_id_sidecar as s
checks=0
def ck(x,msg='qualification'):
    global checks
    checks+=1
    if not x: raise AssertionError(msg)
rng=random.Random(808080)
# Snapshot/import/proof campaigns.
for case in range(35):
    n=rng.randint(0,100); ids=[f'c{case}-{i}' for i in range(n)]; idset=set(ids)
    sp=h.receipt_id_sidecar_snapshot({'receipt_ids':ids,'generation':case%7})['snapshot']; ck(h.validate_receipt_id_sidecar_snapshot(sp)['snapshot_valid']); ck(sp['receipt_id_count']==n)
    for j in range(16):
        rid=(ids[rng.randrange(n)] if n and j%2==0 else f'c{case}-x{j}')
        p=h.receipt_id_sidecar_proof({'snapshot':sp,'journal_records':[],'receipt_id':rid}); ck(p['proof_valid']); ck(p['present']==(rid in idset)); ck(h.verify_sparse_receipt_id_proof(p['receipt_id_root'],rid,p['proof'],expected_present=(rid in idset))['proof_valid'])
# Journal/recovery/compaction campaigns kept bounded to avoid quadratic replay cost.
for case in range(16):
    base=[f'b{case}-{i}' for i in range(6)]; sp=h.receipt_id_sidecar_snapshot({'receipt_ids':base})['snapshot']; records=[]; expected=list(base)
    for j in range(10):
        rid=f'j{case}-{j}'; out=h.append_receipt_id_sidecar({'snapshot':sp,'journal_records':records,'receipt_id':rid}); ck(out['appended']); records.append(out['journal_entry']); expected.append(rid)
        r=h.recover_receipt_id_sidecar({'snapshot':sp,'journal_records':records}); ck(r['recovered']); ck(r['receipt_id_count']==len(expected))
    c=h.compact_receipt_id_sidecar({'snapshot':sp,'journal_records':records}); ck(c['compacted']); ck(c['snapshot']['receipt_id_root']==h.sparse_receipt_id_root(expected)); ck(c['snapshot']['generation']==1)
# File cycles and crash-tail recovery.
for case in range(10):
    with tempfile.TemporaryDirectory() as td:
        td=Path(td); sp=td/'s0.json'; jp=td/'j0.ndjson'; s.init_snapshot(sp,[f'root{case}']); s.ensure_journal(jp)
        for j in range(5): s.append_file(sp,jp,f'f{case}-{j}')
        r=s.recover_files(sp,jp); ck(r['recovered']); ck(r['receipt_id_count']==6)
        with open(jp,'ab') as f: f.write(b'{"schema":"truncated')
        rc=s.recover_files(sp,jp,allow_uncommitted_tail=True); ck(rc['recovered']); ck(rc['truncated_tail_ignored']); ck(rc['receipt_id_count']==6)
# Large exact snapshot: export/import and proofs.
ids=[f'long-{i:05d}' for i in range(1000)]
sp=h.receipt_id_sidecar_snapshot({'receipt_ids':ids,'generation':9})['snapshot']; ck(h.validate_receipt_id_sidecar_snapshot(sp)['snapshot_valid']); ck(sp['receipt_id_count']==1000)
for rid,present in [('long-00000',True),('long-00999',True),('long-missing',False)]:
    p=h.receipt_id_sidecar_proof({'snapshot':sp,'journal_records':[],'receipt_id':rid}); ck(p['proof_valid']); ck(p['present']==present)
print(f'PASS008 qualification: {checks}/{checks} PASS')
print(f'long_snapshot_ids={len(ids)} snapshot_canonical_bytes={len(h._canonical_for_hash(sp))} root={sp["receipt_id_root"]}')
