import copy, json, random
import hypertriangle_solver_aux as h


def mk_events(case,rng):
    b=f'I13-{case:04d}'
    values=[rng.randrange(-50,51) for _ in range(1+rng.randrange(7))]
    return [
        {'event_id':b+'-A','sequence':1,'type':'MEMORY_DROP','signals':[{'operator':'IDENTITY_SEED','certified':True,'projection':b}]},
        {'event_id':b+'-B','sequence':2,'type':'ACTIVATE','contracts':[{'contract_id':b+'-C1','capability':'route_simplex','requires_all':['F001']}]},
        {'event_id':b+'-C','sequence':3,'type':'CAPABILITY','capability':'route_simplex','capability_payload':{'trace_id':b,'contracts':{'additive':True,'common_ledger':True,'positivity_certified':True,'grounded':True},'cells':[{'occurrence_id':'x','weight':1+rng.randrange(99)},{'occurrence_id':'y','weight':1+rng.randrange(99)}]}},
        {'event_id':b+'-D','sequence':4,'type':'MEMORY_DROP','signals':[{'operator':'DIRECTED_ONSET','certified':True,'projection':b+'-2'}]},
        {'event_id':b+'-E','sequence':5,'type':'ACTIVATE','contracts':[{'contract_id':b+'-C2','capability':'signed_polarity','requires_all':['F003']}]},
        {'event_id':b+'-F','sequence':6,'type':'CAPABILITY','capability':'signed_polarity','capability_payload':{'values':values}},
    ]


def rehash_checkpoint(cp):
    body={k:copy.deepcopy(v) for k,v in cp.items() if k!='unified_checkpoint_hash'}
    cp['unified_checkpoint_hash']=h._memory_144_unified_checkpoint_hash(body)
    return cp


def main():
    rng=random.Random(2026092513); checks=0
    cases=60
    for i in range(cases):
        ev=mk_events(i,rng); split=(i%5)+1
        full=h.memory_144_pipeline_replay({'events':ev}); assert full['unified_valid']; checks+=1
        p=h.memory_144_create_unified_checkpoint({'events':ev[:split]}); assert p['checkpoint_valid']; checks+=1
        r=h.memory_144_resume_unified_checkpoint({'checkpoint':p['checkpoint'],'sidecar_snapshot':p['sidecar_snapshot'],'events':ev[split:]}); assert r['resume_valid']; checks+=1
        assert r['projection']==full['projection']; checks+=1
        rot=h.memory_144_rotate_unified_checkpoint({'checkpoint':p['checkpoint'],'sidecar_snapshot':p['sidecar_snapshot'],'events':ev[split:]}); assert rot['checkpoint_valid']; checks+=1
        assert rot['projection']==full['projection']; checks+=1
        assert rot['sidecar_snapshot']['receipt_id_root']==full['projection']['event_id_root']; checks+=1
        assert h.validate_memory_144_unified_transition({'parent_checkpoint':p['checkpoint'],'parent_sidecar_snapshot':p['sidecar_snapshot'],'events':ev[split:],'child_checkpoint':rot['checkpoint'],'child_sidecar_snapshot':rot['sidecar_snapshot']})['transition_valid']; checks+=1

    # Tamper matrix: rehash the outer checkpoint where relevant so semantic validators, not just outer hash, are exercised.
    p=h.memory_144_create_unified_checkpoint({'events':mk_events(999,rng)[:3]}); cp=p['checkpoint']; snap=p['sidecar_snapshot']
    tampers=[]
    b=copy.deepcopy(cp); b['event_id_root']='0'*64; tampers.append(rehash_checkpoint(b))
    b=copy.deepcopy(cp); b['event_id_count']+=1; tampers.append(rehash_checkpoint(b))
    b=copy.deepcopy(cp); b['memory_drop_count']+=1; tampers.append(rehash_checkpoint(b))
    b=copy.deepcopy(cp); b['activation_count']+=1; tampers.append(rehash_checkpoint(b))
    b=copy.deepcopy(cp); b['typed_request_count']+=1; tampers.append(rehash_checkpoint(b))
    b=copy.deepcopy(cp); b['capability_execution_count']+=1; tampers.append(rehash_checkpoint(b))
    b=copy.deepcopy(cp); b['activation_state_hash']='0'*64; tampers.append(rehash_checkpoint(b))
    b=copy.deepcopy(cp); b['pipeline_history_accumulator']='0'*64; tampers.append(b)  # opaque historical accumulator: outer checkpoint hash must catch mutation unless archived prefix/transition is supplied
    b=copy.deepcopy(cp); b['memory_feedback_policy']='ALLOW'; tampers.append(rehash_checkpoint(b))
    b=copy.deepcopy(cp); b['truth_credit']=1; tampers.append(rehash_checkpoint(b))
    b=copy.deepcopy(cp); b['sidecar_chain_state']['tip_receipt_id_root']='0'*64; tampers.append(rehash_checkpoint(b))
    rejected=0
    for bad in tampers:
        assert not h.validate_memory_144_unified_checkpoint({'checkpoint':bad})['checkpoint_valid']; checks+=1; rejected+=1

    # Snapshot substitution and duplicate suffix must fail before state mutation.
    other=h.receipt_id_sidecar_snapshot({'receipt_ids':['OTHER']})['snapshot']
    assert not h.memory_144_resume_unified_checkpoint({'checkpoint':cp,'sidecar_snapshot':other,'events':[]})['resume_valid']; checks+=1
    dup={'event_id':cp['sidecar_chain_state']['anchors'][-1].get('snapshot_hash','X'),'sequence':4,'type':'ACTIVATE','contracts':[]}
    # use a real historic event id for duplicate test
    dup['event_id']=mk_events(999,random.Random(2026092513))[0]['event_id']
    x=h.memory_144_resume_unified_checkpoint({'checkpoint':cp,'sidecar_snapshot':snap,'events':[dup]})
    assert not x['resume_valid']; checks+=1

    # Stale activation firewall independently checked.
    ev=mk_events(1000,rng)[:4]
    ev.append({'event_id':'STALE-CAP','sequence':5,'type':'CAPABILITY','capability':'route_simplex','capability_payload':{}})
    stale=h.memory_144_pipeline_replay({'events':ev}); assert not stale['unified_valid'] and 'fresh activation' in stale['error']; checks+=2

    print(json.dumps({'status':'PASS','checks':checks,'random_equivalence_cases':cases,'checkpoint_tamper_cases':rejected,'snapshot_substitution_cases':1,'duplicate_suffix_cases':1,'stale_activation_cases':1,'memory_feedback_events':0,'truth_credit':0},sort_keys=True))

if __name__=='__main__': main()
