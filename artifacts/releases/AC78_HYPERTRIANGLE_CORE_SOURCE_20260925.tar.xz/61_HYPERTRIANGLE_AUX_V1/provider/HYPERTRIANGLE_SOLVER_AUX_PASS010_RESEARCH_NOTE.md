# HyperTriangle Solver AUX — PASS010 Research Note

Date: 2026-09-25  
Branch: `HYPERTRIANGLE_SOLVER_AUX`  
Parent: PASS009 standalone AUX.  
Scope: native 144-slot invariant memory, one-based trace, push-data flagging, last-certified-invariant retention, and reconstruction state. **No AC77/DD094 integration or mutation.**

## 1. Correction of the frontier
PASS009 proposed archive retention/garbage collection. That was the wrong next object for the project memory model.

PASS010 rereads the existing Causal Memory and F001-F144 canon and adopts the native project rule:

`DATA -> INVARIANT -> SLOT FLAG`.

The grid is not a bank of 144 classifiers that search raw data. Incoming data must carry a typed invariant/operator signature. The unique operator map places it directly into one or more fixed slots.

## 2. Fixed 144-slot grid
`CAUSAL_144_CANON.json` materializes exactly 144 slots `F001..F144` with their canonical function, unique operator, regime and domain anchor.

The slot/function identity is immutable. Context and projection belong to the incoming manifestation, not to the definition of the slot.

## 3. START=1 trace
The memory trace is one-based:

`START = 1`.

An initialized state has `next_trace=1`; every accepted datum consumes exactly the current `next_trace` and increments it by one. Gaps and rewrites are rejected.

## 4. Flag semantics
For every incoming datum:

1. read its declared invariant/operator signatures;
2. map each operator to its unique canonical slot;
3. set that slot's observed flag;
4. increment the slot hit count;
5. if the projection is certified, replace the slot's `last_invariants_saved` record.

Uncertified observations are visible as evidence that the slot was touched, but they do not overwrite the last certified invariant/projection.

## 5. Last invariants saved reconstruction
The active memory state stores:

- 144 observed flags;
- 144 certified flags;
- 144 hit counts;
- at most one last certified invariant/projection record per slot;
- residual and reconstruction references attached to that surviving record;
- a hash-chain accumulator over the one-based trace.

This is the executable form of `last invariants saved reconstruction` used here: the current reconstructible semantic memory is rebuilt from the fixed canon plus the surviving last certified records. Arbitrary raw-history replay is not inferred from flags alone.

## 6. Causal Memory boundary
PASS010 follows the existing memory rule: common/reconstructible structure need not be stored repeatedly, but irreducible distinctions must survive somewhere. Therefore the grid deliberately refuses to claim byte-exact replay unless an external reconstruction contract provides the necessary retained base/residual/decoder.

## 7. Provider modes
- `memory_144_catalog`
- `memory_144_init`
- `memory_144_drop`
- `memory_144_trace`
- `memory_144_validate`
- `memory_144_reconstruct`

## 8. Validation
- cumulative regression + unit tests: **138/138 PASS**;
- independent verifier: **87,522/87,522 PASS**;
- independent ordered two-slot cases: **20,592/20,592 PASS**;
- qualification: **11,026/11,026 PASS** over 2,000 incoming data events;
- all 144 slots flagged and all 144 slots received at least one certified surviving invariant in the qualification witness.

## 9. Authority firewall
Unchanged:

- `truth_credit = 0`;
- ROOT write = `NONE`;
- RETURN write = `NONE`;
- solver mutation = `NONE`;
- AC77 integration = `NOT_PERFORMED`;
- DD094 integration = `NOT_PERFORMED`.

## 10. Next front
The next useful front is no longer generic archive GC. It is **memory reconstruction/activation semantics**: use the 144-flag state plus last surviving invariants to drive which AUX capability becomes relevant, while preserving the direction `data -> flag -> activation` and never reversing it into `category -> data retrieval`.
