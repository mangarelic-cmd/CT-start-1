# HYPERTRIANGLE_SOLVER_AUX — v1.0.0 / PASS015

Final standalone freeze of the HyperTriangle Solver AUX. PASS015 adds no new solver-side semantics. It freezes the cumulative PASS001–PASS014 system and its exact public ABI.

## Final chain

`DATA -> invariant -> F001..F144 memory -> declared activation -> typed local capability request -> capability receipt -> unified persistence -> declared local AUX terminality`

The direction is fixed: data falls onto a declared canonical invariant slot. Categories/capabilities do not search raw data. Certified last invariants survive; uncertified observations never satisfy activation requirements.

## Frozen v1 surface

- 61 provider capabilities;
- 35 JSON schemas;
- fixed F001–F144 canon, START=1;
- exact receipt-ID semantics with Sparse-Merkle root + external exact sidecar;
- bounded checkpoint/snapshot lineage;
- crash-safe checkpoint + suffix = full replay for the declared projections;
- memory-driven activation only through explicit contracts;
- 19 admitted local execution targets;
- no automatic capability-output feedback into memory;
- declared local terminality with immutable first-terminal certificate and post-terminal regression/conflict tracking.

The exact v1 surface and implementation hashes are recorded in `HYPERTRIANGLE_SOLVER_AUX_V1_ABI_FREEZE.json`.

## Authority boundary

`truth_credit = 0`. The AUX has no ROOT write, RETURN write, solver mutation, AC77/DD094 integration, or external scientific-truth authority. `AUX_TERMINAL` means only that a declared local terminal contract is satisfied by the certified standalone AUX state.

## Release status

PASS015 is the freeze/release pass. Functional development of this standalone AUX stops at v1.0.0; any AC77/DD094 connection belongs to a separate integration branch.
