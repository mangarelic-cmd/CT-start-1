import hashlib, json, random
from pathlib import Path
import hypertriangle_solver_aux as h

ROOT=Path(__file__).resolve().parent
F=json.loads((ROOT/'HYPERTRIANGLE_SOLVER_AUX_V1_ABI_FREEZE.json').read_text())
checks=0

def ok(cond,msg):
    global checks
    checks+=1
    if not cond: raise AssertionError(msg)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def csha(obj): return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

ok(h.AUX_VERSION=='1.0.0','version')
caps=h.capabilities(); ok(caps['capabilities']==F['capabilities'],'capabilities'); ok(csha(caps['capabilities'])==F['capabilities_sha256'],'cap hash')
ok(caps['firewalls']==F['firewalls'],'firewalls'); ok(csha(caps['firewalls'])==F['firewalls_sha256'],'fire hash')

# Every schema and frozen implementation file is byte-exact.
for rel,d in F['schemas'].items():
    p=ROOT/rel; ok(p.is_file(),rel+' exists'); ok(sha(p)==d,rel+' hash'); obj=json.loads(p.read_text()); ok(obj.get('$schema') in (None,'https://json-schema.org/draft/2020-12/schema'),rel+' draft')
for rel,d in F['implementation_files'].items(): ok(sha(ROOT/rel)==d,rel+' implementation hash')

# Every canonical slot remains individually usable in START=1 memory and declared local terminality.
cat=h.memory_144_catalog({}); ok(len(cat['slots'])==144,'144 catalog')
for row in cat['slots']:
    slot,op=row['slot'],row['operator']
    ev=[{'event_id':'Q15-'+slot,'sequence':1,'type':'MEMORY_DROP','datum_id':'D-'+slot,'signals':[{'operator':op,'certified':True,'projection':slot}]}]
    r=h.memory_144_terminal_replay({'events':ev,'terminal_contract':{'contract_id':'T-'+slot,'requires_certified_slots':[slot]}})
    ok(r.get('terminal_replay_valid') is True,slot+' replay'); ok(r['projection']['current_terminal'] is True,slot+' terminal'); ok(r['projection']['first_terminal_prefix']==1,slot+' prefix')

# Random checkpoint/suffix equivalence at v1 release boundary.
def route(tag):
    return {'trace_id':tag,'contracts':{'additive':True,'common_ledger':True,'positivity_certified':True,'grounded':True},'cells':[{'occurrence_id':'a','weight':2},{'occurrence_id':'b','weight':3}]}
ev=[
 {'event_id':'Q1','sequence':1,'type':'MEMORY_DROP','datum_id':'D1','signals':[{'operator':'IDENTITY_SEED','certified':True,'projection':'p1'}]},
 {'event_id':'Q2','sequence':2,'type':'ACTIVATE','contracts':[{'contract_id':'R','capability':'route_simplex','requires_all':['F001']}]},
 {'event_id':'Q3','sequence':3,'type':'CAPABILITY','capability':'route_simplex','contract_id':'R','capability_payload':route('r1')},
 {'event_id':'Q4','sequence':4,'type':'MEMORY_DROP','datum_id':'D2','signals':[{'operator':'DIRECTED_ONSET','certified':True,'projection':'p3'}]},
 {'event_id':'Q5','sequence':5,'type':'ACTIVATE','contracts':[{'contract_id':'R','capability':'route_simplex','requires_all':['F001']}]},
 {'event_id':'Q6','sequence':6,'type':'CAPABILITY','capability':'route_simplex','contract_id':'R','capability_payload':route('r2')},
]
contract={'contract_id':'QT','requires_certified_slots':['F001'],'requires_active_contracts':['R'],'requires_completed_capabilities':['route_simplex']}
full=h.memory_144_terminal_replay({'events':ev,'terminal_contract':contract}); ok(full['terminal_replay_valid'],'full')
rng=random.Random(15015)
for i in range(64):
    split=rng.randint(1,5)
    root=h.memory_144_create_terminal_checkpoint({'events':ev[:split],'terminal_contract':contract}); ok(root['terminal_checkpoint_valid'],'root')
    res=h.memory_144_resume_terminal_checkpoint({'checkpoint':root['checkpoint'],'sidecar_snapshot':root['sidecar_snapshot'],'events':ev[split:]}); ok(res['terminal_resume_valid'],'resume')
    for k in ('current_terminal','historical_terminal','first_terminal_prefix','terminal_history_accumulator','execution_state_hash'):
        ok(res['projection'][k]==full['projection'][k],f'eq {i} {k}')

receipt={'status':'PASS','checks':checks,'release_version':'1.0.0','capability_count':len(F['capabilities']),'schema_count':len(F['schemas']),'slot_terminal_cases':144,'checkpoint_suffix_cases':64,'truth_credit':0,'ac77_integration':'NOT_PERFORMED','dd094_integration':'NOT_PERFORMED'}
print(json.dumps(receipt,sort_keys=True))
