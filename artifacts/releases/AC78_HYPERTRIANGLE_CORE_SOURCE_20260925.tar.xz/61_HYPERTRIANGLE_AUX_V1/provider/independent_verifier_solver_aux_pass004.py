#!/usr/bin/env python3
import copy, hashlib, json, random
from itertools import permutations, product
from hypertriangle_solver_aux import (
    create_stream_checkpoint, resume_stream_checkpoint, certify_receipt_stream,
    validate_stream_checkpoint, encode
)

C={"common_scale_certified":True,"axis_independence_certified":True,"b4_comparable":True}

def state(v,e="1/100"):
    return {"values":v,"component_errors":[e]*4,"contracts":C}

def event(w,t,axis,e="1/100"):
    base=[8,6,4,2]; L=base[:]; R=base[:]; L[axis]=-2; R[axis]=2; a=[0,0,0,0]; a[axis]=1
    return {"wall_id":w,"alpha":a,"left":{"time":t-1,"values":L},"right":{"time":t+1,"values":R},"uniform_component_errors":[e]*4,
            "derivative_direction":1,"derivative_magnitude_lower":1,"derivative_error":e,"nominal_time":t,
            "contracts":{"uniform_error_over_bracket_certified":True}}

def base_stream(stream_id="ind"):
    return {"stream_id":stream_id,"requirements":{"required_state_slots":["S0","S1"],"required_event_slots":["E0","E1"],"required_wall_sequence":["w0","w1"]},"receipts":[
        {"receipt_id":"r1","sequence":1,"slot":"S0","kind":"state","payload":state([8,6,4,2])},
        {"receipt_id":"r2","sequence":2,"slot":"E0","kind":"event","payload":event("w0",2,0)},
        {"receipt_id":"r3","sequence":3,"slot":"S1","kind":"state","payload":state([7,-5,3,1])},
        {"receipt_id":"r4","sequence":4,"slot":"E1","kind":"event","payload":event("w1",5,1)},
    ]}

def compare_resume(full,prefix):
    cp=create_stream_checkpoint({"stream":full,"checkpoint_prefix":prefix})["checkpoint"]
    suffix=copy.deepcopy(full["receipts"][prefix:])
    resumed=resume_stream_checkpoint({"checkpoint":cp,"receipts":suffix})
    replay=certify_receipt_stream(full)
    assert resumed["final_stream_hash"]==replay["final_stream_hash"]
    assert resumed["first_terminal_prefix"]==replay["first_terminal_prefix"]
    assert resumed["first_terminal_stream_hash"]==replay["first_terminal_stream_hash"]
    assert resumed["current_terminal"]==replay["current_terminal"]
    assert resumed["historical_terminal"]==replay["historical_terminal"]
    return 5

def main():
    checks=0
    # Every arrival ordering: checkpoint midstream, then continuation equals full replay.
    items=("S0","S1","E0","E1")
    template={
      "S0":{"slot":"S0","kind":"state","payload":state([8,6,4,2])},
      "S1":{"slot":"S1","kind":"state","payload":state([7,-5,3,1])},
      "E0":{"slot":"E0","kind":"event","payload":event("w0",2,0)},
      "E1":{"slot":"E1","kind":"event","payload":event("w1",5,1)},
    }
    for order in permutations(items):
        rec=[]
        for i,k in enumerate(order,1):
            e=copy.deepcopy(template[k]); e["receipt_id"]=f"{k}-{i}"; e["sequence"]=i; rec.append(e)
        s={"stream_id":"perm-"+"".join(order),"requirements":{"required_state_slots":["S0","S1"],"required_event_slots":["E0","E1"],"required_wall_sequence":["w0","w1"]},"receipts":rec}
        for prefix in (0,1,2,3,4):
            checks += compare_resume(s,prefix)

    # 384 B4 single-state checkpoints and 10-message continuations.
    axes=("h1","h2","h3","h4")
    idx=0
    for signs in product((-1,1),repeat=4):
        for perm in permutations(range(4)):
            vals=[0]*4
            for rank,i in enumerate(perm): vals[i]=signs[i]*(8-2*rank)
            idx+=1
            s={"stream_id":f"b4-{idx}","requirements":{"required_state_slots":["S"]},"receipts":[
                {"receipt_id":"r1","sequence":1,"slot":"S","kind":"state","payload":{"axis_ids":list(axes),**state(vals)}}
            ]}
            for j in range(2,12):
                s["receipts"].append({"receipt_id":f"r{j}","sequence":j,"slot":"J","kind":"state","payload":state([50+j,30,20,10])})
            cp=create_stream_checkpoint({"stream":s,"checkpoint_prefix":1})["checkpoint"]
            resumed=resume_stream_checkpoint({"checkpoint":cp,"receipts":copy.deepcopy(s["receipts"][1:])})
            full=certify_receipt_stream(s)
            assert validate_stream_checkpoint(cp)["checkpoint_valid"]
            assert resumed["final_stream_hash"]==full["final_stream_hash"]
            assert resumed["first_terminal_prefix"]==1 and resumed["current_terminal"]
            checks+=4

    # Random long streams with checkpoint at arbitrary point.
    rng=random.Random(4004)
    for trial in range(500):
        s=base_stream(f"rnd-{trial}")
        n=rng.randrange(5,35)
        for seq in range(5,n+1):
            if seq%11==0:
                payload={"values":[1,2,3,4],"component_errors":[2,0,0,0],"contracts":C}; slot="S1"
            elif seq%13==0:
                payload=state([9,-7,5,3]); slot="S1"
            else:
                payload=state([100+seq,60,40,20]); slot=f"J{seq%3}"
            s["receipts"].append({"receipt_id":f"r{seq}","sequence":seq,"slot":slot,"kind":"state","payload":payload})
        prefix=rng.randrange(0,len(s["receipts"])+1)
        checks += compare_resume(s,prefix)

    # Checkpoint after a regression, then repair: historical regression/conflict must survive compaction.
    for trial in range(100):
        s=base_stream(f"conf-{trial}")
        s["receipts"].append({"receipt_id":"r5","sequence":5,"slot":"S1","kind":"state","payload":{"values":[1,2,3,4],"component_errors":[2,0,0,0],"contracts":C}})
        cp=create_stream_checkpoint({"stream":s})["checkpoint"]
        repair={"receipt_id":"r6","sequence":6,"slot":"S1","kind":"state","payload":state([9,-7,5,3])}
        r=resume_stream_checkpoint({"checkpoint":cp,"receipts":[repair]})
        assert r["current_terminal"] and r["historical_terminal"]
        assert r["ever_post_terminal_semantic_conflict"] and r["post_terminal_regression_seen"]
        assert r["first_terminal_prefix"]==4
        checks+=4

    # Tamper sensitivity.
    for trial in range(100):
        cp=create_stream_checkpoint({"stream":base_stream(f"tamper-{trial}")})["checkpoint"]
        bad=copy.deepcopy(cp); bad["next_sequence"] += 1
        v=validate_stream_checkpoint(bad)
        assert not v["checkpoint_valid"] and v["status"]=="CHECKPOINT_HASH_MISMATCH"
        checks+=2

    print(f"INDEPENDENT PASS004: {checks}/{checks} PASS")

if __name__=='__main__': main()
