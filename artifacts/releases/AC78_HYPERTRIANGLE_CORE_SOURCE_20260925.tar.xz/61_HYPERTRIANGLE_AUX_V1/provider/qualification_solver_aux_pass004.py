#!/usr/bin/env python3
import copy, random
from hypertriangle_solver_aux import create_stream_checkpoint, resume_stream_checkpoint, certify_receipt_stream

C={"common_scale_certified":True,"axis_independence_certified":True,"b4_comparable":True}

def state(v,e="1/100"):
    return {"values":v,"component_errors":[e]*4,"contracts":C}

def event(w,t,axis,e="1/100"):
    base=[8,6,4,2]; L=base[:]; R=base[:]; L[axis]=-2; R[axis]=2; a=[0,0,0,0]; a[axis]=1
    return {"wall_id":w,"alpha":a,"left":{"time":t-1,"values":L},"right":{"time":t+1,"values":R},"uniform_component_errors":[e]*4,
            "derivative_direction":1,"derivative_magnitude_lower":1,"derivative_error":e,"nominal_time":t,
            "contracts":{"uniform_error_over_bracket_certified":True}}

def base_stream(i):
    return {"stream_id":f"q-{i}","requirements":{"required_state_slots":["S0","S1"],"required_event_slots":["E0","E1"],"required_wall_sequence":["w0","w1"]},"receipts":[
        {"receipt_id":"r1","sequence":1,"slot":"S0","kind":"state","payload":state([8,6,4,2])},
        {"receipt_id":"r2","sequence":2,"slot":"E0","kind":"event","payload":event("w0",2,0)},
        {"receipt_id":"r3","sequence":3,"slot":"S1","kind":"state","payload":state([7,-5,3,1])},
        {"receipt_id":"r4","sequence":4,"slot":"E1","kind":"event","payload":event("w1",5,1)},
    ]}

def main():
    rng=random.Random(404404); checks=0
    ratios=[]
    for trial in range(1500):
        s=base_stream(trial)
        # Long-ish stream with mostly redundant observations; periodic degradations/repairs.
        n=20 + (trial % 40)
        for seq in range(5,n+1):
            if seq % 17 == 0:
                slot="S1"; payload={"values":[1,2,3,4],"component_errors":[2,0,0,0],"contracts":C}
            elif seq % 19 == 0:
                slot="S1"; payload=state([9,-7,5,3])
            else:
                slot=f"J{seq%5}"; payload=state([200+seq,90,50,25])
            s["receipts"].append({"receipt_id":f"r{seq}","sequence":seq,"slot":slot,"kind":"state","payload":payload})
        prefix=rng.randrange(0,len(s["receipts"])+1)
        c=create_stream_checkpoint({"stream":s,"checkpoint_prefix":prefix})
        assert c["checkpoint_valid"]
        cp=c["checkpoint"]
        r=resume_stream_checkpoint({"checkpoint":cp,"receipts":copy.deepcopy(s["receipts"][prefix:])})
        f=certify_receipt_stream(s)
        assert r["final_stream_hash"]==f["final_stream_hash"]
        assert r["first_terminal_prefix"]==f["first_terminal_prefix"]
        assert r["first_terminal_stream_hash"]==f["first_terminal_stream_hash"]
        assert r["current_terminal"]==f["current_terminal"]
        checks+=5
    # Separate 1000-receipt compression witness.
    for trial in range(12):
        s=base_stream(100000+trial)
        for seq in range(5,1001):
            s["receipts"].append({"receipt_id":f"r{seq}","sequence":seq,"slot":f"J{seq%4}","kind":"state","payload":state([500+seq,250,125,60])})
        c=create_stream_checkpoint({"stream":s})
        assert c["checkpoint_valid"] and float(c["canonical_compaction_ratio"]) < 0.20
        ratios.append(float(c["canonical_compaction_ratio"]))
        checks+=2
    print(f"QUALIFICATION PASS004: {checks}/{checks} PASS")
    if ratios:
        print(f"QUALIFICATION PASS004 CHECKPOINT RATIO: max={max(ratios):.6f} min={min(ratios):.6f} samples={len(ratios)}")

if __name__=='__main__': main()
