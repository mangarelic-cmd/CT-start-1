from __future__ import annotations
import json, os, tempfile
from pathlib import Path
from typing import Any, Dict, List, Sequence, Tuple

import hypertriangle_solver_aux as h


def canonical_json_text(obj: Any) -> str:
    return json.dumps(h.encode(obj), sort_keys=True, separators=(",", ":"), ensure_ascii=False) + "\n"


def atomic_write_json(path: str | os.PathLike[str], obj: Any) -> None:
    target=Path(path); target.parent.mkdir(parents=True, exist_ok=True)
    data=canonical_json_text(obj).encode("utf-8")
    fd,tmp=tempfile.mkstemp(prefix=target.name+".", suffix=".tmp", dir=str(target.parent))
    try:
        with os.fdopen(fd,"wb") as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,target)
        try:
            dfd=os.open(str(target.parent), os.O_RDONLY)
            try: os.fsync(dfd)
            finally: os.close(dfd)
        except Exception:
            pass
    finally:
        try:
            if os.path.exists(tmp): os.unlink(tmp)
        except Exception:
            pass


def load_snapshot(path: str | os.PathLike[str]) -> Dict[str, Any]:
    with open(path,"r",encoding="utf-8") as f: obj=json.load(f)
    v=h.validate_receipt_id_sidecar_snapshot(obj)
    if not v.get("snapshot_valid",False): raise ValueError(v.get("error") or v.get("status"))
    return obj


def init_snapshot(path: str | os.PathLike[str], receipt_ids: Sequence[Any]=(), *, generation: int=0) -> Dict[str, Any]:
    out=h.receipt_id_sidecar_snapshot({"receipt_ids":list(receipt_ids),"generation":generation})
    if not out.get("snapshot_valid",False): raise ValueError(out.get("error") or out.get("status"))
    atomic_write_json(path,out["snapshot"])
    return out["snapshot"]


def ensure_journal(path: str | os.PathLike[str]) -> None:
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    if not p.exists():
        with open(p,"wb") as f:
            f.flush(); os.fsync(f.fileno())


def append_journal_record(path: str | os.PathLike[str], record: Dict[str, Any]) -> None:
    p=Path(path); p.parent.mkdir(parents=True,exist_ok=True)
    line=canonical_json_text(record).encode("utf-8")
    with open(p,"ab") as f:
        f.write(line); f.flush(); os.fsync(f.fileno())


def read_journal_records(path: str | os.PathLike[str], *, allow_uncommitted_tail: bool=True) -> Dict[str, Any]:
    p=Path(path)
    if not p.exists(): return {"records":[],"truncated_tail_ignored":False,"committed_line_count":0}
    raw=p.read_bytes()
    records: List[Dict[str,Any]]=[]
    truncated=False
    lines=raw.splitlines(keepends=True)
    for i,line in enumerate(lines):
        committed=line.endswith(b"\n")
        payload=line[:-1] if committed else line
        if not payload.strip():
            if committed: continue
            if allow_uncommitted_tail: truncated=True; break
            raise ValueError("uncommitted final journal line")
        if not committed:
            if allow_uncommitted_tail:
                truncated=True; break
            raise ValueError("uncommitted final journal line")
        try:
            obj=json.loads(payload.decode("utf-8"))
        except Exception as exc:
            # A newline-terminated line is committed; malformed committed content is never ignored.
            raise ValueError(f"malformed committed journal line {i}: {exc}") from exc
        if not isinstance(obj,dict): raise ValueError(f"journal line {i} is not an object")
        records.append(obj)
    return {"records":records,"truncated_tail_ignored":truncated,"committed_line_count":len(records)}


def recover_files(snapshot_path: str | os.PathLike[str], journal_path: str | os.PathLike[str], *, allow_uncommitted_tail: bool=True) -> Dict[str, Any]:
    snapshot=load_snapshot(snapshot_path)
    jr=read_journal_records(journal_path,allow_uncommitted_tail=allow_uncommitted_tail)
    out=h.recover_receipt_id_sidecar({"snapshot":snapshot,"journal_records":jr["records"]})
    out["truncated_tail_ignored"]=bool(jr["truncated_tail_ignored"])
    out["committed_line_count"]=int(jr["committed_line_count"])
    return out


def append_file(snapshot_path: str | os.PathLike[str], journal_path: str | os.PathLike[str], receipt_id: Any) -> Dict[str, Any]:
    snapshot=load_snapshot(snapshot_path)
    jr=read_journal_records(journal_path,allow_uncommitted_tail=True)
    if jr["truncated_tail_ignored"]:
        raise ValueError("journal has uncommitted tail; recover/repair before appending")
    out=h.append_receipt_id_sidecar({"snapshot":snapshot,"journal_records":jr["records"],"receipt_id":str(receipt_id)})
    if not out.get("appended",False): raise ValueError(out.get("status"))
    append_journal_record(journal_path,out["journal_entry"])
    return out


def proof_files(snapshot_path: str | os.PathLike[str], journal_path: str | os.PathLike[str], receipt_id: Any) -> Dict[str, Any]:
    snapshot=load_snapshot(snapshot_path)
    jr=read_journal_records(journal_path,allow_uncommitted_tail=True)
    out=h.receipt_id_sidecar_proof({"snapshot":snapshot,"journal_records":jr["records"],"receipt_id":str(receipt_id)})
    out["truncated_tail_ignored"]=bool(jr["truncated_tail_ignored"])
    return out


def compact_files(snapshot_path: str | os.PathLike[str], journal_path: str | os.PathLike[str], new_snapshot_path: str | os.PathLike[str], new_journal_path: str | os.PathLike[str]) -> Dict[str, Any]:
    snapshot=load_snapshot(snapshot_path)
    jr=read_journal_records(journal_path,allow_uncommitted_tail=True)
    if jr["truncated_tail_ignored"]:
        raise ValueError("cannot compact with uncommitted journal tail")
    out=h.compact_receipt_id_sidecar({"snapshot":snapshot,"journal_records":jr["records"]})
    if not out.get("compacted",False): raise ValueError(out.get("status"))
    atomic_write_json(new_snapshot_path,out["snapshot"])
    p=Path(new_journal_path); p.parent.mkdir(parents=True,exist_ok=True)
    with open(p,"wb") as f: f.flush(); os.fsync(f.fileno())
    return out
