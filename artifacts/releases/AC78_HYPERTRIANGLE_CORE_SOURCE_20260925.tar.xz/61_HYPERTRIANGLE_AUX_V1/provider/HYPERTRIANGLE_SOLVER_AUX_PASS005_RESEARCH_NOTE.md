# HyperTriangle Solver AUX — PASS005 Research Note

Date: 2026-09-25  
Branch: `HYPERTRIANGLE_SOLVER_AUX`  
Parent: PASS004 standalone AUX.  
Scope: multi-checkpoint rotation and provenance chaining. **No AC77/DD094 integration or mutation.**

## 1. Objective
PASS004 compacted one verified receipt-stream prefix into a resumable checkpoint. PASS005 extends this to arbitrarily repeated compaction cycles without reopening already compacted payloads.

The target is a long-lived solver-side AUX process:

`checkpoint_0 + suffix_1 -> checkpoint_1 + suffix_2 -> ... -> checkpoint_n`

while preserving the original first-terminal certificate and a tamper-evident linear checkpoint lineage.

## 2. Rotation contract
`rotate_stream_checkpoint` accepts one valid checkpoint and a nonempty consecutive suffix. It first applies PASS004 continuation semantics to the suffix, then emits a new compact checkpoint.

The rotated checkpoint stores:

- monotonically increasing `rotation_index`;
- `previous_checkpoint_hash`;
- immutable `checkpoint_chain_root_hash`;
- exact ancestor `checkpoint_lineage` entries;
- suffix receipt count;
- SHA-256 commitment to the compacted suffix history;
- chained prefix-history commitment;
- cumulative rotation-history commitment;
- current latest-slot certificates;
- exact seen receipt IDs;
- frozen first-terminal prefix/hash/snapshot;
- persistent post-terminal regression/conflict summaries.

No prior compacted receipt payload is required to perform the next rotation.

## 3. First-terminal invariance
If a terminal prefix was established before any rotation, every later checkpoint must preserve exactly:

- `first_terminal_prefix`;
- `first_terminal_stream_hash`;
- `first_terminal_snapshot`.

A later conflict may make the current state nonterminal and a later repair may restore current terminality. Neither event may rewrite the original first-terminal certificate.

## 4. Checkpoint-chain audit
`validate_checkpoint_chain` independently checks a supplied archived checkpoint sequence for:

- valid self-hashes and checkpoint semantics;
- strict prefix growth;
- exact parent-checkpoint hash links;
- sequential rotation indices;
- constant stream ID and requirements;
- constant root checkpoint hash;
- exact lineage accumulation;
- rotation-history commitments;
- chained prefix-history commitments;
- immutable first-terminal evidence once established.

A branch/fork substituted into a linear chain is rejected because its `previous_checkpoint_hash` does not point to the preceding archived checkpoint.

## 5. Long-run result
The qualification witness processes 1,001 receipts through 50 successive rotations. The final checkpoint reproduces the full uncompressed stream hash and retains the original first-terminal prefix. The final checkpoint canonical size is approximately 32.6 kB.

PASS005 does not claim constant-size checkpoints: exact historical receipt IDs and the explicit checkpoint lineage still grow. The important reduction is that historical receipt payloads do not accumulate in the active checkpoint.

## 6. Authority firewall
Unchanged:

- `truth_credit = 0`;
- ROOT write capability = `NONE`;
- RETURN write capability = `NONE`;
- solver mutation capability = `NONE`;
- AC77 integration = `NOT_PERFORMED`;
- DD094 integration = `NOT_PERFORMED`.

## 7. Validation
- regression + unit tests: **57/57 PASS**;
- independent verifier: **8,162/8,162 PASS**;
- qualification: **11,705/11,705 PASS**;
- long-run witness: **1,001 receipts / 50 rotations**;
- cold replay: **PASS**.

## 8. Next front
PASS006 should attack the remaining long-run growth: a bounded checkpoint-lineage accumulator/anchor that can compact old checkpoint lineage entries while retaining a verifiable provenance commitment. It must remain standalone and must not alter AC77/DD094.
