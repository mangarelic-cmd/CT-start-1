#!/usr/bin/env python3
from itertools import permutations, product
from fractions import Fraction
import copy, hashlib, json, random
import hypertriangle_solver_aux as h

checks=0
def ck(x,msg='check'):
    global checks
    checks+=1
    if not x: raise AssertionError(msg)

def enc(x): return h.encode(x)
def canon(x): return json.dumps(enc(x),sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def manual_cp_hash(cp):
    body={k:copy.deepcopy(v) for k,v in cp.items() if k!='checkpoint_hash'}
    z=hashlib.sha256(); z.update(b'HYPERTRIANGLE_SOLVER_AUX_CHECKPOINT_V1\n'); z.update(canon(body)); return z.hexdigest()

def state(vals): return {'values':vals,'component_errors':['1/100']*4,'contracts':{'common_scale_certified':True,'axis_independence_certified':True,'b4_comparable':True}}
def one_stream(vals):
    return {'stream_id':'ind','requirements':{'required_state_slots':['S']},'receipts':[{'receipt_id':'r1','sequence':1,'slot':'S','kind':'state','payload':state(vals)}]}

# Exhaust all 384 B4 chambers through a real rotation.
for signs in product((-1,1), repeat=4):
  for perm in permutations(range(4)):
    vals=[0]*4
    for rank,axis in enumerate(perm): vals[axis]=signs[axis]*(8-2*rank)
    s=one_stream(vals); cp0=h.create_stream_checkpoint({'stream':s})['checkpoint']
    vals2=[v*2 for v in vals]
    e={'receipt_id':'r2','sequence':2,'slot':'S','kind':'state','payload':state(vals2)}
    rr=h.rotate_stream_checkpoint({'checkpoint':cp0,'receipts':[e]}); cp1=rr['checkpoint']
    ck(rr['status']=='STREAM_CHECKPOINT_ROTATED'); ck(cp1['rotation_index']==1)
    ck(cp1['previous_checkpoint_hash']==cp0['checkpoint_hash']); ck(cp1['prefix_length']==2)
    ck(cp1['first_terminal_prefix']==1); ck(cp1['first_terminal_stream_hash']==cp0['first_terminal_stream_hash'])
    ck(manual_cp_hash(cp1)==cp1['checkpoint_hash']); ck(len(cp1['checkpoint_lineage'])==1)
    v=h.validate_checkpoint_chain({'checkpoints':[cp0,cp1]}); ck(v['chain_valid']); ck(v['chain_tip_stream_hash']==cp1['prefix_stream_hash'])

# Random multi-rotation chains. Check against full replay.
rng=random.Random(20260925)
for case in range(120):
    vals=[20,15,10,5]
    stream=one_stream(vals); stream['stream_id']=f'r{case}'
    cp=h.create_stream_checkpoint({'stream':stream})['checkpoint']; chain=[cp]
    full=list(stream['receipts']); seq=1
    for rot in range(8):
        batch=[]
        for j in range(rng.randint(1,4)):
            seq+=1
            vv=[20+seq,15,10,5]
            e={'receipt_id':f'r{seq}','sequence':seq,'slot':'S','kind':'state','payload':state(vv)}
            batch.append(e); full.append(copy.deepcopy(e))
        rr=h.rotate_stream_checkpoint({'checkpoint':cp,'receipts':batch}); ck(rr['rotated'])
        cp=rr['checkpoint']; chain.append(cp)
        ck(cp['prefix_length']==seq); ck(len(cp['seen_receipt_ids'])==seq); ck(manual_cp_hash(cp)==cp['checkpoint_hash'])
    audit=h.validate_checkpoint_chain({'checkpoints':chain}); ck(audit['chain_valid']); ck(audit['rotation_count']==8)
    replay=h.certify_receipt_stream({'stream_id':stream['stream_id'],'requirements':stream['requirements'],'receipts':full})
    ck(cp['prefix_stream_hash']==replay['final_stream_hash']); ck(cp['first_terminal_prefix']==replay['first_terminal_prefix'])

# Fork and tamper negative controls.
s=one_stream([8,6,4,2]); cp0=h.create_stream_checkpoint({'stream':s})['checkpoint']
a=h.rotate_stream_checkpoint({'checkpoint':cp0,'receipts':[{'receipt_id':'r2','sequence':2,'slot':'S','kind':'state','payload':state([10,7,4,2])}]})['checkpoint']
b=h.rotate_stream_checkpoint({'checkpoint':cp0,'receipts':[{'receipt_id':'r2b','sequence':2,'slot':'S','kind':'state','payload':state([11,7,4,2])}]})['checkpoint']
ck(not h.validate_checkpoint_chain({'checkpoints':[cp0,a,b]})['chain_valid'])
t=copy.deepcopy(a); t['rotation_suffix_receipt_count']=99; body={k:copy.deepcopy(v) for k,v in t.items() if k!='checkpoint_hash'}; t['checkpoint_hash']=h._checkpoint_hash_body(body)
ck(not h.validate_stream_checkpoint(t)['checkpoint_valid'])

print(f'PASS005 independent verifier: {checks}/{checks} PASS')
