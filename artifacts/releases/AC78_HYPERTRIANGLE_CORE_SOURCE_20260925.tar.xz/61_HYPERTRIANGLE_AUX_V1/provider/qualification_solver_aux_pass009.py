#!/usr/bin/env python3
from __future__ import annotations
import json, random, tempfile
from pathlib import Path
import hypertriangle_solver_aux as h
import receipt_id_sidecar_store as st
checks=0
def ck(x,msg='PASS009 qualification'):
    global checks; checks+=1
    if not x: raise AssertionError(msg)
rng=random.Random(909090)
# Random pure policy/compaction cycles.
for case in range(6):
    sp=h.receipt_id_sidecar_snapshot({'receipt_ids':[f'q{case}-root']})['snapshot']; recs=[]; expected=1
    mr=rng.randint(1,10); mb=rng.randint(500,5000)
    for j in range(rng.randint(5,15)):
        x=h.append_receipt_id_sidecar({'snapshot':sp,'journal_records':recs,'receipt_id':f'q{case}-{j}'}); ck(x['appended']); recs.append(x['journal_entry']); expected+=1
        d=h.receipt_id_sidecar_compaction_decision({'snapshot':sp,'journal_records':recs,'policy':{'max_journal_records':mr,'max_journal_bytes':mb}}); ck(d['decision_valid']); ck(d['receipt_id_count']==expected)
    a=h.receipt_id_sidecar_auto_compact({'snapshot':sp,'journal_records':recs,'policy':{'max_journal_records':mr,'max_journal_bytes':mb}}); ck(a['auto_compaction_valid'])
    if a['compaction_performed']: ck(a['snapshot']['receipt_id_count']==expected)
# Persistent store with automatic compaction and proofs.
for case in range(4):
    with tempfile.TemporaryDirectory() as td:
        threshold=rng.randint(2,7); window=rng.randint(2,6); st.init_store(td,[f'root{case}'],policy={'max_journal_records':threshold,'max_journal_bytes':99999999},anchor_window=window); ids=[f'root{case}']
        for j in range(8):
            rid=f'k{case}-{j}'; out=st.append_store(td,rid); ck(out['appended']); ids.append(rid)
            if j%4==0:
                v=st.verify_store(td); ck(v['receipt_id_count']==len(ids)); p=st.proof_store(td,rid); ck(p['present'])
        v=st.verify_store(td,audit_archives=True); ck(v['receipt_id_count']==len(ids)); p=st.load_pointer(td); ck(len(p['snapshot_chain_state']['anchors'])<=window)
# Long witness: 60 IDs, threshold 10 => 6 automatic snapshot generations, bounded 4-anchor state.
with tempfile.TemporaryDirectory() as td:
    st.init_store(td,['long-root'],policy={'max_journal_records':10,'max_journal_bytes':99999999},anchor_window=4)
    for i in range(60):
        o=st.append_store(td,f'long-{i:05d}'); ck(o['appended'])
    v=st.verify_store(td,audit_archives=True); p=st.load_pointer(td)
    ck(v['receipt_id_count']==61); ck(p['generation']==6); ck(len(p['snapshot_chain_state']['anchors'])==4); ck(p['snapshot_chain_state']['compacted_snapshot_count']==3)
    pointer_bytes=len(json.dumps(h.encode(p),sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())
    print(f'long_store_ids=61 generation={p["generation"]} chain_anchors={len(p["snapshot_chain_state"]["anchors"])} chain_compacted={p["snapshot_chain_state"]["compacted_snapshot_count"]} current_pointer_bytes={pointer_bytes}')
print(f'PASS009 qualification: {checks}/{checks} PASS')
