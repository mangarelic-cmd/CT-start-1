# HyperTriangle Solver AUX — PASS006 Research Note

Date: 2026-09-25  
Branch: `HYPERTRIANGLE_SOLVER_AUX`  
Parent: PASS005 standalone AUX.  
Scope: bounded checkpoint-lineage accumulator and anchor window. **No AC77/DD094 integration or mutation.**

## 1. Objective
PASS005 made repeated checkpoint rotation exact, but every active checkpoint retained the full explicit `checkpoint_lineage`. Its size therefore grew linearly with the number of rotations even after historical receipt payloads had been compacted.

PASS006 removes that rotation-count growth from the active lineage representation.

The target is:

`old checkpoint -> bounded lineage accumulator + recent anchors -> next bounded checkpoint`

while preserving:

- the root checkpoint commitment;
- the immediately previous checkpoint hash;
- the cumulative rotation-history commitment;
- the cumulative prefix-history commitment;
- exact first-terminal evidence;
- exact current certification semantics;
- exact historical receipt-ID duplicate detection;
- auditability against archived checkpoints.

## 2. Bounded lineage representation
A PASS006 bounded checkpoint no longer stores the complete `checkpoint_lineage` array. Instead it stores:

- `lineage_entry_count`;
- `lineage_compacted_count`;
- `lineage_prefix_accumulator`;
- a fixed `lineage_anchor_window_size`;
- `lineage_anchors`, containing only the most recent ancestor entries;
- `lineage_accumulator`, committing to all ancestor entries.

The rolling lineage accumulator is domain-separated SHA-256:

`A_0 = H(domain || EMPTY)`

`A_{k+1} = H(domain || STEP || A_k || canonical(entry_k))`.

When the anchor window is full, its oldest entry is absorbed into the prefix accumulator and removed from the active anchor list. The number of retained lineage entries is therefore bounded by the declared anchor window.

## 3. Migration from PASS005
`rotate_bounded_checkpoint` accepts either:

1. an existing PASS005 full-lineage checkpoint; or
2. an existing PASS006 bounded-lineage checkpoint.

On the first PASS006 rotation, the full PASS005 ancestry is folded into the accumulator and only the final anchor window is retained. Subsequent rotations update the accumulator incrementally.

There is no rewrite of an already published PASS005 checkpoint at the same rotation index. The bounded representation begins naturally at the next checkpoint rotation.

## 4. What standalone validation proves
`validate_bounded_checkpoint` proves the current bounded checkpoint's:

- self-hash;
- stream/prefix structure;
- terminal snapshot consistency;
- retained anchor order;
- anchor-to-parent hash binding;
- accumulator consistency over retained anchors;
- rotation-history and prefix-history commitments;
- authority firewalls.

If old ancestor metadata have already been compacted, the active tip alone cannot reconstruct their contents. This is intentional. The accumulator is a commitment, not an archival replacement.

`validate_bounded_checkpoint_chain` closes the stronger audit when archived checkpoints are supplied: every bounded child is independently reconstructed from the preceding checkpoint's lineage state and compared field-by-field. A rehashed substitution of the compacted-prefix accumulator therefore fails the archived-chain audit even if the modified tip is internally self-consistent.

## 5. First-terminal and solver semantics
PASS006 does not modify PASS003–PASS005 semantics. The first terminal prefix/hash/snapshot remain immutable. A later conflict and later repair may alter current terminality but cannot rewrite historical first-terminal evidence.

Likewise, the exact `seen_receipt_ids` set is still retained. PASS006 therefore continues to reject duplicate receipt IDs across arbitrarily many rotations.

## 6. Long-run boundedness result
The qualification witness executes **500 successive bounded rotations** with an anchor window of 8.

At the final checkpoint:

- rotations: `500`;
- receipts: `501`;
- explicit retained lineage anchors: `8`;
- compacted lineage entries: `492`;
- final bounded-lineage component: approximately `3.6 kB` canonical;
- full active checkpoint: approximately `12.4 kB` canonical.

The lineage component remains bounded with respect to rotation count once the anchor window is saturated.

PASS006 does **not** claim the complete checkpoint is constant-size: `seen_receipt_ids` still grows because exact duplicate detection is preserved without external membership witnesses.

## 7. Authority firewall
Unchanged:

- `truth_credit = 0`;
- ROOT write capability = `NONE`;
- RETURN write capability = `NONE`;
- solver mutation capability = `NONE`;
- AC77 integration = `NOT_PERFORMED`;
- DD094 integration = `NOT_PERFORMED`.

## 8. Validation
- regression + unit tests: **73/73 PASS**;
- independent verifier: **14,071/14,071 PASS**;
- qualification: **30,665/30,665 PASS**;
- long-run witness: **500 rotations / 501 receipts / 8 retained anchors**;
- parent PASS005 nonmutable integrity: checked in the release receipt;
- cold replay: **PASS**.

## 9. Next front
PASS007 should attack the remaining unbounded component: exact historical receipt-ID membership. The branch must determine whether an exact bounded accumulator can be used only with explicit membership/non-membership witnesses or an external authenticated index, or whether exact standalone duplicate detection forces unbounded retained identity information. No probabilistic Bloom-style false-positive structure may silently replace exact duplicate detection.
