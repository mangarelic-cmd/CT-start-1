# HyperTriangle Solver AUX — Claim Firewall (PASS014)

This package is a **standalone AUX**. It is not integrated into AC77, DD094, or any external solver registry.

PASS010 adds a native 144-slot memory layer. The direction of memory is fixed:

`incoming data -> invariant/operator signature -> F001..F144 flag`

and **not** `category -> search/pull data`.

Hard guards:

- the grid contains exactly 144 immutable slot identities `F001..F144`;
- trace numbering starts at 1;
- a datum without an explicit canonical invariant/operator signature is not classified;
- a datum may flag several slots when it carries several independent canonical invariant signatures;
- a supplied slot must agree with the operator-derived slot;
- context/projection may select a manifestation but cannot rewrite the canonical slot/function;
- uncertified observations may raise a seen flag/hit count but do not replace `last_invariants_saved`;
- only later certified observations replace the active last invariant/projection for that slot;
- the memory state retains hashes, flags, counts, last certified invariants, residuals and reconstruction references, not arbitrary raw history;
- exact raw-history replay is not claimed unless an external replay/reconstruction contract supplies what Causal Memory requires.

The Causal Memory no-free-history/injectivity boundary remains in force. PASS010 does not claim that 144 flags alone can reconstruct arbitrary raw history.

All PASS001–PASS009 firewalls remain active, including exact receipt-ID sidecar boundaries.

No scientific or solver truth is minted:

- `truth_credit = 0`;
- ROOT write = `NONE`;
- RETURN write = `NONE`;
- solver mutation = `NONE`;
- AC77 integration = `NOT_PERFORMED`;
- DD094 integration = `NOT_PERFORMED`.

## PASS011 addendum — activation firewall

PASS011 adds only declared-contract relevance evaluation. It does not infer a relation between any `F001..F144` slot and a solver capability.

- an activation contract needs at least one positive certified-slot requirement;
- uncertified flags never satisfy activation;
- unknown or external capabilities are rejected;
- one canonical contract per local activation target is required per evaluation;
- require/forbid overlap is rejected;
- no contracts means no inferred active capabilities;
- activation receipts have `execution_performed = false`;
- activation cannot write ROOT/RETURN, mutate a solver, or grant truth credit.

## PASS012 addendum — execution/provenance firewall

PASS012 may execute one local AUX capability only after a valid PASS011 activation receipt proves that its explicit contract is ACTIVE.

Hard guards:

- the target must be one of the 19 PASS011 standalone local activation targets;
- memory, activation, bridge, sidecar, and external-solver modes cannot be execution targets;
- the capability payload must be explicit and is hash-committed before execution;
- the typed request is bound to the memory-state hash, activation-state hash, source contract, supporting slots, and surviving invariant commitments;
- the local capability receipt is hash-committed and bound to the typed request;
- exact replay is available when the typed request is supplied to the execution validator;
- `memory_feedback_performed = false`;
- `activation_reentry_performed = false`;
- capability output cannot automatically raise a memory flag or activate another capability;
- execution does not grant scientific truth, ROOT/RETURN authority, or external solver mutation.

## PASS013 addendum — unified persistence firewall

PASS013 does not create a second history system. It binds the PASS010-PASS012 pipeline to the exact persistence primitives already established in PASS007-PASS009.

Hard guards:

- pipeline events are explicit `MEMORY_DROP`, `ACTIVATE`, or `CAPABILITY` objects with one-based contiguous sequence numbers and nonempty exact event IDs;
- exact duplicate detection after checkpoint compaction uses the PASS007 Sparse-Merkle root plus the PASS008 exact external sidecar; no Bloom filter or probabilistic membership is introduced;
- every unified checkpoint binds the exact sidecar snapshot by snapshot hash, root, count, and generation;
- sidecar snapshot rotations are appended to the bounded PASS009 snapshot-chain state;
- every `MEMORY_DROP` clears the current activation receipt, so capability execution cannot continue under an activation bound to an older memory-state hash;
- capability events preserve PASS012's no-feedback and no-reentry firewall;
- the checkpoint stores only bounded provenance summaries for the latest typed request/execution; historical payload replay still requires archived events;
- the pipeline-history accumulator is an archival commitment, not a claim that a rehashed checkpoint can reconstruct or independently validate discarded historical payloads without the archived prefix/transition evidence;
- `checkpoint + sidecar + suffix == full replay` is certified only for the explicitly declared PASS013 projection, not arbitrary discarded raw history;
- no AC77/DD094 registration, ROOT/RETURN write, solver mutation, or truth credit is introduced.


## PASS014 addendum — terminality firewall

PASS014 does not infer truth, scientific completion, or external solver success. `AUX_TERMINAL` is strictly local completion of one explicit terminal contract.

Hard guards:

- at least one positive terminal obligation is required;
- terminal requirements are explicit and hash-committed;
- certified slot obligations use only surviving certified memory state;
- completed-capability obligations are fresh only when their execution is bound to the current memory-state hash and current activation-state hash;
- require/forbid overlap is rejected;
- forbidden certified slots produce a distinct semantic-conflict state;
- the first terminal prefix and certificate are frozen once observed;
- later regressions and later repairs cannot rewrite the first terminal certificate;
- terminal checkpoint continuation reuses PASS013 exact sidecar/persistence and does not create a second history authority;
- full validation of discarded historical continuation commitments still requires archived replay/transition evidence;
- terminality grants zero truth credit and no ROOT/RETURN/external-solver authority.


## PASS015 addendum — final standalone freeze

PASS015 adds no new scientific or solver semantics. It freezes the exact v1 ABI, JSON schemas, F001–F144 canon, implementation files and authority boundary of the PASS014-complete standalone AUX. The freeze is a reproducibility/compatibility statement only. It does not promote local terminality into scientific truth, register with AC77/DD094, grant ROOT/RETURN writes, mutate an external solver, or permit capability output to feed memory automatically.

Any future semantic, schema, capability-name or canonical-slot change requires a new release/version and cannot be represented as the same frozen v1 ABI.
