from pathlib import Path
import hashlib,json,zipfile,os,sys
ROOT=Path(__file__).resolve().parent
EXCLUDE={'MANIFEST.json','CHECKSUMS.sha256'}

def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def files():
    out=[]
    for p in ROOT.rglob('*'):
        if not p.is_file(): continue
        rel=p.relative_to(ROOT).as_posix()
        if '__pycache__' in rel or rel.endswith('.pyc') or rel in EXCLUDE: continue
        out.append((rel,p))
    return sorted(out)
def write_meta():
    fs=files()
    m={'branch':'HYPERTRIANGLE_SOLVER_AUX','date':'2026-09-25','external_solver_integration_performed':False,'file_count':len(fs),'files':[{'path':r,'sha256':sha(p),'size':p.stat().st_size} for r,p in fs],'manifest_note':'PASS010 standalone AUX; MANIFEST.json and CHECKSUMS.sha256 are self-excluded.','pass':'PASS010','version':'0.10.0'}
    (ROOT/'MANIFEST.json').write_text(json.dumps(m,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    (ROOT/'CHECKSUMS.sha256').write_text(''.join(f"{sha(p)}  {r}\n" for r,p in fs),encoding='utf-8')
    return m

def build(out):
    write_meta()
    allf=[]
    for p in ROOT.rglob('*'):
        if not p.is_file(): continue
        rel=p.relative_to(ROOT).as_posix()
        if '__pycache__' in rel or rel.endswith('.pyc') or rel.startswith('.git/') or rel=='build_release_pass010.py':
            # builder is included below too; only caches excluded
            pass
        allf.append((rel,p))
    allf=[x for x in allf if '__pycache__' not in x[0] and not x[0].endswith('.pyc')]
    allf=sorted(allf)
    out=Path(out)
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for rel,p in allf:
            zi=zipfile.ZipInfo(rel,date_time=(2026,9,25,12,0,0)); zi.compress_type=zipfile.ZIP_DEFLATED; zi.external_attr=(0o644 & 0xFFFF)<<16
            z.writestr(zi,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    return out
if __name__=='__main__':
    out=sys.argv[1] if len(sys.argv)>1 else str(ROOT.parent/'HYPERTRIANGLE_SOLVER_AUX_PASS010_20260925.zip')
    p=build(out); print(json.dumps({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size,'manifest_files':json.loads((ROOT/'MANIFEST.json').read_text())['file_count']},sort_keys=True))
