import copy, json, random
import hypertriangle_solver_aux as h

checks=0

def ck(cond,msg):
    global checks
    checks+=1
    if not cond: raise AssertionError(msg)

def route_payload(tag):
    return {'trace_id':tag,'contracts':{'additive':True,'common_ledger':True,'positivity_certified':True,'grounded':True},'cells':[{'occurrence_id':'x','weight':1},{'occurrence_id':'y','weight':4}]}

def evs():
    return [
      {'event_id':'I1','sequence':1,'type':'MEMORY_DROP','datum_id':'D1','signals':[{'operator':'IDENTITY_SEED','certified':True,'projection':'x'}]},
      {'event_id':'I2','sequence':2,'type':'ACTIVATE','contracts':[{'contract_id':'R','capability':'route_simplex','requires_all':['F001']}]},
      {'event_id':'I3','sequence':3,'type':'CAPABILITY','capability':'route_simplex','contract_id':'R','capability_payload':route_payload('a')},
      {'event_id':'I4','sequence':4,'type':'MEMORY_DROP','datum_id':'D2','signals':[{'operator':'DIRECTED_ONSET','certified':True,'projection':'y'}]},
      {'event_id':'I5','sequence':5,'type':'ACTIVATE','contracts':[{'contract_id':'R','capability':'route_simplex','requires_all':['F001']}]},
      {'event_id':'I6','sequence':6,'type':'CAPABILITY','capability':'route_simplex','contract_id':'R','capability_payload':route_payload('b')},
    ]

def con(): return {'contract_id':'T','requires_certified_slots':['F001'],'requires_active_contracts':['R'],'requires_completed_capabilities':['route_simplex']}

full=h.memory_144_terminal_replay({'events':evs(),'terminal_contract':con()})
ck(full.get('terminal_replay_valid') is True,'full')
ck(full['projection']['first_terminal_prefix']==3,'prefix')
ck(full['projection']['current_terminal'] is True,'final terminal')
ck(full['projection']['post_terminal_regression_count']==2,'regressions')

rng=random.Random(9914)
for i in range(36):
    split=rng.randint(1,5)
    root=h.memory_144_create_terminal_checkpoint({'events':evs()[:split],'terminal_contract':con()})
    ck(root.get('terminal_checkpoint_valid') is True,'root')
    x=h.memory_144_resume_terminal_checkpoint({'checkpoint':root['checkpoint'],'sidecar_snapshot':root['sidecar_snapshot'],'events':evs()[split:]})
    ck(x.get('terminal_resume_valid') is True,'resume')
    ck(x['projection']['terminal_history_accumulator']==full['projection']['terminal_history_accumulator'],'history')
    ck(x['projection']['first_terminal_prefix']==3,'frozen prefix')
    ck(x['projection']['execution_state_hash']==full['projection']['execution_state_hash'],'exec state')

# Self-hash and semantic tamper rejection. Rehash the outer checkpoint when needed so semantic checks are exercised.
root=h.memory_144_create_terminal_checkpoint({'events':evs()[:3],'terminal_contract':con()})
base=root['checkpoint']
mutations=[]
for field,value in [('current_terminal',False),('execution_state_hash','0'*64),('terminal_history_accumulator','1'*64),('stop_policy','CONTINUE_ACQUISITION')]:
    b=copy.deepcopy(base); b[field]=value; body={k:copy.deepcopy(v) for k,v in b.items() if k!='terminal_checkpoint_hash'}; b['terminal_checkpoint_hash']=h._memory_144_terminal_checkpoint_hash(body); mutations.append(b)
b=copy.deepcopy(base); b['first_terminal_certificate']['prefix_event_count']=2; body={k:copy.deepcopy(v) for k,v in b.items() if k!='terminal_checkpoint_hash'}; b['terminal_checkpoint_hash']=h._memory_144_terminal_checkpoint_hash(body); mutations.append(b)
b=copy.deepcopy(base); b['latest_execution_by_capability']['route_simplex']['source_memory_state_hash']='2'*64; b['execution_state_hash']=h._memory_144_terminal_execution_state_hash(b['latest_execution_by_capability']); body={k:copy.deepcopy(v) for k,v in b.items() if k!='terminal_checkpoint_hash'}; b['terminal_checkpoint_hash']=h._memory_144_terminal_checkpoint_hash(body); mutations.append(b)
for b in mutations: ck(h.validate_memory_144_terminal_checkpoint({'checkpoint':b}).get('terminal_checkpoint_valid') is False,'tamper')

# First-terminal certificate cannot be replaced in a child transition even by a structurally valid alternative child.
child=h.memory_144_rotate_terminal_checkpoint({'checkpoint':base,'sidecar_snapshot':root['sidecar_snapshot'],'events':evs()[3:]})
ck(child.get('terminal_checkpoint_valid') is True,'child')
tr=h.validate_memory_144_terminal_transition({'parent_checkpoint':base,'parent_sidecar_snapshot':root['sidecar_snapshot'],'events':evs()[3:],'child_checkpoint':child['checkpoint'],'child_sidecar_snapshot':child['sidecar_snapshot']})
ck(tr.get('terminal_transition_valid') is True,'transition')

receipt={'status':'PASS','checks':checks,'random_equivalence_cases':36,'tamper_cases':len(mutations),'transition_cases':1,'truth_credit':0}
print(json.dumps(receipt,sort_keys=True))
