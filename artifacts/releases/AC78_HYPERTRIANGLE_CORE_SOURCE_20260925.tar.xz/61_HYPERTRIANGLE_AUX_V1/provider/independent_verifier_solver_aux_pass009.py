#!/usr/bin/env python3
from __future__ import annotations
import copy, hashlib, json, random, tempfile
from pathlib import Path
import hypertriangle_solver_aux as h
import receipt_id_sidecar_store as st

checks=0
def ck(x,msg='PASS009 independent check'):
    global checks; checks+=1
    if not x: raise AssertionError(msg)

def canon(x): return json.dumps(h.encode(x),sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
ENTRY=b'HYPERTRIANGLE_RECEIPT_ID_SIDECAR_SNAPSHOT_CHAIN_ENTRY_V1\n'
ACC=b'HYPERTRIANGLE_RECEIPT_ID_SIDECAR_SNAPSHOT_CHAIN_ACCUMULATOR_V1\n'
STATE=b'HYPERTRIANGLE_RECEIPT_ID_SIDECAR_SNAPSHOT_CHAIN_STATE_V1\n'
def hh(*xs):
    q=hashlib.sha256()
    for x in xs:q.update(x)
    return q.hexdigest()
def entry(snapshot):
    body={'generation':int(snapshot['generation']),'snapshot_hash':str(snapshot['snapshot_hash']),'parent_snapshot_hash':snapshot.get('parent_snapshot_hash'),'compacted_journal_tail_hash':snapshot.get('compacted_journal_tail_hash'),'receipt_id_count':int(snapshot['receipt_id_count']),'receipt_id_root':str(snapshot['receipt_id_root'])}
    out=dict(body); out['entry_hash']=hh(ENTRY,canon(body)); return out
def seed(): return hh(ACC,b'EMPTY\n')
def step(prev,e): return hh(ACC,b'STEP\n',bytes.fromhex(prev),canon(e))
def fold(es,start=None):
    a=start or seed()
    for e in es:a=step(a,e)
    return a
def state_hash(s):
    body={k:copy.deepcopy(v) for k,v in s.items() if k!='chain_state_hash'}
    return hh(STATE,canon(body))

def make_child(parent, ids):
    recs=[]
    for rid in ids:
        x=h.append_receipt_id_sidecar({'snapshot':parent,'journal_records':recs,'receipt_id':rid}); ck(x['appended']); recs.append(x['journal_entry'])
    c=h.compact_receipt_id_sidecar({'snapshot':parent,'journal_records':recs}); ck(c['compacted']); return c['snapshot'],recs

rng=random.Random(909009)
# Independent bounded chain accumulator/hash verification.
for case in range(20):
    snaps=[h.receipt_id_sidecar_snapshot({'receipt_ids':[f'root-{case}']})['snapshot']]
    for g in range(1,10): snaps.append(make_child(snaps[-1],[f'{case}-{g}'])[0])
    window=1+(case%5); out=h.receipt_id_sidecar_snapshot_chain({'snapshots':snaps,'anchor_window':window}); ck(out['chain_valid']); s=out['chain_state']
    es=[entry(x) for x in snaps]; n=max(0,len(es)-window); pref=fold(es[:n]); acc=fold(es[n:],pref)
    ck(s['prefix_accumulator']==pref); ck(s['chain_accumulator']==acc); ck(tuple(s['anchors'])==tuple(es[n:])); ck(s['chain_state_hash']==state_hash(s)); ck(h.validate_receipt_id_sidecar_snapshot_chain({'chain_state':s})['chain_valid'])
# Incremental chain state must equal full rebuild.
for case in range(12):
    snaps=[h.receipt_id_sidecar_snapshot({'receipt_ids':[f'i{case}']})['snapshot']]
    for g in range(1,14): snaps.append(make_child(snaps[-1],[f'i{case}-{g}'])[0])
    window=3+(case%3); state=h.receipt_id_sidecar_snapshot_chain({'snapshots':[snaps[0]],'anchor_window':window})['chain_state']
    for child in snaps[1:]:
        q=h.receipt_id_sidecar_snapshot_chain_append({'chain_state':state,'snapshot':child}); ck(q['chain_valid']); state=q['chain_state']
    full=h.receipt_id_sidecar_snapshot_chain({'snapshots':snaps,'anchor_window':window})['chain_state']; ck(state['chain_accumulator']==full['chain_accumulator']); ck(state['chain_state_hash']==full['chain_state_hash'])
# Policy: independently count canonical newline-delimited journal bytes and threshold decision.
for case in range(40):
    sp=h.receipt_id_sidecar_snapshot({'receipt_ids':[f'p{case}']})['snapshot']; recs=[]
    n=rng.randint(0,8)
    for j in range(n): recs.append(h.append_receipt_id_sidecar({'snapshot':sp,'journal_records':recs,'receipt_id':f'p{case}-{j}'})['journal_entry'])
    rb=sum(len(json.dumps(h.encode(r),sort_keys=True,separators=(',',':'),ensure_ascii=False).encode())+1 for r in recs)
    mr=rng.randint(1,9); mb=rng.randint(1,5000); d=h.receipt_id_sidecar_compaction_decision({'snapshot':sp,'journal_records':recs,'policy':{'max_journal_records':mr,'max_journal_bytes':mb}}); ck(d['decision_valid']); ck(d['journal_record_count']==n); ck(d['journal_canonical_bytes']==rb); ck(d['compact_now']==bool(n and (n>=mr or rb>=mb)))
# Generational store campaigns with archive audit.
for case in range(18):
    with tempfile.TemporaryDirectory() as td:
        threshold=1+(case%5); window=2+(case%4); st.init_store(td,[f's{case}-root'],policy={'max_journal_records':threshold,'max_journal_bytes':99999999},anchor_window=window)
        total=1
        for j in range(20):
            out=st.append_store(td,f's{case}-{j}'); ck(out['appended']); total+=1
        v=st.verify_store(td,audit_archives=True); ck(v['receipt_id_count']==total); p=st.load_pointer(td); ck(p['generation']==20//threshold); ck(len(p['snapshot_chain_state']['anchors'])<=window); ck(h.validate_receipt_id_sidecar_snapshot_chain({'chain_state':p['snapshot_chain_state']})['chain_valid'])
# Tamper and orphan cases.
for case in range(20):
    with tempfile.TemporaryDirectory() as td:
        st.init_store(td,[f't{case}']); p=Path(td)/'CURRENT.json'; obj=json.loads(p.read_text()); obj['receipt_id_count']+=1; p.write_text(json.dumps(obj))
        try: st.load_pointer(td); ck(False)
        except ValueError: ck(True)
print(f'PASS009 independent verifier: {checks}/{checks} PASS')
