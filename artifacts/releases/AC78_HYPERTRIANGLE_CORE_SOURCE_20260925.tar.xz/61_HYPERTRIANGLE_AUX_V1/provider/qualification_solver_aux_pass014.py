import json, random
import hypertriangle_solver_aux as h

checks=0

def ok(cond,msg):
    global checks
    checks+=1
    if not cond: raise AssertionError(msg)

def route_payload(tag='Q14'):
    return {'trace_id':tag,'contracts':{'additive':True,'common_ledger':True,'positivity_certified':True,'grounded':True},'cells':[{'occurrence_id':'a','weight':2},{'occurrence_id':'b','weight':3},{'occurrence_id':'c','weight':5}]}

def events8():
    return [
      {'event_id':'E001','sequence':1,'type':'MEMORY_DROP','datum_id':'D1','signals':[{'operator':'IDENTITY_SEED','certified':True,'projection':'p1'}]},
      {'event_id':'E002','sequence':2,'type':'ACTIVATE','contracts':[{'contract_id':'C-route','capability':'route_simplex','requires_all':['F001']}]},
      {'event_id':'E003','sequence':3,'type':'CAPABILITY','capability':'route_simplex','contract_id':'C-route','capability_payload':route_payload('r1')},
      {'event_id':'E004','sequence':4,'type':'MEMORY_DROP','datum_id':'D2','signals':[{'operator':'DIRECTED_ONSET','certified':True,'projection':'p3'}]},
      {'event_id':'E005','sequence':5,'type':'ACTIVATE','contracts':[{'contract_id':'C-pol','capability':'signed_polarity','requires_all':['F003']}]},
      {'event_id':'E006','sequence':6,'type':'CAPABILITY','capability':'signed_polarity','contract_id':'C-pol','capability_payload':{'values':[3,-2,0]}},
      {'event_id':'E007','sequence':7,'type':'ACTIVATE','contracts':[{'contract_id':'C-route','capability':'route_simplex','requires_all':['F001']},{'contract_id':'C-pol','capability':'signed_polarity','requires_all':['F003']}]},
      {'event_id':'E008','sequence':8,'type':'CAPABILITY','capability':'route_simplex','contract_id':'C-route','capability_payload':route_payload('r2')},
    ]

def contract():
    return {'contract_id':'T-route','requires_certified_slots':['F001'],'requires_active_contracts':['C-route'],'requires_active_capabilities':['route_simplex'],'requires_completed_capabilities':['route_simplex']}

# Every canonical slot can independently participate in a declared terminal obligation.
cat=h.memory_144_catalog({})
for row in cat['slots']:
    slot=row['slot']; op=row['operator']
    ev=[{'event_id':'S'+slot,'sequence':1,'type':'MEMORY_DROP','datum_id':'D'+slot,'signals':[{'operator':op,'certified':True,'projection':slot}]}]
    c={'contract_id':'T-'+slot,'requires_certified_slots':[slot]}
    r=h.memory_144_terminal_replay({'events':ev,'terminal_contract':c})
    ok(r.get('terminal_replay_valid') is True,slot+' replay')
    ok(r['projection']['historical_terminal'] is True,slot+' historical')
    ok(r['projection']['current_terminal'] is True,slot+' current')
    ok(r['projection']['first_terminal_prefix']==1,slot+' prefix')

# Prefix freeze, regression and repair.
full=h.memory_144_terminal_replay({'events':events8(),'terminal_contract':contract()})
ok(full['terminal_replay_valid'],'full replay')
ok(full['projection']['first_terminal_prefix']==3,'first terminal prefix')
ok(full['projection']['current_terminal'] is True,'repair terminal')
ok(full['projection']['post_terminal_regression_count']==4,'regression count')
first_hash=full['tracker']['first_terminal_certificate']['terminal_certificate_hash']

rng=random.Random(14014)
for i in range(48):
    split=rng.randint(1,7); ev=events8(); c=contract()
    root=h.memory_144_create_terminal_checkpoint({'events':ev[:split],'terminal_contract':c})
    ok(root.get('terminal_checkpoint_valid') is True,'root cp')
    resumed=h.memory_144_resume_terminal_checkpoint({'checkpoint':root['checkpoint'],'sidecar_snapshot':root['sidecar_snapshot'],'events':ev[split:]})
    ok(resumed.get('terminal_resume_valid') is True,'resume')
    for k in ('historical_terminal','current_terminal','first_terminal_prefix','post_terminal_regression_count','terminal_history_accumulator','execution_state_hash'):
        ok(resumed['projection'][k]==full['projection'][k],f'equivalence {i} {k}')

# Rotations preserve the frozen first terminal certificate.
root=h.memory_144_create_terminal_checkpoint({'events':events8()[:3],'terminal_contract':contract()})
cp=root['checkpoint']; snap=root['sidecar_snapshot']
for ev in events8()[3:]:
    child=h.memory_144_rotate_terminal_checkpoint({'checkpoint':cp,'sidecar_snapshot':snap,'events':[ev]})
    ok(child.get('terminal_checkpoint_valid') is True,'rotation')
    ok(child['checkpoint']['first_terminal_prefix']==3,'rotation prefix freeze')
    ok(child['checkpoint']['first_terminal_certificate']['terminal_certificate_hash']==first_hash,'rotation cert freeze')
    trans=h.validate_memory_144_terminal_transition({'parent_checkpoint':cp,'parent_sidecar_snapshot':snap,'events':[ev],'child_checkpoint':child['checkpoint'],'child_sidecar_snapshot':child['sidecar_snapshot']})
    ok(trans.get('terminal_transition_valid') is True,'rotation transition')
    cp,snap=child['checkpoint'],child['sidecar_snapshot']
ok(cp['current_terminal'] is True,'rotation repaired terminal')

# Forbidden slot conflicts are distinct and survive checkpoint/rotation.
c_conf=contract(); c_conf['forbids_certified_slots']=['F003']
conf=h.memory_144_terminal_replay({'events':events8()[:4],'terminal_contract':c_conf})
ok(conf['projection']['post_terminal_semantic_conflict_seen'] is True,'semantic conflict seen')
ok(conf['tracker']['current_evaluation']['status']=='AUX_BLOCKED_FORBIDDEN','semantic conflict status')

# Invalid contracts fail closed.
for bad in (
    {'contract_id':'E','forbids_certified_slots':['F003']},
    {'contract_id':'E','requires_certified_slots':['F001'],'forbids_certified_slots':['F001']},
    {'contract_id':'E','requires_active_capabilities':['not_a_capability']},
):
    ok(h.memory_144_terminal_replay({'events':[],'terminal_contract':bad}).get('terminal_replay_valid') is False,'bad contract rejected')

receipt={'status':'PASS','checks':checks,'slot_terminal_cases':144,'checkpoint_suffix_cases':48,'sequential_rotations':5,'first_terminal_prefix':3,'post_terminal_regression_count':4,'semantic_conflict_cases':1,'truth_credit':0,'ac77_integration':'NOT_PERFORMED','dd094_integration':'NOT_PERFORMED'}
print(json.dumps(receipt,sort_keys=True))
