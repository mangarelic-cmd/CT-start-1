from __future__ import annotations

from fractions import Fraction
from itertools import combinations
from typing import Any, Dict, Iterable, List, Sequence, Tuple

AUX_NAME = "HYPERTRIANGLE_SOLVER_AUX"
AUX_VERSION = "1.0.0"
TRUTH_CREDIT = 0
ROOT_WRITE_CAPABILITY = "NONE"
RETURN_WRITE_CAPABILITY = "NONE"


class AuxError(ValueError):
    pass


def F(x: Any) -> Fraction:
    if isinstance(x, Fraction):
        return x
    if isinstance(x, float):
        return Fraction(str(x))
    return Fraction(x)


def frac_text(x: Any) -> str:
    q = F(x)
    return str(q.numerator) if q.denominator == 1 else f"{q.numerator}/{q.denominator}"


def encode(x: Any) -> Any:
    if isinstance(x, Fraction):
        return frac_text(x)
    if isinstance(x, tuple):
        return [encode(v) for v in x]
    if isinstance(x, list):
        return [encode(v) for v in x]
    if isinstance(x, dict):
        return {str(k): encode(v) for k, v in x.items()}
    return x


def provider_envelope(mode: str, receipt: Dict[str, Any], request_id: Any = None) -> Dict[str, Any]:
    return {
        "provider": AUX_NAME,
        "version": AUX_VERSION,
        "request_id": request_id,
        "mode": mode,
        "truth_credit": TRUTH_CREDIT,
        "root_write_capability": ROOT_WRITE_CAPABILITY,
        "return_write_capability": RETURN_WRITE_CAPABILITY,
        "solver_mutation_capability": "NONE",
        "receipt": receipt,
    }


# ---------------------------------------------------------------------------
# Dependency / pole typing firewall
# ---------------------------------------------------------------------------

_DERIVED_ROLES = {
    "DERIVED", "CLOSURE", "MIRROR_VIEW", "PROJECTION_VIEW", "AGGREGATE", "DIAGNOSTIC"
}
_NONIDENTITY_RELATIONS = {"MIRROR", "PROJECTION", "COARSE_GRAINING", "ANALOGY", "EQUIVALENCE"}
_LABEL_KEYS = ("occurrence_id", "cell_id", "id", "label", "canonical_id")
_TYPE_KEYS = ("type_id", "semantic_type", "operator_type")
_WEIGHT_KEYS = ("weight", "w_i", "e_i", "energy", "mass")


def _label(cell: Dict[str, Any], index: int) -> str:
    for k in _LABEL_KEYS:
        if cell.get(k) not in (None, ""):
            return str(cell[k])
    return f"cell_{index}"


def _type_id(cell: Dict[str, Any]) -> Any:
    for k in _TYPE_KEYS:
        if cell.get(k) not in (None, ""):
            return str(cell[k])
    return None


def dependency_firewall(cells: Sequence[Dict[str, Any]], relations: Sequence[Dict[str, Any]] | None = None) -> Dict[str, Any]:
    labels = tuple(_label(c, i) for i, c in enumerate(cells))
    label_set = set(labels)
    blockers: List[Dict[str, Any]] = []
    for i, c in enumerate(cells):
        lab = labels[i]
        role = str(c.get("role", "PRIMITIVE")).upper()
        if role in _DERIVED_ROLES:
            blockers.append({"pole": lab, "reason": f"ROLE_{role}"})
        deps = tuple(str(x) for x in (c.get("derived_from") or ()))
        if deps and any(x in label_set for x in deps):
            blockers.append({"pole": lab, "reason": "DERIVED_FROM_CANDIDATE_POLES", "sources": deps})
        relation = str(c.get("relation_type", "")).upper()
        if relation in _NONIDENTITY_RELATIONS:
            blockers.append({"pole": lab, "reason": f"NONIDENTITY_RELATION_{relation}"})
    for rel in relations or ():
        kind = str(rel.get("type", "")).upper()
        members = set(map(str, rel.get("members", ())))
        overlap = tuple(sorted(members & label_set))
        if kind in {"DERIVATION", "DEPENDENCY", "MIRROR", "PROJECTION", "CLOSURE"} and len(overlap) >= 2:
            blockers.append({"reason": f"EXPLICIT_{kind}", "members": overlap})
    return {
        "status": "INDEPENDENCE_NOT_CERTIFIED" if blockers else "NO_DECLARED_DEPENDENCY_BLOCKER",
        "labels": labels,
        "blockers": blockers,
    }


# ---------------------------------------------------------------------------
# Route simplex / arity layer
# ---------------------------------------------------------------------------

def _extract_numeric_weight(cell: Dict[str, Any]) -> Tuple[Fraction | None, str | None]:
    for k in _WEIGHT_KEYS:
        if k in cell and cell[k] is not None:
            try:
                return F(cell[k]), k
            except Exception:
                return None, k
    return None, None


def _extract_symbolic_weight(cell: Dict[str, Any]) -> Tuple[str | None, str | None]:
    for k in _WEIGHT_KEYS:
        if k in cell and cell[k] is not None:
            try:
                F(cell[k])
            except Exception:
                return str(cell[k]), k
    return None, None


def interval_masses(boundaries: Sequence[Any]) -> Tuple[Fraction, ...]:
    q = tuple(F(x) for x in boundaries)
    if len(q) < 2 or q[0] != 0 or q[-1] != 1:
        raise AuxError("boundaries must run from 0 to 1")
    if any(q[i] > q[i + 1] for i in range(len(q) - 1)):
        raise AuxError("boundaries must be nondecreasing")
    return tuple(q[i + 1] - q[i] for i in range(len(q) - 1))


def route_from_weights(labels: Sequence[str], weights: Sequence[Any], *, grounded: bool, additive: bool,
                       common_ledger: bool, positivity_certified: bool) -> Dict[str, Any]:
    labels = tuple(map(str, labels))
    w = tuple(F(x) for x in weights)
    if len(labels) != len(w) or len(set(labels)) != len(labels):
        raise AuxError("label/weight mismatch or duplicate labels")
    if not labels:
        return {"status": "EMPTY"}
    if not additive:
        return {"status": "NONADDITIVE_SEMANTICS"}
    if not common_ledger:
        return {"status": "DIFFERENT_LEDGERS"}
    if any(x < 0 for x in w):
        return {"status": "SIGNED_REQUIRES_POLARITY_LIFT"}
    if not positivity_certified:
        return {"status": "POSITIVITY_NOT_CERTIFIED"}
    total = sum(w, Fraction(0))
    if total == 0:
        return {
            "status": "ZERO_ROUTE", "magnitude": Fraction(0), "composition": None,
            "boundaries": tuple(Fraction(0) for _ in range(len(w) + 1)), "labels": labels, "weights": w,
        }
    comp = tuple(x / total for x in w)
    qs = [Fraction(0)]
    acc = Fraction(0)
    for x in w:
        acc += x
        qs.append(acc / total)
    return {
        "status": "DIRECT_EXACT" if grounded else "FORMAL_STRUCTURE__NUMERIC_GROUNDING_OPEN",
        "magnitude": total, "composition": comp, "boundaries": tuple(qs), "labels": labels, "weights": w,
    }


def compile_route(payload: Dict[str, Any]) -> Dict[str, Any]:
    cells = tuple(payload.get("cells") or ())
    if not cells:
        return {"status": "NO_CELLS", "trace_id": payload.get("trace_id")}
    labels = tuple(_label(c, i) for i, c in enumerate(cells))
    if len(set(labels)) != len(labels):
        return {"status": "DUPLICATE_OCCURRENCE_ID", "labels": labels}
    dep = dependency_firewall(cells, payload.get("relations"))
    contracts = payload.get("contracts") or {}
    additive = bool(contracts.get("additive", payload.get("additive", True)))
    common_ledger = bool(contracts.get("common_ledger", payload.get("common_ledger", True)))
    positivity = bool(contracts.get("positivity_certified", payload.get("positive_certified", True)))
    grounded = bool(contracts.get("grounded", payload.get("grounded", True)))

    values: List[Fraction | None] = []
    symbols: List[str | None] = []
    sources: List[str | None] = []
    for c in cells:
        v, src = _extract_numeric_weight(c)
        if v is not None:
            values.append(v); symbols.append(None); sources.append(src); continue
        s, src = _extract_symbolic_weight(c)
        values.append(None); symbols.append(s); sources.append(src)

    result: Dict[str, Any] = {
        "trace_id": payload.get("trace_id"),
        "labels": labels,
        "type_ids": tuple(_type_id(c) for c in cells),
        "dependency_firewall": dep,
        "weight_sources": tuple(sources),
        "occurrence_identity_distinct_from_type": True,
    }

    if all(v is not None for v in values):
        route = route_from_weights(labels, [v for v in values if v is not None], grounded=grounded,
                                   additive=additive, common_ledger=common_ledger,
                                   positivity_certified=positivity)
        if dep["status"] != "NO_DECLARED_DEPENDENCY_BLOCKER":
            result.update({"status": "DEPENDENCY_BLOCKED_AS_INDEPENDENT_POLES", "candidate_route": route})
            return result
        result["route"] = route
        if route["status"] in {"DIRECT_EXACT", "FORMAL_STRUCTURE__NUMERIC_GROUNDING_OPEN", "ZERO_ROUTE"}:
            w = route.get("weights") or tuple(Fraction(0) for _ in labels)
            active = tuple(l for l, x in zip(labels, w) if x > 0)
            zeros = tuple(l for l, x in zip(labels, w) if x == 0)
            result.update({
                "status": "COMPILED_NUMERIC_ROUTE" if route["status"] == "DIRECT_EXACT" else route["status"],
                "active_support": active,
                "zero_width_singularities": zeros,
                "active_arity": len(active),
                "raw_magnitude_known": route.get("magnitude") is not None,
            })
        else:
            result["status"] = route["status"]
        return result

    if all(s is not None for s in symbols):
        if not additive or not common_ledger:
            result["status"] = "SYMBOLIC_BUT_LEDGER_CONTRACT_REJECTED"; return result
        if not positivity:
            result["status"] = "SYMBOLIC_POSITIVITY_NOT_CERTIFIED"; return result
        if dep["status"] != "NO_DECLARED_DEPENDENCY_BLOCKER":
            result["status"] = "DEPENDENCY_BLOCKED_AS_INDEPENDENT_POLES"; return result
        syms = tuple(str(s) for s in symbols)
        total = "(" + "+".join(syms) + ")"
        result.update({
            "status": "SYMBOLIC_SIMPLEX_STRUCTURE__WEIGHT_GROUNDING_OPEN",
            "symbolic_route": {
                "total_formula": total,
                "composition_formula": tuple(f"({s})/{total}" for s in syms),
                "arity_if_all_positive": len(syms),
            },
            "raw_magnitude_known": False,
        })
        return result

    boundaries = payload.get("boundaries")
    if boundaries is not None:
        try:
            comp = interval_masses(boundaries)
        except Exception as e:
            result.update({"status": "INVALID_Q_BOUNDARIES", "error": str(e)}); return result
        if len(comp) != len(labels):
            result["status"] = "Q_CELL_COUNT_MISMATCH"; return result
        if dep["status"] != "NO_DECLARED_DEPENDENCY_BLOCKER":
            result["status"] = "DEPENDENCY_BLOCKED_AS_INDEPENDENT_POLES"; return result
        active = tuple(l for l, x in zip(labels, comp) if x > 0)
        result.update({
            "status": "COMPOSITION_ONLY_FROM_Q_BOUNDARIES",
            "route": {"status": "COMPOSITION_ONLY", "labels": labels, "composition": comp,
                      "boundaries": tuple(F(x) for x in boundaries), "magnitude": None, "weights": None},
            "active_support": active,
            "zero_width_singularities": tuple(l for l, x in zip(labels, comp) if x == 0),
            "active_arity": len(active),
            "raw_magnitude_known": False,
        })
        return result

    if any(v is not None for v in values) and any(s is not None for s in symbols):
        result["status"] = "MIXED_NUMERIC_SYMBOLIC_WEIGHTS__COMMON_ALGEBRA_REQUIRED"
    else:
        result["status"] = "WEIGHT_OR_Q_DATA_MISSING"
    return result


def _support(c: Dict[str, Any]) -> Tuple[str, ...]:
    return tuple(c.get("active_support") or ())


def _raw_map(c: Dict[str, Any]) -> Dict[str, Fraction] | None:
    route = c.get("route") or {}
    w = route.get("weights")
    if w is None:
        return None
    labels = tuple(route.get("labels") or c.get("labels") or ())
    return {str(k): F(v) for k, v in zip(labels, w)}


def _comp_map(c: Dict[str, Any]) -> Dict[str, Fraction] | None:
    route = c.get("route") or {}
    p = route.get("composition")
    if p is None:
        return None
    labels = tuple(route.get("labels") or c.get("labels") or ())
    return {str(k): F(v) for k, v in zip(labels, p)}


def classify_route_transition(previous: Dict[str, Any], current: Dict[str, Any], same_ledger: bool = True) -> Dict[str, Any]:
    prev, curr = compile_route(previous), compile_route(current)
    A, B = set(_support(prev)), set(_support(curr))
    added, removed, common = tuple(sorted(B - A)), tuple(sorted(A - B)), tuple(sorted(A & B))
    out: Dict[str, Any] = {
        "previous": prev, "current": curr, "from_arity": len(A), "to_arity": len(B),
        "added": added, "removed": removed, "common": common,
    }
    if same_ledger:
        rp, rq = _raw_map(prev), _raw_map(curr)
        if rp is not None and rq is not None:
            bad = tuple(s for s in common if rp[s] != rq[s])
            if bad:
                out.update({"status": "SHARED_RAW_WEIGHT_CONFLICT", "conflict_poles": bad}); return out
        else:
            p, q = _comp_map(prev), _comp_map(curr)
            if p is not None and q is not None:
                ratios = [p[s] / q[s] for s in common if p.get(s, 0) > 0 and q.get(s, 0) > 0]
                if ratios and any(r != ratios[0] for r in ratios[1:]):
                    out.update({"status": "NORMALIZED_OVERLAP_CONFLICT", "ratios": tuple(ratios)}); return out
    if not added and not removed:
        out["status"] = "SAME_SUPPORT"
    elif added and removed:
        out["status"] = "SUPPORT_REPLACEMENT__NOT_FACE_LIFT"
    elif added:
        if len(A) == 3 and len(B) == 4 and len(added) == 1:
            out.update({"status": "EXACT_3_TO_4_FACE_LIFT", "new_pole": added[0]})
        else:
            out.update({"status": "EXACT_ARITY_INCREASE_FACE_LIFT", "new_poles": added})
    else:
        if len(A) == 4 and len(B) == 3 and len(removed) == 1:
            out.update({"status": "EXACT_4_TO_3_FACE_RESTRICTION", "removed_pole": removed[0]})
        else:
            out.update({"status": "EXACT_ARITY_DECREASE_FACE_RESTRICTION", "removed_poles": removed})
    cmap = _comp_map(curr)
    if cmap is not None:
        out["activation"] = {s: cmap[s] for s in added}
        out["total_new_mass"] = sum((cmap[s] for s in added), Fraction(0))
    return out


# ---------------------------------------------------------------------------
# Signed polarity / cross-polytope layer
# ---------------------------------------------------------------------------

def signed_polarity(values: Sequence[Any]) -> Dict[str, Any]:
    x = tuple(F(v) for v in values)
    if not x:
        return {"status": "EMPTY"}
    pos = tuple(max(v, Fraction(0)) for v in x)
    neg = tuple(max(-v, Fraction(0)) for v in x)
    M = sum(pos, Fraction(0)) + sum(neg, Fraction(0))
    if M == 0:
        return {"status": "ZERO_CONE_APEX", "magnitude": Fraction(0), "bipolar_composition": None}
    bipolar = tuple(v / M for v in pos + neg)
    bary = tuple(abs(v) / M for v in x)
    sectors = []
    choices: List[Tuple[int, ...]] = []
    for v in x:
        if v > 0: choices.append((1,))
        elif v < 0: choices.append((-1,))
        else: choices.append((-1, 1))
    def rec(i: int, cur: List[int]):
        if i == len(choices): sectors.append(tuple(cur)); return
        for s in choices[i]: rec(i + 1, cur + [s])
    rec(0, [])
    return {
        "status": "EXACT",
        "magnitude_l1": M,
        "positive_part": pos,
        "negative_part": neg,
        "bipolar_composition": bipolar,
        "signed_sector_barycentric": bary,
        "compatible_sign_sectors": tuple(sectors),
        "zero_count": sum(v == 0 for v in x),
    }


# ---------------------------------------------------------------------------
# B4 signed-dominance layer
# ---------------------------------------------------------------------------

def _validate_b4_contract(payload: Dict[str, Any]) -> Tuple[bool, str | None]:
    contracts = payload.get("contracts") or {}
    if not bool(contracts.get("common_scale_certified", False)):
        return False, "COMMON_SCALE_NOT_CERTIFIED"
    if not bool(contracts.get("axis_independence_certified", False)):
        return False, "AXIS_INDEPENDENCE_NOT_CERTIFIED"
    if not bool(contracts.get("b4_comparable", False)):
        return False, "B4_COMPARABILITY_NOT_CERTIFIED"
    return True, None


def _simple_reflection(signs: Tuple[int, ...], perm_desc: Tuple[int, ...], wall: int) -> Tuple[Tuple[int, ...], Tuple[int, ...]]:
    q = list(reversed(perm_desc))
    if wall == 0:
        s = list(signs); s[q[0]] *= -1
        return tuple(s), perm_desc
    q[wall - 1], q[wall] = q[wall], q[wall - 1]
    return signs, tuple(reversed(q))


def b4_state(payload: Dict[str, Any]) -> Dict[str, Any]:
    ok, why = _validate_b4_contract(payload)
    if not ok:
        return {"status": why}
    values = tuple(F(v) for v in (payload.get("values") or ()))
    axis_ids = tuple(map(str, payload.get("axis_ids") or ("h1", "h2", "h3", "h4")))
    if len(values) != 4 or len(axis_ids) != 4 or len(set(axis_ids)) != 4:
        return {"status": "B4_REQUIRES_FOUR_DISTINCT_AXES"}
    if all(v == 0 for v in values):
        return {"status": "ZERO_APEX__NO_CHAMBER", "axis_ids": axis_ids}
    zero_axes = tuple(axis_ids[i] for i, v in enumerate(values) if v == 0)
    ties = tuple((axis_ids[i], axis_ids[j]) for i, j in combinations(range(4), 2) if abs(values[i]) == abs(values[j]))
    signs = tuple(0 if v == 0 else (1 if v > 0 else -1) for v in values)
    if zero_axes or ties:
        return {
            "status": "B4_BOUNDARY_STRATUM__NO_UNIQUE_CHAMBER",
            "axis_ids": axis_ids,
            "values": values,
            "signs_with_zero": signs,
            "zero_axes": zero_axes,
            "equal_magnitude_pairs": ties,
            "codimension_lower_bound": len(zero_axes) + len(ties),
        }
    signs_nz = tuple(1 if v > 0 else -1 for v in values)
    perm_desc = tuple(sorted(range(4), key=lambda i: (abs(values[i]), i), reverse=True))
    q = tuple(reversed(perm_desc))
    y = tuple(abs(values[i]) for i in q)
    alpha = (y[0], y[1] - y[0], y[2] - y[1], y[3] - y[2])
    M = sum(abs(v) for v in values)
    beta = (4 * alpha[0] / M, 3 * alpha[1] / M, 2 * alpha[2] / M, alpha[3] / M)
    neighbors = []
    for wall in range(4):
        ns, np = _simple_reflection(signs_nz, perm_desc, wall)
        neighbors.append({
            "wall": wall,
            "kind": "SIGN_ZERO" if wall == 0 else "ADJACENT_MAGNITUDE_TIE",
            "neighbor_signs": ns,
            "neighbor_perm_descending": np,
            "margin": alpha[wall],
        })
    sign_code = "".join("+" if s > 0 else "-" for s in signs_nz)
    chamber_id = f"B4:{sign_code}:" + ">".join(axis_ids[i] for i in perm_desc)
    return {
        "status": "B4_INTERIOR_CHAMBER",
        "axis_ids": axis_ids,
        "values": values,
        "signs": signs_nz,
        "perm_descending": perm_desc,
        "axis_order_descending": tuple(axis_ids[i] for i in perm_desc),
        "ascending_indices": q,
        "simple_root_gaps": alpha,
        "barycentric": beta,
        "l1_magnitude": M,
        "minimum_simple_wall_margin": min(alpha),
        "chamber_id": chamber_id,
        "neighbors": tuple(neighbors),
    }



# ---------------------------------------------------------------------------
# PASS002 robust receipt / event / route layer
# ---------------------------------------------------------------------------

def _error_vector4(values: Sequence[Any]) -> Tuple[Fraction, ...]:
    e = tuple(F(v) for v in values)
    if len(e) != 4:
        raise AuxError("component_errors must have width 4")
    if any(v < 0 for v in e):
        raise AuxError("component_errors must be nonnegative")
    return e


def robust_b4_state(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Certify that a componentwise uncertainty box stays in one B4 chamber."""
    nominal = b4_state(payload)
    if nominal.get("status") != "B4_INTERIOR_CHAMBER":
        return {
            "status": "UNRESOLVED_NOMINAL_B4_STATE",
            "nominal": nominal,
            "certified_same_B4_chamber": False,
        }
    try:
        eps = _error_vector4(payload.get("component_errors") or ())
    except Exception as exc:
        return {"status": "INVALID_COMPONENT_ERROR_BOUNDS", "error": str(exc), "certified_same_B4_chamber": False}
    values = tuple(F(v) for v in payload.get("values") or ())
    axis_ids = tuple(nominal["axis_ids"])
    sign_margins = tuple(abs(v) - e for v, e in zip(values, eps))
    pair_margins = []
    for i, j in combinations(range(4), 2):
        m = abs(abs(values[i]) - abs(values[j])) - (eps[i] + eps[j])
        pair_margins.append({"axes": (axis_ids[i], axis_ids[j]), "margin_lower": m})
    sign_ok = all(m > 0 for m in sign_margins)
    dominance_ok = all(x["margin_lower"] > 0 for x in pair_margins)
    cert = bool(sign_ok and dominance_ok)
    return {
        "status": "ROBUST_B4_CHAMBER_CERTIFIED" if cert else "UNRESOLVED_B4_UNCERTAINTY_INTERSECTS_WALL",
        "certified_same_B4_chamber": cert,
        "chamber_id": nominal["chamber_id"] if cert else None,
        "nominal": nominal,
        "component_errors": eps,
        "sign_margin_lower_bounds": sign_margins,
        "dominance_margin_lower_bounds": tuple(pair_margins),
        "minimum_certified_wall_margin": min(sign_margins + tuple(x["margin_lower"] for x in pair_margins)),
        "firewall": "certified only when the entire componentwise uncertainty box avoids every B4 sign and equal-magnitude wall",
    }


def wall_interval(values: Sequence[Any], component_errors: Sequence[Any], alpha: Sequence[Any]) -> Dict[str, Any]:
    v = tuple(F(x) for x in values)
    e = tuple(F(x) for x in component_errors)
    a = tuple(F(x) for x in alpha)
    if len(v) != 4 or len(e) != 4 or len(a) != 4:
        raise AuxError("wall interval requires width-4 values/errors/alpha")
    if any(x < 0 for x in e):
        raise AuxError("wall errors must be nonnegative")
    nominal = sum((ai * vi for ai, vi in zip(a, v)), Fraction(0))
    err = sum((abs(ai) * ei for ai, ei in zip(a, e)), Fraction(0))
    lo, hi = nominal - err, nominal + err
    sign = 1 if lo > 0 else (-1 if hi < 0 else 0)
    return {
        "nominal": nominal,
        "error_bound": err,
        "lower": lo,
        "upper": hi,
        "certified_sign": sign,
        "separated_from_wall": sign != 0,
    }


def certify_wall_event(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Robust unique crossing certificate under an explicit uniform bracket error + derivative sign contract."""
    try:
        alpha = tuple(F(x) for x in payload.get("alpha") or ())
        if len(alpha) != 4 or all(x == 0 for x in alpha):
            raise AuxError("alpha must be a nonzero width-4 wall covector")
        left = payload.get("left") or {}
        right = payload.get("right") or {}
        t0, t1 = F(left.get("time")), F(right.get("time"))
        if not t0 < t1:
            raise AuxError("left.time must be < right.time")
        uniform_errors = _error_vector4(payload.get("uniform_component_errors") or ())
        contracts = payload.get("contracts") or {}
        if not bool(contracts.get("uniform_error_over_bracket_certified", False)):
            return {"status": "UNRESOLVED_UNIFORM_ERROR_CONTRACT", "certified_unique_crossing": False}
        li = wall_interval(left.get("values") or (), uniform_errors, alpha)
        ri = wall_interval(right.get("values") or (), uniform_errors, alpha)
        robust_bracket = li["certified_sign"] * ri["certified_sign"] == -1
        direction = int(payload.get("derivative_direction", 0))
        if direction not in (-1, 1):
            return {"status": "UNRESOLVED_DERIVATIVE_DIRECTION", "certified_unique_crossing": False,
                    "left_wall": li, "right_wall": ri, "robust_bracket": robust_bracket}
        deriv_lower = F(payload.get("derivative_magnitude_lower", 0))
        deriv_error = F(payload.get("derivative_error", 0))
        if deriv_lower < 0 or deriv_error < 0:
            raise AuxError("derivative bounds must be nonnegative")
        derivative_certified = deriv_lower > deriv_error
        expected = (li["certified_sign"], ri["certified_sign"]) == ((-1, 1) if direction > 0 else (1, -1))
        unique = bool(robust_bracket and derivative_certified and expected)
        wall_error = sum((abs(ai) * ei for ai, ei in zip(alpha, uniform_errors)), Fraction(0))
        true_derivative_lower = deriv_lower - deriv_error if derivative_certified else None
        nominal_time = payload.get("nominal_time")
        shift = wall_error / true_derivative_lower if unique and nominal_time is not None else None
        interval = None
        if unique:
            if nominal_time is None:
                interval = (t0, t1)
            else:
                tn = F(nominal_time)
                if not (t0 <= tn <= t1):
                    return {"status": "INVALID_NOMINAL_TIME_OUTSIDE_BRACKET", "certified_unique_crossing": False,
                            "left_wall": li, "right_wall": ri}
                interval = (max(t0, tn - shift), min(t1, tn + shift))
                if interval[0] > interval[1]:
                    unique = False
        return {
            "status": "UNIQUE_WALL_CROSSING_CERTIFIED" if unique else "UNRESOLVED_WALL_EVENT",
            "certified_unique_crossing": unique,
            "wall_id": payload.get("wall_id"),
            "alpha": alpha,
            "left_time": t0,
            "right_time": t1,
            "left_wall": li,
            "right_wall": ri,
            "robust_bracket": robust_bracket,
            "direction_consistent": expected,
            "derivative_direction": direction,
            "derivative_magnitude_lower": deriv_lower,
            "derivative_error": deriv_error,
            "true_derivative_magnitude_lower": true_derivative_lower,
            "uniform_wall_error_bound": wall_error,
            "nominal_time": F(nominal_time) if nominal_time is not None else None,
            "root_time_shift_bound": shift,
            "certified_time_interval": interval,
            "firewall": "uniqueness requires a robust opposite-sign bracket and an explicit certified derivative direction throughout the bracket",
        }
    except Exception as exc:
        return {"status": "INVALID_EVENT_RECEIPT", "certified_unique_crossing": False, "error": str(exc)}


def certify_b4_route(payload: Dict[str, Any]) -> Dict[str, Any]:
    events_in = list(payload.get("events") or ())
    if not events_in:
        return {"status": "NO_ROUTE_EVENTS", "certified": False, "events": []}
    events = [certify_wall_event(e) for e in events_in]
    if any(not e.get("certified_unique_crossing", False) for e in events):
        return {"status": "UNRESOLVED_ROUTE_EVENT", "certified": False, "events": events}
    ordered = True
    gaps = []
    for a, b in zip(events, events[1:]):
        ia, ib = a["certified_time_interval"], b["certified_time_interval"]
        gap = ib[0] - ia[1]
        gaps.append(gap)
        if not gap > 0:
            ordered = False
    return {
        "status": "B4_ROUTE_CERTIFIED" if ordered else "UNRESOLVED_ROUTE_ORDER",
        "certified": ordered,
        "wall_sequence": tuple(e.get("wall_id") for e in events),
        "inter_event_gap_lower_bounds": tuple(gaps),
        "events": tuple(events),
        "firewall": "route certification preserves the supplied event order only; it does not infer missing wall events",
    }


def certify_receipt_bundle(payload: Dict[str, Any]) -> Dict[str, Any]:
    states = [robust_b4_state(x) for x in (payload.get("states") or ())]
    route_payload = payload.get("route")
    route = certify_b4_route(route_payload) if route_payload is not None else {"status": "NO_ROUTE_REQUIRED", "certified": True, "events": []}
    states_ok = all(s.get("certified_same_B4_chamber", False) for s in states)
    terminal = bool(states_ok and route.get("certified", False))
    return {
        "status": "ROBUST_RECEIPT_BUNDLE_CERTIFIED" if terminal else "UNRESOLVED_RECEIPT_BUNDLE",
        "terminal": terminal,
        "state_certificates": tuple(states),
        "route_certificate": route,
        "required_states": len(states),
        "required_events": len((route_payload or {}).get("events") or ()) if route_payload is not None else 0,
        "truth_credit": 0,
    }


# ---------------------------------------------------------------------------
# PASS003 append-only receipt stream / first-terminal-prefix layer
# ---------------------------------------------------------------------------

import hashlib
import json

_STREAM_DOMAIN = b"HYPERTRIANGLE_SOLVER_AUX_STREAM_V1\n"


def _canonical_for_hash(obj: Any) -> bytes:
    """Stable JSON encoding for tamper-evident AUX receipt chains."""
    return json.dumps(encode(obj), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _stream_hash_step(previous_hex: str, entry: Dict[str, Any]) -> str:
    h = hashlib.sha256()
    h.update(bytes.fromhex(previous_hex))
    h.update(b"\n")
    h.update(_canonical_for_hash(entry))
    return h.hexdigest()


def _stream_initial_hash(stream_id: Any) -> str:
    h = hashlib.sha256()
    h.update(_STREAM_DOMAIN)
    h.update(str(stream_id if stream_id is not None else "").encode("utf-8"))
    return h.hexdigest()


def _certify_stream_entry(entry: Dict[str, Any]) -> Dict[str, Any]:
    kind = str(entry.get("kind", "")).lower()
    payload = entry.get("payload") or {}
    if kind == "state":
        cert = robust_b4_state(payload)
        ok = bool(cert.get("certified_same_B4_chamber", False))
        return {"kind": kind, "certified": ok, "certificate": cert}
    if kind == "event":
        cert = certify_wall_event(payload)
        ok = bool(cert.get("certified_unique_crossing", False))
        return {"kind": kind, "certified": ok, "certificate": cert}
    if kind == "bundle":
        cert = certify_receipt_bundle(payload)
        ok = bool(cert.get("terminal", False))
        return {"kind": kind, "certified": ok, "certificate": cert}
    return {"kind": kind, "certified": False, "certificate": {"status": "UNSUPPORTED_STREAM_ENTRY_KIND"}}


def _route_from_event_slots(latest: Dict[str, Dict[str, Any]], slots: Sequence[str], expected_walls: Sequence[str] | None = None) -> Dict[str, Any]:
    if not slots:
        return {"status": "NO_ROUTE_REQUIRED", "certified": True, "wall_sequence": tuple(), "events": tuple()}
    events=[]
    for slot in slots:
        item=latest.get(slot)
        if not item or item.get("kind") != "event" or not item.get("certified"):
            return {"status": "MISSING_OR_UNCERTIFIED_EVENT_SLOT", "certified": False, "missing_slot": slot, "events": tuple(events)}
        events.append(item["certificate"])
    wall_sequence=tuple(e.get("wall_id") for e in events)
    if expected_walls is not None and tuple(map(str, expected_walls)) != wall_sequence:
        return {"status": "WALL_SEQUENCE_MISMATCH", "certified": False, "wall_sequence": wall_sequence, "expected_wall_sequence": tuple(map(str, expected_walls)), "events": tuple(events)}
    gaps=[]
    for a,b in zip(events,events[1:]):
        ia,ib=a.get("certified_time_interval"),b.get("certified_time_interval")
        if ia is None or ib is None:
            return {"status":"EVENT_INTERVAL_MISSING","certified":False,"wall_sequence":wall_sequence,"events":tuple(events)}
        gap=ib[0]-ia[1]
        gaps.append(gap)
        if not gap>0:
            return {"status":"UNRESOLVED_ROUTE_ORDER","certified":False,"wall_sequence":wall_sequence,"inter_event_gap_lower_bounds":tuple(gaps),"events":tuple(events)}
    return {"status":"B4_ROUTE_CERTIFIED","certified":True,"wall_sequence":wall_sequence,"inter_event_gap_lower_bounds":tuple(gaps),"events":tuple(events)}


def _evaluate_stream_snapshot(latest: Dict[str, Dict[str, Any]], requirements: Dict[str, Any]) -> Dict[str, Any]:
    state_slots=tuple(map(str, requirements.get("required_state_slots") or ()))
    event_slots=tuple(map(str, requirements.get("required_event_slots") or ()))
    bundle_slots=tuple(map(str, requirements.get("required_bundle_slots") or ()))
    expected_walls=requirements.get("required_wall_sequence")

    state_status=[]
    for slot in state_slots:
        item=latest.get(slot)
        ok=bool(item and item.get("kind")=="state" and item.get("certified"))
        state_status.append((slot,ok))
    bundle_status=[]
    for slot in bundle_slots:
        item=latest.get(slot)
        ok=bool(item and item.get("kind")=="bundle" and item.get("certified"))
        bundle_status.append((slot,ok))
    route=_route_from_event_slots(latest,event_slots,expected_walls)
    states_ok=all(ok for _,ok in state_status)
    bundles_ok=all(ok for _,ok in bundle_status)
    terminal=bool(states_ok and bundles_ok and route.get("certified",False))
    return {
        "terminal":terminal,
        "state_slots":tuple(state_status),
        "bundle_slots":tuple(bundle_status),
        "route":route,
        "required_state_count":len(state_slots),
        "required_event_count":len(event_slots),
        "required_bundle_count":len(bundle_slots),
    }


def certify_receipt_stream(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Replay an append-only stream and freeze the first terminal prefix.

    Later receipts may make the *current* prefix unresolved or contradictory, but they never
    erase the historical first-terminal certificate or its hash commitment.
    """
    stream_id=payload.get("stream_id")
    requirements=payload.get("requirements") or {}
    receipts=list(payload.get("receipts") or ())
    ids=[]
    for i,e in enumerate(receipts,1):
        rid=str(e.get("receipt_id", ""))
        if not rid:
            return {"status":"INVALID_STREAM_RECEIPT_ID","historical_terminal":False,"error":f"missing receipt_id at position {i}"}
        if rid in ids:
            return {"status":"DUPLICATE_STREAM_RECEIPT_ID","historical_terminal":False,"duplicate_receipt_id":rid}
        seq=e.get("sequence")
        if seq is not None and int(seq)!=i:
            return {"status":"INVALID_STREAM_SEQUENCE","historical_terminal":False,"position":i,"declared_sequence":seq}
        slot=str(e.get("slot", ""))
        if not slot:
            return {"status":"INVALID_STREAM_SLOT","historical_terminal":False,"receipt_id":rid}
        ids.append(rid)

    chain=_stream_initial_hash(stream_id)
    latest: Dict[str, Dict[str, Any]]={}
    history=[]
    first_terminal=None
    first_terminal_latest=None
    first_terminal_hash=None

    for i,e in enumerate(receipts,1):
        chain=_stream_hash_step(chain,e)
        cert=_certify_stream_entry(e)
        slot=str(e["slot"])
        latest[slot]={
            "receipt_id":str(e["receipt_id"]),
            "slot":slot,
            "kind":cert["kind"],
            "certified":cert["certified"],
            "certificate":cert["certificate"],
            "stream_hash":chain,
        }
        snap=_evaluate_stream_snapshot(latest,requirements)
        hist={
            "prefix_length":i,
            "receipt_id":str(e["receipt_id"]),
            "stream_hash":chain,
            "terminal_now":snap["terminal"],
            "state_slots":snap["state_slots"],
            "bundle_slots":snap["bundle_slots"],
            "route_status":snap["route"].get("status"),
        }
        history.append(hist)
        if first_terminal is None and snap["terminal"]:
            first_terminal=i
            first_terminal_hash=chain
            # immutable compact snapshot for historical terminality
            first_terminal_latest={k:{
                "receipt_id":v["receipt_id"],
                "kind":v["kind"],
                "certified":v["certified"],
                "certificate":v["certificate"],
            } for k,v in latest.items()}

    current=_evaluate_stream_snapshot(latest,requirements)
    historical=first_terminal is not None
    regressed=bool(historical and not current["terminal"])
    post_count=max(0,len(receipts)-(first_terminal or len(receipts))) if receipts else 0

    # Explicit post-terminal change/conflict audit against the frozen terminal snapshot.
    post_changes=[]
    if historical and first_terminal_latest is not None:
        frozen=first_terminal_latest
        for slot,now in latest.items():
            old=frozen.get(slot)
            if old is None:
                if now["receipt_id"] not in ids[:first_terminal]:
                    post_changes.append({"slot":slot,"kind":"NEW_POST_TERMINAL_SLOT","receipt_id":now["receipt_id"]})
                continue
            if now["receipt_id"]==old["receipt_id"]:
                continue
            change={"slot":slot,"kind":"POST_TERMINAL_REPLACEMENT","from_receipt_id":old["receipt_id"],"to_receipt_id":now["receipt_id"],"current_certified":now["certified"]}
            oc, nc = old.get("certificate") or {}, now.get("certificate") or {}
            if old["kind"]=="state":
                change["frozen_chamber_id"]=oc.get("chamber_id")
                change["current_chamber_id"]=nc.get("chamber_id")
                change["semantic_conflict"]=bool(oc.get("chamber_id") != nc.get("chamber_id") or not now["certified"])
            elif old["kind"]=="event":
                change["frozen_wall_id"]=oc.get("wall_id")
                change["current_wall_id"]=nc.get("wall_id")
                change["semantic_conflict"]=bool(oc.get("wall_id") != nc.get("wall_id") or not now["certified"])
            else:
                change["semantic_conflict"]=bool(not now["certified"])
            post_changes.append(change)
    semantic_conflict=any(x.get("semantic_conflict",False) for x in post_changes)

    if not historical:
        status="NO_TERMINAL_PREFIX"
    elif regressed or semantic_conflict:
        status="FIRST_TERMINAL_PREFIX_FROZEN__POST_TERMINAL_CONFLICT"
    elif post_count:
        status="FIRST_TERMINAL_PREFIX_FROZEN__POST_TERMINAL_RECEIPTS_PRESENT"
    else:
        status="FIRST_TERMINAL_PREFIX_FROZEN"

    return {
        "status":status,
        "stream_id":stream_id,
        "receipt_count":len(receipts),
        "historical_terminal":historical,
        "current_terminal":bool(current["terminal"]),
        "first_terminal_prefix":first_terminal,
        "first_terminal_stream_hash":first_terminal_hash,
        "final_stream_hash":chain,
        "stop_recommended":historical,
        "stop_policy":f"STOP_AT_PREFIX_{first_terminal}" if historical else "CONTINUE_ACQUISITION",
        "post_terminal_receipt_count":post_count,
        "current_prefix_regressed":regressed,
        "post_terminal_semantic_conflict":semantic_conflict,
        "post_terminal_changes":tuple(post_changes),
        "first_terminal_snapshot":first_terminal_latest,
        "current_snapshot":current,
        "prefix_history":tuple(history),
        "truth_credit":0,
        "root_write_capability":"NONE",
        "return_write_capability":"NONE",
        "solver_mutation_capability":"NONE",
        "firewall":"first-terminal history is immutable; later receipts can flag current regression/conflict but cannot erase the frozen terminal prefix",
    }


# ---------------------------------------------------------------------------
# PASS004 compact stream checkpoint / resumable provenance layer
# ---------------------------------------------------------------------------

import copy

_CHECKPOINT_DOMAIN = b"HYPERTRIANGLE_SOLVER_AUX_CHECKPOINT_V1\n"
_CHECKPOINT_SCHEMA = "HYPERTRIANGLE_SOLVER_AUX_STREAM_CHECKPOINT_V1"


def _checkpoint_hash_body(body: Dict[str, Any]) -> str:
    h = hashlib.sha256()
    h.update(_CHECKPOINT_DOMAIN)
    h.update(_canonical_for_hash(body))
    return h.hexdigest()


def _latest_slot_snapshot(receipts: Sequence[Dict[str, Any]]) -> Dict[str, Dict[str, Any]]:
    latest: Dict[str, Dict[str, Any]] = {}
    for e in receipts:
        cert = _certify_stream_entry(e)
        slot = str(e.get("slot", ""))
        if not slot:
            continue
        latest[slot] = {
            "receipt_id": str(e.get("receipt_id", "")),
            "kind": cert["kind"],
            "certified": cert["certified"],
            "certificate": cert["certificate"],
        }
    return latest


def _semantic_conflict_against_frozen(frozen: Dict[str, Dict[str, Any]] | None,
                                      now: Dict[str, Dict[str, Any]]) -> bool:
    if not frozen:
        return False
    for slot, old in frozen.items():
        cur = now.get(slot)
        if cur is None:
            return True
        if not cur.get("certified", False):
            return True
        oc, nc = old.get("certificate") or {}, cur.get("certificate") or {}
        kind = old.get("kind")
        if cur.get("kind") != kind:
            return True
        if kind == "state" and oc.get("chamber_id") != nc.get("chamber_id"):
            return True
        if kind == "event" and oc.get("wall_id") != nc.get("wall_id"):
            return True
    return False


def _conflict_event_for_receipt(entry: Dict[str, Any], latest: Dict[str, Dict[str, Any]],
                                frozen: Dict[str, Dict[str, Any]] | None) -> Dict[str, Any] | None:
    if not frozen:
        return None
    slot = str(entry.get("slot", ""))
    old = frozen.get(slot)
    if old is None:
        return None
    cur = latest.get(slot)
    if cur is None or cur.get("receipt_id") == old.get("receipt_id"):
        return None
    conflict = False
    oc, nc = old.get("certificate") or {}, cur.get("certificate") or {}
    kind = old.get("kind")
    if cur.get("kind") != kind or not cur.get("certified", False):
        conflict = True
    elif kind == "state" and oc.get("chamber_id") != nc.get("chamber_id"):
        conflict = True
    elif kind == "event" and oc.get("wall_id") != nc.get("wall_id"):
        conflict = True
    if not conflict:
        return None
    return {
        "receipt_id": str(entry.get("receipt_id", "")),
        "sequence": int(entry.get("sequence")),
        "slot": slot,
        "frozen_receipt_id": old.get("receipt_id"),
        "current_receipt_id": cur.get("receipt_id"),
        "kind": cur.get("kind"),
        "status": "POST_TERMINAL_SEMANTIC_CONFLICT",
    }


def create_stream_checkpoint(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Compact a verified stream prefix into a resumable exact AUX checkpoint.

    The checkpoint discards historical payloads from the *active* stream while retaining:
    the prefix hash commitment, exact seen receipt IDs, latest slot certificates, frozen first-terminal
    certificate, and post-terminal regression/conflict summary. Full historical replay still requires
    the archived original prefix; the checkpoint itself is a continuation certificate, not a replacement
    for the archival evidence packet.
    """
    stream = payload.get("stream") if isinstance(payload.get("stream"), dict) else payload
    receipts = list(stream.get("receipts") or ())
    prefix = payload.get("checkpoint_prefix")
    prefix = len(receipts) if prefix is None else int(prefix)
    if prefix < 0 or prefix > len(receipts):
        return {"status": "INVALID_CHECKPOINT_PREFIX", "checkpoint_valid": False}
    prefix_stream = {
        "stream_id": stream.get("stream_id"),
        "requirements": copy.deepcopy(stream.get("requirements") or {}),
        "receipts": copy.deepcopy(receipts[:prefix]),
    }
    cert = certify_receipt_stream(prefix_stream)
    if cert.get("status") in {
        "INVALID_STREAM_RECEIPT_ID", "DUPLICATE_STREAM_RECEIPT_ID",
        "INVALID_STREAM_SEQUENCE", "INVALID_STREAM_SLOT"
    }:
        return {"status": "CHECKPOINT_SOURCE_STREAM_INVALID", "checkpoint_valid": False, "source_status": cert.get("status")}

    latest = _latest_slot_snapshot(prefix_stream["receipts"])
    frozen = cert.get("first_terminal_snapshot")
    first_terminal = cert.get("first_terminal_prefix")
    regression_prefixes = tuple(
        int(x["prefix_length"]) for x in cert.get("prefix_history", ())
        if first_terminal is not None and int(x["prefix_length"]) > int(first_terminal) and not bool(x.get("terminal_now"))
    )
    # Exact compact conflict list: retain only receipts that created a semantic conflict with the frozen terminal slots.
    conflicts = []
    replay_latest: Dict[str, Dict[str, Any]] = {}
    for i, e in enumerate(prefix_stream["receipts"], 1):
        c = _certify_stream_entry(e)
        replay_latest[str(e["slot"])] = {
            "receipt_id": str(e["receipt_id"]), "kind": c["kind"],
            "certified": c["certified"], "certificate": c["certificate"],
        }
        if first_terminal is not None and i > int(first_terminal):
            z = _conflict_event_for_receipt(e, replay_latest, frozen)
            if z is not None:
                conflicts.append(z)

    history_commitment = hashlib.sha256(_canonical_for_hash(cert.get("prefix_history", ()))).hexdigest()
    body = {
        "schema": _CHECKPOINT_SCHEMA,
        "aux_name": AUX_NAME,
        "aux_version": AUX_VERSION,
        "stream_id": prefix_stream.get("stream_id"),
        "requirements": copy.deepcopy(prefix_stream.get("requirements") or {}),
        "prefix_length": prefix,
        "next_sequence": prefix + 1,
        "prefix_stream_hash": cert.get("final_stream_hash"),
        "seen_receipt_ids": tuple(str(e["receipt_id"]) for e in prefix_stream["receipts"]),
        "latest_slot_snapshot": latest,
        "historical_terminal": bool(cert.get("historical_terminal", False)),
        "current_terminal_at_checkpoint": bool(cert.get("current_terminal", False)),
        "first_terminal_prefix": first_terminal,
        "first_terminal_stream_hash": cert.get("first_terminal_stream_hash"),
        "first_terminal_snapshot": frozen,
        "stop_policy": cert.get("stop_policy"),
        "post_terminal_regression_seen": bool(regression_prefixes),
        "post_terminal_regression_count": len(regression_prefixes),
        "post_terminal_regression_prefixes": regression_prefixes,
        "post_terminal_semantic_conflict_seen": bool(conflicts),
        "post_terminal_semantic_conflict_count": len(conflicts),
        "post_terminal_conflicts": tuple(conflicts),
        "prefix_history_commitment": history_commitment,
        "truth_credit": 0,
        "root_write_capability": "NONE",
        "return_write_capability": "NONE",
        "solver_mutation_capability": "NONE",
        "archive_requirement": "full historical replay requires the archived compacted prefix; checkpoint is sufficient for exact continuation semantics",
    }
    checkpoint_hash = _checkpoint_hash_body(body)
    checkpoint = dict(body)
    checkpoint["checkpoint_hash"] = checkpoint_hash
    raw_size = len(_canonical_for_hash(prefix_stream))
    checkpoint_size = len(_canonical_for_hash(checkpoint))
    return {
        "status": "STREAM_CHECKPOINT_CREATED",
        "checkpoint_valid": True,
        "checkpoint": checkpoint,
        "compacted_prefix_receipt_count": prefix,
        "raw_prefix_canonical_bytes": raw_size,
        "checkpoint_canonical_bytes": checkpoint_size,
        "canonical_byte_reduction": raw_size - checkpoint_size,
        "canonical_compaction_ratio": (Fraction(checkpoint_size, raw_size) if raw_size else Fraction(1)),
        "truth_credit": 0,
    }


def validate_stream_checkpoint(checkpoint: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(checkpoint, dict) or checkpoint.get("schema") != _CHECKPOINT_SCHEMA:
        return {"status": "INVALID_CHECKPOINT_SCHEMA", "checkpoint_valid": False}
    supplied = str(checkpoint.get("checkpoint_hash", ""))
    body = {k: copy.deepcopy(v) for k, v in checkpoint.items() if k != "checkpoint_hash"}
    expected = _checkpoint_hash_body(body)
    if supplied != expected:
        return {"status": "CHECKPOINT_HASH_MISMATCH", "checkpoint_valid": False, "expected_checkpoint_hash": expected}
    try:
        prefix = int(checkpoint.get("prefix_length"))
        if int(checkpoint.get("next_sequence")) != prefix + 1:
            raise AuxError("next_sequence mismatch")
        ids = tuple(map(str, checkpoint.get("seen_receipt_ids") or ()))
        if len(ids) != prefix or len(set(ids)) != len(ids):
            raise AuxError("seen_receipt_ids must exactly cover compacted prefix")
        ph = str(checkpoint.get("prefix_stream_hash", ""))
        if len(ph) != 64:
            raise AuxError("invalid prefix stream hash")
        int(ph, 16)
        req = checkpoint.get("requirements") or {}
        latest = checkpoint.get("latest_slot_snapshot") or {}
        current = _evaluate_stream_snapshot(latest, req)
        if bool(current.get("terminal")) != bool(checkpoint.get("current_terminal_at_checkpoint")):
            raise AuxError("current terminal snapshot mismatch")
        historical = bool(checkpoint.get("historical_terminal", False))
        ftp = checkpoint.get("first_terminal_prefix")
        if historical:
            if ftp is None or int(ftp) < 1 or int(ftp) > prefix:
                raise AuxError("invalid first terminal prefix")
            frozen = checkpoint.get("first_terminal_snapshot") or {}
            frozen_eval = _evaluate_stream_snapshot(frozen, req)
            if not frozen_eval.get("terminal", False):
                raise AuxError("frozen first-terminal snapshot is not terminal")
            if len(str(checkpoint.get("first_terminal_stream_hash", ""))) != 64:
                raise AuxError("invalid first terminal stream hash")
        elif ftp is not None or checkpoint.get("first_terminal_stream_hash") is not None:
            raise AuxError("nonterminal checkpoint cannot declare first terminal data")

        phc = str(checkpoint.get("prefix_history_commitment", ""))
        if phc and not _hex64(phc):
            raise AuxError("invalid prefix history commitment")
        rotation_index = int(checkpoint.get("rotation_index", 0))
        if rotation_index < 0:
            raise AuxError("negative rotation index")
        if rotation_index > 0:
            prev_hash = str(checkpoint.get("previous_checkpoint_hash", ""))
            root_hash = str(checkpoint.get("checkpoint_chain_root_hash", ""))
            if not _hex64(prev_hash) or not _hex64(root_hash):
                raise AuxError("invalid checkpoint lineage hashes")
            lineage = tuple(checkpoint.get("checkpoint_lineage") or ())
            if len(lineage) != rotation_index:
                raise AuxError("checkpoint lineage depth mismatch")
            previous_prefix = -1
            for expected_index, entry in enumerate(lineage):
                if int(entry.get("rotation_index", -1)) != expected_index:
                    raise AuxError("checkpoint lineage rotation index mismatch")
                if not _hex64(entry.get("checkpoint_hash")) or not _hex64(entry.get("prefix_stream_hash")):
                    raise AuxError("invalid checkpoint lineage entry hash")
                if not _hex64(entry.get("rotation_history_commitment")):
                    raise AuxError("invalid checkpoint lineage rotation commitment")
                ep = int(entry.get("prefix_length", -1))
                if ep <= previous_prefix or ep >= prefix:
                    raise AuxError("checkpoint lineage prefix order mismatch")
                previous_prefix = ep
            if str(lineage[-1].get("checkpoint_hash")) != prev_hash:
                raise AuxError("previous checkpoint hash does not match lineage tip")
            if str(lineage[0].get("checkpoint_hash")) != root_hash:
                raise AuxError("checkpoint chain root mismatch")
            suffix_count = int(checkpoint.get("rotation_suffix_receipt_count", -1))
            if suffix_count != prefix - int(lineage[-1].get("prefix_length")):
                raise AuxError("rotation suffix receipt count mismatch")
            suffix_commitment = str(checkpoint.get("rotation_suffix_history_commitment", ""))
            prev_rotation = str(checkpoint.get("previous_rotation_history_commitment", ""))
            rot = str(checkpoint.get("rotation_history_commitment", ""))
            prev_prefix_commitment = str(checkpoint.get("previous_prefix_history_commitment", ""))
            if not all(_hex64(x) for x in (suffix_commitment, prev_rotation, rot, prev_prefix_commitment, phc)):
                raise AuxError("invalid rotation commitment encoding")
            expected_rot = _rotation_history_commitment(prev_rotation, prev_hash, suffix_commitment, ph)
            if rot != expected_rot:
                raise AuxError("rotation history commitment mismatch")
            expected_phc = _chained_prefix_history_commitment(prev_prefix_commitment, suffix_commitment)
            if phc != expected_phc:
                raise AuxError("prefix history commitment mismatch")
            if checkpoint.get("prefix_history_commitment_mode") != "CHAINED_CHECKPOINT_HISTORY_V1":
                raise AuxError("invalid prefix history commitment mode")
    except Exception as exc:
        return {"status": "CHECKPOINT_SEMANTIC_VALIDATION_FAILED", "checkpoint_valid": False, "error": str(exc)}
    return {"status": "STREAM_CHECKPOINT_VALID", "checkpoint_valid": True, "checkpoint_hash": supplied}


def resume_stream_checkpoint(payload: Dict[str, Any]) -> Dict[str, Any]:
    checkpoint = payload.get("checkpoint") or {}
    valid = validate_stream_checkpoint(checkpoint)
    if not valid.get("checkpoint_valid", False):
        return {"status": "INVALID_STREAM_CHECKPOINT", "checkpoint_valid": False, "validation": valid}
    suffix = list(payload.get("receipts") or ())
    prefix = int(checkpoint["prefix_length"])
    seen = set(map(str, checkpoint.get("seen_receipt_ids") or ()))
    local_seen = set()
    for j, e in enumerate(suffix, 1):
        expected_seq = prefix + j
        rid = str(e.get("receipt_id", ""))
        if not rid:
            return {"status": "INVALID_STREAM_RECEIPT_ID", "checkpoint_valid": True, "error": f"missing receipt_id at resumed position {expected_seq}"}
        if rid in seen or rid in local_seen:
            return {"status": "DUPLICATE_STREAM_RECEIPT_ID", "checkpoint_valid": True, "duplicate_receipt_id": rid}
        if e.get("sequence") is not None and int(e.get("sequence")) != expected_seq:
            return {"status": "INVALID_STREAM_SEQUENCE", "checkpoint_valid": True, "position": expected_seq, "declared_sequence": e.get("sequence")}
        if not str(e.get("slot", "")):
            return {"status": "INVALID_STREAM_SLOT", "checkpoint_valid": True, "receipt_id": rid}
        local_seen.add(rid)

    requirements = copy.deepcopy(checkpoint.get("requirements") or {})
    latest = copy.deepcopy(checkpoint.get("latest_slot_snapshot") or {})
    frozen = copy.deepcopy(checkpoint.get("first_terminal_snapshot"))
    first_terminal = checkpoint.get("first_terminal_prefix")
    first_terminal_hash = checkpoint.get("first_terminal_stream_hash")
    chain = str(checkpoint["prefix_stream_hash"])
    suffix_history = []
    regression_prefixes = list(checkpoint.get("post_terminal_regression_prefixes") or ())
    conflicts = list(copy.deepcopy(checkpoint.get("post_terminal_conflicts") or ()))

    for j, e in enumerate(suffix, 1):
        seq = prefix + j
        chain = _stream_hash_step(chain, e)
        c = _certify_stream_entry(e)
        slot = str(e["slot"])
        latest[slot] = {
            "receipt_id": str(e["receipt_id"]), "kind": c["kind"],
            "certified": c["certified"], "certificate": c["certificate"],
        }
        snap = _evaluate_stream_snapshot(latest, requirements)
        if first_terminal is None and snap.get("terminal", False):
            first_terminal = seq
            first_terminal_hash = chain
            frozen = copy.deepcopy(latest)
        if first_terminal is not None and seq > int(first_terminal) and not snap.get("terminal", False):
            regression_prefixes.append(seq)
        if first_terminal is not None and seq > int(first_terminal):
            z = _conflict_event_for_receipt(e, latest, frozen)
            if z is not None:
                conflicts.append(z)
        suffix_history.append({
            "prefix_length": seq,
            "receipt_id": str(e["receipt_id"]),
            "stream_hash": chain,
            "terminal_now": bool(snap.get("terminal", False)),
            "route_status": snap.get("route", {}).get("status"),
        })

    current = _evaluate_stream_snapshot(latest, requirements)
    historical = first_terminal is not None
    current_conflict = _semantic_conflict_against_frozen(frozen, latest) if historical else False
    regressed = bool(historical and not current.get("terminal", False))
    total_count = prefix + len(suffix)
    post_count = max(0, total_count - int(first_terminal)) if historical else 0
    ever_conflict = bool(conflicts)
    if not historical:
        status = "NO_TERMINAL_PREFIX"
    elif regressed or current_conflict:
        status = "FIRST_TERMINAL_PREFIX_FROZEN__POST_TERMINAL_CONFLICT"
    elif post_count:
        status = "FIRST_TERMINAL_PREFIX_FROZEN__POST_TERMINAL_RECEIPTS_PRESENT"
    else:
        status = "FIRST_TERMINAL_PREFIX_FROZEN"

    all_ids = tuple(map(str, checkpoint.get("seen_receipt_ids") or ())) + tuple(str(e["receipt_id"]) for e in suffix)
    return {
        "status": status,
        "checkpoint_valid": True,
        "resumed_from_checkpoint_hash": checkpoint.get("checkpoint_hash"),
        "stream_id": checkpoint.get("stream_id"),
        "receipt_count": total_count,
        "historical_terminal": historical,
        "current_terminal": bool(current.get("terminal", False)),
        "first_terminal_prefix": first_terminal,
        "first_terminal_stream_hash": first_terminal_hash,
        "final_stream_hash": chain,
        "stop_recommended": historical,
        "stop_policy": f"STOP_AT_PREFIX_{first_terminal}" if historical else "CONTINUE_ACQUISITION",
        "post_terminal_receipt_count": post_count,
        "current_prefix_regressed": regressed,
        "post_terminal_semantic_conflict": current_conflict,
        "ever_post_terminal_semantic_conflict": ever_conflict,
        "post_terminal_semantic_conflict_count": len(conflicts),
        "post_terminal_conflicts": tuple(conflicts),
        "post_terminal_regression_seen": bool(regression_prefixes),
        "post_terminal_regression_count": len(regression_prefixes),
        "post_terminal_regression_prefixes": tuple(regression_prefixes),
        "first_terminal_snapshot": frozen,
        "latest_slot_snapshot": latest,
        "current_snapshot": current,
        "suffix_history": tuple(suffix_history),
        "seen_receipt_ids": all_ids,
        "truth_credit": 0,
        "root_write_capability": "NONE",
        "return_write_capability": "NONE",
        "solver_mutation_capability": "NONE",
        "firewall": "checkpoint continuation preserves the compacted prefix commitment and frozen first-terminal semantics; full historical replay still requires the archived prefix",
    }


# ---------------------------------------------------------------------------
# PASS005 multi-checkpoint rotation / lineage layer
# ---------------------------------------------------------------------------

_ROTATION_HISTORY_DOMAIN = b"HYPERTRIANGLE_SOLVER_AUX_ROTATION_HISTORY_V1\n"
_PREFIX_HISTORY_CHAIN_DOMAIN = b"HYPERTRIANGLE_SOLVER_AUX_PREFIX_HISTORY_CHAIN_V1\n"
_CHECKPOINT_CHAIN_DOMAIN = b"HYPERTRIANGLE_SOLVER_AUX_CHECKPOINT_CHAIN_V1\n"


def _hex64(value: Any) -> bool:
    z = str(value or "")
    if len(z) != 64:
        return False
    try:
        int(z, 16)
        return True
    except Exception:
        return False


def _checkpoint_rotation_commitment(checkpoint: Dict[str, Any]) -> str:
    """Return the cumulative rotation commitment represented by a checkpoint.

    PASS004/base checkpoints predate explicit rotation metadata.  They seed the
    PASS005 lineage from their own checkpoint hash, domain-separated so that a
    base checkpoint hash cannot be confused with a rotated-history commitment.
    """
    explicit = checkpoint.get("rotation_history_commitment")
    if explicit is not None:
        return str(explicit)
    h = hashlib.sha256()
    h.update(_ROTATION_HISTORY_DOMAIN)
    h.update(b"SEED\n")
    h.update(bytes.fromhex(str(checkpoint["checkpoint_hash"])))
    return h.hexdigest()


def _checkpoint_lineage_entry(checkpoint: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "rotation_index": int(checkpoint.get("rotation_index", 0)),
        "checkpoint_hash": str(checkpoint.get("checkpoint_hash", "")),
        "prefix_length": int(checkpoint.get("prefix_length", 0)),
        "prefix_stream_hash": str(checkpoint.get("prefix_stream_hash", "")),
        "rotation_history_commitment": _checkpoint_rotation_commitment(checkpoint),
        "prefix_history_commitment": str(checkpoint.get("prefix_history_commitment", "")),
    }


def _suffix_history_commitment(suffix_history: Sequence[Dict[str, Any]]) -> str:
    return hashlib.sha256(_canonical_for_hash(tuple(suffix_history))).hexdigest()


def _chained_prefix_history_commitment(previous: str, suffix_commitment: str) -> str:
    h = hashlib.sha256()
    h.update(_PREFIX_HISTORY_CHAIN_DOMAIN)
    h.update(bytes.fromhex(str(previous)))
    h.update(bytes.fromhex(str(suffix_commitment)))
    return h.hexdigest()


def _rotation_history_commitment(previous_rotation: str, previous_checkpoint_hash: str,
                                 suffix_commitment: str, prefix_stream_hash: str) -> str:
    h = hashlib.sha256()
    h.update(_ROTATION_HISTORY_DOMAIN)
    h.update(b"ROTATE\n")
    h.update(bytes.fromhex(str(previous_rotation)))
    h.update(bytes.fromhex(str(previous_checkpoint_hash)))
    h.update(bytes.fromhex(str(suffix_commitment)))
    h.update(bytes.fromhex(str(prefix_stream_hash)))
    return h.hexdigest()


def rotate_stream_checkpoint(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Compact a suffix directly from an existing checkpoint into a new checkpoint.

    No historical payload from the already compacted prefix is required.  The new
    checkpoint retains the exact PASS004 continuation semantics and adds a linear,
    append-only checkpoint lineage.  Archived checkpoint files are still required
    for independent replay of the checkpoint-to-checkpoint provenance chain.
    """
    previous = payload.get("checkpoint") or {}
    valid = validate_stream_checkpoint(previous)
    if not valid.get("checkpoint_valid", False):
        return {"status": "INVALID_STREAM_CHECKPOINT", "checkpoint_valid": False, "validation": valid}
    suffix = list(payload.get("receipts") or ())
    if not suffix:
        return {"status": "EMPTY_ROTATION_SUFFIX", "checkpoint_valid": True, "rotated": False}
    resumed = resume_stream_checkpoint({"checkpoint": previous, "receipts": suffix})
    if not resumed.get("final_stream_hash"):
        return {"status": "ROTATION_RESUME_FAILED", "checkpoint_valid": True, "rotated": False, "resume": resumed}

    previous_lineage = tuple(copy.deepcopy(previous.get("checkpoint_lineage") or ()))
    previous_entry = _checkpoint_lineage_entry(previous)
    lineage = previous_lineage + (previous_entry,)
    rotation_index = int(previous.get("rotation_index", 0)) + 1
    if len(lineage) != rotation_index:
        return {
            "status": "INVALID_PREVIOUS_CHECKPOINT_LINEAGE_DEPTH",
            "checkpoint_valid": True,
            "rotated": False,
            "expected_rotation_index": len(lineage),
            "declared_rotation_index": rotation_index,
        }

    suffix_hist = tuple(resumed.get("suffix_history") or ())
    suffix_commitment = _suffix_history_commitment(suffix_hist)
    previous_prefix_history = str(previous.get("prefix_history_commitment", ""))
    if not _hex64(previous_prefix_history):
        return {"status": "INVALID_PREVIOUS_PREFIX_HISTORY_COMMITMENT", "checkpoint_valid": True, "rotated": False}
    prefix_history_commitment = _chained_prefix_history_commitment(previous_prefix_history, suffix_commitment)
    previous_rotation = _checkpoint_rotation_commitment(previous)
    rotation_commitment = _rotation_history_commitment(
        previous_rotation, str(previous["checkpoint_hash"]), suffix_commitment, str(resumed["final_stream_hash"])
    )

    root_hash = str(previous.get("checkpoint_chain_root_hash") or previous.get("checkpoint_hash"))
    body = {
        "schema": _CHECKPOINT_SCHEMA,
        "aux_name": AUX_NAME,
        "aux_version": AUX_VERSION,
        "stream_id": previous.get("stream_id"),
        "requirements": copy.deepcopy(previous.get("requirements") or {}),
        "prefix_length": int(resumed["receipt_count"]),
        "next_sequence": int(resumed["receipt_count"]) + 1,
        "prefix_stream_hash": str(resumed["final_stream_hash"]),
        "seen_receipt_ids": tuple(resumed.get("seen_receipt_ids") or ()),
        "latest_slot_snapshot": copy.deepcopy(resumed.get("latest_slot_snapshot") or {}),
        "historical_terminal": bool(resumed.get("historical_terminal", False)),
        "current_terminal_at_checkpoint": bool(resumed.get("current_terminal", False)),
        "first_terminal_prefix": resumed.get("first_terminal_prefix"),
        "first_terminal_stream_hash": resumed.get("first_terminal_stream_hash"),
        "first_terminal_snapshot": copy.deepcopy(resumed.get("first_terminal_snapshot")),
        "stop_policy": resumed.get("stop_policy"),
        "post_terminal_regression_seen": bool(resumed.get("post_terminal_regression_seen", False)),
        "post_terminal_regression_count": int(resumed.get("post_terminal_regression_count", 0)),
        "post_terminal_regression_prefixes": tuple(resumed.get("post_terminal_regression_prefixes") or ()),
        "post_terminal_semantic_conflict_seen": bool(resumed.get("ever_post_terminal_semantic_conflict", False)),
        "post_terminal_semantic_conflict_count": int(resumed.get("post_terminal_semantic_conflict_count", 0)),
        "post_terminal_conflicts": tuple(copy.deepcopy(resumed.get("post_terminal_conflicts") or ())),
        "prefix_history_commitment": prefix_history_commitment,
        "previous_prefix_history_commitment": previous_prefix_history,
        "prefix_history_commitment_mode": "CHAINED_CHECKPOINT_HISTORY_V1",
        "rotation_index": rotation_index,
        "previous_checkpoint_hash": str(previous["checkpoint_hash"]),
        "checkpoint_chain_root_hash": root_hash,
        "checkpoint_lineage": lineage,
        "rotation_suffix_receipt_count": len(suffix),
        "rotation_suffix_history_commitment": suffix_commitment,
        "previous_rotation_history_commitment": previous_rotation,
        "rotation_history_commitment": rotation_commitment,
        "truth_credit": 0,
        "root_write_capability": "NONE",
        "return_write_capability": "NONE",
        "solver_mutation_capability": "NONE",
        "archive_requirement": "independent historical replay requires archived compacted receipts; independent checkpoint-lineage replay requires archived checkpoints",
    }
    checkpoint_hash = _checkpoint_hash_body(body)
    checkpoint = dict(body)
    checkpoint["checkpoint_hash"] = checkpoint_hash
    checkpoint_size = len(_canonical_for_hash(checkpoint))
    suffix_size = len(_canonical_for_hash(suffix))
    return {
        "status": "STREAM_CHECKPOINT_ROTATED",
        "checkpoint_valid": True,
        "rotated": True,
        "rotation_index": rotation_index,
        "previous_checkpoint_hash": str(previous["checkpoint_hash"]),
        "checkpoint_chain_root_hash": root_hash,
        "checkpoint": checkpoint,
        "compacted_suffix_receipt_count": len(suffix),
        "suffix_canonical_bytes": suffix_size,
        "checkpoint_canonical_bytes": checkpoint_size,
        "truth_credit": 0,
    }


def validate_checkpoint_chain(payload: Dict[str, Any] | Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    checkpoints = list(payload.get("checkpoints") or ()) if isinstance(payload, dict) else list(payload)
    require_root = bool(payload.get("require_root", True)) if isinstance(payload, dict) else True
    if not checkpoints:
        return {"status": "EMPTY_CHECKPOINT_CHAIN", "chain_valid": False}
    validations = [validate_stream_checkpoint(c) for c in checkpoints]
    for i, v in enumerate(validations):
        if not v.get("checkpoint_valid", False):
            return {"status": "INVALID_CHECKPOINT_IN_CHAIN", "chain_valid": False, "index": i, "validation": v}

    first = checkpoints[0]
    if require_root and int(first.get("rotation_index", 0)) != 0:
        return {"status": "CHECKPOINT_CHAIN_ROOT_MISSING", "chain_valid": False}
    root_hash = str(first.get("checkpoint_hash")) if int(first.get("rotation_index", 0)) == 0 else str(first.get("checkpoint_chain_root_hash") or "")
    stream_id = first.get("stream_id")
    requirements = _canonical_for_hash(first.get("requirements") or {})
    frozen_prefix = first.get("first_terminal_prefix")
    frozen_hash = first.get("first_terminal_stream_hash")
    frozen_snapshot = first.get("first_terminal_snapshot")

    for i in range(1, len(checkpoints)):
        prev, cur = checkpoints[i-1], checkpoints[i]
        if str(cur.get("previous_checkpoint_hash", "")) != str(prev.get("checkpoint_hash", "")):
            return {"status": "CHECKPOINT_PREVIOUS_HASH_MISMATCH", "chain_valid": False, "index": i}
        if int(cur.get("rotation_index", -1)) != int(prev.get("rotation_index", 0)) + 1:
            return {"status": "CHECKPOINT_ROTATION_INDEX_MISMATCH", "chain_valid": False, "index": i}
        if int(cur.get("prefix_length", 0)) <= int(prev.get("prefix_length", 0)):
            return {"status": "CHECKPOINT_PREFIX_NOT_STRICTLY_INCREASING", "chain_valid": False, "index": i}
        if str(cur.get("checkpoint_chain_root_hash", "")) != root_hash:
            return {"status": "CHECKPOINT_ROOT_HASH_MISMATCH", "chain_valid": False, "index": i}
        if cur.get("stream_id") != stream_id or _canonical_for_hash(cur.get("requirements") or {}) != requirements:
            return {"status": "CHECKPOINT_STREAM_CONTRACT_CHANGED", "chain_valid": False, "index": i}
        expected_lineage = tuple(copy.deepcopy(prev.get("checkpoint_lineage") or ())) + (_checkpoint_lineage_entry(prev),)
        if _canonical_for_hash(cur.get("checkpoint_lineage") or ()) != _canonical_for_hash(expected_lineage):
            return {"status": "CHECKPOINT_LINEAGE_MISMATCH", "chain_valid": False, "index": i}
        expected_prev_rotation = _checkpoint_rotation_commitment(prev)
        if str(cur.get("previous_rotation_history_commitment", "")) != expected_prev_rotation:
            return {"status": "CHECKPOINT_PREVIOUS_ROTATION_COMMITMENT_MISMATCH", "chain_valid": False, "index": i}
        suffix_commitment = str(cur.get("rotation_suffix_history_commitment", ""))
        if not _hex64(suffix_commitment):
            return {"status": "CHECKPOINT_SUFFIX_COMMITMENT_INVALID", "chain_valid": False, "index": i}
        expected_rotation = _rotation_history_commitment(
            expected_prev_rotation, str(prev["checkpoint_hash"]), suffix_commitment, str(cur["prefix_stream_hash"])
        )
        if str(cur.get("rotation_history_commitment", "")) != expected_rotation:
            return {"status": "CHECKPOINT_ROTATION_COMMITMENT_MISMATCH", "chain_valid": False, "index": i}
        if str(cur.get("previous_prefix_history_commitment", "")) != str(prev.get("prefix_history_commitment", "")):
            return {"status": "CHECKPOINT_PREVIOUS_PREFIX_HISTORY_COMMITMENT_MISMATCH", "chain_valid": False, "index": i}
        expected_prefix_history = _chained_prefix_history_commitment(str(prev.get("prefix_history_commitment")), suffix_commitment)
        if str(cur.get("prefix_history_commitment", "")) != expected_prefix_history:
            return {"status": "CHECKPOINT_PREFIX_HISTORY_COMMITMENT_MISMATCH", "chain_valid": False, "index": i}
        delta = int(cur.get("prefix_length")) - int(prev.get("prefix_length"))
        if int(cur.get("rotation_suffix_receipt_count", -1)) != delta:
            return {"status": "CHECKPOINT_ROTATION_SUFFIX_COUNT_MISMATCH", "chain_valid": False, "index": i}

        # Once terminality exists, the original first-terminal certificate is immutable.
        if frozen_prefix is None and cur.get("first_terminal_prefix") is not None:
            frozen_prefix = cur.get("first_terminal_prefix")
            frozen_hash = cur.get("first_terminal_stream_hash")
            frozen_snapshot = cur.get("first_terminal_snapshot")
        elif frozen_prefix is not None:
            if cur.get("first_terminal_prefix") != frozen_prefix or cur.get("first_terminal_stream_hash") != frozen_hash:
                return {"status": "CHECKPOINT_FIRST_TERMINAL_MUTATED", "chain_valid": False, "index": i}
            if _canonical_for_hash(cur.get("first_terminal_snapshot")) != _canonical_for_hash(frozen_snapshot):
                return {"status": "CHECKPOINT_FIRST_TERMINAL_SNAPSHOT_MUTATED", "chain_valid": False, "index": i}

    h = hashlib.sha256()
    h.update(_CHECKPOINT_CHAIN_DOMAIN)
    for c in checkpoints:
        h.update(bytes.fromhex(str(c["checkpoint_hash"])))
    return {
        "status": "CHECKPOINT_CHAIN_VALID",
        "chain_valid": True,
        "checkpoint_count": len(checkpoints),
        "rotation_count": max(0, len(checkpoints) - 1),
        "chain_root_checkpoint_hash": root_hash,
        "chain_tip_checkpoint_hash": str(checkpoints[-1]["checkpoint_hash"]),
        "chain_tip_prefix_length": int(checkpoints[-1]["prefix_length"]),
        "chain_tip_stream_hash": str(checkpoints[-1]["prefix_stream_hash"]),
        "first_terminal_prefix": frozen_prefix,
        "first_terminal_stream_hash": frozen_hash,
        "checkpoint_chain_audit_hash": h.hexdigest(),
        "truth_credit": 0,
    }


# ---------------------------------------------------------------------------
# PASS006 bounded checkpoint-lineage accumulator / anchor layer
# ---------------------------------------------------------------------------

_BOUNDED_CHECKPOINT_SCHEMA = "HYPERTRIANGLE_SOLVER_AUX_BOUNDED_STREAM_CHECKPOINT_V1"
_BOUNDED_CHECKPOINT_DOMAIN = b"HYPERTRIANGLE_SOLVER_AUX_BOUNDED_CHECKPOINT_V1\n"
_LINEAGE_ACCUMULATOR_DOMAIN = b"HYPERTRIANGLE_SOLVER_AUX_LINEAGE_ACCUMULATOR_V1\n"
_DEFAULT_LINEAGE_ANCHOR_WINDOW = 8
_MAX_LINEAGE_ANCHOR_WINDOW = 64


def _bounded_checkpoint_hash_body(body: Dict[str, Any]) -> str:
    h = hashlib.sha256()
    h.update(_BOUNDED_CHECKPOINT_DOMAIN)
    h.update(_canonical_for_hash(body))
    return h.hexdigest()


def _lineage_accumulator_seed() -> str:
    h = hashlib.sha256()
    h.update(_LINEAGE_ACCUMULATOR_DOMAIN)
    h.update(b"EMPTY\n")
    return h.hexdigest()


def _lineage_accumulator_step(previous_accumulator: str, entry: Dict[str, Any]) -> str:
    if not _hex64(previous_accumulator):
        raise AuxError("invalid previous lineage accumulator")
    h = hashlib.sha256()
    h.update(_LINEAGE_ACCUMULATOR_DOMAIN)
    h.update(b"STEP\n")
    h.update(bytes.fromhex(str(previous_accumulator)))
    h.update(_canonical_for_hash(entry))
    return h.hexdigest()


def _fold_lineage_accumulator(entries: Sequence[Dict[str, Any]], seed: str | None = None) -> str:
    acc = str(seed or _lineage_accumulator_seed())
    for entry in entries:
        acc = _lineage_accumulator_step(acc, entry)
    return acc


def _bounded_lineage_state_from_full(checkpoint: Dict[str, Any], window_size: int) -> Dict[str, Any]:
    """Compress the PASS005 explicit ancestor list of *checkpoint* into fixed anchors + accumulator."""
    lineage = tuple(copy.deepcopy(checkpoint.get("checkpoint_lineage") or ()))
    rotation_index = int(checkpoint.get("rotation_index", 0))
    if len(lineage) != rotation_index:
        raise AuxError("full checkpoint lineage depth mismatch")
    if window_size < 1 or window_size > _MAX_LINEAGE_ANCHOR_WINDOW:
        raise AuxError("invalid lineage anchor window size")
    compacted_count = max(0, len(lineage) - window_size)
    compacted = lineage[:compacted_count]
    anchors = lineage[compacted_count:]
    prefix_acc = _fold_lineage_accumulator(compacted)
    lineage_acc = _fold_lineage_accumulator(anchors, prefix_acc)
    return {
        "lineage_entry_count": len(lineage),
        "lineage_compacted_count": compacted_count,
        "lineage_prefix_accumulator": prefix_acc,
        "lineage_anchors": anchors,
        "lineage_accumulator": lineage_acc,
        "lineage_anchor_window_size": window_size,
    }


def _bounded_lineage_state(checkpoint: Dict[str, Any], window_size: int | None = None) -> Dict[str, Any]:
    if checkpoint.get("schema") in {_BOUNDED_CHECKPOINT_SCHEMA, _WITNESSED_CHECKPOINT_SCHEMA}:
        stored_window = int(checkpoint.get("lineage_anchor_window_size", _DEFAULT_LINEAGE_ANCHOR_WINDOW))
        if window_size is not None and int(window_size) != stored_window:
            raise AuxError("lineage anchor window cannot change after bounded migration")
        return {
            "lineage_entry_count": int(checkpoint.get("lineage_entry_count", 0)),
            "lineage_compacted_count": int(checkpoint.get("lineage_compacted_count", 0)),
            "lineage_prefix_accumulator": str(checkpoint.get("lineage_prefix_accumulator", "")),
            "lineage_anchors": tuple(copy.deepcopy(checkpoint.get("lineage_anchors") or ())),
            "lineage_accumulator": str(checkpoint.get("lineage_accumulator", "")),
            "lineage_anchor_window_size": stored_window,
        }
    return _bounded_lineage_state_from_full(checkpoint, int(window_size or _DEFAULT_LINEAGE_ANCHOR_WINDOW))


def _bounded_lineage_append(state: Dict[str, Any], entry: Dict[str, Any]) -> Dict[str, Any]:
    window = int(state["lineage_anchor_window_size"])
    compacted_count = int(state["lineage_compacted_count"])
    prefix_acc = str(state["lineage_prefix_accumulator"])
    anchors = list(copy.deepcopy(state.get("lineage_anchors") or ()))
    anchors.append(copy.deepcopy(entry))
    while len(anchors) > window:
        evicted = anchors.pop(0)
        prefix_acc = _lineage_accumulator_step(prefix_acc, evicted)
        compacted_count += 1
    lineage_acc = _fold_lineage_accumulator(anchors, prefix_acc)
    entry_count = compacted_count + len(anchors)
    return {
        "lineage_entry_count": entry_count,
        "lineage_compacted_count": compacted_count,
        "lineage_prefix_accumulator": prefix_acc,
        "lineage_anchors": tuple(anchors),
        "lineage_accumulator": lineage_acc,
        "lineage_anchor_window_size": window,
    }


def validate_bounded_stream_checkpoint(checkpoint: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(checkpoint, dict) or checkpoint.get("schema") != _BOUNDED_CHECKPOINT_SCHEMA:
        return {"status": "INVALID_BOUNDED_CHECKPOINT_SCHEMA", "checkpoint_valid": False}
    supplied = str(checkpoint.get("checkpoint_hash", ""))
    body = {k: copy.deepcopy(v) for k, v in checkpoint.items() if k != "checkpoint_hash"}
    expected = _bounded_checkpoint_hash_body(body)
    if supplied != expected:
        return {"status": "BOUNDED_CHECKPOINT_HASH_MISMATCH", "checkpoint_valid": False, "expected_checkpoint_hash": expected}
    try:
        prefix = int(checkpoint.get("prefix_length"))
        if int(checkpoint.get("next_sequence")) != prefix + 1:
            raise AuxError("next_sequence mismatch")
        ids = tuple(map(str, checkpoint.get("seen_receipt_ids") or ()))
        if len(ids) != prefix or len(set(ids)) != len(ids):
            raise AuxError("seen_receipt_ids must exactly cover compacted prefix")
        if not _hex64(checkpoint.get("prefix_stream_hash")):
            raise AuxError("invalid prefix stream hash")
        req = checkpoint.get("requirements") or {}
        latest = checkpoint.get("latest_slot_snapshot") or {}
        current = _evaluate_stream_snapshot(latest, req)
        if bool(current.get("terminal")) != bool(checkpoint.get("current_terminal_at_checkpoint")):
            raise AuxError("current terminal snapshot mismatch")
        historical = bool(checkpoint.get("historical_terminal", False))
        ftp = checkpoint.get("first_terminal_prefix")
        if historical:
            if ftp is None or int(ftp) < 1 or int(ftp) > prefix:
                raise AuxError("invalid first terminal prefix")
            frozen = checkpoint.get("first_terminal_snapshot") or {}
            if not _evaluate_stream_snapshot(frozen, req).get("terminal", False):
                raise AuxError("frozen first-terminal snapshot is not terminal")
            if not _hex64(checkpoint.get("first_terminal_stream_hash")):
                raise AuxError("invalid first terminal stream hash")
        elif ftp is not None or checkpoint.get("first_terminal_stream_hash") is not None:
            raise AuxError("nonterminal checkpoint cannot declare first terminal data")
        phc = str(checkpoint.get("prefix_history_commitment", ""))
        if not _hex64(phc):
            raise AuxError("invalid prefix history commitment")
        rotation_index = int(checkpoint.get("rotation_index", -1))
        if rotation_index < 1:
            raise AuxError("bounded checkpoint must be at rotation index >= 1")
        prev_hash = str(checkpoint.get("previous_checkpoint_hash", ""))
        root_hash = str(checkpoint.get("checkpoint_chain_root_hash", ""))
        if not _hex64(prev_hash) or not _hex64(root_hash):
            raise AuxError("invalid checkpoint lineage hashes")

        window = int(checkpoint.get("lineage_anchor_window_size", 0))
        compacted_count = int(checkpoint.get("lineage_compacted_count", -1))
        entry_count = int(checkpoint.get("lineage_entry_count", -1))
        anchors = tuple(checkpoint.get("lineage_anchors") or ())
        prefix_acc = str(checkpoint.get("lineage_prefix_accumulator", ""))
        lineage_acc = str(checkpoint.get("lineage_accumulator", ""))
        if window < 1 or window > _MAX_LINEAGE_ANCHOR_WINDOW:
            raise AuxError("invalid lineage anchor window")
        if compacted_count < 0 or entry_count != rotation_index or compacted_count + len(anchors) != entry_count:
            raise AuxError("bounded lineage count mismatch")
        if len(anchors) < 1 or len(anchors) > window:
            raise AuxError("bounded lineage anchor count invalid")
        if not _hex64(prefix_acc) or not _hex64(lineage_acc):
            raise AuxError("invalid lineage accumulator encoding")
        expected_acc = _fold_lineage_accumulator(anchors, prefix_acc)
        if expected_acc != lineage_acc:
            raise AuxError("lineage accumulator mismatch")
        previous_prefix = -1
        for j, entry in enumerate(anchors):
            expected_index = compacted_count + j
            if int(entry.get("rotation_index", -1)) != expected_index:
                raise AuxError("lineage anchor rotation index mismatch")
            if not _hex64(entry.get("checkpoint_hash")) or not _hex64(entry.get("prefix_stream_hash")):
                raise AuxError("invalid lineage anchor hash")
            if not _hex64(entry.get("rotation_history_commitment")) or not _hex64(entry.get("prefix_history_commitment")):
                raise AuxError("invalid lineage anchor commitment")
            ep = int(entry.get("prefix_length", -1))
            if ep <= previous_prefix or ep >= prefix:
                raise AuxError("lineage anchor prefix order mismatch")
            previous_prefix = ep
        if str(anchors[-1].get("checkpoint_hash")) != prev_hash:
            raise AuxError("previous checkpoint hash does not match anchor tip")
        if compacted_count == 0 and str(anchors[0].get("checkpoint_hash")) != root_hash:
            raise AuxError("checkpoint chain root mismatch")
        suffix_count = int(checkpoint.get("rotation_suffix_receipt_count", -1))
        if suffix_count != prefix - int(anchors[-1].get("prefix_length")):
            raise AuxError("rotation suffix receipt count mismatch")

        suffix_commitment = str(checkpoint.get("rotation_suffix_history_commitment", ""))
        prev_rotation = str(checkpoint.get("previous_rotation_history_commitment", ""))
        rot = str(checkpoint.get("rotation_history_commitment", ""))
        prev_prefix_commitment = str(checkpoint.get("previous_prefix_history_commitment", ""))
        if not all(_hex64(x) for x in (suffix_commitment, prev_rotation, rot, prev_prefix_commitment)):
            raise AuxError("invalid rotation commitment encoding")
        expected_rot = _rotation_history_commitment(prev_rotation, prev_hash, suffix_commitment, str(checkpoint["prefix_stream_hash"]))
        if rot != expected_rot:
            raise AuxError("rotation history commitment mismatch")
        if phc != _chained_prefix_history_commitment(prev_prefix_commitment, suffix_commitment):
            raise AuxError("prefix history commitment mismatch")
        if checkpoint.get("prefix_history_commitment_mode") != "CHAINED_CHECKPOINT_HISTORY_V1":
            raise AuxError("invalid prefix history commitment mode")
        if checkpoint.get("checkpoint_lineage_mode") != "BOUNDED_ACCUMULATOR_ANCHORS_V1":
            raise AuxError("invalid bounded lineage mode")
    except Exception as exc:
        return {"status": "BOUNDED_CHECKPOINT_SEMANTIC_VALIDATION_FAILED", "checkpoint_valid": False, "error": str(exc)}
    return {
        "status": "BOUNDED_STREAM_CHECKPOINT_VALID",
        "checkpoint_valid": True,
        "checkpoint_hash": supplied,
        "lineage_entry_count": int(checkpoint.get("lineage_entry_count", 0)),
        "lineage_compacted_count": int(checkpoint.get("lineage_compacted_count", 0)),
        "lineage_anchor_count": len(tuple(checkpoint.get("lineage_anchors") or ())),
        "lineage_accumulator": str(checkpoint.get("lineage_accumulator", "")),
        "firewall": "standalone validation checks the retained anchors and accumulator self-consistency; reconstructing compacted ancestor metadata requires archived checkpoints",
    }


def _validated_checkpoint_any(checkpoint: Dict[str, Any]) -> Dict[str, Any]:
    if checkpoint.get("schema") == _BOUNDED_CHECKPOINT_SCHEMA:
        return validate_bounded_stream_checkpoint(checkpoint)
    return validate_stream_checkpoint(checkpoint)


def _resume_checkpoint_any(checkpoint: Dict[str, Any], suffix: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    valid = _validated_checkpoint_any(checkpoint)
    if not valid.get("checkpoint_valid", False):
        return {"status": "INVALID_STREAM_CHECKPOINT", "checkpoint_valid": False, "validation": valid}
    suffix = list(copy.deepcopy(suffix))
    prefix = int(checkpoint["prefix_length"])
    seen = set(map(str, checkpoint.get("seen_receipt_ids") or ()))
    local_seen = set()
    for j, e in enumerate(suffix, 1):
        expected_seq = prefix + j
        rid = str(e.get("receipt_id", ""))
        if not rid:
            return {"status": "INVALID_STREAM_RECEIPT_ID", "checkpoint_valid": True, "error": f"missing receipt_id at resumed position {expected_seq}"}
        if rid in seen or rid in local_seen:
            return {"status": "DUPLICATE_STREAM_RECEIPT_ID", "checkpoint_valid": True, "duplicate_receipt_id": rid}
        if e.get("sequence") is not None and int(e.get("sequence")) != expected_seq:
            return {"status": "INVALID_STREAM_SEQUENCE", "checkpoint_valid": True, "position": expected_seq, "declared_sequence": e.get("sequence")}
        if not str(e.get("slot", "")):
            return {"status": "INVALID_STREAM_SLOT", "checkpoint_valid": True, "receipt_id": rid}
        local_seen.add(rid)

    requirements = copy.deepcopy(checkpoint.get("requirements") or {})
    latest = copy.deepcopy(checkpoint.get("latest_slot_snapshot") or {})
    frozen = copy.deepcopy(checkpoint.get("first_terminal_snapshot"))
    first_terminal = checkpoint.get("first_terminal_prefix")
    first_terminal_hash = checkpoint.get("first_terminal_stream_hash")
    chain = str(checkpoint["prefix_stream_hash"])
    suffix_history = []
    regression_prefixes = list(checkpoint.get("post_terminal_regression_prefixes") or ())
    conflicts = list(copy.deepcopy(checkpoint.get("post_terminal_conflicts") or ()))

    for j, e in enumerate(suffix, 1):
        seq = prefix + j
        chain = _stream_hash_step(chain, e)
        c = _certify_stream_entry(e)
        slot = str(e["slot"])
        latest[slot] = {"receipt_id": str(e["receipt_id"]), "kind": c["kind"], "certified": c["certified"], "certificate": c["certificate"]}
        snap = _evaluate_stream_snapshot(latest, requirements)
        if first_terminal is None and snap.get("terminal", False):
            first_terminal = seq; first_terminal_hash = chain; frozen = copy.deepcopy(latest)
        if first_terminal is not None and seq > int(first_terminal) and not snap.get("terminal", False):
            regression_prefixes.append(seq)
        if first_terminal is not None and seq > int(first_terminal):
            z = _conflict_event_for_receipt(e, latest, frozen)
            if z is not None: conflicts.append(z)
        suffix_history.append({"prefix_length": seq, "receipt_id": str(e["receipt_id"]), "stream_hash": chain, "terminal_now": bool(snap.get("terminal", False)), "route_status": snap.get("route", {}).get("status")})

    current = _evaluate_stream_snapshot(latest, requirements)
    historical = first_terminal is not None
    current_conflict = _semantic_conflict_against_frozen(frozen, latest) if historical else False
    total_count = prefix + len(suffix)
    post_count = max(0, total_count - int(first_terminal)) if historical else 0
    if not historical: status = "NO_TERMINAL_PREFIX"
    elif (historical and not current.get("terminal", False)) or current_conflict: status = "FIRST_TERMINAL_PREFIX_FROZEN__POST_TERMINAL_CONFLICT"
    elif post_count: status = "FIRST_TERMINAL_PREFIX_FROZEN__POST_TERMINAL_RECEIPTS_PRESENT"
    else: status = "FIRST_TERMINAL_PREFIX_FROZEN"
    return {
        "status": status,
        "stream_id": checkpoint.get("stream_id"),
        "receipt_count": total_count,
        "historical_terminal": historical,
        "current_terminal": bool(current.get("terminal", False)),
        "first_terminal_prefix": first_terminal,
        "first_terminal_stream_hash": first_terminal_hash,
        "final_stream_hash": chain,
        "stop_policy": f"STOP_AT_PREFIX_{first_terminal}" if historical else "CONTINUE_ACQUISITION",
        "post_terminal_regression_seen": bool(regression_prefixes),
        "post_terminal_regression_count": len(regression_prefixes),
        "post_terminal_regression_prefixes": tuple(regression_prefixes),
        "ever_post_terminal_semantic_conflict": bool(conflicts),
        "post_terminal_semantic_conflict_count": len(conflicts),
        "post_terminal_conflicts": tuple(conflicts),
        "first_terminal_snapshot": frozen,
        "latest_slot_snapshot": latest,
        "suffix_history": tuple(suffix_history),
        "seen_receipt_ids": tuple(map(str, checkpoint.get("seen_receipt_ids") or ())) + tuple(str(e["receipt_id"]) for e in suffix),
        "truth_credit": 0,
        "root_write_capability": "NONE",
        "return_write_capability": "NONE",
        "solver_mutation_capability": "NONE",
    }


def rotate_bounded_checkpoint(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Rotate to a bounded-lineage checkpoint.

    The first call may consume a PASS005 full-lineage checkpoint; all later calls consume bounded checkpoints.
    Only a bounded anchor window is retained in the active checkpoint.  Older ancestor metadata is committed
    by a rolling SHA-256 accumulator and remains independently reconstructible only from archived checkpoints.
    """
    previous = payload.get("checkpoint") or {}
    valid = _validated_checkpoint_any(previous)
    if not valid.get("checkpoint_valid", False):
        return {"status": "INVALID_STREAM_CHECKPOINT", "checkpoint_valid": False, "validation": valid}
    suffix = list(payload.get("receipts") or ())
    if not suffix:
        return {"status": "EMPTY_ROTATION_SUFFIX", "checkpoint_valid": True, "rotated": False}
    requested_window = payload.get("anchor_window_size")
    if previous.get("schema") == _BOUNDED_CHECKPOINT_SCHEMA:
        window = int(previous.get("lineage_anchor_window_size"))
        if requested_window is not None and int(requested_window) != window:
            return {"status": "LINEAGE_ANCHOR_WINDOW_IMMUTABLE", "checkpoint_valid": True, "rotated": False, "anchor_window_size": window}
    else:
        window = int(requested_window or _DEFAULT_LINEAGE_ANCHOR_WINDOW)
    if window < 1 or window > _MAX_LINEAGE_ANCHOR_WINDOW:
        return {"status": "INVALID_LINEAGE_ANCHOR_WINDOW", "checkpoint_valid": True, "rotated": False}

    resumed = _resume_checkpoint_any(previous, suffix)
    if not resumed.get("final_stream_hash"):
        return {"status": "ROTATION_RESUME_FAILED", "checkpoint_valid": True, "rotated": False, "resume": resumed}
    try:
        state = _bounded_lineage_state(previous, window)
        state = _bounded_lineage_append(state, _checkpoint_lineage_entry(previous))
    except Exception as exc:
        return {"status": "BOUNDED_LINEAGE_CONSTRUCTION_FAILED", "checkpoint_valid": True, "rotated": False, "error": str(exc)}
    rotation_index = int(previous.get("rotation_index", 0)) + 1
    if int(state["lineage_entry_count"]) != rotation_index:
        return {"status": "BOUNDED_LINEAGE_DEPTH_MISMATCH", "checkpoint_valid": True, "rotated": False}

    suffix_hist = tuple(resumed.get("suffix_history") or ())
    suffix_commitment = _suffix_history_commitment(suffix_hist)
    previous_prefix_history = str(previous.get("prefix_history_commitment", ""))
    if not _hex64(previous_prefix_history):
        return {"status": "INVALID_PREVIOUS_PREFIX_HISTORY_COMMITMENT", "checkpoint_valid": True, "rotated": False}
    prefix_history_commitment = _chained_prefix_history_commitment(previous_prefix_history, suffix_commitment)
    previous_rotation = _checkpoint_rotation_commitment(previous)
    rotation_commitment = _rotation_history_commitment(previous_rotation, str(previous["checkpoint_hash"]), suffix_commitment, str(resumed["final_stream_hash"]))
    root_hash = str(previous.get("checkpoint_chain_root_hash") or previous.get("checkpoint_hash"))

    body = {
        "schema": _BOUNDED_CHECKPOINT_SCHEMA,
        "aux_name": AUX_NAME,
        "aux_version": AUX_VERSION,
        "stream_id": previous.get("stream_id"),
        "requirements": copy.deepcopy(previous.get("requirements") or {}),
        "prefix_length": int(resumed["receipt_count"]),
        "next_sequence": int(resumed["receipt_count"]) + 1,
        "prefix_stream_hash": str(resumed["final_stream_hash"]),
        "seen_receipt_ids": tuple(resumed.get("seen_receipt_ids") or ()),
        "latest_slot_snapshot": copy.deepcopy(resumed.get("latest_slot_snapshot") or {}),
        "historical_terminal": bool(resumed.get("historical_terminal", False)),
        "current_terminal_at_checkpoint": bool(resumed.get("current_terminal", False)),
        "first_terminal_prefix": resumed.get("first_terminal_prefix"),
        "first_terminal_stream_hash": resumed.get("first_terminal_stream_hash"),
        "first_terminal_snapshot": copy.deepcopy(resumed.get("first_terminal_snapshot")),
        "stop_policy": resumed.get("stop_policy"),
        "post_terminal_regression_seen": bool(resumed.get("post_terminal_regression_seen", False)),
        "post_terminal_regression_count": int(resumed.get("post_terminal_regression_count", 0)),
        "post_terminal_regression_prefixes": tuple(resumed.get("post_terminal_regression_prefixes") or ()),
        "post_terminal_semantic_conflict_seen": bool(resumed.get("ever_post_terminal_semantic_conflict", False)),
        "post_terminal_semantic_conflict_count": int(resumed.get("post_terminal_semantic_conflict_count", 0)),
        "post_terminal_conflicts": tuple(copy.deepcopy(resumed.get("post_terminal_conflicts") or ())),
        "prefix_history_commitment": prefix_history_commitment,
        "previous_prefix_history_commitment": previous_prefix_history,
        "prefix_history_commitment_mode": "CHAINED_CHECKPOINT_HISTORY_V1",
        "rotation_index": rotation_index,
        "previous_checkpoint_hash": str(previous["checkpoint_hash"]),
        "checkpoint_chain_root_hash": root_hash,
        "checkpoint_lineage_mode": "BOUNDED_ACCUMULATOR_ANCHORS_V1",
        "lineage_entry_count": int(state["lineage_entry_count"]),
        "lineage_compacted_count": int(state["lineage_compacted_count"]),
        "lineage_prefix_accumulator": str(state["lineage_prefix_accumulator"]),
        "lineage_anchors": tuple(copy.deepcopy(state["lineage_anchors"])),
        "lineage_accumulator": str(state["lineage_accumulator"]),
        "lineage_anchor_window_size": int(state["lineage_anchor_window_size"]),
        "rotation_suffix_receipt_count": len(suffix),
        "rotation_suffix_history_commitment": suffix_commitment,
        "previous_rotation_history_commitment": previous_rotation,
        "rotation_history_commitment": rotation_commitment,
        "truth_credit": 0,
        "root_write_capability": "NONE",
        "return_write_capability": "NONE",
        "solver_mutation_capability": "NONE",
        "archive_requirement": "active lineage is bounded; independent reconstruction of compacted ancestor metadata requires archived checkpoints; exact receipt-id duplicate detection still retains the historical receipt-id set",
    }
    checkpoint_hash = _bounded_checkpoint_hash_body(body)
    checkpoint = dict(body); checkpoint["checkpoint_hash"] = checkpoint_hash
    return {
        "status": "BOUNDED_STREAM_CHECKPOINT_ROTATED",
        "checkpoint_valid": True,
        "rotated": True,
        "rotation_index": rotation_index,
        "checkpoint": checkpoint,
        "lineage_entry_count": int(state["lineage_entry_count"]),
        "lineage_compacted_count": int(state["lineage_compacted_count"]),
        "lineage_anchor_count": len(tuple(state["lineage_anchors"])),
        "lineage_anchor_window_size": window,
        "lineage_accumulator": str(state["lineage_accumulator"]),
        "checkpoint_canonical_bytes": len(_canonical_for_hash(checkpoint)),
        "truth_credit": 0,
    }


def _expected_bounded_child_lineage(previous: Dict[str, Any], child: Dict[str, Any]) -> Dict[str, Any]:
    window = int(child.get("lineage_anchor_window_size", _DEFAULT_LINEAGE_ANCHOR_WINDOW))
    state = _bounded_lineage_state(previous, window)
    return _bounded_lineage_append(state, _checkpoint_lineage_entry(previous))


def validate_bounded_checkpoint_chain(payload: Dict[str, Any] | Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    checkpoints = list(payload.get("checkpoints") or ()) if isinstance(payload, dict) else list(payload)
    require_root = bool(payload.get("require_root", True)) if isinstance(payload, dict) else True
    if not checkpoints:
        return {"status": "EMPTY_CHECKPOINT_CHAIN", "chain_valid": False}
    if require_root and int(checkpoints[0].get("rotation_index", 0)) != 0:
        return {"status": "CHECKPOINT_CHAIN_ROOT_MISSING", "chain_valid": False}
    validations = [_validated_checkpoint_any(c) for c in checkpoints]
    for i,v in enumerate(validations):
        if not v.get("checkpoint_valid", False):
            return {"status": "INVALID_CHECKPOINT_IN_CHAIN", "chain_valid": False, "index": i, "validation": v}
    root_hash = str(checkpoints[0].get("checkpoint_hash")) if int(checkpoints[0].get("rotation_index",0)) == 0 else str(checkpoints[0].get("checkpoint_chain_root_hash", ""))
    stream_id = checkpoints[0].get("stream_id")
    requirements = _canonical_for_hash(checkpoints[0].get("requirements") or {})
    frozen_prefix = checkpoints[0].get("first_terminal_prefix")
    frozen_hash = checkpoints[0].get("first_terminal_stream_hash")
    frozen_snapshot = checkpoints[0].get("first_terminal_snapshot")
    for i in range(1,len(checkpoints)):
        prev, cur = checkpoints[i-1], checkpoints[i]
        if str(cur.get("previous_checkpoint_hash", "")) != str(prev.get("checkpoint_hash", "")):
            return {"status": "CHECKPOINT_PREVIOUS_HASH_MISMATCH", "chain_valid": False, "index": i}
        if int(cur.get("rotation_index",-1)) != int(prev.get("rotation_index",0))+1:
            return {"status": "CHECKPOINT_ROTATION_INDEX_MISMATCH", "chain_valid": False, "index": i}
        if int(cur.get("prefix_length",0)) <= int(prev.get("prefix_length",0)):
            return {"status": "CHECKPOINT_PREFIX_NOT_STRICTLY_INCREASING", "chain_valid": False, "index": i}
        if str(cur.get("checkpoint_chain_root_hash", "")) != root_hash:
            return {"status": "CHECKPOINT_ROOT_HASH_MISMATCH", "chain_valid": False, "index": i}
        if cur.get("stream_id") != stream_id or _canonical_for_hash(cur.get("requirements") or {}) != requirements:
            return {"status": "CHECKPOINT_STREAM_CONTRACT_CHANGED", "chain_valid": False, "index": i}
        if cur.get("schema") == _BOUNDED_CHECKPOINT_SCHEMA:
            try: expected = _expected_bounded_child_lineage(prev,cur)
            except Exception as exc: return {"status":"CHECKPOINT_BOUNDED_LINEAGE_EXPECTATION_FAILED","chain_valid":False,"index":i,"error":str(exc)}
            fields=("lineage_entry_count","lineage_compacted_count","lineage_prefix_accumulator","lineage_accumulator","lineage_anchor_window_size")
            for field in fields:
                if cur.get(field) != expected.get(field):
                    return {"status":"CHECKPOINT_BOUNDED_LINEAGE_MISMATCH","chain_valid":False,"index":i,"field":field}
            if _canonical_for_hash(cur.get("lineage_anchors") or ()) != _canonical_for_hash(expected.get("lineage_anchors") or ()):
                return {"status":"CHECKPOINT_BOUNDED_LINEAGE_MISMATCH","chain_valid":False,"index":i,"field":"lineage_anchors"}
        elif prev.get("schema") == _BOUNDED_CHECKPOINT_SCHEMA:
            return {"status":"BOUNDED_TO_FULL_LINEAGE_DOWNGRADE_REJECTED","chain_valid":False,"index":i}
        else:
            expected_lineage = tuple(copy.deepcopy(prev.get("checkpoint_lineage") or ())) + (_checkpoint_lineage_entry(prev),)
            if _canonical_for_hash(cur.get("checkpoint_lineage") or ()) != _canonical_for_hash(expected_lineage):
                return {"status":"CHECKPOINT_LINEAGE_MISMATCH","chain_valid":False,"index":i}
        expected_prev_rotation=_checkpoint_rotation_commitment(prev)
        if str(cur.get("previous_rotation_history_commitment", "")) != expected_prev_rotation:
            return {"status":"CHECKPOINT_PREVIOUS_ROTATION_COMMITMENT_MISMATCH","chain_valid":False,"index":i}
        suffix_commitment=str(cur.get("rotation_suffix_history_commitment", ""))
        expected_rotation=_rotation_history_commitment(expected_prev_rotation,str(prev["checkpoint_hash"]),suffix_commitment,str(cur["prefix_stream_hash"]))
        if str(cur.get("rotation_history_commitment", "")) != expected_rotation:
            return {"status":"CHECKPOINT_ROTATION_COMMITMENT_MISMATCH","chain_valid":False,"index":i}
        if str(cur.get("previous_prefix_history_commitment", "")) != str(prev.get("prefix_history_commitment", "")):
            return {"status":"CHECKPOINT_PREVIOUS_PREFIX_HISTORY_COMMITMENT_MISMATCH","chain_valid":False,"index":i}
        if str(cur.get("prefix_history_commitment", "")) != _chained_prefix_history_commitment(str(prev.get("prefix_history_commitment")),suffix_commitment):
            return {"status":"CHECKPOINT_PREFIX_HISTORY_COMMITMENT_MISMATCH","chain_valid":False,"index":i}
        if frozen_prefix is None and cur.get("first_terminal_prefix") is not None:
            frozen_prefix=cur.get("first_terminal_prefix"); frozen_hash=cur.get("first_terminal_stream_hash"); frozen_snapshot=cur.get("first_terminal_snapshot")
        elif frozen_prefix is not None:
            if cur.get("first_terminal_prefix") != frozen_prefix or cur.get("first_terminal_stream_hash") != frozen_hash or _canonical_for_hash(cur.get("first_terminal_snapshot")) != _canonical_for_hash(frozen_snapshot):
                return {"status":"CHECKPOINT_FIRST_TERMINAL_MUTATED","chain_valid":False,"index":i}
    h=hashlib.sha256(); h.update(_CHECKPOINT_CHAIN_DOMAIN)
    for c in checkpoints: h.update(bytes.fromhex(str(c["checkpoint_hash"])))
    tip=checkpoints[-1]
    return {
        "status":"BOUNDED_CHECKPOINT_CHAIN_VALID",
        "chain_valid":True,
        "checkpoint_count":len(checkpoints),
        "rotation_count":max(0,len(checkpoints)-1),
        "chain_root_checkpoint_hash":root_hash,
        "chain_tip_checkpoint_hash":str(tip["checkpoint_hash"]),
        "chain_tip_prefix_length":int(tip["prefix_length"]),
        "chain_tip_stream_hash":str(tip["prefix_stream_hash"]),
        "first_terminal_prefix":frozen_prefix,
        "first_terminal_stream_hash":frozen_hash,
        "lineage_mode":tip.get("checkpoint_lineage_mode","FULL_EXPLICIT_V1"),
        "lineage_entry_count":int(tip.get("lineage_entry_count",tip.get("rotation_index",0))),
        "lineage_compacted_count":int(tip.get("lineage_compacted_count",0)),
        "lineage_anchor_count":len(tuple(tip.get("lineage_anchors") or ())) if tip.get("schema")==_BOUNDED_CHECKPOINT_SCHEMA else len(tuple(tip.get("checkpoint_lineage") or ())),
        "lineage_accumulator":tip.get("lineage_accumulator"),
        "checkpoint_chain_audit_hash":h.hexdigest(),
        "truth_credit":0,
        "firewall":"full audit of compacted ancestor metadata requires the archived checkpoint chain; the active bounded checkpoint carries a fixed-size cryptographic lineage commitment plus recent anchors",
    }


# ---------------------------------------------------------------------------
# PASS007 exact duplicate-membership no-go + witnessed sparse-Merkle layer
# ---------------------------------------------------------------------------

_WITNESSED_CHECKPOINT_SCHEMA = "HYPERTRIANGLE_SOLVER_AUX_WITNESSED_STREAM_CHECKPOINT_V1"
_WITNESSED_CHECKPOINT_DOMAIN = b"HYPERTRIANGLE_SOLVER_AUX_WITNESSED_CHECKPOINT_V1\n"
_RECEIPT_ID_KEY_DOMAIN = b"HYPERTRIANGLE_SOLVER_AUX_RECEIPT_ID_KEY_V1\n"
_RECEIPT_ID_EMPTY_LEAF_DOMAIN = b"HYPERTRIANGLE_SOLVER_AUX_RECEIPT_ID_EMPTY_LEAF_V1\n"
_RECEIPT_ID_PRESENT_LEAF_DOMAIN = b"HYPERTRIANGLE_SOLVER_AUX_RECEIPT_ID_PRESENT_LEAF_V1\n"
_RECEIPT_ID_NODE_DOMAIN = b"HYPERTRIANGLE_SOLVER_AUX_RECEIPT_ID_NODE_V1\n"
_RECEIPT_ID_PROOF_BUNDLE_DOMAIN = b"HYPERTRIANGLE_SOLVER_AUX_RECEIPT_ID_PROOF_BUNDLE_V1\n"
_REGRESSION_ACC_DOMAIN = b"HYPERTRIANGLE_SOLVER_AUX_REGRESSION_ACC_V1\n"
_CONFLICT_ACC_DOMAIN = b"HYPERTRIANGLE_SOLVER_AUX_CONFLICT_ACC_V1\n"


def exact_membership_bounded_no_go(payload: Dict[str, Any] | None = None) -> Dict[str, Any]:
    """Finite-state no-go for exact standalone duplicate membership.

    A b-bit standalone checkpoint has at most 2^b states.  On any universe with N>b
    distinguishable receipt IDs there are 2^N possible seen-ID sets, so two different sets
    must share a checkpoint state.  An ID in their symmetric difference then has different
    exact membership truth values but the same checkpoint state.  Thus no fixed-size
    standalone state can answer exact membership for arbitrarily large sets.
    """
    payload = payload or {}
    bits = int(payload.get("checkpoint_bits", 256))
    universe = int(payload.get("universe_size", bits + 1))
    if bits < 0 or universe < 0:
        return {"status": "INVALID_NO_GO_PARAMETERS"}
    applies = universe > bits
    return {
        "status": "EXACT_STANDALONE_BOUNDED_MEMBERSHIP_NO_GO" if applies else "PIGEONHOLE_THRESHOLD_NOT_CROSSED",
        "checkpoint_bits": bits,
        "universe_size": universe,
        "checkpoint_state_count_log2": bits,
        "possible_seen_sets_log2": universe,
        "pigeonhole_collision_for_distinct_seen_sets": applies,
        "conclusion": (
            "fixed-size standalone exact membership is impossible for arbitrarily large receipt-id sets; "
            "bounded authenticated roots require external membership/non-membership witnesses or an external exact index"
            if applies else
            "choose universe_size > checkpoint_bits to instantiate the finite pigeonhole no-go"
        ),
        "probabilistic_false_positive_substitute_used": False,
        "truth_credit": 0,
    }


def _receipt_id_key(receipt_id: Any) -> bytes:
    rid = str(receipt_id)
    if not rid:
        raise AuxError("receipt_id must be nonempty")
    h = hashlib.sha256(); h.update(_RECEIPT_ID_KEY_DOMAIN); h.update(rid.encode("utf-8")); return h.digest()


def _sm_node(left: bytes, right: bytes) -> bytes:
    h=hashlib.sha256(); h.update(_RECEIPT_ID_NODE_DOMAIN); h.update(left); h.update(right); return h.digest()


def _sm_present_leaf(key: bytes) -> bytes:
    h=hashlib.sha256(); h.update(_RECEIPT_ID_PRESENT_LEAF_DOMAIN); h.update(key); return h.digest()


def _sm_empty_leaf() -> bytes:
    h=hashlib.sha256(); h.update(_RECEIPT_ID_EMPTY_LEAF_DOMAIN); return h.digest()


def _sm_empty_hashes() -> Tuple[bytes, ...]:
    vals=[b""]*257
    vals[256]=_sm_empty_leaf()
    for depth in range(255,-1,-1): vals[depth]=_sm_node(vals[depth+1],vals[depth+1])
    return tuple(vals)

_SM_EMPTY_HASHES=_sm_empty_hashes()


def sparse_receipt_id_empty_root() -> str:
    return _SM_EMPTY_HASHES[0].hex()


def _sm_maps(receipt_ids: Sequence[Any]) -> Tuple[Dict[int, bytes], ...]:
    leaves: Dict[int, bytes]={}
    owner: Dict[int,str]={}
    for x in receipt_ids:
        rid=str(x)
        key=_receipt_id_key(rid); idx=int.from_bytes(key,"big")
        if idx in leaves and owner[idx] != rid:
            raise AuxError("receipt-id key collision under SHA-256 path mapping")
        owner[idx]=rid; leaves[idx]=_sm_present_leaf(key)
    maps=[{} for _ in range(257)]
    maps[256]=leaves
    for depth in range(255,-1,-1):
        child=maps[depth+1]; parents={}
        for parent in {idx>>1 for idx in child.keys()}:
            left=child.get(parent<<1,_SM_EMPTY_HASHES[depth+1])
            right=child.get((parent<<1)|1,_SM_EMPTY_HASHES[depth+1])
            parents[parent]=_sm_node(left,right)
        maps[depth]=parents
    return tuple(maps)


def sparse_receipt_id_root(receipt_ids: Sequence[Any]) -> str:
    maps=_sm_maps(receipt_ids)
    return maps[0].get(0,_SM_EMPTY_HASHES[0]).hex()


class ExternalReceiptIdIndex:
    """Reference exact external index used to produce PASS007 sparse-Merkle witnesses.

    This object is intentionally *not* serialized into a checkpoint.  Its memory grows with the
    number of receipt IDs.  PASS007 keeps that growth outside the bounded checkpoint and uses
    proofs against the checkpoint root to authenticate queries/updates.
    """
    def __init__(self, receipt_ids: Sequence[Any] = ()):
        ids=tuple(map(str,receipt_ids))
        if len(ids)!=len(set(ids)): raise AuxError("duplicate receipt ids in external index")
        self.ids=set(ids); self.maps=[dict(m) for m in _sm_maps(ids)]
    @property
    def root(self) -> str:
        return self.maps[0].get(0,_SM_EMPTY_HASHES[0]).hex()
    def proof(self, receipt_id: Any) -> Dict[str, Any]:
        rid=str(receipt_id); key=_receipt_id_key(rid); key_int=int.from_bytes(key,"big"); siblings=[]
        for depth in range(256,0,-1):
            idx=key_int >> (256-depth); siblings.append(self.maps[depth].get(idx^1,_SM_EMPTY_HASHES[depth]).hex())
        return {"receipt_id":rid,"key_sha256":key.hex(),"present":rid in self.ids,"siblings":tuple(siblings),"root":self.root,"proof_depth":256,"hash":"SHA-256","semantics":"external exact index witness; checkpoint stores only authenticated root"}
    def insert(self, receipt_id: Any) -> Dict[str, Any]:
        rid=str(receipt_id); proof=self.proof(rid)
        if rid in self.ids: return {"status":"DUPLICATE_STREAM_RECEIPT_ID","inserted":False,"proof":proof}
        before=self.root; key=_receipt_id_key(rid); idx=int.from_bytes(key,"big"); self.maps[256][idx]=_sm_present_leaf(key)
        child_idx=idx
        for depth in range(255,-1,-1):
            parent=child_idx>>1; child=self.maps[depth+1]
            left=child.get(parent<<1,_SM_EMPTY_HASHES[depth+1]); right=child.get((parent<<1)|1,_SM_EMPTY_HASHES[depth+1])
            self.maps[depth][parent]=_sm_node(left,right); child_idx=parent
        self.ids.add(rid)
        return {"status":"RECEIPT_ID_INSERTED_IN_EXTERNAL_INDEX","inserted":True,"receipt_id":rid,"root_before":before,"root_after":self.root,"proof":proof}


def sparse_receipt_id_proof(receipt_ids: Sequence[Any], receipt_id: Any) -> Dict[str, Any]:
    ids=tuple(map(str,receipt_ids)); rid=str(receipt_id); key=_receipt_id_key(rid); key_int=int.from_bytes(key,"big")
    maps=_sm_maps(ids); present=rid in set(ids)
    siblings=[]
    for depth in range(256,0,-1):
        idx=key_int >> (256-depth)
        siblings.append(maps[depth].get(idx^1,_SM_EMPTY_HASHES[depth]).hex())
    return {
        "receipt_id":rid,
        "key_sha256":key.hex(),
        "present":present,
        "siblings":tuple(siblings),
        "root":maps[0].get(0,_SM_EMPTY_HASHES[0]).hex(),
        "proof_depth":256,
        "hash":"SHA-256",
        "semantics":"computationally binding authenticated sparse-Merkle proof; not information-theoretic standalone memory",
    }


def verify_sparse_receipt_id_proof(root: Any, receipt_id: Any, proof: Dict[str, Any], *, expected_present: bool | None = None) -> Dict[str, Any]:
    try:
        root_s=str(root); rid=str(receipt_id)
        if not _hex64(root_s): raise AuxError("invalid sparse Merkle root")
        if str(proof.get("receipt_id","")) != rid: raise AuxError("proof receipt_id mismatch")
        key=_receipt_id_key(rid)
        if str(proof.get("key_sha256","")) != key.hex(): raise AuxError("proof key mismatch")
        present=bool(proof.get("present",False))
        if expected_present is not None and present != bool(expected_present): raise AuxError("proof presence polarity mismatch")
        siblings=tuple(proof.get("siblings") or ())
        if len(siblings)!=256: raise AuxError("sparse Merkle proof must contain 256 sibling hashes")
        sib_bytes=[]
        for x in siblings:
            if not _hex64(x): raise AuxError("invalid sibling hash")
            sib_bytes.append(bytes.fromhex(str(x)))
        cur=_sm_present_leaf(key) if present else _SM_EMPTY_HASHES[256]
        key_int=int.from_bytes(key,"big")
        for j,depth in enumerate(range(256,0,-1)):
            idx=key_int >> (256-depth); sib=sib_bytes[j]
            cur=_sm_node(sib,cur) if (idx&1) else _sm_node(cur,sib)
        valid=cur.hex()==root_s
        return {"status":"RECEIPT_ID_PROOF_VALID" if valid else "RECEIPT_ID_PROOF_ROOT_MISMATCH","proof_valid":valid,"present":present,"receipt_id":rid,"root":root_s,"truth_credit":0}
    except Exception as exc:
        return {"status":"INVALID_RECEIPT_ID_PROOF","proof_valid":False,"error":str(exc),"truth_credit":0}


def sparse_receipt_id_insert(root: Any, receipt_id: Any, nonmembership_proof: Dict[str, Any]) -> Dict[str, Any]:
    v=verify_sparse_receipt_id_proof(root,receipt_id,nonmembership_proof,expected_present=False)
    if not v.get("proof_valid",False):
        return {"status":"NONMEMBERSHIP_PROOF_REJECTED","updated":False,"validation":v}
    rid=str(receipt_id); key=_receipt_id_key(rid); key_int=int.from_bytes(key,"big")
    siblings=[bytes.fromhex(str(x)) for x in nonmembership_proof.get("siblings") or ()]
    cur=_sm_present_leaf(key)
    for j,depth in enumerate(range(256,0,-1)):
        idx=key_int >> (256-depth); sib=siblings[j]
        cur=_sm_node(sib,cur) if (idx&1) else _sm_node(cur,sib)
    return {"status":"RECEIPT_ID_INSERT_ROOT_UPDATED","updated":True,"receipt_id":rid,"previous_root":str(root),"new_root":cur.hex(),"truth_credit":0}


def _membership_bundle_commitment(items: Sequence[Dict[str, Any]]) -> str:
    h=hashlib.sha256(); h.update(_RECEIPT_ID_PROOF_BUNDLE_DOMAIN); h.update(_canonical_for_hash(tuple(items))); return h.hexdigest()


def _history_acc_seed(domain: bytes) -> str:
    h=hashlib.sha256(); h.update(domain); h.update(b"EMPTY\n"); return h.hexdigest()


def _history_acc_step(domain: bytes, previous: str, item: Any) -> str:
    if not _hex64(previous): raise AuxError("invalid history accumulator")
    h=hashlib.sha256(); h.update(domain); h.update(b"STEP\n"); h.update(bytes.fromhex(previous)); h.update(_canonical_for_hash(item)); return h.hexdigest()


def _fold_history_acc(domain: bytes, items: Sequence[Any]) -> str:
    a=_history_acc_seed(domain)
    for item in items: a=_history_acc_step(domain,a,item)
    return a


def _witnessed_checkpoint_hash_body(body: Dict[str, Any]) -> str:
    h=hashlib.sha256(); h.update(_WITNESSED_CHECKPOINT_DOMAIN); h.update(_canonical_for_hash(body)); return h.hexdigest()


def _semantic_resume_without_membership(checkpoint: Dict[str, Any], suffix: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    prefix=int(checkpoint["prefix_length"])
    requirements=copy.deepcopy(checkpoint.get("requirements") or {})
    latest=copy.deepcopy(checkpoint.get("latest_slot_snapshot") or {})
    frozen=copy.deepcopy(checkpoint.get("first_terminal_snapshot"))
    first_terminal=checkpoint.get("first_terminal_prefix")
    first_terminal_hash=checkpoint.get("first_terminal_stream_hash")
    chain=str(checkpoint["prefix_stream_hash"])
    reg_count=int(checkpoint.get("post_terminal_regression_count",0))
    reg_seen=bool(checkpoint.get("post_terminal_regression_seen",False))
    reg_acc=str(checkpoint.get("post_terminal_regression_accumulator") or _history_acc_seed(_REGRESSION_ACC_DOMAIN))
    conf_count=int(checkpoint.get("post_terminal_semantic_conflict_count",0))
    conf_seen=bool(checkpoint.get("post_terminal_semantic_conflict_seen",False))
    conf_acc=str(checkpoint.get("post_terminal_conflict_accumulator") or _history_acc_seed(_CONFLICT_ACC_DOMAIN))
    suffix_history=[]
    for j,e in enumerate(suffix,1):
        seq=prefix+j
        if e.get("sequence") is not None and int(e.get("sequence"))!=seq:
            return {"status":"INVALID_STREAM_SEQUENCE","position":seq,"declared_sequence":e.get("sequence")}
        if not str(e.get("slot","")): return {"status":"INVALID_STREAM_SLOT","receipt_id":str(e.get("receipt_id",""))}
        chain=_stream_hash_step(chain,e)
        c=_certify_stream_entry(e); slot=str(e["slot"])
        latest[slot]={"receipt_id":str(e["receipt_id"]),"kind":c["kind"],"certified":c["certified"],"certificate":c["certificate"]}
        snap=_evaluate_stream_snapshot(latest,requirements)
        if first_terminal is None and snap.get("terminal",False):
            first_terminal=seq; first_terminal_hash=chain; frozen=copy.deepcopy(latest)
        if first_terminal is not None and seq>int(first_terminal) and not snap.get("terminal",False):
            reg_seen=True; reg_count+=1; reg_acc=_history_acc_step(_REGRESSION_ACC_DOMAIN,reg_acc,{"prefix":seq,"receipt_id":str(e["receipt_id"])})
        if first_terminal is not None and seq>int(first_terminal):
            z=_conflict_event_for_receipt(e,latest,frozen)
            if z is not None:
                conf_seen=True; conf_count+=1; conf_acc=_history_acc_step(_CONFLICT_ACC_DOMAIN,conf_acc,z)
        suffix_history.append({"prefix_length":seq,"receipt_id":str(e["receipt_id"]),"stream_hash":chain,"terminal_now":bool(snap.get("terminal",False)),"route_status":snap.get("route",{}).get("status")})
    current=_evaluate_stream_snapshot(latest,requirements)
    historical=first_terminal is not None
    current_conflict=_semantic_conflict_against_frozen(frozen,latest) if historical else False
    regressed=bool(historical and not current.get("terminal",False))
    total=prefix+len(suffix); post_count=max(0,total-int(first_terminal)) if historical else 0
    if not historical: status="NO_TERMINAL_PREFIX"
    elif regressed or current_conflict: status="FIRST_TERMINAL_PREFIX_FROZEN__POST_TERMINAL_CONFLICT"
    elif post_count: status="FIRST_TERMINAL_PREFIX_FROZEN__POST_TERMINAL_RECEIPTS_PRESENT"
    else: status="FIRST_TERMINAL_PREFIX_FROZEN"
    return {
        "status":status,"receipt_count":total,"historical_terminal":historical,"current_terminal":bool(current.get("terminal",False)),
        "first_terminal_prefix":first_terminal,"first_terminal_stream_hash":first_terminal_hash,"final_stream_hash":chain,
        "stop_policy":f"STOP_AT_PREFIX_{first_terminal}" if historical else "CONTINUE_ACQUISITION",
        "post_terminal_receipt_count":post_count,"current_prefix_regressed":regressed,"post_terminal_semantic_conflict":current_conflict,
        "post_terminal_regression_seen":reg_seen,"post_terminal_regression_count":reg_count,"post_terminal_regression_accumulator":reg_acc,
        "post_terminal_semantic_conflict_seen":conf_seen,"post_terminal_semantic_conflict_count":conf_count,"post_terminal_conflict_accumulator":conf_acc,
        "first_terminal_snapshot":frozen,"latest_slot_snapshot":latest,"current_snapshot":current,"suffix_history":tuple(suffix_history),
    }


def _p6_history_accumulators(checkpoint: Dict[str, Any]) -> Tuple[str,str]:
    reg_items=tuple({"prefix":int(x)} for x in (checkpoint.get("post_terminal_regression_prefixes") or ()))
    conf_items=tuple(copy.deepcopy(checkpoint.get("post_terminal_conflicts") or ()))
    return _fold_history_acc(_REGRESSION_ACC_DOMAIN,reg_items), _fold_history_acc(_CONFLICT_ACC_DOMAIN,conf_items)


def validate_witnessed_checkpoint(checkpoint: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(checkpoint,dict) or checkpoint.get("schema")!=_WITNESSED_CHECKPOINT_SCHEMA:
        return {"status":"INVALID_WITNESSED_CHECKPOINT_SCHEMA","checkpoint_valid":False}
    supplied=str(checkpoint.get("checkpoint_hash","")); body={k:copy.deepcopy(v) for k,v in checkpoint.items() if k!="checkpoint_hash"}
    expected=_witnessed_checkpoint_hash_body(body)
    if supplied!=expected: return {"status":"WITNESSED_CHECKPOINT_HASH_MISMATCH","checkpoint_valid":False,"expected_checkpoint_hash":expected}
    try:
        prefix=int(checkpoint.get("prefix_length")); count=int(checkpoint.get("receipt_id_count"))
        if prefix<0 or int(checkpoint.get("next_sequence"))!=prefix+1: raise AuxError("sequence/prefix mismatch")
        if count!=prefix: raise AuxError("receipt-id authenticated count must equal prefix length")
        if "seen_receipt_ids" in checkpoint: raise AuxError("witnessed checkpoint must not retain seen_receipt_ids")
        if not _hex64(checkpoint.get("receipt_id_root")) or not _hex64(checkpoint.get("receipt_id_root_before_rotation")): raise AuxError("invalid receipt-id root")
        if checkpoint.get("receipt_id_membership_mode")!="SPARSE_MERKLE_256_SHA256_EXTERNAL_WITNESS_V1": raise AuxError("invalid receipt-id membership mode")
        if not _hex64(checkpoint.get("receipt_id_proof_bundle_commitment")): raise AuxError("invalid receipt-id proof-bundle commitment")
        if not _hex64(checkpoint.get("prefix_stream_hash")): raise AuxError("invalid stream hash")
        latest=checkpoint.get("latest_slot_snapshot") or {}; req=checkpoint.get("requirements") or {}
        current=_evaluate_stream_snapshot(latest,req)
        if bool(current.get("terminal"))!=bool(checkpoint.get("current_terminal_at_checkpoint")): raise AuxError("current terminal snapshot mismatch")
        hist=bool(checkpoint.get("historical_terminal",False)); ftp=checkpoint.get("first_terminal_prefix")
        if hist:
            if ftp is None or not (1<=int(ftp)<=prefix): raise AuxError("invalid first terminal prefix")
            if not _hex64(checkpoint.get("first_terminal_stream_hash")): raise AuxError("invalid first terminal hash")
            if not _evaluate_stream_snapshot(checkpoint.get("first_terminal_snapshot") or {},req).get("terminal",False): raise AuxError("frozen first-terminal snapshot is not terminal")
        elif ftp is not None: raise AuxError("nonterminal checkpoint declares first terminal")
        for field in ("post_terminal_regression_accumulator","post_terminal_conflict_accumulator"):
            if not _hex64(checkpoint.get(field)): raise AuxError(f"invalid {field}")
        window=int(checkpoint.get("lineage_anchor_window_size",0)); cc=int(checkpoint.get("lineage_compacted_count",-1)); ec=int(checkpoint.get("lineage_entry_count",-1)); anchors=tuple(checkpoint.get("lineage_anchors") or ())
        if window<1 or window>_MAX_LINEAGE_ANCHOR_WINDOW or cc<0 or cc+len(anchors)!=ec or ec!=int(checkpoint.get("rotation_index",-1)): raise AuxError("bounded lineage count/window mismatch")
        pa=str(checkpoint.get("lineage_prefix_accumulator","")); la=str(checkpoint.get("lineage_accumulator",""))
        if not _hex64(pa) or not _hex64(la) or _fold_lineage_accumulator(anchors,pa)!=la: raise AuxError("lineage accumulator mismatch")
        if not _hex64(checkpoint.get("previous_checkpoint_hash")) or not _hex64(checkpoint.get("checkpoint_chain_root_hash")): raise AuxError("invalid checkpoint lineage hashes")
        if not _hex64(checkpoint.get("rotation_history_commitment")) or not _hex64(checkpoint.get("prefix_history_commitment")): raise AuxError("invalid history commitments")
        if int(checkpoint.get("rotation_suffix_receipt_count",-1))<1: raise AuxError("witnessed rotation suffix must be nonempty")
        if int(checkpoint.get("truth_credit",-1))!=0 or checkpoint.get("root_write_capability")!="NONE" or checkpoint.get("return_write_capability")!="NONE" or checkpoint.get("solver_mutation_capability")!="NONE": raise AuxError("authority firewall violation")
    except Exception as exc:
        return {"status":"WITNESSED_CHECKPOINT_SEMANTIC_VALIDATION_FAILED","checkpoint_valid":False,"error":str(exc)}
    return {"status":"WITNESSED_STREAM_CHECKPOINT_VALID","checkpoint_valid":True,"checkpoint_hash":supplied,"receipt_id_root":checkpoint.get("receipt_id_root"),"receipt_id_count":checkpoint.get("receipt_id_count")}


def _validated_checkpoint_any_pass007(checkpoint: Dict[str, Any]) -> Dict[str, Any]:
    if checkpoint.get("schema")==_WITNESSED_CHECKPOINT_SCHEMA: return validate_witnessed_checkpoint(checkpoint)
    return _validated_checkpoint_any(checkpoint)


def rotate_witnessed_checkpoint(payload: Dict[str, Any]) -> Dict[str, Any]:
    previous=payload.get("checkpoint") or {}; valid=_validated_checkpoint_any_pass007(previous)
    if not valid.get("checkpoint_valid",False): return {"status":"INVALID_STREAM_CHECKPOINT","checkpoint_valid":False,"validation":valid}
    suffix=list(payload.get("receipts") or ())
    if not suffix: return {"status":"EMPTY_ROTATION_SUFFIX","checkpoint_valid":True,"rotated":False}
    for j,e in enumerate(suffix,1):
        if not str(e.get("receipt_id","")): return {"status":"INVALID_STREAM_RECEIPT_ID","checkpoint_valid":True,"position":int(previous.get("prefix_length",0))+j}
    requested_window=payload.get("anchor_window_size")
    if previous.get("schema") in {_BOUNDED_CHECKPOINT_SCHEMA,_WITNESSED_CHECKPOINT_SCHEMA}:
        window=int(previous.get("lineage_anchor_window_size"))
        if requested_window is not None and int(requested_window)!=window: return {"status":"LINEAGE_ANCHOR_WINDOW_IMMUTABLE","checkpoint_valid":True,"rotated":False,"anchor_window_size":window}
    else: window=int(requested_window or _DEFAULT_LINEAGE_ANCHOR_WINDOW)
    if window<1 or window>_MAX_LINEAGE_ANCHOR_WINDOW: return {"status":"INVALID_LINEAGE_ANCHOR_WINDOW","checkpoint_valid":True,"rotated":False}

    migration=previous.get("schema")!=_WITNESSED_CHECKPOINT_SCHEMA
    proof_records=[]
    if migration:
        ids=tuple(map(str,previous.get("seen_receipt_ids") or ()))
        if len(ids)!=int(previous.get("prefix_length",-1)) or len(set(ids))!=len(ids): return {"status":"MIGRATION_SOURCE_RECEIPT_ID_SET_INVALID","rotated":False}
        root_before=sparse_receipt_id_root(ids); root_after=sparse_receipt_id_root(ids+tuple(str(e["receipt_id"]) for e in suffix))
        # Existing exact set performs the migration duplicate check without external witnesses.
        seen=set(ids)
        for e in suffix:
            rid=str(e["receipt_id"])
            if rid in seen: return {"status":"DUPLICATE_STREAM_RECEIPT_ID","rotated":False,"duplicate_receipt_id":rid}
            seen.add(rid); proof_records.append({"receipt_id":rid,"migration_exact_set_check":True})
        resumed=_resume_checkpoint_any(previous,suffix)
        if not resumed.get("final_stream_hash"): return {"status":"ROTATION_RESUME_FAILED","rotated":False,"resume":resumed}
        reg_acc,conf_acc=_p6_history_accumulators(previous)
        # normalize historical accumulators from the resumed output using parent history + new events
        semantic=_semantic_resume_without_membership({**previous,"post_terminal_regression_accumulator":reg_acc,"post_terminal_conflict_accumulator":conf_acc,"post_terminal_semantic_conflict_seen":bool(previous.get("post_terminal_semantic_conflict_seen",False))},suffix)
    else:
        root_before=str(previous.get("receipt_id_root")); root=root_before
        witnesses=list(payload.get("receipt_id_witnesses") or ())
        if len(witnesses)!=len(suffix): return {"status":"RECEIPT_ID_NONMEMBERSHIP_WITNESSES_REQUIRED","rotated":False,"required":len(suffix),"provided":len(witnesses)}
        for e,proof in zip(suffix,witnesses):
            rid=str(e["receipt_id"])
            v=verify_sparse_receipt_id_proof(root,rid,proof,expected_present=False)
            if not v.get("proof_valid",False): return {"status":"RECEIPT_ID_NONMEMBERSHIP_PROOF_REJECTED","rotated":False,"receipt_id":rid,"validation":v}
            upd=sparse_receipt_id_insert(root,rid,proof)
            if not upd.get("updated",False): return {"status":"RECEIPT_ID_ROOT_UPDATE_FAILED","rotated":False,"receipt_id":rid,"update":upd}
            proof_records.append({"receipt_id":rid,"root_before":root,"proof":copy.deepcopy(proof),"root_after":upd["new_root"]}); root=upd["new_root"]
        root_after=root
        semantic=_semantic_resume_without_membership(previous,suffix)
        if not semantic.get("final_stream_hash"): return {"status":"ROTATION_RESUME_FAILED","rotated":False,"resume":semantic}

    if migration:
        # semantic result is authoritative for compact history accumulators; exact parent resume was used only as cross-check.
        if semantic.get("final_stream_hash") != resumed.get("final_stream_hash"): return {"status":"MIGRATION_SEMANTIC_CROSSCHECK_FAILED","rotated":False}
    try:
        state=_bounded_lineage_state(previous,window) if previous.get("schema")!=_WITNESSED_CHECKPOINT_SCHEMA else {
            "lineage_entry_count":int(previous.get("lineage_entry_count",0)),"lineage_compacted_count":int(previous.get("lineage_compacted_count",0)),"lineage_prefix_accumulator":str(previous.get("lineage_prefix_accumulator")),"lineage_anchors":tuple(copy.deepcopy(previous.get("lineage_anchors") or ())),"lineage_accumulator":str(previous.get("lineage_accumulator")),"lineage_anchor_window_size":window}
        state=_bounded_lineage_append(state,_checkpoint_lineage_entry(previous))
    except Exception as exc: return {"status":"BOUNDED_LINEAGE_CONSTRUCTION_FAILED","rotated":False,"error":str(exc)}
    rotation_index=int(previous.get("rotation_index",0))+1
    if int(state["lineage_entry_count"])!=rotation_index: return {"status":"BOUNDED_LINEAGE_DEPTH_MISMATCH","rotated":False}
    suffix_hist=tuple(semantic.get("suffix_history") or ()); suffix_commitment=_suffix_history_commitment(suffix_hist)
    previous_prefix_history=str(previous.get("prefix_history_commitment",""))
    if not _hex64(previous_prefix_history): return {"status":"INVALID_PREVIOUS_PREFIX_HISTORY_COMMITMENT","rotated":False}
    prefix_history_commitment=_chained_prefix_history_commitment(previous_prefix_history,suffix_commitment)
    previous_rotation=_checkpoint_rotation_commitment(previous); rotation_commitment=_rotation_history_commitment(previous_rotation,str(previous["checkpoint_hash"]),suffix_commitment,str(semantic["final_stream_hash"]))
    root_hash=str(previous.get("checkpoint_chain_root_hash") or previous.get("checkpoint_hash"))
    proof_commitment=_membership_bundle_commitment(proof_records)
    body={
        "schema":_WITNESSED_CHECKPOINT_SCHEMA,"aux_name":AUX_NAME,"aux_version":AUX_VERSION,"stream_id":previous.get("stream_id"),"requirements":copy.deepcopy(previous.get("requirements") or {}),
        "prefix_length":int(semantic["receipt_count"]),"next_sequence":int(semantic["receipt_count"])+1,"prefix_stream_hash":str(semantic["final_stream_hash"]),
        "receipt_id_membership_mode":"SPARSE_MERKLE_256_SHA256_EXTERNAL_WITNESS_V1","receipt_id_root_before_rotation":root_before,"receipt_id_root":root_after,"receipt_id_count":int(semantic["receipt_count"]),"receipt_id_external_index_required":True,"receipt_id_proof_bundle_commitment":proof_commitment,
        "latest_slot_snapshot":copy.deepcopy(semantic.get("latest_slot_snapshot") or {}),"historical_terminal":bool(semantic.get("historical_terminal",False)),"current_terminal_at_checkpoint":bool(semantic.get("current_terminal",False)),"first_terminal_prefix":semantic.get("first_terminal_prefix"),"first_terminal_stream_hash":semantic.get("first_terminal_stream_hash"),"first_terminal_snapshot":copy.deepcopy(semantic.get("first_terminal_snapshot")),"stop_policy":semantic.get("stop_policy"),
        "post_terminal_regression_seen":bool(semantic.get("post_terminal_regression_seen",False)),"post_terminal_regression_count":int(semantic.get("post_terminal_regression_count",0)),"post_terminal_regression_accumulator":str(semantic.get("post_terminal_regression_accumulator") or _history_acc_seed(_REGRESSION_ACC_DOMAIN)),
        "post_terminal_semantic_conflict_seen":bool(semantic.get("post_terminal_semantic_conflict_seen",False)),"post_terminal_semantic_conflict_count":int(semantic.get("post_terminal_semantic_conflict_count",0)),"post_terminal_conflict_accumulator":str(semantic.get("post_terminal_conflict_accumulator") or _history_acc_seed(_CONFLICT_ACC_DOMAIN)),
        "prefix_history_commitment":prefix_history_commitment,"previous_prefix_history_commitment":previous_prefix_history,"prefix_history_commitment_mode":"CHAINED_CHECKPOINT_HISTORY_V1","rotation_index":rotation_index,"previous_checkpoint_hash":str(previous["checkpoint_hash"]),"checkpoint_chain_root_hash":root_hash,
        "checkpoint_lineage_mode":"BOUNDED_ACCUMULATOR_ANCHORS_V1","lineage_entry_count":int(state["lineage_entry_count"]),"lineage_compacted_count":int(state["lineage_compacted_count"]),"lineage_prefix_accumulator":str(state["lineage_prefix_accumulator"]),"lineage_anchors":tuple(copy.deepcopy(state["lineage_anchors"])),"lineage_accumulator":str(state["lineage_accumulator"]),"lineage_anchor_window_size":int(state["lineage_anchor_window_size"]),
        "rotation_suffix_receipt_count":len(suffix),"rotation_suffix_history_commitment":suffix_commitment,"previous_rotation_history_commitment":previous_rotation,"rotation_history_commitment":rotation_commitment,
        "truth_credit":0,"root_write_capability":"NONE","return_write_capability":"NONE","solver_mutation_capability":"NONE",
        "archive_requirement":"active checkpoint drops exact historical receipt-id list; exact duplicate rejection now requires an external authenticated index supplying non-membership proofs bound to the current receipt_id_root; archived witness packets are required for independent transition audit",
        "cryptographic_assumption":"SHA-256 collision/preimage resistance; this is computational authentication, not information-theoretic fixed-memory exactness",
    }
    checkpoint=dict(body); checkpoint["checkpoint_hash"]=_witnessed_checkpoint_hash_body(body)
    return {"status":"WITNESSED_STREAM_CHECKPOINT_ROTATED","checkpoint_valid":True,"rotated":True,"migration_from_exact_id_set":migration,"checkpoint":checkpoint,"receipt_id_root_before_rotation":root_before,"receipt_id_root":root_after,"receipt_id_proof_bundle_commitment":proof_commitment,"proof_packet":tuple(proof_records),"checkpoint_canonical_bytes":len(_canonical_for_hash(checkpoint)),"truth_credit":0}


def validate_witnessed_checkpoint_transition(payload: Dict[str, Any]) -> Dict[str, Any]:
    previous=payload.get("previous_checkpoint") or {}; current=payload.get("current_checkpoint") or {}; packet=tuple(payload.get("proof_packet") or ())
    pv=_validated_checkpoint_any_pass007(previous); cv=validate_witnessed_checkpoint(current)
    if not pv.get("checkpoint_valid",False): return {"status":"INVALID_PREVIOUS_CHECKPOINT","transition_valid":False,"validation":pv}
    if not cv.get("checkpoint_valid",False): return {"status":"INVALID_CURRENT_WITNESSED_CHECKPOINT","transition_valid":False,"validation":cv}
    try:
        if str(current.get("previous_checkpoint_hash"))!=str(previous.get("checkpoint_hash")): raise AuxError("previous checkpoint hash mismatch")
        if int(current.get("rotation_index"))!=int(previous.get("rotation_index",0))+1: raise AuxError("rotation index mismatch")
        if int(current.get("prefix_length"))<=int(previous.get("prefix_length")): raise AuxError("prefix did not increase")
        if _membership_bundle_commitment(packet)!=str(current.get("receipt_id_proof_bundle_commitment")): raise AuxError("proof packet commitment mismatch")
        migration=previous.get("schema")!=_WITNESSED_CHECKPOINT_SCHEMA
        if migration:
            ids=tuple(map(str,previous.get("seen_receipt_ids") or ())); root=sparse_receipt_id_root(ids)
            if root!=str(current.get("receipt_id_root_before_rotation")): raise AuxError("migration root-before mismatch")
            new_ids=[]
            for rec in packet:
                rid=str(rec.get("receipt_id",""));
                if not rec.get("migration_exact_set_check",False): raise AuxError("migration proof packet marker missing")
                if rid in set(ids) or rid in set(new_ids): raise AuxError("migration duplicate receipt id")
                new_ids.append(rid)
            root_after=sparse_receipt_id_root(ids+tuple(new_ids))
        else:
            root=str(previous.get("receipt_id_root"))
            if root!=str(current.get("receipt_id_root_before_rotation")): raise AuxError("root-before mismatch")
            for rec in packet:
                rid=str(rec.get("receipt_id","")); proof=rec.get("proof") or {}
                if str(rec.get("root_before"))!=root: raise AuxError("proof packet root-before chain mismatch")
                v=verify_sparse_receipt_id_proof(root,rid,proof,expected_present=False)
                if not v.get("proof_valid",False): raise AuxError("invalid nonmembership proof in packet")
                upd=sparse_receipt_id_insert(root,rid,proof); root=upd["new_root"]
                if str(rec.get("root_after"))!=root: raise AuxError("proof packet root-after mismatch")
            root_after=root
        if root_after!=str(current.get("receipt_id_root")): raise AuxError("receipt-id root transition mismatch")
        if int(current.get("receipt_id_count")) != int(previous.get("prefix_length"))+len(packet): raise AuxError("receipt-id count transition mismatch")
        expected=_expected_bounded_child_lineage(previous,current)
        for f in ("lineage_entry_count","lineage_compacted_count","lineage_prefix_accumulator","lineage_accumulator","lineage_anchor_window_size"):
            if current.get(f)!=expected.get(f): raise AuxError(f"bounded lineage mismatch: {f}")
        if _canonical_for_hash(current.get("lineage_anchors") or ())!=_canonical_for_hash(expected.get("lineage_anchors") or ()): raise AuxError("bounded lineage anchors mismatch")
    except Exception as exc:
        return {"status":"WITNESSED_CHECKPOINT_TRANSITION_INVALID","transition_valid":False,"error":str(exc)}
    return {"status":"WITNESSED_CHECKPOINT_TRANSITION_VALID","transition_valid":True,"receipt_id_root":current.get("receipt_id_root"),"receipt_id_count":current.get("receipt_id_count"),"truth_credit":0}



# ---------------------------------------------------------------------------
# PASS008 durable exact receipt-ID sidecar layer
# ---------------------------------------------------------------------------

_SIDECAR_SNAPSHOT_SCHEMA = "HYPERTRIANGLE_RECEIPT_ID_SIDECAR_SNAPSHOT_V1"
_SIDECAR_JOURNAL_SCHEMA = "HYPERTRIANGLE_RECEIPT_ID_SIDECAR_JOURNAL_ENTRY_V1"
_SIDECAR_SNAPSHOT_DOMAIN = b"HYPERTRIANGLE_RECEIPT_ID_SIDECAR_SNAPSHOT_V1\n"
_SIDECAR_JOURNAL_SEED_DOMAIN = b"HYPERTRIANGLE_RECEIPT_ID_SIDECAR_JOURNAL_SEED_V1\n"
_SIDECAR_JOURNAL_ENTRY_DOMAIN = b"HYPERTRIANGLE_RECEIPT_ID_SIDECAR_JOURNAL_ENTRY_V1\n"


def _sidecar_snapshot_hash_body(body: Dict[str, Any]) -> str:
    h=hashlib.sha256(); h.update(_SIDECAR_SNAPSHOT_DOMAIN); h.update(_canonical_for_hash(body)); return h.hexdigest()


def _sidecar_journal_seed(snapshot_hash: str) -> str:
    if not _hex64(snapshot_hash): raise AuxError("invalid sidecar snapshot hash")
    h=hashlib.sha256(); h.update(_SIDECAR_JOURNAL_SEED_DOMAIN); h.update(bytes.fromhex(snapshot_hash)); return h.hexdigest()


def _sidecar_journal_hash_body(body: Dict[str, Any]) -> str:
    h=hashlib.sha256(); h.update(_SIDECAR_JOURNAL_ENTRY_DOMAIN); h.update(_canonical_for_hash(body)); return h.hexdigest()


def receipt_id_sidecar_snapshot(payload: Dict[str, Any]) -> Dict[str, Any]:
    try:
        ids=tuple(map(str,payload.get("receipt_ids") or ()))
        if any(not x for x in ids): raise AuxError("empty receipt_id not allowed")
        if len(ids)!=len(set(ids)): raise AuxError("duplicate receipt ids in sidecar snapshot")
        ids=tuple(sorted(ids))
        generation=int(payload.get("generation",0))
        if generation<0: raise AuxError("generation must be nonnegative")
        parent_snapshot_hash=payload.get("parent_snapshot_hash")
        compacted_journal_tail_hash=payload.get("compacted_journal_tail_hash")
        if parent_snapshot_hash is not None and not _hex64(parent_snapshot_hash): raise AuxError("invalid parent snapshot hash")
        if compacted_journal_tail_hash is not None and not _hex64(compacted_journal_tail_hash): raise AuxError("invalid compacted journal tail hash")
        root=sparse_receipt_id_root(ids)
        body={
            "schema":_SIDECAR_SNAPSHOT_SCHEMA,
            "aux_name":AUX_NAME,
            "aux_version":AUX_VERSION,
            "generation":generation,
            "receipt_id_count":len(ids),
            "receipt_id_root":root,
            "receipt_ids":ids,
            "parent_snapshot_hash":parent_snapshot_hash,
            "compacted_journal_tail_hash":compacted_journal_tail_hash,
            "membership_mode":"SPARSE_MERKLE_256_SHA256_EXACT_SIDECAR_V1",
            "truth_credit":0,
            "root_write_capability":"NONE",
            "return_write_capability":"NONE",
            "solver_mutation_capability":"NONE",
        }
        out=dict(body); out["snapshot_hash"]=_sidecar_snapshot_hash_body(body)
        out["journal_seed_hash"]=_sidecar_journal_seed(out["snapshot_hash"])
        return {"status":"RECEIPT_ID_SIDECAR_SNAPSHOT_CREATED","snapshot_valid":True,"snapshot":out,"receipt_id_root":root,"receipt_id_count":len(ids),"truth_credit":0}
    except Exception as exc:
        return {"status":"RECEIPT_ID_SIDECAR_SNAPSHOT_REJECTED","snapshot_valid":False,"error":str(exc),"truth_credit":0}


def validate_receipt_id_sidecar_snapshot(snapshot: Dict[str, Any]) -> Dict[str, Any]:
    try:
        if not isinstance(snapshot,dict) or snapshot.get("schema")!=_SIDECAR_SNAPSHOT_SCHEMA: raise AuxError("invalid sidecar snapshot schema")
        supplied=str(snapshot.get("snapshot_hash","")); seed=str(snapshot.get("journal_seed_hash",""))
        body={k:copy.deepcopy(v) for k,v in snapshot.items() if k not in {"snapshot_hash","journal_seed_hash"}}
        expected=_sidecar_snapshot_hash_body(body)
        if supplied!=expected: raise AuxError("sidecar snapshot hash mismatch")
        if seed!=_sidecar_journal_seed(supplied): raise AuxError("sidecar journal seed mismatch")
        ids=tuple(map(str,snapshot.get("receipt_ids") or ()))
        if ids!=tuple(sorted(ids)) or len(ids)!=len(set(ids)) or any(not x for x in ids): raise AuxError("receipt_ids must be unique, nonempty, and sorted")
        if int(snapshot.get("receipt_id_count",-1))!=len(ids): raise AuxError("sidecar receipt-id count mismatch")
        root=sparse_receipt_id_root(ids)
        if str(snapshot.get("receipt_id_root",""))!=root: raise AuxError("sidecar receipt-id root mismatch")
        if int(snapshot.get("generation",-1))<0: raise AuxError("invalid sidecar generation")
        if snapshot.get("membership_mode")!="SPARSE_MERKLE_256_SHA256_EXACT_SIDECAR_V1": raise AuxError("invalid sidecar membership mode")
        for f in ("parent_snapshot_hash","compacted_journal_tail_hash"):
            v=snapshot.get(f)
            if v is not None and not _hex64(v): raise AuxError(f"invalid {f}")
        if int(snapshot.get("truth_credit",-1))!=0 or snapshot.get("root_write_capability")!="NONE" or snapshot.get("return_write_capability")!="NONE" or snapshot.get("solver_mutation_capability")!="NONE": raise AuxError("authority firewall violation")
        return {"status":"RECEIPT_ID_SIDECAR_SNAPSHOT_VALID","snapshot_valid":True,"snapshot_hash":supplied,"journal_seed_hash":seed,"receipt_id_root":root,"receipt_id_count":len(ids),"generation":int(snapshot["generation"]),"truth_credit":0}
    except Exception as exc:
        return {"status":"INVALID_RECEIPT_ID_SIDECAR_SNAPSHOT","snapshot_valid":False,"error":str(exc),"truth_credit":0}


def _recover_receipt_id_sidecar_internal(snapshot: Dict[str, Any], journal_records: Sequence[Dict[str, Any]]) -> Dict[str, Any]:
    sv=validate_receipt_id_sidecar_snapshot(snapshot)
    if not sv.get("snapshot_valid",False): return {"status":"INVALID_RECEIPT_ID_SIDECAR_SNAPSHOT","recovered":False,"snapshot_validation":sv,"truth_credit":0}
    ids=list(map(str,snapshot.get("receipt_ids") or ()))
    idx=ExternalReceiptIdIndex(ids)
    current_root=idx.root
    expected_sequence=len(ids)+1
    previous_journal_hash=str(snapshot["journal_seed_hash"])
    accepted=[]
    for offset,record in enumerate(journal_records):
        try:
            if not isinstance(record,dict) or record.get("schema")!=_SIDECAR_JOURNAL_SCHEMA: raise AuxError("invalid sidecar journal schema")
            supplied=str(record.get("journal_hash","")); body={k:copy.deepcopy(v) for k,v in record.items() if k!="journal_hash"}
            if supplied!=_sidecar_journal_hash_body(body): raise AuxError("sidecar journal hash mismatch")
            if int(record.get("sequence",-1))!=expected_sequence: raise AuxError("sidecar journal sequence mismatch")
            if int(record.get("generation",-1))!=int(snapshot.get("generation")): raise AuxError("sidecar journal generation mismatch")
            if str(record.get("previous_journal_hash",""))!=previous_journal_hash: raise AuxError("sidecar journal hash-chain mismatch")
            if str(record.get("root_before",""))!=current_root: raise AuxError("sidecar journal root-before mismatch")
            rid=str(record.get("receipt_id",""))
            if not rid: raise AuxError("empty sidecar journal receipt_id")
            proof=idx.proof(rid)
            if proof.get("present"): raise AuxError("duplicate receipt id in sidecar journal")
            ins=idx.insert(rid)
            if not ins.get("inserted",False): raise AuxError("sidecar journal insertion failed")
            if str(record.get("root_after",""))!=idx.root: raise AuxError("sidecar journal root-after mismatch")
            current_root=idx.root; previous_journal_hash=supplied; expected_sequence+=1; accepted.append(copy.deepcopy(record))
        except Exception as exc:
            return {"status":"RECEIPT_ID_SIDECAR_JOURNAL_REJECTED","recovered":False,"rejected_record_index":offset,"accepted_record_count":len(accepted),"error":str(exc),"last_valid_root":current_root,"last_valid_journal_hash":previous_journal_hash,"truth_credit":0}
    return {"status":"RECEIPT_ID_SIDECAR_RECOVERED","recovered":True,"generation":int(snapshot["generation"]),"snapshot_hash":snapshot["snapshot_hash"],"receipt_ids":tuple(sorted(idx.ids)),"receipt_id_root":idx.root,"receipt_id_count":len(idx.ids),"journal_record_count":len(accepted),"journal_tail_hash":previous_journal_hash,"next_sequence":expected_sequence,"truth_credit":0}


def recover_receipt_id_sidecar(payload: Dict[str, Any]) -> Dict[str, Any]:
    return _recover_receipt_id_sidecar_internal(payload.get("snapshot") or {}, tuple(payload.get("journal_records") or ()))


def append_receipt_id_sidecar(payload: Dict[str, Any]) -> Dict[str, Any]:
    recovered=_recover_receipt_id_sidecar_internal(payload.get("snapshot") or {}, tuple(payload.get("journal_records") or ()))
    if not recovered.get("recovered",False): return {"status":"RECEIPT_ID_SIDECAR_APPEND_BLOCKED","appended":False,"recovery":recovered,"truth_credit":0}
    rid=str(payload.get("receipt_id",""))
    if not rid: return {"status":"INVALID_STREAM_RECEIPT_ID","appended":False,"truth_credit":0}
    ids=tuple(recovered["receipt_ids"]); idx=ExternalReceiptIdIndex(ids)
    proof=idx.proof(rid)
    if proof.get("present"): return {"status":"DUPLICATE_STREAM_RECEIPT_ID","appended":False,"receipt_id":rid,"proof":proof,"truth_credit":0}
    before=idx.root; ins=idx.insert(rid)
    if not ins.get("inserted",False): return {"status":"RECEIPT_ID_SIDECAR_APPEND_FAILED","appended":False,"receipt_id":rid,"truth_credit":0}
    body={
        "schema":_SIDECAR_JOURNAL_SCHEMA,
        "generation":int(recovered["generation"]),
        "sequence":int(recovered["next_sequence"]),
        "receipt_id":rid,
        "root_before":before,
        "root_after":idx.root,
        "previous_journal_hash":str(recovered["journal_tail_hash"]),
        "snapshot_hash":str(recovered["snapshot_hash"]),
    }
    record=dict(body); record["journal_hash"]=_sidecar_journal_hash_body(body)
    return {"status":"RECEIPT_ID_SIDECAR_JOURNAL_ENTRY_CREATED","appended":True,"journal_entry":record,"receipt_id_root":idx.root,"receipt_id_count":len(idx.ids),"membership_proof_before_insert":proof,"truth_credit":0}


def receipt_id_sidecar_proof(payload: Dict[str, Any]) -> Dict[str, Any]:
    recovered=_recover_receipt_id_sidecar_internal(payload.get("snapshot") or {}, tuple(payload.get("journal_records") or ()))
    if not recovered.get("recovered",False): return {"status":"RECEIPT_ID_SIDECAR_PROOF_BLOCKED","proof_valid":False,"recovery":recovered,"truth_credit":0}
    rid=str(payload.get("receipt_id","")); idx=ExternalReceiptIdIndex(recovered["receipt_ids"]); proof=idx.proof(rid)
    return {"status":"RECEIPT_ID_SIDECAR_PROOF_CREATED","proof_valid":True,"receipt_id":rid,"present":bool(proof["present"]),"receipt_id_root":idx.root,"proof":proof,"truth_credit":0}


def compact_receipt_id_sidecar(payload: Dict[str, Any]) -> Dict[str, Any]:
    snapshot=payload.get("snapshot") or {}; records=tuple(payload.get("journal_records") or ())
    recovered=_recover_receipt_id_sidecar_internal(snapshot,records)
    if not recovered.get("recovered",False): return {"status":"RECEIPT_ID_SIDECAR_COMPACTION_BLOCKED","compacted":False,"recovery":recovered,"truth_credit":0}
    created=receipt_id_sidecar_snapshot({
        "receipt_ids":recovered["receipt_ids"],
        "generation":int(snapshot.get("generation",0))+1,
        "parent_snapshot_hash":snapshot.get("snapshot_hash"),
        "compacted_journal_tail_hash":recovered.get("journal_tail_hash"),
    })
    if not created.get("snapshot_valid",False): return {"status":"RECEIPT_ID_SIDECAR_COMPACTION_FAILED","compacted":False,"snapshot_creation":created,"truth_credit":0}
    return {"status":"RECEIPT_ID_SIDECAR_COMPACTED","compacted":True,"snapshot":created["snapshot"],"receipt_id_root":recovered["receipt_id_root"],"receipt_id_count":recovered["receipt_id_count"],"compacted_journal_record_count":recovered["journal_record_count"],"truth_credit":0}


# ---------------------------------------------------------------------------
# PASS009 sidecar snapshot-chain + automatic compaction policy
# ---------------------------------------------------------------------------

_SIDECAR_CHAIN_STATE_SCHEMA = "HYPERTRIANGLE_RECEIPT_ID_SIDECAR_SNAPSHOT_CHAIN_STATE_V1"
_SIDECAR_CHAIN_ENTRY_DOMAIN = b"HYPERTRIANGLE_RECEIPT_ID_SIDECAR_SNAPSHOT_CHAIN_ENTRY_V1\n"
_SIDECAR_CHAIN_ACC_DOMAIN = b"HYPERTRIANGLE_RECEIPT_ID_SIDECAR_SNAPSHOT_CHAIN_ACCUMULATOR_V1\n"
_DEFAULT_SIDECAR_CHAIN_ANCHOR_WINDOW = 8
_MAX_SIDECAR_CHAIN_ANCHOR_WINDOW = 64
_DEFAULT_SIDECAR_MAX_JOURNAL_RECORDS = 256
_DEFAULT_SIDECAR_MAX_JOURNAL_BYTES = 1 << 20


def _sidecar_chain_entry(snapshot: Dict[str, Any]) -> Dict[str, Any]:
    sv=validate_receipt_id_sidecar_snapshot(snapshot)
    if not sv.get("snapshot_valid",False):
        raise AuxError("invalid sidecar snapshot for chain entry")
    body={
        "generation":int(snapshot["generation"]),
        "snapshot_hash":str(snapshot["snapshot_hash"]),
        "parent_snapshot_hash":snapshot.get("parent_snapshot_hash"),
        "compacted_journal_tail_hash":snapshot.get("compacted_journal_tail_hash"),
        "receipt_id_count":int(snapshot["receipt_id_count"]),
        "receipt_id_root":str(snapshot["receipt_id_root"]),
    }
    h=hashlib.sha256(); h.update(_SIDECAR_CHAIN_ENTRY_DOMAIN); h.update(_canonical_for_hash(body))
    out=dict(body); out["entry_hash"]=h.hexdigest(); return out


def _sidecar_chain_acc_seed() -> str:
    h=hashlib.sha256(); h.update(_SIDECAR_CHAIN_ACC_DOMAIN); h.update(b"EMPTY\n"); return h.hexdigest()


def _sidecar_chain_acc_step(previous: str, entry: Dict[str, Any]) -> str:
    if not _hex64(previous): raise AuxError("invalid sidecar chain accumulator")
    h=hashlib.sha256(); h.update(_SIDECAR_CHAIN_ACC_DOMAIN); h.update(b"STEP\n"); h.update(bytes.fromhex(previous)); h.update(_canonical_for_hash(entry)); return h.hexdigest()


def _fold_sidecar_chain(entries: Sequence[Dict[str, Any]], seed: str | None=None) -> str:
    acc=str(seed or _sidecar_chain_acc_seed())
    for e in entries: acc=_sidecar_chain_acc_step(acc,e)
    return acc


def _sidecar_chain_state_hash_body(body: Dict[str, Any]) -> str:
    h=hashlib.sha256(); h.update(b"HYPERTRIANGLE_RECEIPT_ID_SIDECAR_SNAPSHOT_CHAIN_STATE_V1\n"); h.update(_canonical_for_hash(body)); return h.hexdigest()


def _validate_sidecar_snapshot_sequence(snapshots: Sequence[Dict[str, Any]]) -> Tuple[Dict[str, Any], ...]:
    snaps=tuple(copy.deepcopy(snapshots))
    if not snaps: raise AuxError("snapshot chain cannot be empty")
    previous=None
    entries=[]
    for i,snap in enumerate(snaps):
        sv=validate_receipt_id_sidecar_snapshot(snap)
        if not sv.get("snapshot_valid",False): raise AuxError(f"invalid snapshot at position {i}")
        if i==0:
            if int(snap.get("generation",-1))<0: raise AuxError("invalid initial generation")
        else:
            if int(snap.get("generation",-1))!=int(previous.get("generation"))+1: raise AuxError("snapshot generation gap")
            if str(snap.get("parent_snapshot_hash"))!=str(previous.get("snapshot_hash")): raise AuxError("snapshot parent hash mismatch")
            if snapshot_count:=int(snap.get("receipt_id_count",-1)):
                if snapshot_count<int(previous.get("receipt_id_count",0)): raise AuxError("snapshot receipt-id count decreased")
            if snap.get("compacted_journal_tail_hash") is None or not _hex64(snap.get("compacted_journal_tail_hash")): raise AuxError("child snapshot lacks compacted journal tail commitment")
        entries.append(_sidecar_chain_entry(snap)); previous=snap
    return tuple(entries)


def receipt_id_sidecar_snapshot_chain(payload: Dict[str, Any]) -> Dict[str, Any]:
    try:
        snapshots=tuple(payload.get("snapshots") or ())
        window=int(payload.get("anchor_window",_DEFAULT_SIDECAR_CHAIN_ANCHOR_WINDOW))
        if window<1 or window>_MAX_SIDECAR_CHAIN_ANCHOR_WINDOW: raise AuxError("invalid sidecar chain anchor window")
        entries=_validate_sidecar_snapshot_sequence(snapshots)
        compacted=max(0,len(entries)-window); prefix=entries[:compacted]; anchors=entries[compacted:]
        prefix_acc=_fold_sidecar_chain(prefix); acc=_fold_sidecar_chain(anchors,prefix_acc)
        body={
            "schema":_SIDECAR_CHAIN_STATE_SCHEMA,
            "aux_name":AUX_NAME,
            "aux_version":AUX_VERSION,
            "snapshot_count":len(entries),
            "compacted_snapshot_count":compacted,
            "prefix_accumulator":prefix_acc,
            "anchors":anchors,
            "chain_accumulator":acc,
            "anchor_window":window,
            "root_snapshot_hash":str(entries[0]["snapshot_hash"]),
            "tip_snapshot_hash":str(entries[-1]["snapshot_hash"]),
            "tip_generation":int(entries[-1]["generation"]),
            "tip_receipt_id_count":int(entries[-1]["receipt_id_count"]),
            "tip_receipt_id_root":str(entries[-1]["receipt_id_root"]),
            "truth_credit":0,
            "root_write_capability":"NONE",
            "return_write_capability":"NONE",
            "solver_mutation_capability":"NONE",
            "audit_scope":"bounded active chain state; exact reconstruction of compacted snapshot metadata requires archived snapshots",
        }
        state=dict(body); state["chain_state_hash"]=_sidecar_chain_state_hash_body(body)
        return {"status":"RECEIPT_ID_SIDECAR_SNAPSHOT_CHAIN_CREATED","chain_valid":True,"chain_state":state,"truth_credit":0}
    except Exception as exc:
        return {"status":"RECEIPT_ID_SIDECAR_SNAPSHOT_CHAIN_REJECTED","chain_valid":False,"error":str(exc),"truth_credit":0}



def receipt_id_sidecar_snapshot_chain_append(payload: Dict[str, Any]) -> Dict[str, Any]:
    state=copy.deepcopy(payload.get("chain_state") or {})
    child=copy.deepcopy(payload.get("snapshot") or payload.get("child_snapshot") or {})
    valid=validate_receipt_id_sidecar_snapshot_chain(state)
    if not valid.get("chain_valid",False): return {"status":"SIDECAR_SNAPSHOT_CHAIN_APPEND_BLOCKED","chain_valid":False,"validation":valid,"truth_credit":0}
    sv=validate_receipt_id_sidecar_snapshot(child)
    if not sv.get("snapshot_valid",False): return {"status":"SIDECAR_SNAPSHOT_CHAIN_APPEND_BLOCKED","chain_valid":False,"snapshot_validation":sv,"truth_credit":0}
    try:
        if int(child.get("generation"))!=int(state.get("tip_generation"))+1: raise AuxError("child generation mismatch")
        if str(child.get("parent_snapshot_hash"))!=str(state.get("tip_snapshot_hash")): raise AuxError("child parent snapshot hash mismatch")
        if child.get("compacted_journal_tail_hash") is None or not _hex64(child.get("compacted_journal_tail_hash")): raise AuxError("child lacks compacted journal tail commitment")
        window=int(state["anchor_window"]); compacted=int(state["compacted_snapshot_count"]); prefix=str(state["prefix_accumulator"]); anchors=list(copy.deepcopy(state.get("anchors") or ()))
        entry=_sidecar_chain_entry(child); anchors.append(entry)
        while len(anchors)>window:
            evicted=anchors.pop(0); prefix=_sidecar_chain_acc_step(prefix,evicted); compacted+=1
        body={
            "schema":_SIDECAR_CHAIN_STATE_SCHEMA,
            "aux_name":AUX_NAME,
            "aux_version":AUX_VERSION,
            "snapshot_count":int(state["snapshot_count"])+1,
            "compacted_snapshot_count":compacted,
            "prefix_accumulator":prefix,
            "anchors":tuple(anchors),
            "chain_accumulator":_fold_sidecar_chain(anchors,prefix),
            "anchor_window":window,
            "root_snapshot_hash":str(state["root_snapshot_hash"]),
            "tip_snapshot_hash":str(child["snapshot_hash"]),
            "tip_generation":int(child["generation"]),
            "tip_receipt_id_count":int(child["receipt_id_count"]),
            "tip_receipt_id_root":str(child["receipt_id_root"]),
            "truth_credit":0,
            "root_write_capability":"NONE",
            "return_write_capability":"NONE",
            "solver_mutation_capability":"NONE",
            "audit_scope":"bounded active chain state; exact reconstruction of compacted snapshot metadata requires archived snapshots",
        }
        out=dict(body); out["chain_state_hash"]=_sidecar_chain_state_hash_body(body)
        return {"status":"RECEIPT_ID_SIDECAR_SNAPSHOT_CHAIN_APPENDED","chain_valid":True,"chain_state":out,"truth_credit":0}
    except Exception as exc:
        return {"status":"SIDECAR_SNAPSHOT_CHAIN_APPEND_REJECTED","chain_valid":False,"error":str(exc),"truth_credit":0}


def validate_receipt_id_sidecar_snapshot_chain(payload: Dict[str, Any]) -> Dict[str, Any]:
    state=payload.get("chain_state") or payload
    try:
        if not isinstance(state,dict) or state.get("schema")!=_SIDECAR_CHAIN_STATE_SCHEMA: raise AuxError("invalid sidecar chain-state schema")
        supplied=str(state.get("chain_state_hash","")); body={k:copy.deepcopy(v) for k,v in state.items() if k!="chain_state_hash"}
        if supplied!=_sidecar_chain_state_hash_body(body): raise AuxError("sidecar chain-state hash mismatch")
        count=int(state.get("snapshot_count",-1)); compacted=int(state.get("compacted_snapshot_count",-1)); window=int(state.get("anchor_window",0)); anchors=tuple(state.get("anchors") or ())
        if count<1 or compacted<0 or window<1 or window>_MAX_SIDECAR_CHAIN_ANCHOR_WINDOW or compacted+len(anchors)!=count: raise AuxError("sidecar chain-state count mismatch")
        if not anchors or len(anchors)>window: raise AuxError("invalid sidecar chain anchor count")
        prefix=str(state.get("prefix_accumulator","")); acc=str(state.get("chain_accumulator",""))
        if not _hex64(prefix) or not _hex64(acc) or _fold_sidecar_chain(anchors,prefix)!=acc: raise AuxError("sidecar chain accumulator mismatch")
        prev_gen=None; prev_hash=None
        for j,e in enumerate(anchors):
            if not _hex64(e.get("snapshot_hash")) or not _hex64(e.get("receipt_id_root")) or not _hex64(e.get("entry_hash")): raise AuxError("invalid sidecar chain anchor hash")
            body_e={k:copy.deepcopy(v) for k,v in e.items() if k!="entry_hash"}; hh=hashlib.sha256(); hh.update(_SIDECAR_CHAIN_ENTRY_DOMAIN); hh.update(_canonical_for_hash(body_e))
            if e.get("entry_hash")!=hh.hexdigest(): raise AuxError("sidecar chain entry hash mismatch")
            g=int(e.get("generation",-1))
            if prev_gen is not None:
                if g!=prev_gen+1: raise AuxError("sidecar anchor generation gap")
                if str(e.get("parent_snapshot_hash"))!=prev_hash: raise AuxError("sidecar anchor parent mismatch")
            prev_gen=g; prev_hash=str(e.get("snapshot_hash"))
        if str(anchors[-1].get("snapshot_hash"))!=str(state.get("tip_snapshot_hash")): raise AuxError("sidecar chain tip mismatch")
        if int(anchors[-1].get("generation"))!=int(state.get("tip_generation")): raise AuxError("sidecar chain tip generation mismatch")
        if int(anchors[-1].get("receipt_id_count"))!=int(state.get("tip_receipt_id_count")): raise AuxError("sidecar chain tip count mismatch")
        if str(anchors[-1].get("receipt_id_root"))!=str(state.get("tip_receipt_id_root")): raise AuxError("sidecar chain tip root mismatch")
        if compacted==0 and str(anchors[0].get("snapshot_hash"))!=str(state.get("root_snapshot_hash")): raise AuxError("sidecar chain root mismatch")
        if int(state.get("truth_credit",-1))!=0 or state.get("root_write_capability")!="NONE" or state.get("return_write_capability")!="NONE" or state.get("solver_mutation_capability")!="NONE": raise AuxError("authority firewall violation")
        return {"status":"RECEIPT_ID_SIDECAR_SNAPSHOT_CHAIN_VALID","chain_valid":True,"chain_state_hash":supplied,"snapshot_count":count,"compacted_snapshot_count":compacted,"anchor_count":len(anchors),"truth_credit":0}
    except Exception as exc:
        return {"status":"INVALID_RECEIPT_ID_SIDECAR_SNAPSHOT_CHAIN","chain_valid":False,"error":str(exc),"truth_credit":0}


def validate_receipt_id_sidecar_compaction_transition(payload: Dict[str, Any]) -> Dict[str, Any]:
    parent=payload.get("parent_snapshot") or {}; records=tuple(payload.get("journal_records") or ()); child=payload.get("child_snapshot") or {}
    recovered=_recover_receipt_id_sidecar_internal(parent,records)
    if not recovered.get("recovered",False): return {"status":"SIDECAR_COMPACTION_TRANSITION_INVALID","transition_valid":False,"recovery":recovered,"truth_credit":0}
    cv=validate_receipt_id_sidecar_snapshot(child)
    if not cv.get("snapshot_valid",False): return {"status":"SIDECAR_COMPACTION_TRANSITION_INVALID","transition_valid":False,"child_validation":cv,"truth_credit":0}
    try:
        if int(child.get("generation"))!=int(parent.get("generation"))+1: raise AuxError("child generation mismatch")
        if str(child.get("parent_snapshot_hash"))!=str(parent.get("snapshot_hash")): raise AuxError("child parent snapshot hash mismatch")
        if str(child.get("compacted_journal_tail_hash"))!=str(recovered.get("journal_tail_hash")): raise AuxError("child compacted journal tail mismatch")
        if int(child.get("receipt_id_count"))!=int(recovered.get("receipt_id_count")): raise AuxError("child receipt-id count mismatch")
        if str(child.get("receipt_id_root"))!=str(recovered.get("receipt_id_root")): raise AuxError("child receipt-id root mismatch")
        if tuple(map(str,child.get("receipt_ids") or ()))!=tuple(map(str,recovered.get("receipt_ids") or ())): raise AuxError("child exact receipt-id set mismatch")
    except Exception as exc:
        return {"status":"SIDECAR_COMPACTION_TRANSITION_INVALID","transition_valid":False,"error":str(exc),"truth_credit":0}
    return {"status":"SIDECAR_COMPACTION_TRANSITION_VALID","transition_valid":True,"parent_snapshot_hash":parent.get("snapshot_hash"),"child_snapshot_hash":child.get("snapshot_hash"),"journal_record_count":len(records),"receipt_id_count":child.get("receipt_id_count"),"truth_credit":0}


def _sidecar_journal_canonical_bytes(records: Sequence[Dict[str, Any]]) -> int:
    total=0
    for r in records:
        total+=len(json.dumps(encode(r),sort_keys=True,separators=(",",":"),ensure_ascii=False).encode("utf-8"))+1
    return total


def receipt_id_sidecar_compaction_decision(payload: Dict[str, Any]) -> Dict[str, Any]:
    snapshot=payload.get("snapshot") or {}; records=tuple(payload.get("journal_records") or ()); policy=payload.get("policy") or {}
    recovered=_recover_receipt_id_sidecar_internal(snapshot,records)
    if not recovered.get("recovered",False): return {"status":"SIDECAR_COMPACTION_POLICY_BLOCKED","decision_valid":False,"recovery":recovered,"truth_credit":0}
    try:
        max_records=int(policy.get("max_journal_records",_DEFAULT_SIDECAR_MAX_JOURNAL_RECORDS)); max_bytes=int(policy.get("max_journal_bytes",_DEFAULT_SIDECAR_MAX_JOURNAL_BYTES))
        if max_records<1 or max_bytes<1: raise AuxError("compaction thresholds must be positive")
        rc=len(records); jb=_sidecar_journal_canonical_bytes(records); triggers=[]
        if rc>=max_records and rc>0: triggers.append("JOURNAL_RECORD_THRESHOLD")
        if jb>=max_bytes and rc>0: triggers.append("JOURNAL_BYTE_THRESHOLD")
        compact=bool(triggers)
        return {"status":"COMPACT_NOW" if compact else "KEEP_APPEND","decision_valid":True,"compact_now":compact,"triggers":tuple(triggers),"journal_record_count":rc,"journal_canonical_bytes":jb,"max_journal_records":max_records,"max_journal_bytes":max_bytes,"current_generation":int(snapshot.get("generation",0)),"next_generation":int(snapshot.get("generation",0))+1,"receipt_id_count":int(recovered.get("receipt_id_count",0)),"receipt_id_root":recovered.get("receipt_id_root"),"truth_credit":0}
    except Exception as exc:
        return {"status":"SIDECAR_COMPACTION_POLICY_REJECTED","decision_valid":False,"error":str(exc),"truth_credit":0}


def receipt_id_sidecar_auto_compact(payload: Dict[str, Any]) -> Dict[str, Any]:
    decision=receipt_id_sidecar_compaction_decision(payload)
    if not decision.get("decision_valid",False): return {"status":"SIDECAR_AUTO_COMPACTION_BLOCKED","auto_compaction_valid":False,"decision":decision,"truth_credit":0}
    if not decision.get("compact_now",False):
        recovered=_recover_receipt_id_sidecar_internal(payload.get("snapshot") or {},tuple(payload.get("journal_records") or ()))
        return {"status":"SIDECAR_AUTO_COMPACTION_NOT_REQUIRED","auto_compaction_valid":True,"compaction_performed":False,"decision":decision,"receipt_id_root":recovered.get("receipt_id_root"),"receipt_id_count":recovered.get("receipt_id_count"),"truth_credit":0}
    compacted=compact_receipt_id_sidecar(payload)
    if not compacted.get("compacted",False): return {"status":"SIDECAR_AUTO_COMPACTION_FAILED","auto_compaction_valid":False,"decision":decision,"compaction":compacted,"truth_credit":0}
    return {"status":"SIDECAR_AUTO_COMPACTED","auto_compaction_valid":True,"compaction_performed":True,"decision":decision,"snapshot":compacted["snapshot"],"receipt_id_root":compacted["receipt_id_root"],"receipt_id_count":compacted["receipt_id_count"],"truth_credit":0}


# ---------------------------------------------------------------------------
# PASS010 — native 144-slot invariant memory grid
# ---------------------------------------------------------------------------

_MEMORY_144_SCHEMA = "HYPERTRIANGLE_CAUSAL_MEMORY_144_V1"
_MEMORY_144_TRACE_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_TRACE_V1\\0"
_MEMORY_144_STATE_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_STATE_V1\\0"

# Canonical source-derived 144-slot catalog.  Slot identity/function is immutable;
# incoming data carries an invariant/operator signature and falls onto the slot.
_CAUSAL_144_ROWS = (
    (1, 'F001', 'Identity seed', 'IDENTITY_SEED', 'ORIGIN', 'H'),
    (2, 'F002', 'Saturated closure', 'SATURATED_FIXPOINT', 'CYCLE', 'He'),
    (3, 'F003', 'Directed onset', 'DIRECTED_ONSET', 'CHANNEL', 'Li'),
    (4, 'F004', 'Orthogonal frame', 'ORTHOGONAL_FRAME', 'LOCALIZE', 'Be'),
    (5, 'F005', 'Deficit mediation', 'DEFICIT_MEDIATION', 'RELAY', 'B'),
    (6, 'F006', 'Composable chain', 'COMPOSABLE_CHAIN', 'CHANNEL', 'C'),
    (7, 'F007', 'Local buffer', 'LOCAL_BUFFER', 'LOCALIZE', 'N'),
    (8, 'F008', 'Stress revelation', 'STRESS_REVEAL', 'DISSIPATE', 'O'),
    (9, 'F009', 'Irreversible extraction', 'IRREVERSIBLE_EXTRACTION', 'DISSIPATE', 'F'),
    (10, 'F010', 'Neutral emission', 'NEUTRAL_EMISSION', 'CYCLE', 'Ne'),
    (11, 'F011', 'Low-threshold trigger', 'LOW_THRESHOLD_TRIGGER', 'RELAY', 'Na'),
    (12, 'F012', 'Light bracing', 'LIGHT_BRACING', 'LOCALIZE', 'Mg'),
    (13, 'F013', 'Surface passivation', 'SURFACE_PASSIVATION', 'CYCLE', 'Al'),
    (14, 'F014', 'Discrete lattice', 'DISCRETE_LATTICE', 'LOCALIZE', 'Si'),
    (15, 'F015', 'Conditional activation', 'CONDITIONAL_IGNITION', 'RELAY', 'P'),
    (16, 'F016', 'Bounded polymorphism', 'BOUNDED_POLYMORPHISM', 'RELAY', 'S'),
    (17, 'F017', 'Targeted capture termination', 'TARGETED_CAPTURE_TERMINATION', 'DISSIPATE', 'Cl'),
    (18, 'F018', 'Closed neutral presence', 'CLOSED_NEUTRAL_PRESENCE', 'CYCLE', 'Ar'),
    (19, 'F019', 'Primed amplification', 'STRONG_PRIMED_BOOST', 'CHANNEL', 'K'),
    (20, 'F020', 'Load-bearing scaffold', 'LOAD_BEARING_SCAFFOLD', 'LOCALIZE', 'Ca'),
    (21, 'F021', 'Axial coordination seed', 'AXIAL_COORDINATION_SEED', 'RELAY', 'Sc'),
    (22, 'F022', 'Isomorphic reinforcement', 'ISOMORPHIC_REINFORCEMENT', 'LOCALIZE', 'Ti'),
    (23, 'F023', 'Reversible state return', 'REVERSIBLE_STATE_RETURN', 'RELAY', 'V'),
    (24, 'F024', 'Strong surface passivation', 'STRONG_SURFACE_PASSIVATION', 'CYCLE', 'Cr'),
    (25, 'F025', 'Multistate balance', 'MULTISTATE_BALANCE', 'RELAY', 'Mn'),
    (26, 'F026', 'Redundant structural binding', 'STRONG_STRUCTURAL_BINDING', 'CHANNEL', 'Fe'),
    (27, 'F027', 'Active stabilization', 'ACTIVE_STABILIZATION', 'RELAY', 'Co'),
    (28, 'F028', 'Reversible modular coupling', 'REVERSIBLE_MODULAR_COUPLING', 'RELAY', 'Ni'),
    (29, 'F029', 'Fidelity conduction', 'FIDELITY_CONDUCTION', 'CHANNEL', 'Cu'),
    (30, 'F030', 'Threshold clamp', 'THRESHOLD_CLAMP', 'LOCALIZE', 'Zn'),
    (31, 'F031', 'Reversible phase shift', 'REVERSIBLE_PHASE_SHIFT', 'RELAY', 'Ga'),
    (32, 'F032', 'Structural translation', 'STRUCTURAL_TRANSLATION', 'RELAY', 'Ge'),
    (33, 'F033', 'Targeted disruption', 'TARGETED_DISRUPTION', 'DISSIPATE', 'As'),
    (34, 'F034', 'Selective filtering', 'SELECTIVE_FILTER', 'RELAY', 'Se'),
    (35, 'F035', 'Global quench', 'GLOBAL_QUENCH', 'DISSIPATE', 'Br'),
    (36, 'F036', 'Inert latency', 'INERT_LATENCY', 'CYCLE', 'Kr'),
    (37, 'F037', 'High-gain amplification', 'HIGH_GAIN_AMPLIFICATION', 'CHANNEL', 'Rb'),
    (38, 'F038', 'Static reference', 'STATIC_REFERENCE', 'CYCLE', 'Sr'),
    (39, 'F039', 'Indirect mediation', 'INDIRECT_MEDIATION', 'RELAY', 'Y'),
    (40, 'F040', 'Volumetric containment', 'VOLUMETRIC_CONTAINMENT', 'LOCALIZE', 'Zr'),
    (41, 'F041', 'Coherence under load', 'COHERENCE_UNDER_LOAD', 'LOCALIZE', 'Nb'),
    (42, 'F042', 'High-stress hold', 'HIGH_STRESS_HOLD', 'LOCALIZE', 'Mo'),
    (43, 'F043', 'Tracked instability', 'TRACKED_INSTABILITY', 'DISSIPATE', 'Tc'),
    (44, 'F044', 'Invariant catalysis', 'INVARIANT_CATALYSIS', 'RELAY', 'Ru'),
    (45, 'F045', 'Strict selectivity', 'STRICT_SELECTIVITY', 'RELAY', 'Rh'),
    (46, 'F046', 'Reversible absorption', 'REVERSIBLE_ABSORPTION', 'RELAY', 'Pd'),
    (47, 'F047', 'Faithful reflection', 'FAITHFUL_REFLECTION', 'CYCLE', 'Ag'),
    (48, 'F048', 'Dissipative fuse', 'DISSIPATIVE_FUSE', 'DISSIPATE', 'Cd'),
    (49, 'F049', 'Continuous plasticity', 'CONTINUOUS_PLASTICITY', 'LOCALIZE', 'In'),
    (50, 'F050', 'Gradual hardening', 'GRADUAL_HARDENING', 'LOCALIZE', 'Sn'),
    (51, 'F051', 'Dual structural hold', 'DUAL_STRUCTURE_HOLD', 'RELAY', 'Sb'),
    (52, 'F052', 'Local weakening', 'LOCAL_WEAKENING', 'DISSIPATE', 'Te'),
    (53, 'F053', 'Reversible inhibition', 'REVERSIBLE_INHIBITION', 'DISSIPATE', 'I'),
    (54, 'F054', 'Protected latency', 'PROTECTED_LATENCY', 'CYCLE', 'Xe'),
    (55, 'F055', 'Hyper-trigger', 'HYPER_TRIGGER', 'CHANNEL', 'Cs'),
    (56, 'F056', 'Massive support', 'MASSIVE_SUPPORT', 'LOCALIZE', 'Ba'),
    (57, 'F057', 'Series opening', 'SERIES_OPENING', 'CHANNEL', 'La'),
    (58, 'F058', 'Bounded state variability', 'BOUNDED_STATE_VARIABILITY', 'RELAY', 'Ce'),
    (59, 'F059', 'Preferred orientation', 'PREFERRED_ORIENTATION', 'LOCALIZE', 'Pr'),
    (60, 'F060', 'Coherent forcing', 'COHERENT_FORCING', 'CHANNEL', 'Nd'),
    (61, 'F061', 'Transient carrying', 'TRANSIENT_CARRIER', 'DISSIPATE', 'Pm'),
    (62, 'F062', 'Bounded remanence', 'BOUNDED_REMANENCE', 'LOCALIZE', 'Sm'),
    (63, 'F063', 'Conditional amplification', 'CONDITIONAL_AMPLIFICATION', 'CHANNEL', 'Eu'),
    (64, 'F064', 'Robust binary split', 'ROBUST_BINARY_SPLIT', 'LOCALIZE', 'Gd'),
    (65, 'F065', 'Anisotropic break', 'ANISOTROPIC_BREAK', 'DISSIPATE', 'Tb'),
    (66, 'F066', 'Shift resistance', 'SHIFT_RESISTANCE', 'LOCALIZE', 'Dy'),
    (67, 'F067', 'Local pinning', 'LOCAL_PINNING', 'LOCALIZE', 'Ho'),
    (68, 'F068', 'Smooth damping', 'SMOOTH_DAMPING', 'LOCALIZE', 'Er'),
    (69, 'F069', 'Narrow validity window', 'NARROW_VALIDITY_WINDOW', 'LOCALIZE', 'Tm'),
    (70, 'F070', 'Binary toggle', 'BINARY_TOGGLE', 'LOCALIZE', 'Yb'),
    (71, 'F071', 'Series closure', 'SERIES_CLOSURE', 'CYCLE', 'Lu'),
    (72, 'F072', 'Stability under drive', 'STABLE_UNDER_DRIVE', 'LOCALIZE', 'Hf'),
    (73, 'F073', 'Deep barrier lock', 'DEEP_BARRIER_LOCK', 'LOCALIZE', 'Ta'),
    (74, 'F074', 'Maximal failure threshold', 'MAX_FAILURE_THRESHOLD', 'LOCALIZE', 'W'),
    (75, 'F075', 'Cyclic recovery', 'CYCLIC_RECOVERY', 'RELAY', 'Re'),
    (76, 'F076', 'Density compression', 'DENSITY_COMPRESSION', 'LOCALIZE', 'Os'),
    (77, 'F077', 'Strong passivation', 'STRONG_PASSIVATION', 'CYCLE', 'Ir'),
    (78, 'F078', 'Stable optimum', 'STABLE_ARGMIN', 'CYCLE', 'Pt'),
    (79, 'F079', 'Chemical inertia', 'CHEMICAL_INERTIA', 'CYCLE', 'Au'),
    (80, 'F080', 'Mobility without fixed point', 'MOBILE_NO_FIXPOINT', 'CHANNEL', 'Hg'),
    (81, 'F081', 'Load-induced collapse', 'LOAD_COLLAPSE', 'DISSIPATE', 'Tl'),
    (82, 'F082', 'Absorbing shield', 'ABSORBING_SHIELD', 'LOCALIZE', 'Pb'),
    (83, 'F083', 'Edge stability', 'EDGE_STABLE', 'LOCALIZE', 'Bi'),
    (84, 'F084', 'Intrinsic self-decay', 'SELF_DECAY', 'DISSIPATE', 'Po'),
    (85, 'F085', 'Ephemeral exception', 'EPHEMERAL_EXCEPTION', 'DISSIPATE', 'At'),
    (86, 'F086', 'Sealed toxic confinement', 'SEALED_TOXIC', 'CYCLE', 'Rn'),
    (87, 'F087', 'Non-tenability', 'NON_TENABLE', 'DISSIPATE', 'Fr'),
    (88, 'F088', 'Persistent emission', 'PERSISTENT_EMISSION', 'DISSIPATE', 'Ra'),
    (89, 'F089', 'Unstable lineage opening', 'UNSTABLE_SERIES_OPENING', 'CHANNEL', 'Ac'),
    (90, 'F090', 'Slow decay', 'SLOW_DECAY', 'DISSIPATE', 'Th'),
    (91, 'F091', 'Blocked transition', 'BLOCKED_TRANSITION', 'LOCALIZE', 'Pa'),
    (92, 'F092', 'Conditional stored power', 'STORED_POWER', 'CHANNEL', 'U'),
    (93, 'F093', 'Instability transfer', 'INSTABILITY_TRANSFER', 'DISSIPATE', 'Np'),
    (94, 'F094', 'Unstable multiregime', 'UNSTABLE_MULTIREGIME', 'CHANNEL', 'Pu'),
    (95, 'F095', 'Long emission with cumulative cost', 'LONG_EMISSION', 'DISSIPATE', 'Am'),
    (96, 'F096', 'Internal thermogenesis', 'INTERNAL_THERMOGENESIS', 'DISSIPATE', 'Cm'),
    (97, 'F097', 'Contained instability', 'CONTAINED_INSTABILITY', 'LOCALIZE', 'Bk'),
    (98, 'F098', 'Supercritical cascade', 'SUPERCRITICAL_CASCADE', 'CHANNEL', 'Cf'),
    (99, 'F099', 'Externally assisted coherence', 'EXTERNAL_DEPENDENT_COHERENCE', 'LOCALIZE', 'Es'),
    (100, 'F100', 'Synthesis-domain limit', 'SYNTHESIS_DOMAIN_LIMIT', 'CYCLE', 'Fm'),
    (101, 'F101', 'Precision experimental hold', 'PRECISION_EXPERIMENTAL_HOLD', 'LOCALIZE', 'Md'),
    (102, 'F102', 'Ultra-narrow survival window', 'ULTRA_NARROW_SURVIVAL_WINDOW', 'DISSIPATE', 'No'),
    (103, 'F103', 'Characterization drift', 'CHARACTERIZATION_DRIFT', 'DISSIPATE', 'Lr'),
    (104, 'F104', 'Forced form', 'FORCED_FORM', 'LOCALIZE', 'Rf'),
    (105, 'F105', 'Domain overlap', 'DOMAIN_OVERLAP', 'RELAY', 'Db'),
    (106, 'F106', 'Support-prolonged persistence', 'PROLONGED_BY_SUPPORT', 'LOCALIZE', 'Sg'),
    (107, 'F107', 'Patterned failure', 'PATTERNED_FAILURE', 'DISSIPATE', 'Bh'),
    (108, 'F108', 'Constraint saturation', 'CONSTRAINT_SATURATION', 'DISSIPATE', 'Hs'),
    (109, 'F109', 'Open asymptotic convergence', 'OPEN_ASYMPTOTE', 'LOCALIZE', 'Mt'),
    (110, 'F110', 'Instantaneous completeness spike', 'INSTANT_COMPLETENESS_SPIKE', 'DISSIPATE', 'Ds'),
    (111, 'F111', 'Label without causal force', 'LABEL_WITHOUT_FORCE', 'CYCLE', 'Rg'),
    (112, 'F112', 'Quasi-inert presence', 'QUASI_INERT_PRESENCE', 'CYCLE', 'Cn'),
    (113, 'F113', 'Context-locked validity', 'CONTEXT_LOCK', 'LOCALIZE', 'Nh'),
    (114, 'F114', 'Shell-only stability', 'SHELL_ONLY_STABILITY', 'CYCLE', 'Fl'),
    (115, 'F115', 'Pre-break margin', 'PRE_BREAK_MARGIN', 'DISSIPATE', 'Mc'),
    (116, 'F116', 'Delayed collapse', 'DELAYED_COLLAPSE', 'DISSIPATE', 'Lv'),
    (117, 'F117', 'Edge attack without binding', 'EDGE_ATTACK_NO_BIND', 'DISSIPATE', 'Ts'),
    (118, 'F118', 'Local horizon closure', 'HORIZON_CLOSURE', 'CYCLE', 'Og'),
    (119, 'F119', 'Distributed support seed', 'HIDDEN_SUPPORT_SEED', 'ORIGIN', 'Hidden Support Seed'),
    (120, 'F120', 'Support-part alignment', 'HIDDEN_SUPPORT_ALIGNMENT', 'CHANNEL', 'Hidden Support Alignment'),
    (121, 'F121', 'Nonradiative curvature storage', 'HIDDEN_SUPPORT_CURVATURE', 'RELAY', 'Hidden Support Curvature'),
    (122, 'F122', 'Distributed boundary halo', 'HIDDEN_SUPPORT_HALO', 'LOCALIZE', 'Hidden Support Halo'),
    (123, 'F123', 'Distributed support seal', 'HIDDEN_SUPPORT_SEAL', 'DISSIPATE', 'Hidden Support Seal'),
    (124, 'F124', 'Distributed resonance opening', 'HIDDEN_RESONANCE_OPENING', 'CHANNEL', 'Hidden Resonance Opening'),
    (125, 'F125', 'Phase-relation lock', 'HIDDEN_RESONANCE_LOCK', 'RELAY', 'Hidden Resonance Lock'),
    (126, 'F126', 'Distributed resonance relay', 'HIDDEN_RESONANCE_RELAY', 'CHANNEL', 'Hidden Resonance Relay'),
    (127, 'F127', 'Coherent resonance field', 'HIDDEN_RESONANCE_FIELD', 'LOCALIZE', 'Hidden Resonance Field'),
    (128, 'F128', 'Silent resonance closure', 'HIDDEN_RESONANCE_SEAL', 'DISSIPATE', 'Hidden Resonance Seal'),
    (129, 'F129', 'Distributed information inscription', 'HIDDEN_INFORMATION_OPENING', 'ORIGIN', 'Hidden Information Opening'),
    (130, 'F130', 'Carrierless information relay', 'HIDDEN_INFORMATION_RELAY', 'CHANNEL', 'Hidden Information Relay'),
    (131, 'F131', 'Coherent distributed information field', 'HIDDEN_INFORMATION_FIELD', 'RELAY', 'Hidden Information Field'),
    (132, 'F132', 'Distributed causal memory', 'HIDDEN_INFORMATION_MEMORY', 'LOCALIZE', 'Hidden Information Memory'),
    (133, 'F133', 'Information-inheritance seal', 'HIDDEN_INFORMATION_SEAL', 'DISSIPATE', 'Hidden Information Seal'),
    (134, 'F134', 'Local manifestation threshold', 'ELECTRON_THRESHOLD', 'ORIGIN', 'Electron Threshold'),
    (135, 'F135', 'Persistent local anchoring', 'PROTON_ANCHOR', 'CHANNEL', 'Proton Anchor'),
    (136, 'F136', 'Unclosed-instability reservoir', 'NEUTRON_RESERVOIR', 'RELAY', 'Neutron Reservoir'),
    (137, 'F137', 'Cohesion without independent carrier', 'GLUON_COHESION', 'LOCALIZE', 'Gluon Cohesion'),
    (138, 'F138', 'Coherence transport beyond locality', 'COHERENCE_BRIDGE', 'RELAY', 'Neutrino Bridge'),
    (139, 'F139', 'Supracausal reopening of possibility', 'PI_EXPANSION', 'ORIGIN', 'Expansion'),
    (140, 'F140', 'Global reconciliation of domains', 'GLOBAL_RELATION', 'CHANNEL', 'Relation'),
    (141, 'F141', 'Generative symmetrization under curvature', 'SYMMETRY_ATTRACTION', 'RELAY', 'Symmetry'),
    (142, 'F142', 'Crystallization of transmissible structure', 'SPACETIME_STRUCTURE', 'LOCALIZE', 'Structure'),
    (143, 'F143', 'Global closure with preserved provenance', 'GLOBAL_BOUNDARY', 'DISSIPATE', 'Boundary'),
    (144, 'F144', 'Terminal unification and support release', 'UNITY_TRANSCENDENCE', 'CYCLE', 'Unity'),
)

_CAUSAL_144_BY_OPERATOR = {r[3]: r for r in _CAUSAL_144_ROWS}
_CAUSAL_144_BY_SLOT = {r[1]: r for r in _CAUSAL_144_ROWS}


def _memory_144_empty_trace_hash() -> str:
    h=hashlib.sha256(); h.update(_MEMORY_144_TRACE_DOMAIN); h.update(b"START:1")
    return h.hexdigest()


def _memory_144_flag_mask(flags: Sequence[bool]) -> str:
    if len(flags)!=144: raise AuxError("memory grid must contain exactly 144 flags")
    value=0
    for i,v in enumerate(flags):
        if bool(v): value |= 1 << i
    return f"{value:036x}"


def _memory_144_state_hash(body: Dict[str, Any]) -> str:
    h=hashlib.sha256(); h.update(_MEMORY_144_STATE_DOMAIN); h.update(_canonical_for_hash(body)); return h.hexdigest()


def memory_144_catalog(_: Dict[str, Any] | None = None) -> Dict[str, Any]:
    return {
        "status":"MEMORY_144_CATALOG",
        "slot_count":144,
        "trace_start":1,
        "slots":tuple({"ordinal":n,"slot":slot,"canonical_function":name,"operator":op,"regime":regime,"domain_anchor":anchor}
                      for n,slot,name,op,regime,anchor in _CAUSAL_144_ROWS),
        "truth_credit":0,
    }


def memory_144_init(payload: Dict[str, Any] | None = None) -> Dict[str, Any]:
    payload=payload or {}
    flags=[False]*144; certified=[False]*144; hits=[0]*144; last=[None]*144
    body={
        "schema":_MEMORY_144_SCHEMA,
        "aux_name":AUX_NAME,
        "aux_version":AUX_VERSION,
        "slot_count":144,
        "trace_start":1,
        "next_trace":1,
        "flags":tuple(flags),
        "certified_flags":tuple(certified),
        "hit_counts":tuple(hits),
        "last_invariants_saved":tuple(last),
        "flag_mask_hex":_memory_144_flag_mask(flags),
        "certified_flag_mask_hex":_memory_144_flag_mask(certified),
        "trace_accumulator":_memory_144_empty_trace_hash(),
        "event_count":0,
        "raw_payload_policy":"DO_NOT_STORE_IF_RECONSTRUCTIBLE",
        "truth_credit":0,
        "root_write_capability":"NONE",
        "return_write_capability":"NONE",
        "solver_mutation_capability":"NONE",
    }
    out=dict(body); out["state_hash"]=_memory_144_state_hash(body)
    return {"status":"MEMORY_144_INITIALIZED","memory_valid":True,"state":out,"truth_credit":0}


def validate_memory_144_state(state: Dict[str, Any]) -> Dict[str, Any]:
    try:
        if not isinstance(state,dict) or state.get("schema")!=_MEMORY_144_SCHEMA: raise AuxError("invalid memory-144 schema")
        if int(state.get("slot_count",0))!=144 or int(state.get("trace_start",0))!=1: raise AuxError("memory grid must be 144 slots with trace start 1")
        flags=tuple(state.get("flags") or ()); cert=tuple(state.get("certified_flags") or ()); hits=tuple(state.get("hit_counts") or ()); last=tuple(state.get("last_invariants_saved") or ())
        if not (len(flags)==len(cert)==len(hits)==len(last)==144): raise AuxError("memory vector length mismatch")
        if any(int(x)<0 for x in hits): raise AuxError("negative hit count")
        if str(state.get("flag_mask_hex"))!=_memory_144_flag_mask(flags): raise AuxError("flag mask mismatch")
        if str(state.get("certified_flag_mask_hex"))!=_memory_144_flag_mask(cert): raise AuxError("certified flag mask mismatch")
        if not _hex64(state.get("trace_accumulator")): raise AuxError("invalid trace accumulator")
        next_trace=int(state.get("next_trace",0)); event_count=int(state.get("event_count",-1))
        if next_trace!=event_count+1 or next_trace<1: raise AuxError("trace counter mismatch")
        for i,rec in enumerate(last):
            if rec is None: continue
            row=_CAUSAL_144_ROWS[i]
            if rec.get("slot")!=row[1] or rec.get("operator")!=row[3]: raise AuxError("last invariant slot/operator mismatch")
            if int(rec.get("trace_index",0))<1 or int(rec.get("trace_index",0))>=next_trace: raise AuxError("last invariant trace index invalid")
            if not bool(cert[i]): raise AuxError("saved last invariant requires certified flag")
        supplied=str(state.get("state_hash","")); body={k:copy.deepcopy(v) for k,v in state.items() if k!="state_hash"}
        if supplied!=_memory_144_state_hash(body): raise AuxError("memory state hash mismatch")
        if int(state.get("truth_credit",-1))!=0 or state.get("root_write_capability")!="NONE" or state.get("return_write_capability")!="NONE" or state.get("solver_mutation_capability")!="NONE": raise AuxError("authority firewall violation")
        return {"status":"MEMORY_144_VALID","memory_valid":True,"state_hash":supplied,"event_count":event_count,"next_trace":next_trace,"flagged_slots":sum(map(bool,flags)),"truth_credit":0}
    except Exception as exc:
        return {"status":"INVALID_MEMORY_144","memory_valid":False,"error":str(exc),"truth_credit":0}


def _memory_144_normalize_signal(signal: Dict[str, Any], trace_index: int, datum_id: str, datum_hash: str | None) -> Tuple[int,Dict[str,Any]]:
    if not isinstance(signal,dict): raise AuxError("memory signal must be an object")
    op=str(signal.get("operator") or signal.get("invariant_operator") or "").strip().upper()
    if not op: raise AuxError("incoming data requires an invariant/operator signature")
    row=_CAUSAL_144_BY_OPERATOR.get(op)
    if row is None: raise AuxError(f"unknown canonical invariant/operator: {op}")
    n,slot,name,canon_op,regime,anchor=row
    supplied_slot=signal.get("slot")
    if supplied_slot not in (None,"") and str(supplied_slot).upper()!=slot: raise AuxError("data-declared slot disagrees with invariant/operator")
    rec={
        "slot":slot,
        "ordinal":n,
        "operator":canon_op,
        "canonical_function":name,
        "trace_index":trace_index,
        "datum_id":datum_id,
        "datum_hash":datum_hash,
        "projection":copy.deepcopy(signal.get("projection")),
        "domain":copy.deepcopy(signal.get("domain")),
        "context":copy.deepcopy(signal.get("context")),
        "residual":copy.deepcopy(signal.get("residual")),
        "reconstruction_ref":copy.deepcopy(signal.get("reconstruction_ref")),
        "certified":bool(signal.get("certified",False)),
    }
    return n-1,rec


def memory_144_drop(payload: Dict[str, Any]) -> Dict[str, Any]:
    state=payload.get("state") or {}
    vv=validate_memory_144_state(state)
    if not vv.get("memory_valid",False): return {"status":"MEMORY_144_DROP_REJECTED","memory_valid":False,"validation":vv,"truth_credit":0}
    try:
        trace_index=int(payload.get("trace_index",state["next_trace"]))
        if trace_index!=int(state["next_trace"]): raise AuxError("trace must continue exactly from next_trace; trace starts at 1")
        datum_id=str(payload.get("datum_id") or f"TRACE_{trace_index:09d}")
        raw=payload.get("data")
        datum_hash=payload.get("datum_hash")
        if datum_hash is None and raw is not None:
            datum_hash=hashlib.sha256(_canonical_for_hash(raw)).hexdigest()
        if datum_hash is not None and not _hex64(datum_hash): raise AuxError("datum_hash must be SHA-256 hex")
        signals=tuple(payload.get("signals") or ())
        if not signals: raise AuxError("data has no invariant signature; categories may not pull/classify the datum")
        normalized=[]; seen_slots=set()
        for sig in signals:
            idx,rec=_memory_144_normalize_signal(sig,trace_index,datum_id,str(datum_hash) if datum_hash is not None else None)
            if idx in seen_slots: raise AuxError("one datum may not duplicate the same invariant slot in one trace step")
            seen_slots.add(idx); normalized.append((idx,rec))
        flags=list(state["flags"]); cert=list(state["certified_flags"]); hits=list(state["hit_counts"]); last=list(copy.deepcopy(state["last_invariants_saved"]))
        for idx,rec in normalized:
            flags[idx]=True; hits[idx]=int(hits[idx])+1
            if rec["certified"]:
                cert[idx]=True
                # Last invariant saved: later certified data replaces the active projection for this slot.
                last[idx]=rec
        event_commit={
            "trace_index":trace_index,
            "datum_id":datum_id,
            "datum_hash":datum_hash,
            "flagged_slots":tuple(_CAUSAL_144_ROWS[idx][1] for idx,_ in normalized),
            "operators":tuple(rec["operator"] for _,rec in normalized),
            "certified":tuple(bool(rec["certified"]) for _,rec in normalized),
        }
        hh=hashlib.sha256(); hh.update(_MEMORY_144_TRACE_DOMAIN); hh.update(bytes.fromhex(str(state["trace_accumulator"]))); hh.update(_canonical_for_hash(event_commit))
        trace_acc=hh.hexdigest()
        body={
            "schema":_MEMORY_144_SCHEMA,
            "aux_name":AUX_NAME,
            "aux_version":AUX_VERSION,
            "slot_count":144,
            "trace_start":1,
            "next_trace":trace_index+1,
            "flags":tuple(flags),
            "certified_flags":tuple(cert),
            "hit_counts":tuple(hits),
            "last_invariants_saved":tuple(last),
            "flag_mask_hex":_memory_144_flag_mask(flags),
            "certified_flag_mask_hex":_memory_144_flag_mask(cert),
            "trace_accumulator":trace_acc,
            "event_count":int(state["event_count"])+1,
            "raw_payload_policy":"DO_NOT_STORE_IF_RECONSTRUCTIBLE",
            "truth_credit":0,
            "root_write_capability":"NONE",
            "return_write_capability":"NONE",
            "solver_mutation_capability":"NONE",
        }
        out=dict(body); out["state_hash"]=_memory_144_state_hash(body)
        check=validate_memory_144_state(out)
        if not check.get("memory_valid",False): raise AuxError("constructed memory state failed validation")
        return {
            "status":"MEMORY_144_DATA_DROPPED_TO_FLAGS",
            "memory_valid":True,
            "trace_index":trace_index,
            "datum_id":datum_id,
            "flagged_slots":event_commit["flagged_slots"],
            "flag_mask_hex":out["flag_mask_hex"],
            "last_invariants_updated":tuple(rec["slot"] for _,rec in normalized if rec["certified"]),
            "raw_payload_retained":False,
            "state":out,
            "truth_credit":0,
        }
    except Exception as exc:
        return {"status":"MEMORY_144_DROP_REJECTED","memory_valid":False,"error":str(exc),"truth_credit":0}


def memory_144_trace(payload: Dict[str, Any]) -> Dict[str, Any]:
    state=payload.get("state")
    if state is None: state=memory_144_init({})["state"]
    receipts=[]
    for event in tuple(payload.get("events") or ()):
        req=dict(event); req["state"]=state
        r=memory_144_drop(req); receipts.append(r)
        if not r.get("memory_valid",False): return {"status":"MEMORY_144_TRACE_REJECTED","memory_valid":False,"receipts":tuple(receipts),"truth_credit":0}
        state=r["state"]
    return {"status":"MEMORY_144_TRACE_COMPLETE","memory_valid":True,"trace_start":1,"event_count":state["event_count"],"next_trace":state["next_trace"],"state":state,"receipts":tuple(receipts),"truth_credit":0}


def memory_144_reconstruct(payload: Dict[str, Any]) -> Dict[str, Any]:
    state=payload.get("state") or payload
    vv=validate_memory_144_state(state)
    if not vv.get("memory_valid",False): return {"status":"MEMORY_144_RECONSTRUCTION_REJECTED","reconstruction_valid":False,"validation":vv,"truth_credit":0}
    slots=[]
    for i,rec in enumerate(state["last_invariants_saved"]):
        if rec is None: continue
        n,slot,name,op,regime,anchor=_CAUSAL_144_ROWS[i]
        slots.append({
            "slot":slot,
            "ordinal":n,
            "canonical_function":name,
            "operator":op,
            "regime":regime,
            "domain_anchor":anchor,
            "last_invariant":copy.deepcopy(rec),
            "hit_count":int(state["hit_counts"][i]),
        })
    return {
        "status":"MEMORY_144_LAST_INVARIANTS_RECONSTRUCTED",
        "reconstruction_valid":True,
        "trace_start":1,
        "event_count":state["event_count"],
        "trace_accumulator":state["trace_accumulator"],
        "flag_mask_hex":state["flag_mask_hex"],
        "certified_flag_mask_hex":state["certified_flag_mask_hex"],
        "active_last_invariants":tuple(slots),
        "raw_history_replay_claim":"NOT_CLAIMED_WITHOUT_EXTERNAL_RECONSTRUCTION_CONTRACT",
        "truth_credit":0,
    }


# ---------------------------------------------------------------------------
# PASS011 — memory-driven capability activation contracts
# ---------------------------------------------------------------------------

_MEMORY_144_ACTIVATION_SCHEMA = "HYPERTRIANGLE_CAUSAL_MEMORY_144_ACTIVATION_V1"
_MEMORY_144_ACTIVATION_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_ACTIVATION_V1\\0"
_MEMORY_144_CONTRACT_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_ACTIVATION_CONTRACTS_V1\\0"
_MEMORY_144_INVARIANT_COMMITMENT_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_LAST_INVARIANT_V1\\0"

# Only local, zero-authority solver-side capabilities are eligible for activation.
# PASS011 deliberately excludes sidecar/storage maintenance and all external solvers.
_MEMORY_144_ACTIVATABLE_CAPABILITIES = (
    "route_simplex",
    "route_transition",
    "signed_polarity",
    "b4_state",
    "robust_b4_state",
    "wall_event",
    "b4_route",
    "receipt_bundle",
    "receipt_stream",
    "stream_checkpoint",
    "resume_stream_checkpoint",
    "rotate_stream_checkpoint",
    "validate_checkpoint_chain",
    "rotate_bounded_checkpoint",
    "validate_bounded_checkpoint",
    "validate_bounded_checkpoint_chain",
    "rotate_witnessed_checkpoint",
    "validate_witnessed_checkpoint",
    "validate_witnessed_checkpoint_transition",
)


def _memory_144_activation_hash(body: Dict[str, Any]) -> str:
    h=hashlib.sha256(); h.update(_MEMORY_144_ACTIVATION_DOMAIN); h.update(_canonical_for_hash(body)); return h.hexdigest()


def _memory_144_contracts_hash(contracts: Sequence[Dict[str, Any]]) -> str:
    h=hashlib.sha256(); h.update(_MEMORY_144_CONTRACT_DOMAIN); h.update(_canonical_for_hash(tuple(contracts))); return h.hexdigest()


def _memory_144_last_invariant_commitment(rec: Dict[str, Any]) -> str:
    h=hashlib.sha256(); h.update(_MEMORY_144_INVARIANT_COMMITMENT_DOMAIN); h.update(_canonical_for_hash(rec)); return h.hexdigest()


def _memory_144_normalize_slot_list(value: Any, field: str) -> Tuple[str, ...]:
    raw=tuple(value or ())
    out=[]; seen=set()
    for x in raw:
        slot=str(x).strip().upper()
        if slot not in _CAUSAL_144_BY_SLOT: raise AuxError(f"{field} contains unknown canonical slot: {slot}")
        if slot in seen: raise AuxError(f"{field} contains duplicate slot: {slot}")
        seen.add(slot); out.append(slot)
    return tuple(sorted(out, key=lambda z:int(z[1:])))


def _memory_144_normalize_activation_contract(contract: Dict[str, Any]) -> Dict[str, Any]:
    if not isinstance(contract,dict): raise AuxError("activation contract must be an object")
    cid=str(contract.get("contract_id") or "").strip()
    if not cid: raise AuxError("activation contract requires contract_id")
    capability=str(contract.get("capability") or "").strip()
    if capability not in _MEMORY_144_ACTIVATABLE_CAPABILITIES:
        raise AuxError(f"activation target is not an allowed standalone AUX capability: {capability}")
    req_all=_memory_144_normalize_slot_list(contract.get("requires_all"),"requires_all")
    req_any=_memory_144_normalize_slot_list(contract.get("requires_any"),"requires_any")
    forbids=_memory_144_normalize_slot_list(contract.get("forbids"),"forbids")
    positive=set(req_all)|set(req_any)
    if not positive: raise AuxError("activation contract needs at least one positive certified-slot requirement")
    overlap=positive & set(forbids)
    if overlap: raise AuxError("activation contract cannot both require and forbid the same slot")
    return {
        "contract_id":cid,
        "capability":capability,
        "requires_all":req_all,
        "requires_any":req_any,
        "forbids":forbids,
        "evidence_policy":"CERTIFIED_LAST_INVARIANT_ONLY",
    }


def memory_144_activation_catalog(_: Dict[str, Any] | None = None) -> Dict[str, Any]:
    return {
        "status":"MEMORY_144_ACTIVATION_CATALOG",
        "schema":_MEMORY_144_ACTIVATION_SCHEMA,
        "activatable_capabilities":_MEMORY_144_ACTIVATABLE_CAPABILITIES,
        "contract_semantics":{
            "requires_all":"every listed slot must have a surviving certified last invariant",
            "requires_any":"if non-empty, at least one listed slot must have a surviving certified last invariant",
            "forbids":"no listed slot may have a surviving certified last invariant",
            "empty_positive_contract":"REJECTED",
            "undeclared_mapping":"NEVER_INFERRED",
            "execution":"NOT_PERFORMED_BY_ACTIVATION",
        },
        "direction":"DATA_TO_INVARIANT_SLOT_TO_ACTIVATION",
        "truth_credit":0,
        "root_write_capability":"NONE",
        "return_write_capability":"NONE",
        "solver_mutation_capability":"NONE",
    }


def _memory_144_evaluate_contract(contract: Dict[str, Any], certified_slots: set[str], last_by_slot: Dict[str, Dict[str, Any]] | None = None) -> Dict[str, Any]:
    req_all=tuple(contract["requires_all"]); req_any=tuple(contract["requires_any"]); forbids=tuple(contract["forbids"])
    matched_all=tuple(s for s in req_all if s in certified_slots)
    missing_all=tuple(s for s in req_all if s not in certified_slots)
    matched_any=tuple(s for s in req_any if s in certified_slots)
    forbidden_present=tuple(s for s in forbids if s in certified_slots)
    any_satisfied=(not req_any) or bool(matched_any)
    active=(not missing_all) and any_satisfied and (not forbidden_present)
    if forbidden_present: state="BLOCKED_FORBIDDEN"
    elif missing_all: state="INACTIVE_MISSING_ALL"
    elif not any_satisfied: state="INACTIVE_MISSING_ANY"
    else: state="ACTIVE"
    supporting=tuple(sorted(set(matched_all)|set(matched_any),key=lambda z:int(z[1:])))
    commitments=[]
    if last_by_slot is not None:
        for slot in supporting:
            rec=last_by_slot.get(slot)
            if rec is None: raise AuxError("certified activation support lacks surviving last invariant")
            commitments.append({"slot":slot,"last_invariant_commitment":_memory_144_last_invariant_commitment(rec),"trace_index":int(rec["trace_index"])})
    return {
        "contract_id":contract["contract_id"],
        "capability":contract["capability"],
        "activation_state":state,
        "active":active,
        "matched_all":matched_all,
        "missing_all":missing_all,
        "matched_any":matched_any,
        "any_requirement_satisfied":any_satisfied,
        "forbidden_present":forbidden_present,
        "supporting_slots":supporting,
        "supporting_last_invariants":tuple(commitments),
    }


def memory_144_activate(payload: Dict[str, Any]) -> Dict[str, Any]:
    state=payload.get("state") or {}
    vv=validate_memory_144_state(state)
    if not vv.get("memory_valid",False):
        return {"status":"MEMORY_144_ACTIVATION_REJECTED","activation_valid":False,"validation":vv,"truth_credit":0}
    try:
        normalized=[]; ids=set(); caps=set()
        for raw in tuple(payload.get("contracts") or ()):
            c=_memory_144_normalize_activation_contract(raw)
            if c["contract_id"] in ids: raise AuxError("duplicate activation contract_id")
            if c["capability"] in caps: raise AuxError("duplicate activation target capability; one canonical contract per target is required")
            ids.add(c["contract_id"]); caps.add(c["capability"]); normalized.append(c)
        normalized=tuple(sorted(normalized,key=lambda c:c["contract_id"]))
        certified_slots=set()
        last_by_slot={}
        for i,rec in enumerate(state["last_invariants_saved"]):
            if rec is not None:
                slot=_CAUSAL_144_ROWS[i][1]
                if not bool(state["certified_flags"][i]): raise AuxError("surviving last invariant without certified flag")
                certified_slots.add(slot); last_by_slot[slot]=rec
        evaluations=tuple(_memory_144_evaluate_contract(c,certified_slots,last_by_slot) for c in normalized)
        active_contracts=tuple(e["contract_id"] for e in evaluations if e["active"])
        active_capabilities=tuple(e["capability"] for e in evaluations if e["active"])
        body={
            "schema":_MEMORY_144_ACTIVATION_SCHEMA,
            "aux_name":AUX_NAME,
            "aux_version":AUX_VERSION,
            "memory_state_hash":state["state_hash"],
            "memory_trace_accumulator":state["trace_accumulator"],
            "memory_event_count":int(state["event_count"]),
            "memory_next_trace":int(state["next_trace"]),
            "certified_flag_mask_hex":state["certified_flag_mask_hex"],
            "certified_slots":tuple(sorted(certified_slots,key=lambda z:int(z[1:]))),
            "contracts":normalized,
            "contracts_hash":_memory_144_contracts_hash(normalized),
            "evaluations":evaluations,
            "active_contracts":active_contracts,
            "active_capabilities":active_capabilities,
            "execution_performed":False,
            "mapping_policy":"DECLARED_CONTRACTS_ONLY_NO_INFERRED_SLOT_TO_CAPABILITY_MAPPING",
            "truth_credit":0,
            "root_write_capability":"NONE",
            "return_write_capability":"NONE",
            "solver_mutation_capability":"NONE",
        }
        out=dict(body); out["activation_state_hash"]=_memory_144_activation_hash(body)
        return {
            "status":"MEMORY_144_ACTIVATION_EVALUATED" if normalized else "MEMORY_144_ACTIVATION_NO_DECLARED_CONTRACTS",
            "activation_valid":True,
            "active_capabilities":active_capabilities,
            "active_contracts":active_contracts,
            "receipt":out,
            "truth_credit":0,
        }
    except Exception as exc:
        return {"status":"MEMORY_144_ACTIVATION_REJECTED","activation_valid":False,"error":str(exc),"truth_credit":0}


def validate_memory_144_activation(payload: Dict[str, Any]) -> Dict[str, Any]:
    receipt=payload.get("receipt") or payload
    try:
        if not isinstance(receipt,dict) or receipt.get("schema")!=_MEMORY_144_ACTIVATION_SCHEMA: raise AuxError("invalid memory activation schema")
        if not _hex64(receipt.get("memory_state_hash")) or not _hex64(receipt.get("memory_trace_accumulator")): raise AuxError("invalid memory activation provenance hash")
        mask=str(receipt.get("certified_flag_mask_hex") or "")
        if len(mask)!=36 or any(ch not in "0123456789abcdefABCDEF" for ch in mask): raise AuxError("invalid certified flag mask")
        normalized=[]; ids=set(); caps=set()
        for raw in tuple(receipt.get("contracts") or ()):
            c=_memory_144_normalize_activation_contract(raw)
            if c["contract_id"] in ids or c["capability"] in caps: raise AuxError("duplicate activation contract identity/target")
            ids.add(c["contract_id"]); caps.add(c["capability"]); normalized.append(c)
        normalized=tuple(sorted(normalized,key=lambda c:c["contract_id"]))
        if str(receipt.get("contracts_hash"))!=_memory_144_contracts_hash(normalized): raise AuxError("activation contracts hash mismatch")
        certified_slots=tuple(receipt.get("certified_slots") or ())
        expected=[]
        value=int(mask,16)
        for i,row in enumerate(_CAUSAL_144_ROWS):
            if value & (1<<i): expected.append(row[1])
        if tuple(certified_slots)!=tuple(expected): raise AuxError("certified slots disagree with certified flag mask")
        expected_evals=tuple(_memory_144_evaluate_contract(c,set(expected),None) for c in normalized)
        supplied_evals=tuple(receipt.get("evaluations") or ())
        if len(supplied_evals)!=len(expected_evals): raise AuxError("activation evaluation count mismatch")
        # Compare semantic fields; evidence commitments are validated against a supplied memory state below when available.
        keys=("contract_id","capability","activation_state","active","matched_all","missing_all","matched_any","any_requirement_satisfied","forbidden_present","supporting_slots")
        for supplied,exp in zip(supplied_evals,expected_evals):
            for k in keys:
                if encode(supplied.get(k))!=encode(exp.get(k)): raise AuxError(f"activation evaluation mismatch: {k}")
        expected_active_contracts=tuple(e["contract_id"] for e in expected_evals if e["active"])
        expected_active_capabilities=tuple(e["capability"] for e in expected_evals if e["active"])
        if tuple(receipt.get("active_contracts") or ())!=expected_active_contracts: raise AuxError("active contract list mismatch")
        if tuple(receipt.get("active_capabilities") or ())!=expected_active_capabilities: raise AuxError("active capability list mismatch")
        if bool(receipt.get("execution_performed",True)): raise AuxError("activation layer must not execute capability")
        if receipt.get("mapping_policy")!="DECLARED_CONTRACTS_ONLY_NO_INFERRED_SLOT_TO_CAPABILITY_MAPPING": raise AuxError("invalid activation mapping policy")
        if int(receipt.get("truth_credit",-1))!=0 or receipt.get("root_write_capability")!="NONE" or receipt.get("return_write_capability")!="NONE" or receipt.get("solver_mutation_capability")!="NONE": raise AuxError("authority firewall violation")
        supplied_hash=str(receipt.get("activation_state_hash") or ""); body={k:copy.deepcopy(v) for k,v in receipt.items() if k!="activation_state_hash"}
        if supplied_hash!=_memory_144_activation_hash(body): raise AuxError("activation state hash mismatch")
        # Optional full evidence binding against the exact memory state.
        state=payload.get("state")
        if state is not None:
            vv=validate_memory_144_state(state)
            if not vv.get("memory_valid",False): raise AuxError("supplied memory state invalid")
            if state["state_hash"]!=receipt["memory_state_hash"] or state["certified_flag_mask_hex"]!=mask: raise AuxError("activation receipt does not bind supplied memory state")
            rebuilt=memory_144_activate({"state":state,"contracts":normalized})
            if not rebuilt.get("activation_valid",False): raise AuxError("activation replay failed")
            if rebuilt["receipt"]["activation_state_hash"]!=supplied_hash: raise AuxError("activation replay hash mismatch")
        return {"status":"MEMORY_144_ACTIVATION_VALID","activation_valid":True,"activation_state_hash":supplied_hash,"active_capabilities":expected_active_capabilities,"truth_credit":0}
    except Exception as exc:
        return {"status":"INVALID_MEMORY_144_ACTIVATION","activation_valid":False,"error":str(exc),"truth_credit":0}


# ---------------------------------------------------------------------------
# PASS012 — activation -> typed request -> local capability receipt bridge
# ---------------------------------------------------------------------------

_MEMORY_144_CAPABILITY_REQUEST_SCHEMA = "HYPERTRIANGLE_CAUSAL_MEMORY_144_TYPED_CAPABILITY_REQUEST_V1"
_MEMORY_144_CAPABILITY_EXECUTION_SCHEMA = "HYPERTRIANGLE_CAUSAL_MEMORY_144_CAPABILITY_EXECUTION_V1"
_MEMORY_144_CAPABILITY_REQUEST_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_CAPABILITY_REQUEST_V1\\0"
_MEMORY_144_CAPABILITY_EXECUTION_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_CAPABILITY_EXECUTION_V1\\0"
_MEMORY_144_CAPABILITY_PAYLOAD_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_CAPABILITY_PAYLOAD_V1\\0"
_MEMORY_144_CAPABILITY_RECEIPT_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_CAPABILITY_RECEIPT_V1\\0"


def _memory_144_capability_payload_hash(payload: Dict[str, Any]) -> str:
    h=hashlib.sha256(); h.update(_MEMORY_144_CAPABILITY_PAYLOAD_DOMAIN); h.update(_canonical_for_hash(payload)); return h.hexdigest()


def _memory_144_capability_request_hash(body: Dict[str, Any]) -> str:
    h=hashlib.sha256(); h.update(_MEMORY_144_CAPABILITY_REQUEST_DOMAIN); h.update(_canonical_for_hash(body)); return h.hexdigest()


def _memory_144_capability_receipt_hash(receipt: Dict[str, Any]) -> str:
    h=hashlib.sha256(); h.update(_MEMORY_144_CAPABILITY_RECEIPT_DOMAIN); h.update(_canonical_for_hash(receipt)); return h.hexdigest()


def _memory_144_capability_execution_hash(body: Dict[str, Any]) -> str:
    h=hashlib.sha256(); h.update(_MEMORY_144_CAPABILITY_EXECUTION_DOMAIN); h.update(_canonical_for_hash(body)); return h.hexdigest()


def _memory_144_active_evaluation(activation: Dict[str, Any], capability: str, contract_id: str | None = None) -> Dict[str, Any]:
    matches=[]
    for ev in tuple(activation.get("evaluations") or ()):
        if ev.get("capability")==capability and bool(ev.get("active",False)):
            if contract_id is None or str(ev.get("contract_id"))==str(contract_id):
                matches.append(ev)
    if not matches:
        raise AuxError("target capability is not active in supplied activation receipt")
    if len(matches)!=1:
        raise AuxError("activation receipt does not identify one canonical active contract for target capability")
    return matches[0]


def memory_144_compile_capability_request(payload: Dict[str, Any]) -> Dict[str, Any]:
    activation=payload.get("activation_receipt") or {}
    state=payload.get("state")
    vv=validate_memory_144_activation({"receipt":activation, **({"state":state} if state is not None else {})})
    if not vv.get("activation_valid",False):
        return {"status":"MEMORY_144_CAPABILITY_REQUEST_REJECTED","request_valid":False,"activation_validation":vv,"truth_credit":0}
    try:
        capability=str(payload.get("capability") or "").strip()
        if capability not in _MEMORY_144_ACTIVATABLE_CAPABILITIES:
            raise AuxError("target capability is outside PASS012 standalone activation-execution boundary")
        contract_id=payload.get("contract_id")
        ev=_memory_144_active_evaluation(activation,capability,None if contract_id in (None,"") else str(contract_id))
        cap_payload=payload.get("capability_payload")
        if not isinstance(cap_payload,dict): raise AuxError("capability_payload must be an explicit object")
        support=tuple(copy.deepcopy(ev.get("supporting_last_invariants") or ()))
        # PASS012 has no reverse channel: capability output can never become memory evidence here.
        body={
            "schema":_MEMORY_144_CAPABILITY_REQUEST_SCHEMA,
            "aux_name":AUX_NAME,
            "aux_version":AUX_VERSION,
            "source_memory_state_hash":activation["memory_state_hash"],
            "source_memory_trace_accumulator":activation["memory_trace_accumulator"],
            "source_memory_event_count":int(activation["memory_event_count"]),
            "source_activation_state_hash":activation["activation_state_hash"],
            "source_contracts_hash":activation["contracts_hash"],
            "source_contract_id":str(ev["contract_id"]),
            "supporting_slots":tuple(ev.get("supporting_slots") or ()),
            "supporting_last_invariants":support,
            "target_capability":capability,
            "capability_payload":copy.deepcopy(cap_payload),
            "capability_payload_hash":_memory_144_capability_payload_hash(cap_payload),
            "causal_parent":{"type":"MEMORY_144_ACTIVATION_STATE","hash":activation["activation_state_hash"]},
            "causal_generation":1,
            "execution_policy":"EXPLICIT_ACTIVE_CONTRACT_LOCAL_PURE_EXECUTION_ONLY",
            "memory_feedback_policy":"FORBIDDEN_NO_AUTOMATIC_MEMORY_DROP_OR_REACTIVATION",
            "truth_credit":0,
            "root_write_capability":"NONE",
            "return_write_capability":"NONE",
            "solver_mutation_capability":"NONE",
        }
        out=dict(body); out["typed_request_hash"]=_memory_144_capability_request_hash(body)
        return {"status":"MEMORY_144_TYPED_CAPABILITY_REQUEST_COMPILED","request_valid":True,"request":out,"truth_credit":0}
    except Exception as exc:
        return {"status":"MEMORY_144_CAPABILITY_REQUEST_REJECTED","request_valid":False,"error":str(exc),"truth_credit":0}


def validate_memory_144_capability_request(payload: Dict[str, Any]) -> Dict[str, Any]:
    req=payload.get("request") or payload
    try:
        if not isinstance(req,dict) or req.get("schema")!=_MEMORY_144_CAPABILITY_REQUEST_SCHEMA: raise AuxError("invalid typed capability request schema")
        cap=str(req.get("target_capability") or "")
        if cap not in _MEMORY_144_ACTIVATABLE_CAPABILITIES: raise AuxError("typed request target not executable in PASS012 boundary")
        for k in ("source_memory_state_hash","source_memory_trace_accumulator","source_activation_state_hash","source_contracts_hash","capability_payload_hash","typed_request_hash"):
            if not _hex64(req.get(k)): raise AuxError(f"invalid provenance hash: {k}")
        if not isinstance(req.get("capability_payload"),dict): raise AuxError("typed request capability_payload must be an object")
        if req["capability_payload_hash"]!=_memory_144_capability_payload_hash(req["capability_payload"]): raise AuxError("capability payload hash mismatch")
        if int(req.get("causal_generation",-1))!=1: raise AuxError("PASS012 typed request causal generation must be 1")
        parent=req.get("causal_parent") or {}
        if parent.get("type")!="MEMORY_144_ACTIVATION_STATE" or parent.get("hash")!=req.get("source_activation_state_hash"): raise AuxError("typed request causal parent mismatch")
        if req.get("execution_policy")!="EXPLICIT_ACTIVE_CONTRACT_LOCAL_PURE_EXECUTION_ONLY": raise AuxError("invalid execution policy")
        if req.get("memory_feedback_policy")!="FORBIDDEN_NO_AUTOMATIC_MEMORY_DROP_OR_REACTIVATION": raise AuxError("memory feedback firewall missing")
        if int(req.get("truth_credit",-1))!=0 or req.get("root_write_capability")!="NONE" or req.get("return_write_capability")!="NONE" or req.get("solver_mutation_capability")!="NONE": raise AuxError("authority firewall violation")
        supplied=req["typed_request_hash"]; body={k:copy.deepcopy(v) for k,v in req.items() if k!="typed_request_hash"}
        if supplied!=_memory_144_capability_request_hash(body): raise AuxError("typed request hash mismatch")
        activation=payload.get("activation_receipt")
        if activation is not None:
            av=validate_memory_144_activation({"receipt":activation, **({"state":payload["state"]} if payload.get("state") is not None else {})})
            if not av.get("activation_valid",False): raise AuxError("supplied activation receipt invalid")
            if activation["activation_state_hash"]!=req["source_activation_state_hash"] or activation["memory_state_hash"]!=req["source_memory_state_hash"] or activation["contracts_hash"]!=req["source_contracts_hash"]: raise AuxError("typed request does not bind supplied activation receipt")
            ev=_memory_144_active_evaluation(activation,cap,req["source_contract_id"])
            if tuple(ev.get("supporting_slots") or ())!=tuple(req.get("supporting_slots") or ()): raise AuxError("typed request supporting slots mismatch")
            if encode(tuple(ev.get("supporting_last_invariants") or ()))!=encode(tuple(req.get("supporting_last_invariants") or ())): raise AuxError("typed request supporting invariant commitments mismatch")
        return {"status":"MEMORY_144_TYPED_CAPABILITY_REQUEST_VALID","request_valid":True,"typed_request_hash":supplied,"target_capability":cap,"truth_credit":0}
    except Exception as exc:
        return {"status":"INVALID_MEMORY_144_TYPED_CAPABILITY_REQUEST","request_valid":False,"error":str(exc),"truth_credit":0}


def _execute_memory_activated_local_capability(capability: str, payload: Dict[str, Any]) -> Dict[str, Any]:
    # Deliberately mirrors only the 19 PASS011 activatable local AUX operations.
    if capability == "route_simplex": return compile_route(payload)
    if capability == "route_transition": return classify_route_transition(payload.get("previous") or {}, payload.get("current") or {}, bool(payload.get("same_ledger",True)))
    if capability == "signed_polarity": return signed_polarity(payload.get("values") or ())
    if capability == "b4_state": return b4_state(payload)
    if capability == "robust_b4_state": return robust_b4_state(payload)
    if capability == "wall_event": return certify_wall_event(payload)
    if capability == "b4_route": return certify_b4_route(payload)
    if capability == "receipt_bundle": return certify_receipt_bundle(payload)
    if capability == "receipt_stream": return certify_receipt_stream(payload)
    if capability == "stream_checkpoint": return create_stream_checkpoint(payload)
    if capability == "resume_stream_checkpoint": return resume_stream_checkpoint(payload)
    if capability == "rotate_stream_checkpoint": return rotate_stream_checkpoint(payload)
    if capability == "validate_checkpoint_chain": return validate_checkpoint_chain(payload)
    if capability == "rotate_bounded_checkpoint": return rotate_bounded_checkpoint(payload)
    if capability == "validate_bounded_checkpoint": return validate_bounded_stream_checkpoint(payload.get("checkpoint") or payload)
    if capability == "validate_bounded_checkpoint_chain": return validate_bounded_checkpoint_chain(payload)
    if capability == "rotate_witnessed_checkpoint": return rotate_witnessed_checkpoint(payload)
    if capability == "validate_witnessed_checkpoint": return validate_witnessed_checkpoint(payload.get("checkpoint") or payload)
    if capability == "validate_witnessed_checkpoint_transition": return validate_witnessed_checkpoint_transition(payload)
    raise AuxError("capability cannot execute through PASS012 bridge")


def memory_144_execute_capability(payload: Dict[str, Any]) -> Dict[str, Any]:
    req=payload.get("request") or {}
    vv=validate_memory_144_capability_request({"request":req, **({"activation_receipt":payload["activation_receipt"]} if payload.get("activation_receipt") is not None else {}), **({"state":payload["state"]} if payload.get("state") is not None else {})})
    if not vv.get("request_valid",False):
        return {"status":"MEMORY_144_CAPABILITY_EXECUTION_REJECTED","execution_valid":False,"request_validation":vv,"truth_credit":0}
    try:
        capability=req["target_capability"]
        local=_execute_memory_activated_local_capability(capability,copy.deepcopy(req["capability_payload"]))
        local_enc=encode(local)
        local_hash=_memory_144_capability_receipt_hash(local_enc)
        body={
            "schema":_MEMORY_144_CAPABILITY_EXECUTION_SCHEMA,
            "aux_name":AUX_NAME,
            "aux_version":AUX_VERSION,
            "source_memory_state_hash":req["source_memory_state_hash"],
            "source_activation_state_hash":req["source_activation_state_hash"],
            "source_contract_id":req["source_contract_id"],
            "typed_request_hash":req["typed_request_hash"],
            "target_capability":capability,
            "capability_payload_hash":req["capability_payload_hash"],
            "capability_receipt":local_enc,
            "capability_receipt_hash":local_hash,
            "causal_parent":{"type":"MEMORY_144_TYPED_CAPABILITY_REQUEST","hash":req["typed_request_hash"]},
            "causal_generation":2,
            "execution_count":1,
            "execution_semantics":"PURE_DETERMINISTIC_LOCAL_AUX_NO_EXTERNAL_SIDE_EFFECT",
            "memory_feedback_performed":False,
            "memory_feedback_policy":"FORBIDDEN_NO_AUTOMATIC_MEMORY_DROP_OR_REACTIVATION",
            "activation_reentry_performed":False,
            "truth_credit":0,
            "root_write_capability":"NONE",
            "return_write_capability":"NONE",
            "solver_mutation_capability":"NONE",
        }
        out=dict(body); out["capability_execution_hash"]=_memory_144_capability_execution_hash(body)
        return {"status":"MEMORY_144_ACTIVATED_CAPABILITY_EXECUTED","execution_valid":True,"receipt":out,"truth_credit":0}
    except Exception as exc:
        return {"status":"MEMORY_144_CAPABILITY_EXECUTION_REJECTED","execution_valid":False,"error":str(exc),"truth_credit":0}


def validate_memory_144_capability_execution(payload: Dict[str, Any]) -> Dict[str, Any]:
    rec=payload.get("receipt") or payload
    try:
        if not isinstance(rec,dict) or rec.get("schema")!=_MEMORY_144_CAPABILITY_EXECUTION_SCHEMA: raise AuxError("invalid capability execution schema")
        cap=str(rec.get("target_capability") or "")
        if cap not in _MEMORY_144_ACTIVATABLE_CAPABILITIES: raise AuxError("execution target outside PASS012 boundary")
        for k in ("source_memory_state_hash","source_activation_state_hash","typed_request_hash","capability_payload_hash","capability_receipt_hash","capability_execution_hash"):
            if not _hex64(rec.get(k)): raise AuxError(f"invalid execution provenance hash: {k}")
        if rec["capability_receipt_hash"]!=_memory_144_capability_receipt_hash(rec.get("capability_receipt") or {}): raise AuxError("capability receipt hash mismatch")
        parent=rec.get("causal_parent") or {}
        if parent.get("type")!="MEMORY_144_TYPED_CAPABILITY_REQUEST" or parent.get("hash")!=rec["typed_request_hash"]: raise AuxError("capability execution causal parent mismatch")
        if int(rec.get("causal_generation",-1))!=2 or int(rec.get("execution_count",-1))!=1: raise AuxError("invalid PASS012 execution generation/count")
        if rec.get("execution_semantics")!="PURE_DETERMINISTIC_LOCAL_AUX_NO_EXTERNAL_SIDE_EFFECT": raise AuxError("invalid execution semantics")
        if bool(rec.get("memory_feedback_performed",True)) or bool(rec.get("activation_reentry_performed",True)): raise AuxError("feedback/reentry firewall violation")
        if rec.get("memory_feedback_policy")!="FORBIDDEN_NO_AUTOMATIC_MEMORY_DROP_OR_REACTIVATION": raise AuxError("memory feedback policy mismatch")
        if int(rec.get("truth_credit",-1))!=0 or rec.get("root_write_capability")!="NONE" or rec.get("return_write_capability")!="NONE" or rec.get("solver_mutation_capability")!="NONE": raise AuxError("authority firewall violation")
        supplied=rec["capability_execution_hash"]; body={k:copy.deepcopy(v) for k,v in rec.items() if k!="capability_execution_hash"}
        if supplied!=_memory_144_capability_execution_hash(body): raise AuxError("capability execution hash mismatch")
        req=payload.get("request")
        if req is not None:
            rv=validate_memory_144_capability_request({"request":req, **({"activation_receipt":payload["activation_receipt"]} if payload.get("activation_receipt") is not None else {}), **({"state":payload["state"]} if payload.get("state") is not None else {})})
            if not rv.get("request_valid",False): raise AuxError("supplied typed request invalid")
            if req["typed_request_hash"]!=rec["typed_request_hash"] or req["target_capability"]!=cap or req["source_activation_state_hash"]!=rec["source_activation_state_hash"] or req["source_memory_state_hash"]!=rec["source_memory_state_hash"]: raise AuxError("execution receipt does not bind supplied typed request")
            # Full deterministic replay: capability output must be byte-semantically identical.
            replay=encode(_execute_memory_activated_local_capability(cap,copy.deepcopy(req["capability_payload"])))
            if _memory_144_capability_receipt_hash(replay)!=rec["capability_receipt_hash"] or replay!=rec["capability_receipt"]: raise AuxError("capability deterministic replay mismatch")
        return {"status":"MEMORY_144_CAPABILITY_EXECUTION_VALID","execution_valid":True,"capability_execution_hash":supplied,"capability_receipt_hash":rec["capability_receipt_hash"],"target_capability":cap,"truth_credit":0}
    except Exception as exc:
        return {"status":"INVALID_MEMORY_144_CAPABILITY_EXECUTION","execution_valid":False,"error":str(exc),"truth_credit":0}


def memory_144_activation_to_capability(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Convenience composition preserving the two typed receipts as separate proof objects."""
    compiled=memory_144_compile_capability_request(payload)
    if not compiled.get("request_valid",False): return compiled
    executed=memory_144_execute_capability({"request":compiled["request"],"activation_receipt":payload.get("activation_receipt"),"state":payload.get("state")})
    if not executed.get("execution_valid",False): return executed
    return {
        "status":"MEMORY_144_ACTIVATION_TO_CAPABILITY_COMPLETE",
        "bridge_valid":True,
        "request":compiled["request"],
        "execution_receipt":executed["receipt"],
        "memory_feedback_performed":False,
        "truth_credit":0,
    }

# ---------------------------------------------------------------------------
# PASS013 — unified memory / activation / capability persistent checkpoint
# ---------------------------------------------------------------------------

_MEMORY_144_PIPELINE_EVENT_SCHEMA = "HYPERTRIANGLE_CAUSAL_MEMORY_144_PIPELINE_EVENT_V1"
_MEMORY_144_UNIFIED_CHECKPOINT_SCHEMA = "HYPERTRIANGLE_CAUSAL_MEMORY_144_UNIFIED_CHECKPOINT_V1"
_MEMORY_144_PIPELINE_EVENT_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_PIPELINE_EVENT_V1\\0"
_MEMORY_144_PIPELINE_HISTORY_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_PIPELINE_HISTORY_V1\\0"
_MEMORY_144_UNIFIED_CHECKPOINT_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_UNIFIED_CHECKPOINT_V1\\0"
_MEMORY_144_UNIFIED_SUFFIX_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_UNIFIED_SUFFIX_V1\\0"
_MEMORY_144_PIPELINE_EVENT_TYPES = ("MEMORY_DROP", "ACTIVATE", "CAPABILITY")


def _memory_144_pipeline_history_seed() -> str:
    h=hashlib.sha256(); h.update(_MEMORY_144_PIPELINE_HISTORY_DOMAIN); h.update(b"START:1")
    return h.hexdigest()


def _memory_144_pipeline_event_hash(event: Dict[str, Any]) -> str:
    h=hashlib.sha256(); h.update(_MEMORY_144_PIPELINE_EVENT_DOMAIN); h.update(_canonical_for_hash(event)); return h.hexdigest()


def _memory_144_pipeline_history_step(previous: str, receipt: Dict[str, Any]) -> str:
    if not _hex64(previous): raise AuxError("invalid memory-144 pipeline history accumulator")
    h=hashlib.sha256(); h.update(_MEMORY_144_PIPELINE_HISTORY_DOMAIN); h.update(b"STEP\\0"); h.update(bytes.fromhex(previous)); h.update(_canonical_for_hash(receipt)); return h.hexdigest()


def _memory_144_unified_checkpoint_hash(body: Dict[str, Any]) -> str:
    h=hashlib.sha256(); h.update(_MEMORY_144_UNIFIED_CHECKPOINT_DOMAIN); h.update(_canonical_for_hash(body)); return h.hexdigest()


def _memory_144_unified_suffix_commitment(receipts: Sequence[Dict[str, Any]]) -> str:
    h=hashlib.sha256(); h.update(_MEMORY_144_UNIFIED_SUFFIX_DOMAIN); h.update(_canonical_for_hash(tuple(receipts))); return h.hexdigest()


def _memory_144_normalize_pipeline_event(raw: Dict[str, Any], expected_sequence: int) -> Dict[str, Any]:
    if not isinstance(raw,dict): raise AuxError("pipeline event must be an object")
    event_id=str(raw.get("event_id") or raw.get("receipt_id") or "").strip()
    if not event_id: raise AuxError("pipeline event requires event_id")
    sequence=int(raw.get("sequence",expected_sequence))
    if sequence!=expected_sequence: raise AuxError("pipeline event sequence mismatch")
    kind=str(raw.get("type") or raw.get("event_type") or "").upper().strip()
    if kind not in _MEMORY_144_PIPELINE_EVENT_TYPES: raise AuxError("unsupported memory-144 pipeline event type")
    body={"schema":_MEMORY_144_PIPELINE_EVENT_SCHEMA,"event_id":event_id,"sequence":sequence,"type":kind}
    if kind=="MEMORY_DROP":
        body["datum_id"]=copy.deepcopy(raw.get("datum_id"))
        body["datum_hash"]=copy.deepcopy(raw.get("datum_hash"))
        body["data"]=copy.deepcopy(raw.get("data"))
        body["signals"]=tuple(copy.deepcopy(raw.get("signals") or ()))
        if not body["signals"]: raise AuxError("MEMORY_DROP pipeline event requires signals")
    elif kind=="ACTIVATE":
        body["contracts"]=tuple(copy.deepcopy(raw.get("contracts") or ()))
    elif kind=="CAPABILITY":
        body["capability"]=str(raw.get("capability") or "")
        if not body["capability"]: raise AuxError("CAPABILITY pipeline event requires capability")
        if not isinstance(raw.get("capability_payload"),dict): raise AuxError("CAPABILITY pipeline event requires explicit capability_payload object")
        body["capability_payload"]=copy.deepcopy(raw.get("capability_payload"))
        if raw.get("contract_id") not in (None,""): body["contract_id"]=str(raw.get("contract_id"))
    out=dict(body); out["event_hash"]=_memory_144_pipeline_event_hash(body)
    return out


def _memory_144_pipeline_context_from_scratch() -> Dict[str, Any]:
    return {
        "memory_state":memory_144_init({})["state"],
        "activation_receipt":None,
        "pipeline_event_count":0,
        "next_pipeline_sequence":1,
        "pipeline_history_accumulator":_memory_144_pipeline_history_seed(),
        "memory_drop_count":0,
        "activation_count":0,
        "typed_request_count":0,
        "capability_execution_count":0,
        "latest_typed_request_summary":None,
        "latest_capability_execution_summary":None,
    }


def _memory_144_pipeline_context_from_checkpoint(checkpoint: Dict[str, Any]) -> Dict[str, Any]:
    return {
        "memory_state":copy.deepcopy(checkpoint["memory_state"]),
        "activation_receipt":copy.deepcopy(checkpoint.get("activation_receipt")),
        "pipeline_event_count":int(checkpoint["pipeline_event_count"]),
        "next_pipeline_sequence":int(checkpoint["next_pipeline_sequence"]),
        "pipeline_history_accumulator":str(checkpoint["pipeline_history_accumulator"]),
        "memory_drop_count":int(checkpoint["memory_drop_count"]),
        "activation_count":int(checkpoint["activation_count"]),
        "typed_request_count":int(checkpoint["typed_request_count"]),
        "capability_execution_count":int(checkpoint["capability_execution_count"]),
        "latest_typed_request_summary":copy.deepcopy(checkpoint.get("latest_typed_request_summary")),
        "latest_capability_execution_summary":copy.deepcopy(checkpoint.get("latest_capability_execution_summary")),
    }


def _memory_144_pipeline_apply_event(context: Dict[str, Any], event: Dict[str, Any]) -> Tuple[Dict[str, Any],Dict[str,Any]]:
    ctx=copy.deepcopy(context)
    seq=int(event["sequence"]); kind=event["type"]
    if seq!=int(ctx["next_pipeline_sequence"]): raise AuxError("pipeline continuation sequence mismatch")
    outcome: Dict[str,Any]
    if kind=="MEMORY_DROP":
        req={
            "state":ctx["memory_state"],
            "datum_id":event.get("datum_id"),
            "datum_hash":event.get("datum_hash"),
            "data":event.get("data"),
            "signals":copy.deepcopy(event.get("signals") or ()),
        }
        r=memory_144_drop(req)
        if not r.get("memory_valid",False): raise AuxError("pipeline MEMORY_DROP rejected: "+str(r.get("error") or r.get("status")))
        ctx["memory_state"]=r["state"]
        # Any memory mutation invalidates the current activation receipt.  A fresh ACTIVATE event is required.
        ctx["activation_receipt"]=None
        ctx["memory_drop_count"]+=1
        outcome={
            "memory_state_hash":r["state"]["state_hash"],
            "memory_trace_accumulator":r["state"]["trace_accumulator"],
            "memory_trace_index":int(r["trace_index"]),
            "flagged_slots":tuple(r.get("flagged_slots") or ()),
            "activation_invalidated":True,
        }
    elif kind=="ACTIVATE":
        r=memory_144_activate({"state":ctx["memory_state"],"contracts":copy.deepcopy(event.get("contracts") or ())})
        if not r.get("activation_valid",False): raise AuxError("pipeline ACTIVATE rejected: "+str(r.get("error") or r.get("status")))
        ctx["activation_receipt"]=r["receipt"]
        ctx["activation_count"]+=1
        outcome={
            "memory_state_hash":ctx["memory_state"]["state_hash"],
            "activation_state_hash":r["receipt"]["activation_state_hash"],
            "active_contracts":tuple(r["receipt"].get("active_contracts") or ()),
            "active_capabilities":tuple(r["receipt"].get("active_capabilities") or ()),
        }
    else:
        activation=ctx.get("activation_receipt")
        if activation is None: raise AuxError("pipeline CAPABILITY requires a fresh activation receipt for the current memory state")
        av=validate_memory_144_activation({"receipt":activation,"state":ctx["memory_state"]})
        if not av.get("activation_valid",False): raise AuxError("pipeline current activation receipt is stale or invalid")
        req={
            "state":ctx["memory_state"],
            "activation_receipt":activation,
            "capability":event["capability"],
            "capability_payload":copy.deepcopy(event["capability_payload"]),
        }
        if event.get("contract_id") is not None: req["contract_id"]=event["contract_id"]
        b=memory_144_activation_to_capability(req)
        if not b.get("bridge_valid",False): raise AuxError("pipeline CAPABILITY rejected: "+str(b.get("error") or b.get("status")))
        q=b["request"]; x=b["execution_receipt"]
        ctx["typed_request_count"]+=1; ctx["capability_execution_count"]+=1
        ctx["latest_typed_request_summary"]={
            "typed_request_hash":q["typed_request_hash"],"target_capability":q["target_capability"],
            "source_memory_state_hash":q["source_memory_state_hash"],"source_activation_state_hash":q["source_activation_state_hash"],
            "source_contract_id":q["source_contract_id"],"capability_payload_hash":q["capability_payload_hash"],
        }
        ctx["latest_capability_execution_summary"]={
            "capability_execution_hash":x["capability_execution_hash"],"typed_request_hash":x["typed_request_hash"],
            "target_capability":x["target_capability"],"capability_receipt_hash":x["capability_receipt_hash"],
            "source_memory_state_hash":x["source_memory_state_hash"],"source_activation_state_hash":x["source_activation_state_hash"],
        }
        outcome={
            "memory_state_hash":ctx["memory_state"]["state_hash"],
            "activation_state_hash":activation["activation_state_hash"],
            "typed_request_hash":q["typed_request_hash"],
            "capability_execution_hash":x["capability_execution_hash"],
            "capability_receipt_hash":x["capability_receipt_hash"],
            "target_capability":x["target_capability"],
            "memory_feedback_performed":False,
            "activation_reentry_performed":False,
        }
    receipt_body={
        "event_id":event["event_id"],"sequence":seq,"type":kind,"event_hash":event["event_hash"],"outcome":outcome,
    }
    acc=_memory_144_pipeline_history_step(ctx["pipeline_history_accumulator"],receipt_body)
    ctx["pipeline_event_count"]+=1; ctx["next_pipeline_sequence"]+=1; ctx["pipeline_history_accumulator"]=acc
    receipt=dict(receipt_body); receipt["pipeline_history_accumulator"]=acc
    return ctx,receipt


def _memory_144_unified_projection(context: Dict[str, Any], event_id_root: str, event_id_count: int) -> Dict[str, Any]:
    activation=context.get("activation_receipt")
    latest_q=context.get("latest_typed_request_summary")
    latest_x=context.get("latest_capability_execution_summary")
    return {
        "memory_state_hash":context["memory_state"]["state_hash"],
        "memory_trace_accumulator":context["memory_state"]["trace_accumulator"],
        "memory_event_count":int(context["memory_state"]["event_count"]),
        "activation_state_hash":activation.get("activation_state_hash") if activation else None,
        "pipeline_event_count":int(context["pipeline_event_count"]),
        "next_pipeline_sequence":int(context["next_pipeline_sequence"]),
        "pipeline_history_accumulator":str(context["pipeline_history_accumulator"]),
        "memory_drop_count":int(context["memory_drop_count"]),
        "activation_count":int(context["activation_count"]),
        "typed_request_count":int(context["typed_request_count"]),
        "capability_execution_count":int(context["capability_execution_count"]),
        "latest_typed_request_hash":latest_q.get("typed_request_hash") if latest_q else None,
        "latest_capability_execution_hash":latest_x.get("capability_execution_hash") if latest_x else None,
        "event_id_root":str(event_id_root),
        "event_id_count":int(event_id_count),
    }


def memory_144_pipeline_replay(payload: Dict[str, Any]) -> Dict[str, Any]:
    """Full replay from START=1. Historical event payloads are available, so exact ID membership is built directly."""
    try:
        events=tuple(payload.get("events") or ())
        ctx=_memory_144_pipeline_context_from_scratch(); idx=ExternalReceiptIdIndex(); receipts=[]; normalized=[]
        for raw in events:
            ev=_memory_144_normalize_pipeline_event(raw,int(ctx["next_pipeline_sequence"]))
            if idx.proof(ev["event_id"]).get("present"): raise AuxError("duplicate pipeline event_id")
            ins=idx.insert(ev["event_id"])
            if not ins.get("inserted",False): raise AuxError("pipeline event-id insertion failed")
            ctx,rr=_memory_144_pipeline_apply_event(ctx,ev); receipts.append(rr); normalized.append(ev)
        projection=_memory_144_unified_projection(ctx,idx.root,len(idx.ids))
        return {
            "status":"MEMORY_144_UNIFIED_PIPELINE_REPLAY_COMPLETE","unified_valid":True,
            "context":ctx,"projection":projection,"event_receipts":tuple(receipts),"normalized_events":tuple(normalized),
            "event_ids":tuple(ev["event_id"] for ev in normalized),
            "truth_credit":0,
        }
    except Exception as exc:
        return {"status":"MEMORY_144_UNIFIED_PIPELINE_REPLAY_REJECTED","unified_valid":False,"error":str(exc),"truth_credit":0}


def _memory_144_build_unified_checkpoint(context: Dict[str, Any], *, sidecar_snapshot: Dict[str, Any], sidecar_chain_state: Dict[str, Any], rotation_index: int, previous_checkpoint_hash: str | None, checkpoint_chain_root_hash: str | None, parent_pipeline_history_accumulator: str | None, rotation_suffix_event_count: int, rotation_suffix_commitment: str | None) -> Dict[str, Any]:
    sv=validate_receipt_id_sidecar_snapshot(sidecar_snapshot)
    if not sv.get("snapshot_valid",False): raise AuxError("invalid exact-ID sidecar snapshot for unified checkpoint")
    cv=validate_receipt_id_sidecar_snapshot_chain(sidecar_chain_state)
    if not cv.get("chain_valid",False): raise AuxError("invalid sidecar snapshot chain for unified checkpoint")
    activation=copy.deepcopy(context.get("activation_receipt"))
    body={
        "schema":_MEMORY_144_UNIFIED_CHECKPOINT_SCHEMA,
        "aux_name":AUX_NAME,"aux_version":AUX_VERSION,
        "memory_state":copy.deepcopy(context["memory_state"]),
        "memory_state_hash":context["memory_state"]["state_hash"],
        "activation_receipt":activation,
        "activation_state_hash":activation.get("activation_state_hash") if activation else None,
        "pipeline_event_count":int(context["pipeline_event_count"]),
        "next_pipeline_sequence":int(context["next_pipeline_sequence"]),
        "pipeline_history_accumulator":str(context["pipeline_history_accumulator"]),
        "memory_drop_count":int(context["memory_drop_count"]),
        "activation_count":int(context["activation_count"]),
        "typed_request_count":int(context["typed_request_count"]),
        "capability_execution_count":int(context["capability_execution_count"]),
        "latest_typed_request_summary":copy.deepcopy(context.get("latest_typed_request_summary")),
        "latest_capability_execution_summary":copy.deepcopy(context.get("latest_capability_execution_summary")),
        "event_id_root":str(sidecar_snapshot["receipt_id_root"]),
        "event_id_count":int(sidecar_snapshot["receipt_id_count"]),
        "event_id_membership_mode":"PASS007_SPARSE_MERKLE_256_SHA256_EXACT_SIDECAR_PASS008",
        "event_id_snapshot_hash":str(sidecar_snapshot["snapshot_hash"]),
        "event_id_snapshot_generation":int(sidecar_snapshot["generation"]),
        "sidecar_chain_state":copy.deepcopy(sidecar_chain_state),
        "rotation_index":int(rotation_index),
        "previous_checkpoint_hash":previous_checkpoint_hash,
        "checkpoint_chain_root_hash":checkpoint_chain_root_hash,
        "parent_pipeline_history_accumulator":parent_pipeline_history_accumulator,
        "rotation_suffix_event_count":int(rotation_suffix_event_count),
        "rotation_suffix_commitment":rotation_suffix_commitment,
        "archive_requirement":"historical event payloads and exact-ID sidecar snapshots/journals remain archival evidence; checkpoint is sufficient for exact continuation semantics when paired with its exact sidecar snapshot",
        "memory_feedback_policy":"FORBIDDEN_NO_AUTOMATIC_MEMORY_DROP_OR_REACTIVATION",
        "truth_credit":0,"root_write_capability":"NONE","return_write_capability":"NONE","solver_mutation_capability":"NONE",
    }
    out=dict(body); out["unified_checkpoint_hash"]=_memory_144_unified_checkpoint_hash(body)
    return out


def memory_144_create_unified_checkpoint(payload: Dict[str, Any]) -> Dict[str, Any]:
    try:
        replay=memory_144_pipeline_replay({"events":tuple(payload.get("events") or ())})
        if not replay.get("unified_valid",False): raise AuxError("full pipeline replay failed: "+str(replay.get("error") or replay.get("status")))
        ids=replay["event_ids"]
        snap_r=receipt_id_sidecar_snapshot({"receipt_ids":ids,"generation":0})
        if not snap_r.get("snapshot_valid",False): raise AuxError("could not create exact event-ID sidecar snapshot")
        snapshot=snap_r["snapshot"]
        chain_r=receipt_id_sidecar_snapshot_chain({"snapshots":[snapshot],"anchor_window":int(payload.get("sidecar_anchor_window",8))})
        if not chain_r.get("chain_valid",False): raise AuxError("could not create sidecar snapshot-chain state")
        cp=_memory_144_build_unified_checkpoint(replay["context"],sidecar_snapshot=snapshot,sidecar_chain_state=chain_r["chain_state"],rotation_index=0,previous_checkpoint_hash=None,checkpoint_chain_root_hash=None,parent_pipeline_history_accumulator=None,rotation_suffix_event_count=0,rotation_suffix_commitment=None)
        vv=validate_memory_144_unified_checkpoint({"checkpoint":cp})
        if not vv.get("checkpoint_valid",False): raise AuxError("constructed unified checkpoint failed validation")
        return {"status":"MEMORY_144_UNIFIED_CHECKPOINT_CREATED","checkpoint_valid":True,"checkpoint":cp,"sidecar_snapshot":snapshot,"projection":replay["projection"],"event_receipts":replay["event_receipts"],"truth_credit":0}
    except Exception as exc:
        return {"status":"MEMORY_144_UNIFIED_CHECKPOINT_REJECTED","checkpoint_valid":False,"error":str(exc),"truth_credit":0}


def _memory_144_validate_latest_summaries(checkpoint: Dict[str, Any]) -> None:
    q=checkpoint.get("latest_typed_request_summary"); x=checkpoint.get("latest_capability_execution_summary")
    req_count=int(checkpoint.get("typed_request_count",-1)); exe_count=int(checkpoint.get("capability_execution_count",-1))
    if req_count<0 or exe_count<0 or req_count!=exe_count: raise AuxError("typed-request/execution count mismatch")
    if req_count==0:
        if q is not None or x is not None: raise AuxError("zero capability count cannot carry latest request/execution summary")
        return
    if not isinstance(q,dict) or not isinstance(x,dict): raise AuxError("nonzero capability count requires latest request/execution summaries")
    for k in ("typed_request_hash","source_memory_state_hash","source_activation_state_hash","capability_payload_hash"):
        if not _hex64(q.get(k)): raise AuxError("invalid latest typed-request summary hash: "+k)
    for k in ("capability_execution_hash","typed_request_hash","capability_receipt_hash","source_memory_state_hash","source_activation_state_hash"):
        if not _hex64(x.get(k)): raise AuxError("invalid latest execution summary hash: "+k)
    if q["typed_request_hash"]!=x["typed_request_hash"] or q["target_capability"]!=x["target_capability"]: raise AuxError("latest request/execution summary mismatch")


def validate_memory_144_unified_checkpoint(payload: Dict[str, Any]) -> Dict[str, Any]:
    cp=payload.get("checkpoint") or payload
    try:
        if not isinstance(cp,dict) or cp.get("schema")!=_MEMORY_144_UNIFIED_CHECKPOINT_SCHEMA: raise AuxError("invalid unified checkpoint schema")
        supplied=str(cp.get("unified_checkpoint_hash") or ""); body={k:copy.deepcopy(v) for k,v in cp.items() if k!="unified_checkpoint_hash"}
        if supplied!=_memory_144_unified_checkpoint_hash(body): raise AuxError("unified checkpoint hash mismatch")
        mv=validate_memory_144_state(cp.get("memory_state") or {})
        if not mv.get("memory_valid",False): raise AuxError("unified checkpoint memory state invalid")
        if cp["memory_state"]["state_hash"]!=cp.get("memory_state_hash"): raise AuxError("unified checkpoint memory state hash binding mismatch")
        activation=cp.get("activation_receipt")
        if activation is None:
            if cp.get("activation_state_hash") is not None: raise AuxError("null activation cannot declare activation hash")
        else:
            av=validate_memory_144_activation({"receipt":activation,"state":cp["memory_state"]})
            if not av.get("activation_valid",False): raise AuxError("unified checkpoint activation invalid")
            if activation["activation_state_hash"]!=cp.get("activation_state_hash"): raise AuxError("unified checkpoint activation hash binding mismatch")
        event_count=int(cp.get("pipeline_event_count",-1)); next_seq=int(cp.get("next_pipeline_sequence",0))
        drops=int(cp.get("memory_drop_count",-1)); acts=int(cp.get("activation_count",-1)); reqs=int(cp.get("typed_request_count",-1)); exes=int(cp.get("capability_execution_count",-1))
        if min(event_count,drops,acts,reqs,exes)<0 or next_seq!=event_count+1: raise AuxError("unified checkpoint event counter mismatch")
        if event_count!=drops+acts+exes: raise AuxError("unified checkpoint event-type counts do not sum to pipeline count")
        if drops!=int(cp["memory_state"]["event_count"]): raise AuxError("memory-drop count disagrees with memory state event_count")
        if reqs!=exes: raise AuxError("typed-request/execution count mismatch")
        if int(cp.get("event_id_count",-1))!=event_count: raise AuxError("event-id count must equal pipeline event count")
        if not _hex64(cp.get("event_id_root")) or not _hex64(cp.get("pipeline_history_accumulator")): raise AuxError("invalid unified checkpoint accumulator/root")
        if cp.get("event_id_membership_mode")!="PASS007_SPARSE_MERKLE_256_SHA256_EXACT_SIDECAR_PASS008": raise AuxError("invalid unified checkpoint exact-ID mode")
        _memory_144_validate_latest_summaries(cp)
        chain=cp.get("sidecar_chain_state") or {}; cv=validate_receipt_id_sidecar_snapshot_chain(chain)
        if not cv.get("chain_valid",False): raise AuxError("unified checkpoint sidecar chain invalid")
        if str(chain.get("tip_snapshot_hash"))!=str(cp.get("event_id_snapshot_hash")): raise AuxError("sidecar chain tip snapshot mismatch")
        if int(chain.get("tip_generation",-1))!=int(cp.get("event_id_snapshot_generation",-2)): raise AuxError("sidecar chain tip generation mismatch")
        if str(chain.get("tip_receipt_id_root"))!=str(cp.get("event_id_root")) or int(chain.get("tip_receipt_id_count",-1))!=event_count: raise AuxError("sidecar chain tip root/count mismatch")
        rotation=int(cp.get("rotation_index",-1)); prev=cp.get("previous_checkpoint_hash"); root=cp.get("checkpoint_chain_root_hash")
        if rotation<0: raise AuxError("negative unified checkpoint rotation index")
        if rotation==0:
            if prev is not None or root is not None or cp.get("parent_pipeline_history_accumulator") is not None or int(cp.get("rotation_suffix_event_count",-1))!=0 or cp.get("rotation_suffix_commitment") is not None: raise AuxError("root unified checkpoint contains rotation-only fields")
        else:
            if not _hex64(prev) or not _hex64(root) or not _hex64(cp.get("parent_pipeline_history_accumulator")) or not _hex64(cp.get("rotation_suffix_commitment")): raise AuxError("invalid unified checkpoint rotation provenance")
            if int(cp.get("rotation_suffix_event_count",0))<1: raise AuxError("rotated checkpoint must commit a nonempty suffix")
        if cp.get("memory_feedback_policy")!="FORBIDDEN_NO_AUTOMATIC_MEMORY_DROP_OR_REACTIVATION": raise AuxError("memory feedback firewall mismatch")
        if int(cp.get("truth_credit",-1))!=0 or cp.get("root_write_capability")!="NONE" or cp.get("return_write_capability")!="NONE" or cp.get("solver_mutation_capability")!="NONE": raise AuxError("authority firewall violation")
        projection={
            "memory_state_hash":cp["memory_state_hash"],"memory_trace_accumulator":cp["memory_state"]["trace_accumulator"],"memory_event_count":cp["memory_state"]["event_count"],
            "activation_state_hash":cp.get("activation_state_hash"),"pipeline_event_count":event_count,"next_pipeline_sequence":next_seq,"pipeline_history_accumulator":cp["pipeline_history_accumulator"],
            "memory_drop_count":drops,"activation_count":acts,"typed_request_count":reqs,"capability_execution_count":exes,
            "latest_typed_request_hash":(cp.get("latest_typed_request_summary") or {}).get("typed_request_hash"),"latest_capability_execution_hash":(cp.get("latest_capability_execution_summary") or {}).get("capability_execution_hash"),
            "event_id_root":cp["event_id_root"],"event_id_count":event_count,
        }
        return {"status":"MEMORY_144_UNIFIED_CHECKPOINT_VALID","checkpoint_valid":True,"unified_checkpoint_hash":supplied,"projection":projection,"truth_credit":0}
    except Exception as exc:
        return {"status":"INVALID_MEMORY_144_UNIFIED_CHECKPOINT","checkpoint_valid":False,"error":str(exc),"truth_credit":0}


def _memory_144_validate_checkpoint_sidecar_binding(checkpoint: Dict[str, Any], snapshot: Dict[str, Any]) -> Dict[str, Any]:
    sv=validate_receipt_id_sidecar_snapshot(snapshot)
    if not sv.get("snapshot_valid",False): return {"binding_valid":False,"error":"invalid sidecar snapshot"}
    if str(snapshot.get("snapshot_hash"))!=str(checkpoint.get("event_id_snapshot_hash")): return {"binding_valid":False,"error":"sidecar snapshot hash does not match checkpoint"}
    if str(snapshot.get("receipt_id_root"))!=str(checkpoint.get("event_id_root")) or int(snapshot.get("receipt_id_count",-1))!=int(checkpoint.get("event_id_count",-2)): return {"binding_valid":False,"error":"sidecar root/count does not match checkpoint"}
    if int(snapshot.get("generation",-1))!=int(checkpoint.get("event_id_snapshot_generation",-2)): return {"binding_valid":False,"error":"sidecar generation does not match checkpoint"}
    return {"binding_valid":True}


def memory_144_resume_unified_checkpoint(payload: Dict[str, Any]) -> Dict[str, Any]:
    cp=payload.get("checkpoint") or {}; snapshot=payload.get("sidecar_snapshot") or {}; events=tuple(payload.get("events") or ())
    vv=validate_memory_144_unified_checkpoint({"checkpoint":cp})
    if not vv.get("checkpoint_valid",False): return {"status":"MEMORY_144_UNIFIED_RESUME_BLOCKED","resume_valid":False,"checkpoint_validation":vv,"truth_credit":0}
    binding=_memory_144_validate_checkpoint_sidecar_binding(cp,snapshot)
    if not binding.get("binding_valid",False): return {"status":"MEMORY_144_UNIFIED_RESUME_BLOCKED","resume_valid":False,"error":binding.get("error"),"truth_credit":0}
    try:
        ctx=_memory_144_pipeline_context_from_checkpoint(cp); records=[]; receipts=[]; normalized=[]
        for raw in events:
            ev=_memory_144_normalize_pipeline_event(raw,int(ctx["next_pipeline_sequence"]))
            app=append_receipt_id_sidecar({"snapshot":snapshot,"journal_records":tuple(records),"receipt_id":ev["event_id"]})
            if not app.get("appended",False): raise AuxError("exact event-ID sidecar rejected suffix event: "+str(app.get("status")))
            proof=app["membership_proof_before_insert"]
            current=recover_receipt_id_sidecar({"snapshot":snapshot,"journal_records":tuple(records)})
            if not current.get("recovered",False): raise AuxError("sidecar recovery failed before suffix event")
            pv=verify_sparse_receipt_id_proof(current["receipt_id_root"],ev["event_id"],proof,expected_present=False)
            if not pv.get("proof_valid",False): raise AuxError("sidecar non-membership witness failed")
            ctx,rr=_memory_144_pipeline_apply_event(ctx,ev); receipts.append(rr); normalized.append(ev); records.append(app["journal_entry"])
        recovered=recover_receipt_id_sidecar({"snapshot":snapshot,"journal_records":tuple(records)})
        if not recovered.get("recovered",False): raise AuxError("sidecar recovery failed after suffix")
        projection=_memory_144_unified_projection(ctx,recovered["receipt_id_root"],recovered["receipt_id_count"])
        return {"status":"MEMORY_144_UNIFIED_CHECKPOINT_RESUMED","resume_valid":True,"context":ctx,"projection":projection,"event_receipts":tuple(receipts),"normalized_events":tuple(normalized),"sidecar_journal_records":tuple(records),"sidecar_recovery":recovered,"truth_credit":0}
    except Exception as exc:
        return {"status":"MEMORY_144_UNIFIED_RESUME_REJECTED","resume_valid":False,"error":str(exc),"truth_credit":0}


def memory_144_rotate_unified_checkpoint(payload: Dict[str, Any]) -> Dict[str, Any]:
    cp=payload.get("checkpoint") or {}; snapshot=payload.get("sidecar_snapshot") or {}; events=tuple(payload.get("events") or ())
    if not events: return {"status":"MEMORY_144_UNIFIED_ROTATION_REJECTED","checkpoint_valid":False,"error":"rotation requires a nonempty suffix","truth_credit":0}
    resumed=memory_144_resume_unified_checkpoint({"checkpoint":cp,"sidecar_snapshot":snapshot,"events":events})
    if not resumed.get("resume_valid",False): return {"status":"MEMORY_144_UNIFIED_ROTATION_BLOCKED","checkpoint_valid":False,"resume":resumed,"truth_credit":0}
    try:
        compact=compact_receipt_id_sidecar({"snapshot":snapshot,"journal_records":resumed["sidecar_journal_records"]})
        if not compact.get("compacted",False): raise AuxError("sidecar compaction failed during unified rotation")
        child_snapshot=compact["snapshot"]
        trans=validate_receipt_id_sidecar_compaction_transition({"parent_snapshot":snapshot,"journal_records":resumed["sidecar_journal_records"],"child_snapshot":child_snapshot})
        if not trans.get("transition_valid",False): raise AuxError("sidecar compaction transition validation failed")
        chain_append=receipt_id_sidecar_snapshot_chain_append({"chain_state":cp["sidecar_chain_state"],"snapshot":child_snapshot})
        if not chain_append.get("chain_valid",False): raise AuxError("sidecar snapshot-chain append failed")
        suffix_commit=_memory_144_unified_suffix_commitment(resumed["event_receipts"])
        rotation=int(cp["rotation_index"])+1
        root_hash=str(cp["unified_checkpoint_hash"]) if int(cp["rotation_index"])==0 else str(cp["checkpoint_chain_root_hash"])
        child=_memory_144_build_unified_checkpoint(resumed["context"],sidecar_snapshot=child_snapshot,sidecar_chain_state=chain_append["chain_state"],rotation_index=rotation,previous_checkpoint_hash=str(cp["unified_checkpoint_hash"]),checkpoint_chain_root_hash=root_hash,parent_pipeline_history_accumulator=str(cp["pipeline_history_accumulator"]),rotation_suffix_event_count=len(events),rotation_suffix_commitment=suffix_commit)
        cv=validate_memory_144_unified_checkpoint({"checkpoint":child})
        if not cv.get("checkpoint_valid",False): raise AuxError("rotated unified checkpoint failed validation")
        return {"status":"MEMORY_144_UNIFIED_CHECKPOINT_ROTATED","checkpoint_valid":True,"checkpoint":child,"sidecar_snapshot":child_snapshot,"projection":resumed["projection"],"event_receipts":resumed["event_receipts"],"sidecar_transition":trans,"truth_credit":0}
    except Exception as exc:
        return {"status":"MEMORY_144_UNIFIED_ROTATION_REJECTED","checkpoint_valid":False,"error":str(exc),"truth_credit":0}


def validate_memory_144_unified_transition(payload: Dict[str, Any]) -> Dict[str, Any]:
    parent=payload.get("parent_checkpoint") or {}; child=payload.get("child_checkpoint") or {}; parent_snapshot=payload.get("parent_sidecar_snapshot") or {}; child_snapshot=payload.get("child_sidecar_snapshot") or {}; events=tuple(payload.get("events") or ())
    pv=validate_memory_144_unified_checkpoint({"checkpoint":parent}); cv=validate_memory_144_unified_checkpoint({"checkpoint":child})
    if not pv.get("checkpoint_valid",False) or not cv.get("checkpoint_valid",False): return {"status":"MEMORY_144_UNIFIED_TRANSITION_INVALID","transition_valid":False,"parent_validation":pv,"child_validation":cv,"truth_credit":0}
    try:
        if str(child.get("previous_checkpoint_hash"))!=str(parent.get("unified_checkpoint_hash")): raise AuxError("unified child previous-checkpoint hash mismatch")
        expected_rotation=int(parent["rotation_index"])+1
        if int(child.get("rotation_index",-1))!=expected_rotation: raise AuxError("unified child rotation index mismatch")
        expected_root=str(parent["unified_checkpoint_hash"]) if int(parent["rotation_index"])==0 else str(parent["checkpoint_chain_root_hash"])
        if str(child.get("checkpoint_chain_root_hash"))!=expected_root: raise AuxError("unified checkpoint-chain root mismatch")
        if str(child.get("parent_pipeline_history_accumulator"))!=str(parent.get("pipeline_history_accumulator")): raise AuxError("unified parent history accumulator mismatch")
        replay=memory_144_rotate_unified_checkpoint({"checkpoint":parent,"sidecar_snapshot":parent_snapshot,"events":events})
        if not replay.get("checkpoint_valid",False): raise AuxError("unified transition replay failed")
        if replay["checkpoint"]["unified_checkpoint_hash"]!=child["unified_checkpoint_hash"]: raise AuxError("unified transition child replay hash mismatch")
        if replay["sidecar_snapshot"]["snapshot_hash"]!=child_snapshot.get("snapshot_hash"): raise AuxError("unified transition child sidecar snapshot mismatch")
        if _memory_144_unified_suffix_commitment(replay["event_receipts"])!=child.get("rotation_suffix_commitment"): raise AuxError("unified transition suffix commitment mismatch")
        return {"status":"MEMORY_144_UNIFIED_TRANSITION_VALID","transition_valid":True,"parent_checkpoint_hash":parent["unified_checkpoint_hash"],"child_checkpoint_hash":child["unified_checkpoint_hash"],"suffix_event_count":len(events),"truth_credit":0}
    except Exception as exc:
        return {"status":"MEMORY_144_UNIFIED_TRANSITION_INVALID","transition_valid":False,"error":str(exc),"truth_credit":0}


# ---------------------------------------------------------------------------
# PASS014 — autonomous global terminality over the unified persistent pipeline
# ---------------------------------------------------------------------------

_MEMORY_144_TERMINAL_CONTRACT_SCHEMA = "HYPERTRIANGLE_CAUSAL_MEMORY_144_TERMINAL_CONTRACT_V1"
_MEMORY_144_TERMINAL_CHECKPOINT_SCHEMA = "HYPERTRIANGLE_CAUSAL_MEMORY_144_TERMINAL_CHECKPOINT_V1"
_MEMORY_144_TERMINAL_CONTRACT_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_TERMINAL_CONTRACT_V1\\0"
_MEMORY_144_TERMINAL_EVALUATION_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_TERMINAL_EVALUATION_V1\\0"
_MEMORY_144_TERMINAL_EXECUTION_STATE_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_TERMINAL_EXECUTION_STATE_V1\\0"
_MEMORY_144_TERMINAL_HISTORY_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_TERMINAL_HISTORY_V1\\0"
_MEMORY_144_TERMINAL_CERTIFICATE_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_TERMINAL_CERTIFICATE_V1\\0"
_MEMORY_144_TERMINAL_CHECKPOINT_DOMAIN = b"HT_SOLVER_AUX_MEMORY_144_TERMINAL_CHECKPOINT_V1\\0"


def _memory_144_terminal_hash(domain: bytes, value: Any) -> str:
    h=hashlib.sha256(); h.update(domain); h.update(_canonical_for_hash(value)); return h.hexdigest()


def _memory_144_normalize_string_list(value: Any, field: str) -> Tuple[str,...]:
    out=[]; seen=set()
    for raw in tuple(value or ()):
        x=str(raw).strip()
        if not x: raise AuxError(f"{field} contains an empty identifier")
        if x in seen: raise AuxError(f"{field} contains duplicate identifier: {x}")
        seen.add(x); out.append(x)
    return tuple(sorted(out))


def _memory_144_normalize_capability_list(value: Any, field: str) -> Tuple[str,...]:
    out=_memory_144_normalize_string_list(value,field)
    for cap in out:
        if cap not in _MEMORY_144_ACTIVATABLE_CAPABILITIES:
            raise AuxError(f"{field} contains capability outside standalone AUX boundary: {cap}")
    return out


def _memory_144_normalize_terminal_contract(contract: Dict[str,Any]) -> Dict[str,Any]:
    if not isinstance(contract,dict): raise AuxError("terminal contract must be an object")
    cid=str(contract.get("contract_id") or "").strip()
    if not cid: raise AuxError("terminal contract requires contract_id")
    req_slots=_memory_144_normalize_slot_list(contract.get("requires_certified_slots"),"requires_certified_slots")
    forbid_slots=_memory_144_normalize_slot_list(contract.get("forbids_certified_slots"),"forbids_certified_slots")
    overlap=set(req_slots)&set(forbid_slots)
    if overlap: raise AuxError("terminal contract cannot both require and forbid the same certified slot")
    req_contracts=_memory_144_normalize_string_list(contract.get("requires_active_contracts"),"requires_active_contracts")
    req_active_caps=_memory_144_normalize_capability_list(contract.get("requires_active_capabilities"),"requires_active_capabilities")
    req_done_caps=_memory_144_normalize_capability_list(contract.get("requires_completed_capabilities"),"requires_completed_capabilities")
    if not (req_slots or req_contracts or req_active_caps or req_done_caps):
        raise AuxError("terminal contract requires at least one positive obligation")
    return {
        "schema":_MEMORY_144_TERMINAL_CONTRACT_SCHEMA,
        "contract_id":cid,
        "requires_certified_slots":req_slots,
        "requires_active_contracts":req_contracts,
        "requires_active_capabilities":req_active_caps,
        "requires_completed_capabilities":req_done_caps,
        "forbids_certified_slots":forbid_slots,
        "execution_freshness":"CURRENT_MEMORY_AND_ACTIVATION",
        "terminal_semantics":"ALL_DECLARED_POSITIVE_OBLIGATIONS_SATISFIED_AND_NO_FORBIDDEN_CERTIFIED_SLOT",
        "truth_claim":"NONE_AUX_TERMINAL_IS_LOCAL_CONTRACT_COMPLETION_ONLY",
    }


def _memory_144_terminal_contract_hash(contract: Dict[str,Any]) -> str:
    return _memory_144_terminal_hash(_MEMORY_144_TERMINAL_CONTRACT_DOMAIN,contract)


def _memory_144_terminal_execution_summary(outcome: Dict[str,Any], sequence: int) -> Dict[str,Any]:
    cap=str(outcome.get("target_capability") or "")
    if cap not in _MEMORY_144_ACTIVATABLE_CAPABILITIES: raise AuxError("terminal tracker received invalid executed capability")
    summary={
        "target_capability":cap,
        "pipeline_sequence":int(sequence),
        "source_memory_state_hash":str(outcome.get("memory_state_hash") or ""),
        "source_activation_state_hash":str(outcome.get("activation_state_hash") or ""),
        "typed_request_hash":str(outcome.get("typed_request_hash") or ""),
        "capability_execution_hash":str(outcome.get("capability_execution_hash") or ""),
        "capability_receipt_hash":str(outcome.get("capability_receipt_hash") or ""),
    }
    for k in ("source_memory_state_hash","source_activation_state_hash","typed_request_hash","capability_execution_hash","capability_receipt_hash"):
        if not _hex64(summary[k]): raise AuxError("terminal execution summary contains invalid hash: "+k)
    return summary


def _memory_144_terminal_execution_state_hash(latest_by_capability: Dict[str,Dict[str,Any]]) -> str:
    rows=tuple(copy.deepcopy(latest_by_capability[k]) for k in sorted(latest_by_capability))
    return _memory_144_terminal_hash(_MEMORY_144_TERMINAL_EXECUTION_STATE_DOMAIN,rows)


def _memory_144_terminal_certified_slots(memory_state: Dict[str,Any]) -> Tuple[str,...]:
    return tuple(row[1] for i,row in enumerate(_CAUSAL_144_ROWS) if bool(memory_state["certified_flags"][i]))


def _memory_144_terminal_evaluate(context: Dict[str,Any], contract: Dict[str,Any], latest_by_capability: Dict[str,Dict[str,Any]]) -> Dict[str,Any]:
    state=context["memory_state"]
    certified=set(_memory_144_terminal_certified_slots(state))
    activation=context.get("activation_receipt")
    active_contracts=set(activation.get("active_contracts") or ()) if activation else set()
    active_caps=set(activation.get("active_capabilities") or ()) if activation else set()
    missing_slots=tuple(x for x in contract["requires_certified_slots"] if x not in certified)
    forbidden_present=tuple(x for x in contract["forbids_certified_slots"] if x in certified)
    missing_contracts=tuple(x for x in contract["requires_active_contracts"] if x not in active_contracts)
    missing_active_caps=tuple(x for x in contract["requires_active_capabilities"] if x not in active_caps)
    missing_completed=[]; stale_completed=[]; current_mem=str(state["state_hash"]); current_act=str(activation.get("activation_state_hash")) if activation else None
    for cap in contract["requires_completed_capabilities"]:
        rec=latest_by_capability.get(cap)
        if rec is None:
            missing_completed.append(cap); continue
        if rec.get("source_memory_state_hash")!=current_mem or current_act is None or rec.get("source_activation_state_hash")!=current_act:
            stale_completed.append(cap)
    terminal=not (missing_slots or forbidden_present or missing_contracts or missing_active_caps or missing_completed or stale_completed)
    body={
        "terminal_contract_hash":_memory_144_terminal_contract_hash(contract),
        "memory_state_hash":current_mem,
        "activation_state_hash":current_act,
        "certified_slots":tuple(sorted(certified,key=lambda z:int(z[1:]))),
        "active_contracts":tuple(sorted(active_contracts)),
        "active_capabilities":tuple(sorted(active_caps)),
        "execution_state_hash":_memory_144_terminal_execution_state_hash(latest_by_capability),
        "missing_certified_slots":missing_slots,
        "forbidden_certified_slots_present":forbidden_present,
        "missing_active_contracts":missing_contracts,
        "missing_active_capabilities":missing_active_caps,
        "missing_completed_capabilities":tuple(missing_completed),
        "stale_completed_capabilities":tuple(stale_completed),
        "blocked_semantic_conflict":bool(forbidden_present),
        "terminal":bool(terminal),
        "status":"AUX_TERMINAL" if terminal else ("AUX_BLOCKED_FORBIDDEN" if forbidden_present else "AUX_OPEN"),
        "truth_credit":0,
    }
    out=dict(body); out["terminal_evaluation_hash"]=_memory_144_terminal_hash(_MEMORY_144_TERMINAL_EVALUATION_DOMAIN,body)
    return out


def _memory_144_terminal_empty_history_hash(contract_hash: str) -> str:
    return _memory_144_terminal_hash(_MEMORY_144_TERMINAL_HISTORY_DOMAIN,{"START":1,"terminal_contract_hash":contract_hash})


def _memory_144_terminal_history_step(previous: str, event: Dict[str,Any], evaluation: Dict[str,Any]) -> str:
    return _memory_144_terminal_hash(_MEMORY_144_TERMINAL_HISTORY_DOMAIN,{
        "previous":previous,"prefix_event_count":int(event["sequence"]),"event_id":event["event_id"],
        "event_hash":event["event_hash"],"terminal_evaluation_hash":evaluation["terminal_evaluation_hash"],"terminal":bool(evaluation["terminal"]),
    })


def _memory_144_terminal_certificate(prefix: int, context: Dict[str,Any], contract_hash: str, evaluation: Dict[str,Any], history_accumulator: str) -> Dict[str,Any]:
    body={
        "prefix_event_count":int(prefix),
        "terminal_contract_hash":contract_hash,
        "pipeline_history_accumulator":str(context["pipeline_history_accumulator"]),
        "terminal_history_accumulator":str(history_accumulator),
        "memory_state_hash":str(context["memory_state"]["state_hash"]),
        "activation_state_hash":evaluation.get("activation_state_hash"),
        "execution_state_hash":evaluation["execution_state_hash"],
        "terminal_evaluation_hash":evaluation["terminal_evaluation_hash"],
        "terminal":True,
        "truth_credit":0,
    }
    out=dict(body); out["terminal_certificate_hash"]=_memory_144_terminal_hash(_MEMORY_144_TERMINAL_CERTIFICATE_DOMAIN,body)
    return out


def _memory_144_terminal_tracker_init(contract: Dict[str,Any]) -> Dict[str,Any]:
    ch=_memory_144_terminal_contract_hash(contract)
    return {
        "latest_execution_by_capability":{},
        "terminal_contract_hash":ch,
        "terminal_history_accumulator":_memory_144_terminal_empty_history_hash(ch),
        "historical_terminal":False,
        "current_terminal":False,
        "first_terminal_prefix":None,
        "first_terminal_certificate":None,
        "post_terminal_regression_prefixes":[],
        "post_terminal_conflicts":[],
        "current_evaluation":None,
    }


def _memory_144_terminal_tracker_from_checkpoint(cp: Dict[str,Any]) -> Dict[str,Any]:
    return {
        "latest_execution_by_capability":{str(k):copy.deepcopy(v) for k,v in (cp.get("latest_execution_by_capability") or {}).items()},
        "terminal_contract_hash":str(cp["terminal_contract_hash"]),
        "terminal_history_accumulator":str(cp["terminal_history_accumulator"]),
        "historical_terminal":bool(cp["historical_terminal"]),
        "current_terminal":bool(cp["current_terminal"]),
        "first_terminal_prefix":cp.get("first_terminal_prefix"),
        "first_terminal_certificate":copy.deepcopy(cp.get("first_terminal_certificate")),
        "post_terminal_regression_prefixes":list(cp.get("post_terminal_regression_prefixes") or ()),
        "post_terminal_conflicts":list(copy.deepcopy(cp.get("post_terminal_conflicts") or ())),
        "current_evaluation":copy.deepcopy(cp.get("current_terminal_evaluation")),
    }


def _memory_144_terminal_tracker_step(tracker: Dict[str,Any], context: Dict[str,Any], event: Dict[str,Any], receipt: Dict[str,Any], contract: Dict[str,Any]) -> Dict[str,Any]:
    tr=copy.deepcopy(tracker)
    if event["type"]=="CAPABILITY":
        summary=_memory_144_terminal_execution_summary(receipt["outcome"],int(event["sequence"]))
        tr["latest_execution_by_capability"][summary["target_capability"]]=summary
    ev=_memory_144_terminal_evaluate(context,contract,tr["latest_execution_by_capability"])
    tr["terminal_history_accumulator"]=_memory_144_terminal_history_step(tr["terminal_history_accumulator"],event,ev)
    seq=int(event["sequence"])
    if tr["first_terminal_prefix"] is None and ev["terminal"]:
        tr["first_terminal_prefix"]=seq
        tr["first_terminal_certificate"]=_memory_144_terminal_certificate(seq,context,tr["terminal_contract_hash"],ev,tr["terminal_history_accumulator"])
        tr["historical_terminal"]=True
    elif tr["first_terminal_prefix"] is not None and seq>int(tr["first_terminal_prefix"]):
        if not ev["terminal"]:
            tr["post_terminal_regression_prefixes"].append(seq)
        if ev["blocked_semantic_conflict"]:
            tr["post_terminal_conflicts"].append({
                "prefix_event_count":seq,
                "event_id":event["event_id"],
                "forbidden_certified_slots_present":ev["forbidden_certified_slots_present"],
                "terminal_evaluation_hash":ev["terminal_evaluation_hash"],
            })
    tr["historical_terminal"]=tr["first_terminal_prefix"] is not None
    tr["current_terminal"]=bool(ev["terminal"])
    tr["current_evaluation"]=ev
    return tr


def _memory_144_terminal_projection(context: Dict[str,Any], tracker: Dict[str,Any]) -> Dict[str,Any]:
    return {
        "pipeline_event_count":int(context["pipeline_event_count"]),
        "memory_state_hash":context["memory_state"]["state_hash"],
        "activation_state_hash":(context.get("activation_receipt") or {}).get("activation_state_hash"),
        "terminal_contract_hash":tracker["terminal_contract_hash"],
        "historical_terminal":bool(tracker["historical_terminal"]),
        "current_terminal":bool(tracker["current_terminal"]),
        "first_terminal_prefix":tracker["first_terminal_prefix"],
        "first_terminal_certificate_hash":(tracker.get("first_terminal_certificate") or {}).get("terminal_certificate_hash"),
        "post_terminal_regression_seen":bool(tracker["post_terminal_regression_prefixes"]),
        "post_terminal_regression_count":len(tracker["post_terminal_regression_prefixes"]),
        "post_terminal_semantic_conflict_seen":bool(tracker["post_terminal_conflicts"]),
        "post_terminal_semantic_conflict_count":len(tracker["post_terminal_conflicts"]),
        "terminal_history_accumulator":tracker["terminal_history_accumulator"],
        "execution_state_hash":_memory_144_terminal_execution_state_hash(tracker["latest_execution_by_capability"]),
        "stop_policy":f"STOP_AT_PREFIX_{tracker['first_terminal_prefix']}" if tracker["historical_terminal"] else "CONTINUE_ACQUISITION",
        "truth_credit":0,
    }


def memory_144_terminal_replay(payload: Dict[str,Any]) -> Dict[str,Any]:
    try:
        contract=_memory_144_normalize_terminal_contract(payload.get("terminal_contract") or {})
        events=tuple(payload.get("events") or ())
        ctx=_memory_144_pipeline_context_from_scratch(); idx=ExternalReceiptIdIndex(); receipts=[]; normalized=[]; tracker=_memory_144_terminal_tracker_init(contract)
        for raw in events:
            ev=_memory_144_normalize_pipeline_event(raw,int(ctx["next_pipeline_sequence"]))
            if idx.proof(ev["event_id"]).get("present"): raise AuxError("duplicate pipeline event_id")
            ins=idx.insert(ev["event_id"])
            if not ins.get("inserted",False): raise AuxError("pipeline event-id insertion failed")
            ctx,rr=_memory_144_pipeline_apply_event(ctx,ev)
            tracker=_memory_144_terminal_tracker_step(tracker,ctx,ev,rr,contract)
            receipts.append(rr); normalized.append(ev)
        # Positive contracts cannot be terminal at prefix zero; evaluate current zero state for completeness.
        if tracker["current_evaluation"] is None:
            tracker["current_evaluation"]=_memory_144_terminal_evaluate(ctx,contract,tracker["latest_execution_by_capability"])
        base_projection=_memory_144_unified_projection(ctx,idx.root,len(idx.ids))
        return {
            "status":"MEMORY_144_TERMINAL_REPLAY_COMPLETE","terminal_replay_valid":True,
            "terminal_contract":contract,"context":ctx,"tracker":tracker,
            "projection":dict(base_projection,**_memory_144_terminal_projection(ctx,tracker)),
            "event_receipts":tuple(receipts),"normalized_events":tuple(normalized),"event_ids":tuple(ev["event_id"] for ev in normalized),
            "truth_credit":0,
        }
    except Exception as exc:
        return {"status":"MEMORY_144_TERMINAL_REPLAY_REJECTED","terminal_replay_valid":False,"error":str(exc),"truth_credit":0}


def _memory_144_terminal_checkpoint_hash(body: Dict[str,Any]) -> str:
    return _memory_144_terminal_hash(_MEMORY_144_TERMINAL_CHECKPOINT_DOMAIN,body)


def _memory_144_build_terminal_checkpoint(unified_checkpoint: Dict[str,Any], contract: Dict[str,Any], tracker: Dict[str,Any]) -> Dict[str,Any]:
    body={
        "schema":_MEMORY_144_TERMINAL_CHECKPOINT_SCHEMA,
        "aux_name":AUX_NAME,"aux_version":AUX_VERSION,
        "unified_checkpoint":copy.deepcopy(unified_checkpoint),
        "unified_checkpoint_hash":str(unified_checkpoint["unified_checkpoint_hash"]),
        "terminal_contract":copy.deepcopy(contract),
        "terminal_contract_hash":str(tracker["terminal_contract_hash"]),
        "latest_execution_by_capability":{k:copy.deepcopy(tracker["latest_execution_by_capability"][k]) for k in sorted(tracker["latest_execution_by_capability"])},
        "execution_state_hash":_memory_144_terminal_execution_state_hash(tracker["latest_execution_by_capability"]),
        "terminal_history_accumulator":str(tracker["terminal_history_accumulator"]),
        "historical_terminal":bool(tracker["historical_terminal"]),
        "current_terminal":bool(tracker["current_terminal"]),
        "first_terminal_prefix":tracker["first_terminal_prefix"],
        "first_terminal_certificate":copy.deepcopy(tracker.get("first_terminal_certificate")),
        "post_terminal_regression_prefixes":tuple(tracker["post_terminal_regression_prefixes"]),
        "post_terminal_conflicts":tuple(copy.deepcopy(tracker["post_terminal_conflicts"])),
        "current_terminal_evaluation":copy.deepcopy(tracker["current_evaluation"]),
        "stop_policy":f"STOP_AT_PREFIX_{tracker['first_terminal_prefix']}" if tracker["historical_terminal"] else "CONTINUE_ACQUISITION",
        "terminality_scope":"AUX_LOCAL_DECLARED_OBLIGATIONS_ONLY_NOT_EXTERNAL_TRUTH",
        "truth_credit":0,"root_write_capability":"NONE","return_write_capability":"NONE","solver_mutation_capability":"NONE",
    }
    out=dict(body); out["terminal_checkpoint_hash"]=_memory_144_terminal_checkpoint_hash(body); return out


def memory_144_create_terminal_checkpoint(payload: Dict[str,Any]) -> Dict[str,Any]:
    try:
        replay=memory_144_terminal_replay(payload)
        if not replay.get("terminal_replay_valid",False): raise AuxError("terminal replay failed: "+str(replay.get("error") or replay.get("status")))
        ids=replay["event_ids"]
        snap_r=receipt_id_sidecar_snapshot({"receipt_ids":ids,"generation":0})
        if not snap_r.get("snapshot_valid",False): raise AuxError("could not create exact event-ID sidecar snapshot")
        snapshot=snap_r["snapshot"]
        chain_r=receipt_id_sidecar_snapshot_chain({"snapshots":[snapshot],"anchor_window":int(payload.get("sidecar_anchor_window",8))})
        if not chain_r.get("chain_valid",False): raise AuxError("could not create sidecar snapshot-chain state")
        ucp=_memory_144_build_unified_checkpoint(replay["context"],sidecar_snapshot=snapshot,sidecar_chain_state=chain_r["chain_state"],rotation_index=0,previous_checkpoint_hash=None,checkpoint_chain_root_hash=None,parent_pipeline_history_accumulator=None,rotation_suffix_event_count=0,rotation_suffix_commitment=None)
        uv=validate_memory_144_unified_checkpoint({"checkpoint":ucp})
        if not uv.get("checkpoint_valid",False): raise AuxError("constructed unified checkpoint failed validation")
        tcp=_memory_144_build_terminal_checkpoint(ucp,replay["terminal_contract"],replay["tracker"])
        tv=validate_memory_144_terminal_checkpoint({"checkpoint":tcp})
        if not tv.get("terminal_checkpoint_valid",False): raise AuxError("constructed terminal checkpoint failed validation: "+str(tv.get("error")))
        return {"status":"MEMORY_144_TERMINAL_CHECKPOINT_CREATED","terminal_checkpoint_valid":True,"checkpoint":tcp,"sidecar_snapshot":snapshot,"projection":replay["projection"],"event_receipts":replay["event_receipts"],"truth_credit":0}
    except Exception as exc:
        return {"status":"MEMORY_144_TERMINAL_CHECKPOINT_REJECTED","terminal_checkpoint_valid":False,"error":str(exc),"truth_credit":0}


def _memory_144_validate_terminal_execution_map(value: Any, pipeline_event_count: int) -> Dict[str,Dict[str,Any]]:
    if not isinstance(value,dict): raise AuxError("terminal checkpoint latest_execution_by_capability must be an object")
    out={}
    for cap,raw in value.items():
        if cap not in _MEMORY_144_ACTIVATABLE_CAPABILITIES or not isinstance(raw,dict): raise AuxError("invalid terminal execution map entry")
        rec=copy.deepcopy(raw)
        if rec.get("target_capability")!=cap: raise AuxError("terminal execution map key/capability mismatch")
        seq=int(rec.get("pipeline_sequence",0))
        if seq<1 or seq>pipeline_event_count: raise AuxError("terminal execution summary sequence outside checkpoint prefix")
        for k in ("source_memory_state_hash","source_activation_state_hash","typed_request_hash","capability_execution_hash","capability_receipt_hash"):
            if not _hex64(rec.get(k)): raise AuxError("invalid terminal execution summary hash: "+k)
        out[cap]=rec
    return out


def validate_memory_144_terminal_checkpoint(payload: Dict[str,Any]) -> Dict[str,Any]:
    cp=payload.get("checkpoint") or payload
    try:
        if not isinstance(cp,dict) or cp.get("schema")!=_MEMORY_144_TERMINAL_CHECKPOINT_SCHEMA: raise AuxError("invalid terminal checkpoint schema")
        supplied=str(cp.get("terminal_checkpoint_hash") or ""); body={k:copy.deepcopy(v) for k,v in cp.items() if k!="terminal_checkpoint_hash"}
        if supplied!=_memory_144_terminal_checkpoint_hash(body): raise AuxError("terminal checkpoint hash mismatch")
        ucp=cp.get("unified_checkpoint") or {}; uv=validate_memory_144_unified_checkpoint({"checkpoint":ucp})
        if not uv.get("checkpoint_valid",False): raise AuxError("terminal checkpoint embeds invalid unified checkpoint")
        if str(ucp.get("unified_checkpoint_hash"))!=str(cp.get("unified_checkpoint_hash")): raise AuxError("terminal/unified checkpoint hash binding mismatch")
        contract=_memory_144_normalize_terminal_contract(cp.get("terminal_contract") or {})
        ch=_memory_144_terminal_contract_hash(contract)
        if ch!=str(cp.get("terminal_contract_hash")): raise AuxError("terminal contract hash mismatch")
        latest=_memory_144_validate_terminal_execution_map(cp.get("latest_execution_by_capability") or {},int(ucp["pipeline_event_count"]))
        if _memory_144_terminal_execution_state_hash(latest)!=str(cp.get("execution_state_hash")): raise AuxError("terminal execution-state hash mismatch")
        ctx=_memory_144_pipeline_context_from_checkpoint(ucp)
        ev=_memory_144_terminal_evaluate(ctx,contract,latest)
        supplied_ev=cp.get("current_terminal_evaluation") or {}
        if ev["terminal_evaluation_hash"]!=supplied_ev.get("terminal_evaluation_hash") or encode(ev)!=encode(supplied_ev): raise AuxError("current terminal evaluation mismatch")
        if bool(cp.get("current_terminal"))!=bool(ev["terminal"]): raise AuxError("current terminal flag mismatch")
        historical=bool(cp.get("historical_terminal")); ftp=cp.get("first_terminal_prefix"); cert=cp.get("first_terminal_certificate")
        if historical:
            if ftp is None or int(ftp)<1 or int(ftp)>int(ucp["pipeline_event_count"]): raise AuxError("invalid first terminal prefix")
            if not isinstance(cert,dict) or int(cert.get("prefix_event_count",0))!=int(ftp) or not bool(cert.get("terminal")): raise AuxError("invalid first terminal certificate")
            cert_body={k:copy.deepcopy(v) for k,v in cert.items() if k!="terminal_certificate_hash"}
            if cert.get("terminal_certificate_hash")!=_memory_144_terminal_hash(_MEMORY_144_TERMINAL_CERTIFICATE_DOMAIN,cert_body): raise AuxError("first terminal certificate hash mismatch")
            if cert.get("terminal_contract_hash")!=ch: raise AuxError("first terminal certificate contract mismatch")
            if int(ftp)==int(ucp["pipeline_event_count"]):
                if cert.get("terminal_history_accumulator")!=cp.get("terminal_history_accumulator"): raise AuxError("terminal history accumulator disagrees with first-terminal certificate at same prefix")
                if cert.get("pipeline_history_accumulator")!=ucp.get("pipeline_history_accumulator"): raise AuxError("pipeline history accumulator disagrees with first-terminal certificate at same prefix")
            if cp.get("stop_policy")!=f"STOP_AT_PREFIX_{int(ftp)}": raise AuxError("terminal stop policy mismatch")
        else:
            if ftp is not None or cert is not None: raise AuxError("non-historical terminal checkpoint carries first-terminal data")
            if cp.get("stop_policy")!="CONTINUE_ACQUISITION": raise AuxError("nonterminal stop policy mismatch")
        regs=tuple(int(x) for x in (cp.get("post_terminal_regression_prefixes") or ()))
        if regs and not historical: raise AuxError("regressions require historical terminality")
        if any(x<=int(ftp or 0) or x>int(ucp["pipeline_event_count"]) for x in regs): raise AuxError("post-terminal regression prefix out of range")
        conflicts=tuple(cp.get("post_terminal_conflicts") or ())
        if conflicts and not historical: raise AuxError("post-terminal conflicts require historical terminality")
        for c in conflicts:
            if int(c.get("prefix_event_count",0))<=int(ftp or 0) or int(c.get("prefix_event_count",0))>int(ucp["pipeline_event_count"]): raise AuxError("post-terminal conflict prefix out of range")
            if not tuple(c.get("forbidden_certified_slots_present") or ()): raise AuxError("post-terminal conflict missing forbidden slot evidence")
            if not _hex64(c.get("terminal_evaluation_hash")): raise AuxError("post-terminal conflict missing evaluation hash")
        if not _hex64(cp.get("terminal_history_accumulator")): raise AuxError("invalid terminal history accumulator")
        if cp.get("terminality_scope")!="AUX_LOCAL_DECLARED_OBLIGATIONS_ONLY_NOT_EXTERNAL_TRUTH": raise AuxError("terminality scope mismatch")
        if int(cp.get("truth_credit",-1))!=0 or cp.get("root_write_capability")!="NONE" or cp.get("return_write_capability")!="NONE" or cp.get("solver_mutation_capability")!="NONE": raise AuxError("authority firewall violation")
        return {"status":"MEMORY_144_TERMINAL_CHECKPOINT_VALID","terminal_checkpoint_valid":True,"terminal_checkpoint_hash":supplied,"historical_terminal":historical,"current_terminal":bool(ev["terminal"]),"first_terminal_prefix":ftp,"truth_credit":0}
    except Exception as exc:
        return {"status":"INVALID_MEMORY_144_TERMINAL_CHECKPOINT","terminal_checkpoint_valid":False,"error":str(exc),"truth_credit":0}


def memory_144_resume_terminal_checkpoint(payload: Dict[str,Any]) -> Dict[str,Any]:
    tcp=payload.get("checkpoint") or {}; snapshot=payload.get("sidecar_snapshot") or {}; events=tuple(payload.get("events") or ())
    tv=validate_memory_144_terminal_checkpoint({"checkpoint":tcp})
    if not tv.get("terminal_checkpoint_valid",False): return {"status":"MEMORY_144_TERMINAL_RESUME_BLOCKED","terminal_resume_valid":False,"checkpoint_validation":tv,"truth_credit":0}
    ucp=tcp["unified_checkpoint"]
    base=memory_144_resume_unified_checkpoint({"checkpoint":ucp,"sidecar_snapshot":snapshot,"events":events})
    if not base.get("resume_valid",False): return {"status":"MEMORY_144_TERMINAL_RESUME_BLOCKED","terminal_resume_valid":False,"base_resume":base,"truth_credit":0}
    try:
        contract=_memory_144_normalize_terminal_contract(tcp["terminal_contract"])
        tracker=_memory_144_terminal_tracker_from_checkpoint(tcp); ctx=_memory_144_pipeline_context_from_checkpoint(ucp)
        replay_receipts=[]
        for ev,expected_rr in zip(base["normalized_events"],base["event_receipts"]):
            ctx,rr=_memory_144_pipeline_apply_event(ctx,ev)
            if rr["pipeline_history_accumulator"]!=expected_rr["pipeline_history_accumulator"] or encode(rr["outcome"])!=encode(expected_rr["outcome"]): raise AuxError("terminal suffix replay disagrees with unified resume")
            tracker=_memory_144_terminal_tracker_step(tracker,ctx,ev,rr,contract); replay_receipts.append(rr)
        if tracker["current_evaluation"] is None: tracker["current_evaluation"]=_memory_144_terminal_evaluate(ctx,contract,tracker["latest_execution_by_capability"])
        projection=dict(base["projection"],**_memory_144_terminal_projection(ctx,tracker))
        return {"status":"MEMORY_144_TERMINAL_CHECKPOINT_RESUMED","terminal_resume_valid":True,"context":ctx,"tracker":tracker,"projection":projection,"event_receipts":tuple(replay_receipts),"normalized_events":base["normalized_events"],"sidecar_journal_records":base["sidecar_journal_records"],"sidecar_recovery":base["sidecar_recovery"],"truth_credit":0}
    except Exception as exc:
        return {"status":"MEMORY_144_TERMINAL_RESUME_REJECTED","terminal_resume_valid":False,"error":str(exc),"truth_credit":0}


def memory_144_rotate_terminal_checkpoint(payload: Dict[str,Any]) -> Dict[str,Any]:
    tcp=payload.get("checkpoint") or {}; snapshot=payload.get("sidecar_snapshot") or {}; events=tuple(payload.get("events") or ())
    if not events: return {"status":"MEMORY_144_TERMINAL_ROTATION_REJECTED","terminal_checkpoint_valid":False,"error":"rotation requires a nonempty suffix","truth_credit":0}
    resumed=memory_144_resume_terminal_checkpoint({"checkpoint":tcp,"sidecar_snapshot":snapshot,"events":events})
    if not resumed.get("terminal_resume_valid",False): return {"status":"MEMORY_144_TERMINAL_ROTATION_BLOCKED","terminal_checkpoint_valid":False,"resume":resumed,"truth_credit":0}
    base=memory_144_rotate_unified_checkpoint({"checkpoint":tcp["unified_checkpoint"],"sidecar_snapshot":snapshot,"events":events})
    if not base.get("checkpoint_valid",False): return {"status":"MEMORY_144_TERMINAL_ROTATION_BLOCKED","terminal_checkpoint_valid":False,"base_rotation":base,"truth_credit":0}
    try:
        contract=_memory_144_normalize_terminal_contract(tcp["terminal_contract"])
        child=_memory_144_build_terminal_checkpoint(base["checkpoint"],contract,resumed["tracker"])
        vv=validate_memory_144_terminal_checkpoint({"checkpoint":child})
        if not vv.get("terminal_checkpoint_valid",False): raise AuxError("rotated terminal checkpoint failed validation: "+str(vv.get("error")))
        return {"status":"MEMORY_144_TERMINAL_CHECKPOINT_ROTATED","terminal_checkpoint_valid":True,"checkpoint":child,"sidecar_snapshot":base["sidecar_snapshot"],"projection":resumed["projection"],"event_receipts":resumed["event_receipts"],"truth_credit":0}
    except Exception as exc:
        return {"status":"MEMORY_144_TERMINAL_ROTATION_REJECTED","terminal_checkpoint_valid":False,"error":str(exc),"truth_credit":0}


def validate_memory_144_terminal_transition(payload: Dict[str,Any]) -> Dict[str,Any]:
    parent=payload.get("parent_checkpoint") or {}; child=payload.get("child_checkpoint") or {}; parent_snapshot=payload.get("parent_sidecar_snapshot") or {}; child_snapshot=payload.get("child_sidecar_snapshot") or {}; events=tuple(payload.get("events") or ())
    pv=validate_memory_144_terminal_checkpoint({"checkpoint":parent}); cv=validate_memory_144_terminal_checkpoint({"checkpoint":child})
    if not pv.get("terminal_checkpoint_valid",False) or not cv.get("terminal_checkpoint_valid",False): return {"status":"MEMORY_144_TERMINAL_TRANSITION_INVALID","terminal_transition_valid":False,"parent_validation":pv,"child_validation":cv,"truth_credit":0}
    try:
        if parent["terminal_contract_hash"]!=child["terminal_contract_hash"]: raise AuxError("terminal contract changed across transition")
        replay=memory_144_rotate_terminal_checkpoint({"checkpoint":parent,"sidecar_snapshot":parent_snapshot,"events":events})
        if not replay.get("terminal_checkpoint_valid",False): raise AuxError("terminal transition replay failed")
        if replay["checkpoint"]["terminal_checkpoint_hash"]!=child["terminal_checkpoint_hash"]: raise AuxError("terminal transition child replay hash mismatch")
        if replay["sidecar_snapshot"]["snapshot_hash"]!=child_snapshot.get("snapshot_hash"): raise AuxError("terminal transition child sidecar mismatch")
        if parent.get("historical_terminal") and child.get("first_terminal_prefix")!=parent.get("first_terminal_prefix"): raise AuxError("first terminal prefix was rewritten")
        if parent.get("historical_terminal") and encode(child.get("first_terminal_certificate"))!=encode(parent.get("first_terminal_certificate")): raise AuxError("first terminal certificate was rewritten")
        return {"status":"MEMORY_144_TERMINAL_TRANSITION_VALID","terminal_transition_valid":True,"parent_terminal_checkpoint_hash":parent["terminal_checkpoint_hash"],"child_terminal_checkpoint_hash":child["terminal_checkpoint_hash"],"first_terminal_prefix":child.get("first_terminal_prefix"),"truth_credit":0}
    except Exception as exc:
        return {"status":"MEMORY_144_TERMINAL_TRANSITION_INVALID","terminal_transition_valid":False,"error":str(exc),"truth_credit":0}

# ---------------------------------------------------------------------------
# Provider front door
# ---------------------------------------------------------------------------

def capabilities() -> Dict[str, Any]:
    return {
        "status": "READY",
        "capabilities": {
            "route_simplex": "typed nonnegative additive route -> simplex/support receipt",
            "route_transition": "two typed routes -> face/superface/support-replacement receipt",
            "signed_polarity": "signed additive vector -> canonical bipolar and signed-sector lift",
            "b4_state": "four certified comparable independent axes -> B4 chamber/boundary receipt",
            "robust_b4_state": "nominal B4 state + component error box -> same-chamber certificate",
            "wall_event": "robust bracket + derivative contract -> unique wall-crossing certificate",
            "b4_route": "ordered wall-event receipts -> certified B4 route order",
            "receipt_bundle": "robust B4 states + optional route -> terminal AUX receipt bundle",
            "receipt_stream": "append-only typed receipts -> hash-chained first-terminal-prefix certificate",
            "stream_checkpoint": "verified stream prefix -> compact resumable checkpoint",
            "resume_stream_checkpoint": "checkpoint + suffix receipts -> exact continuation certificate",
            "rotate_stream_checkpoint": "checkpoint + suffix receipts -> next compact checkpoint with chained provenance",
            "validate_checkpoint_chain": "archived checkpoint sequence -> linear lineage/provenance audit",
            "rotate_bounded_checkpoint": "checkpoint + suffix -> bounded-lineage checkpoint with rolling accumulator + anchor window",
            "validate_bounded_checkpoint": "bounded checkpoint -> self-hash/anchor/accumulator consistency audit",
            "validate_bounded_checkpoint_chain": "archived mixed/full/bounded checkpoint sequence -> exact lineage transition audit",
            "receipt_id_membership_no_go": "finite-state pigeonhole certificate for impossibility of fixed-size standalone exact duplicate membership",
            "receipt_id_proof": "external exact-index snapshot -> sparse-Merkle membership/non-membership proof",
            "verify_receipt_id_proof": "bounded root + witness -> authenticated membership/non-membership verification",
            "receipt_id_insert_root": "bounded root + valid non-membership witness -> next authenticated receipt-id root",
            "rotate_witnessed_checkpoint": "bounded checkpoint + suffix + external non-membership witnesses -> checkpoint without historical receipt-id list",
            "validate_witnessed_checkpoint": "witnessed checkpoint -> self-hash/semantic/bounded-history audit",
            "validate_witnessed_checkpoint_transition": "archived parent + child + witness packet -> authenticated receipt-id root transition audit",
            "receipt_id_sidecar_snapshot": "exact external receipt-ID set -> deterministic authenticated snapshot",
            "validate_receipt_id_sidecar_snapshot": "sidecar snapshot -> exact count/root/hash validation",
            "receipt_id_sidecar_recover": "snapshot + append-only journal records -> exact recovered external index state",
            "receipt_id_sidecar_append": "recovered sidecar state + new receipt ID -> next hash-chained journal entry",
            "receipt_id_sidecar_proof": "recovered sidecar state -> current sparse-Merkle membership/non-membership proof",
            "receipt_id_sidecar_compact": "snapshot + journal -> next-generation deterministic snapshot",
            "receipt_id_sidecar_snapshot_chain": "ordered snapshots -> bounded authenticated snapshot-chain state",
            "receipt_id_sidecar_snapshot_chain_append": "bounded snapshot-chain state + child snapshot -> next bounded chain state",
            "validate_receipt_id_sidecar_snapshot_chain": "bounded sidecar snapshot-chain state -> accumulator/anchor audit",
            "validate_receipt_id_sidecar_compaction_transition": "parent snapshot + compacted journal + child snapshot -> exact semantic transition audit",
            "receipt_id_sidecar_compaction_decision": "sidecar state + deterministic thresholds -> compact-now/keep-append verdict",
            "receipt_id_sidecar_auto_compact": "sidecar state + policy -> deterministic pure auto-compaction result",
            "memory_144_catalog": "fixed F001-F144 invariant grid; data falls onto slots by declared canonical operator",
            "memory_144_init": "initialize 144-slot flag memory with trace START=1",
            "memory_144_drop": "incoming datum + invariant signatures -> slot flags + last certified invariant saved",
            "memory_144_trace": "ordered incoming data stream -> START=1 flag trace over fixed 144-slot grid",
            "memory_144_validate": "audit 144-slot memory state, masks, counters and last-invariant bindings",
            "memory_144_reconstruct": "reconstruct active memory from last certified invariants + residual/reconstruction refs",
            "memory_144_activation_catalog": "declare the standalone AUX capabilities eligible for memory-driven activation",
            "memory_144_activate": "certified last-invariant slots + explicit contracts -> deterministic capability relevance receipt",
            "memory_144_validate_activation": "audit activation receipt, certified-mask semantics, contract hash and optional exact-memory replay",
            "memory_144_compile_capability_request": "valid active contract + explicit payload -> provenance-bound typed local capability request",
            "memory_144_validate_capability_request": "audit typed request and optional exact activation/memory binding",
            "memory_144_execute_capability": "validated typed request -> one deterministic local HyperTriangle capability receipt",
            "memory_144_validate_capability_execution": "audit execution receipt and optionally replay the exact local capability",
            "memory_144_activation_to_capability": "compose activation -> typed request -> deterministic local capability receipt with no memory feedback",
            "memory_144_pipeline_replay": "full START=1 replay of memory-drop / activate / capability events with exact event-ID root and one provenance accumulator",
            "memory_144_create_unified_checkpoint": "full pipeline prefix -> unified memory/activation/execution checkpoint + exact sidecar snapshot",
            "memory_144_validate_unified_checkpoint": "audit unified checkpoint, memory/activation bindings, exact-ID sidecar-chain tip and authority firewall",
            "memory_144_resume_unified_checkpoint": "unified checkpoint + exact sidecar snapshot + suffix -> crash-safe exact continuation",
            "memory_144_rotate_unified_checkpoint": "resume suffix, compact exact-ID sidecar, append bounded snapshot lineage, emit child unified checkpoint",
            "memory_144_validate_unified_transition": "parent + suffix + child -> deterministic rotation replay and provenance audit",
            "memory_144_terminal_replay": "full START=1 unified replay + declared local terminal contract -> frozen first-terminal-prefix history",
            "memory_144_create_terminal_checkpoint": "terminal replay prefix -> unified checkpoint wrapped with terminal history/certificate state",
            "memory_144_validate_terminal_checkpoint": "audit terminal contract, current evaluation, frozen first terminal certificate and authority firewall",
            "memory_144_resume_terminal_checkpoint": "terminal checkpoint + exact sidecar + suffix -> exact continuation of terminal history",
            "memory_144_rotate_terminal_checkpoint": "terminal continuation + unified sidecar rotation -> child terminal checkpoint",
            "memory_144_validate_terminal_transition": "parent terminal checkpoint + suffix + child -> deterministic replay and first-terminal immutability audit",
        },
        "firewalls": [
            "no invented weights",
            "no invented pole independence",
            "no B4 promotion without common scale + axis independence + comparability",
            "zero truth credit",
            "no ROOT/RETURN write",
            "no solver mutation",
            "no probabilistic Bloom substitution for exact duplicate detection",
            "bounded receipt-id root requires external authenticated witnesses after PASS007 migration",
            "sidecar exactness remains externally stored and grows with receipt-ID count",
            "crash recovery may ignore only an uncommitted final journal line; committed semantic/hash failures are hard errors",
            "automatic compaction is threshold-deterministic and adds zero solver authority",
            "bounded snapshot-chain state does not replace archived snapshots/journals required for exact compacted-transition replay",
            "memory direction is data -> invariant slot flag; categories never pull or fuzzily classify raw data",
            "memory trace numbering starts at 1",
            "canonical F001-F144 slot identity is immutable; context/projection never rewrites the slot",
            "only certified incoming projections replace last_invariants_saved; raw replay is not claimed without a reconstruction contract",
            "capability activation uses declared contracts only; no slot-to-capability relation is inferred",
            "uncertified observations never satisfy activation requirements",
            "activation emits relevance receipts only and never executes a capability",
            "PASS012 execution requires a validated active contract plus an explicit typed capability payload",
            "PASS012 executes only the 19 standalone local capabilities admitted by PASS011",
            "capability execution output never feeds memory_144_drop or re-enters activation automatically",
            "typed request and execution receipts are causally hash-bound to memory -> activation -> request -> receipt",
            "PASS013 unified checkpoints bind memory state, current activation, request/execution summaries, pipeline history and exact event-ID root",
            "checkpoint resume requires the exact PASS008 sidecar snapshot bound by hash/root/count/generation",
            "every MEMORY_DROP invalidates current activation; capability execution after a memory change requires a fresh ACTIVATE event",
            "PASS013 rotation compacts the sidecar and appends its snapshot to the bounded PASS009 snapshot-chain state",
            "PASS014 AUX terminality is only completion of a declared local terminal contract and grants zero external truth credit",
            "PASS014 freezes the first terminal prefix/certificate; later regressions or forbidden-slot conflicts cannot rewrite it",
            "PASS014 completed-capability obligations require execution bound to the current memory state and current activation state",
        ],
    }


def handle_request(request: Dict[str, Any]) -> Dict[str, Any]:
    mode = str(request.get("mode", "capabilities"))
    payload = request.get("payload") or {}
    rid = request.get("request_id")
    if mode == "capabilities": receipt = capabilities()
    elif mode == "route_simplex": receipt = compile_route(payload)
    elif mode == "route_transition":
        receipt = classify_route_transition(payload.get("previous") or {}, payload.get("current") or {},
                                            bool(payload.get("same_ledger", True)))
    elif mode == "signed_polarity": receipt = signed_polarity(payload.get("values") or ())
    elif mode == "b4_state": receipt = b4_state(payload)
    elif mode == "robust_b4_state": receipt = robust_b4_state(payload)
    elif mode == "wall_event": receipt = certify_wall_event(payload)
    elif mode == "b4_route": receipt = certify_b4_route(payload)
    elif mode == "receipt_bundle": receipt = certify_receipt_bundle(payload)
    elif mode == "receipt_stream": receipt = certify_receipt_stream(payload)
    elif mode == "stream_checkpoint": receipt = create_stream_checkpoint(payload)
    elif mode == "resume_stream_checkpoint": receipt = resume_stream_checkpoint(payload)
    elif mode == "rotate_stream_checkpoint": receipt = rotate_stream_checkpoint(payload)
    elif mode == "validate_checkpoint_chain": receipt = validate_checkpoint_chain(payload)
    elif mode == "rotate_bounded_checkpoint": receipt = rotate_bounded_checkpoint(payload)
    elif mode == "validate_bounded_checkpoint": receipt = validate_bounded_stream_checkpoint(payload.get("checkpoint") or payload)
    elif mode == "validate_bounded_checkpoint_chain": receipt = validate_bounded_checkpoint_chain(payload)
    elif mode == "receipt_id_membership_no_go": receipt = exact_membership_bounded_no_go(payload)
    elif mode == "receipt_id_proof": receipt = sparse_receipt_id_proof(payload.get("receipt_ids") or (), payload.get("receipt_id"))
    elif mode == "verify_receipt_id_proof": receipt = verify_sparse_receipt_id_proof(payload.get("root"), payload.get("receipt_id"), payload.get("proof") or {}, expected_present=payload.get("expected_present"))
    elif mode == "receipt_id_insert_root": receipt = sparse_receipt_id_insert(payload.get("root"), payload.get("receipt_id"), payload.get("proof") or {})
    elif mode == "rotate_witnessed_checkpoint": receipt = rotate_witnessed_checkpoint(payload)
    elif mode == "validate_witnessed_checkpoint": receipt = validate_witnessed_checkpoint(payload.get("checkpoint") or payload)
    elif mode == "validate_witnessed_checkpoint_transition": receipt = validate_witnessed_checkpoint_transition(payload)
    elif mode == "receipt_id_sidecar_snapshot": receipt = receipt_id_sidecar_snapshot(payload)
    elif mode == "validate_receipt_id_sidecar_snapshot": receipt = validate_receipt_id_sidecar_snapshot(payload.get("snapshot") or payload)
    elif mode == "receipt_id_sidecar_recover": receipt = recover_receipt_id_sidecar(payload)
    elif mode == "receipt_id_sidecar_append": receipt = append_receipt_id_sidecar(payload)
    elif mode == "receipt_id_sidecar_proof": receipt = receipt_id_sidecar_proof(payload)
    elif mode == "receipt_id_sidecar_compact": receipt = compact_receipt_id_sidecar(payload)
    elif mode == "receipt_id_sidecar_snapshot_chain": receipt = receipt_id_sidecar_snapshot_chain(payload)
    elif mode == "receipt_id_sidecar_snapshot_chain_append": receipt = receipt_id_sidecar_snapshot_chain_append(payload)
    elif mode == "validate_receipt_id_sidecar_snapshot_chain": receipt = validate_receipt_id_sidecar_snapshot_chain(payload)
    elif mode == "validate_receipt_id_sidecar_compaction_transition": receipt = validate_receipt_id_sidecar_compaction_transition(payload)
    elif mode == "receipt_id_sidecar_compaction_decision": receipt = receipt_id_sidecar_compaction_decision(payload)
    elif mode == "receipt_id_sidecar_auto_compact": receipt = receipt_id_sidecar_auto_compact(payload)
    elif mode == "memory_144_catalog": receipt = memory_144_catalog(payload)
    elif mode == "memory_144_init": receipt = memory_144_init(payload)
    elif mode == "memory_144_drop": receipt = memory_144_drop(payload)
    elif mode == "memory_144_trace": receipt = memory_144_trace(payload)
    elif mode == "memory_144_validate": receipt = validate_memory_144_state(payload.get("state") or payload)
    elif mode == "memory_144_reconstruct": receipt = memory_144_reconstruct(payload)
    elif mode == "memory_144_activation_catalog": receipt = memory_144_activation_catalog(payload)
    elif mode == "memory_144_activate": receipt = memory_144_activate(payload)
    elif mode == "memory_144_validate_activation": receipt = validate_memory_144_activation(payload)
    elif mode == "memory_144_compile_capability_request": receipt = memory_144_compile_capability_request(payload)
    elif mode == "memory_144_validate_capability_request": receipt = validate_memory_144_capability_request(payload)
    elif mode == "memory_144_execute_capability": receipt = memory_144_execute_capability(payload)
    elif mode == "memory_144_validate_capability_execution": receipt = validate_memory_144_capability_execution(payload)
    elif mode == "memory_144_activation_to_capability": receipt = memory_144_activation_to_capability(payload)
    elif mode == "memory_144_pipeline_replay": receipt = memory_144_pipeline_replay(payload)
    elif mode == "memory_144_create_unified_checkpoint": receipt = memory_144_create_unified_checkpoint(payload)
    elif mode == "memory_144_validate_unified_checkpoint": receipt = validate_memory_144_unified_checkpoint(payload)
    elif mode == "memory_144_resume_unified_checkpoint": receipt = memory_144_resume_unified_checkpoint(payload)
    elif mode == "memory_144_rotate_unified_checkpoint": receipt = memory_144_rotate_unified_checkpoint(payload)
    elif mode == "memory_144_validate_unified_transition": receipt = validate_memory_144_unified_transition(payload)
    elif mode == "memory_144_terminal_replay": receipt = memory_144_terminal_replay(payload)
    elif mode == "memory_144_create_terminal_checkpoint": receipt = memory_144_create_terminal_checkpoint(payload)
    elif mode == "memory_144_validate_terminal_checkpoint": receipt = validate_memory_144_terminal_checkpoint(payload.get("checkpoint") or payload)
    elif mode == "memory_144_resume_terminal_checkpoint": receipt = memory_144_resume_terminal_checkpoint(payload)
    elif mode == "memory_144_rotate_terminal_checkpoint": receipt = memory_144_rotate_terminal_checkpoint(payload)
    elif mode == "memory_144_validate_terminal_transition": receipt = validate_memory_144_terminal_transition(payload)
    else: receipt = {"status": "UNSUPPORTED_MODE", "supported_modes": list(capabilities()["capabilities"].keys())}
    return provider_envelope(mode, receipt, rid)
