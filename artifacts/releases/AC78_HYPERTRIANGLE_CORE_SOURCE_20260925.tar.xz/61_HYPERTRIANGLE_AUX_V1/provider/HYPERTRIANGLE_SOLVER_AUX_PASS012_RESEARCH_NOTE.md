# HyperTriangle Solver AUX — PASS012 Research Note

Date: 2026-09-25  
Branch: `HYPERTRIANGLE_SOLVER_AUX`  
Parent: PASS011 standalone AUX.  
Scope: close the standalone memory-to-capability bridge. **No AC77/DD094 integration, ROOT/RETURN write, or external solver mutation.**

## 1. Frontier closed
PASS011 stopped at relevance:

`certified memory -> declared activation contract -> capability relevance receipt`.

PASS012 closes the next local bridge:

`memory -> activation receipt -> typed capability request -> local capability receipt -> provenance`.

The bridge executes only a capability already declared ACTIVE by a valid PASS011 activation receipt. It never invents a capability from a slot and never uses capability output as new memory evidence.

## 2. Typed request
`memory_144_compile_capability_request` requires:

- a valid PASS011 activation receipt;
- one target among the 19 PASS011 activatable local AUX capabilities;
- the unique active contract for that target;
- an explicit capability payload object.

The typed request commits to:

- source memory state hash and trace accumulator;
- source activation state hash and contracts hash;
- source active contract;
- exact supporting canonical slots;
- commitments to the surviving last certified invariants;
- target capability;
- capability payload and SHA-256 commitment;
- causal parent and generation;
- zero-authority and no-feedback policy.

## 3. Local execution boundary
`memory_144_execute_capability` dispatches only the 19 standalone local operations already admitted by PASS011. It does not dispatch memory operations, sidecar maintenance, AC77, DD094, ROOT/RETURN operations, or the bridge itself.

Execution is pure and local. The existing capability result is wrapped without semantic promotion. A local capability may therefore return a resolved, unresolved, blocked, or diagnostic receipt; PASS012 certifies the dispatch/provenance chain, not scientific truth.

## 4. Causal chain
The proof objects are hash-bound as:

`memory_state_hash`
` -> activation_state_hash`
` -> typed_request_hash`
` -> capability_receipt_hash`
` -> capability_execution_hash`.

The typed request has causal generation 1 and parent `MEMORY_144_ACTIVATION_STATE`. The execution receipt has causal generation 2 and parent `MEMORY_144_TYPED_CAPABILITY_REQUEST`.

## 5. Anti-feedback firewall
PASS012 explicitly records:

- `memory_feedback_performed = false`;
- `activation_reentry_performed = false`;
- `memory_feedback_policy = FORBIDDEN_NO_AUTOMATIC_MEMORY_DROP_OR_REACTIVATION`.

No bridge path calls `memory_144_drop`, `memory_144_activate`, or another bridge operation after capability execution. A capability receipt can affect memory only if some later external process independently supplies a new typed memory event under the normal PASS010 rules; PASS012 grants no automatic path.

## 6. Deterministic replay
A capability execution receipt can be validated structurally from its commitments. When the typed request is supplied, the validator reruns the exact local capability and requires the replayed receipt to match the committed receipt exactly.

Identical memory, activation, contract, capability, and payload produce identical typed-request and execution hashes.

## 7. Dispatch coverage
All 19 PASS011 activatable capabilities are exercised through the bridge and compared against the corresponding direct local provider result. The wrapped capability receipt is exactly equal to the direct local result after canonical encoding.

## 8. Validation
- cumulative unit/regression tests: **175/175 PASS**;
- qualification: **7,360/7,360 PASS**;
- qualification randomized bridge cases: **1,200**;
- independent verifier: **3,696/3,696 PASS**;
- independent canonical slot support cases: **144/144**;
- independent randomized direct-replay route cases: **700/700**;
- request tamper cases: **9/9 rejected**;
- execution tamper cases: **10/10 rejected**;
- cold replay: byte-identical PASS;
- memory feedback events: **0**.

## 9. Parent integrity
222 parent files remain byte-identical outside declared mutable files. One PASS011 test-only version assertion was maintained from exact `0.11.0` to semantic compatibility `>= 0.11.0`, because the previous exact assertion would intentionally fail every later cumulative release. This changes no PASS011 runtime semantics and is explicitly listed in the parent-integrity receipt.

## 10. Authority firewall
Unchanged:

- `truth_credit = 0`;
- ROOT write = `NONE`;
- RETURN write = `NONE`;
- solver mutation = `NONE`;
- AC77 integration = `NOT_PERFORMED`;
- DD094 integration = `NOT_PERFORMED`.

## 11. Next front
PASS013 should unify the PASS010/PASS011/PASS012 memory-activation-execution state with the persistent checkpoint lineage already built in PASS003–PASS009, so crash/restart proves:

`checkpoint + suffix == full replay`

for memory state, activation state, typed capability requests, and capability execution provenance together.
