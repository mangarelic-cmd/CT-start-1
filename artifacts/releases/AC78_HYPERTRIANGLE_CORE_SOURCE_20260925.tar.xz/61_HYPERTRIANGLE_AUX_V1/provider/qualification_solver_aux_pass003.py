#!/usr/bin/env python3
import random
from hypertriangle_solver_aux import certify_receipt_stream

C={"common_scale_certified":True,"axis_independence_certified":True,"b4_comparable":True}

def state(v,e): return {"values":v,"component_errors":[e]*4,"contracts":C}
def event(w,t,axis,e):
    base=[8,6,4,2]; L=base[:]; R=base[:]; L[axis]=-2; R[axis]=2; a=[0,0,0,0]; a[axis]=1
    return {"wall_id":w,"alpha":a,"left":{"time":t-1,"values":L},"right":{"time":t+1,"values":R},"uniform_component_errors":[e]*4,
            "derivative_direction":1,"derivative_magnitude_lower":1,"derivative_error":e,"nominal_time":t,
            "contracts":{"uniform_error_over_bracket_certified":True}}

def main():
    rng=random.Random(3003); checks=0
    for trial in range(20000):
        eps="1/100" if trial%5 else "1/20"
        rec=[
          {"receipt_id":f"a{trial}","sequence":1,"slot":"S0","kind":"state","payload":state([8,6,4,2],eps)},
          {"receipt_id":f"b{trial}","sequence":2,"slot":"E0","kind":"event","payload":event("w0",2,0,eps)},
          {"receipt_id":f"c{trial}","sequence":3,"slot":"S1","kind":"state","payload":state([7,-5,3,1],eps)},
          {"receipt_id":f"d{trial}","sequence":4,"slot":"E1","kind":"event","payload":event("w1",5,1,eps)},
        ]
        # permute arrival order but keep stream sequence canonical after permutation
        rng.shuffle(rec)
        for i,e in enumerate(rec,1): e["sequence"]=i
        p={"stream_id":f"q{trial}","requirements":{"required_state_slots":["S0","S1"],"required_event_slots":["E0","E1"],"required_wall_sequence":["w0","w1"]},"receipts":rec}
        r=certify_receipt_stream(p)
        assert r["historical_terminal"] and r["first_terminal_prefix"]==4 and r["stop_recommended"]
        checks+=3
        if trial%2==0:
            p["receipts"].append({"receipt_id":f"x{trial}","sequence":5,"slot":"S1","kind":"state","payload":{"values":[1,2,3,4],"component_errors":[2,0,0,0],"contracts":C}})
            q=certify_receipt_stream(p)
            assert q["first_terminal_prefix"]==4 and q["historical_terminal"] and not q["current_terminal"]
            checks+=3
        else:
            p["receipts"].append({"receipt_id":f"x{trial}","sequence":5,"slot":"J","kind":"state","payload":state([9,7,5,3],eps)})
            q=certify_receipt_stream(p)
            assert q["first_terminal_prefix"]==4 and q["historical_terminal"] and q["current_terminal"]
            checks+=3
    print(f"QUALIFICATION PASS003: {checks}/{checks} PASS")
if __name__=='__main__': main()
