import copy, json, random
import hypertriangle_solver_aux as h


def main():
    rng=random.Random(2026092512)
    cat=h.memory_144_catalog({})['slots']
    targets=h.memory_144_activation_catalog({})['activatable_capabilities']
    checks=0
    assert len(cat)==144 and len(targets)==19; checks+=2

    # Every canonical slot can be the declared certified causal support for a bridge request.
    slot_cases=0
    for i,row in enumerate(cat):
        cap=targets[i%len(targets)]
        s=h.memory_144_init({})['state']
        s=h.memory_144_drop({'state':s,'datum_id':f'S{i}','signals':[{'operator':row['operator'],'certified':True,'projection':f'slot-{i}'}]})['state']
        c={'contract_id':f'SLOT-{i:03d}','capability':cap,'requires_all':[row['slot']]}
        a=h.memory_144_activate({'state':s,'contracts':[c]})['receipt']
        b=h.memory_144_activation_to_capability({'state':s,'activation_receipt':a,'capability':cap,'capability_payload':{}})
        assert b['bridge_valid']; checks+=1
        q=b['request']; x=b['execution_receipt']
        assert q['supporting_slots']==(row['slot'],); checks+=1
        assert q['source_memory_state_hash']==s['state_hash'] and q['source_activation_state_hash']==a['activation_state_hash']; checks+=1
        assert h.validate_memory_144_capability_request({'request':q,'activation_receipt':a,'state':s})['request_valid']; checks+=1
        assert h.validate_memory_144_capability_execution({'receipt':x,'request':q,'activation_receipt':a,'state':s})['execution_valid']; checks+=1
        assert x['capability_receipt']==h.encode(h.handle_request({'mode':cap,'payload':{}})['receipt']); checks+=1
        slot_cases+=1

    # Independent random route payload replay and provenance check.
    route_cases=700
    s=h.memory_144_init({})['state']
    s=h.memory_144_drop({'state':s,'signals':[{'operator':'IDENTITY_SEED','certified':True}]})['state']
    c={'contract_id':'ROUTE','capability':'route_simplex','requires_all':['F001']}
    a=h.memory_144_activate({'state':s,'contracts':[c]})['receipt']
    for t in range(route_cases):
        n=1+rng.randrange(7)
        vals=[rng.randrange(0,10000) for _ in range(n)]
        if not any(vals): vals[0]=1
        p={'trace_id':f'I{t}','contracts':{'additive':True,'common_ledger':True,'positivity_certified':True,'grounded':True},'cells':[{'occurrence_id':f'x{k}','weight':v} for k,v in enumerate(vals)]}
        b=h.memory_144_activation_to_capability({'activation_receipt':a,'capability':'route_simplex','capability_payload':p})
        assert b['bridge_valid']; checks+=1
        q=b['request']; x=b['execution_receipt']
        assert h.validate_memory_144_capability_execution({'receipt':x})['execution_valid']; checks+=1
        if t%70==0:
            assert h.validate_memory_144_capability_execution({'receipt':x,'request':q,'activation_receipt':a,'state':s})['execution_valid']; checks+=1
        assert x['capability_receipt']==h.encode(h.compile_route(p)); checks+=1
        assert x['memory_feedback_performed'] is False and x['activation_reentry_performed'] is False; checks+=1

    # Tamper matrix over independent fields in both proof objects.
    q=h.memory_144_compile_capability_request({'state':s,'activation_receipt':a,'capability':'route_simplex','capability_payload':{'cells':[{'occurrence_id':'a','weight':1}]}})['request']
    x=h.memory_144_execute_capability({'request':q,'activation_receipt':a,'state':s})['receipt']
    request_tampers=[
        ('source_memory_state_hash','0'*64),('source_activation_state_hash','0'*64),('source_contracts_hash','0'*64),
        ('capability_payload_hash','0'*64),('typed_request_hash','0'*64),('causal_generation',2),
        ('memory_feedback_policy','ALLOW'),('target_capability','memory_144_drop'),('truth_credit',1),
    ]
    for field,value in request_tampers:
        bad=copy.deepcopy(q); bad[field]=value
        assert not h.validate_memory_144_capability_request({'request':bad})['request_valid']; checks+=1
    execution_tampers=[
        ('source_memory_state_hash','0'*64),('source_activation_state_hash','0'*64),('typed_request_hash','0'*64),
        ('capability_receipt_hash','0'*64),('capability_execution_hash','0'*64),('causal_generation',1),
        ('execution_count',2),('memory_feedback_performed',True),('activation_reentry_performed',True),('truth_credit',1),
    ]
    for field,value in execution_tampers:
        bad=copy.deepcopy(x); bad[field]=value
        assert not h.validate_memory_144_capability_execution({'receipt':bad})['execution_valid']; checks+=1

    # Even a correctly rehashed external target is rejected before execution because it is outside the allowlist.
    fake=copy.deepcopy(q); fake['target_capability']='memory_144_activate'
    fake['typed_request_hash']=h._memory_144_capability_request_hash({k:copy.deepcopy(v) for k,v in fake.items() if k!='typed_request_hash'})
    assert not h.validate_memory_144_capability_request({'request':fake})['request_valid']; checks+=1

    print(json.dumps({
        'status':'PASS','checks':checks,'slot_cases':slot_cases,'dispatch_targets':len(targets),
        'random_route_cases':route_cases,'request_tamper_cases':len(request_tampers),
        'execution_tamper_cases':len(execution_tampers),'memory_feedback_events':0,'truth_credit':0,
    },sort_keys=True))

if __name__=='__main__': main()
