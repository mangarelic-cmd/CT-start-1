#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
import receipt_id_sidecar as s


def emit(x):
    json.dump(x,sys.stdout,indent=2,sort_keys=True,ensure_ascii=False); sys.stdout.write("\n")

def main(argv=None):
    p=argparse.ArgumentParser(description="HyperTriangle exact receipt-ID sidecar")
    sub=p.add_subparsers(dest="cmd",required=True)
    a=sub.add_parser("init"); a.add_argument("snapshot"); a.add_argument("journal"); a.add_argument("receipt_ids",nargs="*")
    a=sub.add_parser("append"); a.add_argument("snapshot"); a.add_argument("journal"); a.add_argument("receipt_id")
    a=sub.add_parser("verify"); a.add_argument("snapshot"); a.add_argument("journal"); a.add_argument("--strict-tail",action="store_true")
    a=sub.add_parser("proof"); a.add_argument("snapshot"); a.add_argument("journal"); a.add_argument("receipt_id")
    a=sub.add_parser("compact"); a.add_argument("snapshot"); a.add_argument("journal"); a.add_argument("new_snapshot"); a.add_argument("new_journal")
    ns=p.parse_args(argv)
    if ns.cmd=="init":
        snap=s.init_snapshot(ns.snapshot,ns.receipt_ids); s.ensure_journal(ns.journal); emit({"status":"SIDECAR_INITIALIZED","snapshot":snap})
    elif ns.cmd=="append": emit(s.append_file(ns.snapshot,ns.journal,ns.receipt_id))
    elif ns.cmd=="verify": emit(s.recover_files(ns.snapshot,ns.journal,allow_uncommitted_tail=not ns.strict_tail))
    elif ns.cmd=="proof": emit(s.proof_files(ns.snapshot,ns.journal,ns.receipt_id))
    elif ns.cmd=="compact": emit(s.compact_files(ns.snapshot,ns.journal,ns.new_snapshot,ns.new_journal))

if __name__=="__main__": main()
