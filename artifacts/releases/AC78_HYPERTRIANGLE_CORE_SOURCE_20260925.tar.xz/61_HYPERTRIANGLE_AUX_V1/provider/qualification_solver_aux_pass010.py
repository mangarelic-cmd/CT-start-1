import json, random
import hypertriangle_solver_aux as h

def main():
    rng=random.Random(10010); cat=h.memory_144_catalog({})['slots']; checks=0
    s=h.memory_144_init({})['state']
    for t in range(1,2001):
        k=1+rng.randrange(4); inds=rng.sample(range(144),k); sig=[]
        for i in inds:
            sig.append({'operator':cat[i]['operator'],'certified':rng.random()<0.8,'projection':f'q{t}_{i}','context':{'t':t}})
        r=h.memory_144_drop({'state':s,'datum_id':f'Q{t}','signals':sig}); assert r['memory_valid']; s=r['state']; checks+=1
        assert r['trace_index']==t; checks+=1
        assert set(r['flagged_slots'])=={cat[i]['slot'] for i in inds}; checks+=1
        for i in inds:
            assert s['flags'][i]; checks+=1
        if t%25==0:
            assert h.validate_memory_144_state(s)['memory_valid']; checks+=1
    recon=h.memory_144_reconstruct({'state':s}); assert recon['reconstruction_valid']; checks+=1
    assert recon['event_count']==2000 and recon['trace_start']==1; checks+=2
    bad=h.memory_144_drop({'state':s,'data':{'x':1}}); assert not bad['memory_valid']; checks+=1
    # Every canonical operator must have been source-bound to one unique slot.
    assert len({x['operator'] for x in cat})==144; checks+=1
    print(json.dumps({'status':'PASS','checks':checks,'events':2000,'flagged_slots':sum(s['flags']),'certified_slots':sum(s['certified_flags']),'state_bytes':len(json.dumps(h.encode(s),sort_keys=True,separators=(",",":"),ensure_ascii=False).encode())},sort_keys=True))
if __name__=='__main__': main()
