#!/usr/bin/env python3
from fractions import Fraction
from itertools import product
from hypertriangle_solver_aux import robust_b4_state, certify_wall_event, certify_b4_route, certify_receipt_bundle

C={"common_scale_certified":True,"axis_independence_certified":True,"b4_comparable":True}
checks=0

def ck(x):
    global checks
    checks+=1
    if not x: raise AssertionError(f"qualification failure at {checks}")

# 20k robust interior states with deterministic varying magnitudes/signs/errors.
for n in range(1,20001):
    mags=[Fraction(80+(n%7),10), Fraction(60+(n%5),10), Fraction(40+(n%3),10), Fraction(20+(n%2),10)]
    signs=[1 if ((n>>i)&1) else -1 for i in range(4)]
    vals=[signs[i]*mags[i] for i in range(4)]
    eps=[Fraction(1,100)]*4
    r=robust_b4_state({"values":vals,"component_errors":eps,"contracts":C})
    ck(r["certified_same_B4_chamber"])

# 10k deliberate sign-wall unresolved cases.
for n in range(1,10001):
    vals=[Fraction(1,100), 6, 4, 2]
    eps=[Fraction(1,50),0,0,0]
    r=robust_b4_state({"values":vals,"component_errors":eps,"contracts":C})
    ck(not r["certified_same_B4_chamber"])

# 10k deliberate equal-magnitude-wall unresolved cases.
for n in range(1,10001):
    vals=[8,Fraction(799,100),4,2]
    eps=[Fraction(1,100),Fraction(1,100),0,0]
    r=robust_b4_state({"values":vals,"component_errors":eps,"contracts":C})
    ck(not r["certified_same_B4_chamber"])

# 10k event receipts, half valid, half intentionally invalid by derivative budget.
for n in range(1,10001):
    good=(n%2)==0
    p={"wall_id":"x","alpha":[1,0,0,0],"left":{"time":0,"values":[-2,7,4,1]},"right":{"time":2,"values":[2,7,4,1]},
       "uniform_component_errors":[Fraction(1,100),0,0,0],"derivative_direction":1,"derivative_magnitude_lower":1,
       "derivative_error":Fraction(1,100) if good else 2,"nominal_time":1,
       "contracts":{"uniform_error_over_bracket_certified":True}}
    r=certify_wall_event(p)
    ck(r["certified_unique_crossing"]==good)

# 5k receipt bundles / route certificates.
for n in range(1,5001):
    state={"values":[8,6,4,2],"component_errors":[Fraction(1,100)]*4,"contracts":C}
    events=[]
    for j,t in enumerate((2,5)):
        events.append({"wall_id":f"w{j}","alpha":[1,0,0,0],"left":{"time":t-1,"values":[-2,7,4,1]},"right":{"time":t+1,"values":[2,7,4,1]},
            "uniform_component_errors":[Fraction(1,100),0,0,0],"derivative_direction":1,"derivative_magnitude_lower":1,
            "derivative_error":Fraction(1,100),"nominal_time":t,"contracts":{"uniform_error_over_bracket_certified":True}})
    r=certify_receipt_bundle({"states":[state],"route":{"events":events}})
    ck(r["terminal"])

print(f"QUALIFICATION_PASS002={checks}/{checks} PASS")
