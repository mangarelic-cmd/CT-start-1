# HyperTriangle Solver AUX — PASS001 Research Note

Date: 2026-09-25  
Branch: `HYPERTRIANGLE_SOLVER_AUX`  
Parent theory: terminal HyperTriangle PASS052R1  
Integration scope: **standalone AUX only; no AC77/DD094 mutation or registry insertion**.

## 1. Objective

Turn the completed HyperTriangle theory into a small executable solver-side component without reopening the theoretical project.

The original HyperTriangle AUX had already demonstrated an exact solver-trace path:

`typed route -> active support -> simplex -> face/superface transition verdict`.

PASS001 lifts that capability into a standalone provider front door and adds the final B4 signed-dominance compiler from the closed theory.

## 2. Provider authority

The provider is intentionally non-sovereign:

- `truth_credit = 0`;
- `root_write_capability = NONE`;
- `return_write_capability = NONE`;
- `solver_mutation_capability = NONE`.

It emits typed receipts only.

## 3. Solver capabilities

### A. Route simplex

Consumes a typed additive nonnegative route ledger or exact normalized q-boundaries. Produces composition, magnitude when known, active support, arity, zero-width singularities, and provenance/firewall status.

### B. Route transition

For two route states, determines whether the change is an exact simplicial face lift/restriction, same support, or support replacement. The canonical 3→4 fixture is recovered exactly.

### C. Signed polarity

A signed additive vector is not silently normalized as nonnegative mass. It is lifted canonically to positive/negative parts and to its signed cross-polytope sector.

### D. B4 state

Exactly four scalar axes may be promoted to a HyperTriangle B4 state only when three contracts are explicit:

1. common physical/solver scale;
2. axis independence;
3. B4 magnitude comparability.

For a generic interior point the AUX returns the sign vector, strict descending magnitude permutation, chamber id, four simple-root wall margins, chamber barycentric coordinates and four simple-reflection neighbors. Zero amplitudes or magnitude ties return a boundary-stratum receipt rather than a fabricated unique chamber.

## 4. Why the new branch is separate

The theoretical HyperTriangle is already closed. Solver integration is engineering/infrastructure work. Keeping a separate AUX branch prevents later changes in a solver ABI from mutating the mathematical theorem archive.

## 5. PASS001 terminal state

`STANDALONE_AUX = READY`  
`AC77_INTEGRATION = NOT_PERFORMED`  
`DD094_INTEGRATION = NOT_PERFORMED`  
`ROOT_TRUTH_CREDIT = 0`  
`THEORY_REOPENED = NO`

Next engineering front: enrich receipts with robust uncertainty budgets and event/route certification from the terminal HyperTriangle machinery, still without integrating into a sovereign solver.

## 6. Validation

- unit tests: **9/9 PASS**;
- independent verifier: **1,946/1,946 PASS**;
- deterministic qualification: **25,384/25,384 PASS**;
- exhaustive B4 interiors: **384/384 PASS**.

No AC77/DD094 integration was performed.
