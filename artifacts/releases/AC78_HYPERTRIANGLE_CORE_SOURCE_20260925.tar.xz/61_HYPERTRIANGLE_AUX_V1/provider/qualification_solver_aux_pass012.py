import copy, json, random
import hypertriangle_solver_aux as h


def main():
    rng=random.Random(12012)
    cat=h.memory_144_catalog({})['slots']
    targets=h.memory_144_activation_catalog({})['activatable_capabilities']
    checks=0

    # Fully certified support state: one distinct canonical slot per executable local target.
    s=h.memory_144_init({})['state']
    s=h.memory_144_drop({'state':s,'datum_id':'Q12-ALL','signals':[{'operator':cat[i]['operator'],'certified':True,'projection':f'Q12-{i}'} for i in range(len(targets))]})['state']
    contracts=[{'contract_id':f'Q12-C{i:02d}','capability':cap,'requires_all':[cat[i]['slot']]} for i,cap in enumerate(targets)]
    act=h.memory_144_activate({'state':s,'contracts':contracts})
    assert act['activation_valid'] and len(act['active_capabilities'])==len(targets); checks+=2
    a=act['receipt']

    # Exercise every one of the 19 bridge dispatch targets and compare to the direct local provider result.
    all_exec_hashes=[]
    for i,cap in enumerate(targets):
        p={'state':s,'activation_receipt':a,'contract_id':f'Q12-C{i:02d}','capability':cap,'capability_payload':{}}
        c=h.memory_144_compile_capability_request(p); assert c['request_valid']; checks+=1
        q=c['request']
        assert h.validate_memory_144_capability_request({'request':q,'activation_receipt':a,'state':s})['request_valid']; checks+=1
        x=h.memory_144_execute_capability({'request':q,'activation_receipt':a,'state':s}); assert x['execution_valid']; checks+=1
        rec=x['receipt']
        assert h.validate_memory_144_capability_execution({'receipt':rec,'request':q,'activation_receipt':a,'state':s})['execution_valid']; checks+=1
        direct=h.handle_request({'mode':cap,'payload':{}})['receipt']
        assert rec['capability_receipt']==h.encode(direct); checks+=1
        assert rec['source_memory_state_hash']==s['state_hash'] and rec['source_activation_state_hash']==a['activation_state_hash']; checks+=1
        assert rec['memory_feedback_performed'] is False and rec['activation_reentry_performed'] is False; checks+=1
        all_exec_hashes.append(rec['capability_execution_hash'])

    # Random payload stress on two representative geometry/polarity capabilities.
    random_cases=1200
    for t in range(random_cases):
        if t%2==0:
            cap='route_simplex'; cid='Q12-C00'
            n=2+rng.randrange(5)
            payload={'trace_id':f'R{t}','contracts':{'additive':True,'common_ledger':True,'positivity_certified':True,'grounded':True},'cells':[{'occurrence_id':f'c{k}','weight':1+rng.randrange(1000)} for k in range(n)]}
        else:
            cap='signed_polarity'; cid='Q12-C02'
            payload={'values':[rng.randrange(-100,101) for _ in range(1+rng.randrange(12))]}
        b=h.memory_144_activation_to_capability({'activation_receipt':a,'contract_id':cid,'capability':cap,'capability_payload':payload})
        assert b['bridge_valid']; checks+=1
        q=b['request']; rec=b['execution_receipt']
        assert h.validate_memory_144_capability_request({'request':q})['request_valid']; checks+=1
        assert h.validate_memory_144_capability_execution({'receipt':rec})['execution_valid']; checks+=1
        if t%100==0:
            assert h.validate_memory_144_capability_request({'request':q,'activation_receipt':a,'state':s})['request_valid']; checks+=1
            assert h.validate_memory_144_capability_execution({'receipt':rec,'request':q,'activation_receipt':a,'state':s})['execution_valid']; checks+=1
        direct=h.handle_request({'mode':cap,'payload':payload})['receipt']
        assert rec['capability_receipt']==h.encode(direct); checks+=1
        # identical input must yield identical request/execution hashes
        b2=h.memory_144_activation_to_capability({'activation_receipt':a,'contract_id':cid,'capability':cap,'capability_payload':copy.deepcopy(payload)})
        assert b2['request']['typed_request_hash']==q['typed_request_hash']; checks+=1
        assert b2['execution_receipt']['capability_execution_hash']==rec['capability_execution_hash']; checks+=1
        all_exec_hashes.append(rec['capability_execution_hash'])

    # Anti-loop boundary: no activation contract can target the bridge/memory layer itself.
    bad=h.memory_144_activate({'state':s,'contracts':[{'contract_id':'LOOP','capability':'memory_144_activation_to_capability','requires_all':['F001']}]})
    assert not bad['activation_valid']; checks+=1

    print(json.dumps({
        'status':'PASS','checks':checks,'dispatch_targets':len(targets),'random_cases':random_cases,
        'unique_execution_hashes':len(set(all_exec_hashes)),'memory_feedback_events':0,
        'ac77_integration':'NOT_PERFORMED','dd094_integration':'NOT_PERFORMED','truth_credit':0,
    },sort_keys=True))

if __name__=='__main__': main()
