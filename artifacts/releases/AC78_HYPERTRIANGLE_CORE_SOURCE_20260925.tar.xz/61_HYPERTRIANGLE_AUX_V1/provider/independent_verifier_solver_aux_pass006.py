#!/usr/bin/env python3
import copy, hashlib, random
import hypertriangle_solver_aux as h

checks=0
def ck(x,msg='independent'):
    global checks
    checks+=1
    if not x: raise AssertionError(msg)
C={'common_scale_certified':True,'axis_independence_certified':True,'b4_comparable':True}
def state(vals,err='1/100'): return {'values':vals,'component_errors':[err]*4,'contracts':C}
def root(stream_id):
    s={'stream_id':stream_id,'requirements':{'required_state_slots':['S']},'receipts':[{'receipt_id':'r1','sequence':1,'slot':'S','kind':'state','payload':state([20,15,10,5])}]}
    return s,h.create_stream_checkpoint({'stream':s})['checkpoint']
def upd(seq,bad=False):
    p=state([100+seq,30,12,5]) if not bad else {'values':[1,2,3,4],'component_errors':[2,0,0,0],'contracts':C}
    return {'receipt_id':f'r{seq}','sequence':seq,'slot':'S','kind':'state','payload':p}
def seed():
    z=hashlib.sha256(); z.update(b'HYPERTRIANGLE_SOLVER_AUX_LINEAGE_ACCUMULATOR_V1\n'); z.update(b'EMPTY\n'); return z.hexdigest()
def step(acc,entry):
    z=hashlib.sha256(); z.update(b'HYPERTRIANGLE_SOLVER_AUX_LINEAGE_ACCUMULATOR_V1\n'); z.update(b'STEP\n'); z.update(bytes.fromhex(acc)); z.update(h._canonical_for_hash(entry)); return z.hexdigest()
def full_acc(chain_before_tip):
    a=seed()
    for cp in chain_before_tip: a=step(a,h._checkpoint_lineage_entry(cp))
    return a

rng=random.Random(6062026)
for case in range(80):
    stream,cp=root(f'i{case}')
    chain=[cp]; full=copy.deepcopy(stream); window=rng.randint(2,8); seq=1
    for rot in range(25):
        seq+=1
        bad=((case*31+rot)%97==0 and rot>2)
        e=upd(seq,bad=bad)
        rr=h.rotate_bounded_checkpoint({'checkpoint':cp,'receipts':[e],'anchor_window_size':window})
        ck(rr['rotated']); cp=rr['checkpoint']; chain.append(cp); full['receipts'].append(copy.deepcopy(e))
        ck(h.validate_bounded_stream_checkpoint(cp)['checkpoint_valid'])
        ck(cp['lineage_entry_count']==rot+1)
        ck(cp['lineage_compacted_count']+len(cp['lineage_anchors'])==rot+1)
        ck(len(cp['lineage_anchors'])<=window)
        ck(cp['lineage_accumulator']==full_acc(chain[:-1]))
        if rot>=window: ck(cp['lineage_compacted_count']>0)
    v=h.validate_bounded_checkpoint_chain({'checkpoints':chain}); ck(v['chain_valid'])
    replay=h.certify_receipt_stream(full); ck(cp['prefix_stream_hash']==replay['final_stream_hash'])
    ck(cp['first_terminal_prefix']==replay['first_terminal_prefix'])
    ck(cp['current_terminal_at_checkpoint']==replay['current_terminal'])

# Deep PASS005 -> bounded migration, independently recompute all ancestors.
for case in range(30):
    s,cp=root(f'm{case}'); old_chain=[cp]; seq=1
    for _ in range(12):
        seq+=1; cp=h.rotate_stream_checkpoint({'checkpoint':cp,'receipts':[upd(seq)]})['checkpoint']; old_chain.append(cp)
    seq+=1; child=h.rotate_bounded_checkpoint({'checkpoint':cp,'receipts':[upd(seq)],'anchor_window_size':5})['checkpoint']
    ck(child['rotation_index']==13); ck(child['lineage_compacted_count']==8); ck(len(child['lineage_anchors'])==5)
    ck(child['lineage_accumulator']==full_acc(old_chain))
    ck(h.validate_bounded_stream_checkpoint(child)['checkpoint_valid'])

# Rehashed compacted-prefix substitution is not independently reconstructible from tip alone,
# but must fail when the archived consecutive chain is supplied.
s,cp=root('tamper'); chain=[cp]
for seq in range(2,16):
    cp=h.rotate_bounded_checkpoint({'checkpoint':cp,'receipts':[upd(seq)],'anchor_window_size':3})['checkpoint']; chain.append(cp)
bad=copy.deepcopy(chain[-1]); bad['lineage_prefix_accumulator']='f'*64
bad['lineage_accumulator']=h._fold_lineage_accumulator(bad['lineage_anchors'],bad['lineage_prefix_accumulator'])
body={k:copy.deepcopy(v) for k,v in bad.items() if k!='checkpoint_hash'}; bad['checkpoint_hash']=h._bounded_checkpoint_hash_body(body)
ck(h.validate_bounded_stream_checkpoint(bad)['checkpoint_valid'])
ck(not h.validate_bounded_checkpoint_chain({'checkpoints':chain[:-1]+[bad]})['chain_valid'])

print(f'PASS006 independent verifier: {checks}/{checks} PASS')
