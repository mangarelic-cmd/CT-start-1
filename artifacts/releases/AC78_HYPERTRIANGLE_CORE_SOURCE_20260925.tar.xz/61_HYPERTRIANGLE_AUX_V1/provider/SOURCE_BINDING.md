# Source Binding — HYPERTRIANGLE_SOLVER_AUX PASS014

Parent standalone AUX: `HYPERTRIANGLE_SOLVER_AUX_PASS013_20260925.zip`.

Theory parent: `HYPERTRIANGLE_AUX_CUMULATIVE_PASS052R1_20260925.zip`.

PASS010 is source-bound to two existing project objects:

1. `CAUSAL_NUMEROLOGY_144_EN.pdf` — SHA-256 `4e7f2c5ef97e72f2ff7c8ed90fe8302fc567faeffe24b208bfd1a9e80960f8ac`.
   - source states a 144-slot `F001-F144` canon;
   - canonical meaning seeks the invariant first;
   - one slot may carry several valid projections;
   - context selects a manifestation and does not rewrite `F_n`;
   - the source reports 144/144 unique formal operators.

2. `1084CAUSAL_MEMORY_CERTIFIED_COHERENCE_COMPRESSION_EN_V2_1_20260917 (1)(1).pdf` — SHA-256 `5d125de85b50e07981f8323918f53ddc5ed1e783cc93163ed15f9422923ed7b2`.
   - store once what is common and reconstructible;
   - retain explicitly what remains independent;
   - exact replay requires a retained base/residual/decoder contract and fails closed when insufficient.

Project-owner trace contract used by PASS010: trace starts at `1`.

The embedded `CAUSAL_144_CANON.json` is a machine-readable extraction of all 144 canonical slot/operator bindings from the source edition. PASS010 does not alter the canonical functions.

No AC77, DD094, or other solver archive is modified or registered.

## PASS011 extension

PASS011 does not claim a source-derived semantic mapping from canonical slots to HyperTriangle solver operations because no such mapping is established by the PASS010 source binding.

Instead it materializes the narrower source-compatible bridge: **surviving certified invariants may satisfy explicit declared requirements**. The relation from those requirements to a local AUX capability is therefore carried by a typed activation contract, hashed into the receipt, rather than inferred by the provider.

This preserves the project direction `data -> invariant -> flag -> activation` and avoids reversing the memory grid into a classifier or retrieval system.

## PASS012 extension

PASS012 introduces no new source-derived slot-to-capability semantics. It consumes only a PASS011 relation that was already made explicit by an activation contract.

The new bridge binds that declared ACTIVE relation to an explicit local capability payload, executes the corresponding existing standalone AUX function, and stores the resulting local receipt under a causal provenance chain.

No scientific meaning is inferred from the fact that a capability executed. The capability receipt retains its own existing status and semantics. No capability output is automatically promoted to a new `F001..F144` memory event.

## PASS013 extension

PASS013 adds no new theory mapping and no new scientific semantics. It is a persistence integration of already-established local objects:

- PASS010 fixed `F001-F144` memory and last-certified-invariant state;
- PASS011 declared-contract activation state;
- PASS012 typed request and local capability execution provenance;
- PASS007 authenticated exact-ID root/witness mechanism;
- PASS008 exact external sidecar snapshot/journal recovery;
- PASS009 bounded sidecar snapshot-chain state.

The new unified checkpoint therefore preserves the existing direction of causality. Memory changes invalidate activation; activation must be recomputed from the new certified surviving invariants before a later capability can run. Capability output is not promoted into memory evidence.

The checkpoint is a continuation certificate. Exact reconstruction of discarded prefix payloads remains an archival responsibility, consistent with the earlier Causal Memory no-free-history boundary.


## PASS014 extension

PASS014 adds no source-derived criterion for scientific truth or universal completion. Terminality is intentionally contractual: the caller declares which already-existing certified AUX facts must hold for a local task to count as complete.

The contract may refer to certified F-slots, current PASS011 activation facts, and PASS012 local capability executions. Executions satisfy completion obligations only while bound to the current memory and activation hashes. This makes memory change a genuine causal invalidation rather than allowing historical capability output to remain falsely current.

The first terminal prefix follows the historical-freeze semantics already proven for the earlier receipt stream, but is now applied to the complete PASS013 memory/activation/execution pipeline. This is a local provenance property only; it does not promote an AUX result into scientific truth or external solver authority.


## PASS015 extension

PASS015 introduces no new external source and no new theory mapping. It is a release freeze over the cumulative standalone AUX already sourced and bounded in PASS001–PASS014. The v1 ABI freeze records byte hashes for the canonical 144-slot table, JSON schemas, implementation/CLI files, capability map and firewalls so the released object can be reconstructed and audited exactly.

Parent standalone AUX: `HYPERTRIANGLE_SOLVER_AUX_PASS014_20260925.zip`. External solver integration remains not performed.
