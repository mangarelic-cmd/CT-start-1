import copy, json, random
import hypertriangle_solver_aux as h


def main():
    checks=0
    cat=h.memory_144_catalog({})['slots']
    targets=h.memory_144_activation_catalog({})['activatable_capabilities']
    assert len(cat)==144 and targets; checks+=2
    # Every slot can independently support an explicitly declared activation.
    for i,row in enumerate(cat):
        s=h.memory_144_init({})['state']
        d=h.memory_144_drop({'state':s,'signals':[{'operator':row['operator'],'certified':True,'projection':f'p{i}'}]})
        assert d['memory_valid']; s=d['state']; checks+=1
        cap=targets[i%len(targets)]
        c={'contract_id':f'S{i:03d}','capability':cap,'requires_all':[row['slot']]}
        a=h.memory_144_activate({'state':s,'contracts':[c]})
        assert a['activation_valid'] and a['active_capabilities']==(cap,); checks+=2
        assert h.validate_memory_144_activation({'receipt':a['receipt'],'state':s})['activation_valid']; checks+=1
    # Exhaust all 20,592 ordered distinct slot pairs as two-part conjunctions.
    # Batch 19 contracts per activation call so the public API still evaluates every pair
    # while the 144-slot state is validated only once per batch.
    full=h.memory_144_init({})['state']
    full=h.memory_144_drop({'state':full,'signals':[{'operator':row['operator'],'certified':True} for row in cat]})['state']
    pairs=[(i,j) for i in range(144) for j in range(144) if i!=j]
    pair_cases=len(pairs)
    for base in range(0,len(pairs),len(targets)):
        chunk=pairs[base:base+len(targets)]
        contracts=[]
        for k,(i,j) in enumerate(chunk):
            contracts.append({'contract_id':f'P{i:03d}_{j:03d}','capability':targets[k],'requires_all':[cat[i]['slot'],cat[j]['slot']]})
        act=h.memory_144_activate({'state':full,'contracts':contracts})
        assert act['activation_valid']; checks+=1
        assert len(act['active_capabilities'])==len(chunk); checks+=1
        for e,(i,j) in zip(act['receipt']['evaluations'],sorted(chunk,key=lambda x:f'P{x[0]:03d}_{x[1]:03d}')):
            assert e['active'] and not e['missing_all']; checks+=1
            assert set(e['supporting_slots'])=={cat[i]['slot'],cat[j]['slot']}; checks+=1
    assert pair_cases==144*143; checks+=1
    # Random independent truth-table check for all/any/forbid semantics.
    rng=random.Random(2026092511)
    for t in range(1200):
        cert_inds=set(rng.sample(range(144),rng.randrange(0,25)))
        s=h.memory_144_init({})['state']
        if cert_inds:
            sig=[{'operator':cat[i]['operator'],'certified':True} for i in sorted(cert_inds)]
            s=h.memory_144_drop({'state':s,'signals':sig})['state']
        pos=[i for i in range(144)]
        req_all=set(rng.sample(pos,rng.randrange(1,4)))
        remaining=[i for i in pos if i not in req_all]
        req_any=set(rng.sample(remaining,rng.randrange(0,4)))
        remaining=[i for i in remaining if i not in req_any]
        forb=set(rng.sample(remaining,rng.randrange(0,3)))
        cap=targets[t%len(targets)]
        c={'contract_id':f'R{t}','capability':cap,'requires_all':[cat[i]['slot'] for i in req_all],'requires_any':[cat[i]['slot'] for i in req_any],'forbids':[cat[i]['slot'] for i in forb]}
        act=h.memory_144_activate({'state':s,'contracts':[c]})
        certified={cat[i]['slot'] for i in cert_inds}
        expected={cat[i]['slot'] for i in req_all} <= certified and (not req_any or bool({cat[i]['slot'] for i in req_any}&certified)) and not bool({cat[i]['slot'] for i in forb}&certified)
        assert bool(act['active_capabilities'])==expected; checks+=1
        assert h.validate_memory_144_activation({'receipt':act['receipt']})['activation_valid']; checks+=1
    # Tamper resistance and anti-inference firewall.
    s=h.memory_144_init({})['state']
    s=h.memory_144_drop({'state':s,'signals':[{'operator':'IDENTITY_SEED','certified':True}]})['state']
    no=h.memory_144_activate({'state':s,'contracts':[]}); assert no['activation_valid'] and no['active_capabilities']==(); checks+=2
    good=h.memory_144_activate({'state':s,'contracts':[{'contract_id':'T','capability':'route_simplex','requires_all':['F001']}]})['receipt']
    for field,value in [('certified_flag_mask_hex','0'*36),('contracts_hash','0'*64),('activation_state_hash','0'*64),('execution_performed',True)]:
        bad=copy.deepcopy(good); bad[field]=value
        assert not h.validate_memory_144_activation({'receipt':bad})['activation_valid']; checks+=1
    print(json.dumps({'status':'PASS','checks':checks,'slots':144,'ordered_pair_cases':pair_cases,'random_truth_table_cases':1200},sort_keys=True))
if __name__=='__main__': main()
