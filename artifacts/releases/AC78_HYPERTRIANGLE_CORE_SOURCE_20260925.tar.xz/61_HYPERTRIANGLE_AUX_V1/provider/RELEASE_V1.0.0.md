# HyperTriangle Solver AUX v1.0.0

Final standalone release corresponding to PASS015. No new functional semantics are introduced beyond PASS014; this release freezes and certifies the cumulative AUX surface.

Frozen: 61 capabilities, 35 schemas, F001–F144 canon, START=1 memory semantics, exact persistence/provenance, declared activation/execution, and declared local terminality.

Authority remains zero: no AC77/DD094 integration, no external provider registration, no ROOT/RETURN write, no solver mutation, and `truth_credit=0`.
