# HYPERTRIANGLE_SOLVER_AUX — PASS015 Research Note

Date: 2026-09-25  
Release: `1.0.0`  
Scope: final standalone freeze

## Purpose

PASS015 adds no new solver semantics. It freezes the cumulative PASS001–PASS014 AUX as a reproducible standalone v1 release. The functional endpoint entering this pass is already complete: fixed 144-slot memory, declared activation, typed local capability execution, exact persistent provenance/checkpoint continuation, and declared local terminality with immutable first-terminal history.

## Frozen surface

- 61 provider capabilities;
- 35 JSON schemas;
- F001–F144 canonical memory table;
- START=1 trace semantics;
- capability/firewall maps;
- six implementation/CLI files;
- authority boundary (`truth_credit=0`, no ROOT/RETURN write, no solver mutation, no external integration).

`HYPERTRIANGLE_SOLVER_AUX_V1_ABI_FREEZE.json` records the exact commitments. Its SHA-256 before packaging is `47e1d3389ff78e987fc40ab2c31e508df0ec5958aaa89f1a195f466b9600a6b5`.

## Compatibility correction

PASS014's test harness contained two literal `0.14.0` equality assertions. PASS015 changes only those assertions to compatibility checks `>= 0.14.0`, allowing the exact PASS014 semantics to be rerun under the v1.0.0 release number. No PASS014 functional rule is relaxed.

## Validation before packaging

- cumulative unit suite: 225/225 PASS;
- PASS015 qualification: 998/998 PASS;
- PASS015 independent freeze verifier: 62/62 PASS;
- all 144 slots independently satisfy a matching declared local terminal obligation;
- 64 checkpoint+suffix/full-replay equivalence cases;
- 61 dispatch modes exactly match the frozen capability ABI;
- 35 schema files and 6 implementation/CLI files match their frozen SHA-256 commitments;
- 4 freeze-tamper classes change their commitments;
- PASS001–PASS014: 97 pass-specific evidence files are byte-identical to the PASS014 parent archive.

## Boundary

The standalone AUX ends here. AC77/DD094 integration is not performed. Any provider registration, solver mutation, ROOT/RETURN authority, or external integration must occur in a separate integration branch and cannot be represented as part of the frozen standalone v1 ABI.

## Final packaging audit

The release archive passes CRC, root checksum verification and MANIFEST file/hash/size verification from a cold extraction. The cumulative unit suite, PASS015 qualification and PASS015 independent verifier all pass from that extracted archive. The deterministic release builder produces byte-identical archives, and the package contains zero `__pycache__` directories or `.pyc` files.
