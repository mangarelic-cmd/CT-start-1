#!/usr/bin/env python3
from __future__ import annotations
import argparse, json, sys
import receipt_id_sidecar_store as st

def emit(x):
    json.dump(x,sys.stdout,indent=2,sort_keys=True,ensure_ascii=False); sys.stdout.write("\n")

def main(argv=None):
    p=argparse.ArgumentParser(description="HyperTriangle durable generational receipt-ID sidecar store")
    sub=p.add_subparsers(dest="cmd",required=True)
    a=sub.add_parser("init"); a.add_argument("store"); a.add_argument("receipt_ids",nargs="*"); a.add_argument("--max-journal-records",type=int,default=256); a.add_argument("--max-journal-bytes",type=int,default=1<<20); a.add_argument("--anchor-window",type=int,default=8)
    a=sub.add_parser("append"); a.add_argument("store"); a.add_argument("receipt_id"); a.add_argument("--no-auto-compact",action="store_true")
    a=sub.add_parser("verify"); a.add_argument("store"); a.add_argument("--strict-tail",action="store_true"); a.add_argument("--audit-archives",action="store_true")
    a=sub.add_parser("proof"); a.add_argument("store"); a.add_argument("receipt_id")
    a=sub.add_parser("compact"); a.add_argument("store"); a.add_argument("--force",action="store_true")
    a=sub.add_parser("status"); a.add_argument("store")
    ns=p.parse_args(argv)
    if ns.cmd=="init": emit(st.init_store(ns.store,ns.receipt_ids,policy={"max_journal_records":ns.max_journal_records,"max_journal_bytes":ns.max_journal_bytes},anchor_window=ns.anchor_window))
    elif ns.cmd=="append": emit(st.append_store(ns.store,ns.receipt_id,auto_compact=not ns.no_auto_compact))
    elif ns.cmd=="verify": emit(st.verify_store(ns.store,strict_tail=ns.strict_tail,audit_archives=ns.audit_archives))
    elif ns.cmd=="proof": emit(st.proof_store(ns.store,ns.receipt_id))
    elif ns.cmd=="compact": emit(st.compact_store(ns.store,force=ns.force))
    elif ns.cmd=="status": emit(st.status_store(ns.store))

if __name__=="__main__": main()
