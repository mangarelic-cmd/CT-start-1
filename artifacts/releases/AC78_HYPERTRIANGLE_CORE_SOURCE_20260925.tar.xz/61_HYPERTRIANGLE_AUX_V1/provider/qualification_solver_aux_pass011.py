import json, random
import hypertriangle_solver_aux as h


def independent_expected(contract, certified):
    req_all=set(contract.get('requires_all') or ())
    req_any=set(contract.get('requires_any') or ())
    forb=set(contract.get('forbids') or ())
    return req_all <= certified and (not req_any or bool(req_any & certified)) and not bool(forb & certified)


def main():
    rng=random.Random(11011)
    cat=h.memory_144_catalog({})['slots']
    targets=h.memory_144_activation_catalog({})['activatable_capabilities']
    checks=0
    # 19 stable explicit contracts, each with positive support and a disjoint blocker.
    contracts=[]
    for i,cap in enumerate(targets):
        a=cat[(i*7)%144]['slot']; b=cat[(i*7+1)%144]['slot']; c=cat[(i*7+73)%144]['slot']
        contracts.append({'contract_id':f'Q{i:02d}','capability':cap,'requires_all':[a],'requires_any':[b],'forbids':([c] if i%3==0 else [])})
    s=h.memory_144_init({})['state']
    certified=set()
    activation_hashes=[]
    for t in range(1,3001):
        inds=rng.sample(range(144),1+rng.randrange(4))
        sig=[]
        for i in inds:
            cert=(rng.randrange(5)!=0)
            sig.append({'operator':cat[i]['operator'],'certified':cert,'projection':f'q{t}_{i}'})
            if cert: certified.add(cat[i]['slot'])
        d=h.memory_144_drop({'state':s,'datum_id':f'Q{t}','signals':sig})
        assert d['memory_valid']; s=d['state']; checks+=1
        a=h.memory_144_activate({'state':s,'contracts':contracts})
        assert a['activation_valid']; checks+=1
        got=set(a['active_capabilities'])
        exp={c['capability'] for c in contracts if independent_expected(c,certified)}
        assert got==exp; checks+=1
        v=h.validate_memory_144_activation({'receipt':a['receipt']})
        assert v['activation_valid']; checks+=1
        if t%50==0:
            vf=h.validate_memory_144_activation({'receipt':a['receipt'],'state':s})
            assert vf['activation_valid']; checks+=1
        activation_hashes.append(a['receipt']['activation_state_hash'])
    # Contract order must never influence the receipt.
    r1=h.memory_144_activate({'state':s,'contracts':contracts})
    r2=h.memory_144_activate({'state':s,'contracts':list(reversed(contracts))})
    assert r1['receipt']['activation_state_hash']==r2['receipt']['activation_state_hash']; checks+=1
    # Empty contract set may not infer relevance from the now densely populated memory.
    empty=h.memory_144_activate({'state':s,'contracts':[]})
    assert empty['activation_valid'] and not empty['active_capabilities']; checks+=1
    out={
        'status':'PASS','checks':checks,'events':3000,'contracts':len(contracts),
        'final_certified_slots':len(certified),'final_active_capabilities':len(r1['active_capabilities']),
        'unique_activation_hashes':len(set(activation_hashes))
    }
    print(json.dumps(out,sort_keys=True))
if __name__=='__main__': main()
