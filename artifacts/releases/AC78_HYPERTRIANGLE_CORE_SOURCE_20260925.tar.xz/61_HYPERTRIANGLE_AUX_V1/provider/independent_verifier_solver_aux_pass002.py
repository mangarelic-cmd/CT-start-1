#!/usr/bin/env python3
from fractions import Fraction
from itertools import permutations, product
from hypertriangle_solver_aux import robust_b4_state, b4_state, certify_wall_event, certify_b4_route

C={"common_scale_certified":True,"axis_independence_certified":True,"b4_comparable":True}
checks=0

def ck(cond,msg):
    global checks
    checks += 1
    if not cond:
        raise AssertionError(msg)

# Exhaustive 384 chambers; independently enumerate all 16 corners of each error box.
for signs in product((-1,1),repeat=4):
    for perm in permutations(range(4)):
        vals=[None]*4
        for rank,i in enumerate(perm): vals[i]=Fraction(signs[i]*(8-2*rank),1)
        eps=[Fraction(1,10)]*4
        r=robust_b4_state({"axis_ids":["a","b","c","d"],"values":vals,"component_errors":eps,"contracts":C})
        ck(r["certified_same_B4_chamber"],"robust chamber rejected")
        cid=r["chamber_id"]
        for corner in product((-1,1),repeat=4):
            vv=[vals[i]+corner[i]*eps[i] for i in range(4)]
            q=b4_state({"axis_ids":["a","b","c","d"],"values":vv,"contracts":C})
            ck(q["status"]=="B4_INTERIOR_CHAMBER","corner hit boundary unexpectedly")
            ck(q["chamber_id"]==cid,"corner changed chamber")

# Exact linear event family. A uniform wall disturbance delta shifts the root by <= E/slope;
# the AUX bound E/(slope-Ev) must contain all such shifts.
for k in range(1,1001):
    slope=Fraction(10+k%17,10)
    Ev=Fraction(1,100)
    E=Fraction(1+(k%5),100)
    tstar=Fraction(k,37)
    left_t=tstar-Fraction(2,1)
    right_t=tstar+Fraction(2,1)
    lv=slope*(left_t-tstar)
    rv=slope*(right_t-tstar)
    p={"wall_id":f"e{k}","alpha":[1,0,0,0],
       "left":{"time":left_t,"values":[lv,7,4,1]},
       "right":{"time":right_t,"values":[rv,7,4,1]},
       "uniform_component_errors":[E,0,0,0],
       "derivative_direction":1,"derivative_magnitude_lower":slope,"derivative_error":Ev,
       "nominal_time":tstar,"contracts":{"uniform_error_over_bracket_certified":True}}
    r=certify_wall_event(p)
    ck(r["certified_unique_crossing"],"linear crossing not certified")
    bound=r["root_time_shift_bound"]
    for delta in (-E,E):
        true_root=tstar-delta/slope
        ck(abs(true_root-tstar) <= bound,"true root outside certified bound")
        ck(r["certified_time_interval"][0] <= true_root <= r["certified_time_interval"][1],"true root outside interval")

# Route ordering family.
for k in range(1,401):
    events=[]
    for j,t in enumerate((2,5,8)):
        events.append({"wall_id":f"w{j}","alpha":[1,0,0,0],
            "left":{"time":t-1,"values":[-2,7,4,1]},"right":{"time":t+1,"values":[2,7,4,1]},
            "uniform_component_errors":[Fraction(1,100),0,0,0],"derivative_direction":1,
            "derivative_magnitude_lower":1,"derivative_error":Fraction(1,100),"nominal_time":t,
            "contracts":{"uniform_error_over_bracket_certified":True}})
    q=certify_b4_route({"events":events})
    ck(q["certified"],"separated route not certified")
    ck(all(g>0 for g in q["inter_event_gap_lower_bounds"]),"route gap nonpositive")

print(f"INDEPENDENT_PASS002={checks}/{checks} PASS")
