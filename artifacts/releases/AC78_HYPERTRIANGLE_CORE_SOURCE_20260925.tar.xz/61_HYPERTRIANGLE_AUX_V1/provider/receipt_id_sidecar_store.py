from __future__ import annotations

import hashlib, json, os, tempfile
from pathlib import Path
from typing import Any, Dict, Sequence

import hypertriangle_solver_aux as h
import receipt_id_sidecar as s

_POINTER_SCHEMA = "HYPERTRIANGLE_RECEIPT_ID_SIDECAR_STORE_POINTER_V1"
_POINTER_DOMAIN = b"HYPERTRIANGLE_RECEIPT_ID_SIDECAR_STORE_POINTER_V1\n"


def _canon_bytes(obj: Any) -> bytes:
    return json.dumps(h.encode(obj), sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _pointer_hash(body: Dict[str, Any]) -> str:
    q=hashlib.sha256(); q.update(_POINTER_DOMAIN); q.update(_canon_bytes(body)); return q.hexdigest()


def _atomic_write_bytes(path: Path, data: bytes) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    fd,tmp=tempfile.mkstemp(prefix=path.name+".", suffix=".tmp", dir=str(path.parent))
    try:
        with os.fdopen(fd,"wb") as f:
            f.write(data); f.flush(); os.fsync(f.fileno())
        os.replace(tmp,path)
        try:
            dfd=os.open(str(path.parent),os.O_RDONLY)
            try: os.fsync(dfd)
            finally: os.close(dfd)
        except Exception:
            pass
    finally:
        try:
            if os.path.exists(tmp): os.unlink(tmp)
        except Exception:
            pass


def _atomic_write_json(path: Path, obj: Any) -> None:
    _atomic_write_bytes(path, _canon_bytes(obj)+b"\n")


def default_policy() -> Dict[str, int]:
    return {"max_journal_records":256,"max_journal_bytes":1<<20}


def _normal_policy(policy: Dict[str, Any] | None) -> Dict[str, int]:
    src=policy or {}
    out={
        "max_journal_records":int(src.get("max_journal_records",256)),
        "max_journal_bytes":int(src.get("max_journal_bytes",1<<20)),
    }
    if out["max_journal_records"]<1 or out["max_journal_bytes"]<1:
        raise ValueError("compaction thresholds must be positive")
    return out


def _snapshot_rel(generation: int) -> str:
    return f"snapshots/g{generation:09d}.json"


def _journal_rel(generation: int) -> str:
    return f"journals/g{generation:09d}.ndjson"


def _pointer_body(generation: int, snapshot_rel: str, journal_rel: str, snapshot: Dict[str, Any], chain_state: Dict[str, Any], policy: Dict[str, int]) -> Dict[str, Any]:
    return {
        "schema":_POINTER_SCHEMA,
        "aux_name":h.AUX_NAME,
        "aux_version":h.AUX_VERSION,
        "generation":int(generation),
        "snapshot_file":snapshot_rel,
        "journal_file":journal_rel,
        "snapshot_hash":str(snapshot["snapshot_hash"]),
        "receipt_id_root":str(snapshot["receipt_id_root"]),
        "receipt_id_count":int(snapshot["receipt_id_count"]),
        "snapshot_chain_state":chain_state,
        "compaction_policy":policy,
        "truth_credit":0,
        "root_write_capability":"NONE",
        "return_write_capability":"NONE",
        "solver_mutation_capability":"NONE",
    }


def _make_pointer(*args, **kwargs) -> Dict[str, Any]:
    body=_pointer_body(*args, **kwargs); out=dict(body); out["pointer_hash"]=_pointer_hash(body); return out


def init_store(root: str | os.PathLike[str], receipt_ids: Sequence[Any]=(), *, policy: Dict[str, Any] | None=None, anchor_window: int=8, overwrite: bool=False) -> Dict[str, Any]:
    root=Path(root); current=root/"CURRENT.json"
    if current.exists() and not overwrite:
        raise ValueError("store already initialized")
    (root/"snapshots").mkdir(parents=True,exist_ok=True); (root/"journals").mkdir(parents=True,exist_ok=True)
    pol=_normal_policy(policy)
    created=h.receipt_id_sidecar_snapshot({"receipt_ids":list(receipt_ids),"generation":0})
    if not created.get("snapshot_valid",False): raise ValueError(created.get("error") or created.get("status"))
    snapshot=created["snapshot"]
    chain=h.receipt_id_sidecar_snapshot_chain({"snapshots":[snapshot],"anchor_window":anchor_window})
    if not chain.get("chain_valid",False): raise ValueError(chain.get("error") or chain.get("status"))
    srel=_snapshot_rel(0); jrel=_journal_rel(0)
    s.atomic_write_json(root/srel,snapshot); s.ensure_journal(root/jrel)
    pointer=_make_pointer(0,srel,jrel,snapshot,chain["chain_state"],pol)
    _atomic_write_json(current,pointer)
    return {"status":"SIDECAR_STORE_INITIALIZED","pointer":pointer,"store_root":str(root)}


def load_pointer(root: str | os.PathLike[str]) -> Dict[str, Any]:
    root=Path(root); p=root/"CURRENT.json"
    if not p.exists(): raise ValueError("CURRENT.json missing")
    obj=json.loads(p.read_text(encoding="utf-8"))
    if not isinstance(obj,dict) or obj.get("schema")!=_POINTER_SCHEMA: raise ValueError("invalid store pointer schema")
    supplied=str(obj.get("pointer_hash","")); body={k:v for k,v in obj.items() if k!="pointer_hash"}
    if supplied!=_pointer_hash(body): raise ValueError("store pointer hash mismatch")
    if obj.get("truth_credit")!=0 or obj.get("root_write_capability")!="NONE" or obj.get("return_write_capability")!="NONE" or obj.get("solver_mutation_capability")!="NONE": raise ValueError("store authority firewall violation")
    chain=h.validate_receipt_id_sidecar_snapshot_chain({"chain_state":obj.get("snapshot_chain_state") or {}})
    if not chain.get("chain_valid",False): raise ValueError("invalid bounded snapshot-chain state")
    return obj


def _paths(root: Path, pointer: Dict[str, Any]):
    return root/str(pointer["snapshot_file"]), root/str(pointer["journal_file"])


def verify_store(root: str | os.PathLike[str], *, strict_tail: bool=False, audit_archives: bool=False) -> Dict[str, Any]:
    root=Path(root); pointer=load_pointer(root); sp,jp=_paths(root,pointer)
    snapshot=s.load_snapshot(sp)
    if str(snapshot.get("snapshot_hash"))!=str(pointer.get("snapshot_hash")): raise ValueError("pointer snapshot hash mismatch")
    recovered=s.recover_files(sp,jp,allow_uncommitted_tail=not strict_tail)
    if not recovered.get("recovered",False): raise ValueError(recovered.get("error") or recovered.get("status"))
    chain=h.validate_receipt_id_sidecar_snapshot_chain({"chain_state":pointer["snapshot_chain_state"]})
    if str(chain.get("chain_state_hash"))!=str(pointer["snapshot_chain_state"].get("chain_state_hash")): raise ValueError("chain state mismatch")
    if int(pointer["generation"])!=int(snapshot["generation"]): raise ValueError("pointer generation mismatch")
    if int(pointer["receipt_id_count"])>int(recovered["receipt_id_count"]): raise ValueError("pointer receipt-id count exceeds recovered state")
    archive_audit=None
    if audit_archives:
        snaps=[]
        for g in range(int(pointer["generation"])+1):
            p=root/_snapshot_rel(g)
            if not p.exists(): raise ValueError(f"archived snapshot missing for generation {g}")
            snaps.append(s.load_snapshot(p))
        full=h.receipt_id_sidecar_snapshot_chain({"snapshots":snaps,"anchor_window":int(pointer["snapshot_chain_state"]["anchor_window"])})
        if not full.get("chain_valid",False): raise ValueError(full.get("error") or full.get("status"))
        if full["chain_state"]["chain_accumulator"]!=pointer["snapshot_chain_state"]["chain_accumulator"]: raise ValueError("archived snapshot-chain accumulator mismatch")
        archive_audit={"snapshot_count":len(snaps),"chain_accumulator":full["chain_state"]["chain_accumulator"]}
    return {
        "status":"SIDECAR_STORE_VALID",
        "generation":int(pointer["generation"]),
        "snapshot_hash":snapshot["snapshot_hash"],
        "receipt_id_root":recovered["receipt_id_root"],
        "receipt_id_count":recovered["receipt_id_count"],
        "journal_record_count":recovered["journal_record_count"],
        "truncated_tail_ignored":bool(recovered.get("truncated_tail_ignored",False)),
        "chain_state_hash":pointer["snapshot_chain_state"]["chain_state_hash"],
        "archive_audit":archive_audit,
        "truth_credit":0,
    }


def compaction_decision(root: str | os.PathLike[str]) -> Dict[str, Any]:
    root=Path(root); pointer=load_pointer(root); sp,jp=_paths(root,pointer); snapshot=s.load_snapshot(sp); jr=s.read_journal_records(jp,allow_uncommitted_tail=True)
    if jr["truncated_tail_ignored"]: raise ValueError("journal has uncommitted tail; repair before compaction decision")
    return h.receipt_id_sidecar_compaction_decision({"snapshot":snapshot,"journal_records":jr["records"],"policy":pointer["compaction_policy"]})


def compact_store(root: str | os.PathLike[str], *, force: bool=False) -> Dict[str, Any]:
    root=Path(root); pointer=load_pointer(root); sp,jp=_paths(root,pointer); snapshot=s.load_snapshot(sp); jr=s.read_journal_records(jp,allow_uncommitted_tail=True)
    if jr["truncated_tail_ignored"]: raise ValueError("cannot compact with uncommitted journal tail")
    decision=h.receipt_id_sidecar_compaction_decision({"snapshot":snapshot,"journal_records":jr["records"],"policy":pointer["compaction_policy"]})
    if not decision.get("decision_valid",False): raise ValueError(decision.get("error") or decision.get("status"))
    if not jr["records"]:
        return {"status":"SIDECAR_STORE_COMPACTION_NOT_REQUIRED","compaction_performed":False,"decision":decision,"generation":int(pointer["generation"])}
    if not force and not decision.get("compact_now",False):
        return {"status":"SIDECAR_STORE_COMPACTION_NOT_REQUIRED","compaction_performed":False,"decision":decision,"generation":int(pointer["generation"])}
    compacted=h.compact_receipt_id_sidecar({"snapshot":snapshot,"journal_records":jr["records"]})
    if not compacted.get("compacted",False): raise ValueError(compacted.get("status"))
    child=compacted["snapshot"]
    trans=h.validate_receipt_id_sidecar_compaction_transition({"parent_snapshot":snapshot,"journal_records":jr["records"],"child_snapshot":child})
    if not trans.get("transition_valid",False): raise ValueError(trans.get("error") or trans.get("status"))
    chain=h.receipt_id_sidecar_snapshot_chain_append({"chain_state":pointer["snapshot_chain_state"],"snapshot":child})
    if not chain.get("chain_valid",False): raise ValueError(chain.get("error") or chain.get("status"))
    g=int(child["generation"]); srel=_snapshot_rel(g); jrel=_journal_rel(g)
    # New generation files are durable before the active pointer is swapped.
    s.atomic_write_json(root/srel,child); s.ensure_journal(root/jrel)
    new_pointer=_make_pointer(g,srel,jrel,child,chain["chain_state"],pointer["compaction_policy"])
    _atomic_write_json(root/"CURRENT.json",new_pointer)
    return {"status":"SIDECAR_STORE_COMPACTED","compaction_performed":True,"decision":decision,"transition":trans,"pointer":new_pointer,"generation":g,"receipt_id_root":child["receipt_id_root"],"receipt_id_count":child["receipt_id_count"],"truth_credit":0}


def append_store(root: str | os.PathLike[str], receipt_id: Any, *, auto_compact: bool=True) -> Dict[str, Any]:
    root=Path(root); pointer=load_pointer(root); sp,jp=_paths(root,pointer)
    appended=s.append_file(sp,jp,receipt_id)
    out={"status":"SIDECAR_STORE_APPENDED","appended":True,"journal_entry":appended["journal_entry"],"receipt_id_root":appended["receipt_id_root"],"receipt_id_count":appended["receipt_id_count"],"auto_compaction_checked":bool(auto_compact),"truth_credit":0}
    if auto_compact:
        decision=compaction_decision(root); out["compaction_decision"]=decision
        if decision.get("compact_now",False):
            comp=compact_store(root,force=True); out["auto_compaction"]=comp; out["status"]="SIDECAR_STORE_APPENDED_AND_COMPACTED"; out["receipt_id_root"]=comp["receipt_id_root"]; out["receipt_id_count"]=comp["receipt_id_count"]
    return out


def proof_store(root: str | os.PathLike[str], receipt_id: Any) -> Dict[str, Any]:
    root=Path(root); pointer=load_pointer(root); sp,jp=_paths(root,pointer); return s.proof_files(sp,jp,receipt_id)


def status_store(root: str | os.PathLike[str]) -> Dict[str, Any]:
    root=Path(root); pointer=load_pointer(root); verified=verify_store(root); decision=compaction_decision(root)
    return {"status":"SIDECAR_STORE_STATUS","pointer":pointer,"verified":verified,"compaction_decision":decision,"truth_credit":0}
