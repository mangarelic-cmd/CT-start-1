#!/usr/bin/env python3
import copy, hashlib, random
import hypertriangle_solver_aux as h
checks=0
def ck(x,msg='independent'):
    global checks
    checks+=1
    if not x: raise AssertionError(msg)

KEYDOM=b'HYPERTRIANGLE_SOLVER_AUX_RECEIPT_ID_KEY_V1\n'
EMPTYDOM=b'HYPERTRIANGLE_SOLVER_AUX_RECEIPT_ID_EMPTY_LEAF_V1\n'
PRESENTDOM=b'HYPERTRIANGLE_SOLVER_AUX_RECEIPT_ID_PRESENT_LEAF_V1\n'
NODEDOM=b'HYPERTRIANGLE_SOLVER_AUX_RECEIPT_ID_NODE_V1\n'
def H(*parts):
    z=hashlib.sha256()
    for p in parts: z.update(p)
    return z.digest()
def key(rid): return H(KEYDOM,str(rid).encode())
def leaf_present(k): return H(PRESENTDOM,k)
def node(a,b): return H(NODEDOM,a,b)
empty=[b'']*257; empty[256]=H(EMPTYDOM)
for d in range(255,-1,-1): empty[d]=node(empty[d+1],empty[d+1])
def verify_ind(root,rid,proof,present):
    k=key(rid); cur=leaf_present(k) if present else empty[256]; ki=int.from_bytes(k,'big')
    sibs=proof['siblings']; ck(len(sibs)==256,'depth')
    for j,d in enumerate(range(256,0,-1)):
        sib=bytes.fromhex(sibs[j]); idx=ki>>(256-d); cur=node(sib,cur) if idx&1 else node(cur,sib)
    return cur.hex()==root

def independent_root(ids):
    nodes={int.from_bytes(key(r),'big'):leaf_present(key(r)) for r in ids}
    for d in range(255,-1,-1):
        parents={}
        for par in {i>>1 for i in nodes}:
            parents[par]=node(nodes.get(par<<1,empty[d+1]),nodes.get((par<<1)|1,empty[d+1]))
        nodes=parents
    return nodes.get(0,empty[0]).hex()

# Pigeonhole theorem instantiations.
for b in range(0,513,7):
    r=h.exact_membership_bounded_no_go({'checkpoint_bits':b,'universe_size':b+1})
    ck(r['pigeonhole_collision_for_distinct_seen_sets']); ck(r['status']=='EXACT_STANDALONE_BOUNDED_MEMBERSHIP_NO_GO')

rng=random.Random(7072026)
# Independently verify roots and proofs across randomized sets.
for case in range(10):
    n=rng.randint(0,40); ids=[f'c{case}-r{i}' for i in range(n)]
    root=h.sparse_receipt_id_root(ids); ck(root==independent_root(ids))
    for j in range(8):
        present=(n>0 and j%2==0); rid=rng.choice(ids) if present else f'c{case}-x{j}'
        p=h.sparse_receipt_id_proof(ids,rid)
        ck(bool(p['present'])==present); ck(verify_ind(root,rid,p,present)); ck(h.verify_sparse_receipt_id_proof(root,rid,p,expected_present=present)['proof_valid'])
        if not present:
            u=h.sparse_receipt_id_insert(root,rid,p); ck(u['updated']); ck(u['new_root']==independent_root(ids+[rid]))

# Incremental external index: each witness checked by independent verifier.
for case in range(10):
    idx=h.ExternalReceiptIdIndex([]); ids=[]
    for j in range(30):
        rid=f'i{case}-{j}'; p=idx.proof(rid)
        ck(not p['present']); ck(verify_ind(idx.root,rid,p,False)); before=idx.root
        upd=h.sparse_receipt_id_insert(before,rid,p); ck(upd['updated'])
        got=idx.insert(rid); ck(got['inserted']); ids.append(rid); ck(idx.root==upd['new_root']);
        if j%10==0 or j==29: ck(idx.root==independent_root(ids))

# Checkpoint migration + witnessed rotations against full replay and external index.
C={'common_scale_certified':True,'axis_independence_certified':True,'b4_comparable':True}
def st(vals): return {'values':vals,'component_errors':['1/100']*4,'contracts':C}
def base(sid):
    stream={'stream_id':sid,'requirements':{'required_state_slots':['S']},'receipts':[{'receipt_id':'r1','sequence':1,'slot':'S','kind':'state','payload':st([20,15,10,5])}]}
    cp0=h.create_stream_checkpoint({'stream':stream})['checkpoint']
    r2={'receipt_id':'r2','sequence':2,'slot':'S','kind':'state','payload':st([102,30,12,5])}
    cp6=h.rotate_bounded_checkpoint({'checkpoint':cp0,'receipts':[r2],'anchor_window_size':5})['checkpoint']
    stream['receipts'].append(copy.deepcopy(r2))
    return stream,cp6
def rec(seq): return {'receipt_id':f'r{seq}','sequence':seq,'slot':'S','kind':'state','payload':st([100+seq,30,12,5])}
for case in range(30):
    stream,cp=base(f'w{case}'); full=copy.deepcopy(stream)
    r=h.rotate_witnessed_checkpoint({'checkpoint':cp,'receipts':[rec(3)]}); ck(r['rotated']); ck(h.validate_witnessed_checkpoint_transition({'previous_checkpoint':cp,'current_checkpoint':r['checkpoint'],'proof_packet':r['proof_packet']})['transition_valid']); cp=r['checkpoint']; full['receipts'].append(rec(3))
    idx=h.ExternalReceiptIdIndex(['r1','r2','r3'])
    for seq in range(4,14):
        p=idx.proof(f'r{seq}'); ck(verify_ind(idx.root,f'r{seq}',p,False))
        r=h.rotate_witnessed_checkpoint({'checkpoint':cp,'receipts':[rec(seq)],'receipt_id_witnesses':[p]}); ck(r['rotated']); ck(h.validate_witnessed_checkpoint(r['checkpoint'])['checkpoint_valid']); ck(h.validate_witnessed_checkpoint_transition({'previous_checkpoint':cp,'current_checkpoint':r['checkpoint'],'proof_packet':r['proof_packet']})['transition_valid'])
        cp=r['checkpoint']; idx.insert(f'r{seq}'); full['receipts'].append(rec(seq)); ck(cp['receipt_id_root']==idx.root)
    replay=h.certify_receipt_stream(full); ck(cp['prefix_stream_hash']==replay['final_stream_hash']); ck(cp['first_terminal_prefix']==replay['first_terminal_prefix'])

print(f'PASS007 independent verifier: {checks}/{checks} PASS')
