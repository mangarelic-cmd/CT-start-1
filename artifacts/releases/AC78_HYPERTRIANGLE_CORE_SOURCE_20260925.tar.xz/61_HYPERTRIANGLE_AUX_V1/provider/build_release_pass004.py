#!/usr/bin/env python3
from __future__ import annotations
from pathlib import Path
import hashlib, json, os, shutil, stat, zipfile

ROOT=Path(__file__).resolve().parent
FIXED_DT=(2026,9,25,0,0,0)
EXCLUDE_ROOT={'MANIFEST.json','SHA256SUMS.txt'}

def sha256(p:Path)->str:
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()

def clean():
    for p in list(ROOT.rglob('__pycache__')):
        if p.is_dir(): shutil.rmtree(p)
    for p in list(ROOT.rglob('*.pyc')):
        p.unlink(missing_ok=True)

def payload_files():
    out=[]
    for p in ROOT.rglob('*'):
        if not p.is_file(): continue
        rel=p.relative_to(ROOT).as_posix()
        if '/' not in rel and rel in EXCLUDE_ROOT: continue
        out.append(p)
    return sorted(out,key=lambda p:p.relative_to(ROOT).as_posix())

def regenerate_metadata():
    clean()
    base=payload_files()
    lines=[]
    for p in base:
        rel=p.relative_to(ROOT).as_posix()
        lines.append(f"{sha256(p)}  {rel}")
    (ROOT/'SHA256SUMS.txt').write_text('\n'.join(lines)+'\n',encoding='utf-8')
    files=[]
    for p in sorted(base+[ROOT/'SHA256SUMS.txt'],key=lambda p:p.relative_to(ROOT).as_posix()):
        rel=p.relative_to(ROOT).as_posix()
        files.append({'path':rel,'sha256':sha256(p),'size':p.stat().st_size})
    manifest={
        'branch':'HYPERTRIANGLE_SOLVER_AUX','pass':'PASS004','version':'0.4.0','date':'2026-09-25',
        'external_solver_integration_performed':False,'file_count':len(files),'files':files,
        'manifest_note':'file_count excludes root MANIFEST.json itself; SHA256SUMS excludes root MANIFEST.json and root SHA256SUMS.txt'
    }
    (ROOT/'MANIFEST.json').write_text(json.dumps(manifest,indent=2,sort_keys=True)+'\n',encoding='utf-8')
    return manifest

def build(out:Path):
    regenerate_metadata(); clean()
    files=sorted([p for p in ROOT.rglob('*') if p.is_file()],key=lambda p:p.relative_to(ROOT).as_posix())
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for p in files:
            rel=p.relative_to(ROOT).as_posix()
            zi=zipfile.ZipInfo(rel,FIXED_DT)
            mode=0o755 if os.access(p,os.X_OK) else 0o644
            zi.external_attr=(mode & 0xFFFF)<<16
            zi.compress_type=zipfile.ZIP_DEFLATED
            z.writestr(zi,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    return out

if __name__=='__main__':
    import sys
    target=Path(sys.argv[1]) if len(sys.argv)>1 else ROOT.parent/'HYPERTRIANGLE_SOLVER_AUX_PASS004_20260925.zip'
    build(target)
    print(target)
