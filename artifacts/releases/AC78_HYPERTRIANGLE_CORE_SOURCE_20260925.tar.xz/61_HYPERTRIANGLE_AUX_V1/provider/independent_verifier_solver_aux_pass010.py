import json, random
import hypertriangle_solver_aux as h

def main():
    checks=0
    cat=h.memory_144_catalog({})['slots']
    assert len(cat)==144; checks+=1
    # Exhaust every canonical operator independently.
    for i,row in enumerate(cat):
        s=h.memory_144_init({})['state']
        r=h.memory_144_drop({'state':s,'datum_id':f'd{i+1}','signals':[{'operator':row['operator'],'certified':True}]})
        assert r['memory_valid']; assert r['flagged_slots']==(row['slot'],); assert r['state']['flags'][i]; assert sum(r['state']['flags'])==1
        assert r['state']['last_invariants_saved'][i]['operator']==row['operator']; checks+=8
    # All ordered distinct pairs: datum can fall on multiple slots without category pull.
    for i,a in enumerate(cat):
        for j,b in enumerate(cat):
            if i==j: continue
            s=h.memory_144_init({})['state']
            r=h.memory_144_drop({'state':s,'signals':[{'operator':a['operator'],'certified':True},{'operator':b['operator'],'certified':True}]})
            assert r['memory_valid']; assert r['state']['flags'][i] and r['state']['flags'][j]; assert sum(r['state']['flags'])==2; checks+=4
    # Streaming random direct lookup vs expected latest certified per slot.
    rng=random.Random(20260925); s=h.memory_144_init({})['state']; expected=[None]*144; hits=[0]*144
    for t in range(1,1001):
        i=rng.randrange(144); cert=(rng.randrange(4)!=0); row=cat[i]; proj=f'p{t}'
        r=h.memory_144_drop({'state':s,'signals':[{'operator':row['operator'],'certified':cert,'projection':proj}]})
        assert r['memory_valid'] and r['trace_index']==t; s=r['state']; hits[i]+=1
        if cert: expected[i]=proj
        assert s['hit_counts'][i]==hits[i]
        if expected[i] is None: assert s['last_invariants_saved'][i] is None
        else: assert s['last_invariants_saved'][i]['projection']==expected[i]
        checks+=4
    assert h.validate_memory_144_state(s)['memory_valid']; checks+=1
    print(json.dumps({'status':'PASS','checks':checks,'catalog_slots':144,'pair_cases':144*143,'stream_events':1000},sort_keys=True))
if __name__=='__main__': main()
