# HyperTriangle Solver AUX — PASS013 Research Note

Date: 2026-09-25  
Branch: `HYPERTRIANGLE_SOLVER_AUX`  
Parent: PASS012 standalone AUX.  
Scope: unify memory, activation, local execution provenance and existing exact persistence. **No AC77/DD094 integration, ROOT/RETURN write, or external solver mutation.**

## 1. Frontier closed

PASS012 closed:

`memory -> activation -> typed request -> local capability receipt`.

It did not yet prove that a crash/restart at an arbitrary prefix resumes to the same combined state as replaying the complete event history.

PASS013 closes that gap with a single event pipeline and a unified checkpoint.

## 2. Unified event pipeline

The only pipeline event classes are:

- `MEMORY_DROP`;
- `ACTIVATE`;
- `CAPABILITY`.

Events have exact IDs and contiguous one-based pipeline sequence numbers. A canonical event hash is committed into one pipeline-history accumulator.

`MEMORY_DROP` uses the PASS010 memory rule. It also invalidates the current activation receipt because that receipt is bound to the previous memory-state hash.

`ACTIVATE` reruns PASS011 against the current memory state.

`CAPABILITY` requires a fresh valid activation for the current memory state and then uses the PASS012 typed-request/execution bridge.

## 3. Unified checkpoint state

A checkpoint commits the current:

- full fixed-grid memory state and memory-state hash;
- activation receipt/hash, or explicit absence of one;
- pipeline event count and next sequence;
- pipeline-history accumulator;
- memory-drop, activation, typed-request and execution counts;
- latest typed-request provenance summary;
- latest capability-execution provenance summary;
- exact event-ID root/count;
- exact sidecar snapshot hash/generation;
- bounded sidecar snapshot-chain state;
- checkpoint rotation provenance.

The exact historic event-ID set is not stored in the checkpoint.

## 4. Exact ID persistence reused, not duplicated

PASS013 reuses the earlier result directly:

`bounded checkpoint + exact membership` requires external exact storage.

Accordingly:

- PASS007 supplies the Sparse-Merkle authenticated event-ID root/proof semantics;
- PASS008 supplies the exact sidecar snapshot and append-only journal;
- PASS009 supplies compaction and the bounded snapshot-chain state.

A resume is blocked unless the supplied sidecar snapshot matches the checkpoint's exact snapshot hash, root, count, and generation.

## 5. Resume and rotation

`memory_144_resume_unified_checkpoint`:

1. validates the unified checkpoint;
2. validates and binds its exact sidecar snapshot;
3. checks each suffix event ID for exact non-membership;
4. appends the ID to the sidecar journal;
5. executes the event against the current combined state;
6. returns the continued state and exact recovered sidecar root.

`memory_144_rotate_unified_checkpoint` additionally compacts the suffix journal into the next exact sidecar snapshot, appends that snapshot to the bounded PASS009 chain state, and emits a child unified checkpoint.

## 6. Equivalence invariant

For the declared combined projection:

`checkpoint(prefix) + sidecar(prefix) + suffix == full replay(prefix + suffix)`.

The compared projection includes:

- memory-state hash and trace accumulator;
- current activation-state hash;
- pipeline-history accumulator;
- event/type/request/execution counts;
- latest typed-request and execution hashes;
- exact event-ID root/count.

The package includes a deterministic witness receipt where full replay, resumed replay, and rotated checkpoint projections are identical.

## 7. Archival boundary

PASS013 does not claim that a compact checkpoint can regenerate discarded event payloads. Historical payload replay requires the archived prefix. The history accumulator and checkpoint hash are tamper-evident commitments when their prior trusted values or archived transition evidence are available; they are not an information-theoretic substitute for discarded history.

## 8. Validation

- cumulative unit/regression tests: **196/196 PASS**;
- qualification: **917/917 PASS**;
- randomized qualification checkpoint/suffix cases: **72**;
- independent verifier: **495/495 PASS**;
- independent random equivalence cases: **60**;
- checkpoint semantic tamper cases: **11/11 rejected under their declared audit conditions**;
- sidecar snapshot substitution: rejected;
- duplicate suffix ID: rejected by exact sidecar;
- stale activation after memory mutation: rejected;
- long witness: **12 rotations**, sidecar anchor window 8, **5 compacted snapshot entries**;
- parent integrity: **239/239** nonmutable PASS012 files byte-identical;
- cold extraction replay: PASS;
- memory feedback events: **0**.

## 9. Authority firewall

Unchanged:

- `truth_credit = 0`;
- ROOT write = `NONE`;
- RETURN write = `NONE`;
- solver mutation = `NONE`;
- AC77 integration = `NOT_PERFORMED`;
- DD094 integration = `NOT_PERFORMED`.

## 10. Next front

PASS014 should define terminality for the complete standalone AUX state rather than for an isolated receipt stream: declared obligations, current memory/activation consistency, local capability receipts, provenance and blocking conflicts must converge to one frozen first-terminal prefix without turning terminality into a scientific truth claim.
