# HyperTriangle Solver AUX — PASS009 Research Note

Date: 2026-09-25  
Branch: `HYPERTRIANGLE_SOLVER_AUX`  
Parent: PASS008 standalone AUX.  
Scope: bounded sidecar snapshot-chain metadata, exact compaction-transition audit, deterministic automatic compaction policy, and a crash-safe generational sidecar store. **No AC77/DD094 integration or mutation.**

## 1. Objective
PASS008 materialized the exact external receipt-ID index as a persistent snapshot + append-only journal sidecar. Two operational debts remained:

1. repeated compaction creates a growing sequence of exact snapshots whose active provenance metadata should not itself grow without bound;
2. compaction should be triggered by a deterministic policy rather than ad hoc operator choice.

PASS009 closes those two debts without changing the PASS007 no-go: the exact receipt-ID set remains externally stored and grows with receipt count.

## 2. Bounded snapshot-chain state
Each validated exact snapshot is represented in the chain by a compact entry containing:

- generation;
- snapshot hash;
- parent snapshot hash;
- compacted-journal tail hash;
- exact receipt-ID count;
- exact sparse-Merkle root;
- a domain-separated entry hash.

For a snapshot sequence `S_0,...,S_n`, PASS009 keeps a rolling SHA-256 accumulator over old entries and a fixed recent-anchor window. With anchor window `w`, the active chain metadata stores at most `w` explicit snapshot entries regardless of the number of prior snapshot generations.

This is the same design discipline already proven for solver-checkpoint lineage in PASS006, now applied to the external exact sidecar generations.

The active chain state does **not** replace archived exact snapshots. Reconstructing compacted ancestor metadata or replaying exact snapshot-to-snapshot semantics still requires archived sidecar artifacts.

## 3. Exact compaction-transition audit
Snapshot-level parent hashes alone prove lineage declarations, not the semantic correctness of the compacted additions.

PASS009 therefore adds an exact transition verifier:

`parent snapshot + committed journal + child snapshot -> transition verdict`.

A transition is valid only when replaying the parent journal yields exactly the child's:

- generation `g+1`;
- `parent_snapshot_hash`;
- `compacted_journal_tail_hash`;
- exact receipt-ID set;
- receipt-ID count;
- sparse-Merkle root.

Thus bounded active chain metadata and full archived transition replay are deliberately separate levels of audit.

## 4. Deterministic automatic compaction policy
PASS009 defines two policy thresholds:

- `max_journal_records`;
- `max_journal_bytes` using canonical newline-delimited JSON byte count.

For a valid sidecar state, compaction is triggered iff the journal is nonempty and at least one threshold is met:

`record_count >= max_journal_records`

or

`canonical_journal_bytes >= max_journal_bytes`.

The default AUX policy is:

- 256 records;
- 1 MiB canonical journal bytes.

The policy returns either `KEEP_APPEND` or `COMPACT_NOW` and identifies the exact trigger(s). It adds no scientific truth credit and has no solver authority.

## 5. Generational filesystem store
PASS009 adds `receipt_id_sidecar_store.py` and `receipt_id_sidecar_store_cli.py`.

The store uses:

- `snapshots/gNNNNNNNNN.json`;
- `journals/gNNNNNNNNN.ndjson`;
- one atomically replaced `CURRENT.json` pointer;
- a bounded snapshot-chain state embedded in the pointer;
- a fixed compaction policy embedded in the pointer.

### Atomic generation switch
Compaction follows this order:

1. recover and verify the current generation;
2. build and validate the next exact snapshot;
3. write/fsync the next snapshot;
4. create/fsync its empty journal;
5. advance and validate the bounded snapshot-chain state;
6. atomically replace `CURRENT.json`.

Therefore a crash before step 6 leaves the old generation active. A fully written but orphaned future generation is ignored until the active pointer changes. A crash after step 6 sees already-durable next-generation files.

PASS009 does not claim an atomic transaction across arbitrary filesystems beyond this pointer-swap contract.

## 6. Store interface
Standalone CLI commands:

```text
python receipt_id_sidecar_store_cli.py init STORE [receipt_id ...] [--max-journal-records N] [--max-journal-bytes N] [--anchor-window N]
python receipt_id_sidecar_store_cli.py append STORE RECEIPT_ID [--no-auto-compact]
python receipt_id_sidecar_store_cli.py verify STORE [--strict-tail] [--audit-archives]
python receipt_id_sidecar_store_cli.py proof STORE RECEIPT_ID
python receipt_id_sidecar_store_cli.py compact STORE [--force]
python receipt_id_sidecar_store_cli.py status STORE
```

`append` evaluates the active policy after a committed append and rotates automatically if required.

## 7. New provider modes
PASS009 adds pure/stateless provider modes:

- `receipt_id_sidecar_snapshot_chain`;
- `receipt_id_sidecar_snapshot_chain_append`;
- `validate_receipt_id_sidecar_snapshot_chain`;
- `validate_receipt_id_sidecar_compaction_transition`;
- `receipt_id_sidecar_compaction_decision`;
- `receipt_id_sidecar_auto_compact`.

The filesystem store is a separate AUX helper and is not a solver daemon or solver registry entry.

## 8. Qualification witness
The PASS009 deterministic qualification witness uses:

- 61 exact receipt IDs;
- automatic compaction every 10 journal records;
- 6 completed snapshot rotations;
- snapshot-chain anchor window = 4;
- 3 snapshot-chain entries compacted into the rolling accumulator;
- 4 recent explicit anchors;
- canonical active `CURRENT.json` size ≈ 3,628 bytes.

This bounded size applies to active **snapshot-chain metadata**, not to the archived exact snapshots or the exact receipt-ID sidecar storage.

## 9. Authority firewall
Unchanged:

- `truth_credit = 0`;
- ROOT write = `NONE`;
- RETURN write = `NONE`;
- solver mutation = `NONE`;
- AC77 integration = `NOT_PERFORMED`;
- DD094 integration = `NOT_PERFORMED`.

## 10. Validation
- cumulative regression + unit tests: **123/123 PASS**;
- independent verifier: **1,584/1,584 PASS**;
- qualification: **293/293 PASS**;
- parent PASS008 nonmutable integrity: **158/158 byte-identical**;
- cold replay: **PASS**;

## 11. Remaining front
PASS009 closes snapshot-generation scheduling and bounded active provenance metadata. The next useful front is not AC integration.

A natural PASS010 is **archive retention / garbage-collection certification**: determine which old sidecar journals/snapshots can be pruned, when they must remain available for exact historical transition replay, and how a retained archive subset can be certified without silently weakening the audit contract.
