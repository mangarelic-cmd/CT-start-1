#!/usr/bin/env python3
from __future__ import annotations
import copy, hashlib, json, random, tempfile
from pathlib import Path
import hypertriangle_solver_aux as h
import receipt_id_sidecar as s

checks=0
def ck(x,msg='independent check'):
    global checks
    checks+=1
    if not x: raise AssertionError(msg)

KEY=b'HYPERTRIANGLE_SOLVER_AUX_RECEIPT_ID_KEY_V1\n'
EMPTY=b'HYPERTRIANGLE_SOLVER_AUX_RECEIPT_ID_EMPTY_LEAF_V1\n'
PRESENT=b'HYPERTRIANGLE_SOLVER_AUX_RECEIPT_ID_PRESENT_LEAF_V1\n'
NODE=b'HYPERTRIANGLE_SOLVER_AUX_RECEIPT_ID_NODE_V1\n'
SNAP=b'HYPERTRIANGLE_RECEIPT_ID_SIDECAR_SNAPSHOT_V1\n'
JSEED=b'HYPERTRIANGLE_RECEIPT_ID_SIDECAR_JOURNAL_SEED_V1\n'
JENTRY=b'HYPERTRIANGLE_RECEIPT_ID_SIDECAR_JOURNAL_ENTRY_V1\n'
def canon(x): return json.dumps(h.encode(x),sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()
def hh(*parts):
    q=hashlib.sha256()
    for p in parts: q.update(p)
    return q.digest()
def key(r): return hh(KEY,str(r).encode())
def node(a,b): return hh(NODE,a,b)
def pleaf(k): return hh(PRESENT,k)
def empty(): return hh(EMPTY)
EMPTY_HASH=[b'']*257; EMPTY_HASH[256]=empty()
for d in range(255,-1,-1): EMPTY_HASH[d]=node(EMPTY_HASH[d+1],EMPTY_HASH[d+1])
def iroot(ids):
    cur={int.from_bytes(key(r),'big'):pleaf(key(r)) for r in ids}
    for depth in range(255,-1,-1):
        nxt={}
        for parent in {x>>1 for x in cur}:
            nxt[parent]=node(cur.get(parent<<1,EMPTY_HASH[depth+1]),cur.get((parent<<1)|1,EMPTY_HASH[depth+1]))
        cur=nxt
    return cur.get(0,EMPTY_HASH[0]).hex()
def snap_hash(snapshot):
    body={k:copy.deepcopy(v) for k,v in snapshot.items() if k not in {'snapshot_hash','journal_seed_hash'}}
    return hh(SNAP,canon(body)).hex()
def jseed(sh): return hh(JSEED,bytes.fromhex(sh)).hex()
def jhash(rec):
    body={k:copy.deepcopy(v) for k,v in rec.items() if k!='journal_hash'}
    return hh(JENTRY,canon(body)).hex()

rng=random.Random(808808)
# Deterministic snapshot/root/hash verification against an independent implementation.
for case in range(30):
    ids=[f's{case}-{i}' for i in range(rng.randint(0,60))]
    out=h.receipt_id_sidecar_snapshot({'receipt_ids':ids,'generation':case%4}); ck(out['snapshot_valid'])
    sp=out['snapshot']; ck(sp['receipt_id_root']==iroot(ids)); ck(sp['snapshot_hash']==snap_hash(sp)); ck(sp['journal_seed_hash']==jseed(sp['snapshot_hash']))
    ck(h.validate_receipt_id_sidecar_snapshot(sp)['snapshot_valid'])
# Journal records: independent hash chain + root checks.
for case in range(20):
    base=[f'b{case}-{i}' for i in range(5)]
    sp=h.receipt_id_sidecar_snapshot({'receipt_ids':base,'generation':2})['snapshot']; records=[]; ids=list(base); prev=sp['journal_seed_hash']
    for j in range(20):
        rid=f'n{case}-{j}'; out=h.append_receipt_id_sidecar({'snapshot':sp,'journal_records':records,'receipt_id':rid}); ck(out['appended'])
        rec=out['journal_entry']; ck(rec['journal_hash']==jhash(rec)); ck(rec['previous_journal_hash']==prev); ids.append(rid); ck(rec['root_after']==iroot(ids)); prev=rec['journal_hash']; records.append(rec)
    r=h.recover_receipt_id_sidecar({'snapshot':sp,'journal_records':records}); ck(r['recovered']); ck(r['receipt_id_root']==iroot(ids)); ck(r['journal_tail_hash']==prev)
    c=h.compact_receipt_id_sidecar({'snapshot':sp,'journal_records':records}); ck(c['compacted']); ck(c['snapshot']['receipt_id_root']==iroot(ids)); ck(c['snapshot']['generation']==3)
# Tamper and stale-root campaigns.
for case in range(40):
    sp=h.receipt_id_sidecar_snapshot({'receipt_ids':[f'a{case}']})['snapshot']
    r1=h.append_receipt_id_sidecar({'snapshot':sp,'journal_records':[],'receipt_id':f'b{case}'})['journal_entry']
    bad=copy.deepcopy(r1)
    if case%2: bad['journal_hash']='0'*64
    else: bad['root_after']='f'*64
    rr=h.recover_receipt_id_sidecar({'snapshot':sp,'journal_records':[bad]}); ck(not rr['recovered'])
# File crash semantics: only non-newline final tail is ignorable.
for case in range(30):
    with tempfile.TemporaryDirectory() as td:
        spath=Path(td)/'s.json'; jpath=Path(td)/'j.ndjson'
        s.init_snapshot(spath,[f'a{case}']); s.ensure_journal(jpath); s.append_file(spath,jpath,f'b{case}')
        with open(jpath,'ab') as f: f.write(b'{"partial":')
        r=s.recover_files(spath,jpath,allow_uncommitted_tail=True); ck(r['recovered']); ck(r['truncated_tail_ignored']); ck(r['receipt_id_count']==2)
        try: s.recover_files(spath,jpath,allow_uncommitted_tail=False); ck(False)
        except ValueError: ck(True)
print(f'PASS008 independent verifier: {checks}/{checks} PASS')
