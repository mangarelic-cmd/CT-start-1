#!/usr/bin/env python3
from itertools import permutations, product
from fractions import Fraction
import hashlib, json, random
from hypertriangle_solver_aux import certify_receipt_stream, encode

C={"common_scale_certified":True,"axis_independence_certified":True,"b4_comparable":True}
DOMAIN=b"HYPERTRIANGLE_SOLVER_AUX_STREAM_V1\n"

def state(vals,err="1/100"):
    return {"values":vals,"component_errors":[err]*4,"contracts":C}

def event(w,t,axis,err="1/100"):
    base=[8,6,4,2]; left=base[:]; right=base[:]
    left[axis]=-2; right[axis]=2
    a=[0,0,0,0]; a[axis]=1
    return {"wall_id":w,"alpha":a,"left":{"time":t-1,"values":left},"right":{"time":t+1,"values":right},
            "uniform_component_errors":[err]*4,"derivative_direction":1,"derivative_magnitude_lower":1,
            "derivative_error":err,"nominal_time":t,"contracts":{"uniform_error_over_bracket_certified":True}}

def canonical(x):
    return json.dumps(encode(x),sort_keys=True,separators=(",",":"),ensure_ascii=False).encode()

def chain_hash(stream_id,receipts):
    h=hashlib.sha256(); h.update(DOMAIN); h.update(str(stream_id or "").encode()); cur=h.hexdigest()
    for e in receipts:
        z=hashlib.sha256(); z.update(bytes.fromhex(cur)); z.update(b"\n"); z.update(canonical(e)); cur=z.hexdigest()
    return cur

def good_entries():
    return {
      "S0":{"receipt_id":"S0","slot":"S0","kind":"state","payload":state([8,6,4,2])},
      "S1":{"receipt_id":"S1","slot":"S1","kind":"state","payload":state([7,-5,3,1])},
      "E0":{"receipt_id":"E0","slot":"E0","kind":"event","payload":event("w0",2,0)},
      "E1":{"receipt_id":"E1","slot":"E1","kind":"event","payload":event("w1",5,1)},
    }

def payload_from_order(order,stream_id="ind"):
    g=good_entries(); receipts=[]
    for i,k in enumerate(order,1):
        e=dict(g[k]); e["receipt_id"]=f"{e['receipt_id']}_{i}"; e["sequence"]=i; receipts.append(e)
    return {"stream_id":stream_id,"requirements":{"required_state_slots":["S0","S1"],"required_event_slots":["E0","E1"],"required_wall_sequence":["w0","w1"]},"receipts":receipts}

def main():
    checks=0
    # Every arrival order of the four required good receipts closes at prefix 4.
    for order in permutations(("S0","S1","E0","E1")):
        p=payload_from_order(order,stream_id="perm-"+"".join(order))
        r=certify_receipt_stream(p)
        assert r["historical_terminal"] and r["current_terminal"] and r["first_terminal_prefix"]==4
        assert r["final_stream_hash"]==chain_hash(p["stream_id"],p["receipts"])
        checks+=2

    # Exhaustive 384 one-state terminal streams; independent chamber label expectation.
    axes=("h1","h2","h3","h4")
    for signs in product((-1,1),repeat=4):
        for perm in permutations(range(4)):
            vals=[0]*4
            for rank,i in enumerate(perm): vals[i]=signs[i]*(8-2*rank)
            signcode="".join("+" if signs[i]>0 else "-" for i in range(4))
            expected="B4:"+signcode+":"+">".join(axes[i] for i in perm)
            e={"receipt_id":"r1","sequence":1,"slot":"S","kind":"state","payload":{"axis_ids":list(axes),**state(vals)}}
            p={"stream_id":expected,"requirements":{"required_state_slots":["S"]},"receipts":[e]}
            r=certify_receipt_stream(p)
            assert r["first_terminal_prefix"]==1 and r["first_terminal_snapshot"]["S"]["certificate"]["chamber_id"]==expected
            assert r["first_terminal_stream_hash"]==chain_hash(expected,[e])
            checks+=2

    # Deterministic randomized insertion of non-required receipts before closure.
    rng=random.Random(20260925)
    keys=("S0","S1","E0","E1")
    for trial in range(5000):
        g=good_entries(); order=list(keys); rng.shuffle(order)
        junk=rng.randrange(0,5)
        receipts=[]; positions={}; seq=0
        for j in range(junk):
            seq+=1
            receipts.append({"receipt_id":f"j{trial}_{j}","sequence":seq,"slot":f"J{j}","kind":"state","payload":state([8+j+1,6,4,2])})
        for k in order:
            seq+=1; e=dict(g[k]); e["receipt_id"]=f"{k}_{trial}"; e["sequence"]=seq; receipts.append(e); positions[k]=seq
        p={"stream_id":f"trial-{trial}","requirements":{"required_state_slots":["S0","S1"],"required_event_slots":["E0","E1"],"required_wall_sequence":["w0","w1"]},"receipts":receipts}
        r=certify_receipt_stream(p)
        expected=max(positions.values())
        assert r["first_terminal_prefix"]==expected and r["current_terminal"]
        assert r["final_stream_hash"]==chain_hash(p["stream_id"],receipts)
        checks+=2

    # Late degradation cannot erase historical terminality.
    for trial in range(2500):
        p=payload_from_order(("S0","E0","S1","E1"),stream_id=f"late-{trial}")
        p["receipts"].append({"receipt_id":f"bad-{trial}","sequence":5,"slot":"S1","kind":"state","payload":{"values":[1,2,3,4],"component_errors":[2,0,0,0],"contracts":C}})
        r=certify_receipt_stream(p)
        assert r["historical_terminal"] and r["first_terminal_prefix"]==4
        assert not r["current_terminal"] and r["post_terminal_semantic_conflict"]
        assert r["first_terminal_stream_hash"]==chain_hash(p["stream_id"],p["receipts"][:4])
        checks+=3

    print(f"INDEPENDENT PASS003: {checks}/{checks} PASS")

if __name__=='__main__': main()
