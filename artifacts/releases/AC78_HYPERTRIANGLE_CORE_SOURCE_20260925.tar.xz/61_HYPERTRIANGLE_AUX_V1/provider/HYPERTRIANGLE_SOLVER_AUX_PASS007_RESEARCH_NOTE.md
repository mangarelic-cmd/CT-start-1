# HyperTriangle Solver AUX — PASS007 Research Note

Date: 2026-09-25  
Branch: `HYPERTRIANGLE_SOLVER_AUX`  
Parent: PASS006 standalone AUX.  
Scope: exact duplicate-membership no-go plus authenticated external-witness replacement. **No AC77/DD094 integration or mutation.**

## 1. Objective
PASS006 bounded the checkpoint-lineage representation but retained the exact historical `seen_receipt_ids` list. PASS007 asks whether that last growing identity set can be replaced by a fixed-size standalone state without losing perfect duplicate detection.

## 2. Exact standalone no-go
Let a standalone checkpoint have `b` bits of state. It has at most `2^b` possible internal states. On any universe of `N>b` distinguishable receipt IDs there are `2^N` possible seen-ID subsets. By pigeonhole, two different seen sets must map to the same checkpoint state. An ID in their symmetric difference has different exact membership truth values for the same checkpoint state.

Therefore:

`fixed-size standalone exact duplicate membership for arbitrarily large receipt-ID sets = IMPOSSIBLE`.

PASS007 does not replace this with a Bloom filter or any other probabilistic false-positive structure.

## 3. Practical authenticated mode
The workable bounded interface is instead:

`bounded checkpoint root + external exact index + membership/non-membership witness`.

PASS007 implements a 256-level sparse Merkle tree. Receipt IDs are mapped to paths by domain-separated SHA-256. The active checkpoint stores only:

- `receipt_id_root`;
- `receipt_id_count`;
- the fixed declaration `SPARSE_MERKLE_256_SHA256_EXTERNAL_WITNESS_V1`.

The exact external index remains growing and produces witnesses. This growth is not hidden inside the checkpoint.

## 4. Witnessed rotation
The first `rotate_witnessed_checkpoint` may migrate from PASS006, where the exact historical ID set is still present. The new PASS007 checkpoint drops `seen_receipt_ids`.

Every later rotation requires, for each new receipt ID, a non-membership proof against the **current** root. The AUX verifies the proof and computes the next root before processing the next ID. Thus:

- a historical duplicate yields a membership proof, not a valid non-membership proof;
- a stale proof bound to an older root is rejected;
- multi-ID suffixes require sequential proofs against sequentially updated roots.

## 5. Cryptographic scope
The sparse-Merkle construction is computationally authenticated under SHA-256 collision/preimage resistance. It is not an information-theoretic counterexample to the no-go theorem. The exact set lives in the external index; the bounded checkpoint only authenticates it.

## 6. Other history components
PASS007 also replaces explicit post-terminal regression/conflict lists in the new witnessed checkpoint by counts plus rolling SHA-256 accumulators. The bounded lineage window from PASS006 is retained.

For fixed solver requirements and fixed lineage-anchor window, the historical receipt-ID and event-history representation in the active PASS007 checkpoint is therefore bounded with respect to receipt count. Dynamic growth of the solver contract itself is outside this statement.

## 7. Archived audit boundary
A witnessed checkpoint validates its own hash, authenticated ID root, bounded-lineage fields and certification semantics. A rehashed substitution of already compacted ancestor metadata still requires the archived parent/chain to detect, exactly as in PASS006.

`validate_witnessed_checkpoint_transition` uses the archived parent plus the archived witness packet to reconstruct the receipt-ID root transition and the bounded-lineage transition.

## 8. Long-run witness
Qualification executes 500 witnessed rotations after migration.

Final witness:

- authenticated receipt IDs: `503`;
- exact IDs retained in active checkpoint: `0`;
- external exact index IDs: `503`;
- active checkpoint canonical size: approximately `9.8 kB`;
- size range over the last 500 witnessed states: approximately `2.1 kB` (integer/count/anchor-content variation, not linear ID-history growth).

## 9. Authority firewall
Unchanged:

- `truth_credit = 0`;
- ROOT write capability = `NONE`;
- RETURN write capability = `NONE`;
- solver mutation capability = `NONE`;
- AC77 integration = `NOT_PERFORMED`;
- DD094 integration = `NOT_PERFORMED`.

## 10. Validation
- cumulative regression + unit tests: **89/89 PASS**;
- independent verifier: **4,318/4,318 PASS**;
- qualification: **7,084/7,084 PASS**;
- long witnessed rotation: **500 rotations / 503 authenticated IDs**;
- parent PASS006 nonmutable integrity: checked in release receipt;
- cold replay: **PASS**.

## 11. Next front
PASS008 should package the external exact index as a separately auditable sidecar with snapshot/export/import and crash-recovery semantics, while preserving the strict rule that the sidecar is not part of the bounded checkpoint and does not gain ROOT/RETURN authority.
