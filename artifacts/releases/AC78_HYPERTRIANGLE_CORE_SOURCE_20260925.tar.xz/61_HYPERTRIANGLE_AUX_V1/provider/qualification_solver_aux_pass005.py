#!/usr/bin/env python3
import copy, random
import hypertriangle_solver_aux as h

checks=0
def ck(x,msg='q'):
    global checks
    checks+=1
    if not x: raise AssertionError(msg)
C={'common_scale_certified':True,'axis_independence_certified':True,'b4_comparable':True}
def st(vals,err='1/100'): return {'values':vals,'component_errors':[err]*4,'contracts':C}
def root(stream_id='q'):
    stream={'stream_id':stream_id,'requirements':{'required_state_slots':['S']},'receipts':[{'receipt_id':'r1','sequence':1,'slot':'S','kind':'state','payload':st([20,15,10,5])}]}
    return stream,h.create_stream_checkpoint({'stream':stream})['checkpoint']

rng=random.Random(5052026)
# 150 chains, 12 rotations each, variable batches.
for case in range(150):
    stream,cp=root(f'q{case}'); chain=[cp]; full=list(stream['receipts']); seq=1
    for rot in range(12):
        batch=[]
        for _ in range(rng.randint(1,5)):
            seq+=1
            # mostly same chamber; periodically force a robust conflict then repair later.
            if (case+rot+seq)%37==0:
                payload={'values':[1,2,3,4],'component_errors':[2,0,0,0],'contracts':C}
            else:
                payload=st([30+seq,18,11,5])
            e={'receipt_id':f'r{seq}','sequence':seq,'slot':'S','kind':'state','payload':payload}
            batch.append(e); full.append(copy.deepcopy(e))
        rr=h.rotate_stream_checkpoint({'checkpoint':cp,'receipts':batch}); ck(rr['rotated']); cp=rr['checkpoint']; chain.append(cp)
        ck(h.validate_stream_checkpoint(cp)['checkpoint_valid']); ck(cp['rotation_index']==rot+1); ck(cp['prefix_length']==seq)
        ck(cp['first_terminal_prefix']==1); ck(cp['first_terminal_stream_hash']==chain[0]['first_terminal_stream_hash'])
    aud=h.validate_checkpoint_chain({'checkpoints':chain}); ck(aud['chain_valid']); ck(aud['chain_tip_prefix_length']==seq)
    replay=h.certify_receipt_stream({'stream_id':stream['stream_id'],'requirements':stream['requirements'],'receipts':full})
    ck(cp['prefix_stream_hash']==replay['final_stream_hash']); ck(cp['current_terminal_at_checkpoint']==replay['current_terminal'])
    ever_reg=any((x['prefix_length']>replay['first_terminal_prefix'] and not x['terminal_now']) for x in replay['prefix_history']) if replay['first_terminal_prefix'] is not None else False
    ck(cp['post_terminal_regression_seen']==ever_reg)

# Long-run rotation witness: >1000 receipts, 50 rotations.
stream,cp=root('long'); chain=[cp]; full=list(stream['receipts']); seq=1
for rot in range(50):
    batch=[]
    for _ in range(20):
        seq+=1; e={'receipt_id':f'r{seq}','sequence':seq,'slot':'S','kind':'state','payload':st([1000+seq,50,20,5])}; batch.append(e); full.append(copy.deepcopy(e))
    cp=h.rotate_stream_checkpoint({'checkpoint':cp,'receipts':batch})['checkpoint']; chain.append(cp)
    ck(cp['rotation_index']==rot+1); ck(cp['prefix_length']==seq); ck(len(cp['checkpoint_lineage'])==rot+1)
aud=h.validate_checkpoint_chain({'checkpoints':chain}); ck(aud['chain_valid']); ck(aud['rotation_count']==50)
replay=h.certify_receipt_stream({'stream_id':'long','requirements':stream['requirements'],'receipts':full})
ck(cp['prefix_stream_hash']==replay['final_stream_hash']); ck(cp['first_terminal_prefix']==1); ck(len(cp['seen_receipt_ids'])==1001)
print(f'PASS005 qualification: {checks}/{checks} PASS')
print(f'long_run_receipts={seq} rotations=50 tip_checkpoint_bytes={len(h._canonical_for_hash(cp))}')
