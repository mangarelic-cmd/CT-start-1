# HyperTriangle Solver AUX — PASS004 Research Note

Date: 2026-09-25  
Branch: `HYPERTRIANGLE_SOLVER_AUX`  
Parent: PASS003 standalone AUX.  
Scope: resumable stream checkpoint/compaction. **No AC77/DD094 integration or mutation.**

## 1. Objective
PASS003 established an append-only hash-chained receipt stream and a frozen first-terminal-prefix certificate. PASS004 asks whether long streams can be compacted without losing:

- the prefix provenance commitment;
- the frozen first-terminal prefix and hash;
- the latest certified state per semantic slot;
- exact duplicate receipt-ID protection across the compacted prefix;
- post-terminal regression/conflict history needed by the solver-side audit;
- exact continuation semantics for later receipts.

## 2. Checkpoint contract
For a verified prefix `r_1,...,r_k`, PASS004 creates a checkpoint containing:

- `prefix_length=k` and `next_sequence=k+1`;
- `prefix_stream_hash`, the PASS003 SHA-256 chain commitment to the entire compacted prefix;
- exact `seen_receipt_ids` for duplicate-ID rejection after compaction;
- the latest certificate for each active slot;
- the frozen `first_terminal_prefix`, `first_terminal_stream_hash`, and first-terminal slot snapshot when terminality has occurred;
- summarized post-terminal regression prefixes and semantic conflicts;
- a SHA-256 `prefix_history_commitment`;
- its own domain-separated `checkpoint_hash`.

The old payloads may then leave the active stream. They remain archival evidence if full historical replay is required.

## 3. Continuation theorem
Let `C_k` be a valid checkpoint of prefix `r_1,...,r_k`, and let `s=(r_{k+1},...,r_n)` be a valid suffix with exact continuation sequence numbers and no reused receipt IDs. PASS004 resumes the PASS003 hash chain from `prefix_stream_hash` and re-evaluates the slot semantics after each suffix receipt.

For the fields relevant to solver continuation, replay from `C_k+s` agrees with full replay from `r_1,...,r_n`:

- final stream hash;
- historical terminality;
- first terminal prefix;
- first-terminal stream hash;
- current terminality;
- stop policy.

This is tested over all 24 arrival orders of the four required canonical receipts, all 384 B4 chambers, randomized long streams, terminal regressions/repairs, and tamper controls.

## 4. Historical regression preservation
A checkpoint created after a post-terminal regression retains a permanent summary of that regression and any semantic conflicts. If later receipts repair the current state, the current prefix may become terminal again, but the checkpoint lineage still records that a post-terminal regression/conflict occurred.

This is stricter than merely storing the latest state.

## 5. Compaction boundary
The checkpoint is a continuation certificate, not a cryptographic proof of an unseen archive by itself. Its `prefix_stream_hash` commits to the archived compacted prefix; independently replaying that historical prefix still requires the original archived receipts (or another proof system not introduced here).

PASS004 deliberately retains exact historical receipt IDs, so compaction is semantic/payload compaction rather than asymptotically constant-size identity compaction. This preserves exact duplicate-ID detection.

## 6. Measured compaction
In the qualification witness with 1000 receipts, the checkpoint occupies approximately 9.9142% of the canonical JSON size of the active raw stream. The ratio improves as redundant payload history grows because only slot state, terminal evidence, identifiers and commitments are retained.

## 7. Authority firewall
Unchanged:

- `truth_credit = 0`;
- ROOT write capability = `NONE`;
- RETURN write capability = `NONE`;
- solver mutation capability = `NONE`;
- AC77 integration = `NOT_PERFORMED`;
- DD094 integration = `NOT_PERFORMED`.

## 8. Validation
- regression + unit tests: **42/42 PASS**;
- independent verifier: **5,236/5,236 PASS**;
- qualification: **7,524/7,524 PASS**;
- 1000-receipt compaction witness: checkpoint/raw canonical ratio about **0.099142**;
- cold replay: required before final sealing.

## 9. Next front
PASS005 should add **checkpoint rotation / multi-checkpoint chaining**: allow a stream to be repeatedly compacted over long solver runs while preserving a chain of checkpoint commitments and the original first-terminal certificate.
