import copy, hashlib, unittest
import hypertriangle_solver_aux as h

C={'common_scale_certified':True,'axis_independence_certified':True,'b4_comparable':True}
def state(vals, err='1/100'): return {'values':vals,'component_errors':[err]*4,'contracts':C}
def event(w,t,axis,err="1/100"):
    base=[8,6,4,2]; left=base[:]; right=base[:]; left[axis]=-2; right[axis]=2
    a=[0,0,0,0]; a[axis]=1
    return {"wall_id":w,"alpha":a,"left":{"time":t-1,"values":left},"right":{"time":t+1,"values":right},
            "uniform_component_errors":[err]*4,"derivative_direction":1,"derivative_magnitude_lower":1,
            "derivative_error":err,"nominal_time":t,"contracts":{"uniform_error_over_bracket_certified":True}}
def base_stream():
    return {'stream_id':'p6','requirements':{'required_state_slots':['S0','S1'],'required_event_slots':['E0','E1'],'required_wall_sequence':['w0','w1']},'receipts':[
        {'receipt_id':'r1','sequence':1,'slot':'S0','kind':'state','payload':state([8,6,4,2])},
        {'receipt_id':'r2','sequence':2,'slot':'E0','kind':'event','payload':event('w0',2,0)},
        {'receipt_id':'r3','sequence':3,'slot':'S1','kind':'state','payload':state([7,-5,3,1])},
        {'receipt_id':'r4','sequence':4,'slot':'E1','kind':'event','payload':event('w1',5,1)},
    ]}
def upd(seq, slot='S1', vals=None, bad=False):
    if vals is None: vals=[8+seq,6,4,2]
    payload=state(vals)
    if bad: payload={'values':[1,2,3,4],'component_errors':[2,0,0,0],'contracts':C}
    return {'receipt_id':f'r{seq}','sequence':seq,'slot':slot,'kind':'state','payload':payload}

def independent_seed():
    z=hashlib.sha256(); z.update(b'HYPERTRIANGLE_SOLVER_AUX_LINEAGE_ACCUMULATOR_V1\n'); z.update(b'EMPTY\n'); return z.hexdigest()
def independent_step(prev,entry):
    z=hashlib.sha256(); z.update(b'HYPERTRIANGLE_SOLVER_AUX_LINEAGE_ACCUMULATOR_V1\n'); z.update(b'STEP\n'); z.update(bytes.fromhex(prev)); z.update(h._canonical_for_hash(entry)); return z.hexdigest()

class TestSolverAuxPass006(unittest.TestCase):
    def setUp(self):
        self.s=base_stream(); self.root=h.create_stream_checkpoint({'stream':self.s})['checkpoint']
    def rotate(self,cp,start,count=1,window=4):
        suffix=[upd(i) for i in range(start,start+count)]
        return h.rotate_bounded_checkpoint({'checkpoint':cp,'receipts':suffix,'anchor_window_size':window})['checkpoint']
    def test_first_bounded_rotation_from_root(self):
        cp=self.rotate(self.root,5,window=4)
        self.assertEqual(cp['schema'],h._BOUNDED_CHECKPOINT_SCHEMA)
        self.assertEqual(cp['rotation_index'],1); self.assertEqual(cp['lineage_entry_count'],1)
        self.assertEqual(cp['lineage_compacted_count'],0); self.assertEqual(len(cp['lineage_anchors']),1)
        self.assertTrue(h.validate_bounded_stream_checkpoint(cp)['checkpoint_valid'])
    def test_anchor_window_is_bounded(self):
        cp=self.root
        for seq in range(5,35): cp=self.rotate(cp,seq,window=4)
        self.assertEqual(cp['rotation_index'],30); self.assertEqual(len(cp['lineage_anchors']),4)
        self.assertEqual(cp['lineage_compacted_count'],26); self.assertEqual(cp['lineage_entry_count'],30)
    def test_no_explicit_full_lineage_in_bounded_checkpoint(self):
        cp=self.rotate(self.root,5)
        self.assertNotIn('checkpoint_lineage',cp)
    def test_independent_accumulator_matches_anchors_and_prefix(self):
        cp=self.root; archived=[cp]
        for seq in range(5,14): cp=self.rotate(cp,seq,window=3); archived.append(cp)
        acc=independent_seed()
        entries=[]
        for anc in archived[:-1]: entries.append(h._checkpoint_lineage_entry(anc))
        for e in entries: acc=independent_step(acc,e)
        self.assertEqual(acc,cp['lineage_accumulator'])
    def test_chain_validation(self):
        cp=self.root; chain=[cp]
        for seq in range(5,20): cp=self.rotate(cp,seq,window=5); chain.append(cp)
        v=h.validate_bounded_checkpoint_chain({'checkpoints':chain})
        self.assertTrue(v['chain_valid']); self.assertEqual(v['lineage_anchor_count'],5); self.assertEqual(v['lineage_compacted_count'],10)
    def test_tampered_anchor_rejected_even_rehashed(self):
        cp=self.root
        for seq in range(5,12): cp=self.rotate(cp,seq,window=3)
        bad=copy.deepcopy(cp); bad['lineage_anchors'][0]['prefix_length'] += 1
        body={k:copy.deepcopy(v) for k,v in bad.items() if k!='checkpoint_hash'}; bad['checkpoint_hash']=h._bounded_checkpoint_hash_body(body)
        v=h.validate_bounded_stream_checkpoint(bad)
        self.assertFalse(v['checkpoint_valid'])
    def test_tampered_compacted_accumulator_detected_by_full_chain(self):
        cp=self.root; chain=[cp]
        for seq in range(5,15): cp=self.rotate(cp,seq,window=3); chain.append(cp)
        bad=copy.deepcopy(chain[-1]); bad['lineage_prefix_accumulator']='0'*64
        bad['lineage_accumulator']=h._fold_lineage_accumulator(bad['lineage_anchors'],bad['lineage_prefix_accumulator'])
        body={k:copy.deepcopy(v) for k,v in bad.items() if k!='checkpoint_hash'}; bad['checkpoint_hash']=h._bounded_checkpoint_hash_body(body)
        self.assertTrue(h.validate_bounded_stream_checkpoint(bad)['checkpoint_valid'])
        v=h.validate_bounded_checkpoint_chain({'checkpoints':chain[:-1]+[bad]})
        self.assertFalse(v['chain_valid']); self.assertEqual(v['status'],'CHECKPOINT_BOUNDED_LINEAGE_MISMATCH')
    def test_full_replay_equivalence(self):
        cp=self.root; full=copy.deepcopy(self.s)
        for seq in range(5,25):
            e=upd(seq); cp=h.rotate_bounded_checkpoint({'checkpoint':cp,'receipts':[e],'anchor_window_size':4})['checkpoint']; full['receipts'].append(copy.deepcopy(e))
        replay=h.certify_receipt_stream(full)
        self.assertEqual(cp['prefix_stream_hash'],replay['final_stream_hash']); self.assertEqual(cp['first_terminal_prefix'],replay['first_terminal_prefix'])
    def test_first_terminal_immutable_through_conflict_repair(self):
        c1=h.rotate_bounded_checkpoint({'checkpoint':self.root,'receipts':[upd(5,bad=True)],'anchor_window_size':3})['checkpoint']
        c2=h.rotate_bounded_checkpoint({'checkpoint':c1,'receipts':[upd(6,vals=[11,-7,5,3])]})['checkpoint']
        self.assertEqual(c2['first_terminal_prefix'],4); self.assertEqual(c2['first_terminal_stream_hash'],self.root['first_terminal_stream_hash'])
        self.assertTrue(c2['post_terminal_regression_seen']); self.assertTrue(c2['post_terminal_semantic_conflict_seen'])
    def test_duplicate_ids_still_exact(self):
        cp=self.rotate(self.root,5,window=2); e=upd(6); e['receipt_id']='r2'
        r=h.rotate_bounded_checkpoint({'checkpoint':cp,'receipts':[e]})
        self.assertEqual(r['status'],'ROTATION_RESUME_FAILED'); self.assertEqual(r['resume']['status'],'DUPLICATE_STREAM_RECEIPT_ID')
    def test_window_immutable_after_migration(self):
        cp=self.rotate(self.root,5,window=3)
        r=h.rotate_bounded_checkpoint({'checkpoint':cp,'receipts':[upd(6)],'anchor_window_size':4})
        self.assertEqual(r['status'],'LINEAGE_ANCHOR_WINDOW_IMMUTABLE')
    def test_migration_from_deep_pass005_checkpoint(self):
        cp=self.root
        for seq in range(5,17): cp=h.rotate_stream_checkpoint({'checkpoint':cp,'receipts':[upd(seq)]})['checkpoint']
        self.assertEqual(len(cp['checkpoint_lineage']),12)
        child=h.rotate_bounded_checkpoint({'checkpoint':cp,'receipts':[upd(17)],'anchor_window_size':4})['checkpoint']
        self.assertEqual(child['rotation_index'],13); self.assertEqual(len(child['lineage_anchors']),4); self.assertEqual(child['lineage_compacted_count'],9)
        self.assertTrue(h.validate_bounded_stream_checkpoint(child)['checkpoint_valid'])
    def test_bounded_downgrade_rejected_in_chain(self):
        c1=self.rotate(self.root,5,window=3)
        # An ordinary PASS005 rotation cannot validate a bounded parent, so chain downgrade is structurally unavailable.
        v=h.validate_bounded_checkpoint_chain({'checkpoints':[self.root,c1]}); self.assertTrue(v['chain_valid'])
    def test_provider_firewall(self):
        env=h.handle_request({'mode':'rotate_bounded_checkpoint','payload':{'checkpoint':self.root,'receipts':[upd(5)],'anchor_window_size':3}})
        self.assertEqual(env['truth_credit'],0); self.assertEqual(env['root_write_capability'],'NONE'); self.assertEqual(env['return_write_capability'],'NONE'); self.assertEqual(env['solver_mutation_capability'],'NONE')
    def test_capabilities_expose_pass006(self):
        caps=h.capabilities()['capabilities']; self.assertIn('rotate_bounded_checkpoint',caps); self.assertIn('validate_bounded_checkpoint_chain',caps)
    def test_checkpoint_lineage_size_component_stays_bounded(self):
        cp=self.root; sizes=[]
        for seq in range(5,105):
            cp=self.rotate(cp,seq,window=5)
            lineage_view={k:cp[k] for k in ('lineage_prefix_accumulator','lineage_anchors','lineage_accumulator','lineage_anchor_window_size','lineage_compacted_count','lineage_entry_count')}
            sizes.append(len(h._canonical_for_hash(lineage_view)))
        self.assertLess(max(sizes[-50:])-min(sizes[-50:]),200)
        self.assertEqual(len(cp['lineage_anchors']),5)

if __name__=='__main__': unittest.main()
