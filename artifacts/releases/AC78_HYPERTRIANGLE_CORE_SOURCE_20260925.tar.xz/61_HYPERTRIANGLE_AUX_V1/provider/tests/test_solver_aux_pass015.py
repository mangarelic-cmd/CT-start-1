import hashlib, json, re, unittest
from pathlib import Path
import hypertriangle_solver_aux as h

ROOT=Path(__file__).resolve().parents[1]
FREEZE=ROOT/'HYPERTRIANGLE_SOLVER_AUX_V1_ABI_FREEZE.json'

def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def csha(obj): return hashlib.sha256(json.dumps(obj,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

class TestPass015FinalFreeze(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.f=json.loads(FREEZE.read_text())

    def test_final_version(self):
        self.assertEqual(h.AUX_VERSION,'1.0.0')

    def test_capability_abi_exact(self):
        caps=h.capabilities()
        self.assertEqual(caps['capabilities'],self.f['capabilities'])
        self.assertEqual(csha(caps['capabilities']),self.f['capabilities_sha256'])
        self.assertEqual(len(caps['capabilities']),61)

    def test_firewall_abi_exact(self):
        caps=h.capabilities()
        self.assertEqual(caps['firewalls'],self.f['firewalls'])
        self.assertEqual(csha(caps['firewalls']),self.f['firewalls_sha256'])
        self.assertIn('zero truth credit',caps['firewalls'])
        self.assertIn('no solver mutation',caps['firewalls'])

    def test_schema_freeze_exact(self):
        self.assertEqual(self.f['schema_count'],35)
        for rel,digest in self.f['schemas'].items():
            p=ROOT/rel
            self.assertTrue(p.is_file(),rel)
            self.assertEqual(sha(p),digest,rel)
            obj=json.loads(p.read_text())
            self.assertIn(obj.get('$schema'),(None,'https://json-schema.org/draft/2020-12/schema'),rel)
        self.assertEqual(csha(self.f['schemas']),self.f['schemas_index_sha256'])

    def test_canon_freeze_exact(self):
        entry=self.f['causal_144_canon']; p=ROOT/entry['path']
        self.assertEqual(sha(p),entry['sha256'])
        obj=json.loads(p.read_text())
        self.assertEqual(obj['slot_count'],144); self.assertEqual(obj['trace_start'],1)
        self.assertEqual([x['slot'] for x in obj['slots']],[f'F{i:03d}' for i in range(1,145)])
        cat=h.memory_144_catalog({})
        self.assertEqual([x['slot'] for x in cat['slots']],[f'F{i:03d}' for i in range(1,145)])

    def test_implementation_freeze_exact(self):
        for rel,digest in self.f['implementation_files'].items(): self.assertEqual(sha(ROOT/rel),digest,rel)
        self.assertEqual(csha(self.f['implementation_files']),self.f['implementation_index_sha256'])

    def test_handle_request_modes_match_abi(self):
        source=(ROOT/'hypertriangle_solver_aux.py').read_text()
        modes=set(re.findall(r'(?:if|elif) mode == [\"\']([^\"\']+)[\"\']',source))
        modes.discard('capabilities')
        self.assertEqual(modes,set(self.f['capabilities']))

    def test_authority_firewall(self):
        env=h.handle_request({'mode':'capabilities','request_id':'freeze'})
        self.assertEqual(env['version'],'1.0.0')
        self.assertEqual(env['truth_credit'],0)
        self.assertEqual(env['root_write_capability'],'NONE')
        self.assertEqual(env['return_write_capability'],'NONE')
        self.assertEqual(env['solver_mutation_capability'],'NONE')
        self.assertEqual(self.f['authority']['external_solver_integration_performed'],False)

    def test_release_metadata_final(self):
        m=json.loads((ROOT/'HYPERTRIANGLE_SOLVER_AUX_PROVIDER_MANIFEST.json').read_text())
        b=json.loads((ROOT/'INTEGRATION_BOUNDARY.json').read_text())
        self.assertEqual(m['version'],'1.0.0'); self.assertEqual(m['branch'],'HYPERTRIANGLE_SOLVER_AUX_PASS015')
        self.assertEqual(m['status'],'COMPLETE_STANDALONE_V1_FROZEN')
        self.assertTrue(m['pass015_final_freeze'])
        self.assertEqual(b['pass'],'PASS015'); self.assertFalse(b['integration_performed'])
        self.assertEqual(m['truth_credit'],0)

    def test_prior_pass_receipts_present(self):
        for i in range(1,15):
            p=ROOT/f'PASS{i:03d}_STATUS.json'
            self.assertTrue(p.is_file(),p.name)
            self.assertEqual(json.loads(p.read_text())['pass'],f'PASS{i:03d}')

    def test_pass014_terminality_survives_v1_version(self):
        events=[
          {'event_id':'V1E1','sequence':1,'type':'MEMORY_DROP','datum_id':'D1','signals':[{'operator':'IDENTITY_SEED','certified':True,'projection':'p1'}]},
        ]
        c={'contract_id':'V1-T','requires_certified_slots':['F001']}
        r=h.memory_144_terminal_replay({'events':events,'terminal_contract':c})
        self.assertTrue(r['terminal_replay_valid']); self.assertTrue(r['projection']['current_terminal'])
        self.assertEqual(r['projection']['first_terminal_prefix'],1)

if __name__=='__main__': unittest.main()
