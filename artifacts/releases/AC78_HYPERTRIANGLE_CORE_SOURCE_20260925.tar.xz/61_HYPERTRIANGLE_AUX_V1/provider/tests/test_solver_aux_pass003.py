import unittest, copy
from hypertriangle_solver_aux import certify_receipt_stream, handle_request

C={"common_scale_certified":True,"axis_independence_certified":True,"b4_comparable":True}

def state(vals,err="1/100"):
    return {"values":vals,"component_errors":[err]*4,"contracts":C}

def event(w,t,axis,err="1/100"):
    base=[8,6,4,2]
    left=base[:]; right=base[:]
    left[axis]=-2; right[axis]=2
    alpha=[0,0,0,0]; alpha[axis]=1
    return {"wall_id":w,"alpha":alpha,"left":{"time":t-1,"values":left},"right":{"time":t+1,"values":right},
            "uniform_component_errors":[err]*4,"derivative_direction":1,"derivative_magnitude_lower":1,
            "derivative_error":err,"nominal_time":t,"contracts":{"uniform_error_over_bracket_certified":True}}

def stream4():
    return {"stream_id":"s-demo","requirements":{"required_state_slots":["S0","S1"],"required_event_slots":["E0","E1"],"required_wall_sequence":["w0","w1"]},"receipts":[
        {"receipt_id":"r1","sequence":1,"slot":"S0","kind":"state","payload":state([8,6,4,2])},
        {"receipt_id":"r2","sequence":2,"slot":"E0","kind":"event","payload":event("w0",2,0)},
        {"receipt_id":"r3","sequence":3,"slot":"S1","kind":"state","payload":state([7,-5,3,1])},
        {"receipt_id":"r4","sequence":4,"slot":"E1","kind":"event","payload":event("w1",5,1)},
    ]}

class TestSolverAuxPass003(unittest.TestCase):
    def test_first_terminal_prefix_4(self):
        r=certify_receipt_stream(stream4())
        self.assertTrue(r["historical_terminal"])
        self.assertTrue(r["current_terminal"])
        self.assertEqual(r["first_terminal_prefix"],4)
        self.assertEqual(r["stop_policy"],"STOP_AT_PREFIX_4")
        self.assertEqual([x["terminal_now"] for x in r["prefix_history"]],[False,False,False,True])

    def test_late_bad_receipt_cannot_erase_history(self):
        p=stream4(); p["receipts"].append({"receipt_id":"r5","sequence":5,"slot":"S1","kind":"state","payload":state([1,2,3,4])|{"component_errors":[2,0,0,0]}})
        r=certify_receipt_stream(p)
        self.assertTrue(r["historical_terminal"])
        self.assertFalse(r["current_terminal"])
        self.assertEqual(r["first_terminal_prefix"],4)
        self.assertTrue(r["current_prefix_regressed"])
        self.assertTrue(r["post_terminal_semantic_conflict"])
        self.assertIn("POST_TERMINAL_CONFLICT",r["status"])

    def test_late_good_receipt_preserves_terminal(self):
        p=stream4(); p["receipts"].append({"receipt_id":"r5","sequence":5,"slot":"S1","kind":"state","payload":state([9,-7,5,3])})
        r=certify_receipt_stream(p)
        self.assertTrue(r["historical_terminal"])
        self.assertTrue(r["current_terminal"])
        self.assertEqual(r["first_terminal_prefix"],4)
        self.assertEqual(r["post_terminal_receipt_count"],1)

    def test_no_terminal_prefix(self):
        p=stream4(); p["receipts"]=p["receipts"][:3]
        r=certify_receipt_stream(p)
        self.assertFalse(r["historical_terminal"])
        self.assertEqual(r["status"],"NO_TERMINAL_PREFIX")
        self.assertEqual(r["stop_policy"],"CONTINUE_ACQUISITION")

    def test_duplicate_id_rejected(self):
        p=stream4(); p["receipts"][1]["receipt_id"]="r1"
        r=certify_receipt_stream(p)
        self.assertEqual(r["status"],"DUPLICATE_STREAM_RECEIPT_ID")

    def test_sequence_mismatch_rejected(self):
        p=stream4(); p["receipts"][2]["sequence"]=99
        r=certify_receipt_stream(p)
        self.assertEqual(r["status"],"INVALID_STREAM_SEQUENCE")

    def test_missing_slot_rejected(self):
        p=stream4(); del p["receipts"][0]["slot"]
        r=certify_receipt_stream(p)
        self.assertEqual(r["status"],"INVALID_STREAM_SLOT")

    def test_hash_changes_when_payload_changes(self):
        a=certify_receipt_stream(stream4())
        p=stream4(); p["receipts"][0]["payload"]=state([10,8,6,4])
        b=certify_receipt_stream(p)
        self.assertNotEqual(a["final_stream_hash"],b["final_stream_hash"])

    def test_hash_deterministic(self):
        a=certify_receipt_stream(stream4())
        b=certify_receipt_stream(copy.deepcopy(stream4()))
        self.assertEqual(a["final_stream_hash"],b["final_stream_hash"])
        self.assertEqual(a["first_terminal_stream_hash"],b["first_terminal_stream_hash"])

    def test_wrong_wall_sequence_prevents_terminal(self):
        p=stream4(); p["requirements"]["required_wall_sequence"]=["w1","w0"]
        r=certify_receipt_stream(p)
        self.assertFalse(r["historical_terminal"])
        self.assertEqual(r["prefix_history"][-1]["route_status"],"WALL_SEQUENCE_MISMATCH")

    def test_provider_envelope_authority(self):
        r=handle_request({"mode":"receipt_stream","payload":stream4()})
        self.assertEqual(r["truth_credit"],0)
        self.assertEqual(r["root_write_capability"],"NONE")
        self.assertEqual(r["return_write_capability"],"NONE")
        self.assertEqual(r["solver_mutation_capability"],"NONE")
        self.assertEqual(r["receipt"]["first_terminal_prefix"],4)

if __name__=='__main__': unittest.main()
