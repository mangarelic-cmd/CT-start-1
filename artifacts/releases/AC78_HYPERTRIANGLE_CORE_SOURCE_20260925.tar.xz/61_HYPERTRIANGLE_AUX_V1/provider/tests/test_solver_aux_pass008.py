import copy, json, os, tempfile, unittest
from pathlib import Path
import hypertriangle_solver_aux as h
import receipt_id_sidecar as s

class TestSolverAuxPass008(unittest.TestCase):
    def test_snapshot_deterministic_and_sorted(self):
        a=h.receipt_id_sidecar_snapshot({'receipt_ids':['c','a','b'],'generation':0})
        b=h.receipt_id_sidecar_snapshot({'receipt_ids':['b','c','a'],'generation':0})
        self.assertTrue(a['snapshot_valid']); self.assertEqual(a['snapshot'],b['snapshot'])
        self.assertEqual(tuple(a['snapshot']['receipt_ids']),('a','b','c'))
    def test_snapshot_validation(self):
        snap=h.receipt_id_sidecar_snapshot({'receipt_ids':['a','b']})['snapshot']
        self.assertTrue(h.validate_receipt_id_sidecar_snapshot(snap)['snapshot_valid'])
    def test_snapshot_tamper_rejected(self):
        snap=h.receipt_id_sidecar_snapshot({'receipt_ids':['a','b']})['snapshot']
        bad=copy.deepcopy(snap); bad['receipt_ids']=('z','b')
        self.assertFalse(h.validate_receipt_id_sidecar_snapshot(bad)['snapshot_valid'])
    def test_duplicate_snapshot_rejected(self):
        out=h.receipt_id_sidecar_snapshot({'receipt_ids':['a','a']})
        self.assertFalse(out['snapshot_valid'])
    def test_append_and_recover(self):
        snap=h.receipt_id_sidecar_snapshot({'receipt_ids':['a']})['snapshot']
        a=h.append_receipt_id_sidecar({'snapshot':snap,'journal_records':[],'receipt_id':'b'})
        self.assertTrue(a['appended'])
        r=h.recover_receipt_id_sidecar({'snapshot':snap,'journal_records':[a['journal_entry']]})
        self.assertTrue(r['recovered']); self.assertEqual(r['receipt_id_count'],2)
        self.assertEqual(r['receipt_id_root'],h.sparse_receipt_id_root(['a','b']))
    def test_duplicate_append_rejected(self):
        snap=h.receipt_id_sidecar_snapshot({'receipt_ids':['a']})['snapshot']
        a=h.append_receipt_id_sidecar({'snapshot':snap,'journal_records':[],'receipt_id':'a'})
        self.assertFalse(a['appended']); self.assertEqual(a['status'],'DUPLICATE_STREAM_RECEIPT_ID')
    def test_journal_chain_tamper_rejected(self):
        snap=h.receipt_id_sidecar_snapshot({'receipt_ids':['a']})['snapshot']
        a=h.append_receipt_id_sidecar({'snapshot':snap,'journal_records':[],'receipt_id':'b'})
        bad=copy.deepcopy(a['journal_entry']); bad['root_after']='0'*64
        r=h.recover_receipt_id_sidecar({'snapshot':snap,'journal_records':[bad]})
        self.assertFalse(r['recovered'])
    def test_stale_journal_record_rejected(self):
        snap=h.receipt_id_sidecar_snapshot({'receipt_ids':['a']})['snapshot']
        b=h.append_receipt_id_sidecar({'snapshot':snap,'journal_records':[],'receipt_id':'b'})['journal_entry']
        c=h.append_receipt_id_sidecar({'snapshot':snap,'journal_records':[],'receipt_id':'c'})['journal_entry']
        r=h.recover_receipt_id_sidecar({'snapshot':snap,'journal_records':[b,c]})
        self.assertFalse(r['recovered'])
    def test_sidecar_proof_current_root(self):
        snap=h.receipt_id_sidecar_snapshot({'receipt_ids':['a']})['snapshot']
        e=h.append_receipt_id_sidecar({'snapshot':snap,'journal_records':[],'receipt_id':'b'})['journal_entry']
        p=h.receipt_id_sidecar_proof({'snapshot':snap,'journal_records':[e],'receipt_id':'z'})
        self.assertTrue(p['proof_valid']); self.assertFalse(p['present'])
        self.assertTrue(h.verify_sparse_receipt_id_proof(p['receipt_id_root'],'z',p['proof'],expected_present=False)['proof_valid'])
    def test_compaction_preserves_root_and_count(self):
        snap=h.receipt_id_sidecar_snapshot({'receipt_ids':['a']})['snapshot']
        e=h.append_receipt_id_sidecar({'snapshot':snap,'journal_records':[],'receipt_id':'b'})['journal_entry']
        c=h.compact_receipt_id_sidecar({'snapshot':snap,'journal_records':[e]})
        self.assertTrue(c['compacted']); self.assertEqual(c['receipt_id_count'],2)
        self.assertEqual(c['snapshot']['receipt_id_root'],h.sparse_receipt_id_root(['a','b']))
        self.assertEqual(c['snapshot']['generation'],1); self.assertEqual(c['snapshot']['parent_snapshot_hash'],snap['snapshot_hash'])
    def test_file_roundtrip_and_proof(self):
        with tempfile.TemporaryDirectory() as td:
            sp=Path(td)/'snapshot.json'; jp=Path(td)/'journal.ndjson'
            s.init_snapshot(sp,['a']); s.ensure_journal(jp); s.append_file(sp,jp,'b')
            r=s.recover_files(sp,jp); self.assertTrue(r['recovered']); self.assertEqual(r['receipt_id_count'],2)
            p=s.proof_files(sp,jp,'z'); self.assertTrue(p['proof_valid']); self.assertFalse(p['present'])
    def test_uncommitted_tail_ignored(self):
        with tempfile.TemporaryDirectory() as td:
            sp=Path(td)/'snapshot.json'; jp=Path(td)/'journal.ndjson'
            s.init_snapshot(sp,['a']); s.ensure_journal(jp); s.append_file(sp,jp,'b')
            with open(jp,'ab') as f: f.write(b'{"schema":"half')
            r=s.recover_files(sp,jp,allow_uncommitted_tail=True)
            self.assertTrue(r['recovered']); self.assertTrue(r['truncated_tail_ignored']); self.assertEqual(r['receipt_id_count'],2)
            with self.assertRaises(ValueError): s.recover_files(sp,jp,allow_uncommitted_tail=False)
    def test_committed_malformed_line_is_hard_error(self):
        with tempfile.TemporaryDirectory() as td:
            sp=Path(td)/'snapshot.json'; jp=Path(td)/'journal.ndjson'
            s.init_snapshot(sp,['a']); s.ensure_journal(jp)
            with open(jp,'ab') as f: f.write(b'{bad json}\n')
            with self.assertRaises(ValueError): s.recover_files(sp,jp,allow_uncommitted_tail=True)
    def test_compact_files_new_generation(self):
        with tempfile.TemporaryDirectory() as td:
            sp=Path(td)/'snapshot.json'; jp=Path(td)/'journal.ndjson'; nsp=Path(td)/'snapshot2.json'; njp=Path(td)/'journal2.ndjson'
            s.init_snapshot(sp,['a']); s.ensure_journal(jp); s.append_file(sp,jp,'b')
            c=s.compact_files(sp,jp,nsp,njp); self.assertTrue(c['compacted'])
            r=s.recover_files(nsp,njp); self.assertTrue(r['recovered']); self.assertEqual(r['receipt_id_count'],2); self.assertEqual(r['generation'],1)
    def test_append_refuses_uncommitted_tail(self):
        with tempfile.TemporaryDirectory() as td:
            sp=Path(td)/'snapshot.json'; jp=Path(td)/'journal.ndjson'
            s.init_snapshot(sp,['a']); s.ensure_journal(jp)
            with open(jp,'ab') as f: f.write(b'{"partial":')
            with self.assertRaises(ValueError): s.append_file(sp,jp,'b')
    def test_provider_modes_and_firewalls(self):
        caps=h.capabilities()['capabilities']
        for m in ('receipt_id_sidecar_snapshot','receipt_id_sidecar_recover','receipt_id_sidecar_append','receipt_id_sidecar_proof','receipt_id_sidecar_compact'):
            self.assertIn(m,caps)
        env=h.handle_request({'mode':'receipt_id_sidecar_snapshot','payload':{'receipt_ids':['a']}})
        self.assertEqual(env['truth_credit'],0); self.assertEqual(env['root_write_capability'],'NONE'); self.assertEqual(env['solver_mutation_capability'],'NONE')

if __name__=='__main__': unittest.main()
