import copy, unittest
import hypertriangle_solver_aux as h


def route_payload(tag='P14'):
    return {
        'trace_id':tag,
        'contracts':{'additive':True,'common_ledger':True,'positivity_certified':True,'grounded':True},
        'cells':[{'occurrence_id':'a','weight':2},{'occurrence_id':'b','weight':3},{'occurrence_id':'c','weight':5}],
    }


def prefix3():
    return [
        {'event_id':'E001','sequence':1,'type':'MEMORY_DROP','datum_id':'D1','signals':[{'operator':'IDENTITY_SEED','certified':True,'projection':'p1'}]},
        {'event_id':'E002','sequence':2,'type':'ACTIVATE','contracts':[{'contract_id':'C-route','capability':'route_simplex','requires_all':['F001']}]},
        {'event_id':'E003','sequence':3,'type':'CAPABILITY','capability':'route_simplex','contract_id':'C-route','capability_payload':route_payload('r1')},
    ]


def suffix_repair():
    return [
        {'event_id':'E004','sequence':4,'type':'MEMORY_DROP','datum_id':'D2','signals':[{'operator':'DIRECTED_ONSET','certified':True,'projection':'p3'}]},
        {'event_id':'E005','sequence':5,'type':'ACTIVATE','contracts':[{'contract_id':'C-pol','capability':'signed_polarity','requires_all':['F003']}]},
        {'event_id':'E006','sequence':6,'type':'CAPABILITY','capability':'signed_polarity','contract_id':'C-pol','capability_payload':{'values':[3,-2,0]}},
        {'event_id':'E007','sequence':7,'type':'ACTIVATE','contracts':[
            {'contract_id':'C-route','capability':'route_simplex','requires_all':['F001']},
            {'contract_id':'C-pol','capability':'signed_polarity','requires_all':['F003']},
        ]},
        {'event_id':'E008','sequence':8,'type':'CAPABILITY','capability':'route_simplex','contract_id':'C-route','capability_payload':route_payload('r2')},
    ]


def terminal_contract():
    return {
        'contract_id':'T-route',
        'requires_certified_slots':['F001'],
        'requires_active_contracts':['C-route'],
        'requires_active_capabilities':['route_simplex'],
        'requires_completed_capabilities':['route_simplex'],
    }


class TestPass014Terminality(unittest.TestCase):
    def test_version(self):
        self.assertGreaterEqual(tuple(map(int,h.AUX_VERSION.split('.'))),(0,14,0))

    def test_first_terminal_prefix_is_three(self):
        r=h.memory_144_terminal_replay({'events':prefix3(),'terminal_contract':terminal_contract()})
        self.assertTrue(r['terminal_replay_valid'])
        p=r['projection']
        self.assertTrue(p['historical_terminal']); self.assertTrue(p['current_terminal'])
        self.assertEqual(p['first_terminal_prefix'],3); self.assertEqual(p['stop_policy'],'STOP_AT_PREFIX_3')

    def test_memory_change_regresses_completion_until_reexecution(self):
        ev=prefix3()+suffix_repair()[:1]
        r=h.memory_144_terminal_replay({'events':ev,'terminal_contract':terminal_contract()})
        self.assertTrue(r['terminal_replay_valid']); p=r['projection']
        self.assertTrue(p['historical_terminal']); self.assertFalse(p['current_terminal'])
        self.assertEqual(p['first_terminal_prefix'],3); self.assertEqual(p['post_terminal_regression_count'],1)
        self.assertIn('route_simplex',r['tracker']['current_evaluation']['stale_completed_capabilities'])

    def test_repair_does_not_rewrite_first_terminal(self):
        r=h.memory_144_terminal_replay({'events':prefix3()+suffix_repair(),'terminal_contract':terminal_contract()})
        self.assertTrue(r['terminal_replay_valid']); p=r['projection']
        self.assertTrue(p['current_terminal']); self.assertEqual(p['first_terminal_prefix'],3)
        self.assertEqual(p['post_terminal_regression_count'],4)
        self.assertEqual(r['tracker']['first_terminal_certificate']['prefix_event_count'],3)

    def test_forbidden_slot_becomes_semantic_conflict(self):
        c=terminal_contract(); c['forbids_certified_slots']=['F003']
        r=h.memory_144_terminal_replay({'events':prefix3()+suffix_repair()[:1],'terminal_contract':c})
        self.assertTrue(r['terminal_replay_valid']); p=r['projection']
        self.assertTrue(p['historical_terminal']); self.assertFalse(p['current_terminal'])
        self.assertTrue(p['post_terminal_semantic_conflict_seen'])
        self.assertEqual(r['tracker']['current_evaluation']['status'],'AUX_BLOCKED_FORBIDDEN')

    def test_empty_positive_contract_rejected(self):
        r=h.memory_144_terminal_replay({'events':[],'terminal_contract':{'contract_id':'empty','forbids_certified_slots':['F003']}})
        self.assertFalse(r['terminal_replay_valid'])

    def test_require_forbid_overlap_rejected(self):
        c={'contract_id':'bad','requires_certified_slots':['F001'],'forbids_certified_slots':['F001']}
        self.assertFalse(h.memory_144_terminal_replay({'events':[],'terminal_contract':c})['terminal_replay_valid'])

    def test_create_and_validate_terminal_checkpoint(self):
        r=h.memory_144_create_terminal_checkpoint({'events':prefix3(),'terminal_contract':terminal_contract()})
        self.assertTrue(r['terminal_checkpoint_valid'])
        v=h.validate_memory_144_terminal_checkpoint({'checkpoint':r['checkpoint']})
        self.assertTrue(v['terminal_checkpoint_valid']); self.assertEqual(v['first_terminal_prefix'],3)

    def test_resume_checkpoint_preserves_first_terminal(self):
        r=h.memory_144_create_terminal_checkpoint({'events':prefix3(),'terminal_contract':terminal_contract()})
        x=h.memory_144_resume_terminal_checkpoint({'checkpoint':r['checkpoint'],'sidecar_snapshot':r['sidecar_snapshot'],'events':suffix_repair()})
        self.assertTrue(x['terminal_resume_valid']); self.assertTrue(x['projection']['current_terminal'])
        self.assertEqual(x['projection']['first_terminal_prefix'],3)

    def test_checkpoint_plus_suffix_matches_full_replay_terminal_projection(self):
        root=h.memory_144_create_terminal_checkpoint({'events':prefix3(),'terminal_contract':terminal_contract()})
        x=h.memory_144_resume_terminal_checkpoint({'checkpoint':root['checkpoint'],'sidecar_snapshot':root['sidecar_snapshot'],'events':suffix_repair()})
        full=h.memory_144_terminal_replay({'events':prefix3()+suffix_repair(),'terminal_contract':terminal_contract()})
        self.assertTrue(x['terminal_resume_valid']); self.assertTrue(full['terminal_replay_valid'])
        for k in ('historical_terminal','current_terminal','first_terminal_prefix','post_terminal_regression_count','terminal_history_accumulator','execution_state_hash'):
            self.assertEqual(x['projection'][k],full['projection'][k])

    def test_rotation_and_transition(self):
        root=h.memory_144_create_terminal_checkpoint({'events':prefix3(),'terminal_contract':terminal_contract()})
        child=h.memory_144_rotate_terminal_checkpoint({'checkpoint':root['checkpoint'],'sidecar_snapshot':root['sidecar_snapshot'],'events':suffix_repair()})
        self.assertTrue(child['terminal_checkpoint_valid']); self.assertTrue(child['checkpoint']['current_terminal'])
        self.assertEqual(child['checkpoint']['first_terminal_prefix'],3)
        v=h.validate_memory_144_terminal_transition({'parent_checkpoint':root['checkpoint'],'parent_sidecar_snapshot':root['sidecar_snapshot'],'events':suffix_repair(),'child_checkpoint':child['checkpoint'],'child_sidecar_snapshot':child['sidecar_snapshot']})
        self.assertTrue(v['terminal_transition_valid'])

    def test_tamper_first_terminal_prefix_rejected(self):
        r=h.memory_144_create_terminal_checkpoint({'events':prefix3(),'terminal_contract':terminal_contract()})
        bad=copy.deepcopy(r['checkpoint']); bad['first_terminal_prefix']=2
        body={k:copy.deepcopy(v) for k,v in bad.items() if k!='terminal_checkpoint_hash'}
        bad['terminal_checkpoint_hash']=h._memory_144_terminal_checkpoint_hash(body)
        self.assertFalse(h.validate_memory_144_terminal_checkpoint({'checkpoint':bad})['terminal_checkpoint_valid'])

    def test_tamper_current_eval_rejected(self):
        r=h.memory_144_create_terminal_checkpoint({'events':prefix3(),'terminal_contract':terminal_contract()})
        bad=copy.deepcopy(r['checkpoint']); bad['current_terminal_evaluation']['terminal']=False
        body={k:copy.deepcopy(v) for k,v in bad.items() if k!='terminal_checkpoint_hash'}
        bad['terminal_checkpoint_hash']=h._memory_144_terminal_checkpoint_hash(body)
        self.assertFalse(h.validate_memory_144_terminal_checkpoint({'checkpoint':bad})['terminal_checkpoint_valid'])

    def test_tamper_execution_state_rejected(self):
        r=h.memory_144_create_terminal_checkpoint({'events':prefix3(),'terminal_contract':terminal_contract()})
        bad=copy.deepcopy(r['checkpoint']); bad['execution_state_hash']='0'*64
        body={k:copy.deepcopy(v) for k,v in bad.items() if k!='terminal_checkpoint_hash'}
        bad['terminal_checkpoint_hash']=h._memory_144_terminal_checkpoint_hash(body)
        self.assertFalse(h.validate_memory_144_terminal_checkpoint({'checkpoint':bad})['terminal_checkpoint_valid'])

    def test_transition_rejects_contract_substitution(self):
        root=h.memory_144_create_terminal_checkpoint({'events':prefix3(),'terminal_contract':terminal_contract()})
        child=h.memory_144_rotate_terminal_checkpoint({'checkpoint':root['checkpoint'],'sidecar_snapshot':root['sidecar_snapshot'],'events':suffix_repair()})
        bad=copy.deepcopy(child['checkpoint']); bad['terminal_contract']['contract_id']='OTHER'
        c=h._memory_144_normalize_terminal_contract(bad['terminal_contract']); bad['terminal_contract']=c; bad['terminal_contract_hash']=h._memory_144_terminal_contract_hash(c)
        body={k:copy.deepcopy(v) for k,v in bad.items() if k!='terminal_checkpoint_hash'}; bad['terminal_checkpoint_hash']=h._memory_144_terminal_checkpoint_hash(body)
        v=h.validate_memory_144_terminal_transition({'parent_checkpoint':root['checkpoint'],'parent_sidecar_snapshot':root['sidecar_snapshot'],'events':suffix_repair(),'child_checkpoint':bad,'child_sidecar_snapshot':child['sidecar_snapshot']})
        self.assertFalse(v['terminal_transition_valid'])

    def test_nonterminal_contract_remains_open(self):
        c={'contract_id':'never-yet','requires_certified_slots':['F144']}
        r=h.memory_144_terminal_replay({'events':prefix3(),'terminal_contract':c})
        self.assertTrue(r['terminal_replay_valid']); self.assertFalse(r['projection']['historical_terminal']); self.assertEqual(r['projection']['stop_policy'],'CONTINUE_ACQUISITION')

    def test_completed_capability_requires_current_activation(self):
        c={'contract_id':'done','requires_completed_capabilities':['route_simplex']}
        ev=prefix3()+[{'event_id':'E004','sequence':4,'type':'ACTIVATE','contracts':[{'contract_id':'C-pol','capability':'signed_polarity','requires_all':['F001']}]}]
        r=h.memory_144_terminal_replay({'events':ev,'terminal_contract':c})
        self.assertTrue(r['terminal_replay_valid']); self.assertFalse(r['projection']['current_terminal']); self.assertIn('route_simplex',r['tracker']['current_evaluation']['stale_completed_capabilities'])

    def test_provider_modes(self):
        caps=h.capabilities()['capabilities']
        modes=('memory_144_terminal_replay','memory_144_create_terminal_checkpoint','memory_144_validate_terminal_checkpoint','memory_144_resume_terminal_checkpoint','memory_144_rotate_terminal_checkpoint','memory_144_validate_terminal_transition')
        for m in modes: self.assertIn(m,caps)
        env=h.handle_request({'mode':'memory_144_terminal_replay','payload':{'events':prefix3(),'terminal_contract':terminal_contract()}})
        self.assertGreaterEqual(tuple(map(int,env['version'].split('.'))),(0,14,0)); self.assertEqual(env['truth_credit'],0); self.assertEqual(env['solver_mutation_capability'],'NONE')


if __name__=='__main__': unittest.main()
