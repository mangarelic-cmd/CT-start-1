import copy, json, subprocess, sys, tempfile, unittest
from pathlib import Path
import hypertriangle_solver_aux as h
import receipt_id_sidecar as s
import receipt_id_sidecar_store as st


def child_from(parent, new_ids):
    records=[]
    for rid in new_ids:
        out=h.append_receipt_id_sidecar({'snapshot':parent,'journal_records':records,'receipt_id':rid})
        assert out['appended']; records.append(out['journal_entry'])
    comp=h.compact_receipt_id_sidecar({'snapshot':parent,'journal_records':records})
    assert comp['compacted']
    return comp['snapshot'], records

class TestSolverAuxPass009(unittest.TestCase):
    def test_snapshot_chain_build_and_validate(self):
        s0=h.receipt_id_sidecar_snapshot({'receipt_ids':['a'],'generation':0})['snapshot']
        s1,r1=child_from(s0,['b','c']); s2,r2=child_from(s1,['d'])
        out=h.receipt_id_sidecar_snapshot_chain({'snapshots':[s0,s1,s2],'anchor_window':2})
        self.assertTrue(out['chain_valid']); state=out['chain_state']
        self.assertEqual(state['snapshot_count'],3); self.assertEqual(state['compacted_snapshot_count'],1); self.assertEqual(len(state['anchors']),2)
        self.assertTrue(h.validate_receipt_id_sidecar_snapshot_chain({'chain_state':state})['chain_valid'])
    def test_snapshot_chain_tamper_rejected(self):
        s0=h.receipt_id_sidecar_snapshot({'receipt_ids':['a']})['snapshot']; s1,_=child_from(s0,['b'])
        state=h.receipt_id_sidecar_snapshot_chain({'snapshots':[s0,s1]})['chain_state']
        bad=copy.deepcopy(state); bad['tip_receipt_id_count']=999
        self.assertFalse(h.validate_receipt_id_sidecar_snapshot_chain({'chain_state':bad})['chain_valid'])
    def test_chain_incremental_append_matches_full(self):
        snaps=[h.receipt_id_sidecar_snapshot({'receipt_ids':['a']})['snapshot']]
        for j in range(1,12): snaps.append(child_from(snaps[-1],[f'x{j}'])[0])
        state=h.receipt_id_sidecar_snapshot_chain({'snapshots':[snaps[0]],'anchor_window':4})['chain_state']
        for snap in snaps[1:]:
            out=h.receipt_id_sidecar_snapshot_chain_append({'chain_state':state,'snapshot':snap}); self.assertTrue(out['chain_valid']); state=out['chain_state']
        full=h.receipt_id_sidecar_snapshot_chain({'snapshots':snaps,'anchor_window':4})['chain_state']
        self.assertEqual(state['chain_accumulator'],full['chain_accumulator']); self.assertEqual(state['chain_state_hash'],full['chain_state_hash']); self.assertEqual(len(state['anchors']),4)
    def test_chain_append_fork_rejected(self):
        s0=h.receipt_id_sidecar_snapshot({'receipt_ids':['a']})['snapshot']; state=h.receipt_id_sidecar_snapshot_chain({'snapshots':[s0]})['chain_state']
        fork=h.receipt_id_sidecar_snapshot({'receipt_ids':['a','z'],'generation':1,'parent_snapshot_hash':'0'*64,'compacted_journal_tail_hash':'1'*64})['snapshot']
        self.assertFalse(h.receipt_id_sidecar_snapshot_chain_append({'chain_state':state,'snapshot':fork})['chain_valid'])
    def test_compaction_transition_exact(self):
        s0=h.receipt_id_sidecar_snapshot({'receipt_ids':['a']})['snapshot']; s1,recs=child_from(s0,['b','c'])
        self.assertTrue(h.validate_receipt_id_sidecar_compaction_transition({'parent_snapshot':s0,'journal_records':recs,'child_snapshot':s1})['transition_valid'])
        bad=copy.deepcopy(s1); bad['receipt_ids']=('a','b','z')
        self.assertFalse(h.validate_receipt_id_sidecar_compaction_transition({'parent_snapshot':s0,'journal_records':recs,'child_snapshot':bad})['transition_valid'])
    def test_policy_record_threshold(self):
        s0=h.receipt_id_sidecar_snapshot({'receipt_ids':['a']})['snapshot']; recs=[]
        for rid in ['b','c']:
            x=h.append_receipt_id_sidecar({'snapshot':s0,'journal_records':recs,'receipt_id':rid}); recs.append(x['journal_entry'])
        d=h.receipt_id_sidecar_compaction_decision({'snapshot':s0,'journal_records':recs,'policy':{'max_journal_records':2,'max_journal_bytes':999999}})
        self.assertTrue(d['compact_now']); self.assertIn('JOURNAL_RECORD_THRESHOLD',d['triggers'])
    def test_policy_byte_threshold(self):
        s0=h.receipt_id_sidecar_snapshot({'receipt_ids':['a']})['snapshot']; x=h.append_receipt_id_sidecar({'snapshot':s0,'journal_records':[],'receipt_id':'b'})
        d=h.receipt_id_sidecar_compaction_decision({'snapshot':s0,'journal_records':[x['journal_entry']],'policy':{'max_journal_records':999,'max_journal_bytes':1}})
        self.assertTrue(d['compact_now']); self.assertIn('JOURNAL_BYTE_THRESHOLD',d['triggers'])
    def test_policy_keep_append(self):
        s0=h.receipt_id_sidecar_snapshot({'receipt_ids':['a']})['snapshot']
        d=h.receipt_id_sidecar_compaction_decision({'snapshot':s0,'journal_records':[],'policy':{'max_journal_records':2,'max_journal_bytes':100}})
        self.assertFalse(d['compact_now']); self.assertEqual(d['status'],'KEEP_APPEND')
    def test_pure_auto_compact(self):
        s0=h.receipt_id_sidecar_snapshot({'receipt_ids':['a']})['snapshot']; x=h.append_receipt_id_sidecar({'snapshot':s0,'journal_records':[],'receipt_id':'b'})
        out=h.receipt_id_sidecar_auto_compact({'snapshot':s0,'journal_records':[x['journal_entry']],'policy':{'max_journal_records':1,'max_journal_bytes':999999}})
        self.assertTrue(out['compaction_performed']); self.assertEqual(out['snapshot']['generation'],1)
    def test_store_auto_compaction_generations(self):
        with tempfile.TemporaryDirectory() as td:
            st.init_store(td,['a'],policy={'max_journal_records':3,'max_journal_bytes':999999},anchor_window=2)
            st.append_store(td,'b'); st.append_store(td,'c'); out=st.append_store(td,'d')
            self.assertEqual(out['status'],'SIDECAR_STORE_APPENDED_AND_COMPACTED')
            v=st.verify_store(td,audit_archives=True); self.assertEqual(v['generation'],1); self.assertEqual(v['receipt_id_count'],4); self.assertEqual(v['journal_record_count'],0)
            self.assertTrue((Path(td)/'snapshots/g000000000.json').exists()); self.assertTrue((Path(td)/'snapshots/g000000001.json').exists())
    def test_store_long_rotation_bounded_chain(self):
        with tempfile.TemporaryDirectory() as td:
            st.init_store(td,['root'],policy={'max_journal_records':1,'max_journal_bytes':999999},anchor_window=3)
            for i in range(12): st.append_store(td,f'r{i}')
            p=st.load_pointer(td); self.assertEqual(p['generation'],12); self.assertEqual(len(p['snapshot_chain_state']['anchors']),3); self.assertEqual(p['snapshot_chain_state']['compacted_snapshot_count'],10)
            self.assertEqual(st.verify_store(td,audit_archives=True)['receipt_id_count'],13)
    def test_store_pointer_tamper_rejected(self):
        with tempfile.TemporaryDirectory() as td:
            st.init_store(td,['a']); p=Path(td)/'CURRENT.json'; obj=json.loads(p.read_text()); obj['generation']=99; p.write_text(json.dumps(obj))
            with self.assertRaises(ValueError): st.load_pointer(td)
    def test_store_proof(self):
        with tempfile.TemporaryDirectory() as td:
            st.init_store(td,['a']); st.append_store(td,'b',auto_compact=False)
            p=st.proof_store(td,'b'); self.assertTrue(p['present']); q=st.proof_store(td,'z'); self.assertFalse(q['present'])
    def test_store_force_compact(self):
        with tempfile.TemporaryDirectory() as td:
            st.init_store(td,['a'],policy={'max_journal_records':99,'max_journal_bytes':999999}); st.append_store(td,'b',auto_compact=False)
            out=st.compact_store(td,force=True); self.assertTrue(out['compaction_performed']); self.assertEqual(out['generation'],1)
    def test_store_empty_force_is_noop(self):
        with tempfile.TemporaryDirectory() as td:
            st.init_store(td,['a']); out=st.compact_store(td,force=True); self.assertFalse(out['compaction_performed'])
    def test_orphan_generation_does_not_switch_current(self):
        with tempfile.TemporaryDirectory() as td:
            st.init_store(td,['a']); p0=st.load_pointer(td); sp=Path(td)/'snapshots/g000000001.json'
            fake=h.receipt_id_sidecar_snapshot({'receipt_ids':['a'],'generation':1,'parent_snapshot_hash':p0['snapshot_hash'],'compacted_journal_tail_hash':'1'*64})['snapshot']; s.atomic_write_json(sp,fake)
            self.assertEqual(st.load_pointer(td)['generation'],0); self.assertEqual(st.verify_store(td)['generation'],0)
    def test_capabilities_include_pass009(self):
        caps=h.capabilities()['capabilities']
        for m in ('receipt_id_sidecar_snapshot_chain','receipt_id_sidecar_snapshot_chain_append','validate_receipt_id_sidecar_snapshot_chain','validate_receipt_id_sidecar_compaction_transition','receipt_id_sidecar_compaction_decision','receipt_id_sidecar_auto_compact'):
            self.assertIn(m,caps)
        env=h.handle_request({'mode':'receipt_id_sidecar_compaction_decision','payload':{'snapshot':h.receipt_id_sidecar_snapshot({'receipt_ids':[]})['snapshot'],'journal_records':[]}})
        self.assertEqual(env['truth_credit'],0); self.assertEqual(env['solver_mutation_capability'],'NONE')
    def test_store_cli_end_to_end(self):
        with tempfile.TemporaryDirectory() as td:
            cli=Path(__file__).resolve().parents[1]/'receipt_id_sidecar_store_cli.py'
            def run(*args):
                r=subprocess.run([sys.executable,str(cli),*map(str,args)],capture_output=True,text=True,check=True); return json.loads(r.stdout)
            run('init',td,'a','--max-journal-records','2','--max-journal-bytes','999999','--anchor-window','2')
            run('append',td,'b'); a=run('append',td,'c'); self.assertEqual(a['status'],'SIDECAR_STORE_APPENDED_AND_COMPACTED')
            v=run('verify',td,'--audit-archives'); self.assertEqual(v['generation'],1); self.assertEqual(v['receipt_id_count'],3)

if __name__=='__main__': unittest.main()
