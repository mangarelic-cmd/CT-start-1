import unittest
from fractions import Fraction
from itertools import permutations, product

from hypertriangle_solver_aux import (
    robust_b4_state, certify_wall_event, certify_b4_route, certify_receipt_bundle,
    handle_request
)

C={"common_scale_certified":True,"axis_independence_certified":True,"b4_comparable":True}

class TestSolverAuxPass002(unittest.TestCase):
    def test_robust_b4_positive(self):
        r=robust_b4_state({"axis_ids":["a","b","c","d"],"values":[8,-6,4,-2],"component_errors":["1/10"]*4,"contracts":C})
        self.assertEqual(r["status"],"ROBUST_B4_CHAMBER_CERTIFIED")
        self.assertTrue(r["certified_same_B4_chamber"])
        self.assertEqual(r["chamber_id"],"B4:+-+-:a>b>c>d")

    def test_robust_b4_reject_near_sign_wall(self):
        r=robust_b4_state({"values":[1,2,3,4],"component_errors":[2,0,0,0],"contracts":C})
        self.assertFalse(r["certified_same_B4_chamber"])

    def test_robust_b4_reject_near_dominance_wall(self):
        r=robust_b4_state({"values":[4,"39/10",2,1],"component_errors":["1/10"]*4,"contracts":C})
        self.assertFalse(r["certified_same_B4_chamber"])

    def test_unique_event_positive(self):
        p={"wall_id":"s0","alpha":[1,0,0,0],
           "left":{"time":0,"values":[-2,7,4,1]},
           "right":{"time":2,"values":[2,7,4,1]},
           "uniform_component_errors":["1/10"]*4,
           "derivative_direction":1,"derivative_magnitude_lower":1,"derivative_error":"1/10",
           "nominal_time":1,
           "contracts":{"uniform_error_over_bracket_certified":True}}
        r=certify_wall_event(p)
        self.assertTrue(r["certified_unique_crossing"])
        self.assertEqual(r["root_time_shift_bound"],Fraction(1,9))

    def test_event_requires_uniform_contract(self):
        p={"alpha":[1,0,0,0],"left":{"time":0,"values":[-2,1,1,1]},"right":{"time":2,"values":[2,1,1,1]},
           "uniform_component_errors":[0,0,0,0],"derivative_direction":1,"derivative_magnitude_lower":1,"derivative_error":0}
        r=certify_wall_event(p)
        self.assertEqual(r["status"],"UNRESOLVED_UNIFORM_ERROR_CONTRACT")

    def test_route_order(self):
        def ev(w,t,axis=0):
            left=[8,6,4,2]; right=[8,6,4,2]
            left[axis]=-2; right[axis]=2
            a=[0,0,0,0]; a[axis]=1
            return {"wall_id":w,"alpha":a,
                    "left":{"time":t-1,"values":left},"right":{"time":t+1,"values":right},
                    "uniform_component_errors":["1/100"]*4,
                    "derivative_direction":1,"derivative_magnitude_lower":1,"derivative_error":"1/100",
                    "nominal_time":t,"contracts":{"uniform_error_over_bracket_certified":True}}
        r=certify_b4_route({"events":[ev("s0",2,0),ev("s1",5,1)]})
        self.assertTrue(r["certified"])
        self.assertEqual(r["wall_sequence"],("s0","s1"))

    def test_route_overlap_rejected(self):
        base={"alpha":[1,0,0,0],"left":{"time":0,"values":[-2,6,4,2]},"right":{"time":2,"values":[2,6,4,2]},
              "uniform_component_errors":[1,0,0,0],"derivative_direction":1,"derivative_magnitude_lower":2,"derivative_error":1,
              "contracts":{"uniform_error_over_bracket_certified":True}}
        a=dict(base); a.update({"wall_id":"a","nominal_time":1})
        b=dict(base); b["left"]={"time":1,"values":[-2,6,4,2]}; b["right"]={"time":3,"values":[2,6,4,2]}; b.update({"wall_id":"b","nominal_time":2})
        r=certify_b4_route({"events":[a,b]})
        self.assertFalse(r["certified"])

    def test_receipt_bundle(self):
        state={"values":[8,6,4,2],"component_errors":["1/100"]*4,"contracts":C}
        ev={"wall_id":"x","alpha":[1,0,0,0],"left":{"time":0,"values":[-2,6,4,2]},"right":{"time":2,"values":[2,6,4,2]},
            "uniform_component_errors":["1/100"]*4,"derivative_direction":1,"derivative_magnitude_lower":1,"derivative_error":"1/100",
            "nominal_time":1,"contracts":{"uniform_error_over_bracket_certified":True}}
        r=certify_receipt_bundle({"states":[state],"route":{"events":[ev]}})
        self.assertTrue(r["terminal"])
        self.assertEqual(r["truth_credit"],0)

    def test_provider_authority_unchanged(self):
        r=handle_request({"mode":"robust_b4_state","payload":{"values":[8,6,4,2],"component_errors":[0,0,0,0],"contracts":C}})
        self.assertEqual(r["truth_credit"],0)
        self.assertEqual(r["solver_mutation_capability"],"NONE")

    def test_all_384_robust_chambers(self):
        seen=set()
        for signs in product((-1,1),repeat=4):
            for perm in permutations(range(4)):
                vals=[None]*4
                for rank,i in enumerate(perm): vals[i]=signs[i]*(8-2*rank)
                r=robust_b4_state({"axis_ids":["a","b","c","d"],"values":vals,
                                   "component_errors":["1/10"]*4,"contracts":C})
                self.assertTrue(r["certified_same_B4_chamber"])
                seen.add(r["chamber_id"])
        self.assertEqual(len(seen),384)

if __name__=='__main__': unittest.main()
