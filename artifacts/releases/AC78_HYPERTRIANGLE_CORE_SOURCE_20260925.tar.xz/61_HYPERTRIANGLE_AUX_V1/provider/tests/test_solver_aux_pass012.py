import copy, unittest
import hypertriangle_solver_aux as h


def activated(capability='route_simplex', slots=('F001',)):
    cat={x['slot']:x for x in h.memory_144_catalog({})['slots']}
    s=h.memory_144_init({})['state']
    sig=[{'operator':cat[x]['operator'],'certified':True,'projection':f'proof-{x}'} for x in slots]
    s=h.memory_144_drop({'state':s,'datum_id':'P12','signals':sig})['state']
    c={'contract_id':'P12-C','capability':capability,'requires_all':list(slots)}
    a=h.memory_144_activate({'state':s,'contracts':[c]})['receipt']
    return s,a


def route_payload():
    return {
        'trace_id':'P12-route',
        'contracts':{'additive':True,'common_ledger':True,'positivity_certified':True,'grounded':True},
        'cells':[{'occurrence_id':'a','weight':2},{'occurrence_id':'b','weight':3},{'occurrence_id':'c','weight':5}],
    }


class TestPass012ActivationCapabilityBridge(unittest.TestCase):
    def test_version(self):
        self.assertGreaterEqual(tuple(map(int,h.AUX_VERSION.split('.'))),(0,12,0))

    def test_compile_typed_request(self):
        s,a=activated()
        r=h.memory_144_compile_capability_request({'state':s,'activation_receipt':a,'capability':'route_simplex','capability_payload':route_payload()})
        self.assertTrue(r['request_valid'])
        q=r['request']
        self.assertEqual(q['target_capability'],'route_simplex')
        self.assertEqual(q['source_activation_state_hash'],a['activation_state_hash'])
        self.assertEqual(q['causal_generation'],1)
        self.assertEqual(q['memory_feedback_policy'],'FORBIDDEN_NO_AUTOMATIC_MEMORY_DROP_OR_REACTIVATION')

    def test_request_validator_structural_and_full_binding(self):
        s,a=activated()
        q=h.memory_144_compile_capability_request({'state':s,'activation_receipt':a,'capability':'route_simplex','capability_payload':route_payload()})['request']
        self.assertTrue(h.validate_memory_144_capability_request({'request':q})['request_valid'])
        self.assertTrue(h.validate_memory_144_capability_request({'request':q,'activation_receipt':a,'state':s})['request_valid'])

    def test_inactive_target_rejected(self):
        s,a=activated('route_simplex')
        r=h.memory_144_compile_capability_request({'state':s,'activation_receipt':a,'capability':'signed_polarity','capability_payload':{'values':[1,-1]}})
        self.assertFalse(r['request_valid']); self.assertIn('not active',r['error'])

    def test_memory_mode_target_rejected(self):
        s,a=activated('route_simplex')
        bad=copy.deepcopy(a); bad['active_capabilities']=('memory_144_drop',)
        r=h.memory_144_compile_capability_request({'activation_receipt':bad,'capability':'memory_144_drop','capability_payload':{}})
        self.assertFalse(r['request_valid'])

    def test_payload_must_be_explicit_object(self):
        s,a=activated()
        r=h.memory_144_compile_capability_request({'state':s,'activation_receipt':a,'capability':'route_simplex','capability_payload':None})
        self.assertFalse(r['request_valid']); self.assertIn('explicit object',r['error'])

    def test_request_tamper_rejected(self):
        s,a=activated()
        q=h.memory_144_compile_capability_request({'state':s,'activation_receipt':a,'capability':'route_simplex','capability_payload':route_payload()})['request']
        bad=copy.deepcopy(q); bad['capability_payload']['cells'][0]['weight']=999
        self.assertFalse(h.validate_memory_144_capability_request({'request':bad})['request_valid'])

    def test_execution_matches_direct_capability(self):
        s,a=activated()
        q=h.memory_144_compile_capability_request({'state':s,'activation_receipt':a,'capability':'route_simplex','capability_payload':route_payload()})['request']
        x=h.memory_144_execute_capability({'request':q,'activation_receipt':a,'state':s})
        self.assertTrue(x['execution_valid'])
        self.assertEqual(x['receipt']['capability_receipt'],h.encode(h.compile_route(route_payload())))
        self.assertEqual(x['receipt']['target_capability'],'route_simplex')

    def test_execution_validator_structural_and_replay(self):
        s,a=activated()
        q=h.memory_144_compile_capability_request({'state':s,'activation_receipt':a,'capability':'route_simplex','capability_payload':route_payload()})['request']
        x=h.memory_144_execute_capability({'request':q,'activation_receipt':a,'state':s})['receipt']
        self.assertTrue(h.validate_memory_144_capability_execution({'receipt':x})['execution_valid'])
        self.assertTrue(h.validate_memory_144_capability_execution({'receipt':x,'request':q,'activation_receipt':a,'state':s})['execution_valid'])

    def test_execution_receipt_tamper_rejected(self):
        s,a=activated()
        q=h.memory_144_compile_capability_request({'state':s,'activation_receipt':a,'capability':'route_simplex','capability_payload':route_payload()})['request']
        x=h.memory_144_execute_capability({'request':q})['receipt']
        bad=copy.deepcopy(x); bad['capability_receipt']['status']='FORGED'
        self.assertFalse(h.validate_memory_144_capability_execution({'receipt':bad})['execution_valid'])

    def test_request_mismatch_rejected_by_execution(self):
        s,a=activated()
        q=h.memory_144_compile_capability_request({'state':s,'activation_receipt':a,'capability':'route_simplex','capability_payload':route_payload()})['request']
        bad=copy.deepcopy(q); bad['typed_request_hash']='0'*64
        self.assertFalse(h.memory_144_execute_capability({'request':bad})['execution_valid'])

    def test_feedback_is_explicitly_absent(self):
        s,a=activated()
        q=h.memory_144_compile_capability_request({'state':s,'activation_receipt':a,'capability':'route_simplex','capability_payload':route_payload()})['request']
        x=h.memory_144_execute_capability({'request':q})['receipt']
        self.assertFalse(x['memory_feedback_performed'])
        self.assertFalse(x['activation_reentry_performed'])
        self.assertEqual(x['causal_generation'],2)
        self.assertEqual(x['solver_mutation_capability'],'NONE')

    def test_bridge_composition(self):
        s,a=activated()
        b=h.memory_144_activation_to_capability({'state':s,'activation_receipt':a,'capability':'route_simplex','capability_payload':route_payload()})
        self.assertTrue(b['bridge_valid'])
        self.assertEqual(b['execution_receipt']['typed_request_hash'],b['request']['typed_request_hash'])
        self.assertFalse(b['memory_feedback_performed'])

    def test_deterministic_request_and_execution_hashes(self):
        s,a=activated()
        p={'state':s,'activation_receipt':a,'capability':'route_simplex','capability_payload':route_payload()}
        b1=h.memory_144_activation_to_capability(p); b2=h.memory_144_activation_to_capability(copy.deepcopy(p))
        self.assertEqual(b1['request']['typed_request_hash'],b2['request']['typed_request_hash'])
        self.assertEqual(b1['execution_receipt']['capability_execution_hash'],b2['execution_receipt']['capability_execution_hash'])

    def test_second_local_capability_signed_polarity(self):
        s,a=activated('signed_polarity',('F003',))
        b=h.memory_144_activation_to_capability({'state':s,'activation_receipt':a,'capability':'signed_polarity','capability_payload':{'values':[3,-2,0]}})
        self.assertTrue(b['bridge_valid'])
        self.assertEqual(b['execution_receipt']['capability_receipt'],h.encode(h.signed_polarity([3,-2,0])))

    def test_wrong_contract_id_rejected(self):
        s,a=activated()
        r=h.memory_144_compile_capability_request({'state':s,'activation_receipt':a,'contract_id':'OTHER','capability':'route_simplex','capability_payload':route_payload()})
        self.assertFalse(r['request_valid'])

    def test_activation_tamper_stops_bridge(self):
        s,a=activated()
        bad=copy.deepcopy(a); bad['activation_state_hash']='f'*64
        b=h.memory_144_activation_to_capability({'state':s,'activation_receipt':bad,'capability':'route_simplex','capability_payload':route_payload()})
        self.assertFalse(b.get('request_valid',False))

    def test_provider_modes(self):
        caps=h.capabilities()['capabilities']
        modes=('memory_144_compile_capability_request','memory_144_validate_capability_request','memory_144_execute_capability','memory_144_validate_capability_execution','memory_144_activation_to_capability')
        for m in modes: self.assertIn(m,caps)
        env=h.handle_request({'mode':'memory_144_activation_to_capability','payload':{}})
        self.assertGreaterEqual(tuple(map(int,env['version'].split('.'))),(0,12,0)); self.assertEqual(env['solver_mutation_capability'],'NONE')

if __name__=='__main__': unittest.main()
