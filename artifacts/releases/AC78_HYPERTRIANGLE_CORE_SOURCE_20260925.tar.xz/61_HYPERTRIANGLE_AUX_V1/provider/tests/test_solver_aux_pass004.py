import copy, json, unittest
from hypertriangle_solver_aux import (
    create_stream_checkpoint, resume_stream_checkpoint, certify_receipt_stream,
    validate_stream_checkpoint, handle_request, encode
)

C={"common_scale_certified":True,"axis_independence_certified":True,"b4_comparable":True}

def state(vals,err="1/100"):
    return {"values":vals,"component_errors":[err]*4,"contracts":C}

def event(w,t,axis,err="1/100"):
    base=[8,6,4,2]; left=base[:]; right=base[:]
    left[axis]=-2; right[axis]=2
    a=[0,0,0,0]; a[axis]=1
    return {"wall_id":w,"alpha":a,"left":{"time":t-1,"values":left},"right":{"time":t+1,"values":right},
            "uniform_component_errors":[err]*4,"derivative_direction":1,"derivative_magnitude_lower":1,
            "derivative_error":err,"nominal_time":t,"contracts":{"uniform_error_over_bracket_certified":True}}

def stream4():
    return {"stream_id":"s-demo","requirements":{"required_state_slots":["S0","S1"],"required_event_slots":["E0","E1"],"required_wall_sequence":["w0","w1"]},"receipts":[
        {"receipt_id":"r1","sequence":1,"slot":"S0","kind":"state","payload":state([8,6,4,2])},
        {"receipt_id":"r2","sequence":2,"slot":"E0","kind":"event","payload":event("w0",2,0)},
        {"receipt_id":"r3","sequence":3,"slot":"S1","kind":"state","payload":state([7,-5,3,1])},
        {"receipt_id":"r4","sequence":4,"slot":"E1","kind":"event","payload":event("w1",5,1)},
    ]}

def bad5():
    return {"receipt_id":"r5","sequence":5,"slot":"S1","kind":"state","payload":{"values":[1,2,3,4],"component_errors":[2,0,0,0],"contracts":C}}

def good5():
    return {"receipt_id":"r5","sequence":5,"slot":"S1","kind":"state","payload":state([9,-7,5,3])}

class TestSolverAuxPass004(unittest.TestCase):
    def test_checkpoint_terminal_prefix(self):
        c=create_stream_checkpoint({"stream":stream4()})
        self.assertTrue(c["checkpoint_valid"])
        cp=c["checkpoint"]
        self.assertEqual(cp["prefix_length"],4)
        self.assertEqual(cp["first_terminal_prefix"],4)
        self.assertTrue(cp["historical_terminal"])
        self.assertTrue(validate_stream_checkpoint(cp)["checkpoint_valid"])

    def test_resume_good_equivalent_to_full(self):
        s=stream4(); cp=create_stream_checkpoint({"stream":s})["checkpoint"]
        resumed=resume_stream_checkpoint({"checkpoint":cp,"receipts":[good5()]})
        full=copy.deepcopy(s); full["receipts"].append(good5())
        replay=certify_receipt_stream(full)
        for k in ("final_stream_hash","first_terminal_prefix","first_terminal_stream_hash","current_terminal","historical_terminal","stop_policy"):
            self.assertEqual(resumed[k],replay[k],k)

    def test_resume_bad_equivalent_main_semantics(self):
        s=stream4(); cp=create_stream_checkpoint({"stream":s})["checkpoint"]
        resumed=resume_stream_checkpoint({"checkpoint":cp,"receipts":[bad5()]})
        full=copy.deepcopy(s); full["receipts"].append(bad5())
        replay=certify_receipt_stream(full)
        self.assertEqual(resumed["final_stream_hash"],replay["final_stream_hash"])
        self.assertEqual(resumed["first_terminal_prefix"],4)
        self.assertFalse(resumed["current_terminal"])
        self.assertTrue(resumed["post_terminal_semantic_conflict"])
        self.assertTrue(resumed["ever_post_terminal_semantic_conflict"])
        self.assertTrue(resumed["post_terminal_regression_seen"])

    def test_checkpoint_after_conflict_preserves_history_even_if_later_repaired(self):
        s=stream4(); s["receipts"].append(bad5())
        c=create_stream_checkpoint({"stream":s})
        cp=c["checkpoint"]
        self.assertTrue(cp["post_terminal_regression_seen"])
        self.assertTrue(cp["post_terminal_semantic_conflict_seen"])
        r6={"receipt_id":"r6","sequence":6,"slot":"S1","kind":"state","payload":state([9,-7,5,3])}
        r=resume_stream_checkpoint({"checkpoint":cp,"receipts":[r6]})
        self.assertTrue(r["current_terminal"])
        self.assertFalse(r["post_terminal_semantic_conflict"])
        self.assertTrue(r["ever_post_terminal_semantic_conflict"])
        self.assertTrue(r["post_terminal_regression_seen"])
        self.assertEqual(r["first_terminal_prefix"],4)

    def test_tamper_checkpoint_rejected(self):
        cp=create_stream_checkpoint({"stream":stream4()})["checkpoint"]
        cp=copy.deepcopy(cp); cp["prefix_length"]=3
        v=validate_stream_checkpoint(cp)
        self.assertFalse(v["checkpoint_valid"])
        self.assertEqual(v["status"],"CHECKPOINT_HASH_MISMATCH")

    def test_duplicate_historic_receipt_id_rejected(self):
        cp=create_stream_checkpoint({"stream":stream4()})["checkpoint"]
        e=good5(); e["receipt_id"]="r2"
        r=resume_stream_checkpoint({"checkpoint":cp,"receipts":[e]})
        self.assertEqual(r["status"],"DUPLICATE_STREAM_RECEIPT_ID")

    def test_wrong_resume_sequence_rejected(self):
        cp=create_stream_checkpoint({"stream":stream4()})["checkpoint"]
        e=good5(); e["sequence"]=99
        r=resume_stream_checkpoint({"checkpoint":cp,"receipts":[e]})
        self.assertEqual(r["status"],"INVALID_STREAM_SEQUENCE")

    def test_nonterminal_checkpoint_can_close_later(self):
        s=stream4(); s["receipts"]=s["receipts"][:3]
        cp=create_stream_checkpoint({"stream":s})["checkpoint"]
        self.assertFalse(cp["historical_terminal"])
        e=stream4()["receipts"][3]
        r=resume_stream_checkpoint({"checkpoint":cp,"receipts":[e]})
        self.assertTrue(r["historical_terminal"])
        self.assertTrue(r["current_terminal"])
        self.assertEqual(r["first_terminal_prefix"],4)

    def test_checkpoint_deterministic(self):
        a=create_stream_checkpoint({"stream":stream4()})["checkpoint"]
        b=create_stream_checkpoint({"stream":copy.deepcopy(stream4())})["checkpoint"]
        self.assertEqual(a["checkpoint_hash"],b["checkpoint_hash"])

    def test_checkpoint_prefix_option(self):
        s=stream4(); s["receipts"].append(good5())
        c=create_stream_checkpoint({"stream":s,"checkpoint_prefix":4})
        self.assertEqual(c["checkpoint"]["prefix_length"],4)
        self.assertEqual(c["checkpoint"]["seen_receipt_ids"],("r1","r2","r3","r4"))

    def test_long_stream_compacts_payloads(self):
        s=stream4()
        for i in range(5,205):
            s["receipts"].append({"receipt_id":f"r{i}","sequence":i,"slot":"J","kind":"state","payload":state([100+i,60,40,20])})
        c=create_stream_checkpoint({"stream":s})
        self.assertGreater(c["canonical_byte_reduction"],0)
        self.assertLess(float(c["canonical_compaction_ratio"]),0.35)

    def test_provider_envelope(self):
        c=handle_request({"mode":"stream_checkpoint","payload":{"stream":stream4()}})
        self.assertEqual(c["truth_credit"],0)
        self.assertEqual(c["root_write_capability"],"NONE")
        cp=c["receipt"]["checkpoint"]
        r=handle_request({"mode":"resume_stream_checkpoint","payload":{"checkpoint":cp,"receipts":[good5()]}})
        self.assertEqual(r["return_write_capability"],"NONE")
        self.assertEqual(r["receipt"]["first_terminal_prefix"],4)

if __name__=='__main__': unittest.main()
