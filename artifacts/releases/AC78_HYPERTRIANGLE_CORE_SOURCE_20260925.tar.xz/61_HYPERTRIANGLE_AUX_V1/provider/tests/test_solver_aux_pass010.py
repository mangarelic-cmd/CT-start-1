import copy, unittest
import hypertriangle_solver_aux as h

class TestSolverAuxPass010(unittest.TestCase):
    def test_catalog_has_144_unique_slots_and_operators(self):
        c=h.memory_144_catalog({})
        self.assertEqual(c['slot_count'],144); self.assertEqual(c['trace_start'],1)
        self.assertEqual(len({x['slot'] for x in c['slots']}),144)
        self.assertEqual(len({x['operator'] for x in c['slots']}),144)
        self.assertEqual(c['slots'][0]['slot'],'F001'); self.assertEqual(c['slots'][-1]['slot'],'F144')
    def test_init_starts_trace_at_one(self):
        s=h.memory_144_init({})['state']
        self.assertEqual(s['trace_start'],1); self.assertEqual(s['next_trace'],1); self.assertEqual(s['event_count'],0)
        self.assertEqual(s['flag_mask_hex'],'0'*36)
        self.assertTrue(h.validate_memory_144_state(s)['memory_valid'])
    def test_data_drops_on_operator_to_slot(self):
        s=h.memory_144_init({})['state']
        r=h.memory_144_drop({'state':s,'datum_id':'d1','signals':[{'operator':'DIRECTED_ONSET','certified':True,'projection':'x'}]})
        self.assertTrue(r['memory_valid']); self.assertEqual(r['trace_index'],1); self.assertEqual(r['flagged_slots'],('F003',))
        self.assertTrue(r['state']['flags'][2]); self.assertEqual(r['state']['last_invariants_saved'][2]['projection'],'x')
    def test_category_does_not_pull_untyped_data(self):
        s=h.memory_144_init({})['state']
        r=h.memory_144_drop({'state':s,'datum_id':'raw','data':{'foo':'bar'}})
        self.assertFalse(r['memory_valid']); self.assertIn('no invariant signature',r['error'])
    def test_forced_wrong_slot_rejected(self):
        s=h.memory_144_init({})['state']
        r=h.memory_144_drop({'state':s,'signals':[{'operator':'IDENTITY_SEED','slot':'F003','certified':True}]})
        self.assertFalse(r['memory_valid']); self.assertIn('disagrees',r['error'])
    def test_multiple_invariants_flag_multiple_slots(self):
        s=h.memory_144_init({})['state']
        r=h.memory_144_drop({'state':s,'signals':[{'operator':'IDENTITY_SEED','certified':True},{'operator':'UNITY_TRANSCENDENCE','certified':True}]})
        self.assertEqual(r['flagged_slots'],('F001','F144')); self.assertTrue(r['state']['flags'][0]); self.assertTrue(r['state']['flags'][143])
    def test_trace_indices_are_one_based_and_contiguous(self):
        out=h.memory_144_trace({'events':[{'datum_id':'a','signals':[{'operator':'IDENTITY_SEED','certified':True}]},{'datum_id':'b','signals':[{'operator':'SATURATED_FIXPOINT','certified':True}]}]})
        self.assertTrue(out['memory_valid']); self.assertEqual([r['trace_index'] for r in out['receipts']],[1,2]); self.assertEqual(out['next_trace'],3)
        bad=h.memory_144_drop({'state':out['state'],'trace_index':4,'signals':[{'operator':'DIRECTED_ONSET','certified':True}]})
        self.assertFalse(bad['memory_valid'])
    def test_uncertified_flag_does_not_replace_saved_last_invariant(self):
        s=h.memory_144_init({})['state']
        a=h.memory_144_drop({'state':s,'signals':[{'operator':'IDENTITY_SEED','certified':True,'projection':'cert'}]})['state']
        b=h.memory_144_drop({'state':a,'signals':[{'operator':'IDENTITY_SEED','certified':False,'projection':'candidate'}]})['state']
        self.assertEqual(b['hit_counts'][0],2); self.assertEqual(b['last_invariants_saved'][0]['projection'],'cert')
    def test_later_certified_projection_becomes_last_saved(self):
        s=h.memory_144_init({})['state']
        a=h.memory_144_drop({'state':s,'signals':[{'operator':'IDENTITY_SEED','certified':True,'projection':'p1'}]})['state']
        b=h.memory_144_drop({'state':a,'signals':[{'operator':'IDENTITY_SEED','certified':True,'projection':'p2'}]})['state']
        self.assertEqual(b['last_invariants_saved'][0]['projection'],'p2'); self.assertEqual(b['last_invariants_saved'][0]['trace_index'],2)
    def test_context_never_rewrites_canonical_slot(self):
        s=h.memory_144_init({})['state']
        b=h.memory_144_drop({'state':s,'signals':[{'operator':'IDENTITY_SEED','certified':True,'context':{'name':'other'},'projection':'manifest'}]})['state']
        rec=h.memory_144_reconstruct({'state':b})['active_last_invariants'][0]
        self.assertEqual(rec['slot'],'F001'); self.assertEqual(rec['operator'],'IDENTITY_SEED'); self.assertEqual(rec['canonical_function'],'Identity seed')
    def test_raw_payload_not_stored(self):
        s=h.memory_144_init({})['state']
        r=h.memory_144_drop({'state':s,'data':{'secret':'large'},'signals':[{'operator':'IDENTITY_SEED','certified':True}]})
        self.assertFalse(r['raw_payload_retained']); self.assertNotIn('data',str(r['state']))
    def test_reconstruction_is_last_invariants_not_raw_history_claim(self):
        s=h.memory_144_init({})['state']
        s=h.memory_144_drop({'state':s,'signals':[{'operator':'DEFICIT_MEDIATION','certified':True,'residual':'r','reconstruction_ref':'model://x'}]})['state']
        r=h.memory_144_reconstruct({'state':s})
        self.assertTrue(r['reconstruction_valid']); self.assertEqual(r['raw_history_replay_claim'],'NOT_CLAIMED_WITHOUT_EXTERNAL_RECONSTRUCTION_CONTRACT')
        self.assertEqual(r['active_last_invariants'][0]['last_invariant']['residual'],'r')
    def test_state_tamper_rejected(self):
        s=h.memory_144_init({})['state']; bad=copy.deepcopy(s); bad['next_trace']=9
        self.assertFalse(h.validate_memory_144_state(bad)['memory_valid'])
    def test_duplicate_same_slot_in_one_datum_rejected(self):
        s=h.memory_144_init({})['state']
        r=h.memory_144_drop({'state':s,'signals':[{'operator':'IDENTITY_SEED','certified':True},{'operator':'IDENTITY_SEED','certified':True}]})
        self.assertFalse(r['memory_valid'])
    def test_provider_modes_and_firewall(self):
        caps=h.capabilities()['capabilities']
        for m in ('memory_144_catalog','memory_144_init','memory_144_drop','memory_144_trace','memory_144_validate','memory_144_reconstruct'):
            self.assertIn(m,caps)
        env=h.handle_request({'mode':'memory_144_init','payload':{}})
        self.assertEqual(env['truth_credit'],0); self.assertEqual(env['solver_mutation_capability'],'NONE')

if __name__=='__main__': unittest.main()
