import copy, unittest
import hypertriangle_solver_aux as h


def state_with(signals):
    s=h.memory_144_init({})['state']
    r=h.memory_144_drop({'state':s,'datum_id':'d','signals':signals})
    assert r['memory_valid']
    return r['state']


class TestSolverAuxPass011(unittest.TestCase):
    def test_activation_catalog_is_zero_authority(self):
        c=h.memory_144_activation_catalog({})
        self.assertEqual(c['direction'],'DATA_TO_INVARIANT_SLOT_TO_ACTIVATION')
        self.assertFalse(c['contract_semantics']['execution']=='PERFORMED')
        self.assertEqual(c['truth_credit'],0)
        self.assertIn('route_simplex',c['activatable_capabilities'])

    def test_no_contract_never_infers_mapping(self):
        s=state_with([{'operator':'IDENTITY_SEED','certified':True}])
        r=h.memory_144_activate({'state':s})
        self.assertTrue(r['activation_valid'])
        self.assertEqual(r['status'],'MEMORY_144_ACTIVATION_NO_DECLARED_CONTRACTS')
        self.assertEqual(r['active_capabilities'],())
        self.assertEqual(r['receipt']['mapping_policy'],'DECLARED_CONTRACTS_ONLY_NO_INFERRED_SLOT_TO_CAPABILITY_MAPPING')

    def test_requires_all_activates(self):
        s=state_with([{'operator':'IDENTITY_SEED','certified':True},{'operator':'DIRECTED_ONSET','certified':True}])
        c={'contract_id':'c1','capability':'route_simplex','requires_all':['F001','F003']}
        r=h.memory_144_activate({'state':s,'contracts':[c]})
        self.assertEqual(r['active_capabilities'],('route_simplex',))
        self.assertEqual(r['receipt']['evaluations'][0]['activation_state'],'ACTIVE')

    def test_requires_all_missing_is_inactive(self):
        s=state_with([{'operator':'IDENTITY_SEED','certified':True}])
        c={'contract_id':'c1','capability':'route_simplex','requires_all':['F001','F003']}
        r=h.memory_144_activate({'state':s,'contracts':[c]})
        e=r['receipt']['evaluations'][0]
        self.assertFalse(e['active']); self.assertEqual(e['missing_all'],('F003',))

    def test_requires_any(self):
        s=state_with([{'operator':'DIRECTED_ONSET','certified':True}])
        c={'contract_id':'c','capability':'signed_polarity','requires_any':['F001','F003']}
        r=h.memory_144_activate({'state':s,'contracts':[c]})
        self.assertEqual(r['active_capabilities'],('signed_polarity',))
        self.assertEqual(r['receipt']['evaluations'][0]['matched_any'],('F003',))

    def test_requires_any_missing(self):
        s=state_with([{'operator':'DEFICIT_MEDIATION','certified':True}])
        c={'contract_id':'c','capability':'signed_polarity','requires_any':['F001','F003']}
        r=h.memory_144_activate({'state':s,'contracts':[c]})
        self.assertEqual(r['receipt']['evaluations'][0]['activation_state'],'INACTIVE_MISSING_ANY')

    def test_forbidden_slot_blocks(self):
        s=state_with([{'operator':'IDENTITY_SEED','certified':True},{'operator':'NON_TENABLE','certified':True}])
        c={'contract_id':'c','capability':'b4_state','requires_all':['F001'],'forbids':['F087']}
        r=h.memory_144_activate({'state':s,'contracts':[c]})
        e=r['receipt']['evaluations'][0]
        self.assertFalse(e['active']); self.assertEqual(e['activation_state'],'BLOCKED_FORBIDDEN'); self.assertEqual(e['forbidden_present'],('F087',))

    def test_uncertified_observation_never_activates(self):
        s=state_with([{'operator':'IDENTITY_SEED','certified':False}])
        c={'contract_id':'c','capability':'route_simplex','requires_all':['F001']}
        r=h.memory_144_activate({'state':s,'contracts':[c]})
        self.assertEqual(r['active_capabilities'],())
        self.assertEqual(r['receipt']['certified_slots'],())

    def test_later_certified_survivor_activates(self):
        s=h.memory_144_init({})['state']
        s=h.memory_144_drop({'state':s,'signals':[{'operator':'IDENTITY_SEED','certified':False}]})['state']
        s=h.memory_144_drop({'state':s,'signals':[{'operator':'IDENTITY_SEED','certified':True,'projection':'survivor'}]})['state']
        c={'contract_id':'c','capability':'route_simplex','requires_all':['F001']}
        r=h.memory_144_activate({'state':s,'contracts':[c]})
        self.assertEqual(r['active_capabilities'],('route_simplex',))
        self.assertEqual(r['receipt']['evaluations'][0]['supporting_last_invariants'][0]['trace_index'],2)

    def test_contract_order_is_canonical(self):
        s=state_with([{'operator':'IDENTITY_SEED','certified':True},{'operator':'DIRECTED_ONSET','certified':True}])
        a={'contract_id':'z','capability':'signed_polarity','requires_all':['F003']}
        b={'contract_id':'a','capability':'route_simplex','requires_all':['F001']}
        r1=h.memory_144_activate({'state':s,'contracts':[a,b]})
        r2=h.memory_144_activate({'state':s,'contracts':[b,a]})
        self.assertEqual(r1['receipt']['activation_state_hash'],r2['receipt']['activation_state_hash'])
        self.assertEqual([x['contract_id'] for x in r1['receipt']['contracts']],['a','z'])

    def test_unknown_slot_rejected(self):
        s=state_with([{'operator':'IDENTITY_SEED','certified':True}])
        r=h.memory_144_activate({'state':s,'contracts':[{'contract_id':'c','capability':'route_simplex','requires_all':['F145']}]})
        self.assertFalse(r['activation_valid']); self.assertIn('unknown canonical slot',r['error'])

    def test_unknown_target_rejected(self):
        s=state_with([{'operator':'IDENTITY_SEED','certified':True}])
        r=h.memory_144_activate({'state':s,'contracts':[{'contract_id':'c','capability':'AC77_ROOT_WRITE','requires_all':['F001']}]})
        self.assertFalse(r['activation_valid']); self.assertIn('not an allowed',r['error'])

    def test_empty_positive_contract_rejected(self):
        s=state_with([{'operator':'IDENTITY_SEED','certified':True}])
        r=h.memory_144_activate({'state':s,'contracts':[{'contract_id':'c','capability':'route_simplex','forbids':['F087']}]})
        self.assertFalse(r['activation_valid']); self.assertIn('positive',r['error'])

    def test_require_forbid_overlap_rejected(self):
        s=state_with([{'operator':'IDENTITY_SEED','certified':True}])
        r=h.memory_144_activate({'state':s,'contracts':[{'contract_id':'c','capability':'route_simplex','requires_all':['F001'],'forbids':['F001']}]})
        self.assertFalse(r['activation_valid']); self.assertIn('both require and forbid',r['error'])

    def test_duplicate_capability_contract_rejected(self):
        s=state_with([{'operator':'IDENTITY_SEED','certified':True}])
        cs=[{'contract_id':'a','capability':'route_simplex','requires_all':['F001']},{'contract_id':'b','capability':'route_simplex','requires_all':['F001']}]
        r=h.memory_144_activate({'state':s,'contracts':cs})
        self.assertFalse(r['activation_valid']); self.assertIn('duplicate activation target',r['error'])

    def test_activation_validator_structural_and_full_replay(self):
        s=state_with([{'operator':'IDENTITY_SEED','certified':True},{'operator':'DIRECTED_ONSET','certified':True}])
        c={'contract_id':'c','capability':'route_simplex','requires_all':['F001'],'requires_any':['F003']}
        a=h.memory_144_activate({'state':s,'contracts':[c]})['receipt']
        self.assertTrue(h.validate_memory_144_activation({'receipt':a})['activation_valid'])
        self.assertTrue(h.validate_memory_144_activation({'receipt':a,'state':s})['activation_valid'])

    def test_activation_tamper_rejected(self):
        s=state_with([{'operator':'IDENTITY_SEED','certified':True}])
        a=h.memory_144_activate({'state':s,'contracts':[{'contract_id':'c','capability':'route_simplex','requires_all':['F001']}]})['receipt']
        bad=copy.deepcopy(a); bad['active_capabilities']=()
        self.assertFalse(h.validate_memory_144_activation({'receipt':bad})['activation_valid'])

    def test_activation_never_executes_capability(self):
        s=state_with([{'operator':'IDENTITY_SEED','certified':True}])
        a=h.memory_144_activate({'state':s,'contracts':[{'contract_id':'c','capability':'route_simplex','requires_all':['F001']}]})['receipt']
        self.assertFalse(a['execution_performed'])
        self.assertEqual(a['solver_mutation_capability'],'NONE')
        self.assertEqual(a['truth_credit'],0)

    def test_provider_modes(self):
        caps=h.capabilities()['capabilities']
        for m in ('memory_144_activation_catalog','memory_144_activate','memory_144_validate_activation'):
            self.assertIn(m,caps)
        env=h.handle_request({'mode':'memory_144_activation_catalog','payload':{}})
        self.assertGreaterEqual(tuple(map(int,env['version'].split('.'))),(0,11,0)); self.assertEqual(env['solver_mutation_capability'],'NONE')

if __name__=='__main__': unittest.main()
