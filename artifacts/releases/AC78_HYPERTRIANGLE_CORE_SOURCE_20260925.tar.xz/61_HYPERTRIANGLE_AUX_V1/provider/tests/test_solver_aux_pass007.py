import copy, unittest
import hypertriangle_solver_aux as h

C={"common_scale_certified":True,"axis_independence_certified":True,"b4_comparable":True}
def state(vals,err="1/100"):
    return {"values":vals,"component_errors":[err]*4,"contracts":C}
def event(w,t,axis,err="1/100"):
    base=[8,6,4,2]; left=base[:]; right=base[:]; left[axis]=-2; right[axis]=2
    a=[0,0,0,0]; a[axis]=1
    return {"wall_id":w,"alpha":a,"left":{"time":t-1,"values":left},"right":{"time":t+1,"values":right},
            "uniform_component_errors":[err]*4,"derivative_direction":1,"derivative_magnitude_lower":1,
            "derivative_error":err,"nominal_time":t,"contracts":{"uniform_error_over_bracket_certified":True}}
def base_stream():
    return {"stream_id":"p7-demo","requirements":{"required_state_slots":["S0","S1"],"required_event_slots":["E0","E1"],"required_wall_sequence":["w0","w1"]},"receipts":[
        {"receipt_id":"r1","sequence":1,"slot":"S0","kind":"state","payload":state([8,6,4,2])},
        {"receipt_id":"r2","sequence":2,"slot":"E0","kind":"event","payload":event("w0",2,0)},
        {"receipt_id":"r3","sequence":3,"slot":"S1","kind":"state","payload":state([7,-5,3,1])},
        {"receipt_id":"r4","sequence":4,"slot":"E1","kind":"event","payload":event("w1",5,1)},
    ]}
def upd(seq,slot="J",vals=None,bad=False):
    if vals is None: vals=[100+seq,60,40,20]
    payload=state(vals)
    if bad: payload={"values":[1,2,3,4],"component_errors":[2,0,0,0],"contracts":C}
    return {"receipt_id":f"r{seq}","sequence":seq,"slot":slot,"kind":"state","payload":payload}

class TestSolverAuxPass007(unittest.TestCase):
    def setUp(self):
        s=base_stream(); cp0=h.create_stream_checkpoint({"stream":s})["checkpoint"]
        self.p6=h.rotate_bounded_checkpoint({"checkpoint":cp0,"receipts":[upd(5)],"anchor_window_size":4})["checkpoint"]
        self.assertTrue(h.validate_bounded_stream_checkpoint(self.p6)["checkpoint_valid"])
    def migrate(self):
        r=h.rotate_witnessed_checkpoint({"checkpoint":self.p6,"receipts":[upd(6)]})
        self.assertTrue(r["rotated"]); return r
    def test_no_go(self):
        r=h.exact_membership_bounded_no_go({"checkpoint_bits":256,"universe_size":257})
        self.assertEqual(r["status"],"EXACT_STANDALONE_BOUNDED_MEMBERSHIP_NO_GO"); self.assertTrue(r["pigeonhole_collision_for_distinct_seen_sets"])
    def test_sparse_membership_and_nonmembership(self):
        ids=["a","b","c"]; root=h.sparse_receipt_id_root(ids)
        pa=h.sparse_receipt_id_proof(ids,"a"); pz=h.sparse_receipt_id_proof(ids,"z")
        self.assertTrue(h.verify_sparse_receipt_id_proof(root,"a",pa,expected_present=True)["proof_valid"])
        self.assertTrue(h.verify_sparse_receipt_id_proof(root,"z",pz,expected_present=False)["proof_valid"])
        u=h.sparse_receipt_id_insert(root,"z",pz); self.assertTrue(u["updated"]); self.assertEqual(u["new_root"],h.sparse_receipt_id_root(ids+["z"]))
    def test_tampered_proof_rejected(self):
        idx=h.ExternalReceiptIdIndex(["a","b"]); p=idx.proof("z"); p=copy.deepcopy(p); p["siblings"]=list(p["siblings"]); p["siblings"][7]="0"*64
        self.assertFalse(h.verify_sparse_receipt_id_proof(idx.root,"z",p,expected_present=False)["proof_valid"])
    def test_migration_drops_seen_ids(self):
        r=self.migrate(); cp=r["checkpoint"]
        self.assertNotIn("seen_receipt_ids",cp); self.assertEqual(cp["receipt_id_count"],6); self.assertTrue(h.validate_witnessed_checkpoint(cp)["checkpoint_valid"])
        self.assertEqual(cp["receipt_id_root"],h.sparse_receipt_id_root([f"r{i}" for i in range(1,7)]))
    def test_migration_transition_audit(self):
        r=self.migrate(); v=h.validate_witnessed_checkpoint_transition({"previous_checkpoint":self.p6,"current_checkpoint":r["checkpoint"],"proof_packet":r["proof_packet"]})
        self.assertTrue(v["transition_valid"])
    def test_second_rotation_requires_witness(self):
        cp=self.migrate()["checkpoint"]
        r=h.rotate_witnessed_checkpoint({"checkpoint":cp,"receipts":[upd(7)]})
        self.assertEqual(r["status"],"RECEIPT_ID_NONMEMBERSHIP_WITNESSES_REQUIRED")
    def test_witnessed_rotation_exact_root(self):
        cp=self.migrate()["checkpoint"]; idx=h.ExternalReceiptIdIndex([f"r{i}" for i in range(1,7)])
        proof=idx.proof("r7")
        r=h.rotate_witnessed_checkpoint({"checkpoint":cp,"receipts":[upd(7)],"receipt_id_witnesses":[proof]})
        self.assertTrue(r["rotated"]); ins=idx.insert("r7"); self.assertTrue(ins["inserted"])
        self.assertEqual(r["checkpoint"]["receipt_id_root"],idx.root)
        v=h.validate_witnessed_checkpoint_transition({"previous_checkpoint":cp,"current_checkpoint":r["checkpoint"],"proof_packet":r["proof_packet"]})
        self.assertTrue(v["transition_valid"])
    def test_historic_duplicate_rejected(self):
        cp=self.migrate()["checkpoint"]; idx=h.ExternalReceiptIdIndex([f"r{i}" for i in range(1,7)])
        p=idx.proof("r2"); e=upd(7); e["receipt_id"]="r2"
        r=h.rotate_witnessed_checkpoint({"checkpoint":cp,"receipts":[e],"receipt_id_witnesses":[p]})
        self.assertEqual(r["status"],"RECEIPT_ID_NONMEMBERSHIP_PROOF_REJECTED")
    def test_stale_witness_rejected(self):
        cp=self.migrate()["checkpoint"]; idx=h.ExternalReceiptIdIndex([f"r{i}" for i in range(1,7)])
        stale=idx.proof("r8"); p7=idx.proof("r7")
        r7=h.rotate_witnessed_checkpoint({"checkpoint":cp,"receipts":[upd(7)],"receipt_id_witnesses":[p7]})["checkpoint"]; idx.insert("r7")
        r=h.rotate_witnessed_checkpoint({"checkpoint":r7,"receipts":[upd(8)],"receipt_id_witnesses":[stale]})
        self.assertEqual(r["status"],"RECEIPT_ID_NONMEMBERSHIP_PROOF_REJECTED")
    def test_multi_suffix_sequential_witnesses(self):
        cp=self.migrate()["checkpoint"]; idx=h.ExternalReceiptIdIndex([f"r{i}" for i in range(1,7)])
        p7=idx.proof("r7"); idx.insert("r7"); p8=idx.proof("r8"); idx.insert("r8")
        r=h.rotate_witnessed_checkpoint({"checkpoint":cp,"receipts":[upd(7),upd(8)],"receipt_id_witnesses":[p7,p8]})
        self.assertTrue(r["rotated"]); self.assertEqual(r["checkpoint"]["receipt_id_root"],idx.root)
    def test_sequence_gap_rejected(self):
        cp=self.migrate()["checkpoint"]; idx=h.ExternalReceiptIdIndex([f"r{i}" for i in range(1,7)]); e=upd(7); e["sequence"]=99
        r=h.rotate_witnessed_checkpoint({"checkpoint":cp,"receipts":[e],"receipt_id_witnesses":[idx.proof("r7")]})
        self.assertEqual(r["status"],"ROTATION_RESUME_FAILED")
    def test_first_terminal_immutable_conflict_repair(self):
        cp=self.migrate()["checkpoint"]; idx=h.ExternalReceiptIdIndex([f"r{i}" for i in range(1,7)])
        bad=upd(7,slot="S1",bad=True); p=idx.proof("r7"); c1=h.rotate_witnessed_checkpoint({"checkpoint":cp,"receipts":[bad],"receipt_id_witnesses":[p]})["checkpoint"]; idx.insert("r7")
        good=upd(8,slot="S1",vals=[11,-7,5,3]); p=idx.proof("r8"); c2=h.rotate_witnessed_checkpoint({"checkpoint":c1,"receipts":[good],"receipt_id_witnesses":[p]})["checkpoint"]
        self.assertEqual(c2["first_terminal_prefix"],4); self.assertTrue(c2["post_terminal_regression_seen"]); self.assertTrue(c2["post_terminal_semantic_conflict_seen"]); self.assertTrue(c2["current_terminal_at_checkpoint"])
    def test_rehashed_compacted_lineage_substitution_needs_parent_audit(self):
        r=self.migrate(); cp=r["checkpoint"]; bad=copy.deepcopy(cp); bad["lineage_prefix_accumulator"]="0"*64; bad["lineage_accumulator"]=h._fold_lineage_accumulator(bad["lineage_anchors"],bad["lineage_prefix_accumulator"])
        body={k:copy.deepcopy(v) for k,v in bad.items() if k!="checkpoint_hash"}; bad["checkpoint_hash"]=h._witnessed_checkpoint_hash_body(body)
        self.assertTrue(h.validate_witnessed_checkpoint(bad)["checkpoint_valid"])
        v=h.validate_witnessed_checkpoint_transition({"previous_checkpoint":self.p6,"current_checkpoint":bad,"proof_packet":r["proof_packet"]})
        self.assertFalse(v["transition_valid"])
    def test_transition_packet_tamper_rejected(self):
        cp=self.migrate()["checkpoint"]; idx=h.ExternalReceiptIdIndex([f"r{i}" for i in range(1,7)]); p=idx.proof("r7")
        r=h.rotate_witnessed_checkpoint({"checkpoint":cp,"receipts":[upd(7)],"receipt_id_witnesses":[p]}); packet=copy.deepcopy(r["proof_packet"]); packet[0]["root_after"]="0"*64
        v=h.validate_witnessed_checkpoint_transition({"previous_checkpoint":cp,"current_checkpoint":r["checkpoint"],"proof_packet":packet})
        self.assertFalse(v["transition_valid"])
    def test_checkpoint_size_bounded_against_id_history(self):
        cp=self.migrate()["checkpoint"]; idx=h.ExternalReceiptIdIndex([f"r{i}" for i in range(1,7)]); sizes=[]
        for seq in range(7,207):
            p=idx.proof(f"r{seq}"); r=h.rotate_witnessed_checkpoint({"checkpoint":cp,"receipts":[upd(seq)],"receipt_id_witnesses":[p]}); self.assertTrue(r["rotated"])
            cp=r["checkpoint"]; idx.insert(f"r{seq}"); sizes.append(len(h._canonical_for_hash(cp)))
        self.assertEqual(cp["receipt_id_count"],206); self.assertNotIn("seen_receipt_ids",cp)
        self.assertLess(max(sizes[-100:])-min(sizes[-100:]),1500)
        self.assertLess(max(sizes),25000)
    def test_provider_firewalls_and_capabilities(self):
        env=h.handle_request({"mode":"receipt_id_membership_no_go","payload":{"checkpoint_bits":64,"universe_size":65}})
        self.assertEqual(env["truth_credit"],0); self.assertEqual(env["root_write_capability"],"NONE"); self.assertEqual(env["return_write_capability"],"NONE"); self.assertEqual(env["solver_mutation_capability"],"NONE")
        caps=h.capabilities()["capabilities"]; self.assertIn("rotate_witnessed_checkpoint",caps); self.assertIn("validate_witnessed_checkpoint_transition",caps)

if __name__=='__main__': unittest.main()
