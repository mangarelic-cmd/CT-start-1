import json, unittest
from fractions import Fraction
from itertools import permutations, product

from hypertriangle_solver_aux import (
    handle_request, compile_route, classify_route_transition, signed_polarity, b4_state
)

class TestSolverAux(unittest.TestCase):
    def test_authority_firewall(self):
        r = handle_request({"mode":"capabilities"})
        self.assertEqual(r["truth_credit"],0)
        self.assertEqual(r["root_write_capability"],"NONE")
        self.assertEqual(r["return_write_capability"],"NONE")
        self.assertEqual(r["solver_mutation_capability"],"NONE")

    def test_cp013_3_to_4(self):
        def tr(labels, weights):
            return {"contracts":{"additive":True,"common_ledger":True,"positivity_certified":True,"grounded":True},
                    "cells":[{"occurrence_id":l,"weight":w} for l,w in zip(labels,weights)]}
        r = classify_route_transition(tr("abc",[25,169,289]), tr("abcd",[25,169,289,625]))
        self.assertEqual(r["status"],"EXACT_3_TO_4_FACE_LIFT")
        self.assertEqual(r["new_pole"],"d")
        self.assertEqual(r["total_new_mass"], Fraction(625,1108))

    def test_dependency_blocks(self):
        r=compile_route({"cells":[
            {"occurrence_id":"T","weight":9},
            {"occurrence_id":"S","weight":16},
            {"occurrence_id":"COS","weight":25,"role":"DERIVED","derived_from":["T","S"]}
        ]})
        self.assertEqual(r["status"],"DEPENDENCY_BLOCKED_AS_INDEPENDENT_POLES")

    def test_q_boundaries(self):
        r=compile_route({"cells":[{"id":"a"},{"id":"b"},{"id":"c"}],"boundaries":[0,"1/4","3/4",1]})
        self.assertEqual(r["status"],"COMPOSITION_ONLY_FROM_Q_BOUNDARIES")
        self.assertEqual(r["route"]["composition"],(Fraction(1,4),Fraction(1,2),Fraction(1,4)))

    def test_symbolic(self):
        r=compile_route({"cells":[{"id":"a","weight":"wa"},{"id":"b","weight":"wb"}]})
        self.assertEqual(r["status"],"SYMBOLIC_SIMPLEX_STRUCTURE__WEIGHT_GROUNDING_OPEN")

    def test_signed_polarity(self):
        r=signed_polarity([3,-2,0,5])
        self.assertEqual(r["status"],"EXACT")
        self.assertEqual(r["magnitude_l1"],10)
        self.assertEqual(sum(r["bipolar_composition"],Fraction(0)),1)
        self.assertEqual(len(r["compatible_sign_sectors"]),2)

    def test_b4_contract_guard(self):
        r=b4_state({"values":[1,2,3,4],"contracts":{}})
        self.assertEqual(r["status"],"COMMON_SCALE_NOT_CERTIFIED")

    def test_b4_boundary(self):
        p={"values":[1,1,2,3],"contracts":{"common_scale_certified":True,"axis_independence_certified":True,"b4_comparable":True}}
        self.assertEqual(b4_state(p)["status"],"B4_BOUNDARY_STRATUM__NO_UNIQUE_CHAMBER")

    def test_all_384_b4_states(self):
        c={"common_scale_certified":True,"axis_independence_certified":True,"b4_comparable":True}
        ids=("a","b","c","d")
        seen=set()
        for signs in product((-1,1),repeat=4):
            for perm in permutations(range(4)):
                # perm is descending order; assign magnitudes 4,3,2,1 accordingly
                vals=[None]*4
                for rank,i in enumerate(perm): vals[i]=signs[i]*(4-rank)
                r=b4_state({"axis_ids":ids,"values":vals,"contracts":c})
                self.assertEqual(r["status"],"B4_INTERIOR_CHAMBER")
                self.assertEqual(tuple(r["perm_descending"]),perm)
                self.assertEqual(sum(r["barycentric"],Fraction(0)),1)
                self.assertEqual(len(r["neighbors"]),4)
                seen.add(r["chamber_id"])
        self.assertEqual(len(seen),384)

if __name__=="__main__": unittest.main()
