import copy, json, unittest
import hypertriangle_solver_aux as h


def route_payload(tag='P13'):
    return {
        'trace_id':tag,
        'contracts':{'additive':True,'common_ledger':True,'positivity_certified':True,'grounded':True},
        'cells':[{'occurrence_id':'a','weight':2},{'occurrence_id':'b','weight':3},{'occurrence_id':'c','weight':5}],
    }


def events6():
    return [
        {'event_id':'E001','sequence':1,'type':'MEMORY_DROP','datum_id':'D1','signals':[{'operator':'IDENTITY_SEED','certified':True,'projection':'p1'}]},
        {'event_id':'E002','sequence':2,'type':'ACTIVATE','contracts':[{'contract_id':'C-route','capability':'route_simplex','requires_all':['F001']}]},
        {'event_id':'E003','sequence':3,'type':'CAPABILITY','capability':'route_simplex','contract_id':'C-route','capability_payload':route_payload()},
        {'event_id':'E004','sequence':4,'type':'MEMORY_DROP','datum_id':'D2','signals':[{'operator':'DIRECTED_ONSET','certified':True,'projection':'p3'}]},
        {'event_id':'E005','sequence':5,'type':'ACTIVATE','contracts':[{'contract_id':'C-pol','capability':'signed_polarity','requires_all':['F003']}]},
        {'event_id':'E006','sequence':6,'type':'CAPABILITY','capability':'signed_polarity','contract_id':'C-pol','capability_payload':{'values':[3,-2,0]}},
    ]


def prefix_checkpoint():
    r=h.memory_144_create_unified_checkpoint({'events':events6()[:3]})
    assert r['checkpoint_valid'], r
    return r


class TestPass013UnifiedPersistentCheckpoint(unittest.TestCase):
    def test_version(self):
        self.assertGreaterEqual(tuple(map(int,h.AUX_VERSION.split('.'))),(0,13,0))

    def test_full_pipeline_replay(self):
        r=h.memory_144_pipeline_replay({'events':events6()})
        self.assertTrue(r['unified_valid'])
        p=r['projection']
        self.assertEqual(p['pipeline_event_count'],6)
        self.assertEqual(p['memory_drop_count'],2)
        self.assertEqual(p['activation_count'],2)
        self.assertEqual(p['typed_request_count'],2)
        self.assertEqual(p['capability_execution_count'],2)
        self.assertEqual(p['event_id_count'],6)
        self.assertEqual(p['memory_event_count'],2)

    def test_checkpoint_creation_binds_exact_sidecar(self):
        r=prefix_checkpoint(); cp=r['checkpoint']; snap=r['sidecar_snapshot']
        self.assertTrue(h.validate_memory_144_unified_checkpoint({'checkpoint':cp})['checkpoint_valid'])
        self.assertEqual(cp['event_id_snapshot_hash'],snap['snapshot_hash'])
        self.assertEqual(cp['event_id_root'],snap['receipt_id_root'])
        self.assertEqual(cp['event_id_count'],snap['receipt_id_count'])
        self.assertEqual(cp['sidecar_chain_state']['snapshot_count'],1)

    def test_checkpoint_plus_suffix_equals_full_replay(self):
        r=prefix_checkpoint()
        resumed=h.memory_144_resume_unified_checkpoint({'checkpoint':r['checkpoint'],'sidecar_snapshot':r['sidecar_snapshot'],'events':events6()[3:]})
        full=h.memory_144_pipeline_replay({'events':events6()})
        self.assertTrue(resumed['resume_valid'])
        self.assertTrue(full['unified_valid'])
        self.assertEqual(resumed['projection'],full['projection'])

    def test_resume_exact_sidecar_journal_count(self):
        r=prefix_checkpoint()
        resumed=h.memory_144_resume_unified_checkpoint({'checkpoint':r['checkpoint'],'sidecar_snapshot':r['sidecar_snapshot'],'events':events6()[3:]})
        self.assertEqual(len(resumed['sidecar_journal_records']),3)
        self.assertEqual(resumed['sidecar_recovery']['receipt_id_count'],6)

    def test_rotation_matches_full_replay(self):
        r=prefix_checkpoint(); child=h.memory_144_rotate_unified_checkpoint({'checkpoint':r['checkpoint'],'sidecar_snapshot':r['sidecar_snapshot'],'events':events6()[3:]})
        full=h.memory_144_pipeline_replay({'events':events6()})
        self.assertTrue(child['checkpoint_valid'])
        self.assertEqual(child['projection'],full['projection'])
        self.assertEqual(child['checkpoint']['rotation_index'],1)
        self.assertEqual(child['checkpoint']['previous_checkpoint_hash'],r['checkpoint']['unified_checkpoint_hash'])
        self.assertEqual(child['sidecar_snapshot']['generation'],1)
        self.assertEqual(child['checkpoint']['sidecar_chain_state']['snapshot_count'],2)

    def test_transition_validator(self):
        r=prefix_checkpoint(); child=h.memory_144_rotate_unified_checkpoint({'checkpoint':r['checkpoint'],'sidecar_snapshot':r['sidecar_snapshot'],'events':events6()[3:]})
        v=h.validate_memory_144_unified_transition({'parent_checkpoint':r['checkpoint'],'parent_sidecar_snapshot':r['sidecar_snapshot'],'events':events6()[3:],'child_checkpoint':child['checkpoint'],'child_sidecar_snapshot':child['sidecar_snapshot']})
        self.assertTrue(v['transition_valid'])

    def test_second_rotation(self):
        r=prefix_checkpoint(); child=h.memory_144_rotate_unified_checkpoint({'checkpoint':r['checkpoint'],'sidecar_snapshot':r['sidecar_snapshot'],'events':events6()[3:]})
        e7={'event_id':'E007','sequence':7,'type':'ACTIVATE','contracts':[{'contract_id':'C-pol2','capability':'signed_polarity','requires_all':['F003']}]}
        c2=h.memory_144_rotate_unified_checkpoint({'checkpoint':child['checkpoint'],'sidecar_snapshot':child['sidecar_snapshot'],'events':[e7]})
        self.assertTrue(c2['checkpoint_valid'])
        self.assertEqual(c2['checkpoint']['rotation_index'],2)
        self.assertEqual(c2['checkpoint']['checkpoint_chain_root_hash'],r['checkpoint']['unified_checkpoint_hash'])
        self.assertEqual(c2['checkpoint']['sidecar_chain_state']['snapshot_count'],3)

    def test_memory_drop_invalidates_activation(self):
        ev=events6()[:4]
        ev.append({'event_id':'E005x','sequence':5,'type':'CAPABILITY','capability':'route_simplex','capability_payload':route_payload('stale')})
        r=h.memory_144_pipeline_replay({'events':ev})
        self.assertFalse(r['unified_valid'])
        self.assertIn('fresh activation',r['error'])

    def test_duplicate_event_id_full_replay_rejected(self):
        ev=events6(); ev[4]=copy.deepcopy(ev[4]); ev[4]['event_id']='E004'
        r=h.memory_144_pipeline_replay({'events':ev})
        self.assertFalse(r['unified_valid']); self.assertIn('duplicate',r['error'])

    def test_duplicate_prefix_id_on_resume_rejected_by_exact_sidecar(self):
        r=prefix_checkpoint(); bad=copy.deepcopy(events6()[3]); bad['event_id']='E002'
        x=h.memory_144_resume_unified_checkpoint({'checkpoint':r['checkpoint'],'sidecar_snapshot':r['sidecar_snapshot'],'events':[bad]})
        self.assertFalse(x['resume_valid']); self.assertIn('sidecar rejected',x['error'])

    def test_wrong_sidecar_snapshot_rejected(self):
        r=prefix_checkpoint(); other=h.receipt_id_sidecar_snapshot({'receipt_ids':['X']})['snapshot']
        x=h.memory_144_resume_unified_checkpoint({'checkpoint':r['checkpoint'],'sidecar_snapshot':other,'events':events6()[3:]})
        self.assertFalse(x['resume_valid'])

    def test_checkpoint_hash_tamper_rejected(self):
        r=prefix_checkpoint(); bad=copy.deepcopy(r['checkpoint']); bad['pipeline_event_count']=999
        self.assertFalse(h.validate_memory_144_unified_checkpoint({'checkpoint':bad})['checkpoint_valid'])

    def test_checkpoint_memory_tamper_rejected(self):
        r=prefix_checkpoint(); bad=copy.deepcopy(r['checkpoint']); hh=list(bad['memory_state']['hit_counts']); hh[0]=99; bad['memory_state']['hit_counts']=tuple(hh)
        self.assertFalse(h.validate_memory_144_unified_checkpoint({'checkpoint':bad})['checkpoint_valid'])

    def test_sidecar_chain_tamper_rejected(self):
        r=prefix_checkpoint(); bad=copy.deepcopy(r['checkpoint']); bad['sidecar_chain_state']['tip_receipt_id_count']=99
        # rehash outer checkpoint to ensure nested semantic validation catches it.
        body={k:copy.deepcopy(v) for k,v in bad.items() if k!='unified_checkpoint_hash'}
        bad['unified_checkpoint_hash']=h._memory_144_unified_checkpoint_hash(body)
        self.assertFalse(h.validate_memory_144_unified_checkpoint({'checkpoint':bad})['checkpoint_valid'])

    def test_crash_json_roundtrip_resume_identical(self):
        r=prefix_checkpoint()
        cp=json.loads(json.dumps(h.encode(r['checkpoint']),sort_keys=True))
        snap=json.loads(json.dumps(h.encode(r['sidecar_snapshot']),sort_keys=True))
        a=h.memory_144_resume_unified_checkpoint({'checkpoint':r['checkpoint'],'sidecar_snapshot':r['sidecar_snapshot'],'events':events6()[3:]})
        b=h.memory_144_resume_unified_checkpoint({'checkpoint':cp,'sidecar_snapshot':snap,'events':events6()[3:]})
        self.assertTrue(b['resume_valid']); self.assertEqual(a['projection'],b['projection'])
        self.assertEqual(h.encode(a['sidecar_journal_records']),h.encode(b['sidecar_journal_records']))

    def test_pipeline_history_is_deterministic(self):
        a=h.memory_144_pipeline_replay({'events':events6()}); b=h.memory_144_pipeline_replay({'events':copy.deepcopy(events6())})
        self.assertEqual(a['projection']['pipeline_history_accumulator'],b['projection']['pipeline_history_accumulator'])
        self.assertEqual(a['projection']['event_id_root'],b['projection']['event_id_root'])

    def test_latest_request_execution_summary_binding(self):
        r=h.memory_144_create_unified_checkpoint({'events':events6()})
        cp=r['checkpoint']; q=cp['latest_typed_request_summary']; x=cp['latest_capability_execution_summary']
        self.assertEqual(q['typed_request_hash'],x['typed_request_hash'])
        self.assertEqual(q['target_capability'],'signed_polarity')
        self.assertEqual(x['target_capability'],'signed_polarity')

    def test_rotation_suffix_commitment_tamper_detected_by_transition(self):
        r=prefix_checkpoint(); child=h.memory_144_rotate_unified_checkpoint({'checkpoint':r['checkpoint'],'sidecar_snapshot':r['sidecar_snapshot'],'events':events6()[3:]})
        bad=copy.deepcopy(child['checkpoint']); bad['rotation_suffix_commitment']='0'*64
        body={k:copy.deepcopy(v) for k,v in bad.items() if k!='unified_checkpoint_hash'}; bad['unified_checkpoint_hash']=h._memory_144_unified_checkpoint_hash(body)
        v=h.validate_memory_144_unified_transition({'parent_checkpoint':r['checkpoint'],'parent_sidecar_snapshot':r['sidecar_snapshot'],'events':events6()[3:],'child_checkpoint':bad,'child_sidecar_snapshot':child['sidecar_snapshot']})
        self.assertFalse(v['transition_valid'])

    def test_no_memory_feedback_from_capability(self):
        r=h.memory_144_pipeline_replay({'events':events6()[:3]})
        cap=r['event_receipts'][-1]['outcome']
        self.assertFalse(cap['memory_feedback_performed']); self.assertFalse(cap['activation_reentry_performed'])
        self.assertEqual(r['projection']['memory_event_count'],1)

    def test_provider_modes(self):
        caps=h.capabilities()['capabilities']
        modes=('memory_144_pipeline_replay','memory_144_create_unified_checkpoint','memory_144_validate_unified_checkpoint','memory_144_resume_unified_checkpoint','memory_144_rotate_unified_checkpoint','memory_144_validate_unified_transition')
        for m in modes: self.assertIn(m,caps)
        env=h.handle_request({'mode':'memory_144_pipeline_replay','payload':{'events':[]}})
        self.assertGreaterEqual(tuple(map(int,env['version'].split('.'))),(0,13,0)); self.assertEqual(env['solver_mutation_capability'],'NONE')


if __name__=='__main__': unittest.main()
