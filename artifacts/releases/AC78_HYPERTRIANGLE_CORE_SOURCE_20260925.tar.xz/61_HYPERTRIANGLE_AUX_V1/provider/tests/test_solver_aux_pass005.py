import copy, unittest
import hypertriangle_solver_aux as h

C={"common_scale_certified":True,"axis_independence_certified":True,"b4_comparable":True}
def state(vals,err="1/100"):
    return {"values":vals,"component_errors":[err]*4,"contracts":C}
def event(w,t,axis,err="1/100"):
    base=[8,6,4,2]; left=base[:]; right=base[:]; left[axis]=-2; right[axis]=2
    a=[0,0,0,0]; a[axis]=1
    return {"wall_id":w,"alpha":a,"left":{"time":t-1,"values":left},"right":{"time":t+1,"values":right},
            "uniform_component_errors":[err]*4,"derivative_direction":1,"derivative_magnitude_lower":1,
            "derivative_error":err,"nominal_time":t,"contracts":{"uniform_error_over_bracket_certified":True}}
def base_stream():
    return {"stream_id":"p5-demo","requirements":{"required_state_slots":["S0","S1"],"required_event_slots":["E0","E1"],"required_wall_sequence":["w0","w1"]},"receipts":[
        {"receipt_id":"r1","sequence":1,"slot":"S0","kind":"state","payload":state([8,6,4,2])},
        {"receipt_id":"r2","sequence":2,"slot":"E0","kind":"event","payload":event("w0",2,0)},
        {"receipt_id":"r3","sequence":3,"slot":"S1","kind":"state","payload":state([7,-5,3,1])},
        {"receipt_id":"r4","sequence":4,"slot":"E1","kind":"event","payload":event("w1",5,1)},
    ]}
def upd(seq, slot="S1", vals=None, bad=False):
    if vals is None: vals=[8+seq,6,4,2]
    payload=state(vals)
    if bad: payload={"values":[1,2,3,4],"component_errors":[2,0,0,0],"contracts":C}
    return {"receipt_id":f"r{seq}","sequence":seq,"slot":slot,"kind":"state","payload":payload}

class TestSolverAuxPass005(unittest.TestCase):
    def setUp(self):
        self.s=base_stream(); self.cp0=h.create_stream_checkpoint({"stream":self.s})["checkpoint"]
    def test_first_rotation_valid(self):
        r=h.rotate_stream_checkpoint({"checkpoint":self.cp0,"receipts":[upd(5)]})
        self.assertTrue(r["rotated"]); self.assertEqual(r["rotation_index"],1)
        self.assertTrue(h.validate_stream_checkpoint(r["checkpoint"])["checkpoint_valid"])
    def test_two_rotations_equal_full_replay(self):
        r1=h.rotate_stream_checkpoint({"checkpoint":self.cp0,"receipts":[upd(5)]})["checkpoint"]
        r2=h.rotate_stream_checkpoint({"checkpoint":r1,"receipts":[upd(6,"S0",[14,8,5,2])]})["checkpoint"]
        full=copy.deepcopy(self.s); full["receipts"] += [upd(5),upd(6,"S0",[14,8,5,2])]
        cert=h.certify_receipt_stream(full)
        self.assertEqual(r2["prefix_stream_hash"],cert["final_stream_hash"])
        self.assertEqual(r2["first_terminal_prefix"],cert["first_terminal_prefix"])
        self.assertEqual(r2["current_terminal_at_checkpoint"],cert["current_terminal"])
    def test_chain_validation(self):
        r1=h.rotate_stream_checkpoint({"checkpoint":self.cp0,"receipts":[upd(5)]})["checkpoint"]
        r2=h.rotate_stream_checkpoint({"checkpoint":r1,"receipts":[upd(6)]})["checkpoint"]
        v=h.validate_checkpoint_chain({"checkpoints":[self.cp0,r1,r2]})
        self.assertTrue(v["chain_valid"]); self.assertEqual(v["rotation_count"],2)
    def test_missing_root_rejected_by_default(self):
        r1=h.rotate_stream_checkpoint({"checkpoint":self.cp0,"receipts":[upd(5)]})["checkpoint"]
        r2=h.rotate_stream_checkpoint({"checkpoint":r1,"receipts":[upd(6)]})["checkpoint"]
        self.assertFalse(h.validate_checkpoint_chain({"checkpoints":[r1,r2]})["chain_valid"])
        self.assertTrue(h.validate_checkpoint_chain({"checkpoints":[r1,r2],"require_root":False})["chain_valid"])
    def test_fork_detected(self):
        a=h.rotate_stream_checkpoint({"checkpoint":self.cp0,"receipts":[upd(5)]})["checkpoint"]
        b=h.rotate_stream_checkpoint({"checkpoint":self.cp0,"receipts":[upd(5,"S0",[13,8,5,2])]})["checkpoint"]
        v=h.validate_checkpoint_chain({"checkpoints":[self.cp0,a,b]})
        self.assertFalse(v["chain_valid"]); self.assertEqual(v["status"],"CHECKPOINT_PREVIOUS_HASH_MISMATCH")
    def test_duplicate_across_rotation_rejected(self):
        e=upd(5); e["receipt_id"]="r2"
        r=h.rotate_stream_checkpoint({"checkpoint":self.cp0,"receipts":[e]})
        self.assertEqual(r["status"],"ROTATION_RESUME_FAILED")
        self.assertEqual(r["resume"]["status"],"DUPLICATE_STREAM_RECEIPT_ID")
    def test_sequence_gap_rejected(self):
        e=upd(5); e["sequence"]=7
        r=h.rotate_stream_checkpoint({"checkpoint":self.cp0,"receipts":[e]})
        self.assertEqual(r["status"],"ROTATION_RESUME_FAILED")
    def test_empty_rotation_rejected(self):
        self.assertEqual(h.rotate_stream_checkpoint({"checkpoint":self.cp0,"receipts":[]})["status"],"EMPTY_ROTATION_SUFFIX")
    def test_first_terminal_immutable_through_conflict_and_repair(self):
        c1=h.rotate_stream_checkpoint({"checkpoint":self.cp0,"receipts":[upd(5,bad=True)]})["checkpoint"]
        c2=h.rotate_stream_checkpoint({"checkpoint":c1,"receipts":[upd(6,vals=[11,-7,5,3])]})["checkpoint"]
        self.assertEqual(c2["first_terminal_prefix"],4)
        self.assertEqual(c2["first_terminal_stream_hash"],self.cp0["first_terminal_stream_hash"])
        self.assertTrue(c2["post_terminal_regression_seen"])
        self.assertTrue(c2["post_terminal_semantic_conflict_seen"])
        self.assertTrue(c2["current_terminal_at_checkpoint"])
    def test_nonterminal_root_can_become_terminal(self):
        s=base_stream(); s["receipts"]=s["receipts"][:3]
        cp=h.create_stream_checkpoint({"stream":s})["checkpoint"]
        self.assertFalse(cp["historical_terminal"])
        c1=h.rotate_stream_checkpoint({"checkpoint":cp,"receipts":[base_stream()["receipts"][3]]})["checkpoint"]
        self.assertTrue(c1["historical_terminal"]); self.assertEqual(c1["first_terminal_prefix"],4)
    def test_lineage_depth_exact(self):
        cp=self.cp0
        chain=[cp]
        for seq in range(5,10):
            cp=h.rotate_stream_checkpoint({"checkpoint":cp,"receipts":[upd(seq)]})["checkpoint"]; chain.append(cp)
        self.assertEqual(cp["rotation_index"],5); self.assertEqual(len(cp["checkpoint_lineage"]),5)
        self.assertTrue(h.validate_checkpoint_chain({"checkpoints":chain})["chain_valid"])
    def test_standalone_tamper_semantic_rejected_even_rehashed(self):
        cp=h.rotate_stream_checkpoint({"checkpoint":self.cp0,"receipts":[upd(5)]})["checkpoint"]
        cp=copy.deepcopy(cp); cp["rotation_history_commitment"]="0"*64
        body={k:copy.deepcopy(v) for k,v in cp.items() if k!="checkpoint_hash"}
        cp["checkpoint_hash"]=h._checkpoint_hash_body(body)
        v=h.validate_stream_checkpoint(cp)
        self.assertFalse(v["checkpoint_valid"]); self.assertIn("rotation history commitment",v.get("error","").lower())
    def test_provider_firewall(self):
        env=h.handle_request({"mode":"rotate_stream_checkpoint","payload":{"checkpoint":self.cp0,"receipts":[upd(5)]}})
        self.assertEqual(env["truth_credit"],0); self.assertEqual(env["root_write_capability"],"NONE"); self.assertEqual(env["solver_mutation_capability"],"NONE")
    def test_chain_audit_hash_deterministic(self):
        c1=h.rotate_stream_checkpoint({"checkpoint":self.cp0,"receipts":[upd(5)]})["checkpoint"]
        x=h.validate_checkpoint_chain({"checkpoints":[self.cp0,c1]})
        y=h.validate_checkpoint_chain({"checkpoints":[copy.deepcopy(self.cp0),copy.deepcopy(c1)]})
        self.assertEqual(x["checkpoint_chain_audit_hash"],y["checkpoint_chain_audit_hash"])
    def test_seen_ids_exact_after_rotations(self):
        cp=self.cp0
        for seq in range(5,15): cp=h.rotate_stream_checkpoint({"checkpoint":cp,"receipts":[upd(seq)]})["checkpoint"]
        self.assertEqual(len(cp["seen_receipt_ids"]),14); self.assertEqual(len(set(cp["seen_receipt_ids"])),14)

if __name__=='__main__': unittest.main()
