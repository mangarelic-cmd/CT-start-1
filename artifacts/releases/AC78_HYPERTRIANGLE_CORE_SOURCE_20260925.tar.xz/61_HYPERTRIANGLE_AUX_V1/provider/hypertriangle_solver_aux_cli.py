#!/usr/bin/env python3
import json, sys
from hypertriangle_solver_aux import handle_request, encode

def main(argv=None):
    argv = sys.argv[1:] if argv is None else argv
    if len(argv) > 1:
        raise SystemExit("usage: hypertriangle_solver_aux_cli.py [request.json]")
    if argv:
        with open(argv[0], encoding="utf-8") as f: req = json.load(f)
    else:
        req = json.load(sys.stdin)
    json.dump(encode(handle_request(req)), sys.stdout, indent=2, sort_keys=True)
    sys.stdout.write("\n")

if __name__ == "__main__": main()
