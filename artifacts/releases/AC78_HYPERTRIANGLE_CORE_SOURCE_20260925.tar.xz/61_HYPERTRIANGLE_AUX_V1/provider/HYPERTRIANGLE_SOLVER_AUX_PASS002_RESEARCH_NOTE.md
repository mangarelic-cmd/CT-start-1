# HyperTriangle Solver AUX — PASS002 Research Note

Date: 2026-09-25  
Branch: `HYPERTRIANGLE_SOLVER_AUX`  
Parent: PASS001 standalone AUX + frozen theoretical PASS052R1  
Scope: robust receipts and B4 event/route certification. **No AC77/DD094 integration is performed.**

## 1. Objective

PASS001 exposed four standalone capabilities: route simplex compilation, route transition typing, signed-polarity lifting and exact B4 state compilation. PASS002 adds the uncertainty-aware layer required before a solver may consume those receipts safely.

The central rule is fail-closed: nominal proximity to a chamber or event is not promoted to certification unless the complete declared uncertainty set remains on the same side of every required wall.

## 2. Robust B4 chamber certificate

For nominal amplitudes `h_i` with componentwise certified errors `eps_i`, a unique B4 chamber is certified only if

- `|h_i| > eps_i` for every axis; and
- `||h_i|-|h_j|| > eps_i + eps_j` for every pair.

These conditions ensure the full uncertainty box avoids all sign walls and all equal-magnitude walls. The provider returns the nominal chamber, per-wall lower margins and the minimum certified wall margin.

## 3. Robust wall-event certificate

For a declared wall covector `alpha`, PASS002 computes

`w = alpha^T h`,  `E_w = sum_i |alpha_i| eps_i`.

A unique crossing is certified only when:

1. the left and right wall intervals have opposite certified signs;
2. the error bound is explicitly certified uniform across the bracket;
3. a derivative direction is declared; and
4. the declared derivative magnitude lower bound exceeds its error bound.

When a nominal event time is supplied, the provider returns the conservative shift bound

`E_w / (v_lower - E_v)`

and a certified time interval clipped to the original bracket.

## 4. Route certificate

A B4 route is certified only if every supplied event is individually certified and the resulting event-time intervals are strictly ordered and disjoint. PASS002 does not infer omitted events.

## 5. Receipt bundle

`receipt_bundle` combines any declared robust B4 state requirements with an optional route. The bundle becomes terminal only when every required state and event/route requirement is certified. It carries zero scientific truth credit and cannot write ROOT or RETURN.

## 6. Solver boundary

PASS002 remains a standalone AUX. It does not modify, register into, or execute AC77/DD094. Integration is deliberately a separate future operation.

## 7. Validation

- unit/regression: **19/19 PASS**;
- independent verifier: **18,472/18,472 PASS**;
- qualification campaign: **55,000/55,000 PASS**;
- nominal B4 chamber census: **384/384**;
- robust B4 chamber census with full corner checks: **384/384**.

## 8. Next front

PASS003 should remain standalone and add a receipt-stream layer: evaluate prefixes, detect the first terminal robust certificate, screen a proposed next receipt, and preserve the PASS051 no-go that more worst-case data need not monotonically improve a certificate.
