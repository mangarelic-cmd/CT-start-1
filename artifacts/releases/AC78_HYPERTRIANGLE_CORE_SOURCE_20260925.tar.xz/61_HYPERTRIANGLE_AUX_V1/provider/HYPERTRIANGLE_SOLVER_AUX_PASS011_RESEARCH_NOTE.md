# HyperTriangle Solver AUX — PASS011 Research Note

Date: 2026-09-25  
Branch: `HYPERTRIANGLE_SOLVER_AUX`  
Parent: PASS010 standalone AUX.  
Scope: deterministic memory-driven capability activation contracts. **No AC77/DD094 integration, capability execution, ROOT/RETURN write, or solver mutation.**

## 1. Frontier closed
PASS010 established the native direction:

`DATA -> INVARIANT -> F001..F144 FLAG -> LAST CERTIFIED INVARIANT`.

PASS011 closes the next bridge:

`CERTIFIED SURVIVING MEMORY -> DECLARED ACTIVATION CONTRACT -> CAPABILITY RELEVANCE RECEIPT`.

The reverse direction remains forbidden. A capability never searches for data and PASS011 never invents a slot-to-capability relation.

## 2. Activation contracts
A contract declares:

- `contract_id`;
- one local standalone AUX `capability`;
- `requires_all`: every listed slot must carry a surviving certified last invariant;
- `requires_any`: when non-empty, at least one listed slot must carry a surviving certified last invariant;
- `forbids`: none of the listed slots may carry a surviving certified last invariant.

At least one positive requirement is mandatory. Unknown slots, external solver targets, duplicate targets, and self-contradictory require/forbid contracts are rejected.

## 3. No inferred mapping
PASS011 intentionally ships no invented semantic map such as `F017 -> b4_state`.

If no contracts are supplied, a populated memory yields **zero active capabilities**. This is a hard anti-category-pull property, not an omission.

## 4. Certified evidence only
Observed-but-uncertified flags never satisfy an activation requirement. Activation support is bound to the surviving `last_invariants_saved` record for each supporting slot. Every supporting last invariant receives a SHA-256 commitment and trace index in the activation evaluation.

## 5. Deterministic states
Each contract resolves to exactly one state:

- `ACTIVE`;
- `INACTIVE_MISSING_ALL`;
- `INACTIVE_MISSING_ANY`;
- `BLOCKED_FORBIDDEN`.

Contracts are canonically ordered by `contract_id`, so input ordering does not alter the activation-state hash.

## 6. Activation receipt
The receipt commits to:

- exact memory state hash;
- memory trace accumulator and event counter;
- certified 144-bit mask and certified slot list;
- normalized contracts and `contracts_hash`;
- per-contract evaluation;
- active contracts and capabilities;
- `activation_state_hash`.

The validator can audit the receipt structurally from its certified mask and contracts, and can optionally perform full replay against the exact supplied memory state.

## 7. Execution boundary
Activation is relevance only:

`execution_performed = false`.

PASS011 does **not** call the activated capability. That bridge belongs to the next pass, where a typed activation receipt can be consumed by the HyperTriangle capability layer without creating a feedback loop.

## 8. Validation
- cumulative unit/regression tests: **157/157 PASS**;
- qualification: **12,062/12,062 PASS** over 3,000 memory events and 19 explicit contracts;
- independent verifier: **46,337/46,337 PASS**;
- all ordered distinct canonical slot pairs: **20,592/20,592** evaluated as two-slot activation conjunctions;
- independent randomized truth-table cases: **1,200/1,200 PASS**;
- cold replay: PASS;
- activation contract ordering: deterministic.

## 9. Metadata debt repaired
The stale PASS008/PASS009 provider/integration metadata inherited by PASS010 is updated to PASS011/version `0.11.0`.

## 10. Authority firewall
Unchanged:

- `truth_credit = 0`;
- ROOT write = `NONE`;
- RETURN write = `NONE`;
- solver mutation = `NONE`;
- AC77 integration = `NOT_PERFORMED`;
- DD094 integration = `NOT_PERFORMED`.

## 11. Next front
PASS012 should consume a valid activation receipt and bind it to the corresponding local HyperTriangle capability request, preserving provenance and preventing self-reinforcing activation loops:

`memory -> activation receipt -> typed capability request -> capability receipt -> causal parent/provenance`.
