#!/usr/bin/env python3
from fractions import Fraction
from itertools import product, permutations
import random
from hypertriangle_solver_aux import b4_state, compile_route, handle_request


def run():
    checks=0
    contracts={"common_scale_certified":True,"axis_independence_certified":True,"b4_comparable":True}
    # Exhaustive 384 chambers.
    for signs in product((-1,1), repeat=4):
        for perm in permutations(range(4)):
            vals=[0]*4
            for rank,i in enumerate(perm): vals[i]=signs[i]*(8-2*rank)
            r=b4_state({"values":vals,"contracts":contracts})
            assert r["status"]=="B4_INTERIOR_CHAMBER"
            assert tuple(r["perm_descending"])==perm
            assert sum(r["barycentric"],Fraction(0))==1
            checks += 1
    # Deterministic route campaign.
    rng=random.Random(20260925)
    for n in range(1,7):
        for _ in range(2500):
            w=[rng.randrange(0,20) for _ in range(n)]
            cells=[{"id":f"p{i}","weight":x} for i,x in enumerate(w)]
            r=compile_route({"cells":cells})
            assert r["status"] in {"COMPILED_NUMERIC_ROUTE","ZERO_ROUTE"}
            if sum(w)>0:
                assert sum(r["route"]["composition"],Fraction(0))==1
            checks += 1
    # Provider firewall campaign.
    for _ in range(10000):
        r=handle_request({"mode":"capabilities"})
        assert r["truth_credit"]==0 and r["root_write_capability"]=="NONE" and r["return_write_capability"]=="NONE"
        checks += 1
    return checks

if __name__=="__main__":
    n=run(); print(f"HYPERTRIANGLE_SOLVER_AUX qualification: {n}/{n} PASS")
