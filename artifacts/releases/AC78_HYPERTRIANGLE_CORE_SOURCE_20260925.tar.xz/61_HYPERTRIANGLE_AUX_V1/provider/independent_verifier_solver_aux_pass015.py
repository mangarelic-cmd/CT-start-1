import hashlib, json, re
from pathlib import Path
import hypertriangle_solver_aux as h
ROOT=Path(__file__).resolve().parent
F=json.loads((ROOT/'HYPERTRIANGLE_SOLVER_AUX_V1_ABI_FREEZE.json').read_text())
checks=0

def ck(x,msg):
    global checks
    checks+=1
    if not x: raise AssertionError(msg)
def sha(p): return hashlib.sha256(Path(p).read_bytes()).hexdigest()
def csha(o): return hashlib.sha256(json.dumps(o,sort_keys=True,separators=(',',':'),ensure_ascii=False).encode()).hexdigest()

# Static source/ABI parity independent of handle_request execution.
source=(ROOT/'hypertriangle_solver_aux.py').read_text()
ck('AUX_VERSION = "1.0.0"' in source,'source version')
modes=set(re.findall(r'(?:if|elif) mode == [\"\']([^\"\']+)[\"\']',source)); modes.discard('capabilities')
ck(modes==set(F['capabilities']),'dispatch set')
ck(len(modes)==61,'dispatch count')
for rel,d in F['schemas'].items(): ck(sha(ROOT/rel)==d,rel)
for rel,d in F['implementation_files'].items(): ck(sha(ROOT/rel)==d,rel)
ck(csha(F['schemas'])==F['schemas_index_sha256'],'schema index')
ck(csha(F['implementation_files'])==F['implementation_index_sha256'],'impl index')
ck(sha(ROOT/F['causal_144_canon']['path'])==F['causal_144_canon']['sha256'],'canon hash')

# Runtime ABI must equal independently frozen JSON.
caps=h.capabilities(); ck(caps['capabilities']==F['capabilities'],'caps runtime'); ck(caps['firewalls']==F['firewalls'],'firewalls runtime')
env=h.handle_request({'mode':'capabilities','request_id':'IV15'})
ck(env['version']=='1.0.0','env version'); ck(env['truth_credit']==0,'truth'); ck(env['solver_mutation_capability']=='NONE','mutation'); ck(env['root_write_capability']=='NONE','root'); ck(env['return_write_capability']=='NONE','return')

# Freeze tampering must change the corresponding canonical commitment.
for field in ('capabilities','firewalls','schemas','implementation_files'):
    x=json.loads(json.dumps(F[field]))
    if isinstance(x,list): x=x+['TAMPER']
    else: x[next(iter(x))]='0'*64
    expected=F.get(field+'_sha256') or F.get(field.replace('schemas','schemas_index').replace('implementation_files','implementation_index')+'_sha256')
    ck(csha(x)!=expected,'tamper '+field)

# V1 terminal path smoke + stale execution regression remains intact.
def route(tag): return {'trace_id':tag,'contracts':{'additive':True,'common_ledger':True,'positivity_certified':True,'grounded':True},'cells':[{'occurrence_id':'a','weight':1},{'occurrence_id':'b','weight':2}]}
events=[
 {'event_id':'I1','sequence':1,'type':'MEMORY_DROP','datum_id':'D1','signals':[{'operator':'IDENTITY_SEED','certified':True,'projection':'x'}]},
 {'event_id':'I2','sequence':2,'type':'ACTIVATE','contracts':[{'contract_id':'R','capability':'route_simplex','requires_all':['F001']}]},
 {'event_id':'I3','sequence':3,'type':'CAPABILITY','capability':'route_simplex','contract_id':'R','capability_payload':route('a')},
 {'event_id':'I4','sequence':4,'type':'MEMORY_DROP','datum_id':'D2','signals':[{'operator':'DIRECTED_ONSET','certified':True,'projection':'y'}]},
]
contract={'contract_id':'T','requires_certified_slots':['F001'],'requires_active_contracts':['R'],'requires_completed_capabilities':['route_simplex']}
r=h.memory_144_terminal_replay({'events':events,'terminal_contract':contract})
ck(r['terminal_replay_valid'],'terminal replay'); ck(r['projection']['first_terminal_prefix']==3,'first terminal'); ck(r['projection']['current_terminal'] is False,'regression'); ck(r['projection']['historical_terminal'] is True,'history')

print(json.dumps({'status':'PASS','checks':checks,'release_version':'1.0.0','static_dispatch_modes':len(modes),'schemas':len(F['schemas']),'implementation_files':len(F['implementation_files']),'tamper_classes':4,'truth_credit':0},sort_keys=True))
