# HYPERTRIANGLE_SOLVER_AUX — PASS014 Research Note

Date: 2026-09-25
Branch: `HYPERTRIANGLE_SOLVER_AUX`
Version: `0.14.0`
Scope: standalone AUX terminality only. AC77/DD094 integration is not performed.

## Object closed

PASS014 adds a declared local terminal contract over the unified PASS013 pipeline. It does **not** infer when a scientific problem is solved and does not mint truth. `AUX_TERMINAL` means only that the obligations explicitly declared in one local terminal contract are satisfied by the current certified AUX state.

The terminal contract may require:

- certified surviving `F001..F144` slots;
- active PASS011 contract IDs;
- active standalone local HyperTriangle capabilities;
- capabilities already executed under the **current memory-state hash and current activation-state hash**;
- absence of explicitly forbidden certified slots.

At least one positive obligation is mandatory. A require/forbid overlap is rejected.

## Prefix semantics

The terminal predicate is evaluated after every pipeline prefix. The first prefix that satisfies the contract is frozen as a terminal certificate containing:

- prefix event count;
- terminal-contract hash;
- pipeline-history accumulator;
- terminal-history accumulator;
- memory-state hash;
- activation-state hash;
- bounded execution-state hash;
- terminal-evaluation hash.

Once frozen, later events cannot rewrite the first terminal prefix or certificate.

A later memory mutation may invalidate activation and make a previously valid capability execution stale. That creates a post-terminal regression without erasing the historical terminal prefix. A later repair may make the current state terminal again while the first terminal certificate remains unchanged.

A forbidden certified slot present after historical terminality is recorded separately as a post-terminal semantic conflict.

## Persistence

PASS014 wraps the PASS013 unified checkpoint rather than creating a competing persistence system. Terminal checkpoint continuation therefore inherits:

- PASS007 exact Sparse-Merkle event-ID root;
- PASS008 exact external sidecar snapshot/journal;
- PASS009 bounded snapshot lineage;
- PASS013 checkpoint+sufﬁxe/full-replay semantics.

New provider modes:

- `memory_144_terminal_replay`;
- `memory_144_create_terminal_checkpoint`;
- `memory_144_validate_terminal_checkpoint`;
- `memory_144_resume_terminal_checkpoint`;
- `memory_144_rotate_terminal_checkpoint`;
- `memory_144_validate_terminal_transition`.

## Archival boundary

The current terminal evaluation is reconstructible from the active checkpoint. The full terminal-history accumulator after discarded historical prefixes, like PASS013's pipeline-history accumulator, remains an archival commitment. Exact validation of rehashed historical continuation state requires the archived transition evidence or replay. Transition validation performs that replay and therefore detects child substitution or first-terminal rewriting.

## Validation

- cumulative unit tests: 214/214 PASS;
- PASS014 qualification: 990/990 PASS;
- canonical slot terminal-contract cases: 144/144;
- checkpoint+sufﬁxe equivalence cases: 48;
- sequential terminal rotations: 5;
- independent verifier: 192/192 PASS;
- independent random equivalence cases: 36;
- semantic tamper cases: 6;
- transition replay cases: 1;
- AC77 integration: NOT_PERFORMED;
- DD094 integration: NOT_PERFORMED;
- truth credit: 0.

PASS014 is scoped terminality closure. PASS015 remains the final standalone AUX freeze/release pass.
