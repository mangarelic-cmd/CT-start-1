#!/usr/bin/env python3
from fractions import Fraction
from itertools import product, permutations
from hypertriangle_solver_aux import handle_request


def run():
    checks=0
    # Authority must be immutable across every mode.
    modes=["capabilities","route_simplex","route_transition","signed_polarity","b4_state","unknown"]
    for m in modes:
        r=handle_request({"mode":m,"payload":{}})
        assert r["truth_credit"]==0
        assert r["root_write_capability"]=="NONE"
        assert r["return_write_capability"]=="NONE"
        assert r["solver_mutation_capability"]=="NONE"
        checks += 4

    # Independent B4 cardinality and chamber-id uniqueness.
    ids=set()
    c={"common_scale_certified":True,"axis_independence_certified":True,"b4_comparable":True}
    axes=["a","b","c","d"]
    for s in product((-1,1),repeat=4):
        for p in permutations(range(4)):
            v=[0]*4
            mags=[11,7,5,2]
            for rank,i in enumerate(p): v[i]=s[i]*mags[rank]
            r=handle_request({"mode":"b4_state","payload":{"axis_ids":axes,"values":v,"contracts":c}})["receipt"]
            assert r["status"]=="B4_INTERIOR_CHAMBER"
            assert tuple(r["perm_descending"])==p
            assert len(r["neighbors"])==4
            ids.add(r["chamber_id"])
            checks += 3
    assert len(ids)==384; checks += 1

    # Exact finite route census, independent normalization identity.
    for w in product(range(4), repeat=4):
        req={"mode":"route_simplex","payload":{"cells":[{"id":f"x{i}","weight":w[i]} for i in range(4)]}}
        r=handle_request(req)["receipt"]
        total=sum(w)
        if total==0:
            assert r["status"]=="ZERO_ROUTE"
        else:
            assert r["status"]=="COMPILED_NUMERIC_ROUTE"
            comp=tuple(Fraction(x) if not isinstance(x,Fraction) else x for x in r["route"]["composition"])
            assert sum(comp,Fraction(0))==1
            assert r["active_arity"]==sum(x>0 for x in w)
        checks += 3

    # Dependency negative control.
    dep=handle_request({"mode":"route_simplex","payload":{"cells":[
        {"id":"T","weight":9},{"id":"S","weight":16},{"id":"COS","weight":25,"role":"DERIVED","derived_from":["T","S"]}
    ]}})["receipt"]
    assert dep["status"]=="DEPENDENCY_BLOCKED_AS_INDEPENDENT_POLES"; checks += 1
    return checks

if __name__=="__main__":
    n=run(); print(f"HYPERTRIANGLE_SOLVER_AUX independent: {n}/{n} PASS")
