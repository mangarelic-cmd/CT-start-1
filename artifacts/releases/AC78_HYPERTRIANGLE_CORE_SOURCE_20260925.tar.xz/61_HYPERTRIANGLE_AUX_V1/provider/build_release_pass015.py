from pathlib import Path
import hashlib, json, zipfile, sys
ROOT=Path(__file__).resolve().parent
META={'MANIFEST.json','CHECKSUMS.sha256','SHA256SUMS.txt'}
def sha(p): return hashlib.sha256(p.read_bytes()).hexdigest()
def base_files():
    out=[]
    for p in ROOT.rglob('*'):
        if not p.is_file(): continue
        rel=p.relative_to(ROOT).as_posix()
        if '__pycache__' in rel or rel.endswith('.pyc') or rel in META: continue
        out.append((rel,p))
    return sorted(out)
def write_meta():
    base=base_files(); lines=''.join(f"{sha(p)}  {rel}\n" for rel,p in base)
    (ROOT/'CHECKSUMS.sha256').write_text(lines,encoding='utf-8'); (ROOT/'SHA256SUMS.txt').write_text(lines,encoding='utf-8')
    items=sorted(base+[('CHECKSUMS.sha256',ROOT/'CHECKSUMS.sha256'),('SHA256SUMS.txt',ROOT/'SHA256SUMS.txt')])
    m={'branch':'HYPERTRIANGLE_SOLVER_AUX','pass':'PASS015','version':'1.0.0','date':'2026-09-25','status':'COMPLETE_STANDALONE_V1_FROZEN','external_solver_integration_performed':False,'truth_credit':0,'file_count':len(items),'files':[{'path':rel,'sha256':sha(p),'size':p.stat().st_size} for rel,p in items],'manifest_note':'MANIFEST.json excludes itself. CHECKSUMS.sha256 and SHA256SUMS.txt are identical and each excludes the three root metadata files to avoid recursive hashes.'}
    (ROOT/'MANIFEST.json').write_text(json.dumps(m,indent=2,sort_keys=True)+'\n',encoding='utf-8'); return m
def build(out):
    m=write_meta(); files=[]
    for p in ROOT.rglob('*'):
        if not p.is_file(): continue
        rel=p.relative_to(ROOT).as_posix()
        if '__pycache__' in rel or rel.endswith('.pyc'): continue
        files.append((rel,p))
    out=Path(out)
    with zipfile.ZipFile(out,'w',compression=zipfile.ZIP_DEFLATED,compresslevel=9) as z:
        for rel,p in sorted(files):
            zi=zipfile.ZipInfo(rel,date_time=(2026,9,25,12,0,0)); zi.compress_type=zipfile.ZIP_DEFLATED; zi.external_attr=(0o644 & 0xFFFF)<<16
            z.writestr(zi,p.read_bytes(),compress_type=zipfile.ZIP_DEFLATED,compresslevel=9)
    return out,m
if __name__=='__main__':
    out=sys.argv[1] if len(sys.argv)>1 else str(ROOT.parent/'HYPERTRIANGLE_SOLVER_AUX_PASS015_V1.0.0_20260925.zip')
    p,m=build(out); print(json.dumps({'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'size':p.stat().st_size,'manifest_files':m['file_count']},sort_keys=True))
