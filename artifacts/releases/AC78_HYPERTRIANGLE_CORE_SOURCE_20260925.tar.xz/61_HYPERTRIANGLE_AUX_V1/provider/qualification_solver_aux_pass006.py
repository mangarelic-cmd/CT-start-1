#!/usr/bin/env python3
import copy, random
import hypertriangle_solver_aux as h
checks=0
def ck(x,msg='qualification'):
    global checks
    checks+=1
    if not x: raise AssertionError(msg)
C={'common_scale_certified':True,'axis_independence_certified':True,'b4_comparable':True}
def st(vals,err='1/100'): return {'values':vals,'component_errors':[err]*4,'contracts':C}
def root(stream_id):
    s={'stream_id':stream_id,'requirements':{'required_state_slots':['S']},'receipts':[{'receipt_id':'r1','sequence':1,'slot':'S','kind':'state','payload':st([20,15,10,5])}]}
    return s,h.create_stream_checkpoint({'stream':s})['checkpoint']
def e(seq,bad=False):
    p=st([1000+seq,60,20,5]) if not bad else {'values':[1,2,3,4],'component_errors':[2,0,0,0],'contracts':C}
    return {'receipt_id':f'r{seq}','sequence':seq,'slot':'S','kind':'state','payload':p}
rng=random.Random(606606)
# Mixed campaigns, bounded active lineage with exact full-stream equivalence.
for case in range(120):
    stream,cp=root(f'q{case}'); full=copy.deepcopy(stream); chain=[cp]; seq=1; window=rng.randint(2,10)
    for rot in range(40):
        batch=[]
        for _ in range(rng.randint(1,3)):
            seq+=1; z=e(seq,bad=((case+rot+seq)%131==0)); batch.append(z); full['receipts'].append(copy.deepcopy(z))
        rr=h.rotate_bounded_checkpoint({'checkpoint':cp,'receipts':batch,'anchor_window_size':window})
        ck(rr['rotated']); cp=rr['checkpoint']; chain.append(cp)
        ck(h.validate_bounded_stream_checkpoint(cp)['checkpoint_valid'])
        ck(len(cp['lineage_anchors'])<=window)
        ck(cp['lineage_entry_count']==cp['rotation_index'])
        ck(cp['lineage_compacted_count']+len(cp['lineage_anchors'])==cp['rotation_index'])
        ck('checkpoint_lineage' not in cp)
    audit=h.validate_bounded_checkpoint_chain({'checkpoints':chain}); ck(audit['chain_valid'])
    replay=h.certify_receipt_stream(full); ck(cp['prefix_stream_hash']==replay['final_stream_hash']); ck(cp['current_terminal_at_checkpoint']==replay['current_terminal'])

# Long witness: 500 rotations. Lineage fields stay bounded; total checkpoint still grows because exact receipt IDs are retained.
stream,cp=root('long'); full=copy.deepcopy(stream); seq=1; window=8; lineage_sizes=[]; total_sizes=[]
for rot in range(500):
    seq+=1; z=e(seq); cp=h.rotate_bounded_checkpoint({'checkpoint':cp,'receipts':[z],'anchor_window_size':window})['checkpoint']; full['receipts'].append(copy.deepcopy(z))
    ck(len(cp['lineage_anchors'])<=window); ck(cp['lineage_entry_count']==rot+1); ck(cp['lineage_compacted_count']+len(cp['lineage_anchors'])==rot+1)
    view={k:cp[k] for k in ('checkpoint_lineage_mode','lineage_entry_count','lineage_compacted_count','lineage_prefix_accumulator','lineage_anchors','lineage_accumulator','lineage_anchor_window_size')}
    lineage_sizes.append(len(h._canonical_for_hash(view))); total_sizes.append(len(h._canonical_for_hash(cp)))
ck(len(cp['lineage_anchors'])==window); ck(cp['lineage_compacted_count']==492)
ck(max(lineage_sizes[100:])-min(lineage_sizes[100:]) < 256)
replay=h.certify_receipt_stream(full); ck(cp['prefix_stream_hash']==replay['final_stream_hash']); ck(cp['first_terminal_prefix']==1)
print(f'PASS006 qualification: {checks}/{checks} PASS')
print(f'long_rotations=500 receipts={seq} anchor_window={window} lineage_component_bytes_final={lineage_sizes[-1]} checkpoint_bytes_final={total_sizes[-1]}')
