#!/usr/bin/env python3
import copy, random
import hypertriangle_solver_aux as h
checks=0
def ck(x,msg='qualification'):
    global checks
    checks+=1
    if not x: raise AssertionError(msg)
C={'common_scale_certified':True,'axis_independence_certified':True,'b4_comparable':True}
def st(vals,bad=False):
    if bad: return {'values':[1,2,3,4],'component_errors':[2,0,0,0],'contracts':C}
    return {'values':vals,'component_errors':['1/100']*4,'contracts':C}
def rec(seq,slot='S',bad=False): return {'receipt_id':f'r{seq}','sequence':seq,'slot':slot,'kind':'state','payload':st([1000+seq,60,20,5],bad=bad)}
def root(sid):
    s={'stream_id':sid,'requirements':{'required_state_slots':['S']},'receipts':[{'receipt_id':'r1','sequence':1,'slot':'S','kind':'state','payload':st([20,15,10,5])}]}
    cp0=h.create_stream_checkpoint({'stream':s})['checkpoint']; r2=rec(2); cp6=h.rotate_bounded_checkpoint({'checkpoint':cp0,'receipts':[r2],'anchor_window_size':8})['checkpoint']; s['receipts'].append(copy.deepcopy(r2)); return s,cp6
rng=random.Random(707707)
# Random exact-index campaigns and negative proof checks.
for case in range(30):
    ids=[]; idx=h.ExternalReceiptIdIndex([])
    for j in range(30):
        rid=f'q{case}-{j}'; proof=idx.proof(rid); ck(not proof['present']); ck(h.verify_sparse_receipt_id_proof(idx.root,rid,proof,expected_present=False)['proof_valid']); before=idx.root
        out=idx.insert(rid); ck(out['inserted']); ids.append(rid);
        if j%10==0 or j==29: ck(idx.root==h.sparse_receipt_id_root(ids))
        # Historical ID must now produce membership, never a valid nonmembership proof.
        if j%10==0:
            dup=idx.proof(rid); ck(dup['present']); ck(not h.verify_sparse_receipt_id_proof(idx.root,rid,dup,expected_present=False)['proof_valid'])
# Mixed checkpoint campaigns.
for case in range(30):
    full,cp6=root(f'case{case}'); r=h.rotate_witnessed_checkpoint({'checkpoint':cp6,'receipts':[rec(3)]}); ck(r['rotated']); cp=r['checkpoint']; full['receipts'].append(rec(3)); idx=h.ExternalReceiptIdIndex(['r1','r2','r3'])
    sizes=[]
    for seq in range(4,24):
        bad=((case*53+seq)%211==0)
        e=rec(seq,bad=bad); proof=idx.proof(e['receipt_id']); rr=h.rotate_witnessed_checkpoint({'checkpoint':cp,'receipts':[e],'receipt_id_witnesses':[proof]}); ck(rr['rotated']); ck(h.validate_witnessed_checkpoint(rr['checkpoint'])['checkpoint_valid']);
        if seq%10==0: ck(h.validate_witnessed_checkpoint_transition({'previous_checkpoint':cp,'current_checkpoint':rr['checkpoint'],'proof_packet':rr['proof_packet']})['transition_valid'])
        cp=rr['checkpoint']; idx.insert(e['receipt_id']); full['receipts'].append(copy.deepcopy(e)); sizes.append(len(h._canonical_for_hash(cp))); ck(cp['receipt_id_root']==idx.root); ck('seen_receipt_ids' not in cp)
    replay=h.certify_receipt_stream(full); ck(cp['prefix_stream_hash']==replay['final_stream_hash']); ck(cp['first_terminal_prefix']==replay['first_terminal_prefix']); ck(max(sizes)-min(sizes)<2500)
# Long witness: 1000 witnessed rotations, exact external index, bounded checkpoint size.
full,cp6=root('long'); r=h.rotate_witnessed_checkpoint({'checkpoint':cp6,'receipts':[rec(3)]}); cp=r['checkpoint']; full['receipts'].append(rec(3)); idx=h.ExternalReceiptIdIndex(['r1','r2','r3']); sizes=[]
for seq in range(4,504):
    e=rec(seq); proof=idx.proof(e['receipt_id']); rr=h.rotate_witnessed_checkpoint({'checkpoint':cp,'receipts':[e],'receipt_id_witnesses':[proof]}); ck(rr['rotated']); cp=rr['checkpoint']; idx.insert(e['receipt_id']); sizes.append(len(h._canonical_for_hash(cp)))
    ck(cp['receipt_id_root']==idx.root); ck(cp['receipt_id_count']==seq)
ck('seen_receipt_ids' not in cp); ck(len(idx.ids)==503); ck(max(sizes[-500:])-min(sizes[-500:])<2500); ck(max(sizes)<25000)
print(f'PASS007 qualification: {checks}/{checks} PASS')
print(f'long_witnessed_rotations=500 receipt_id_count={cp["receipt_id_count"]} external_index_ids={len(idx.ids)} checkpoint_bytes_final={sizes[-1]} checkpoint_bytes_range_last500={max(sizes[-500:])-min(sizes[-500:])}')
