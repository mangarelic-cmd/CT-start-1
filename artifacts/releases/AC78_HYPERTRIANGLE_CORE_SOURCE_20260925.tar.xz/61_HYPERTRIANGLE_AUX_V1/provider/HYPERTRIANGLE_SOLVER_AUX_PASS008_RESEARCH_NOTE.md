# HyperTriangle Solver AUX — PASS008 Research Note

Date: 2026-09-25  
Branch: `HYPERTRIANGLE_SOLVER_AUX`  
Parent: PASS007 standalone AUX.  
Scope: persistent exact external receipt-ID sidecar, deterministic snapshots, append-only journal, crash recovery, compaction, and proof export. **No AC77/DD094 integration or mutation.**

## 1. Objective
PASS007 proved that an arbitrarily large exact `receipt_id` set cannot be represented by a fixed-size standalone checkpoint while preserving perfect membership. The bounded checkpoint therefore retained only a sparse-Merkle root and required an external exact index.

PASS008 turns that external index from an abstract contract into a separately auditable and recoverable sidecar.

The sidecar must support:

- deterministic export/import;
- exact root reconstruction;
- exact membership/non-membership proof generation;
- append-only persistence between snapshots;
- recovery after an interrupted final write;
- periodic compaction into a new generation snapshot;
- no ROOT/RETURN/solver authority.

## 2. Exact snapshot format
A PASS008 snapshot stores the exact sorted receipt-ID set. It therefore grows with the number of IDs; this is intentional and is the information-theoretic cost isolated by PASS007.

For an exact set `R`, the snapshot contains:

- `receipt_ids = sort(R)`;
- `receipt_id_count = |R|`;
- the PASS007 256-level sparse-Merkle `receipt_id_root`;
- a snapshot generation;
- optional parent snapshot and compacted-journal commitments;
- a domain-separated SHA-256 `snapshot_hash`;
- a journal seed derived from that snapshot hash.

The snapshot is deterministic: permutations of the same exact set produce byte-equivalent semantic content and the same authenticated root/hash.

## 3. Append-only journal
Between snapshots, each new receipt ID is persisted as one journal record containing:

- global exact sequence number;
- receipt ID;
- sparse-Merkle root before insertion;
- sparse-Merkle root after insertion;
- previous journal-record hash;
- owning snapshot hash;
- domain-separated journal-record hash.

Recovery replays the journal from the snapshot exact set and independently recomputes every insertion. A stale root, duplicate ID, sequence gap, generation mismatch, broken hash chain, or modified complete record is rejected.

## 4. Crash semantics
The filesystem sidecar uses newline-delimited JSON journal records.

The newline is the commit marker. Recovery may ignore exactly one final **uncommitted** line that lacks its terminating newline. This models a crash during the final append.

A newline-terminated record is committed. If such a record is malformed, has the wrong hash, wrong root transition, wrong sequence, or duplicate receipt ID, recovery fails hard. PASS008 never silently discards a committed semantic failure.

Snapshot files are written through a temporary file, `fsync`, and atomic `os.replace` before directory sync is attempted.

## 5. Compaction
`receipt_id_sidecar_compact` replays a snapshot plus its committed journal and emits a next-generation deterministic snapshot containing the complete exact ID set at the recovered root.

The next snapshot records:

- `parent_snapshot_hash`;
- `compacted_journal_tail_hash`;
- incremented generation.

The new journal starts empty from a new seed derived from the new snapshot hash.

Compaction bounds journal replay length between snapshots. It does **not** make the exact sidecar set constant-size; the exact snapshot itself grows with `|R|`.

## 6. File-sidecar interface
PASS008 adds `receipt_id_sidecar.py` and `receipt_id_sidecar_cli.py`.

CLI commands:

- `init SNAPSHOT JOURNAL [receipt_id ...]`;
- `append SNAPSHOT JOURNAL RECEIPT_ID`;
- `verify SNAPSHOT JOURNAL [--strict-tail]`;
- `proof SNAPSHOT JOURNAL RECEIPT_ID`;
- `compact SNAPSHOT JOURNAL NEW_SNAPSHOT NEW_JOURNAL`.

This is a standalone AUX-side storage tool. It is not a solver daemon and is not registered into AC77/DD094.

## 7. Provider modes
The generic provider adds pure/stateless modes:

- `receipt_id_sidecar_snapshot`;
- `validate_receipt_id_sidecar_snapshot`;
- `receipt_id_sidecar_recover`;
- `receipt_id_sidecar_append`;
- `receipt_id_sidecar_proof`;
- `receipt_id_sidecar_compact`.

These operate on supplied snapshot/journal objects and never mutate a solver.

## 8. Qualification witness
PASS008 qualification includes a deterministic exact snapshot containing 1,000 receipt IDs.

Witness:

- exact IDs: `1000`;
- snapshot canonical size: `13,669 bytes`;
- validated root: `393914a7bc6980ca7afd9fcbaaa9396bfd26c2b2ac9c440934a31e6ae5e2f81d`;
- present and absent proof generation: PASS.

This size is intentionally not claimed to be bounded with receipt count.

## 9. Authority firewall
Unchanged:

- `truth_credit = 0`;
- ROOT write capability = `NONE`;
- RETURN write capability = `NONE`;
- solver mutation capability = `NONE`;
- AC77 integration = `NOT_PERFORMED`;
- DD094 integration = `NOT_PERFORMED`.

## 10. Validation
- cumulative regression + unit tests: **105/105 PASS**;
- independent verifier: **2,030/2,030 PASS**;
- qualification: **2,336/2,336 PASS**;
- parent PASS007 nonmutable integrity: **135/135 byte-identical**;
- deterministic exact 1,000-ID snapshot import/proof witness: PASS;
- crash-tail recovery semantics: PASS;
- cold replay: **PASS**.

## 11. Next front
PASS009 should attack **sidecar snapshot-chain retention and bounded journal scheduling policy**: determine when to compact, how to audit a long sequence of sidecar generations efficiently, and whether snapshot-chain provenance itself should use the same bounded accumulator/anchor strategy already established for solver checkpoints.
