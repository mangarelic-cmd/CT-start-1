# AC78 HyperTriangle Memory Integration Core

AC78 extends the standalone SC_SOLVER AC77 by integrating the frozen `HYPERTRIANGLE_SOLVER_AUX` v1.0.0 as an explicit typed pre-ALL-AUX provider. The 99-mechanism registry is unchanged.

```text
hypertriangle_request -> frozen provider v1.0.0 -> typed receipt/current -> ALL-AUX context
SovereignSolver.hypertriangle(request) -> direct frozen-provider API
```

The memory direction is fixed: `data -> declared canonical invariant -> F001..F144 -> certified survivor -> declared activation -> typed capability`. AC78 does not infer slots from free text, does not feed capability outputs back into memory automatically, and grants HyperTriangle zero ROOT/RETURN/solver-mutation authority.

Validation: **109/109 inherited AC65-AC77 logical tests PASS; 10/10 AC78 tests PASS; AC78 qualification 13/13 PASS; AC77 qualification replay 12/12 PASS; independent integration verifier 14/14 PASS; 99/99 mechanisms preserved.**

Project boundary: DD094/PASS117 is **not** the AC78 parent. Its archive was only the storage carrier used to recover the self-contained `SC_SOLVER_AC77_PERIODIC_CARTESIAN_THEOREM_METROLOGY_CORE_20260922` runtime subtree. No PASS117 research logic was imported into the AC78 adapter.

---

# AC77 Periodic Cartesian Theorem Metrology Core

AC77 extends AC76 by integrating the Periodic Cartesian Theorem Table PASS053/PASS054 stack as a native **pre-ALL-AUX core service**. Exact theorem routes are now measured automatically in the frozen provider-relative theorem metric, decomposed through the certified Cartesian/local-chart geometry, and checked by a mandatory composition gate: **Pythagoras only under certified mutual orthogonality; otherwise Gram/law of cosines**.

Key interfaces:

```text
periodic_cartesian_request -> provider-typed distance/coherence certificate
theorem_route=[T...,T...] -> automatic pre-ALL-AUX route measurement
SovereignSolver.periodic_cartesian(request) -> direct API
```

Preserved firewalls:

```text
theorem identity T != route/periodic address P
provider metric != universal intrinsic metric
cross-provider arithmetic requires a certified adapter
local temporal chart != one fixed global time axis
geometry/metrology != theorem proof
periodic receipts add zero ROOT truth credit
```

Validation: **109/109 solver tests PASS in two exhaustive shards; AC77 qualification 12/12 PASS; AC76 qualification replay 9/9 PASS; 99/99 mechanisms preserved.** See `00_STATE/AC77_STATE.json`, `01_CONTRACT/AC77_PERIODIC_CARTESIAN_THEOREM_METROLOGY_CONTRACT.json`, `05_LINEAGE/CHANGELOG_AC77.md`, and `06_RECEIPTS/AC77_QUALIFICATION.json`.

---

# AC76 Semantic Constraint Unifier

AC76 extends AC75 with conservative semantic atomization and relation detection for external rule/constraint corpora. External benchmark rules are never promoted to CT axioms or ROOT truth. See `AC76_REPORT_FR.md`, `01_CONTRACT/AC76_SEMANTIC_CONSTRAINT_UNIFIER_CONTRACT.json`, and `06_RECEIPTS/AC76_QUALIFICATION.json`.

# SC Solver AC75 — Universal Constraint Carrier Core

AC75 extends AC74 without changing the 99-mechanism ALL-AUX registry.

The new pre-ALL-AUX carrier accepts mathematical routes exactly as before and additionally accepts declared rule/constraint systems:

```text
RULE / CONSTRAINT
 -> condition
 -> scope
 -> authority
 -> operator
 -> target
 -> exception
 -> precedence
 -> validation condition
 -> ACTIVE | REDUNDANT | CONFLICT_OPEN | OVERRIDDEN
 -> ALL-AUX
```

Firewalls:

```text
rule text != scientific truth
structural compilation != runtime applicability
missing precedence != permission to invent a winner
semantic ambiguity -> retained skin/residue
metric coordinate != Borges rank != transport coordinate
structural mirror != causal inverse
constraint carrier adds zero ROOT truth credit
```

Qualification:

```text
98/98 pytest PASS
AC75 qualification 13/13 PASS
Gold Standard 724/724 constraint routes compiled
Gold Standard auto_unresolved = 0
42 operator-semantic residues retained as skin
0 false ROOT / 0 false formal proof
AC68–AC74 regression qualifications PASS
99/99 mechanisms preserved
```

The AC74 CP026 canonical coordinate library remains active and unchanged in authority. AC75 adds a universal constraint carrier; it does not claim that arbitrary natural-language rules are automatically true or fully semantically disambiguated.
