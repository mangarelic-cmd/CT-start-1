# SC_SOLVER AC78 — HyperTriangle Memory Integration Core

AC78 is the standalone SC_SOLVER successor to AC77. It preserves the AC77 solver lineage and its 99-mechanism ALL-AUX registry while integrating the frozen `HYPERTRIANGLE_SOLVER_AUX v1.0.0` as an explicit typed pre-ALL-AUX provider.

## Source boundary

The logical parent is `SC_SOLVER_AC77_PERIODIC_CARTESIAN_THEOREM_METROLOGY_CORE_20260922`. The copy used for this build was recovered from the self-contained `runtime/AC77/` subtree of a downstream archive. No downstream DD094/PASS117 project logic, source, receipts, or solver policy is imported into AC78.

## HyperTriangle integration

- Frozen provider ZIP SHA-256: `fa82b76a200703afe38e1f3e6ecabe2b1cb363f4fbb89c34ca00adf24ea23295`.
- 144 fixed causal slots.
- 61 frozen provider capabilities.
- 35 frozen schemas.
- Explicit request field: `hypertriangle_request`.
- Direct API: `SovereignSolver.hypertriangle(request)`.
- HyperTriangle runs before ALL-AUX only when explicitly requested.
- Ordinary solver data is never implicitly classified into F001–F144.
- HyperTriangle output does not feed memory automatically.
- AUX terminality is local and cannot establish scientific ROOT.
- HyperTriangle adds zero truth credit and has no ROOT, RETURN, or solver-mutation authority.

## Preserved solver surface

- AC77 periodic-Cartesian service remains available.
- ALL-AUX registry remains 99 mechanisms; HyperTriangle is a provider core, not mechanism 100.
- Formal proof / ROOT authority remains sovereign to the existing solver logic.

## Validation before release packaging

- inherited AC65→AC77 logical regression: 109/109 PASS;
- new AC78 tests: 10/10 PASS;
- logical total: 119/119 PASS;
- AC78 qualification: 13/13 PASS;
- AC77 qualification replay on AC78: 12/12 PASS;
- independent integration verifier: 14/14 PASS;
- parent AC77 tracked files: 597, with 591 byte-identical and exactly 6 declared integration mutations;
- frozen HyperTriangle provider: 296/296 files byte-identical to its sealed ZIP.
