from __future__ import annotations
from typing import Any, Dict, Iterable, List

# AC71/CP019 theorem pack: scoped mathematical contracts for the twelve
# structural fronts exposed by CP018. These are core semantic receipts,
# not extra ALL-AUX mechanisms and not external scientific truth claims.

THEOREMS: Dict[str, Dict[str, Any]] = {
    'Q01_WEIGHT_LAW': {
        'title':'Carrier-relative cell-weight law',
        'verdict':'CLOSED_SCOPED_THEOREM',
        'operations':['BIND_SCIENTIFIC_CELL_WEIGHT'],
        'discharges':['UNIVERSAL_CELL_WEIGHT_BINDING_LAW','NO_INVENTED_METRIC_CERTIFICATE','LOCAL_TO_GLOBAL_ENERGY_COMPATIBILITY'],
        'statement':(
            'For a grounded cell displacement Delta_i in a typed metric carrier (E_i,g_i), '
            'the admissible energy weight is w_i=g_i(Delta_i,Delta_i). Under an isometric/pullback '
            'transport this value is invariant. Global route energy is the orthogonal direct-sum sum '
            'of the cell energies. If no authoritative metric/displacement exists, the only admissible '
            'state is SYMBOLIC_EXACT; operation count or display index is never a metric.'
        ),
        'conditions':['typed metric carrier','grounded displacement or residual current','transport receipt if charts differ'],
        'no_go':'There is no representation-independent numeric weight from an operator name alone.'
    },
    'Q02_COS_RESIDUAL_IDENTITY': {
        'title':'COS/FULL_DELTA geodesic disambiguation',
        'verdict':'CLOSED_BY_REFUTATION_AND_SCOPED_IDENTITY',
        'operations':['IDENTIFY_COS_WITH_TOTAL_CAUSAL_RESIDUAL'],
        'discharges':['COS_TOTAL_RESIDUAL_IDENTITY','INDEPENDENT_COS_EXTRACTION','NORM_EQUALITY_CELLWISE_AND_GLOBAL'],
        'statement':(
            'The universal identity COS = information-loss residue is false: a unitary representation '
            'change can have zero information-loss residue and nonzero causal displacement. If total causal '
            'residual means FULL_DELTA from current state to closed state in a common metric carrier, COS is '
            'the direct minimizing geodesic/current representing that net displacement when such a geodesic '
            'is defined. Its squared norm equals the sum of cell squared norms only under orthogonal direct-sum '
            'aggregation (or equivalent vanishing cross terms).'
        ),
        'conditions':['common metric/geodesic carrier','closed typed endpoints','orthogonal lift for cellwise energy sum'],
        'no_go':'Do not identify COS with the mere sum of information-loss residues or with route arclength in general.'
    },
    'Q03_EDGE_GATE_CLASSIFIER': {
        'title':'Intrinsic edge/gate/COS classifier',
        'verdict':'CLOSED_CLASSIFIER_CONTRACT',
        'operations':['CLASSIFY_GRID_ROLE'],
        'discharges':['INTRINSIC_EDGE_GATE_COS_CLASSIFIER','QUADRATURE_SIGNATURE_CERTIFICATE','LONGITUDINAL_SIGNATURE_CERTIFICATE'],
        'statement':(
            'Relative to an orthogonal local split V=T direct_sum S and mirror reflection R, a RIGHT_ANGLE_GATE '
            'is certified when the active map exchanges T and S, is metric-isometric on the active plane, and '
            'satisfies J^2=-I there. A COS direction lies in the +1 fixed subspace of R. Remaining longitudinal '
            'moves are classified TIME_EDGE or SPACE_EDGE by preserved subbundle plus grounded dominance/orientation; '
            'the space class is the R-conjugate of the time class. Ambiguous or mixed maps remain MIXED_TYPED rather '
            'than being forced into one class.'
        ),
        'conditions':['typed T/S split','metric','mirror/reflection orientation'],
        'no_go':'Labels such as Fourier, time, or space are not classifiers by themselves.'
    },
    'Q04_MINIMAL_RESIDUE': {
        'title':'Minimal residue as fibre-separating information',
        'verdict':'CLOSED_EXISTENCE_AND_CANONICALITY_SCOPE',
        'operations':['COMPUTE_MINIMAL_CAUSAL_RESIDUE'],
        'discharges':['MINIMAL_RESIDUE_EXISTENCE','CANONICAL_RESIDUE_CRITERION','RESIDUE_COST_OR_DIMENSION'],
        'statement':(
            'For O:X->Y, a residue rho is sufficient exactly when rho restricted to every fibre O^{-1}(y) is injective. '
            'Thus a reversible lift x |-> (O(x),rho(x)) exists whenever the fibres admit the chosen encoding. There is '
            'no canonical smallest scalar residue without a declared category/cost/section. In a Hilbert linear carrier, '
            'the canonical orthogonal residue is P_ker(O) x. For a smooth regular map the local residue dimension is the '
            'fibre dimension dim X-rank dO. For a finite set, worst-case fixed-length residue requires at least '
            'ceil(log2(max_y |O^{-1}(y)|)) bits.'
        ),
        'conditions':['declared structure/cost notion for canonical minimality'],
        'no_go':'A universal canonical scalar residue for arbitrary deterministic maps does not exist without extra structure.'
    },
    'Q05_NONLINEAR_PYTHAGORE': {
        'title':'Nonlinear orthogonal-completion criterion',
        'verdict':'CLOSED_RIEMANNIAN_PULLBACK_THEOREM',
        'operations':['NONLINEAR_ORTHOGONAL_RESIDUE_SPLIT'],
        'discharges':['NONLINEAR_ORTHOGONAL_COMPLETION','PULLBACK_METRIC_CONDITION','LOCAL_TO_GLOBAL_CROSS_TERM_CONTROL'],
        'statement':(
            'For smooth F:(M,g)->(N,h), let V=ker dF and H=V^perp. Infinitesimal Pythagoras holds from the orthogonal '
            'split. If F is a Riemannian submersion on H, ||v||_g^2=||dF(v_H)||_h^2+||v_V||_g^2. A finite nonlinear '
            'output+residue completion Phi=(F,rho):M->N x R has exact product-metric Pythagoras iff '
            'g=F^*h+rho^*k (equivalently Phi is an isometric immersion/embedding on the declared scope). Global endpoint '
            'Pythagoras requires an integrable/product or otherwise cross-term-free geometry; otherwise path-energy '
            'decomposition is the safe invariant.'
        ),
        'conditions':['smooth regular scope','declared Riemannian metrics','product/pullback receipt for global finite relation'],
        'no_go':'Nonlinearity alone does not preserve endpoint Pythagoras.'
    },
    'Q06_INFINITE_DIMENSION_MIRROR': {
        'title':'Hilbert/Banach mirror-plus-residue theorem',
        'verdict':'CLOSED_HILBERT_THEOREM_BANACH_CONDITIONAL',
        'operations':['INFINITE_DIMENSIONAL_MIRROR_COMPLETION'],
        'discharges':['HILBERT_BANACH_MIRROR_THEOREM','DOMAIN_CODOMAIN_CERTIFICATE','CLOSED_RANGE_OR_GENERALIZED_INVERSE_CONDITIONS'],
        'statement':(
            'For a bounded operator A:H->K between Hilbert spaces, H=ker A direct_sum closure(ran A*) and '
            'x=A^dagger A x + P_ker(A)x on the natural Moore-Penrose domain; the terms are orthogonal. If ran A is closed, '
            'A^dagger is bounded and the mirror completion is stable. For densely defined closed unbounded A the same '
            'decomposition is domain-sensitive and A^dagger is generally unbounded; closed range again gives boundedness '
            'on the appropriate carrier. In Banach spaces there is no canonical orthogonal residue: a bounded generalized '
            'inverse requires complemented kernel/range (or an explicitly chosen splitting), and Pythagoras requires '
            'additional Hilbert/metric structure.'
        ),
        'conditions':['domain/codomain certificate','closed/densely-defined conditions as applicable','closed range for bounded stable generalized inverse'],
        'no_go':'Do not transport Hilbert orthogonality canonically into an arbitrary Banach space.'
    },
    'Q07_THEOREM_STEP_TYPING': {
        'title':'Theorem application as a causal-grid cell',
        'verdict':'CLOSED_TYPING_CONTRACT',
        'operations':['APPLY_THEOREM'],
        'discharges':['THEOREM_APPLICATION_CAKE_PLATE_TYPING','PROOF_DEPENDENCY_RESIDUE','THEOREM_STEP_METRIC_POLICY'],
        'statement':(
            'Plate = formal context (logic, signature, axioms, domains); cake = current proof/goal state; operator = theorem '
            'plus instantiation/substitution; controls = side conditions/unification/type obligations; residue = unresolved '
            'premises, discharged-assumption ledger, dependency/provenance and any branch information; mirror = structural '
            'dependency replay/elaboration, not logical converse. Metric weight remains symbolic unless the proof system '
            'declares an authoritative cost/energy metric.'
        ),
        'conditions':['kernel-checkable theorem object or authority','typed instantiation','side-condition ledger'],
        'no_go':'A theorem name or proof-line count is not a causal distance.'
    },
    'Q08_TOPOLOGICAL_QUOTIENT': {
        'title':'Quotient/gauge/covering grid typing',
        'verdict':'CLOSED_TOPOLOGICAL_LIFT_CONTRACT',
        'operations':['QUOTIENT_OR_GAUGE_MOVE'],
        'discharges':['TOPOLOGICAL_QUOTIENT_GRID_TYPING','FIBRE_RESIDUE_OR_GAUGE_LEDGER','SECTION_OR_LIFT_MIRROR'],
        'statement':(
            'For a quotient pi:X->X/~, the visible cake is the equivalence class and the residue needed for reconstruction is '
            'a fibre/orbit coordinate relative to a chosen section/gauge. For a group action, x=g.s([x]) locally; the residue '
            'is g modulo stabilizer. A global exact mirror exists only when a global section/trivialization (or equivalent lift '
            'data) exists. Coverings require sheet/basepoint/path-lift/monodromy data. Gauge quotients require gauge-fixing '
            'plus transition/holonomy ledger. With a Riemannian submersion, horizontal/vertical components provide the '
            'orthogonal Pythagorean split.'
        ),
        'conditions':['equivalence/group action typed','local/global section status','transition/holonomy provenance'],
        'no_go':'A nontrivial quotient cannot be globally inverted from the class alone.'
    },
    'Q09_SU_PHI5_WEIGHT_BINDING': {
        'title':'Conditional SU/Phi5-to-grid metric bridge',
        'verdict':'CLOSED_CONDITIONAL_BRIDGE_UNCONDITIONAL_NO_GO',
        'operations':['BIND_PHI5_TO_GRID_METRIC'],
        'discharges':['SU_PHI5_TO_CELL_WEIGHT_INTERTWINER','OPERATOR_TO_PHI5_PROJECTION','METRIC_PRESERVATION_RECEIPT'],
        'statement':(
            'Given a typed operator/state projection Psi into Phi5 coordinates s and the declared metric G, the exact cell '
            'energy is w=(Delta s)^T G (Delta s). A mirror M preserves the weight exactly when M^T G M=G. This is an exact '
            'conditional intertwiner. The current corpus does not supply a universal Psi from arbitrary solver operators into '
            'Phi5; therefore an unconditional arbitrary-operation bridge is not derivable. Missing Psi remains an explicit '
            'operator-to-Phi5 adapter obligation.'
        ),
        'conditions':['typed Psi projection','Phi5 metric G','metric-preserving mirror/transport'],
        'no_go':'Phi5 coordinates cannot be assigned to an arbitrary operator merely by semantic resemblance.'
    },
    'Q10_PRIMEGRID_TEMPORAL_Q': {
        'title':'PrimeGrid/Temporal order-to-q no-go and weighted construction',
        'verdict':'CLOSED_NO_GO_PLUS_CONDITIONAL_MAP',
        'operations':['BIND_PRIMEGRID_TEMPORAL_TO_Q'],
        'discharges':['PRIMEGRID_TEMPORAL_Q_INTERTWINER','ORDER_PRESERVATION','NO_ARBITRARY_INDEX_METRIC'],
        'statement':(
            'PrimeGrid stage/ray plus Temporal phase/order can determine precedence and branch identity, but order alone cannot '
            'determine a unique normalized metric coordinate q: infinitely many strictly increasing embeddings into [0,1] '
            'preserve the same order. Once grounded nonnegative cell weights w_i with positive total are supplied, the unique '
            'normalized cumulative address is q_k=(sum_{i<=k} w_i)/(sum_i w_i). Thus PrimeGrid/Temporal provides the order; '
            'the metric layer provides the spacing.'
        ),
        'conditions':['grounded weights for metric q','order/phase receipt from PrimeGrid+Temporal'],
        'no_go':'Never use stage number, prime index, or cycle index as distance without a metric bridge.'
    },
    'Q11_PROSE_TO_ROUTE': {
        'title':'Fail-closed prose-to-route compiler contract',
        'verdict':'CLOSED_COMPILER_SPECIFICATION',
        'operations':['COMPILE_PROSE_TO_ROUTE'],
        'discharges':['PROSE_SEMANTIC_ROUTE_COMPILER','DOMAIN_LAW_AUTHORITY','AMBIGUITY_RESIDUE'],
        'statement':(
            'A safe compiler is a staged relation, not an unrestricted guesser: (1) parse literal equations/quantifiers/units '
            'and candidate entities; (2) produce all compatible cake/plate/operator/control typings; (3) bind transformations '
            'only to registered domain laws/theorems/adapters; (4) preserve unresolved references, branch choices, units and '
            'competing parses as AMBIGUITY_RESIDUE; (5) compile a route only when mandatory typing and authority fields are '
            'grounded; otherwise emit a typed route-extraction current to ALL-AUX. Provenance for every binding is mandatory.'
        ),
        'conditions':['registered domain-law authority for nontrivial transformations','lossless ambiguity ledger'],
        'no_go':'Free prose does not authorize invention of a domain law.'
    },
    'Q12_COMPLETENESS': {
        'title':'Declared-class causal-grid completeness criterion',
        'verdict':'CLOSED_DECLARED_CLASS_CRITERION',
        'operations':['CERTIFY_ATLAS_SATURATION'],
        'discharges':['CAUSAL_GRID_COMPLETENESS_CRITERION','COVERAGE_UNIVERSE_CERTIFICATE','NO_NEW_SEMANTIC_CELL_FIXED_POINT'],
        'statement':(
            'The atlas is complete only relative to a declared problem class C and a declared generator/authority universe U. '
            'A completeness certificate requires: sound typed compilation; coverage of every primitive semantic cell/transition '
            'in U (by enumeration or proof schema); closure of all generated routes under the declared transformations; '
            'semantic fixed point modulo proven equivalence; retained negative knowledge preventing renamed dead routes; '
            'zero untyped/unclassified residual families; and replay/independent verification. A finite empirical fixed point '
            'cannot certify all mathematics; infinite classes require an induction/proof schema establishing coverage.'
        ),
        'conditions':['declared class C','declared universe U','coverage proof/enumeration','semantic equivalence relation'],
        'no_go':'No universal all-mathematics completeness claim follows from a finite runtime saturation.'
    },
}

BY_OPERATION = {op:key for key,t in THEOREMS.items() for op in t.get('operations',[])}
BY_REQUIREMENT = {req:key for key,t in THEOREMS.items() for req in t.get('discharges',[])}


def match_theorems(payload: Dict[str, Any]) -> List[Dict[str, Any]]:
    op = str(payload.get('operation') or payload.get('operator') or '').upper()
    reqs = {str(x) for x in (payload.get('requires') or [])}
    keys=[]
    if op in BY_OPERATION:
        keys.append(BY_OPERATION[op])
    for r in sorted(reqs):
        if r in BY_REQUIREMENT:
            keys.append(BY_REQUIREMENT[r])
    out=[]
    for k in dict.fromkeys(keys):
        t=dict(THEOREMS[k]); t['theorem_id']=k
        out.append(t)
    return out


def theorem_supplies(payload: Dict[str, Any]) -> List[str]:
    out=[]
    for t in match_theorems(payload):
        out.extend(t.get('discharges') or [])
    return list(dict.fromkeys(out))
