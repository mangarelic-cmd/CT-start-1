from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Dict, Iterable, Callable, Tuple, List
from causal_grid_core import CausalGridCore
import hashlib, json
STATUSES = {'PASS', 'OPEN', 'PARTIAL', 'INVALID', 'NOT_APPLICABLE', 'NEED_DATA', 'MISSING_CARRIER', 'COUNTEREXAMPLE', 'CAPABILITY_GAP', 'WAITING'}
STRATEGIES = ('DECOMPOSE', 'REENCODE', 'DUALIZE', 'CONSTRUCT_CARRIER', 'FORMALIZE_OR_REFUTE')
_OBLIGATION_FAMILIES = {'MATERIAL_SPECIFICATION': 4, 'PROVIDER_SPECIFICATION': 4, 'RELATION_SIGNATURE': 4, 'CARRIER_SPECIFICATION': 4, 'RECOVERY_EVIDENCE': 3, 'RECONSTRUCTION_RULE': 3, 'EXACT_INTERVAL_DATA': 3, 'EXACT_NEWTON_TRANSITION_DATA': 3, 'DUAL_OR_OBSTRUCTION_WITNESS': 3, 'FAULT_LOCATION': 3, 'DELTA_CANDIDATE': 3, 'FORMAL_GOAL': 2, 'SUPPORTED_FORMALIZATION': 2, 'ADAPTER_SPECIFICATION': 2, 'COMPLETE_CONSTRUCTION': 1, 'COMPLETE_DUAL_OR_OBSTRUCTION': 1, 'DISAMBIGUATING_CONSTRAINT': 2, 'COMPLETE_PROOF_OBJECT': 1, 'EXTERNAL_DEFINITION': 1, 'KERNEL_VERIFIED_PROOF': 0, 'COMPLETE_CLOSURE': 0}
_FAMILY_ORDER = {k: i for i, k in enumerate(_OBLIGATION_FAMILIES)}
REPRESENTATION_FAMILIES = {'FORMAL_GOAL', 'SUPPORTED_FORMALIZATION', 'ADAPTER_SPECIFICATION', 'MATERIAL_SPECIFICATION', 'PROVIDER_SPECIFICATION', 'RELATION_SIGNATURE', 'CARRIER_SPECIFICATION', 'RECONSTRUCTION_RULE'}
BRIDGE_FAMILIES = {'RECOVERY_EVIDENCE', 'DUAL_OR_OBSTRUCTION_WITNESS'}
SCIENTIFIC_LEAF_FAMILIES = {'COMPLETE_CONSTRUCTION', 'COMPLETE_DUAL_OR_OBSTRUCTION', 'COMPLETE_PROOF_OBJECT', 'EXACT_INTERVAL_DATA', 'EXACT_NEWTON_TRANSITION_DATA', 'DISAMBIGUATING_CONSTRAINT', 'EXTERNAL_DEFINITION', 'KERNEL_VERIFIED_PROOF', 'COMPLETE_CLOSURE'}

def split_requirement(req: str):
    parts = [x for x in str(req).split('::') if x]
    wrappers = []
    while parts and parts[0] in _OBLIGATION_FAMILIES:
        wrappers.append(parts.pop(0))
    base = '::'.join(parts) if parts else wrappers[-1] if wrappers else str(req)
    return (wrappers, base)

def normalize_requirement(req: str) -> str:
    wrappers, base = split_requirement(req)
    if not wrappers:
        return str(req)
    fam = min(wrappers, key=lambda x: (_OBLIGATION_FAMILIES[x], _FAMILY_ORDER[x]))
    return f'{fam}::{base}' if base and base != fam else fam

def obligation_rank(req: str) -> int:
    wrappers, _ = split_requirement(normalize_requirement(req))
    return _OBLIGATION_FAMILIES[wrappers[0]] if wrappers else 6

def requirement_wrapper_depth(req: str) -> int:
    wrappers, _ = split_requirement(req)
    return len(wrappers)

def requirement_family(req: str) -> str:
    wrappers, _ = split_requirement(normalize_requirement(req))
    return wrappers[0] if wrappers else 'RAW_SCIENTIFIC'

def canon(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False, default=str)

def digest(x):
    return hashlib.sha256(canon(x).encode()).hexdigest()

def context_prefix(a: Tuple[str, ...], b: Tuple[str, ...]) -> bool:
    return len(a) <= len(b) and tuple(b[:len(a)]) == tuple(a)

def contexts_compatible(a: Tuple[str, ...], b: Tuple[str, ...]) -> bool:
    a = tuple(a)
    b = tuple(b)
    if not a or not b:
        return True
    return context_prefix(a, b) or context_prefix(b, a)

def context_can_supply(provider: Tuple[str, ...], consumer: Tuple[str, ...]) -> bool:
    provider = tuple(provider)
    consumer = tuple(consumer)
    if not provider:
        return True
    return context_prefix(provider, consumer)

@dataclass(frozen=True)
class Node:
    kind: str
    payload: Dict[str, Any]
    parents: Tuple[str, ...] = ()
    wave: int = 0
    context: Tuple[str, ...] = ()

    def identity(self):
        return digest({'kind': self.kind, 'payload': self.payload, 'parents': sorted(self.parents), 'context': list(self.context)})

    def semantic_identity(self):
        return digest({'kind': self.kind, 'payload': self.payload, 'context': list(self.context)})

    def to_dict(self):
        d = asdict(self)
        d['id'] = self.identity()
        d['semantic_id'] = self.semantic_identity()
        return d

@dataclass(frozen=True)
class MechanismResult:
    mechanism: str
    status: str
    result_kind: str
    payload: Dict[str, Any]
    input_node: str

    def as_node(self, wave, context: Tuple[str, ...]=()):
        def clean(x):
            if isinstance(x, dict): return {k:clean(v) for k,v in x.items()}
            if isinstance(x, list): return [clean(v) for v in x]
            if isinstance(x, tuple): return tuple(clean(v) for v in x)
            return x
        p=clean(dict(self.payload))
        return Node(self.result_kind, {'mechanism':self.mechanism,'status':self.status,**p}, (self.input_node,), wave, tuple(context))

AuxResult = MechanismResult

class ResourceCutoff(RuntimeError):
    pass

class AllEverythingWaveEngine:
    """AC66 cross-problem ALL-AUX + mechanical proof reconstruction engine.

    Every registered mechanism sees every active node. Dependency labels remain descriptive
    metadata only. They are never compiled into gating currents. Scientific continuation is
    carried by observable residual/current nodes plus automatic causal-geometric closure.
    """

    def __init__(self, registry: Dict[str, Callable], correlation: Callable):
        self.registry = dict(sorted(registry.items()))
        self.correlation = correlation
        self.executed = set()
        self.known = {}
        self.log = []
        self.calls = 0
        from target_grain_router import TargetGrainRouter
        self.grain_router = TargetGrainRouter()
        self.discovery_result_count = 0
        self.active_grain_count = 0
        self.dormant_relation_count = 0
        self.compacted_dormant_node_count = 0
        self.dormant_flag_replay_count = 0
        self.scientific_common_trunk = {}
        self.causal_grid_core = CausalGridCore()
        self.core_grid_receipt_count = 0
        self.core_grid_cell_count = 0
        self.core_grid_residue_count = 0

    def publish(self, n: Node, constraints=None):
        # AC66 keeps provenance-rich semantic nodes, but also builds a content-addressed
        # scientific common trunk so wrappers/metadata do not masquerade as new science.
        from automation_reconciliation_ac66 import scientific_signature
        ssig = scientific_signature(n)
        row = self.scientific_common_trunk.setdefault(ssig, {'count': 0, 'node_ids': [], 'kinds': set()})
        row['count'] += 1
        row['node_ids'].append(n.identity())
        row['kinds'].add(n.kind)
        sid = n.semantic_identity()
        old = self.known.get(sid)
        if old is None:
            self.known[sid] = n
            return n
        parents = tuple(sorted(set(old.parents + n.parents)))
        if parents != old.parents:
            old = Node(old.kind, old.payload, parents, max(old.wave, n.wave), old.context)
            self.known[sid] = old
        return old

    def semantic_signature(self):
        return tuple(sorted(self.known.keys()))

    def _execute(self, node: Node, world: Dict[str, Any], wave: int, max_calls: int):
        out = []
        ctx = digest({'context': list(node.context), 'version': world.get('context_version', 0), 'generation': world.get('knowledge_generation', 'AC64')})
        for aid, fn in self.registry.items():
            key = (node.semantic_identity(), aid, ctx)
            if key in self.executed:
                continue
            if self.calls >= max_calls:
                raise ResourceCutoff(f'max_calls={max_calls}')
            self.executed.add(key)
            self.calls += 1
            r = fn(node, world)
            if r.status not in STATUSES:
                raise ValueError('untyped status ' + str(r.status))
            rn = r.as_node(wave + 1, node.context)
            out.append(rn)
            self.log.append({'wave': wave, 'node': node.identity(), 'semantic_node': node.semantic_identity(), 'context': list(node.context), 'mechanism': aid, 'status': r.status, 'result_semantic': rn.semantic_identity()})
        return out

    @staticmethod
    def _dedup(nodes):
        groups = {}
        for n in nodes:
            sid = n.semantic_identity()
            if sid not in groups:
                groups[sid] = [n, set(n.parents)]
            else:
                groups[sid][1].update(n.parents)
        return [Node(n.kind, n.payload, tuple(sorted(parents)), n.wave, n.context) for _, (n, parents) in sorted(groups.items())]

    def compile_semantic_projection_currents(self, nodes: Iterable[Node], wave: int) -> List[Node]:
        """Flatten AC66 semantic projection bundles into executable AUX-language currents.

        This fixes the old 'broadcast the opaque object to everyone' failure: mechanisms receive
        top-level typed fields in subsequent waves rather than a projection bundle nobody consumes.
        """
        out=[]
        for b in nodes:
            if b.kind != 'SEMANTIC_PROJECTION_BUNDLE' or b.payload.get('status') != 'PASS':
                continue
            views=b.payload.get('views') or {}
            if not isinstance(views,dict):
                continue
            for name,view in sorted(views.items()):
                if not isinstance(view,dict):
                    continue
                payload={k:v for k,v in view.items() if v not in (None,[],{},'')}
                payload.update({
                    'status':'OPEN',
                    'scientific_focus':True,
                    'ac66_projection_materialized':True,
                    'projection_view':str(name),
                    'projection_source_bundle':b.identity(),
                    'statement':payload.get('statement') or f'AC66_{name}_SEMANTIC_PROJECTION',
                    'inherited_sovereign_root_id':payload.get('sovereign_root_id') or None,
                })
                out.append(Node('SCIENTIFIC_CURRENT',payload,(b.identity(),),wave,tuple(b.context)))
        return self._dedup(out)

    def compile_parent_reactivations(self, returns: Iterable[Node], wave: int) -> List[Node]:
        out = []
        by_id = {n.identity(): n for n in self.known.values()}
        for rr in returns:
            if rr.kind != 'NODE_RETURN_RECEIPT':
                continue
            for pid in rr.payload.get('parent_node_ids') or []:
                p = by_id.get(str(pid))
                if p is None:
                    continue
                payload = dict(p.payload)
                payload['resume_after_child_return'] = True
                payload['child_return_receipt'] = rr.identity()
                out.append(Node(p.kind, payload, (rr.identity(),), wave, tuple(p.context)))
        return out

    def run_wave(self, frontier: Iterable[Node], world: Dict[str, Any], wave: int, max_calls: int):
        frontier = [self.publish(n) for n in frontier]
        world.setdefault('knowledge_generation', 'AC78_HYPERTRIANGLE_MEMORY_INTEGRATION_CORE')
        # AC71 CORE HOOK: every active node is typed/projected before ALL-AUX.
        # This is non-blocking: original nodes continue even when typing is incomplete.
        if world.get('causal_grid_core_enabled', True):
            execution_frontier, core_nodes = self.causal_grid_core.enrich_frontier(frontier, world, wave)
        else:
            execution_frontier, core_nodes = list(frontier), []
        for n in execution_frontier:
            self.publish(n)
        for n in core_nodes:
            self.publish(n)
        self.core_grid_receipt_count += sum(1 for n in core_nodes if n.kind=='CAUSAL_GRID_CORE_RECEIPT')
        self.core_grid_cell_count += sum(1 for n in core_nodes if n.kind=='CAUSAL_GRID_CELL')
        self.core_grid_residue_count += sum(1 for n in core_nodes if n.kind=='CAUSAL_GRID_RESIDUE_CURRENT')
        raw = []
        for node in sorted(execution_frontier, key=lambda n: (n.context, n.semantic_identity(), n.identity())):
            raw.extend(self._execute(node, world, wave, max_calls))
        raw2 = self._dedup(core_nodes + raw)
        for n in raw2:
            self.publish(n)
        projection_currents = self.compile_semantic_projection_currents(raw2, wave + 1)
        for n in projection_currents:
            self.publish(n)
        corr = list(self.correlation(raw2 + projection_currents, wave + 1, self.known, world))
        for n in corr:
            self.publish(n)
        self.discovery_result_count += len(raw2) + len(corr)
        active, decisions = self.grain_router.route(execution_frontier, raw2 + projection_currents + corr, self.known, world)
        closure = self.grain_router.closure_requests(execution_frontier, self.known, wave + 1)
        for n in closure:
            self.publish(n)
        closure_results = []
        if closure:
            for n in closure:
                closure_results.extend(self._execute(n, world, wave + 1, max_calls))
            closure_results = self._dedup(closure_results)
            for n in closure_results:
                self.publish(n)
            active2, _ = self.grain_router.route(closure, closure_results, self.known, world)
            active.extend(active2)
        returns = [n for n in active + closure_results if n.kind == 'NODE_RETURN_RECEIPT']
        parent_returns = self.compile_parent_reactivations(returns, wave + 2)
        for n in parent_returns:
            self.publish(n)
        active.extend(parent_returns)
        nxt = {n.semantic_identity(): n for n in active if n.payload.get('status') != 'NOT_APPLICABLE'}
        self.active_grain_count += len(nxt)
        self.dormant_relation_count += sum((1 for d in decisions.values() if not d.active))
        self.semantic_history = getattr(self, 'semantic_history', [])
        self.semantic_history.append(self.semantic_signature())
        return (list(nxt.values()), raw2, projection_currents + corr + closure + closure_results + parent_returns)
