from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, List, Optional, Sequence
import hashlib
import json
import math

import numpy as np

from pass053_provider_typed_distance_api import (
    DEFAULT_PROVIDER,
    ProviderTypedDistanceEngine,
    DistanceAPIError,
    InvalidRequestError,
)

SCHEMA_DISTANCE = "PASS054_CARTESIAN_COHERENT_DISTANCE_CERTIFICATE_V1"
SCHEMA_ROUTE = "PASS054_CARTESIAN_COHERENT_ROUTE_CERTIFICATE_V1"
DIMENSION = 1302
# Dimension-aware floating point orthogonality gate. This is a numerical
# certification tolerance, not a physical or semantic threshold.
ORTHOGONALITY_COSINE_TOL = 64.0 * np.finfo(float).eps * DIMENSION


class CartesianCoherenceError(DistanceAPIError):
    code = "CARTESIAN_COHERENCE_ERROR"


def _canonical_json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _certificate_id(prefix: str, payload: Dict[str, Any]) -> str:
    return prefix + hashlib.sha256(_canonical_json_bytes(payload)).hexdigest()[:24]


class CartesianSpaceTimeCoherenceEngine:
    """PASS054 coherence gate over the frozen PASS053 theorem metric.

    It adds a nested Cartesian decomposition to every theorem-pair distance:

        d_native^2 = ||q4||^2 + ||r||^2
                   = ||q4||^2 + DeltaTau_chart^2 + ||DeltaSpace_chart||^2.

    Chart A and chart B are the local scalar-time charts certified by PASS048/049.
    They are local coordinate charts, not a claim of one universal global time axis.

    For multi-leg theorem routes, Pythagoras is *not* assumed. It is certified only
    when all nonzero leg vectors are mutually orthogonal within a dimension-aware
    numerical tolerance. Otherwise the exact Gram/law-of-cosines composition is used.
    """

    def __init__(self, root: Path | str):
        self.root = Path(root)
        self.base = ProviderTypedDistanceEngine(self.root)
        self.q4 = self.base.q4
        reg = self.root / "55_PASS049_EXACT_CHART_TRANSITION_INTERTWINER/REGISTRY"
        self.a = np.load(reg / "PASS049_TEMPORAL_AXIS_A_1302.npy")
        self.b = np.load(reg / "PASS049_TEMPORAL_AXIS_B_1302.npy")
        self.v = np.load(reg / "PASS049_SHARED_PLANE_AXIS_V_1302.npy")
        self.w = np.load(reg / "PASS049_CHART_B_SPATIAL_PLANE_AXIS_W_1302.npy")
        theorem = json.loads((reg / "PASS049_CHART_TRANSITION_THEOREM.json").read_text(encoding="utf-8"))
        self.T_A_to_B = np.asarray(theorem["T_A_to_B_2x2"], dtype=float)
        self.T_B_to_A = np.asarray(theorem["T_B_to_A_2x2"], dtype=float)
        self.theta_degrees = float(theorem["theta_degrees"])
        self.transition_claim_ceiling = theorem["claim_ceiling"]

    def _chart_decomposition(self, delta: np.ndarray, temporal: np.ndarray, plane_spatial: np.ndarray, chart: str) -> Dict[str, Any]:
        q = self.q4.T @ delta
        parent = self.q4 @ q
        r = delta - parent
        d2 = float(delta @ delta)
        q2 = float(q @ q)
        r2 = float(r @ r)
        tau = float(temporal @ r)
        sigma = float(plane_spatial @ r)
        h = r - tau * temporal - sigma * plane_spatial
        h2 = float(h @ h)
        spatial_vec = sigma * plane_spatial + h
        spatial2 = float(spatial_vec @ spatial_vec)
        # Two equivalent receipts are kept: coordinate-square form and actual
        # reconstructed spatial-vector norm. Their difference audits numerical
        # orthogonality of the frame.
        spatial2_coordinate = float(sigma * sigma + h2)
        child_coord_err = abs(r2 - (tau * tau + spatial2_coordinate))
        child_vector_err = abs(r2 - (tau * tau + spatial2))
        full_coord_err = abs(d2 - (q2 + tau * tau + spatial2_coordinate))
        full_vector_err = abs(d2 - (q2 + tau * tau + spatial2))
        time_space_dot = float((tau * temporal) @ spatial_vec)
        reconstruct = parent + tau * temporal + spatial_vec
        return {
            "chart": chart,
            "temporal_semantics": "PASS048_LOCAL_SCALAR_TEMPORAL_COORDINATE_CANDIDATE",
            "spatial_semantics": "ORTHOGONAL_COMPLEMENT_TO_LOCAL_TEMPORAL_AXIS_INSIDE_PASS039_RESIDUAL_DOMAIN",
            "parent_q4_coordinates": [float(x) for x in q],
            "parent_distance_squared": q2,
            "child_residual_distance_squared": r2,
            "delta_tau": tau,
            "transition_plane_spatial_coordinate_sigma": sigma,
            "higher_spatial_complement_distance_squared": h2,
            "spatial_distance_squared": spatial2,
            "spatial_coordinate_square_sum": spatial2_coordinate,
            "hierarchical_pythagorean_identity": "d_native^2 = d_Q4^2 + DeltaTau^2 + d_space^2",
            "child_pythagorean_coordinate_abs_error": child_coord_err,
            "child_pythagorean_vector_abs_error": child_vector_err,
            "full_pythagorean_coordinate_abs_error": full_coord_err,
            "full_pythagorean_vector_abs_error": full_vector_err,
            "time_space_dot_abs": abs(time_space_dot),
            "reconstruction_norm_error": float(np.linalg.norm(delta - reconstruct)),
            "global_fixed_time_axis_claimed": False,
        }

    def _transition_receipt(self, delta: np.ndarray, A: Dict[str, Any], B: Dict[str, Any]) -> Dict[str, Any]:
        pred_B = self.T_A_to_B @ np.asarray([A["delta_tau"], A["transition_plane_spatial_coordinate_sigma"]])
        pred_A = self.T_B_to_A @ np.asarray([B["delta_tau"], B["transition_plane_spatial_coordinate_sigma"]])
        return {
            "transition": "PASS049_A_TO_B",
            "theta_degrees": self.theta_degrees,
            "A_to_B_tau_abs_error": abs(float(pred_B[0]) - B["delta_tau"]),
            "A_to_B_sigma_abs_error": abs(float(pred_B[1]) - B["transition_plane_spatial_coordinate_sigma"]),
            "B_to_A_tau_abs_error": abs(float(pred_A[0]) - A["delta_tau"]),
            "B_to_A_sigma_abs_error": abs(float(pred_A[1]) - A["transition_plane_spatial_coordinate_sigma"]),
            "native_distance_invariant": True,
            "transition_changes_theorem_identity_distance": False,
        }

    @staticmethod
    def _route_chart_policy(route_positions: Optional[Sequence[str]]) -> Dict[str, Any]:
        if not route_positions:
            return {
                "policy": "BOTH_AUDIT_ONLY",
                "selected_chart": None,
                "reason": "No address route supplied; both certified local frames are reported without assigning temporal semantics globally.",
            }
        try:
            nums = [int(p[1:]) for p in route_positions if isinstance(p, str) and p.startswith("P")]
        except Exception:
            nums = []
        if len(nums) != len(route_positions):
            return {"policy": "FAIL_CLOSED", "selected_chart": None, "reason": "Malformed route position."}
        lo, hi = min(nums), max(nums)
        in_A = lo >= 93 and hi <= 103
        in_B = lo >= 101 and hi <= 117
        if in_A and not in_B:
            return {"policy": "LOCAL_CHART", "selected_chart": "A", "reason": "Entire address route lies in PASS048 chart A."}
        if in_B and not in_A:
            return {"policy": "LOCAL_CHART", "selected_chart": "B", "reason": "Entire address route lies in PASS048 chart B."}
        if in_A and in_B:
            return {"policy": "OVERLAP_EITHER_CHART", "selected_chart": "A", "reason": "Route lies in P101..P103 overlap; both charts are metric-equivalent."}
        if lo >= 93 and hi <= 117:
            return {"policy": "TWO_CHART_ATLAS", "selected_chart": "A+B", "reason": "Route crosses the certified PASS049 overlap and requires chart transition."}
        return {"policy": "OUTSIDE_CERTIFIED_TEMPORAL_ATLAS", "selected_chart": None, "reason": "Address route is outside P093..P117; no PASS048/049 temporal chart semantics assigned."}

    def coherent_distance(
        self,
        source_theorem_id: str,
        target_theorem_id: str,
        *,
        metric_provider_id: str = DEFAULT_PROVIDER,
        route_context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        base = self.base.distance(source_theorem_id, target_theorem_id, metric_provider_id=metric_provider_id, route_context=route_context)
        a = self.base._vec(source_theorem_id)
        b = self.base._vec(target_theorem_id)
        delta = b - a
        A = self._chart_decomposition(delta, self.a, self.v, "A")
        B = self._chart_decomposition(delta, self.b, self.w, "B")
        transition = self._transition_receipt(delta, A, B)
        route_positions = route_context.get("address_route_positions") if isinstance(route_context, dict) else None
        policy = self._route_chart_policy(route_positions)
        payload = {
            "schema": SCHEMA_DISTANCE,
            "status": "CERTIFIED_PROVIDER_RELATIVE_CARTESIAN_COHERENCE",
            "source_theorem_id": source_theorem_id,
            "target_theorem_id": target_theorem_id,
            "metric_provider_id": base["metric_provider_id"],
            "native_scale_id": base["native_scale_id"],
            "distance": base["distance"],
            "distance_squared": base["distance_squared"],
            "base_pass053_certificate_id": base["certificate_id"],
            "source_theorem_name": base.get("source_theorem_name"),
            "target_theorem_name": base.get("target_theorem_name"),
            "base_cartesian_decomposition": base["cartesian_decomposition"],
            "base_route_context_receipt": base["route_context_receipt"],
            "provider_firewall": base["provider_firewall"],
            "space_time_atlas": {
                "chart_policy": policy,
                "chart_A": A,
                "chart_B": B,
                "transition_A_B": transition,
                "pythagoras_required_scope": "Orthogonal pair decomposition: Q4 parent vs residual, then local temporal axis vs spatial complement.",
                "pythagoras_not_automatically_valid_scope": "Concatenated theorem-route legs unless mutual orthogonality is separately certified.",
            },
            "coherence_gate": {
                "pair_decomposition_closed": max(
                    A["full_pythagorean_coordinate_abs_error"], B["full_pythagorean_coordinate_abs_error"]
                ) <= 1e-12,
                "chart_transition_closed": max(
                    transition["A_to_B_tau_abs_error"], transition["A_to_B_sigma_abs_error"],
                    transition["B_to_A_tau_abs_error"], transition["B_to_A_sigma_abs_error"]
                ) <= 1e-12,
                "global_fixed_time_axis_claimed": False,
                "provider_independent_intrinsic_metric_claimed": False,
            },
            "claim_ceiling": (
                "Exact nested Cartesian/Pythagorean decomposition relative to frozen PASS021/PASS019R theorem vectors, PASS039 Q4, "
                "and PASS048/049 local chart axes. Space/time semantics are local to the certified atlas; no universal global time axis, "
                "provider-independent intrinsic metric, or physical absolute scale is claimed."
            ),
        }
        payload["certificate_id"] = _certificate_id("COHCERT-", payload)
        return payload

    @staticmethod
    def _mutual_orthogonality_receipt(legs: List[np.ndarray]) -> Dict[str, Any]:
        nonzero = [(i, x, float(np.linalg.norm(x))) for i, x in enumerate(legs) if float(np.linalg.norm(x)) > 0.0]
        max_abs_cos = 0.0
        worst = None
        cross_sum = 0.0
        for ii in range(len(nonzero)):
            i, u, nu = nonzero[ii]
            for jj in range(ii + 1, len(nonzero)):
                j, v, nv = nonzero[jj]
                dot = float(u @ v)
                cos = dot / (nu * nv)
                cross_sum += 2.0 * dot
                if abs(cos) > max_abs_cos:
                    max_abs_cos = abs(cos)
                    worst = {"leg_i": i, "leg_j": j, "dot": dot, "cosine": cos}
        return {
            "nonzero_leg_count": len(nonzero),
            "orthogonality_cosine_tolerance": float(ORTHOGONALITY_COSINE_TOL),
            "max_abs_pairwise_leg_cosine": max_abs_cos,
            "worst_pair": worst,
            "mutually_orthogonal": bool(max_abs_cos <= ORTHOGONALITY_COSINE_TOL),
            "double_cross_term_sum": cross_sum,
        }

    def coherent_route(
        self,
        theorem_route: Sequence[str],
        *,
        metric_provider_id: str = DEFAULT_PROVIDER,
        endpoint_contexts: Optional[Sequence[Optional[Dict[str, Any]]]] = None,
    ) -> Dict[str, Any]:
        if len(theorem_route) < 2:
            raise InvalidRequestError("theorem_route requires at least two theorem ids")
        if endpoint_contexts is not None and len(endpoint_contexts) != len(theorem_route):
            raise InvalidRequestError("endpoint_contexts length must equal theorem_route length")
        vectors = [self.base._vec(t) for t in theorem_route]
        leg_vecs = [b - a for a, b in zip(vectors, vectors[1:])]
        legs = []
        for i, (s, t) in enumerate(zip(theorem_route, theorem_route[1:])):
            rc = None
            if endpoint_contexts is not None:
                sa, sb = endpoint_contexts[i], endpoint_contexts[i + 1]
                if sa is not None or sb is not None:
                    rc = {"source_binding": sa, "target_binding": sb}
            legs.append(self.coherent_distance(s, t, metric_provider_id=metric_provider_id, route_context=rc))

        direct_vec = vectors[-1] - vectors[0]
        direct2 = float(direct_vec @ direct_vec)
        sum_leg2 = float(sum(float(x @ x) for x in leg_vecs))
        orth = self._mutual_orthogonality_receipt(leg_vecs)
        gram2 = sum_leg2 + orth["double_cross_term_sum"]
        direct = self.coherent_distance(theorem_route[0], theorem_route[-1], metric_provider_id=metric_provider_id)
        route_length = float(sum(x["distance"] for x in legs))
        payload = {
            "schema": SCHEMA_ROUTE,
            "status": "CERTIFIED_PROVIDER_RELATIVE_ROUTE_COMPOSITION",
            "metric_provider_id": metric_provider_id,
            "native_scale_id": direct["native_scale_id"],
            "theorem_route": list(theorem_route),
            "leg_count": len(legs),
            "legs": legs,
            "route_length": route_length,
            "direct_chord_distance": math.sqrt(max(direct2, 0.0)),
            "direct_chord_distance_squared": direct2,
            "sum_leg_distance_squared": sum_leg2,
            "gram_composition_distance_squared": gram2,
            "gram_law_abs_error": abs(direct2 - gram2),
            "orthogonality_gate": orth,
            "route_pythagoras": {
                "applicable": orth["mutually_orthogonal"],
                "identity_if_applicable": "d_endpoint^2 = sum_i d_leg_i^2",
                "naive_pythagorean_abs_residual": abs(direct2 - sum_leg2),
                "result": (
                    "CERTIFIED" if orth["mutually_orthogonal"] and abs(direct2 - sum_leg2) <= 1e-12
                    else "NOT_APPLICABLE_USE_GRAM_LAW"
                ),
            },
            "direct_pair_cartesian_certificate_id": direct["certificate_id"],
            "coherence_rule": "Pairwise orthogonal decompositions use Pythagoras; arbitrary route composition uses the exact Gram/law-of-cosines identity unless mutual leg orthogonality is certified.",
            "provider_independent_intrinsic_metric_claimed": False,
        }
        payload["certificate_id"] = _certificate_id("ROUTECOH-", payload)
        return payload

    def execute(self, request: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(request, dict):
            raise InvalidRequestError("request must be a JSON object")
        op = request.get("operation", "coherent_distance")
        provider = request.get("metric_provider_id", DEFAULT_PROVIDER)
        if op in ("coherent_distance", "distance"):
            return self.coherent_distance(
                request["source_theorem_id"], request["target_theorem_id"],
                metric_provider_id=provider, route_context=request.get("route_context")
            )
        if op in ("coherent_route", "route_distance"):
            return self.coherent_route(
                request["theorem_route"], metric_provider_id=provider,
                endpoint_contexts=request.get("endpoint_contexts")
            )
        if op == "provider_registry":
            return self.base.execute(request)
        raise InvalidRequestError(f"Unsupported operation: {op!r}")


def solver_cartesian_coherence_request(root: Path | str, request: Dict[str, Any]) -> Dict[str, Any]:
    engine = CartesianSpaceTimeCoherenceEngine(root)
    try:
        return {"ok": True, "result": engine.execute(request)}
    except DistanceAPIError as e:
        return {"ok": False, "error": e.as_dict()}
