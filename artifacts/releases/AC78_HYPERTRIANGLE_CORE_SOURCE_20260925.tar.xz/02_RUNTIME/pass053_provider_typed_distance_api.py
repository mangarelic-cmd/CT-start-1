from __future__ import annotations

from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
import hashlib
import json
import math

import numpy as np

DEFAULT_PROVIDER = "PASS021_NATIVE_THEOREM_METRIC_EFFECT_RESPONSE_V1"
DEFAULT_SCALE = "PASS021_L2_NORMALIZED_EFFECT_RESPONSE_NATIVE_SCALE_V1"
PASS018_PROVIDER = "PASS018_THEOREM_CORELATIONS_EFFECT"
PASS019Q_PROVIDER = "SECOND_MATH_CARRIER_PASS019Q_FORMAL_RELATION_PROFILE"

class DistanceAPIError(RuntimeError):
    code = "DISTANCE_API_ERROR"

    def as_dict(self) -> Dict[str, Any]:
        return {"error_code": self.code, "message": str(self)}


class UnknownTheoremError(DistanceAPIError):
    code = "UNKNOWN_THEOREM_ID"


class UnknownProviderError(DistanceAPIError):
    code = "UNKNOWN_METRIC_PROVIDER"


class CrossProviderConversionForbidden(DistanceAPIError):
    code = "UNCERTIFIED_CROSS_PROVIDER_CONVERSION_FORBIDDEN"


class RouteContextBindingError(DistanceAPIError):
    code = "ROUTE_CONTEXT_BINDING_NOT_EXACT"


class InvalidRequestError(DistanceAPIError):
    code = "INVALID_DISTANCE_REQUEST"


def _read_json(path: Path) -> Any:
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def _sha256_bytes(data: bytes) -> str:
    return hashlib.sha256(data).hexdigest()


def _canonical_json_bytes(obj: Any) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=False).encode("utf-8")


def _certificate_id(payload: Dict[str, Any]) -> str:
    return "DISTCERT-" + _sha256_bytes(_canonical_json_bytes(payload))[:24]


def _position_number(p: str) -> int:
    if not isinstance(p, str) or len(p) != 4 or not p.startswith("P") or not p[1:].isdigit():
        raise InvalidRequestError(f"Invalid position id: {p!r}")
    return int(p[1:])


@dataclass(frozen=True)
class ProviderSpec:
    provider_id: str
    native_scale_id: str
    enabled_for_numeric_distance: bool
    metric_law: str
    unit: str


class ProviderTypedDistanceEngine:
    """Frozen-provider theorem distance API introduced by PASS053.

    The engine deliberately keeps theorem metric identity separate from route-address
    geometry. The theorem distance is computed only in the selected metric provider.
    Route context, when supplied, is bound independently through PASS050 and appears
    only as an address receipt in the returned certificate.
    """

    def __init__(self, root: Path | str):
        self.root = Path(root)
        self._load()

    def _load(self) -> None:
        authority = _read_json(
            self.root
            / "27_PASS021_THEOREM_METRIC_ACTION/REGISTRY/PASS021_NATIVE_THEOREM_METRIC_AUTHORITY.json"
        )
        policy = _read_json(
            self.root
            / "58_PASS052_CROSS_CARRIER_ISOMETRY_SCALE_AUTHORITY/REGISTRY/PASS052_SCALE_AUTHORITY_POLICY.json"
        )
        if authority["authority_id"] != DEFAULT_PROVIDER:
            raise RuntimeError("PASS053 provider authority mismatch")
        if policy["default_theorem_metric_provider"] != DEFAULT_PROVIDER:
            raise RuntimeError("PASS053 scale policy mismatch")
        if policy["cross_provider_global_scale_authority"] != "NONE_CERTIFIED":
            raise RuntimeError("PASS053 requires PASS052 no-cross-scale firewall")

        rows = _read_json(
            self.root
            / "18_THIRD_EFFECT_CARRIER/REGISTRY/PASS019R_EFFECT_RESPONSE_VECTORS_118.json"
        )
        self.vectors: Dict[str, np.ndarray] = {
            r["theorem_id"]: np.asarray(r["vector"], dtype=float) for r in rows
        }
        if len(self.vectors) != 118 or {len(v) for v in self.vectors.values()} != {1302}:
            raise RuntimeError("PASS053 expected 118 theorem vectors of dimension 1302")

        lift = _read_json(
            self.root
            / "56_PASS050_THEOREM_LIFT_ROUTE_CONTEXT/REGISTRY/PASS050_THEOREM_TO_CARTESIAN_LIFT_118.json"
        )
        self.theorem_names = {r["theorem_id"]: r["theorem_name"] for r in lift["rows"]}
        self.q4 = np.load(
            self.root
            / "45_PASS039_EXACT_NATIVE_CARTESIAN_PYTHAGOREAN_ADAPTER/REGISTRY/PASS039_ORTHOGONAL_BASIS_1302x4.npy"
        )
        if self.q4.shape != (1302, 4):
            raise RuntimeError("PASS053 expected PASS039 1302x4 orthogonal basis")

        binding = _read_json(
            self.root
            / "56_PASS050_THEOREM_LIFT_ROUTE_CONTEXT/REGISTRY/PASS050_THEOREM_ROUTE_CONTEXT_BINDING_CATALOG.json"
        )
        self.binding_rows: Dict[str, List[Dict[str, Any]]] = {}
        for r in binding["rows"]:
            self.binding_rows.setdefault(r["theorem_id"], []).append(r)

        self.chart_transition = _read_json(
            self.root
            / "55_PASS049_EXACT_CHART_TRANSITION_INTERTWINER/REGISTRY/PASS049_CHART_TRANSITION_THEOREM.json"
        )
        self.chart_decision = _read_json(
            self.root
            / "55_PASS049_EXACT_CHART_TRANSITION_INTERTWINER/REGISTRY/PASS049_DECISION.json"
        )

        self.provider_specs: Dict[str, ProviderSpec] = {
            DEFAULT_PROVIDER: ProviderSpec(
                provider_id=DEFAULT_PROVIDER,
                native_scale_id=DEFAULT_SCALE,
                enabled_for_numeric_distance=True,
                metric_law=authority["metric_law"],
                unit=policy["default_provider_unit"],
            ),
            PASS018_PROVIDER: ProviderSpec(
                provider_id=PASS018_PROVIDER,
                native_scale_id="PASS018_SQRT_HAMMING_NATIVE_SCALE_V1",
                enabled_for_numeric_distance=False,
                metric_law="sqrt(Hamming) on frozen 944-coordinate binary Co-Relations effect signature",
                unit="PASS018 native sqrt(Hamming) unit",
            ),
            PASS019Q_PROVIDER: ProviderSpec(
                provider_id=PASS019Q_PROVIDER,
                native_scale_id="PASS019Q_NORMALIZED_FORMAL_PROFILE_EUCLIDEAN_SCALE_V1",
                enabled_for_numeric_distance=False,
                metric_law="Euclidean distance on normalized 106-dimensional formal relation profiles",
                unit="PASS019Q native Euclidean profile unit",
            ),
        }

    def provider_registry(self) -> List[Dict[str, Any]]:
        return [
            {
                "metric_provider_id": x.provider_id,
                "native_scale_id": x.native_scale_id,
                "enabled_for_numeric_distance": x.enabled_for_numeric_distance,
                "metric_law": x.metric_law,
                "unit": x.unit,
                "cross_scale_to_default": 1.0 if x.provider_id == DEFAULT_PROVIDER else None,
            }
            for x in self.provider_specs.values()
        ]

    def _check_provider(self, provider_id: str) -> ProviderSpec:
        if provider_id not in self.provider_specs:
            raise UnknownProviderError(provider_id)
        spec = self.provider_specs[provider_id]
        if not spec.enabled_for_numeric_distance:
            raise CrossProviderConversionForbidden(
                f"Provider {provider_id} is registered but not exposed through PASS053 numeric API; "
                "PASS052 certified no cross-provider scale adapter to the default provider."
            )
        return spec

    def _vec(self, theorem_id: str) -> np.ndarray:
        try:
            return self.vectors[theorem_id]
        except KeyError:
            raise UnknownTheoremError(theorem_id)

    def bind_route_context(self, theorem_id: str, context: Dict[str, Any]) -> Dict[str, Any]:
        if theorem_id not in self.vectors:
            raise UnknownTheoremError(theorem_id)
        if not isinstance(context, dict):
            raise RouteContextBindingError("Route binding context must be an object")
        required_role = context.get("required_role")
        if not required_role:
            raise RouteContextBindingError("required_role is mandatory for exact PASS050 binding")
        active_positions = context.get("active_positions")
        if active_positions is not None:
            active_positions = sorted(set(active_positions))

        candidates: List[Dict[str, Any]] = []
        for row in self.binding_rows.get(theorem_id, []):
            rc = row["route_context"]
            if rc.get("required_role") != required_role:
                continue
            row_positions = rc.get("active_positions")
            if active_positions is None:
                if row_positions is None:
                    candidates.append(row)
            else:
                if row_positions is not None and sorted(set(row_positions)) == active_positions:
                    candidates.append(row)

        if len(candidates) != 1:
            raise RouteContextBindingError(
                f"{theorem_id} with role={required_role!r} active_positions={active_positions!r} "
                f"resolved to {len(candidates)} exact PASS050 bindings"
            )
        row = candidates[0]
        return {
            "binding_status": row["binding_status"],
            "theorem_id": theorem_id,
            "required_role": required_role,
            "active_positions": active_positions,
            "selected_position": row["selected_position"],
            "selected_role": row["selected_role"],
            "selected_function_id": row["selected_function_id"],
            "address_support_coordinate_sha256": row["address_support_coordinate_sha256"],
            "theorem_native_coordinate_sha256": row["theorem_native_coordinate_sha256"],
            "identity_equals_address": False,
        }

    def _address_route_receipt(self, route_positions: Optional[Sequence[str]]) -> Dict[str, Any]:
        if route_positions is None:
            return {"status": "NOT_REQUESTED", "used_in_theorem_metric": False}
        if len(route_positions) < 2:
            raise InvalidRequestError("address_route_positions requires at least two positions")
        nums = [_position_number(p) for p in route_positions]
        step = 1 if nums[-1] >= nums[0] else -1
        if any(b - a != step for a, b in zip(nums, nums[1:])):
            return {
                "status": "ROUTE_NOT_CONTIGUOUS_IN_PASS049_ATLAS",
                "route_positions": list(route_positions),
                "used_in_theorem_metric": False,
            }
        lo, hi = min(nums), max(nums)
        if lo < 93 or hi > 117:
            return {
                "status": "ROUTE_OUTSIDE_PASS049_TWO_CHART_ATLAS",
                "route_positions": list(route_positions),
                "used_in_theorem_metric": False,
            }
        a_legs = []
        b_legs = []
        for p, q in zip(nums, nums[1:]):
            s, t = min(p, q), max(p, q)
            if 93 <= s and t <= 103:
                a_legs.append([f"P{p:03d}", f"P{q:03d}"])
            if 101 <= s and t <= 117:
                b_legs.append([f"P{p:03d}", f"P{q:03d}"])
        crosses = bool(a_legs and b_legs and lo < 101 and hi > 103)
        return {
            "status": "PASS049_TWO_CHART_ATLAS_ROUTE_CERTIFIED",
            "route_positions": list(route_positions),
            "chart_A": "P093..P103",
            "chart_B": "P101..P117",
            "overlap": "P101..P103",
            "chart_A_legs": a_legs,
            "chart_B_legs": b_legs,
            "transition_required": crosses,
            "transition_dimension": self.chart_decision["transition_dimension"],
            "transition_determinant": self.chart_decision["transition_determinant"],
            "transition_orthogonality_max_abs": self.chart_decision["transition_orthogonality_max_abs"],
            "theta_degrees": self.chart_decision["theta_degrees"],
            "used_in_theorem_metric": False,
            "firewall": "PASS049 address-atlas transition is a route-address geometry receipt, not a theorem-identity metric conversion.",
        }

    def distance(
        self,
        source_theorem_id: str,
        target_theorem_id: str,
        *,
        metric_provider_id: str = DEFAULT_PROVIDER,
        route_context: Optional[Dict[str, Any]] = None,
    ) -> Dict[str, Any]:
        spec = self._check_provider(metric_provider_id)
        a = self._vec(source_theorem_id)
        b = self._vec(target_theorem_id)
        delta = b - a
        q = self.q4.T @ delta
        residual = delta - self.q4 @ q
        d2 = float(delta @ delta)
        q2 = float(q @ q)
        r2 = float(residual @ residual)
        pyth_err = abs(d2 - (q2 + r2))
        d = math.sqrt(max(d2, 0.0))

        source_binding = {"status": "NOT_REQUESTED"}
        target_binding = {"status": "NOT_REQUESTED"}
        route_positions = None
        if route_context is not None:
            if not isinstance(route_context, dict):
                raise InvalidRequestError("route_context must be an object")
            if route_context.get("source_binding") is not None:
                source_binding = self.bind_route_context(source_theorem_id, route_context["source_binding"])
            if route_context.get("target_binding") is not None:
                target_binding = self.bind_route_context(target_theorem_id, route_context["target_binding"])
            route_positions = route_context.get("address_route_positions")
        atlas = self._address_route_receipt(route_positions)

        payload: Dict[str, Any] = {
            "schema": "PASS053_PROVIDER_TYPED_DISTANCE_CERTIFICATE_V1",
            "status": "CERTIFIED_PROVIDER_RELATIVE_DISTANCE",
            "source_theorem_id": source_theorem_id,
            "source_theorem_name": self.theorem_names.get(source_theorem_id),
            "target_theorem_id": target_theorem_id,
            "target_theorem_name": self.theorem_names.get(target_theorem_id),
            "metric_provider_id": spec.provider_id,
            "native_scale_id": spec.native_scale_id,
            "native_unit": spec.unit,
            "metric_law": spec.metric_law,
            "distance": d,
            "distance_squared": d2,
            "cartesian_decomposition": {
                "parent_basis_id": "PASS039_ORTHOGONAL_BASIS_1302x4",
                "parent_delta_q4": [float(x) for x in q],
                "parent_distance": math.sqrt(max(q2, 0.0)),
                "parent_distance_squared": q2,
                "orthogonal_residual_distance": math.sqrt(max(r2, 0.0)),
                "orthogonal_residual_distance_squared": r2,
                "pythagorean_identity": "d_native^2 = d_Q4^2 + d_perp^2",
                "pythagorean_abs_error": pyth_err,
            },
            "route_context_receipt": {
                "source_binding": source_binding,
                "target_binding": target_binding,
                "address_atlas": atlas,
                "route_context_changes_theorem_identity_distance": False,
            },
            "provider_firewall": {
                "cross_provider_global_scale_authority": "NONE_CERTIFIED",
                "cross_provider_numeric_conversion_allowed": False,
                "provider_independent_intrinsic_metric_claimed": False,
            },
            "claim_ceiling": (
                "Exact relative to the frozen PASS021/PASS019R theorem effect-response provider and PASS039 orthogonal decomposition. "
                "This certificate does not promote the distance to a provider-independent intrinsic theorem metric."
            ),
        }
        payload["certificate_id"] = _certificate_id(payload)
        return payload

    def route_distance(
        self,
        theorem_route: Sequence[str],
        *,
        metric_provider_id: str = DEFAULT_PROVIDER,
        endpoint_contexts: Optional[Sequence[Optional[Dict[str, Any]]]] = None,
    ) -> Dict[str, Any]:
        if len(theorem_route) < 2:
            raise InvalidRequestError("theorem_route requires at least two theorem ids")
        if endpoint_contexts is not None and len(endpoint_contexts) != len(theorem_route):
            raise InvalidRequestError("endpoint_contexts length must equal theorem_route length")
        legs = []
        for i, (a, b) in enumerate(zip(theorem_route, theorem_route[1:])):
            rc = None
            if endpoint_contexts is not None:
                sa, sb = endpoint_contexts[i], endpoint_contexts[i + 1]
                if sa is not None or sb is not None:
                    rc = {"source_binding": sa, "target_binding": sb}
            cert = self.distance(a, b, metric_provider_id=metric_provider_id, route_context=rc)
            legs.append(cert)
        direct = self.distance(theorem_route[0], theorem_route[-1], metric_provider_id=metric_provider_id)
        route_length = float(sum(x["distance"] for x in legs))
        excess = route_length - direct["distance"]
        payload = {
            "schema": "PASS053_PROVIDER_TYPED_ROUTE_DISTANCE_CERTIFICATE_V1",
            "status": "CERTIFIED_PROVIDER_RELATIVE_ROUTE_DISTANCE",
            "metric_provider_id": metric_provider_id,
            "native_scale_id": legs[0]["native_scale_id"],
            "theorem_route": list(theorem_route),
            "leg_count": len(legs),
            "legs": legs,
            "route_length": route_length,
            "direct_chord_distance": direct["distance"],
            "route_excess_over_chord": excess,
            "triangle_inequality_satisfied": excess >= -1e-12,
            "max_leg_pythagorean_abs_error": max(
                x["cartesian_decomposition"]["pythagorean_abs_error"] for x in legs
            ),
            "provider_independent_intrinsic_metric_claimed": False,
        }
        payload["certificate_id"] = _certificate_id(payload)
        return payload

    def execute(self, request: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(request, dict):
            raise InvalidRequestError("request must be a JSON object")
        op = request.get("operation", "distance")
        provider = request.get("metric_provider_id", DEFAULT_PROVIDER)
        if op == "distance":
            return self.distance(
                request["source_theorem_id"],
                request["target_theorem_id"],
                metric_provider_id=provider,
                route_context=request.get("route_context"),
            )
        if op == "route_distance":
            return self.route_distance(
                request["theorem_route"],
                metric_provider_id=provider,
                endpoint_contexts=request.get("endpoint_contexts"),
            )
        if op == "provider_registry":
            return {
                "schema": "PASS053_PROVIDER_REGISTRY_RESPONSE_V1",
                "providers": self.provider_registry(),
                "default_metric_provider_id": DEFAULT_PROVIDER,
            }
        raise InvalidRequestError(f"Unsupported operation: {op!r}")


def solver_distance_request(root: Path | str, request: Dict[str, Any]) -> Dict[str, Any]:
    """Stable adapter entry point intended for AC/DD solver orchestration."""
    engine = ProviderTypedDistanceEngine(root)
    try:
        return {"ok": True, "result": engine.execute(request)}
    except DistanceAPIError as e:
        return {"ok": False, "error": e.as_dict()}

