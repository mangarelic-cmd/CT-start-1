from __future__ import annotations

import copy
import hashlib
import importlib.util
import json
import sys
from pathlib import Path
from typing import Any, Dict


AC78_CORE_SCHEMA = "AC78_HYPERTRIANGLE_MEMORY_INTEGRATION_CORE_V1"
EXPECTED_PROVIDER = "HYPERTRIANGLE_SOLVER_AUX"
EXPECTED_PROVIDER_VERSION = "1.0.0"
EXPECTED_FROZEN_ZIP_SHA256 = "fa82b76a200703afe38e1f3e6ecabe2b1cb363f4fbb89c34ca00adf24ea23295"
EXPECTED_CAPABILITY_COUNT = 61
EXPECTED_SLOT_COUNT = 144
EXPECTED_SCHEMA_COUNT = 35


def _canon(x: Any) -> str:
    return json.dumps(x, sort_keys=True, separators=(",", ":"), ensure_ascii=False, default=str)


def _sha_obj(x: Any) -> str:
    return hashlib.sha256(_canon(x).encode("utf-8")).hexdigest()


def _sha_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b""):
            h.update(chunk)
    return h.hexdigest()


class HyperTriangleProviderError(RuntimeError):
    pass


class HyperTriangleMemoryCore:
    """AC78 adapter around the frozen HyperTriangle solver AUX v1.0.0.

    Integration is explicit and typed. AC78 never infers a F001..F144 slot from free text,
    never feeds capability output back into memory automatically, and never treats AUX
    terminality as scientific ROOT truth.
    """

    def __init__(self):
        self.root = Path(__file__).resolve().parents[1]
        self.vendor_root = self.root / "61_HYPERTRIANGLE_AUX_V1"
        self.provider_root = self.vendor_root / "provider"
        self.frozen_zip = self.vendor_root / "HYPERTRIANGLE_SOLVER_AUX_PASS015_V1.0.0_20260925.zip"
        self._calls = 0
        self._errors = 0
        self._memory_calls = 0
        self._terminal_calls = 0
        self._verification = self._verify_frozen_provider()
        self.provider = self._load_provider()
        self._verify_runtime_envelope()

    def _verify_frozen_provider(self) -> Dict[str, Any]:
        required = [
            self.frozen_zip,
            self.provider_root / "HYPERTRIANGLE_SOLVER_AUX_PROVIDER_MANIFEST.json",
            self.provider_root / "HYPERTRIANGLE_SOLVER_AUX_V1_ABI_FREEZE.json",
            self.provider_root / "CAUSAL_144_CANON.json",
            self.provider_root / "hypertriangle_solver_aux.py",
        ]
        missing = [str(p) for p in required if not p.is_file()]
        if missing:
            raise HyperTriangleProviderError("missing frozen provider files: " + ", ".join(missing))

        zip_sha = _sha_file(self.frozen_zip)
        if zip_sha != EXPECTED_FROZEN_ZIP_SHA256:
            raise HyperTriangleProviderError(f"frozen provider ZIP SHA mismatch: {zip_sha}")

        manifest_path = self.provider_root / "HYPERTRIANGLE_SOLVER_AUX_PROVIDER_MANIFEST.json"
        freeze_path = self.provider_root / "HYPERTRIANGLE_SOLVER_AUX_V1_ABI_FREEZE.json"
        manifest = json.loads(manifest_path.read_text(encoding="utf-8"))
        freeze = json.loads(freeze_path.read_text(encoding="utf-8"))

        if manifest.get("provider_id") != EXPECTED_PROVIDER or manifest.get("version") != EXPECTED_PROVIDER_VERSION:
            raise HyperTriangleProviderError("provider identity/version mismatch")
        if manifest.get("status") != "COMPLETE_STANDALONE_V1_FROZEN":
            raise HyperTriangleProviderError("provider is not the frozen standalone v1 release")
        if int(manifest.get("truth_credit", -1)) != 0:
            raise HyperTriangleProviderError("provider truth-credit firewall mismatch")
        for k in ("root_write_capability", "return_write_capability", "solver_mutation_capability"):
            if manifest.get(k) != "NONE":
                raise HyperTriangleProviderError(f"provider authority firewall mismatch: {k}")

        freeze_sha = _sha_file(freeze_path)
        if freeze_sha != manifest.get("abi_freeze_sha256"):
            raise HyperTriangleProviderError("ABI freeze hash mismatch")
        if freeze.get("provider_id") != EXPECTED_PROVIDER or freeze.get("release_version") != EXPECTED_PROVIDER_VERSION:
            raise HyperTriangleProviderError("ABI freeze provider identity/version mismatch")
        if int(freeze.get("capability_count", -1)) != EXPECTED_CAPABILITY_COUNT:
            raise HyperTriangleProviderError("unexpected frozen capability count")
        if int((freeze.get("causal_144_canon") or {}).get("slot_count", -1)) != EXPECTED_SLOT_COUNT:
            raise HyperTriangleProviderError("unexpected frozen 144-slot count")
        if int(freeze.get("schema_count", -1)) != EXPECTED_SCHEMA_COUNT:
            raise HyperTriangleProviderError("unexpected frozen schema count")

        for rel, expected in (freeze.get("implementation_files") or {}).items():
            p = self.provider_root / rel
            if not p.is_file() or _sha_file(p) != expected:
                raise HyperTriangleProviderError(f"frozen implementation hash mismatch: {rel}")
        canon = freeze.get("causal_144_canon") or {}
        canon_path = self.provider_root / str(canon.get("path") or "CAUSAL_144_CANON.json")
        if _sha_file(canon_path) != canon.get("sha256"):
            raise HyperTriangleProviderError("frozen CAUSAL_144_CANON hash mismatch")

        return {
            "verified": True,
            "provider": EXPECTED_PROVIDER,
            "version": EXPECTED_PROVIDER_VERSION,
            "frozen_zip_sha256": zip_sha,
            "abi_freeze_sha256": freeze_sha,
            "capability_count": EXPECTED_CAPABILITY_COUNT,
            "slot_count": EXPECTED_SLOT_COUNT,
            "schema_count": EXPECTED_SCHEMA_COUNT,
            "truth_credit": 0,
            "root_write_capability": "NONE",
            "return_write_capability": "NONE",
            "solver_mutation_capability": "NONE",
        }

    def _load_provider(self):
        path = self.provider_root / "hypertriangle_solver_aux.py"
        spec = importlib.util.spec_from_file_location("ac78_frozen_hypertriangle_solver_aux_v1", path)
        if spec is None or spec.loader is None:
            raise HyperTriangleProviderError("cannot load frozen HyperTriangle provider")
        mod = importlib.util.module_from_spec(spec)
        old_dont_write = sys.dont_write_bytecode
        sys.dont_write_bytecode = True
        try:
            spec.loader.exec_module(mod)
        finally:
            sys.dont_write_bytecode = old_dont_write
        return mod

    def _verify_runtime_envelope(self) -> None:
        env = self.provider.handle_request({"request_id": "AC78_PROVIDER_SELFTEST", "mode": "capabilities", "payload": {}})
        if env.get("provider") != EXPECTED_PROVIDER or env.get("version") != EXPECTED_PROVIDER_VERSION:
            raise HyperTriangleProviderError("runtime provider envelope identity mismatch")
        if env.get("truth_credit") != 0:
            raise HyperTriangleProviderError("runtime provider truth-credit mismatch")
        if env.get("root_write_capability") != "NONE" or env.get("return_write_capability") != "NONE" or env.get("solver_mutation_capability") != "NONE":
            raise HyperTriangleProviderError("runtime provider authority firewall mismatch")
        caps = (env.get("receipt") or {}).get("capabilities") or {}
        if len(caps) != EXPECTED_CAPABILITY_COUNT:
            raise HyperTriangleProviderError("runtime capability count mismatch")

    def verification(self) -> Dict[str, Any]:
        return copy.deepcopy(self._verification)

    def counters(self) -> Dict[str, Any]:
        return {
            "requests": self._calls,
            "errors": self._errors,
            "memory_requests": self._memory_calls,
            "terminal_requests": self._terminal_calls,
            "provider_verified": True,
            "frozen_provider_sha256": self._verification["frozen_zip_sha256"],
            "capability_count": EXPECTED_CAPABILITY_COUNT,
            "slot_count": EXPECTED_SLOT_COUNT,
        }

    def execute_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        if not isinstance(request, dict):
            raise HyperTriangleProviderError("hypertriangle request must be an object")
        mode = str(request.get("mode") or "")
        if not mode:
            raise HyperTriangleProviderError("hypertriangle request requires explicit mode")
        self._calls += 1
        if mode.startswith("memory_144_"):
            self._memory_calls += 1
        if "terminal" in mode:
            self._terminal_calls += 1
        try:
            env = self.provider.handle_request(copy.deepcopy(request))
        except Exception as exc:
            self._errors += 1
            raise HyperTriangleProviderError(f"frozen provider rejected request: {type(exc).__name__}: {exc}") from exc
        if env.get("truth_credit") != 0 or env.get("root_write_capability") != "NONE" or env.get("return_write_capability") != "NONE" or env.get("solver_mutation_capability") != "NONE":
            self._errors += 1
            raise HyperTriangleProviderError("provider authority firewall violated at runtime")
        return env

    def apply_payload(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        if "hypertriangle_request" not in payload:
            return {
                "schema": AC78_CORE_SCHEMA,
                "status": "NO_HYPERTRIANGLE_REQUEST",
                "provider_verified": True,
                "truth_credit_added": 0,
            }
        req = payload.get("hypertriangle_request")
        if not isinstance(req, dict):
            self._errors += 1
            return {
                "schema": AC78_CORE_SCHEMA,
                "status": "OPEN_FAIL_CLOSED",
                "error": {"error_code": "HYPERTRIANGLE_REQUEST_NOT_TYPED_OBJECT"},
                "requires": ["TYPED_HYPERTRIANGLE_REQUEST"],
                "truth_credit_added": 0,
                "provider_verified": True,
            }
        request_hash = _sha_obj(req)
        try:
            env = self.execute_request(req)
        except HyperTriangleProviderError as exc:
            return {
                "schema": AC78_CORE_SCHEMA,
                "status": "OPEN_FAIL_CLOSED",
                "request_hash": request_hash,
                "error": {"error_code": "HYPERTRIANGLE_PROVIDER_REJECTED", "detail": str(exc)},
                "requires": ["VALID_FROZEN_HYPERTRIANGLE_TYPED_REQUEST"],
                "truth_credit_added": 0,
                "provider_verified": True,
            }
        receipt = env.get("receipt") if isinstance(env.get("receipt"), dict) else {}
        semantic_status = receipt.get("status")
        return {
            "schema": AC78_CORE_SCHEMA,
            "status": "PASS",
            "request_hash": request_hash,
            "request_mode": env.get("mode"),
            "provider_semantic_status": semantic_status,
            "provider_envelope": env,
            "provider_verified": True,
            "frozen_provider_sha256": self._verification["frozen_zip_sha256"],
            "memory_direction": "DATA_TO_INVARIANT_SLOT_TO_ACTIVATION_TO_TYPED_CAPABILITY",
            "implicit_slot_classification_performed": False,
            "capability_output_memory_feedback_performed": False,
            "aux_terminality_equals_scientific_root": False,
            "truth_credit_added": 0,
            "external_scientific_truth_certified": False,
            "root_write_capability": "NONE",
            "return_write_capability": "NONE",
            "solver_mutation_capability": "NONE",
        }
