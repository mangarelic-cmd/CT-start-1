\
from __future__ import annotations
from copy import deepcopy
from hashlib import sha256
from pathlib import Path
import json, sys
from functools import lru_cache
from typing import Any
import sympy as sp

SCHEMA='AC66_TRIVALENT_MECHANICAL_PROOF_RECONSTRUCTION_V1'

def _canon(x): return json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,default=str)
def _digest(x): return sha256(_canon(x).encode()).hexdigest()

def _fabric_path():
    return Path(__file__).resolve().parents[1]/'08_DD094_EXACT_THEOREM_FABRIC'/'core'

def _load_fabric():
    p=str(_fabric_path())
    if p not in sys.path: sys.path.insert(0,p)
    from sc_aux_theorem_payload_compiler.compiler import compiler_audit
    from sc_aux_theorem_router.profiles import profile_audit
    from sc_aux_theorem_router.router import route, structural_candidates
    from sc_aux_theorem_router.backends import executable_backend_count
    from sc_aux_theorem_residual_closure.engine import canonical_residual_closure_audit
    return compiler_audit,profile_audit,route,structural_candidates,executable_backend_count,canonical_residual_closure_audit

@lru_cache(maxsize=1)
def fabric_audit():
    compiler_audit,profile_audit,_,_,backend_count,residual_audit=_load_fabric()
    c=compiler_audit(); p=profile_audit(); r=residual_audit()
    out={'schema':'AC66_EXACT_THEOREM_FABRIC_AUDIT_V1','compiler':c,'profiles':p,'residual_closure':r,'exact_backend_count':backend_count()}
    out['pass']=bool(c.get('pass') and p.get('pass') and out['exact_backend_count']==217)
    out['digest']=_digest(out)
    return out

def theorem_search(raw:dict, goal:str):
    _,_,route,structural_candidates,_,_=_load_fabric()
    packet={'raw':deepcopy(raw),'goal':goal,'mode':'COMPLETE','structural_limit':64}
    routed=route(packet)
    structural=structural_candidates(raw,goal,limit=64)
    return {'route':routed,'structural_candidates':structural}

def _locals(symbols):
    return {str(s):sp.symbols(str(s), nonzero=False) for s in symbols}

def verify_symbolic_identity(v:dict)->dict:
    loc=_locals(v.get('symbols') or [])
    lhs=sp.sympify(v['lhs'],locals=loc); rhs=sp.sympify(v['rhs'],locals=loc)
    diff=sp.factor(sp.together(lhs-rhs))
    ok=(diff==0)
    return {'pass':bool(ok),'normalized_difference':str(diff),'lhs':str(lhs),'rhs':str(rhs)}

def verify_zero_equivalence(v:dict)->dict:
    loc=_locals(v.get('symbols') or [])
    R=sp.sympify(v['expression'],locals=loc); var=loc[v['variable']]
    expected=sp.sympify(v['expected_solution'],locals=loc)
    sols=sp.solve(sp.Eq(R,0),var,dict=False)
    ok=any(sp.simplify(s-expected)==0 for s in sols)
    return {'pass':bool(ok),'solutions':[str(s) for s in sols],'expected':str(expected),'assumptions':list(v.get('assumptions') or [])}

def _scope_overpromotion(claim:dict, verifier:dict)->bool:
    ps=str(verifier.get('scope_kind') or verifier.get('proof_scope_kind') or '').upper()
    cs=str(claim.get('claim_scope_kind') or claim.get('scope_kind') or '').upper()
    return ps in {'FINITE','BOUNDED','SAMPLED','SCOPED_FINITE'} and cs in {'UNIVERSAL','GLOBAL','ALL','UNBOUNDED'}

def verify_claim(claim:dict)->dict:
    v=claim.get('verifier') or {}; kind=str(v.get('kind') or 'NONE').upper()
    if kind in {'PLACEHOLDER','AUTO_TRUE','TRUST_ME','STRING_MATCH','UNSAFE_PLACEHOLDER'}:
        res={'pass':False,'reason':'UNSAFE_PLACEHOLDER_VERIFIER_FORBIDDEN'}
    elif _scope_overpromotion(claim,v):
        res={'pass':False,'reason':'FINITE_SCOPE_CANNOT_PROVE_UNIVERSAL_CLAIM'}
    elif kind=='SYMBOLIC_IDENTITY': res=verify_symbolic_identity(v)
    elif kind=='ZERO_EQUIVALENCE': res=verify_zero_equivalence(v)
    elif kind=='BOOLEAN_ASSERTIONS':
        checks=v.get('checks') or []
        if claim.get('scientific_claim') is True and v.get('independent_authority') is not True:
            res={'pass':False,'reason':'BOOLEAN_ASSERTIONS_NOT_INDEPENDENT_SCIENTIFIC_CERTIFIER','checks':checks}
        else:
            res={'pass':all(bool(x) for x in checks),'checks':checks}
    elif kind=='SOURCE_RECEIPT':
        ok=bool(v.get('source_verified') is True and v.get('source_digest'))
        res={'pass':ok,'source':v.get('source'),'source_digest':v.get('source_digest'),'reason':None if ok else 'SOURCE_RECEIPT_NEEDS_VERIFIED_DIGEST'}
    else: res={'pass':False,'reason':'NO_EXECUTABLE_VERIFIER'}
    res['claim_id']=claim.get('id'); res['verifier_kind']=kind
    res['epistemic_status']='PROVED' if res.get('pass') else 'UNKNOWN'
    res['digest']=_digest(res)
    return res

def _edge_verified(edge:dict, proved:set[str])->tuple[bool,dict]:
    src=[str(x) for x in edge.get('from') or []]
    if any(x not in proved for x in src):
        return False,{'pass':False,'epistemic_status':'UNKNOWN','reason':'SOURCE_CLAIM_NOT_PROVED','unproved_sources':[x for x in src if x not in proved]}
    rule=str(edge.get('rule') or '').upper()
    if rule=='EXPLICIT_PROOF_OBJECT':
        obj=edge.get('proof_object')
        if isinstance(obj,dict) and obj.get('verified') is True and obj.get('conclusion')==edge.get('to'):
            return True,{'pass':True,'epistemic_status':'PROVED','rule':rule,'proof_digest':_digest(obj)}
        return False,{'pass':False,'epistemic_status':'UNKNOWN','reason':'MISSING_VERIFIED_PROOF_OBJECT'}
    if rule=='IDENTITY_SPECIALIZATION':
        v=edge.get('verifier') or {}
        rr=verify_symbolic_identity(v); rr['epistemic_status']='PROVED' if rr.get('pass') else 'UNKNOWN'
        return bool(rr.get('pass')),rr
    if rule=='LOGICAL_CHAIN':
        steps=edge.get('steps') or []
        ok=bool(steps) and all(isinstance(st,dict) and st.get('verified') is True for st in steps)
        return ok,{'pass':ok,'epistemic_status':'PROVED' if ok else 'UNKNOWN','step_count':len(steps),'step_digests':[_digest(st) for st in steps]}
    if rule=='PARTITION_EXHAUSTIVE':
        obj=edge.get('proof_object') or {}
        ok=bool(obj.get('verified') is True and obj.get('coverage_exhaustive') is True and obj.get('conclusion')==edge.get('to'))
        return ok,{'pass':ok,'epistemic_status':'PROVED' if ok else 'UNKNOWN','rule':rule,'proof_digest':_digest(obj) if obj else None}
    if rule=='MULTI_PARENT_DAG_MERGE':
        # All listed parents have already been proved above. The merge still requires an explicit
        # composition receipt so convergence of arrows is not itself treated as entailment.
        obj=edge.get('proof_object') or {}
        ok=bool(len(src)>=2 and obj.get('verified') is True and obj.get('conclusion')==edge.get('to'))
        return ok,{'pass':ok,'epistemic_status':'PROVED' if ok else 'UNKNOWN','rule':rule,'parent_count':len(src),'proof_digest':_digest(obj) if obj else None}
    return False,{'pass':False,'epistemic_status':'UNKNOWN','reason':'NO_EXECUTABLE_EDGE_RULE'}

def reconstruct(spec:dict)->dict:
    if not isinstance(spec,dict): raise TypeError('proof spec must be dict')
    target=str(spec.get('target') or '')
    claims={str(c['id']):c for c in spec.get('claims') or [] if isinstance(c,dict) and c.get('id')}
    claim_receipts={cid:verify_claim(c) for cid,c in claims.items()}
    proved={cid for cid,r in claim_receipts.items() if r.get('pass')}
    unknown_claims={cid for cid,r in claim_receipts.items() if not r.get('pass')}
    edges=list(spec.get('edges') or [])
    edge_receipts=[]
    changed=True
    while changed:
        changed=False
        for e in edges:
            eid=str(e.get('id') or _digest(e))
            if any(x.get('edge_id')==eid and x.get('pass') for x in edge_receipts): continue
            ok,rr=_edge_verified(e,proved)
            row={'edge_id':eid,'from':list(e.get('from') or []),'to':e.get('to'),'rule':e.get('rule'),'pass':ok,'epistemic_status':'PROVED' if ok else 'UNKNOWN','detail':rr}
            edge_receipts.append(row)
            if ok and e.get('to') not in proved:
                proved.add(str(e.get('to'))); changed=True
    target_proved=target in proved
    residuals=[]
    if not target_proved:
        inbound=[e for e in edges if str(e.get('to'))==target]
        if not inbound:
            residuals.append({'target':target,'kind':'MISSING_INBOUND_PROOF_EDGE','statement':'No executable proof edge reaches the target.'})
        else:
            for e in inbound:
                eid=str(e.get('id') or _digest(e))
                passed=any(r.get('edge_id')==eid and r.get('pass') for r in edge_receipts)
                if not passed:
                    residuals.append({'target':target,'kind':'UNPROVED_EDGE','edge_id':eid,'from':list(e.get('from') or []),'statement':e.get('statement') or e.get('meaning')})
    search_raw=deepcopy(spec.get('theorem_search_raw') or {})
    search=theorem_search(search_raw,target) if target and search_raw else None
    geometry=deepcopy(spec.get('geometry_evidence') or [])
    geom_ok=all(isinstance(g,dict) and g.get('pythagorean_pass') is True for g in geometry) if geometry else None
    out={'schema':SCHEMA,'target':target,'formal_proof_verified':target_proved,'epistemic_status':'PROVED' if target_proved else 'UNKNOWN','status':'PROVED' if target_proved else 'OPEN_RESIDUAL','proved_claim_ids':sorted(proved),'unknown_claim_ids':sorted(unknown_claims - proved),'refuted_claim_ids':[],'failed_proof_is_refutation':False,'claim_receipts':claim_receipts,'edge_receipts':edge_receipts,'proof_residuals':residuals,'geometry_evidence_count':len(geometry),'geometry_identity_pass':geom_ok,'geometry_role':'AUXILIARY_COORDINATE_EVIDENCE_NOT_SEMANTIC_ENTAILMENT','theorem_fabric_search':search,'theorem_fabric_audit':fabric_audit()}
    out['digest']=_digest(out)
    return out
