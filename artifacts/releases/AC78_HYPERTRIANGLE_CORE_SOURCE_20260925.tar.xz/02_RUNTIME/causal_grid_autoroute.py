from __future__ import annotations
from typing import Any, Dict, Optional, Tuple
import re
import sympy as sp
from universal_constraint_compiler import infer_constraint_route

SAFE_FUNCS = {
    'exp': sp.exp, 'log': sp.log, 'sqrt': sp.sqrt, 'Abs': sp.Abs,
    'sin': sp.sin, 'cos': sp.cos, 'tan': sp.tan, 'pi': sp.pi, 'E': sp.E,
}

def _parse_equation(eq: Any, variable: str='x') -> Tuple[sp.Eq, sp.Symbol]:
    x = sp.Symbol(variable, real=True)
    loc = dict(SAFE_FUNCS); loc[variable]=x
    if isinstance(eq, sp.Equality):
        return eq, x
    if not isinstance(eq, str):
        raise ValueError('equation must be string or sympy Equality')
    s=eq.strip()
    if '=' in s and '==' not in s:
        a,b=s.split('=',1)
        return sp.Eq(sp.sympify(a,locals=loc), sp.sympify(b,locals=loc), evaluate=False), x
    expr=sp.sympify(s,locals=loc)
    return sp.Eq(expr,0,evaluate=False), x

def _poly_coeff(expr:sp.Expr,x:sp.Symbol):
    try:
        p=sp.Poly(sp.expand(expr),x)
        return p
    except Exception:
        return None

def _linear_spec(eq:sp.Eq,x:sp.Symbol)->Optional[Dict[str,Any]]:
    expr=sp.expand(eq.lhs-eq.rhs)
    p=_poly_coeff(expr,x)
    if p is None or p.degree()!=1: return None
    a=p.coeff_monomial(x); b=p.coeff_monomial(1)
    if sp.simplify(a)==0: return None
    return {'kind':'AFFINE_SCALAR','variable':str(x),'a':a,'b':b,'c':0,
            'source_equation':str(eq),'auto_extracted':True}

def _quadratic_spec(eq:sp.Eq,x:sp.Symbol,payload:Dict[str,Any])->Optional[Dict[str,Any]]:
    expr=sp.expand(eq.lhs-eq.rhs); p=_poly_coeff(expr,x)
    if p is None or p.degree()!=2: return None
    a=p.coeff_monomial(x**2); b=p.coeff_monomial(x); c=p.coeff_monomial(1)
    if sp.simplify(a)==0: return None
    out={'kind':'GENERAL_QUADRATIC','variable':str(x),'a':a,'b':b,'c':c,
         'source_equation':str(eq),'auto_extracted':True}
    if payload.get('branch') is not None: out['branch']=payload['branch']
    return out

def _absolute_spec(eq:sp.Eq,x:sp.Symbol,payload:Dict[str,Any])->Optional[Dict[str,Any]]:
    # Only canonical Abs(x-a)=c pattern for exact route semantics.
    lhs,rhs=eq.lhs,eq.rhs
    if lhs.func is sp.Abs and not rhs.has(x):
        inside=sp.expand(lhs.args[0]); p=_poly_coeff(inside,x)
        if p is not None and p.degree()==1:
            a=p.coeff_monomial(x); b=p.coeff_monomial(1)
            out={'kind':'ABSOLUTE_VALUE_SCALAR','variable':str(x),'a':a,'b':b,'c':rhs,
                 'source_equation':str(eq),'auto_extracted':True}
            if payload.get('branch') is not None: out['branch']=payload['branch']
            return out
    if rhs.func is sp.Abs and not lhs.has(x):
        return _absolute_spec(sp.Eq(rhs,lhs),x,payload)
    return None

def _exp_spec(eq:sp.Eq,x:sp.Symbol,payload:Dict[str,Any])->Optional[Dict[str,Any]]:
    # canonical base**(alpha*x+beta)=rhs, RHS independent of x
    lhs,rhs=eq.lhs,eq.rhs
    if isinstance(lhs,sp.Pow) and lhs.exp.has(x) and not lhs.base.has(x) and not rhs.has(x):
        exponent=sp.expand(lhs.exp); p=_poly_coeff(exponent,x)
        if p is not None and p.degree()==1:
            alpha=p.coeff_monomial(x); beta=p.coeff_monomial(1)
            return {'kind':'EXPONENTIAL_SCALAR','variable':str(x),'base':lhs.base,'alpha':alpha,'beta':beta,'rhs':rhs,
                    'domain':payload.get('domain','REAL_POSITIVE_BASE'),'source_equation':str(eq),'auto_extracted':True}
    if isinstance(rhs,sp.Pow) and rhs.exp.has(x) and not rhs.base.has(x) and not lhs.has(x):
        return _exp_spec(sp.Eq(rhs,lhs),x,payload)
    return None

def _log_spec(eq:sp.Eq,x:sp.Symbol,payload:Dict[str,Any])->Optional[Dict[str,Any]]:
    lhs,rhs=eq.lhs,eq.rhs
    if lhs.func is sp.log and lhs.args[0].has(x) and not rhs.has(x):
        arg=sp.expand(lhs.args[0]); p=_poly_coeff(arg,x)
        if p is not None and p.degree()==1:
            a=p.coeff_monomial(x); b=p.coeff_monomial(1)
            return {'kind':'LOGARITHMIC_SCALAR','variable':str(x),'a':a,'b':b,'rhs':rhs,
                    'domain':payload.get('domain','REAL_LOG_DOMAIN'),'source_equation':str(eq),'auto_extracted':True}
    if rhs.func is sp.log and rhs.args[0].has(x) and not lhs.has(x):
        return _log_spec(sp.Eq(rhs,lhs),x,payload)
    return None

def _rational_spec(eq:sp.Eq,x:sp.Symbol,payload:Dict[str,Any])->Optional[Dict[str,Any]]:
    expr=sp.together(eq.lhs-eq.rhs)
    num,den=sp.fraction(expr)
    if den==1 or not den.has(x): return None
    pn=_poly_coeff(sp.expand(num),x); pd=_poly_coeff(sp.expand(den),x)
    if pn is None or pn.degree()>1 or pd is None or pd.degree()>1: return None
    # equation num/den = 0 is equivalent to num=0 under den!=0.
    return {'kind':'RATIONAL_SCALAR','variable':str(x),'numerator':sp.expand(num),'denominator':sp.expand(den),
            'source_equation':str(eq),'auto_extracted':True}

def _factored_poly_spec(eq:sp.Eq,x:sp.Symbol,payload:Dict[str,Any])->Optional[Dict[str,Any]]:
    expr=sp.expand(eq.lhs-eq.rhs); p=_poly_coeff(expr,x)
    if p is None or p.degree()<3 or p.degree()>6: return None
    fac=sp.factor_list(expr,x)
    factors=[]
    for f,m in fac[1]:
        pf=_poly_coeff(f,x)
        if pf is None or pf.degree()!=1: return None
        aa=pf.coeff_monomial(x); bb=pf.coeff_monomial(1)
        factors.append({'a':aa,'b':bb,'multiplicity':int(m),'root':sp.simplify(-bb/aa)})
    if not factors: return None
    return {'kind':'POLYNOMIAL_FACTORED','variable':str(x),'polynomial':expr,'factors':factors,
            'source_equation':str(eq),'auto_extracted':True}


def _trig_zero_spec(eq:sp.Eq,x:sp.Symbol,payload:Dict[str,Any])->Optional[Dict[str,Any]]:
    lhs,rhs=eq.lhs,eq.rhs
    if rhs==0 and lhs.func is sp.sin and sp.simplify(lhs.args[0]-x)==0:
        return {'kind':'TRIG_PERIODIC_ZERO','variable':str(x),'function':'sin','source_equation':str(eq),'auto_extracted':True}
    if lhs==0 and rhs.func is sp.sin and sp.simplify(rhs.args[0]-x)==0:
        return {'kind':'TRIG_PERIODIC_ZERO','variable':str(x),'function':'sin','source_equation':str(eq),'auto_extracted':True}
    return None

def _sin_dominance_spec(eq:sp.Eq,x:sp.Symbol,payload:Dict[str,Any])->Optional[Dict[str,Any]]:
    expr=sp.expand_trig(eq.lhs-eq.rhs)
    if sp.simplify(expr-(x+sp.sin(x)))==0 or sp.simplify(expr+(x+sp.sin(x)))==0:
        return {'kind':'SIN_LINEAR_DOMINANCE_ZERO','variable':str(x),'source_equation':str(eq),'auto_extracted':True}
    return None

def _algebraic_root_spec(eq:sp.Eq,x:sp.Symbol,payload:Dict[str,Any])->Optional[Dict[str,Any]]:
    expr=sp.expand(eq.lhs-eq.rhs); p=_poly_coeff(expr,x)
    if p is None or p.degree()<3: return None
    return {'kind':'ALGEBRAIC_ROOT_SET','variable':str(x),'polynomial':expr,'degree':int(p.degree()),'source_equation':str(eq),'auto_extracted':True}

def infer_route_spec(payload:Dict[str,Any]) -> Dict[str,Any]:
    """Infer a typed route spec from exact structured input.

    This is deliberately fail-closed: it reads an explicit equation field, not arbitrary prose.
    It never invents a metric weight. Unsupported forms return exact missing obligations.
    """
    # Existing typed route wins.
    for key in ('causal_grid_route_spec','route_spec'):
        c=payload.get(key)
        if isinstance(c,dict) and c.get('kind'):
            return {'status':'EXPLICIT_ROUTE_SPEC','route_spec':dict(c),'requires':[],'source':key}

    # Universal declarative / normative constraint carrier.  This is intentionally
    # domain-agnostic and precedes equation-only extraction.  It compiles declared
    # rules into a typed carrier without pretending the rule text is scientific truth.
    constraint = infer_constraint_route(payload)
    if constraint is not None:
        return constraint

    # Structured non-equation packets.
    if payload.get('matrix_A') is not None and payload.get('matrix_b') is not None:
        return {'status':'AUTO_EXTRACTED','route_spec':{'kind':'LINEAR_SYSTEM','A':payload['matrix_A'],'b':payload['matrix_b'],'auto_extracted':True},'requires':[],'source':'matrix_packet'}
    if payload.get('derivative_rhs') is not None and payload.get('boundary_value') is not None:
        return {'status':'AUTO_EXTRACTED','route_spec':{'kind':'DERIVATIVE_WITH_BOUNDARY','rhs':payload['derivative_rhs'],'f0':payload['boundary_value'],'t0':payload.get('boundary_time',0),'variable':payload.get('variable','t'),'auto_extracted':True},'requires':[],'source':'derivative_packet'}
    if payload.get('dft_n') is not None:
        return {'status':'AUTO_EXTRACTED','route_spec':{'kind':'FINITE_DFT','n':int(payload['dft_n']),'auto_extracted':True},'requires':[],'source':'dft_packet'}

    equation=payload.get('equation')
    if equation is None:
        return {'status':'NEED_DATA','route_spec':None,'requires':['EXPLICIT_EQUATION_OR_STRUCTURED_ROUTE_PACKET'],'source':'none'}
    variable=str(payload.get('variable') or 'x')
    try:
        eq,x=_parse_equation(equation,variable)
    except Exception as exc:
        return {'status':'PARSE_FAILED','route_spec':None,'requires':['PARSEABLE_EXACT_EQUATION'],'error':str(exc),'source':'equation'}

    # Order matters: rational before polynomial, special functions before generic polynomial.
    for fn in (
        lambda: _trig_zero_spec(eq,x,payload),
        lambda: _sin_dominance_spec(eq,x,payload),
        lambda: _absolute_spec(eq,x,payload),
        lambda: _exp_spec(eq,x,payload),
        lambda: _log_spec(eq,x,payload),
        lambda: _rational_spec(eq,x,payload),
        lambda: _linear_spec(eq,x),
        lambda: _quadratic_spec(eq,x,payload),
        lambda: _factored_poly_spec(eq,x,payload),
        lambda: _algebraic_root_spec(eq,x,payload),
    ):
        spec=fn()
        if spec:
            if payload.get('metric_weights') is not None:
                spec['metric_weights']=payload['metric_weights']
            return {'status':'AUTO_EXTRACTED','route_spec':spec,'requires':[],'source':'equation'}

    return {
        'status':'OPEN_TYPED','route_spec':None,
        'requires':['ROUTE_FAMILY_CLASSIFICATION','CAKE_TYPE','PLATE_TYPE','OPERATOR_SIGNATURE'],
        'equation':str(eq),'source':'equation',
        'note':'Equation parsed exactly but no certified route family compiler matches it.'
    }
