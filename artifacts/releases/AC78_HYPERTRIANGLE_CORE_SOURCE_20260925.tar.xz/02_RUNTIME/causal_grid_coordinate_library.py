from __future__ import annotations

from dataclasses import asdict
from fractions import Fraction
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple

from causal_cartesian_plane_aux import (
    FINAL_PROFILE_ID,
    DECLARED_CLASS_ID,
    PlaneContractError,
    SemanticType,
    TemporalStamp,
    MetricPoint,
    RealizationKey,
    CertifiedRealization,
    LinearBridge,
    CanonicalCoordinateLibrary,
    ActiveGrid,
    build_active_grid,
    validate_grid,
    semantic_transparency_receipt,
    digest,
)

SCHEMA = "AC74_CANONICAL_COORDINATE_LIBRARY_CORE_V1"


def _semantic_from(row: Mapping[str, Any]) -> SemanticType:
    required = ("authority_id", "family", "domain", "plate_contract", "canonical_name")
    missing = [k for k in required if row.get(k) in (None, "")]
    if missing:
        raise PlaneContractError(f"semantic type missing: {','.join(missing)}")
    return SemanticType(*(str(row[k]) for k in required))


def _temporal_from(row: Mapping[str, Any]) -> TemporalStamp:
    if row.get("epoch") in (None, "") or row.get("phase") in (None, ""):
        raise PlaneContractError("temporal stamp requires epoch and phase")
    return TemporalStamp(str(row["epoch"]), str(row["phase"]), str(row.get("ancestry_digest") or ""))


def _metric_from(row: Mapping[str, Any]) -> MetricPoint:
    if row.get("metric_receipt_id") in (None, ""):
        raise PlaneContractError("metric requires metric_receipt_id")
    if row.get("t") is None or row.get("s") is None:
        raise PlaneContractError("metric requires exact t and s")
    return MetricPoint.make(row["t"], row["s"], bool(row.get("orthogonal", False)), str(row["metric_receipt_id"]))


def _key_from(semantic: SemanticType, row: Mapping[str, Any]) -> RealizationKey:
    temporal = _temporal_from(row.get("temporal") or {})
    required = ("carrier_id", "metric_signature", "orientation", "authority_version")
    missing = [k for k in required if row.get(k) in (None, "")]
    if missing:
        raise PlaneContractError(f"realization key missing: {','.join(missing)}")
    declared_type_id = str(row.get("type_id") or semantic.type_id)
    if declared_type_id != semantic.type_id:
        raise PlaneContractError("declared type_id does not match semantic type")
    return RealizationKey(
        semantic.type_id,
        str(row["carrier_id"]),
        str(row["metric_signature"]),
        temporal,
        str(row["orientation"]),
        str(row["authority_version"]),
    )


def _realization_from(row: Mapping[str, Any]) -> CertifiedRealization:
    semantic = _semantic_from(row.get("semantic") or {})
    key = _key_from(semantic, row.get("key") or {})
    metric = _metric_from(row.get("metric") or {})
    residual_schema = str(row.get("residual_schema") or "NO_RESIDUAL_SCHEMA_DECLARED")
    mirror_policy = str(row.get("mirror_policy") or "STRUCTURAL_MIRROR_ONLY")
    provenance = str(row.get("provenance_digest") or "")
    if not provenance:
        raise PlaneContractError("certified realization requires provenance_digest")
    return CertifiedRealization(
        semantic=semantic,
        key=key,
        metric=metric,
        residual_schema=residual_schema,
        mirror_policy=mirror_policy,
        provenance_digest=provenance,
        certified=bool(row.get("certified", True)),
    )


def _bridge_from(row: Mapping[str, Any]) -> LinearBridge:
    required = (
        "source_carrier", "target_carrier", "source_metric_signature",
        "target_metric_signature", "matrix", "bridge_receipt_id",
    )
    missing = [k for k in required if row.get(k) in (None, "")]
    if missing:
        raise PlaneContractError(f"bridge missing: {','.join(missing)}")
    return LinearBridge.make(
        str(row["source_carrier"]),
        str(row["target_carrier"]),
        str(row["source_metric_signature"]),
        str(row["target_metric_signature"]),
        row["matrix"],
        str(row["bridge_receipt_id"]),
        bool(row.get("isometry_certified", False)),
    )


def _metric_dict(p: MetricPoint) -> Dict[str, Any]:
    return {
        "t": str(p.t),
        "s": str(p.s),
        "orthogonal": p.orthogonal,
        "metric_receipt_id": p.metric_receipt_id,
        "pythagorean_weight": str(p.pythagorean_weight) if p.orthogonal else None,
    }


def _realization_dict(r: CertifiedRealization) -> Dict[str, Any]:
    return {
        "realization_id": r.realization_id,
        "semantic": asdict(r.semantic),
        "type_id": r.semantic.type_id,
        "key": {
            "type_id": r.key.type_id,
            "carrier_id": r.key.carrier_id,
            "metric_signature": r.key.metric_signature,
            "temporal": asdict(r.key.temporal),
            "orientation": r.key.orientation,
            "authority_version": r.key.authority_version,
            "key_digest": r.key.key,
        },
        "metric": _metric_dict(r.metric),
        "residual_schema": r.residual_schema,
        "mirror_policy": r.mirror_policy,
        "provenance_digest": r.provenance_digest,
        "certified": r.certified,
    }


def _grid_dict(grid: ActiveGrid) -> Dict[str, Any]:
    return {
        "problem_id": grid.problem_id,
        "total_weight": str(grid.total_weight),
        "grid_digest": grid.grid_digest,
        "errors": validate_grid(grid),
        "cells": [
            {
                "occurrence_id": c.occurrence_id,
                "realization_id": c.realization_id,
                "semantic_type_id": c.semantic_type_id,
                "weight": str(c.weight),
                "rank_address": c.rank_address,
                "q0": str(c.q0),
                "q1": str(c.q1),
                "mirror_occurrence_id": c.mirror_occurrence_id,
                "metric": _metric_dict(c.metric_point),
            }
            for c in grid.cells
        ],
    }


class CanonicalCoordinateCore:
    """Stateful AC74 integration of the frozen CP026 coordinate-library profile.

    This service is deliberately non-semantic. It never creates a metric, a theorem,
    a carrier equivalence, a Temporal identity, or ROOT truth. It only stores and
    reuses already-certified realizations under CP026's exact firewalls.
    """

    def __init__(self):
        self.library = CanonicalCoordinateLibrary()
        self.realizations: Dict[str, CertifiedRealization] = {}
        self.active_grids: Dict[str, ActiveGrid] = {}
        self.request_count = 0
        self.exact_hit_count = 0
        self.projectable_count = 0
        self.recalculate_count = 0
        self.grid_build_count = 0
        self.mirror_grid_count = 0

    def _register_realization(self, row: Mapping[str, Any]) -> Dict[str, Any]:
        r = _realization_from(row)
        self.library.register_realization(r)
        self.realizations[r.realization_id] = r
        hit = self.library.exact_lookup(r.key)
        if hit.status != "EXACT_HIT":
            raise PlaneContractError("post-registration exact lookup failed")
        self.exact_hit_count += 1
        return {
            "status": "PASS",
            "action": "REGISTER_REALIZATION",
            "lookup_status": "EXACT_HIT",
            "realization": _realization_dict(r),
            "supplies": ["CP026_CERTIFIED_REALIZATION_REGISTERED", "CP026_EXACT_HIT"],
        }

    def _register_bridge(self, row: Mapping[str, Any]) -> Dict[str, Any]:
        b = _bridge_from(row)
        self.library.register_bridge(b)
        return {
            "status": "PASS",
            "action": "REGISTER_BRIDGE",
            "bridge": {
                "source_carrier": b.source_carrier,
                "target_carrier": b.target_carrier,
                "source_metric_signature": b.source_metric_signature,
                "target_metric_signature": b.target_metric_signature,
                "matrix": [[str(x) for x in rr] for rr in b.matrix],
                "bridge_receipt_id": b.bridge_receipt_id,
                "isometry_certified": b.isometry_certified,
            },
            "supplies": ["CP026_CARRIER_METRIC_BRIDGE_REGISTERED"],
        }

    def _lookup(self, row: Mapping[str, Any]) -> Dict[str, Any]:
        semantic = _semantic_from(row.get("semantic") or {})
        key = _key_from(semantic, row.get("key") or {})
        result = self.library.lookup_or_project(key)
        out: Dict[str, Any] = {
            "action": "LOOKUP",
            "lookup_status": result.status,
            "reason": result.reason,
            "target_key_digest": key.key,
            "semantic_type_id": semantic.type_id,
            "truth_credit_added": 0,
        }
        if result.realization is not None:
            out["realization"] = _realization_dict(result.realization)
        if result.bridge is not None:
            out["bridge_receipt_id"] = result.bridge.bridge_receipt_id
        if result.status == "EXACT_HIT":
            self.exact_hit_count += 1
            out.update({"status": "PASS", "supplies": ["CP026_EXACT_HIT"]})
        elif result.status == "PROJECTABLE":
            self.projectable_count += 1
            out.update({"status": "PASS", "supplies": ["CP026_PROJECTABLE_COORDINATE"]})
            if bool(row.get("store_projected", False)) and result.realization is not None:
                self.library.register_realization(result.realization)
                self.realizations[result.realization.realization_id] = result.realization
                out["projected_realization_stored"] = True
        else:
            self.recalculate_count += 1
            out.update({
                "status": "OPEN",
                "requires": ["RECALCULATE_CERTIFIED_REALIZATION"],
                "supplies": ["CP026_RECALCULATE_DECISION"],
                "movement_blocked": False,
            })
        return out

    def _build_grid(self, row: Mapping[str, Any]) -> Dict[str, Any]:
        problem_id = str(row.get("problem_id") or "")
        if not problem_id:
            raise PlaneContractError("BUILD_ACTIVE_GRID requires problem_id")
        occ_rows = row.get("ordered_occurrences")
        if not isinstance(occ_rows, list) or not occ_rows:
            raise PlaneContractError("BUILD_ACTIVE_GRID requires non-empty ordered_occurrences")
        ordered = []
        for item in occ_rows:
            if not isinstance(item, Mapping):
                raise PlaneContractError("ordered occurrence must be an object")
            rid = str(item.get("realization_id") or "")
            if rid not in self.realizations:
                raise PlaneContractError(f"unknown realization_id: {rid}")
            occ = str(item.get("occurrence_id") or "")
            if not occ:
                raise PlaneContractError("occurrence_id required")
            rank = int(item.get("rank_address"))
            ordered.append((occ, self.realizations[rid], rank))
        grid = build_active_grid(problem_id, ordered)
        errors = validate_grid(grid)
        if errors:
            raise PlaneContractError("active grid validation failed: " + ",".join(errors))
        self.active_grids[problem_id] = grid
        self.grid_build_count += 1
        return {
            "status": "PASS",
            "action": "BUILD_ACTIVE_GRID",
            "grid": _grid_dict(grid),
            "problem_local": True,
            "inactive_prior_problem_cells_counted": False,
            "rank_used_as_metric": False,
            "supplies": ["CP026_ACTIVE_GRID_BUILT", "CP026_LOCAL_GRID_VALIDATED"],
        }

    def _mirror_grid(self, row: Mapping[str, Any]) -> Dict[str, Any]:
        problem_id = str(row.get("problem_id") or "")
        grid = self.active_grids.get(problem_id)
        if grid is None:
            raise PlaneContractError("MIRROR_ACTIVE_GRID requires an existing problem-local grid")
        mirrored = grid.mirror()
        errors = validate_grid(mirrored)
        if errors:
            raise PlaneContractError("mirrored grid validation failed: " + ",".join(errors))
        invariant = all(
            a.weight == b.weight and a.q0 == b.q0 and a.q1 == b.q1 and
            a.metric_point.t == b.metric_point.s and a.metric_point.s == b.metric_point.t
            for a, b in zip(grid.cells, mirrored.cells)
        )
        if not invariant:
            raise PlaneContractError("mirror invariant failed")
        self.mirror_grid_count += 1
        return {
            "status": "PASS",
            "action": "MIRROR_ACTIVE_GRID",
            "source_problem_id": problem_id,
            "mirror_grid": _grid_dict(mirrored),
            "q_sigma_weight_preserved": True,
            "ts_swapped": True,
            "causal_reverse_claimed": False,
            "supplies": ["CP026_STRUCTURAL_MIRROR_GRID"],
        }

    def _transparency(self, row: Mapping[str, Any]) -> Dict[str, Any]:
        direct_id = str(row.get("direct_problem_id") or "")
        cached_id = str(row.get("cached_problem_id") or "")
        direct = self.active_grids.get(direct_id)
        cached = self.active_grids.get(cached_id)
        if direct is None or cached is None:
            raise PlaneContractError("SEMANTIC_TRANSPARENCY requires two existing grids")
        receipt = semantic_transparency_receipt(direct, cached)
        return {
            "status": "PASS" if receipt["same_semantics"] else "OPEN",
            "action": "SEMANTIC_TRANSPARENCY",
            **receipt,
            "requires": [] if receipt["same_semantics"] else ["RECALCULATE_OR_REJECT_CACHE_REUSE"],
            "supplies": ["CP026_CACHE_SEMANTIC_TRANSPARENCY"] if receipt["same_semantics"] else ["CP026_CACHE_MISMATCH_DETECTED"],
        }

    def _snapshot(self) -> Dict[str, Any]:
        d = self.library.to_dict()
        return {
            "status": "PASS",
            "action": "SNAPSHOT",
            "profile": FINAL_PROFILE_ID,
            "declared_class": DECLARED_CLASS_ID,
            "library_digest": digest(d),
            "type_count": len(d.get("types") or []),
            "realization_count": len(d.get("realizations") or []),
            "bridge_count": len(d.get("bridges") or []),
            "active_problem_grid_count": len(self.active_grids),
            "supplies": ["CP026_LIBRARY_SNAPSHOT"],
        }

    def apply_one(self, request: Mapping[str, Any]) -> Dict[str, Any]:
        self.request_count += 1
        action = str(request.get("action") or "").upper().strip()
        try:
            if action == "REGISTER_REALIZATION":
                out = self._register_realization(request.get("realization") or {})
            elif action == "REGISTER_BRIDGE":
                out = self._register_bridge(request.get("bridge") or {})
            elif action == "LOOKUP":
                out = self._lookup(request)
            elif action == "BUILD_ACTIVE_GRID":
                out = self._build_grid(request)
            elif action == "MIRROR_ACTIVE_GRID":
                out = self._mirror_grid(request)
            elif action == "SEMANTIC_TRANSPARENCY":
                out = self._transparency(request)
            elif action == "SNAPSHOT":
                out = self._snapshot()
            else:
                out = {
                    "status": "OPEN",
                    "action": action or "MISSING_ACTION",
                    "requires": ["SUPPORTED_CP026_LIBRARY_ACTION"],
                    "supplies": ["CP026_LIBRARY_REQUEST_DIAGNOSIS"],
                    "movement_blocked": False,
                }
        except (PlaneContractError, ValueError, TypeError, KeyError) as e:
            out = {
                "status": "REJECTED",
                "action": action or "MISSING_ACTION",
                "reason": str(e),
                "requires": ["VALID_CP026_CERTIFIED_INPUT"],
                "supplies": ["CP026_LIBRARY_CONTRACT_REJECTION"],
                "movement_blocked": False,
            }
        out.setdefault("schema", SCHEMA)
        out.setdefault("profile", FINAL_PROFILE_ID)
        out.setdefault("declared_class", DECLARED_CLASS_ID)
        out.setdefault("truth_credit_added", 0)
        out.setdefault("external_scientific_truth_certified", False)
        return out

    def apply_payload(self, payload: Mapping[str, Any]) -> Dict[str, Any]:
        requests: List[Mapping[str, Any]] = []
        one = payload.get("canonical_coordinate_library_request")
        many = payload.get("canonical_coordinate_library_requests")
        if isinstance(one, Mapping):
            requests.append(one)
        if isinstance(many, list):
            requests.extend(x for x in many if isinstance(x, Mapping))
        if not requests:
            return {"schema": SCHEMA, "status": "NO_COORDINATE_LIBRARY_REQUEST", "receipts": []}
        receipts = [self.apply_one(r) for r in requests]
        statuses = [r.get("status") for r in receipts]
        if statuses and all(s == "PASS" for s in statuses):
            status = "PASS"
        elif any(s == "REJECTED" for s in statuses):
            status = "PARTIAL"
        else:
            status = "PARTIAL"
        open_requirements = sorted({
            str(req)
            for receipt in receipts
            for req in (receipt.get("requires") or [])
        })
        return {
            "schema": SCHEMA,
            "status": status,
            "profile": FINAL_PROFILE_ID,
            "declared_class": DECLARED_CLASS_ID,
            "receipts": receipts,
            "open_requirements": open_requirements,
            "semantic_authority_added": False,
            "metric_from_borges_rank": False,
            "cross_carrier_reuse_without_certified_bridge": False,
        }

    def counters(self) -> Dict[str, int]:
        return {
            "requests": self.request_count,
            "exact_hits": self.exact_hit_count,
            "projectable": self.projectable_count,
            "recalculate": self.recalculate_count,
            "active_grids": self.grid_build_count,
            "mirror_grids": self.mirror_grid_count,
        }
