from __future__ import annotations
from typing import Any, Dict, List
import sympy as sp

# AC72/CP020 executable bindings for structural theorems closed in CP019.
# These routines never infer a metric, Phi5 projection, section, or domain law from names.
# They bind only explicitly supplied mathematical data.


def _M(x: Any) -> sp.Matrix:
    return x if isinstance(x, sp.MatrixBase) else sp.Matrix(x)


def _S(x: Any) -> sp.Expr:
    return x if isinstance(x, sp.Basic) else sp.sympify(x)


def _json_matrix(M: sp.MatrixBase) -> List[List[str]]:
    return [[str(sp.simplify(M[i,j])) for j in range(M.cols)] for i in range(M.rows)]


def _json_vector(v: sp.MatrixBase) -> List[str]:
    return [str(sp.simplify(v[i,0])) for i in range(v.rows)]


def bind_metric_weight(displacement: Any, metric: Any) -> Dict[str, Any]:
    d=_M(displacement)
    if d.cols != 1:
        d=sp.Matrix(list(d))
    G=_M(metric)
    if G.rows != G.cols or G.rows != d.rows:
        return {'status':'REJECTED','reason':'metric/displacement dimension mismatch'}
    if sp.simplify(G-G.T) != sp.zeros(G.rows):
        return {'status':'REJECTED','reason':'metric must be symmetric on declared real carrier'}
    w=sp.simplify((d.T*G*d)[0])
    return {
        'status':'PASS','schema':'AC72_GROUNDED_WEIGHT_V1',
        'weight':str(w),'displacement':_json_vector(d),'metric':_json_matrix(G),
        'metric_invented':False,'rule':'w = Delta^T G Delta'
    }


def bind_cumulative_q(weights: List[Any]) -> Dict[str, Any]:
    vals=[sp.simplify(_S(x)) for x in weights]
    if not vals:
        return {'status':'REJECTED','reason':'empty weight list'}
    for v in vals:
        if v.is_number and v <= 0:
            return {'status':'REJECTED','reason':'weights must be positive for nondegenerate cells'}
    total=sp.simplify(sum(vals,sp.Integer(0)))
    if total == 0:
        return {'status':'REJECTED','reason':'zero total weight'}
    acc=sp.Integer(0); q=[sp.Integer(0)]
    for v in vals:
        acc=sp.simplify(acc+v); q.append(sp.simplify(acc/total))
    return {
        'status':'PASS','schema':'AC72_Q_BINDING_V1','weights':[str(v) for v in vals],
        'total_weight':str(total),'q_bounds':[str(x) for x in q],
        'rule':'q_k = cumulative grounded weight / total grounded weight',
        'order_is_not_metric':True
    }


def bind_linear_hilbert_residue(A: Any, x: Any) -> Dict[str, Any]:
    A=_M(A); x=_M(x)
    if x.cols != 1:
        x=sp.Matrix(list(x))
    if A.cols != x.rows:
        return {'status':'REJECTED','reason':'operator/state dimension mismatch'}
    pinv=A.pinv()
    y=sp.simplify(A*x)
    visible=sp.simplify(pinv*y)
    residue=sp.simplify(x-visible)
    recon=sp.simplify(visible+residue)
    orth=sp.simplify((visible.T*residue)[0])
    nx=sp.simplify((x.T*x)[0]); nv=sp.simplify((visible.T*visible)[0]); nr=sp.simplify((residue.T*residue)[0])
    ker_check=sp.simplify(A*residue)
    return {
        'status':'PASS' if recon==x and ker_check==sp.zeros(A.rows,1) and orth==0 and sp.simplify(nx-nv-nr)==0 else 'FAIL',
        'schema':'AC72_LINEAR_HILBERT_RESIDUE_V1',
        'output':_json_vector(y),'visible_reconstruction':_json_vector(visible),'residue':_json_vector(residue),
        'reconstruction':_json_vector(recon),'kernel_check':_json_vector(ker_check),
        'orthogonality':str(orth),'input_energy':str(nx),'visible_energy':str(nv),'residue_energy':str(nr),
        'pythagorean_residual':str(sp.simplify(nx-nv-nr)),
        'rule':'x = A^+ A x + P_ker(A) x'
    }


def classify_ts_role(operator: Any, metric: Any | None = None) -> Dict[str, Any]:
    J=_M(operator)
    if J.rows != 2 or J.cols != 2:
        return {'status':'OPEN_TYPED','role':'MIXED_TYPED','reason':'classifier currently requires declared 2D T/S active plane'}
    G=sp.eye(2) if metric is None else _M(metric)
    if G.shape != (2,2):
        return {'status':'REJECTED','role':'MIXED_TYPED','reason':'metric must be 2x2'}
    isometry=sp.simplify(J.T*G*J-G)==sp.zeros(2)
    square=sp.simplify(J*J)
    swaps_axes=bool(J[0,0]==0 and J[1,1]==0 and J[0,1]!=0 and J[1,0]!=0)
    if isometry and square == -sp.eye(2) and swaps_axes:
        role='RIGHT_ANGLE_GATE'
    elif isometry and square == sp.eye(2) and swaps_axes:
        role='MIRROR_REFLECTION'
    elif J[1,0]==0 and J[0,1]==0:
        role='LONGITUDINAL_TYPED'
    else:
        role='MIXED_TYPED'
    return {
        'status':'PASS','schema':'AC72_TS_ROLE_CLASSIFIER_V1','role':role,
        'isometry':bool(isometry),'square':_json_matrix(square),'swaps_axes':swaps_axes,
        'operator':_json_matrix(J),'metric':_json_matrix(G)
    }


def bind_phi5_weight(delta_s: Any, metric_G: Any, psi_authority: Any = None) -> Dict[str, Any]:
    if not psi_authority:
        return {
            'status':'OPEN_MISSING_PSI','schema':'AC72_PHI5_BINDING_V1',
            'requires':['OPERATOR_TO_PHI5_TYPED_PROJECTION_PSI'],
            'reason':'Phi5 metric cannot be bound to an arbitrary operator without an authoritative Psi projection'
        }
    out=bind_metric_weight(delta_s,metric_G)
    out['schema']='AC72_PHI5_BINDING_V1'
    out['psi_authority']=str(psi_authority)
    out['phi5_binding_conditional']=True
    return out


def bind_quotient_lift(visible_class: Any, fibre_coordinate: Any = None, section_authority: Any = None) -> Dict[str, Any]:
    if section_authority is None:
        return {
            'status':'OPEN_MISSING_SECTION','schema':'AC72_QUOTIENT_LIFT_V1',
            'visible_class':str(visible_class),'requires':['SECTION_GAUGE_OR_LIFT_AUTHORITY'],
            'reason':'a quotient class alone does not globally reconstruct its representative'
        }
    if fibre_coordinate is None:
        return {
            'status':'OPEN_MISSING_FIBRE_RESIDUE','schema':'AC72_QUOTIENT_LIFT_V1',
            'visible_class':str(visible_class),'section_authority':str(section_authority),
            'requires':['FIBRE_ORBIT_COORDINATE']
        }
    return {
        'status':'PASS','schema':'AC72_QUOTIENT_LIFT_V1','visible_class':str(visible_class),
        'fibre_coordinate':str(fibre_coordinate),'section_authority':str(section_authority),
        'mirror_kind':'SECTION_PLUS_FIBRE_RECONSTRUCTION'
    }


def apply_bindings(payload: Dict[str, Any], diagnosis: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {'schema':'AC72_CAUSAL_GRID_BINDINGS_V1','bindings':{}}
    b=out['bindings']
    req=payload.get('metric_binding')
    if isinstance(req,dict) and 'displacement' in req and 'metric' in req:
        b['weight']=bind_metric_weight(req['displacement'],req['metric'])
    qreq=payload.get('q_binding')
    if isinstance(qreq,dict) and isinstance(qreq.get('weights'),list):
        b['q']=bind_cumulative_q(qreq['weights'])
    lreq=payload.get('linear_residue_binding')
    if isinstance(lreq,dict) and 'A' in lreq and 'x' in lreq:
        b['linear_residue']=bind_linear_hilbert_residue(lreq['A'],lreq['x'])
    rreq=payload.get('role_classifier_binding')
    if isinstance(rreq,dict) and 'operator' in rreq:
        b['role']=classify_ts_role(rreq['operator'],rreq.get('metric'))
    preq=payload.get('phi5_binding')
    if isinstance(preq,dict) and 'delta_s' in preq and 'metric' in preq:
        b['phi5']=bind_phi5_weight(preq['delta_s'],preq['metric'],preq.get('psi_authority'))
    ql=payload.get('quotient_lift_binding')
    if isinstance(ql,dict) and 'visible_class' in ql:
        b['quotient_lift']=bind_quotient_lift(ql.get('visible_class'),ql.get('fibre_coordinate'),ql.get('section_authority'))
    # If all route cells have explicit grounded weights, bind q into the diagnosis.
    cells=diagnosis.get('cells') or []
    grounded=[]
    all_grounded=bool(cells)
    for c in cells:
        if c.get('grounded_weight') is None:
            all_grounded=False; break
        grounded.append(c.get('grounded_weight'))
    if all_grounded:
        b['route_q']=bind_cumulative_q(grounded)
    statuses=[v.get('status') for v in b.values() if isinstance(v,dict)]
    out['status']='PASS' if statuses and all(s=='PASS' for s in statuses) else ('PARTIAL' if statuses else 'NO_BINDING_REQUEST')
    out['open_requirements']=sorted({r for v in b.values() if isinstance(v,dict) for r in (v.get('requires') or [])})
    return out
