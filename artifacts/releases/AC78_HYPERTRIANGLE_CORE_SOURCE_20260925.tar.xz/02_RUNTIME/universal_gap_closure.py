from __future__ import annotations
import hashlib, json
from typing import Any, Dict
from all_everything_wave_engine import AuxResult, Node, normalize_requirement, split_requirement, requirement_family
REPRESENTATION_FAMILIES = {'FORMAL_GOAL', 'SUPPORTED_FORMALIZATION', 'ADAPTER_SPECIFICATION', 'MATERIAL_SPECIFICATION', 'PROVIDER_SPECIFICATION', 'RELATION_SIGNATURE', 'CARRIER_SPECIFICATION', 'RECONSTRUCTION_RULE'}
BRIDGE_FAMILIES = {'RECOVERY_EVIDENCE', 'DUAL_OR_OBSTRUCTION_WITNESS'}

def _canon(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False, default=str)

def _sha(x):
    return hashlib.sha256(_canon(x).encode()).hexdigest()

def _result(node, status, kind, **payload):
    return AuxResult('UNIVERSAL_GAP_CLOSURE', status, kind, payload, node.identity())

def _target_req(node):
    if node.kind == 'OPEN_RESIDUAL' and node.payload.get('obligation'):
        return normalize_requirement(str(node.payload['obligation']))
    req = node.payload.get('requires') or []
    if isinstance(req, str):
        req = [req]
    if len(req) == 1:
        return normalize_requirement(str(req[0]))
    t = node.payload.get('target_obligation')
    return normalize_requirement(str(t)) if t else ''

def _rep_cert(kind, base, req, context, payload):
    sin1 = {'kind': kind, 'base': base, 'requirement': req, 'context': list(context), 'payload': payload}
    sin2 = dict(payload=payload, context=list(context), requirement=req, base=base, kind=kind)
    d1 = _sha(sin1)
    d2 = _sha({'kind': sin2['kind'], 'base': sin2['base'], 'requirement': sin2['requirement'], 'context': sin2['context'], 'payload': sin2['payload']})
    return dict(representation_only=True, representation_digest=d1, independent_reconstruction_digest=d2, representation_local_2sin1cos_verified=d1 == d2, representation_cos_verified=d1 == d2)

def _find_authoritative(world: Dict[str, Any], base: str):
    for key in ('dynamic_artifact_catalog', 'artifact_catalog', 'materialization_catalog'):
        xs = world.get(key) or []
        if isinstance(xs, dict):
            xs = list(xs.values())
        for e in xs if isinstance(xs, list) else []:
            if not isinstance(e, dict):
                continue
            ts = set((str(x) for x in e.get('targets') or []))
            for k in ('target', 'id', 'name', 'object_id'):
                if e.get(k):
                    ts.add(str(e[k]))
            su = set((str(x) for x in e.get('supplies') or []))
            if base not in ts and base not in su:
                continue
            if e.get('authoritative') is True or e.get('verified') is True or str(e.get('status', '')).upper() in {'VERIFIED', 'CERTIFIED', 'TERMINAL'}:
                return e
    return None

def universal_gap_closure(node: Node, world: Dict[str, Any]):
    if not (world.get('target_grain_mode') or world.get('universal_recursive_mode') or world.get('ac60_gap_closure_mode')):
        return _result(node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='UNIVERSAL_GAP_CLOSURE_COMPATIBILITY_NOOP')
    if node.kind == 'KERNEL_RECEIPT' and node.payload.get('kernel_verified'):
        base = str(node.payload.get('formal_target') or node.payload.get('statement') or '')
        if base:
            return _result(node, 'PASS', 'SCIENTIFIC_CLOSURE_RECEIPT', statement='VERIFIED_PROOF_CLOSES_GENERIC_PROOF_FRONTIER', formal_target=base, supplies=[f'COMPLETE_PROOF_OBJECT::{base}', f'COMPLETE_DUAL_OR_OBSTRUCTION::{base}'])
    if node.kind == 'COUNTEREXAMPLE' and node.payload.get('counterexample_verified'):
        base = str(node.payload.get('formal_target') or node.payload.get('target') or node.payload.get('statement') or '')
        if base:
            return _result(node, 'PASS', 'SCIENTIFIC_CLOSURE_RECEIPT', statement='VERIFIED_COUNTEREXAMPLE_CLOSES_GENERIC_OBSTRUCTION_FRONTIER', formal_target=base, supplies=[f'COMPLETE_DUAL_OR_OBSTRUCTION::{base}'])
    if node.kind in {'MATERIALIZED_OBJECT', 'AUTO_MATERIALIZED_OBJECT', 'CARRIER_OBJECT', 'PROVIDER_OBJECT', 'RELATION_OBJECT', 'EXECUTABLE_PARALLEL_TRANSPORT_TOOL'}:
        base = str(node.payload.get('construction_target') or node.payload.get('target') or '')
        if base and (node.payload.get('status') == 'PASS' or node.payload.get('representation_local_2sin1cos_verified')):
            return _result(node, 'PASS', 'SCIENTIFIC_CLOSURE_RECEIPT', statement='VERIFIED_MATERIAL_CLOSES_GENERIC_CONSTRUCTION_FRONTIER', construction_target=base, supplies=[f'COMPLETE_CONSTRUCTION::{base}'])
    req = _target_req(node)
    if not req:
        if node.payload.get('status') == 'CAPABILITY_GAP':
            base = str(node.payload.get('missing_capability') or node.payload.get('statement') or node.kind)
            req = f'ADAPTER_SPECIFICATION::{base}'
        elif node.payload.get('status') == 'MISSING_CARRIER':
            base = str(node.payload.get('target_obligation') or node.payload.get('statement') or node.kind)
            req = f'CARRIER_SPECIFICATION::{base}'
        else:
            return _result(node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='UNIVERSAL_GAP_CLOSURE_NO_TYPED_GAP')
    fam, base = (lambda wb: (wb[0][0] if wb[0] else 'RAW_SCIENTIFIC', wb[1]))(split_requirement(req))
    if fam == 'FORMAL_GOAL':
        formal = {'schema': 'AC60_OPAQUE_ATOMIC_SCIENTIFIC_GOAL_V1', 'atom': base, 'hypotheses': [], 'conclusion': base, 'scope': 'EXACT_CURRENT'}
        cert = _rep_cert('FORMAL_GOAL', base, req, node.context, formal)
        return _result(node, 'OPEN', 'FORMAL_GOAL_PACKET', statement='UNIVERSAL_FORMAL_GOAL_MATERIALIZED', formal_target=base, formal_statement=formal, zfc_goal={'kind': 'OPAQUE_ATOM', 'atom': base}, target=base, supplies=[req], requires=[f'COMPLETE_PROOF_OBJECT::{base}'], required_effect_match=True, scientific_frontier_bridge=True, **cert)
    if fam == 'SUPPORTED_FORMALIZATION':
        formal = {'schema': 'AC60_SUPPORTED_OPAQUE_FORMALIZATION_V1', 'atom': base, 'semantics': 'UNINTERPRETED_SCIENTIFIC_ATOM', 'truth_claim': False}
        cert = _rep_cert('SUPPORTED_FORMALIZATION', base, req, node.context, formal)
        return _result(node, 'PASS', 'FORMALIZATION_RECEIPT', statement='UNIVERSAL_SUPPORTED_FORMALIZATION_MATERIALIZED', formal_target=base, formalization=formal, target=base, supplies=[req], **cert)
    if fam == 'CARRIER_SPECIFICATION':
        carrier = {'schema': 'AC60_SYMBOLIC_SCIENTIFIC_CARRIER_V1', 'carrier_id': 'SYMBOLIC::' + _sha({'base': base, 'context': list(node.context)})[:24], 'target': base, 'context': list(node.context), 'scope': 'CURRENT_EXACT', 'truth_claim': False}
        cert = _rep_cert('CARRIER_SPECIFICATION', base, req, node.context, carrier)
        return _result(node, 'PASS', 'CARRIER_OBJECT', statement='UNIVERSAL_SYMBOLIC_CARRIER_MATERIALIZED', target=base, carrier=carrier, carrier_digest=_sha(carrier), supplies=[req, 'TYPED_CARRIER'], **cert)
    if fam == 'PROVIDER_SPECIFICATION':
        provider = {'schema': 'AC60_META_PROVIDER_SPEC_V1', 'provider_id': 'PROVIDER::' + _sha({'base': base, 'context': list(node.context)})[:24], 'target': base, 'output_token': base, 'input_contract': f'COMPLETE_CONSTRUCTION::{base}', 'truth_claim': False, 'executable_when_input_ready': True}
        cert = _rep_cert('PROVIDER_SPECIFICATION', base, req, node.context, provider)
        return _result(node, 'PASS', 'PROVIDER_OBJECT', statement='UNIVERSAL_PROVIDER_SPEC_MATERIALIZED', target=base, provider=provider, provider_digest=_sha(provider), supplies=[req], **cert)
    if fam == 'RELATION_SIGNATURE':
        rel = {'schema': 'AC60_SYMBOLIC_RELATION_SIGNATURE_V1', 'target': base, 'arity': 'UNKNOWN_UNTIL_DOMAIN_BIND', 'truth_claim': False}
        cert = _rep_cert('RELATION_SIGNATURE', base, req, node.context, rel)
        return _result(node, 'PASS', 'RELATION_OBJECT', statement='UNIVERSAL_RELATION_SIGNATURE_MATERIALIZED', target=base, relation=rel, relation_digest=_sha(rel), supplies=[req], **cert)
    if fam == 'MATERIAL_SPECIFICATION':
        spec = {'schema': 'AC60_MATERIAL_SPECIFICATION_V1', 'target': base, 'required_output': base, 'exactness': 'REPLAYABLE', 'truth_claim': False}
        cert = _rep_cert('MATERIAL_SPECIFICATION', base, req, node.context, spec)
        return _result(node, 'PASS', 'MATERIAL_SPECIFICATION_OBJECT', statement='UNIVERSAL_MATERIAL_SPECIFICATION_MATERIALIZED', target=base, material_specification=spec, supplies=[req], **cert)
    if fam == 'RECONSTRUCTION_RULE':
        rule = {'schema': 'AC60_RECONSTRUCTION_RULE_SPEC_V1', 'target': base, 'rule_type': 'SCIENTIFIC_CONSTRUCTION_DELEGATE', 'truth_claim': False}
        cert = _rep_cert('RECONSTRUCTION_RULE', base, req, node.context, rule)
        return _result(node, 'PASS', 'RECONSTRUCTION_RULE_OBJECT', statement='UNIVERSAL_RECONSTRUCTION_RULE_MATERIALIZED', target=base, reconstruction_rule=rule, supplies=[req], **cert)
    if fam == 'ADAPTER_SPECIFICATION':
        adapter = {'schema': 'AC60_CANONICAL_SCHEMA_ADAPTER_V1', 'target': base, 'input': 'ANY_TYPED_NODE', 'output': 'CANONICAL_SCIENTIFIC_PACKET', 'field_map': ['target', 'requires', 'supplies', 'context', 'question_identity'], 'truth_claim': False}
        cert = _rep_cert('ADAPTER_SPECIFICATION', base, req, node.context, adapter)
        return _result(node, 'PASS', 'CANONICAL_ADAPTER_OBJECT', statement='UNIVERSAL_CANONICAL_ADAPTER_MATERIALIZED', target=base, adapter=adapter, adapter_digest=_sha(adapter), supplies=[req], **cert)
    if fam == 'RECOVERY_EVIDENCE':
        hit = _find_authoritative(world, base)
        if hit is not None:
            return _result(node, 'PASS', 'RECOVERED_ARTIFACT', statement='UNIVERSAL_RECOVERY_FOUND_AUTHORITATIVE_GRAPH_OR_CATALOG_OBJECT', target=base, recovered_artifact=hit, supplies=[req])
        return _result(node, 'OPEN', 'SCIENTIFIC_CONSTRUCTION_CURRENT', statement='RECOVERY_EXHAUSTED_ESCALATE_TO_FIRST_PRINCIPLES_CONSTRUCTION', target=base, scientific_frontier=True, architecture_gap_closed=True, recovery_exhausted=True, required_effect_match=True, requires=[f'COMPLETE_CONSTRUCTION::{base}'], delta_cost=[1, 0, 0, 0])
    if fam == 'DUAL_OR_OBSTRUCTION_WITNESS':
        plan = {'schema': 'AC60_PROOF_OR_OBSTRUCTION_SEARCH_PLAN_V1', 'target': base, 'positive_goal': base, 'negative_goal': 'NOT(' + base + ')', 'success_condition': 'KERNEL_VERIFIED_PROOF_OR_VERIFIED_COUNTEREXAMPLE', 'truth_claim': False}
        return _result(node, 'OPEN', 'WITNESS_SEARCH_PLAN', statement='DUAL_OR_OBSTRUCTION_ESCALATED_TO_SCIENTIFIC_SEARCH', target=base, formal_target=base, formal_statement={'schema': 'AC60_OPAQUE_ATOMIC_SCIENTIFIC_GOAL_V1', 'atom': base}, zfc_goal={'kind': 'OPAQUE_ATOM', 'atom': base}, negated_goal={'kind': 'OPAQUE_NEGATION', 'atom': base}, witness_search_plan=plan, scientific_frontier=True, architecture_gap_closed=True, required_effect_match=True, requires=[f'COMPLETE_DUAL_OR_OBSTRUCTION::{base}'], delta_cost=[1, 0, 0, 0])
    if world.get('ac61_no_stop_mode'):
        return _result(node, 'OPEN', 'SCIENTIFIC_RESIDUAL_CONTINUATION_REQUEST', statement='OPEN_SCIENTIFIC_LEAF_CONTINUES_AS_SOVEREIGN_DELTA', target=base, family=fam, scientific_frontier=True, sovereign_continuation_required=True, original_requirement=req)
    return _result(node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='UNIVERSAL_GAP_CLOSURE_REACHED_SCIENTIFIC_OR_EXTERNAL_LEAF', target=base, family=fam)
