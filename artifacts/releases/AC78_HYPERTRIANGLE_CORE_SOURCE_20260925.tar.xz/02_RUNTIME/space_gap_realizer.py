from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, Iterable, List, Optional, Sequence, Tuple
import math
import numpy as np
from scipy.optimize import Bounds, LinearConstraint, linprog, milp

class SpaceGapError(RuntimeError):
    pass

@dataclass(frozen=True)
class QuestionIdentity:
    question_id: str
    source: str
    target: str
    epoch: str
    scope: str

    def matches(self, other: 'QuestionIdentity') -> bool:
        return self == other

class SpaceGapClass(str, Enum):
    CURRENT_SPACE_SUFFICIENT = 'CURRENT_SPACE_SUFFICIENT'
    CAPACITY_BOUND_ACTIVE = 'CAPACITY_BOUND_ACTIVE'
    CONTINUOUS_OK_DISCRETE_REALIZATION_FAIL = 'CONTINUOUS_OK_DISCRETE_REALIZATION_FAIL'
    CURRENT_LINEAR_SPACE_INSUFFICIENT = 'CURRENT_LINEAR_SPACE_INSUFFICIENT'
    REPRESENTATION_FORM_GAP = 'REPRESENTATION_FORM_GAP'
    UNRESOLVED_CAPACITY_VS_FORM = 'UNRESOLVED_CAPACITY_VS_FORM'
    SOLVER_UNRESOLVED = 'SOLVER_UNRESOLVED'

@dataclass(frozen=True)
class FiniteMarginProblem:
    """Finite declared SPACE test.

    The declared inequalities are

        A x - b >= t

    and the solver maximizes the common margin t. This object certifies only
    the supplied finite constraint system. It is not a theorem about an
    unsampled continuous domain unless the caller separately supplies such a
    theorem/certificate.
    """
    A: Sequence[Sequence[float]]
    b: Sequence[float]
    lower_bounds: Sequence[Optional[float]]
    upper_bounds: Sequence[Optional[float]]
    integrality: Optional[Sequence[int]] = None
    constraint_labels: Optional[Sequence[str]] = None
    variable_labels: Optional[Sequence[str]] = None
    scope: str = 'FINITE_DECLARED_SPACE'
    problem_id: str = 'SPACE_MARGIN_PROBLEM'

    def validate(self) -> None:
        A = np.asarray(self.A, dtype=float)
        b = np.asarray(self.b, dtype=float)
        if A.ndim != 2 or b.ndim != 1:
            raise SpaceGapError('A must be 2D and b must be 1D')
        if A.shape[0] != b.shape[0]:
            raise SpaceGapError('A/b row mismatch')
        if A.shape[1] != len(self.lower_bounds) or A.shape[1] != len(self.upper_bounds):
            raise SpaceGapError('variable-bound mismatch')
        if self.integrality is not None and len(self.integrality) != A.shape[1]:
            raise SpaceGapError('integrality length mismatch')
        if self.constraint_labels is not None and len(self.constraint_labels) != A.shape[0]:
            raise SpaceGapError('constraint-label mismatch')

@dataclass
class MarginSolve:
    mode: str
    success: bool
    optimal: bool
    status: int
    message: str
    margin: Optional[float]
    variables: Optional[List[float]] = None
    active_constraints: List[Dict[str, Any]] = field(default_factory=list)

@dataclass(frozen=True)
class CapacityProbe:
    probe_id: str
    optimum: float
    coefficient_bound: Optional[float] = None
    degree_bound: Optional[int] = None
    scope: str = 'FINITE_DECLARED_SPACE'
    optimal: bool = True
    question_id: Optional[str] = None
    source: Optional[str] = None
    target: Optional[str] = None
    epoch: Optional[str] = None

    def identity(self) -> Optional[QuestionIdentity]:
        if None in (self.question_id, self.source, self.target, self.epoch):
            return None
        return QuestionIdentity(str(self.question_id), str(self.source), str(self.target), str(self.epoch), str(self.scope))

@dataclass
class SpaceGapReceipt:
    problem_id: str
    scope: str
    classification: SpaceGapClass
    continuous: Optional[MarginSolve]
    discrete: Optional[MarginSolve]
    capacity_probes: List[Dict[str, Any]]
    defect_support: List[Dict[str, Any]]
    next_delta_classes: List[str]
    notes: List[str]

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d['classification'] = self.classification.value
        return d

@dataclass(frozen=True)
class RepresentationVariant:
    variant_id: str
    delta_class: str
    problem: FiniteMarginProblem
    material_cost: Tuple[float, ...]
    preserves_resolved_axes: bool = True

@dataclass
class VariantEvaluation:
    variant_id: str
    delta_class: str
    material_cost: Tuple[float, ...]
    classification: str
    continuous_margin: Optional[float]
    discrete_margin: Optional[float]
    certified_can_close: bool
    preserves_resolved_axes: bool

@dataclass(frozen=True)
class DeltaCandidate:
    candidate_id: str
    delta_class: str
    material_cost: Tuple[float, ...]
    certified_can_close: bool
    preserves_resolved_axes: bool = True
    evidence: Optional[Dict[str, Any]] = None
    identity: Optional[QuestionIdentity] = None

def _bounds(problem: FiniteMarginProblem, multiplier: float=1.0) -> List[Tuple[Optional[float], Optional[float]]]:
    out: List[Tuple[Optional[float], Optional[float]]] = []
    for lo, hi in zip(problem.lower_bounds, problem.upper_bounds):
        lo2 = None if lo is None else float(lo) * multiplier if lo < 0 else float(lo)
        hi2 = None if hi is None else float(hi) * multiplier if hi > 0 else float(hi)
        out.append((lo2, hi2))
    return out

def _lp_matrices(problem: FiniteMarginProblem):
    A = np.asarray(problem.A, dtype=float)
    b = np.asarray(problem.b, dtype=float)
    M = np.hstack([-A, np.ones((A.shape[0], 1), dtype=float)])
    rhs = -b
    c = np.zeros(A.shape[1] + 1, dtype=float)
    c[-1] = -1.0
    return (A, b, M, rhs, c)

def solve_continuous(problem: FiniteMarginProblem, bound_multiplier: float=1.0) -> MarginSolve:
    problem.validate()
    A, b, M, rhs, c = _lp_matrices(problem)
    bounds = _bounds(problem, bound_multiplier) + [(None, None)]
    r = linprog(c, A_ub=M, b_ub=rhs, bounds=bounds, method='highs')
    margin = float(r.x[-1]) if r.x is not None else None
    variables = [float(x) for x in r.x[:-1]] if r.x is not None else None
    active: List[Dict[str, Any]] = []
    if r.x is not None:
        slacks = np.asarray(r.ineqlin.residual, dtype=float)
        marginals = np.asarray(r.ineqlin.marginals, dtype=float)
        labels = list(problem.constraint_labels or [f'C{i}' for i in range(A.shape[0])])
        for i, (slack, dual) in enumerate(zip(slacks, marginals)):
            if slack <= 1e-07 or abs(dual) >= 1e-07:
                active.append({'index': i, 'label': labels[i], 'slack': float(slack), 'dual_marginal': float(dual)})
        active.sort(key=lambda x: (-abs(x['dual_marginal']), x['index']))
    return MarginSolve(mode='CONTINUOUS_RELAXATION', success=bool(r.success), optimal=bool(r.status == 0), status=int(r.status), message=str(r.message), margin=margin, variables=variables, active_constraints=active[:64])

def solve_discrete(problem: FiniteMarginProblem, time_limit: float=20.0) -> MarginSolve:
    problem.validate()
    if problem.integrality is None or not any((int(v) != 0 for v in problem.integrality)):
        return solve_continuous(problem)
    A, b, M, rhs, c = _lp_matrices(problem)
    lo = [-np.inf if x is None else float(x) for x in problem.lower_bounds] + [-np.inf]
    hi = [np.inf if x is None else float(x) for x in problem.upper_bounds] + [np.inf]
    integrality = np.asarray(list(problem.integrality) + [0], dtype=int)
    cons = LinearConstraint(M, -np.inf * np.ones(len(rhs)), rhs)
    r = milp(c=c, integrality=integrality, bounds=Bounds(lo, hi), constraints=cons, options={'time_limit': float(time_limit), 'presolve': True})
    margin = float(r.x[-1]) if r.x is not None else None
    variables = [float(x) for x in r.x[:-1]] if r.x is not None else None
    return MarginSolve(mode='DISCRETE_REALIZATION', success=bool(r.success), optimal=bool(r.status == 0), status=int(r.status), message=str(r.message), margin=margin, variables=variables, active_constraints=[])

def rank_delta_candidates(candidates: Iterable[DeltaCandidate], required_identity: Optional[QuestionIdentity]=None) -> List[DeltaCandidate]:
    """Rank only materially admissible, certified-closing candidates.

    AC44: if a required SAME_QUESTION identity is supplied, candidates without
    that exact identity are ineligible. This prevents a cheaper foreign-scope
    object from winning by cost alone.
    """
    eligible = []
    for c in candidates:
        if not (c.certified_can_close and c.preserves_resolved_axes):
            continue
        if required_identity is not None:
            if c.identity is None or not c.identity.matches(required_identity):
                continue
        eligible.append(c)
    return sorted(eligible, key=lambda c: (tuple(c.material_cost), c.candidate_id))

class UniversalSpaceGapRealizer:

    def __init__(self, tol: float=1e-08):
        self.tol = float(tol)

    def diagnose(self, problem: FiniteMarginProblem, *, bound_multipliers: Sequence[float]=(2.0, 4.0), discrete_time_limit: float=20.0) -> SpaceGapReceipt:
        cont = solve_continuous(problem, 1.0)
        if cont.margin is None or not cont.optimal:
            return SpaceGapReceipt(problem.problem_id, problem.scope, SpaceGapClass.SOLVER_UNRESOLVED, cont, None, [], cont.active_constraints, ['EXACT_SPACE_SOLVER_OR_CERTIFICATE'], ['Continuous relaxation did not reach a certified optimum.'], 0)
        probes: List[Dict[str, Any]] = []
        if cont.margin >= -self.tol:
            disc = None
            if problem.integrality is not None and any((int(v) != 0 for v in problem.integrality)):
                disc = solve_discrete(problem, discrete_time_limit)
                if disc.margin is None or not disc.optimal:
                    return SpaceGapReceipt(problem.problem_id, problem.scope, SpaceGapClass.SOLVER_UNRESOLVED, cont, disc, probes, cont.active_constraints, ['DISCRETE_REALIZATION_CERTIFICATE'], ['Continuous SPACE closes but discrete realization is not yet certified.'], 0)
                if disc.margin < -self.tol:
                    return SpaceGapReceipt(problem.problem_id, problem.scope, SpaceGapClass.CONTINUOUS_OK_DISCRETE_REALIZATION_FAIL, cont, disc, probes, cont.active_constraints, ['LATTICE_OR_INTEGER_REALIZER', 'CANONICAL_DISCRETE_CARRIER'], ['Do not change TIME or COS; the current continuous SPACE is sufficient.'], 0)
            return SpaceGapReceipt(problem.problem_id, problem.scope, SpaceGapClass.CURRENT_SPACE_SUFFICIENT, cont, disc, probes, cont.active_constraints, ['SPACE_CANDIDATE_VERIFY_AND_COMMIT'], ['SPACE sufficiency is only for the declared finite constraints.'], 0)
        best = cont.margin
        crosses = False
        for mult in bound_multipliers:
            p = solve_continuous(problem, float(mult))
            probes.append({'kind': 'BOUND_MULTIPLIER', 'multiplier': float(mult), 'margin': p.margin, 'optimal': p.optimal, 'status': p.status})
            if p.optimal and p.margin is not None:
                best = max(best, p.margin)
                if p.margin >= -self.tol:
                    crosses = True
        if crosses:
            return SpaceGapReceipt(problem.problem_id, problem.scope, SpaceGapClass.CAPACITY_BOUND_ACTIVE, cont, None, probes, cont.active_constraints, ['MINIMAL_CAPACITY_BOUND_DELTA'], ['A larger numeric envelope closes the declared finite continuous SPACE; find the smallest certified bound.'], 0)
        optimal_probes = [p for p in probes if p['optimal']]
        stable = bool(optimal_probes) and all((p['margin'] is not None and abs(float(p['margin']) - cont.margin) <= max(self.tol, 1e-07 * max(1.0, abs(cont.margin))) for p in optimal_probes))
        cls = SpaceGapClass.CURRENT_LINEAR_SPACE_INSUFFICIENT if stable else SpaceGapClass.UNRESOLVED_CAPACITY_VS_FORM
        nexts = ['MISSING_LINEAR_DIRECTION_OR_SHAPE_FACTOR', 'MISSING_NONLINEAR_FORM', 'NEW_SELECTOR_OR_CARRIER', 'AUTHORIZED_CATALOG_EXTENSION', 'COORDINATE_ASCENT_CANDIDATE'] if stable else ['BOUND_VS_FORM_DISCRIMINATION', 'MISSING_LINEAR_DIRECTION_OR_SHAPE_FACTOR', 'COORDINATE_ASCENT_CANDIDATE']
        notes = ['Increasing coefficient magnitude alone did not close the declared continuous SPACE.' if stable else 'Bound expansion changes the optimum but has not certified closure; do not infer the missing delta yet.']
        return SpaceGapReceipt(problem.problem_id, problem.scope, cls, cont, None, probes, cont.active_constraints, nexts, notes, 0)

    def evaluate_variants(self, variants: Sequence[RepresentationVariant], *, discrete_time_limit: float=20.0) -> Dict[str, Any]:
        evaluations: List[VariantEvaluation] = []
        candidates: List[DeltaCandidate] = []
        for v in variants:
            rec = self.diagnose(v.problem, bound_multipliers=(), discrete_time_limit=discrete_time_limit)
            cont = rec.continuous.margin if rec.continuous else None
            disc = rec.discrete.margin if rec.discrete else None
            closes = rec.classification == SpaceGapClass.CURRENT_SPACE_SUFFICIENT
            ev = VariantEvaluation(variant_id=v.variant_id, delta_class=v.delta_class, material_cost=v.material_cost, classification=rec.classification.value, continuous_margin=cont, discrete_margin=disc, certified_can_close=closes, preserves_resolved_axes=v.preserves_resolved_axes)
            evaluations.append(ev)
            candidates.append(DeltaCandidate(v.variant_id, v.delta_class, v.material_cost, closes, v.preserves_resolved_axes, rec.to_dict()))
        ranked = rank_delta_candidates(candidates)
        return {'evaluations': [asdict(x) for x in evaluations], 'selected': asdict(ranked[0]) if ranked else None}

    def classify_recorded_capacity_evidence(self, *, problem_id: str, scope: str, current_optimum: float, probes: Sequence[CapacityProbe], required_identity: Optional[QuestionIdentity]=None) -> SpaceGapReceipt:
        if any((str(p.scope) != str(scope) for p in probes)):
            raise SpaceGapError('recorded capacity probe scope mismatch')
        if required_identity is not None:
            for p in probes:
                pid = p.identity()
                if pid is None or not pid.matches(required_identity):
                    raise SpaceGapError('recorded capacity probe SAME_QUESTION identity mismatch')
        good = [p for p in probes if p.optimal]
        if current_optimum >= -self.tol:
            cls = SpaceGapClass.CURRENT_SPACE_SUFFICIENT
            nexts = ['SPACE_CANDIDATE_VERIFY_AND_COMMIT']
            note = 'Recorded optimum is nonnegative on the declared finite scope.'
        elif any((p.optimum >= -self.tol for p in good)):
            cls = SpaceGapClass.CAPACITY_BOUND_ACTIVE
            nexts = ['MINIMAL_CAPACITY_BOUND_DELTA']
            note = 'At least one recorded capacity extension closes the declared finite scope.'
        elif good and all((abs(p.optimum - current_optimum) <= max(self.tol, 1e-09 * max(1.0, abs(current_optimum))) for p in good)):
            cls = SpaceGapClass.REPRESENTATION_FORM_GAP
            nexts = ['MISSING_LINEAR_DIRECTION_OR_SHAPE_FACTOR', 'MISSING_NONLINEAR_FORM', 'NEW_SELECTOR_OR_CARRIER', 'AUTHORIZED_CATALOG_EXTENSION', 'COORDINATE_ASCENT_CANDIDATE']
            note = 'Recorded coefficient/degree expansions leave the optimum invariant; capacity-only repair is eliminated in this scope.'
        else:
            cls = SpaceGapClass.UNRESOLVED_CAPACITY_VS_FORM
            nexts = ['BOUND_VS_FORM_DISCRIMINATION', 'MISSING_LINEAR_DIRECTION_OR_SHAPE_FACTOR', 'COORDINATE_ASCENT_CANDIDATE']
            note = 'Recorded extensions remain negative but do not yet isolate bound versus representation-form debt.'
        return SpaceGapReceipt(problem_id=problem_id, scope=scope, classification=cls, continuous=None, discrete=None, capacity_probes=[asdict(p) for p in probes], defect_support=[], next_delta_classes=nexts, notes=[note])
