from __future__ import annotations
import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver
from causal_grid_theorem_pack import THEOREMS

CASES=[]
for qid,t in THEOREMS.items():
    CASES.append(Node('PROBLEM',{
        'statement':t['title'],
        'operation':t['operations'][0],
        'cake':'typed object',
        'plate':'typed carrier',
        'requires':list(t['discharges']),
        'scientific_focus':True,
        'sovereign_focus':True,
        'sovereign_root_id':'AC71::'+qid,
    },context=('AC71',qid)))

def main():
    s=SovereignSolver(); r=s.solve_universal(CASES,max_waves=1,max_calls=5000)
    known=list(s.engine.known.values())
    receipts=[n for n in known if n.kind=='CAUSAL_GRID_THEOREM_RECEIPT']
    ids={n.payload.get('theorem_id') for n in receipts}
    enriched=[n for n in known if n.kind=='PROBLEM' and n.payload.get('ac71_core_enriched')]
    all_discharged=True
    for n in enriched:
        if n.payload.get('requires'):
            # only count theorem-pack raw requirements, not new generic route-extraction obligations
            if any(str(x) in {d for t in THEOREMS.values() for d in t['discharges']} for x in n.payload.get('requires') or []):
                all_discharged=False
    out={
        'schema':'AC71_QUALIFICATION_V1',
        'case_count':len(CASES),
        'theorem_receipt_count':len(receipts),
        'theorem_ids':sorted(x for x in ids if x),
        'all_12_present':len(ids)==12,
        'all_declared_obligations_discharged_in_enriched_roots':all_discharged,
        'active_mechanism_count':r.get('active_mechanism_count'),
        'execution_calls':r.get('execution_calls'),
        'run_state':r.get('run_state'),
        'pass':len(ids)==12 and all_discharged and r.get('active_mechanism_count')==99,
    }
    print(json.dumps(out,indent=2,ensure_ascii=False))

if __name__=='__main__': main()
