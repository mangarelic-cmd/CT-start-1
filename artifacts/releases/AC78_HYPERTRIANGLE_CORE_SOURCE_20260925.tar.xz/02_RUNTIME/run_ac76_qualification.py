from __future__ import annotations
import json, sys, time
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from causal_grid_core import CausalGridCore
from sovereign_aux import REGISTRY


def main():
    fixture=json.loads((ROOT/'04_FIXTURES'/'GOLD_STANDARD_724_RULES_CONSTRAINT_FIXTURE.json').read_text())
    text_by_id={str(r['rule_id']):r['text'] for r in fixture['rules']}
    core=CausalGridCore(); t=time.time(); receipts=[]
    for row in fixture['rules']:
        n=Node('PROBLEM',{
            'rule_id':str(row['rule_id']),'rule_text':row['text'],
            'cake':'NORMATIVE_GOVERNANCE_RULE','plate':'SOFTWARE_AGENT_PROJECT_GOVERNANCE',
            'authority':'EXTERNAL_BENCHMARK_NON_CT'
        },context=('AC76','EXTERNAL_BENCHMARK',str(row['rule_id'])))
        out=core.compile_node(n,{},0)
        receipts.extend(x for x in out if x.kind=='CAUSAL_GRID_CONSTRAINT_RECEIPT')
    rels=[]
    for row in core.constraint_ledger.rows:
        for rel in row.get('semantic_relations') or []:
            if rel.get('relation')!='DISTINCT':
                rr=dict(rel)
                rr['text_a']=text_by_id.get(str(rr.get('rule_a')))
                rr['text_b']=text_by_id.get(str(rr.get('rule_b')))
                rels.append(rr)
    order={'CONFLICT_DETERMINISTIC':9,'CONFLICT_CANDIDATE':8,'REDUNDANT_DETERMINISTIC':7,'REDUNDANT_HIGH_CONFIDENCE':6,'SPECIALIZATION':5,'OVERLAP_REVIEW':4}
    rels.sort(key=lambda x:(order.get(x.get('relation'),0),x.get('jaccard',0)),reverse=True)
    counters=core.constraint_ledger.counters()

    # ALL-AUX registry integrity is covered by regression tests; qualification itself stays corpus-focused.

    checks={
        '724_rules_compiled':core.constraint_compiled_count==724,
        'zero_route_unresolved':core.auto_unresolved_count==0,
        'zero_operator_semantic_residue':core.constraint_semantic_residue_count==0,
        'zero_deterministic_conflict_open':counters.get('conflict_open')==0,
        'zero_semantic_conflict_candidates':counters.get('semantic_conflict_candidate_pairs')==0,
        'detects_non_independence':counters.get('semantic_high_redundancy_pairs',0)>=1 and counters.get('semantic_specialization_pairs',0)>=1,
        'external_corpus_not_promoted_to_ct':all((r.get('semantic_profile') or {}).get('ct_axiom_promoted') is False for r in core.constraint_ledger.rows),
        'all_aux_99_preserved':len(REGISTRY)==99,
        'no_false_root_from_rules':all((r.payload.get('truth_credit_added')==0 and r.payload.get('external_scientific_truth_certified') is False) for r in receipts),
    }
    out={
        'schema':'AC76_SEMANTIC_CONSTRAINT_UNIFIER_QUALIFICATION_V1','version':'AC76','base':'AC75',
        'external_benchmark':{'name':'Gold Standard Rules','ct_authority':False,'rule_count':724},
        'elapsed_seconds':round(time.time()-t,3),'checks':checks,'pass_count':sum(bool(v) for v in checks.values()),'check_count':len(checks),'pass':all(checks.values()),
        'constraint_counts':{'compiled':core.constraint_compiled_count,'closed':core.constraint_closed_count,'open':core.constraint_open_count,'semantic_residues':core.constraint_semantic_residue_count,'auto_unresolved':core.auto_unresolved_count},
        'semantic_ledger':counters,'semantic_relations':rels,
        'interpretation':{
            'logical_closure_delta_required':False if counters.get('conflict_open')==0 and counters.get('semantic_conflict_candidate_pairs')==0 else True,
            'canonical_consolidation_delta_present':bool(counters.get('semantic_high_redundancy_pairs') or counters.get('semantic_specialization_pairs') or counters.get('semantic_overlap_review_pairs')),
            'external_rules_are_solver_test_only':True,
        },
        'all_aux_integration':{'active_mechanisms':len(REGISTRY),'regression_test':'test_solver_core_emits_ac74_coordinate_and_grid_receipts_before_all_aux'},
    }
    print(json.dumps(out,indent=2,ensure_ascii=False))

if __name__=='__main__': main()
