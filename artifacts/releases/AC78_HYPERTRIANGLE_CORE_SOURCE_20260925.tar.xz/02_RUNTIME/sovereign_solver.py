from __future__ import annotations
import json
from pathlib import Path
from all_everything_wave_engine import AllEverythingWaveEngine, Node, ResourceCutoff
from sovereign_aux import REGISTRY, MECHANISM_CATEGORIES, correlation
from automation_reconciliation_ac66 import open_like_status

class SovereignSolver:

    def __init__(self):
        self.engine = AllEverythingWaveEngine(REGISTRY, correlation)

    def _reset(self):
        self.engine = AllEverythingWaveEngine(REGISTRY, correlation)

    def _prepare_world(self, world=None):
        world = {} if world is None else dict(world)
        world.setdefault('context_version', 78)
        world['all_everything_mode'] = True
        world['target_grain_mode'] = True
        world['full_discovery_no_aux_prefilter'] = True
        world['direct_causal_triangulation'] = True
        world['auto_sin2_quadrature'] = True
        world['auto_cos_closure'] = True
        world['mechanical_proof_reconstruction'] = True
        world['ac66_full_delta_semantics'] = True
        world['ac66_barrierless_motion'] = True
        world['ac66_append_only_skin'] = True
        world['ac66_local_global_transduction'] = True
        world['ac66_trivalent_proof_status'] = True
        world['ac67_electrical_global_current_hardening'] = True
        world['causal_grid_core_enabled'] = True
        world['causal_grid_core_precedes_all_aux'] = True
        world['causal_grid_auto_route_extraction'] = True
        world['causal_grid_auto_route_fail_closed'] = True
        world['causal_grid_no_invented_metric'] = True
        world['causal_grid_structural_mirror_not_causal_inverse'] = True
        world['causal_grid_residue_to_cos_skin'] = True
        world['causal_grid_theorem_pack_enabled'] = True
        world['causal_grid_scoped_theorems_precede_all_aux'] = True
        world['causal_grid_typing_nonblocking'] = True
        world['causal_grid_domain_metric_atlas'] = True
        world['causal_grid_operator_phi5_psi_library'] = True
        world['causal_grid_nonlinear_residue_library'] = True
        world['causal_grid_cp026_canonical_coordinate_library'] = True
        world['causal_grid_problem_local_dynamic_grid'] = True
        world['causal_grid_exact_hit_projectable_recalculate'] = True
        world['causal_grid_metric_borges_transport_firewall'] = True
        world['causal_grid_cross_carrier_reuse_requires_certified_bridge'] = True
        world['causal_grid_cache_semantically_transparent_only'] = True
        world['ac75_universal_constraint_carrier'] = True
        world['ac75_rule_precedence_never_invented'] = True
        world['ac75_rule_conflict_last_survivor_requires_explicit_basis'] = True
        world['ac75_rule_text_not_promoted_to_external_truth'] = True
        world['ac76_semantic_constraint_unifier'] = True
        world['ac76_external_corpus_never_promoted_to_ct_authority'] = True
        world['ac76_semantic_similarity_never_creates_precedence'] = True
        world['ac76_semantic_atomization_enabled'] = True
        world['ac77_periodic_cartesian_theorem_metrology_core'] = True
        world['ac77_periodic_cartesian_precedes_all_aux'] = True
        world['ac77_pass053_provider_typed_distance_api'] = True
        world['ac77_pass054_cartesian_coherence_gate'] = True
        world['ac77_pythagoras_requires_certified_mutual_orthogonality'] = True
        world['ac77_gram_fallback_mandatory_for_oblique_routes'] = True
        world['ac77_theorem_identity_distinct_from_route_address'] = True
        world['ac77_cross_provider_numeric_conversion_fail_closed'] = True
        world['ac77_provider_independent_intrinsic_metric_claimed'] = False
        world['ac78_hypertriangle_memory_integration_core'] = True
        world['ac78_hypertriangle_precedes_all_aux'] = True
        world['ac78_hypertriangle_frozen_provider_version'] = '1.0.0'
        world['ac78_hypertriangle_explicit_typed_request_only'] = True
        world['ac78_hypertriangle_implicit_slot_classification'] = False
        world['ac78_hypertriangle_memory_feedback'] = False
        world['ac78_hypertriangle_aux_terminality_equals_scientific_root'] = False
        world['ac78_hypertriangle_truth_credit_added'] = 0
        world['ac78_hypertriangle_root_write_capability'] = 'NONE'
        world['ac78_hypertriangle_return_write_capability'] = 'NONE'
        world['ac78_hypertriangle_solver_mutation_capability'] = 'NONE'
        world['active_mechanism_ids'] = list(REGISTRY)
        world['active_mechanism_count'] = len(REGISTRY)
        world['active_mechanism_categories'] = dict(MECHANISM_CATEGORIES)
        return world

    def _open_currents(self):
        out = []
        for n in self.engine.known.values():
            st = str(n.payload.get('status') or '')
            if n.kind == 'OPEN_RESIDUAL_CURRENT' or (open_like_status(st) and n.kind not in {'AUX_OBSERVATION', 'MECHANISM_OBSERVATION'}):
                out.append(n)
        return sorted(out, key=lambda n: (n.context, n.semantic_identity()))

    def _root(self, nodes):
        # AC66 scientific ROOT requires an executable semantic proof. Structural RETURN,
        # geometry, kernel-local or transport receipts carry zero ROOT truth credit.
        roots = [n for n in nodes if n.kind == 'FORMAL_PROOF_RECEIPT' and n.payload.get('formal_proof_verified') is True]
        if not roots:
            roots = [n for n in nodes if n.kind == 'ROOT_RECEIPT' and n.payload.get('external_scientific_truth_certified') is True and n.payload.get('kernel_verified')]
        return sorted(roots, key=lambda n: n.identity())[0] if roots else None

    def _base_result(self, waves, run_state, root, frontier, world):
        vals = list(self.engine.known.values())
        open_currents = self._open_currents()
        exec_counts = {}
        for e in self.engine.log:
            m = e.get('mechanism')
            exec_counts[m] = exec_counts.get(m, 0) + 1
        geo = [n for n in vals if n.kind == 'CAUSAL_GEOMETRIC_PROOF_RECEIPT']
        tri = [n for n in geo if n.payload.get('causal_solution_geometry_ready')]
        returns = [n for n in vals if n.kind == 'NODE_RETURN_RECEIPT']
        coord = [n for n in vals if n.kind == 'CAUSAL_GRID_COORDINATE_LIBRARY_RECEIPT']
        active_grid = [n for n in vals if n.kind == 'CAUSAL_GRID_ACTIVE_GRID_RECEIPT']
        ccore = self.engine.causal_grid_core.coordinate_library_core
        ccounters = ccore.counters()
        constraint_receipts=[n for n in vals if n.kind=='CAUSAL_GRID_CONSTRAINT_RECEIPT']
        constraint_counters=self.engine.causal_grid_core.constraint_ledger.counters()
        periodic_receipts=[n for n in vals if n.kind in {'PERIODIC_CARTESIAN_DISTANCE_RECEIPT','PERIODIC_CARTESIAN_ROUTE_RECEIPT','PERIODIC_CARTESIAN_PROVIDER_RECEIPT'}]
        periodic_currents=[n for n in vals if n.kind=='PERIODIC_CARTESIAN_COHERENCE_CURRENT']
        periodic_counters=self.engine.causal_grid_core.periodic_cartesian_core.counters()
        hypertriangle_receipts=[n for n in vals if n.kind=='HYPERTRIANGLE_AUX_RECEIPT']
        hypertriangle_currents=[n for n in vals if n.kind=='HYPERTRIANGLE_AUX_CURRENT']
        hypertriangle_counters=self.engine.causal_grid_core.hypertriangle_core.counters()
        return {'schema': 'AC76_SEMANTIC_CONSTRAINT_UNIFIER_SOLVER_RUN_V1', 'current_schema':'AC78_HYPERTRIANGLE_MEMORY_INTEGRATION_SOLVER_RUN_V1', 'version':'AC78', 'compatibility_schemas':['AC77_PERIODIC_CARTESIAN_THEOREM_METROLOGY_SOLVER_RUN_V1','AC76_SEMANTIC_CONSTRAINT_UNIFIER_SOLVER_RUN_V1','AC75_UNIVERSAL_CONSTRAINT_CARRIER_SOLVER_RUN_V1','AC74_CANONICAL_COORDINATE_LIBRARY_SOLVER_RUN_V1'], 'run_state': run_state, 'solution_certified': bool(root), 'formal_proof_verified': bool(root), 'root_receipt': root.to_dict() if root else None, 'waves': waves, 'final_frontier_count': len(frontier), 'known_node_count': len(vals), 'execution_calls': self.engine.calls, 'causal_grid_core_receipt_count': self.engine.core_grid_receipt_count, 'causal_grid_core_cell_count': self.engine.core_grid_cell_count, 'causal_grid_core_residue_count': self.engine.core_grid_residue_count, 'causal_grid_core_compiled_count': self.engine.causal_grid_core.compiled_count, 'causal_grid_auto_extracted_count': self.engine.causal_grid_core.auto_extracted_count, 'causal_grid_auto_unresolved_count': self.engine.causal_grid_core.auto_unresolved_count, 'causal_grid_coordinate_library_receipt_count': len(coord), 'causal_grid_active_grid_receipt_count': len(active_grid), 'causal_grid_cp026_counters': ccounters, 'causal_grid_constraint_receipt_count':len(constraint_receipts), 'causal_grid_constraint_compiled_count':self.engine.causal_grid_core.constraint_compiled_count, 'causal_grid_constraint_closed_count':self.engine.causal_grid_core.constraint_closed_count, 'causal_grid_constraint_open_count':self.engine.causal_grid_core.constraint_open_count, 'causal_grid_constraint_semantic_residue_count':self.engine.causal_grid_core.constraint_semantic_residue_count, 'causal_grid_constraint_ledger_counters':constraint_counters, 'periodic_cartesian_receipt_count':len(periodic_receipts), 'periodic_cartesian_open_current_count':len(periodic_currents), 'periodic_cartesian_counters':periodic_counters, 'hypertriangle_receipt_count':len(hypertriangle_receipts), 'hypertriangle_open_current_count':len(hypertriangle_currents), 'hypertriangle_counters':hypertriangle_counters, 'active_mechanism_count': len(REGISTRY), 'active_mechanism_ids': list(REGISTRY), 'active_mechanism_categories': dict(MECHANISM_CATEGORIES), 'mechanism_execution_counts': exec_counts, 'causal_geometric_receipt_count': len(geo), 'causal_solution_geometry_count': len(tri), 'node_return_receipt_count': len(returns), 'open_residual_count': len(open_currents), 'open_residuals': [{'kind': n.kind, 'statement': n.payload.get('statement'), 'status': n.payload.get('status'), 'context': list(n.context)} for n in open_currents], 'full_discovery_result_count': self.engine.discovery_result_count, 'active_grain_count': self.engine.active_grain_count, 'dormant_relation_count': self.engine.dormant_relation_count, 'grain_decision_count': len(self.engine.grain_router.decisions), 'scientific_common_trunk_unique_count': len(self.engine.scientific_common_trunk), 'scientific_common_trunk_total_publications': sum(v['count'] for v in self.engine.scientific_common_trunk.values()), 'execution_log': self.engine.log, 'final_frontier': [n.to_dict() for n in frontier], 'world': world}

    def hypertriangle(self, request):
        """Direct AC78 API into the exact frozen HyperTriangle AUX v1.0.0."""
        return self.engine.causal_grid_core.hypertriangle_core.execute_request(request)

    def periodic_cartesian(self, request):
        """Direct AC77 theorem-distance/route-coherence API with PASS054 claim ceiling."""
        return self.engine.causal_grid_core.periodic_cartesian_core.execute_request(request)

    def solve(self, seeds, world=None, max_waves=8, max_calls=20000):
        return self.solve_universal(seeds, world, max_waves, max_calls)

    def solve_universal(self, seeds, world=None, max_waves=24, max_calls=100000, stable_waves=2):
        self._reset()
        world = self._prepare_world(world)
        frontier = list(seeds)
        waves = []
        root = None
        state = 'RUNNING'
        stable = 0
        prev = None
        try:
            for w in range(max_waves):
                if not frontier:
                    frontier = self._open_currents()
                    if not frontier:
                        state = 'COMPLETE' if root else 'NO_NEW_ACTIVE_ROUTE'
                        break
                before = set(self.engine.semantic_signature())
                nxt, raw, corr = self.engine.run_wave(frontier, world, w, max_calls)
                after = set(self.engine.semantic_signature())
                sig = tuple(sorted(after))
                stable = stable + 1 if sig == prev else 0
                prev = sig
                root = self._root(nxt) or root
                waves.append({'wave': w, 'frontier_count': len(frontier), 'all_everything_results': len(raw), 'correlation_nodes': len(corr), 'next_count': len(nxt), 'calls_total': self.engine.calls, 'new_semantic_nodes': len(after - before), 'semantic_stable_counter': stable})
                if root:
                    state = 'SOLUTION_CERTIFIED'
                    frontier = nxt
                    break
                frontier = nxt
                if stable >= stable_waves and (not frontier):
                    frontier = self._open_currents()
                    if not frontier:
                        state = 'NO_NEW_ACTIVE_ROUTE'
                        break
            else:
                state = 'RESOURCE_CHECKPOINT_ACTIVE_FRONTIER' if frontier else 'RESOURCE_CHECKPOINT'
        except ResourceCutoff as e:
            world['cutoff_detail'] = str(e)
            state = 'RESOURCE_CHECKPOINT_MAX_CALLS'
        return self._base_result(waves, state, root, frontier, world)

def nodes_from_fixture(path):
    d = json.loads(Path(path).read_text())
    return ([Node(x['kind'], x, context=tuple(x.get('context', ()))) for x in d['nodes']], d)
