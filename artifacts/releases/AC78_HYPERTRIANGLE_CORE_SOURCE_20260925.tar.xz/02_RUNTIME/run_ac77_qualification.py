from __future__ import annotations
import json, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / '02_RUNTIME'))

from all_everything_wave_engine import Node
from causal_grid_core import CausalGridCore
from sovereign_aux import REGISTRY
from sovereign_solver import SovereignSolver
from pass053_provider_typed_distance_api import PASS018_PROVIDER


def load_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def main():
    t0=time.time()
    core=CausalGridCore()

    pair=core.periodic_cartesian_core.execute_request({
        'operation':'coherent_distance','source_theorem_id':'T003','target_theorem_id':'T072'
    })
    route_node=Node('PROBLEM',{
        'statement':'AC77_PERIODIC_ROUTE_QUALIFICATION',
        'theorem_route':['T003','T072','T106'],
        'claim_route_pythagoras':True,
    },context=('AC77','QUALIFICATION'))
    enriched, side=core.enrich_node(route_node,{},0)
    route=enriched.payload.get('periodic_cartesian_result') or {}
    pre_aux_receipts=[x for x in side if x.kind=='PERIODIC_CARTESIAN_ROUTE_RECEIPT']

    bad=core.periodic_cartesian_core.execute_request({
        'operation':'coherent_distance','source_theorem_id':'T003','target_theorem_id':'T072',
        'metric_provider_id':PASS018_PROVIDER,
    })

    rdir=ROOT/'60_PASS054_CARTESIAN_SPACE_TIME_COHERENCE_GATE'/'REGISTRY'
    decision=load_json(rdir/'PASS054_DECISION.json')
    gate=load_json(rdir/'PASS054_SOLVER_COHERENCE_GATE.json')
    pair_audit=load_json(rdir/'PASS054_ALL_THEOREM_PAIR_SPACE_TIME_PYTHAGORE_AUDIT.json')
    angle_audit=load_json(rdir/'PASS054_THEOREM_TRIPLE_ORTHOGONALITY_CENSUS.json')

    solver=SovereignSolver(); world=solver._prepare_world({})
    counters=core.periodic_cartesian_core.counters()
    checks={
        'pass054_6903_pair_audit_inherited_and_closed': pair_audit.get('distinct_pair_count')==6903 and pair_audit.get('failed_pair_count')==0,
        'pass054_pair_nested_pythagoras_closed': pair.get('ok') is True and pair['result']['coherence_gate']['pair_decomposition_closed'] is True,
        'pass054_chart_transition_closed': pair.get('ok') is True and pair['result']['coherence_gate']['chart_transition_closed'] is True,
        'route_gram_fallback_active': route.get('route_pythagoras',{}).get('result')=='NOT_APPLICABLE_USE_GRAM_LAW' and route.get('gram_law_abs_error',1)>0 and route.get('gram_law_abs_error')<1e-12,
        'false_naive_pythagoras_rejected': (enriched.payload.get('periodic_cartesian_receipt') or {}).get('coherence_gate',{}).get('claim_rejected') is True,
        'pre_all_aux_route_receipt_emitted': len(pre_aux_receipts)==1 and pre_aux_receipts[0].payload.get('truth_credit_added')==0,
        'cross_provider_conversion_fails_closed': bad.get('ok') is False and bad.get('error',{}).get('error_code')=='UNCERTIFIED_CROSS_PROVIDER_CONVERSION_FORBIDDEN',
        'global_time_and_intrinsic_metric_not_overclaimed': decision.get('global_fixed_time_axis_claimed') is False and decision.get('provider_independent_intrinsic_metric_claimed') is False,
        'all_800748_angles_audited_and_no_false_right_angle': angle_audit.get('vertex_centered_angle_count')==800748 and angle_audit.get('certified_right_angle_count')==0,
        'pass054_solver_gate_policy_preserved': gate.get('route_composition_law')=='GRAM_UNLESS_MUTUAL_ORTHOGONALITY_CERTIFIED' and gate.get('false_naive_route_pythagoras_allowed') is False,
        'ac77_world_flags_active': int(world.get('context_version',0))>=77 and world.get('ac77_periodic_cartesian_theorem_metrology_core') is True and world.get('ac77_pass054_cartesian_coherence_gate') is True,
        'all_aux_registry_99_preserved': len(REGISTRY)==99,
    }
    out={
        'schema':'AC77_PERIODIC_CARTESIAN_THEOREM_METROLOGY_QUALIFICATION_V1',
        'version':'AC77','base':'AC76',
        'elapsed_seconds':round(time.time()-t0,3),
        'checks':checks,'pass_count':sum(bool(v) for v in checks.values()),'check_count':len(checks),'pass':all(checks.values()),
        'periodic_cartesian':{
            'default_provider':'PASS021_NATIVE_THEOREM_METRIC_EFFECT_RESPONSE_V1',
            'native_scale':'PASS021_L2_NORMALIZED_EFFECT_RESPONSE_NATIVE_SCALE_V1',
            'theorem_identity_count':118,
            'distinct_pair_count':6903,
            'effect_response_dimension':1302,
            'route_context_count':192,
            'chart_A':'P093-P103','chart_B':'P101-P117','overlap':'P101-P103',
            'chart_rotation_degrees':77.043300265,
            'vertex_centered_angles_audited':800748,
            'claim_ceiling':pair['result'].get('claim_ceiling') if pair.get('ok') else None,
            'integration_counters':counters,
        },
        'integration':{
            'pre_all_aux':True,
            'active_mechanisms':len(REGISTRY),
            'new_registry_mechanisms_added':0,
            'theorem_route_auto_measurement':True,
            'explicit_distance_api':True,
            'false_pythagoras_rejected':True,
            'gram_fallback':True,
            'root_truth_credit_added':0,
        },
        'inherited_ac76_contract':'Preserved; AC76 qualification rerun separately remains 9/9 PASS.',
        'remaining_open_relative_to_pass054_claim_ceiling':gate.get('extension_work_remaining') or [],
    }
    print(json.dumps(out,indent=2,ensure_ascii=False))

if __name__=='__main__':
    main()
