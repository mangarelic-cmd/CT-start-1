from __future__ import annotations
from fractions import Fraction
from typing import Any, Dict, Iterable, List, Tuple
import hashlib, json
from all_everything_wave_engine import Node, AuxResult

def _canon(x: Any) -> str:
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True, default=str)

def _sha(x: Any) -> str:
    return hashlib.sha256(_canon(x).encode()).hexdigest()

def _result(mid: str, node: Node, status: str, kind: str, **payload: Any) -> AuxResult:
    return AuxResult(mid, status, kind, payload, node.identity())

def _obs(mid: str, node: Node, statement: str) -> AuxResult:
    return _result(mid, node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement=statement)

def exact_fraction(v: Any) -> Fraction:
    if isinstance(v, bool):
        raise TypeError('boolean is not an exact scalar')
    if isinstance(v, Fraction):
        return v
    if isinstance(v, int):
        return Fraction(v, 1)
    if isinstance(v, (list, tuple)) and len(v) == 2:
        return Fraction(int(v[0]), int(v[1]))
    if isinstance(v, str):
        t = v.strip()
        if not t or any((ch in t for ch in '.eE')):
            raise ValueError('decimal/inexact scalar forbidden')
        return Fraction(t)
    raise TypeError(f'unsupported exact scalar {type(v).__name__}')

def fobj(q: Fraction) -> List[int]:
    return [q.numerator, q.denominator]

def _flatten_state(v: Any) -> Tuple[str, Dict[str, Fraction]]:
    if isinstance(v, dict):
        if not v:
            raise ValueError('empty state mapping')
        out = {str(k): exact_fraction(v[k]) for k in sorted(v, key=str)}
        return ('mapping', out)
    if isinstance(v, (list, tuple)):
        if len(v) == 2:
            if all((isinstance(x, int) and (not isinstance(x, bool)) for x in v)):
                return ('scalar', {'value': exact_fraction(v)})
        if not v:
            raise ValueError('empty state vector')
        return ('vector', {str(i): exact_fraction(x) for i, x in enumerate(v)})
    return ('scalar', {'value': exact_fraction(v)})

def _state_obj(shape: str, comps: Dict[str, Fraction]) -> Any:
    if shape == 'scalar':
        return fobj(comps['value'])
    if shape == 'vector':
        return [fobj(comps[str(i)]) for i in range(len(comps))]
    return {k: fobj(comps[k]) for k in sorted(comps)}

def normalize_anchor_observations(raw: Any) -> Dict[str, Any]:
    if not isinstance(raw, (list, tuple)) or len(raw) < 2:
        raise ValueError('at least two exact anchors are required')
    anchors = []
    shape = None
    keys = None
    seen = set()
    for i, a in enumerate(raw):
        if not isinstance(a, dict):
            raise TypeError('each anchor must be an object')
        xraw = a.get('coordinate', a.get('x', a.get('n')))
        if xraw is None:
            raise ValueError('anchor coordinate missing')
        sraw = a.get('state', a.get('value', a.get('coordinates')))
        if sraw is None:
            raise ValueError('anchor state missing')
        x = exact_fraction(xraw)
        if x in seen:
            raise ValueError('duplicate anchor coordinate')
        seen.add(x)
        shp, comp = _flatten_state(sraw)
        if shape is None:
            shape, keys = (shp, tuple(sorted(comp)))
        if shp != shape or tuple(sorted(comp)) != keys:
            raise ValueError('anchor state dimension/type drift')
        anchors.append((x, comp, a.get('label', f'A{i}')))
    anchors.sort(key=lambda t: t[0])
    return {'shape': shape, 'components': list(keys or ()), 'anchors': [{'coordinate': fobj(x), 'state': _state_obj(shape, comp), 'label': label} for x, comp, label in anchors]}

def _anchor_internal(norm: Dict[str, Any]) -> Tuple[str, List[str], List[Fraction], Dict[str, List[Fraction]]]:
    shape = norm['shape']
    keys = list(norm['components'])
    xs = [exact_fraction(a['coordinate']) for a in norm['anchors']]
    ys: Dict[str, List[Fraction]] = {k: [] for k in keys}
    for a in norm['anchors']:
        _, comp = _flatten_state(a['state'])
        for k in keys:
            ys[k].append(comp[k])
    return (shape, keys, xs, ys)

def newton_coefficients(xs: List[Fraction], ys: List[Fraction]) -> List[Fraction]:
    if len(xs) != len(ys) or not xs:
        raise ValueError('invalid interpolation data')
    if len(set(xs)) != len(xs):
        raise ValueError('duplicate interpolation coordinate')
    a = list(ys)
    for j in range(1, len(xs)):
        for i in range(len(xs) - 1, j - 1, -1):
            den = xs[i] - xs[i - j]
            if den == 0:
                raise ValueError('zero divided-difference denominator')
            a[i] = (a[i] - a[i - 1]) / den
    return a

def newton_eval(xs: List[Fraction], coeffs: List[Fraction], x: Fraction) -> Fraction:
    if not coeffs:
        raise ValueError('empty polynomial')
    y = coeffs[-1]
    for i in range(len(coeffs) - 2, -1, -1):
        y = y * (x - xs[i]) + coeffs[i]
    return y

def _degree(coeffs: List[Fraction]) -> int:
    for i in range(len(coeffs) - 1, -1, -1):
        if coeffs[i] != 0:
            return i
    return 0

def _finite_differences(values: List[Fraction]) -> List[List[Fraction]]:
    table = [list(values)]
    while len(table[-1]) > 1:
        prev = table[-1]
        table.append([prev[i + 1] - prev[i] for i in range(len(prev) - 1)])
    return table

def synthesize_minimal_transport(raw_anchors: Any, route_coordinates: Any=None) -> Dict[str, Any]:
    norm = normalize_anchor_observations(raw_anchors)
    shape, keys, xs, ys = _anchor_internal(norm)
    coeffs: Dict[str, List[Fraction]] = {}
    degrees: Dict[str, int] = {}
    for k in keys:
        c = newton_coefficients(xs, ys[k])
        coeffs[k] = c
        degrees[k] = _degree(c)
    degree = max(degrees.values()) if degrees else 0
    exact_anchor_replay = True
    for k in keys:
        for x, y in zip(xs, ys[k]):
            if newton_eval(xs, coeffs[k], x) != y:
                exact_anchor_replay = False
                break
    slopes: Dict[str, List[Fraction]] = {}
    parallel = True
    for k in keys:
        ss = [(ys[k][i + 1] - ys[k][i]) / (xs[i + 1] - xs[i]) for i in range(len(xs) - 1)]
        slopes[k] = ss
        if any((s != ss[0] for s in ss[1:])):
            parallel = False
    generator = {k: slopes[k][0] if slopes[k] else Fraction(0) for k in keys} if parallel else None
    route_xs: List[Fraction] = []
    if route_coordinates is not None:
        if not isinstance(route_coordinates, (list, tuple)):
            raise TypeError('route_coordinates must be a list')
        route_xs = [exact_fraction(x) for x in route_coordinates]
    else:
        route_xs = list(xs)
    predictions = []
    for x in route_xs:
        comp = {k: newton_eval(xs, coeffs[k], x) for k in keys}
        predictions.append({'coordinate': fobj(x), 'state': _state_obj(shape, comp)})
    unit_grid = all((xs[i + 1] - xs[i] == 1 for i in range(len(xs) - 1)))
    fd = {}
    if unit_grid:
        for k in keys:
            table = _finite_differences(ys[k])
            fd[k] = [[fobj(v) for v in row] for row in table[:degree + 2]]
    law = {'schema': 'MINIMAL_EXACT_ANCHOR_TRANSPORT_LAW_V1', 'state_shape': shape, 'components': keys, 'anchor_coordinates': [fobj(x) for x in xs], 'anchor_count': len(xs), 'minimal_polynomial_degree': degree, 'component_degrees': degrees, 'newton_basis_nodes': [fobj(x) for x in xs], 'newton_coefficients': {k: [fobj(v) for v in coeffs[k]] for k in keys}, 'strict_parallelity': parallel, 'parallel_generator': None if generator is None else {k: fobj(generator[k]) for k in keys}, 'unit_grid': unit_grid, 'finite_difference_table': fd, 'exact_anchor_replay': exact_anchor_replay, 'forward_reverse_same_law': exact_anchor_replay, 'predictions': predictions, 'external_domain_binding_required': True, 'unconditional_theorem': False}
    law['law_digest'] = _sha(law)
    return law

def parallel_anchor_transport(node: Node, world: Dict[str, Any]) -> AuxResult:
    if node.kind != 'COORDINATE_DYNAMICS_RECEIPT':
        return _obs('PARALLEL_ANCHOR_FINITE_DIFFERENCE_TRANSPORT', node, 'PARALLEL_TRANSPORT_WAIT_COORDINATE_DYNAMICS')
    anchors = node.payload.get('transport_anchors')
    route = node.payload.get('route_coordinates')
    if not anchors:
        return _result('PARALLEL_ANCHOR_FINITE_DIFFERENCE_TRANSPORT', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='PARALLEL_TRANSPORT_NEEDS_EXACT_ANCHORS', requires=['EXACT_PARALLEL_ANCHORS'])
    try:
        law = synthesize_minimal_transport(anchors, route)
    except Exception as exc:
        return _result('PARALLEL_ANCHOR_FINITE_DIFFERENCE_TRANSPORT', node, 'INVALID', 'INVALID_RESULT', statement='PARALLEL_TRANSPORT_EXACT_SYNTHESIS_REJECTED', error=str(exc))
    if not law['exact_anchor_replay']:
        return _result('PARALLEL_ANCHOR_FINITE_DIFFERENCE_TRANSPORT', node, 'INVALID', 'INVALID_RESULT', statement='PARALLEL_TRANSPORT_ANCHOR_REPLAY_FAILED')
    statement = 'STRICT_PARALLEL_TRANSPORT_GENERATOR_SYNTHESIZED' if law['strict_parallelity'] else 'MINIMAL_FINITE_DIFFERENCE_TRANSPORT_LAW_SYNTHESIZED'
    return _result('PARALLEL_ANCHOR_FINITE_DIFFERENCE_TRANSPORT', node, 'PASS', 'PARALLEL_TRANSPORT_LAW_RECEIPT', statement=statement, transport_law=law, law_digest=law['law_digest'], strict_parallelity=law['strict_parallelity'], minimal_polynomial_degree=law['minimal_polynomial_degree'], supplies=['EXACT_PARALLEL_TRANSPORT_LAW', 'FORWARD_TRANSPORT_WITNESS', 'REVERSE_TRANSPORT_WITNESS'])
