from __future__ import annotations
from typing import Any, Dict, List, Sequence
import math
import sympy as sp

from causal_grid_bindings import bind_metric_weight

SCHEMA = 'AC73_CAUSAL_GRID_ATLAS_BINDINGS_V1'


def _M(x: Any) -> sp.Matrix:
    return x if isinstance(x, sp.MatrixBase) else sp.Matrix(x)


def _S(x: Any) -> sp.Expr:
    return x if isinstance(x, sp.Basic) else sp.sympify(x)


def _json_matrix(M: sp.MatrixBase) -> List[List[str]]:
    return [[str(sp.simplify(M[i, j])) for j in range(M.cols)] for i in range(M.rows)]


def _positive_diag(vals: Sequence[Any]) -> bool:
    for raw in vals:
        v = sp.simplify(_S(raw))
        if v.is_number and not bool(v > 0):
            return False
    return True


def metric_from_domain(domain: str, dimension: int | None = None, **kwargs: Any) -> Dict[str, Any]:
    """Fail-closed domain metric atlas.

    The atlas supplies only canonical metrics that are part of the declared mathematical
    structure or metrics explicitly provided by the caller. It never turns a space name,
    stage number, operation count, or display index into a distance.
    """
    d = str(domain or '').upper().strip()
    n = int(dimension or kwargs.get('n') or 0)

    if d in {'SCALAR_FIELD', 'REAL_LINE', 'EUCLIDEAN_RN', 'VECTOR_SPACE_EUCLIDEAN'}:
        n = n or 1
        G = sp.eye(n)
        return {'status': 'PASS', 'domain': d, 'metric': _json_matrix(G), 'metric_matrix': G,
                'authority': 'CANONICAL_EUCLIDEAN_INNER_PRODUCT', 'metric_invented': False}

    if d in {'HERMITIAN_CN', 'COMPLEX_EUCLIDEAN', 'L2_FINITE', 'FOURIER_UNITARY_L2'}:
        n = n or 1
        weights = kwargs.get('quadrature_weights')
        if weights is None:
            G = sp.eye(n)
            authority = 'CANONICAL_HERMITIAN_L2_INNER_PRODUCT'
        else:
            vals = [_S(v) for v in weights]
            if len(vals) != n or not _positive_diag(vals):
                return {'status': 'REJECTED', 'domain': d, 'reason': 'quadrature weights must be positive and match dimension'}
            G = sp.diag(*vals)
            authority = 'DECLARED_EXACT_L2_QUADRATURE_WEIGHTS'
        return {'status': 'PASS', 'domain': d, 'metric': _json_matrix(G), 'metric_matrix': G,
                'authority': authority, 'metric_invented': False, 'complex_carrier': True}

    if d in {'WEIGHTED_L2', 'DIAGONAL_METRIC'}:
        weights = kwargs.get('weights')
        if not isinstance(weights, (list, tuple)) or not weights or not _positive_diag(weights):
            return {'status': 'OPEN_MISSING_METRIC_DATA', 'domain': d, 'requires': ['POSITIVE_EXACT_METRIC_WEIGHTS']}
        G = sp.diag(*[_S(v) for v in weights])
        return {'status': 'PASS', 'domain': d, 'metric': _json_matrix(G), 'metric_matrix': G,
                'authority': str(kwargs.get('metric_authority') or 'DECLARED_WEIGHTED_L2_METRIC'), 'metric_invented': False}

    if d in {'H1_DISCRETE', 'SOBOLEV_H1_DISCRETE'}:
        D = kwargs.get('derivative_matrix')
        if D is None:
            return {'status': 'OPEN_MISSING_METRIC_DATA', 'domain': d, 'requires': ['DERIVATIVE_MATRIX']}
        D = _M(D)
        n = n or D.cols
        if D.cols != n:
            return {'status': 'REJECTED', 'domain': d, 'reason': 'derivative matrix column count must match dimension'}
        mass = kwargs.get('mass_metric')
        M = sp.eye(n) if mass is None else _M(mass)
        if M.shape != (n, n):
            return {'status': 'REJECTED', 'domain': d, 'reason': 'mass metric dimension mismatch'}
        row_weights = kwargs.get('derivative_weights')
        W = sp.eye(D.rows) if row_weights is None else sp.diag(*[_S(v) for v in row_weights])
        if W.shape != (D.rows, D.rows):
            return {'status': 'REJECTED', 'domain': d, 'reason': 'derivative weights dimension mismatch'}
        G = sp.simplify(M + D.T * W * D)
        return {'status': 'PASS', 'domain': d, 'metric': _json_matrix(G), 'metric_matrix': G,
                'authority': str(kwargs.get('metric_authority') or 'DISCRETE_H1_INNER_PRODUCT'), 'metric_invented': False}

    if d in {'RIEMANNIAN_USER', 'TYPED_RIEMANNIAN_CHART'}:
        metric = kwargs.get('metric')
        authority = kwargs.get('metric_authority')
        if metric is None or not authority:
            return {'status': 'OPEN_MISSING_METRIC_DATA', 'domain': d, 'requires': ['EXPLICIT_METRIC', 'METRIC_AUTHORITY']}
        G = _M(metric)
        if G.rows != G.cols or sp.simplify(G - G.T) != sp.zeros(G.rows):
            return {'status': 'REJECTED', 'domain': d, 'reason': 'declared Riemannian metric must be square and symmetric'}
        return {'status': 'PASS', 'domain': d, 'metric': _json_matrix(G), 'metric_matrix': G,
                'authority': str(authority), 'metric_invented': False}

    if d in {'QUOTIENT_HORIZONTAL', 'GAUGE_HORIZONTAL'}:
        ambient = kwargs.get('ambient_metric')
        basis = kwargs.get('horizontal_basis')
        authority = kwargs.get('metric_authority')
        if ambient is None or basis is None or not authority:
            return {'status': 'OPEN_MISSING_METRIC_DATA', 'domain': d,
                    'requires': ['AMBIENT_METRIC', 'HORIZONTAL_BASIS_OR_GAUGE_FIXING', 'METRIC_AUTHORITY']}
        G = _M(ambient); H = _M(basis)
        if G.rows != G.cols or G.rows != H.rows:
            return {'status': 'REJECTED', 'domain': d, 'reason': 'ambient metric / horizontal basis mismatch'}
        induced = sp.simplify(H.T * G * H)
        return {'status': 'PASS', 'domain': d, 'metric': _json_matrix(induced), 'metric_matrix': induced,
                'authority': str(authority), 'metric_invented': False,
                'rule': 'G_horizontal = H^T G_ambient H'}

    if d in {'PROOF_COST', 'THEOREM_COST'}:
        costs = kwargs.get('cost_weights')
        authority = kwargs.get('cost_authority')
        if not costs or not authority:
            return {'status': 'OPEN_NO_CANONICAL_PROOF_METRIC', 'domain': d,
                    'requires': ['AUTHORITATIVE_PROOF_COST_WEIGHTS', 'PROOF_COST_AUTHORITY'],
                    'reason': 'proof-line count or theorem name is not a causal metric'}
        if not _positive_diag(costs):
            return {'status': 'REJECTED', 'domain': d, 'reason': 'proof cost weights must be positive'}
        G = sp.diag(*[_S(v) for v in costs])
        return {'status': 'PASS', 'domain': d, 'metric': _json_matrix(G), 'metric_matrix': G,
                'authority': str(authority), 'metric_invented': False, 'scheduling_metric_not_truth': True}

    if d in {'TOPOLOGICAL_SPACE', 'BARE_TOPOLOGY', 'GAUGE_ORBIT_WITHOUT_FIXING'}:
        return {'status': 'OPEN_NO_CANONICAL_METRIC', 'domain': d,
                'requires': ['METRIC_OR_RIEMANNIAN_STRUCTURE'],
                'reason': 'topology alone does not determine distances'}

    return {'status': 'OPEN_UNREGISTERED_DOMAIN_METRIC', 'domain': d,
            'requires': ['DOMAIN_METRIC_ADAPTER_OR_EXPLICIT_METRIC'], 'metric_invented': False}


def bind_domain_metric_weight(domain: str, displacement: Any, dimension: int | None = None, **kwargs: Any) -> Dict[str, Any]:
    atlas = metric_from_domain(domain, dimension=dimension, **kwargs)
    if atlas.get('status') != 'PASS':
        return atlas
    result = bind_metric_weight(displacement, atlas['metric_matrix'])
    result['schema'] = 'AC73_DOMAIN_METRIC_WEIGHT_V1'
    result['domain'] = atlas['domain']
    result['metric_authority'] = atlas['authority']
    result['atlas_metric'] = atlas['metric']
    return result


# Primitive CT causal-order signatures. These are a coordinate-basis convention over
# the source phase labels (+,-,x,/,=). It is not a universal projection for arbitrary operators.
_PRIMITIVE_PSI = {
    '+': (1, 0, 0, 0, 0), 'ADD': (1, 0, 0, 0, 0), 'PLUS': (1, 0, 0, 0, 0),
    '-': (0, 1, 0, 0, 0), 'SUBTRACT': (0, 1, 0, 0, 0), 'MINUS': (0, 1, 0, 0, 0),
    '*': (0, 0, 1, 0, 0), 'X': (0, 0, 1, 0, 0), 'MULTIPLY': (0, 0, 1, 0, 0),
    '/': (0, 0, 0, 1, 0), 'DIVIDE': (0, 0, 0, 1, 0),
    '=': (0, 0, 0, 0, 1), 'EQUALITY': (0, 0, 0, 0, 1), 'CLOSE': (0, 0, 0, 0, 1),
}


def _primitive_name(op: str) -> str:
    u = str(op or '').upper().strip()
    for prefix, canon in [('ADD(', 'ADD'), ('SUBTRACT(', 'SUBTRACT'), ('MULTIPLY(', 'MULTIPLY'), ('DIVIDE(', 'DIVIDE')]:
        if u.startswith(prefix): return canon
    return u


def bind_operator_phi5_psi(operator: str, primitive_decomposition: List[str] | None = None,
                            explicit_delta_s: Any = None, psi_authority: Any = None,
                            normalize_simplex: bool = False) -> Dict[str, Any]:
    key = _primitive_name(operator)
    if key in _PRIMITIVE_PSI:
        vec = sp.Matrix(_PRIMITIVE_PSI[key])
        return {'status': 'PASS', 'schema': 'AC73_OPERATOR_PHI5_PSI_V1', 'operator': operator,
                'delta_s': [str(v) for v in vec], 'psi_kind': 'CT_PRIMITIVE_PHASE_BASIS',
                'psi_authority': 'CT_PRIME_SOURCE_PHASE_SIGNATURE_BASIS_CONVENTION',
                'universal_arbitrary_operator_claim': False}

    if primitive_decomposition:
        total = sp.zeros(5, 1)
        unknown = []
        for op in primitive_decomposition:
            k = _primitive_name(op)
            if k not in _PRIMITIVE_PSI:
                unknown.append(str(op)); continue
            total += sp.Matrix(_PRIMITIVE_PSI[k])
        if unknown:
            return {'status': 'OPEN_MISSING_PSI', 'schema': 'AC73_OPERATOR_PHI5_PSI_V1',
                    'operator': operator, 'unknown_primitives': unknown,
                    'requires': ['PSI_FOR_UNRESOLVED_PRIMITIVES']}
        if normalize_simplex:
            z = sp.simplify(sum(total))
            if z != 0: total = sp.simplify(total / z)
        return {'status': 'PASS', 'schema': 'AC73_OPERATOR_PHI5_PSI_V1', 'operator': operator,
                'delta_s': [str(sp.simplify(v)) for v in total], 'psi_kind': 'PRIMITIVE_DECOMPOSITION',
                'psi_authority': str(psi_authority or 'DECLARED_PRIMITIVE_DECOMPOSITION'),
                'normalization': 'SIMPLEX' if normalize_simplex else 'RAW_COUNTS',
                'universal_arbitrary_operator_claim': False}

    if explicit_delta_s is not None and psi_authority:
        v = _M(explicit_delta_s)
        if v.cols != 1: v = sp.Matrix(list(v))
        if v.rows != 5:
            return {'status': 'REJECTED', 'schema': 'AC73_OPERATOR_PHI5_PSI_V1', 'reason': 'Phi5 delta_s must have five components'}
        return {'status': 'PASS', 'schema': 'AC73_OPERATOR_PHI5_PSI_V1', 'operator': operator,
                'delta_s': [str(sp.simplify(v[i,0])) for i in range(5)], 'psi_kind': 'EXPLICIT_TYPED_ADAPTER',
                'psi_authority': str(psi_authority), 'universal_arbitrary_operator_claim': False}

    return {'status': 'OPEN_MISSING_PSI', 'schema': 'AC73_OPERATOR_PHI5_PSI_V1', 'operator': operator,
            'requires': ['PRIMITIVE_DECOMPOSITION_OR_TYPED_PSI_ADAPTER'],
            'reason': 'semantic resemblance is not an operator-to-Phi5 projection'}


def bind_finite_fibre_residue(inputs: Sequence[Any], outputs: Sequence[Any]) -> Dict[str, Any]:
    if len(inputs) != len(outputs) or not inputs:
        return {'status': 'REJECTED', 'schema': 'AC73_FINITE_FIBRE_RESIDUE_V1', 'reason': 'inputs/outputs must be same nonzero length'}
    fibres: Dict[str, List[Any]] = {}
    for x, y in zip(inputs, outputs):
        fibres.setdefault(repr(y), []).append(x)
    codebook = []
    reconstruct = {}
    max_fibre = max(len(v) for v in fibres.values())
    for ykey, xs in fibres.items():
        for j, x in enumerate(xs):
            codebook.append({'output_key': ykey, 'residue_index': j, 'input': repr(x)})
            reconstruct[(ykey, j)] = repr(x)
    bits = 0 if max_fibre <= 1 else int(math.ceil(math.log(max_fibre, 2)))
    return {'status': 'PASS', 'schema': 'AC73_FINITE_FIBRE_RESIDUE_V1',
            'max_fibre_size': max_fibre, 'minimal_fixed_length_bits': bits,
            'codebook': codebook, 'fibre_separating': True,
            'rule': 'residue index separates each output fibre exactly'}


def bind_nonlinear_branch_residue(kind: str, x: Any) -> Dict[str, Any]:
    k = str(kind or '').upper()
    xv = _S(x)
    if k in {'SQUARE_REAL', 'ABS_REAL'}:
        y = sp.simplify(xv**2) if k == 'SQUARE_REAL' else sp.Abs(xv)
        if xv.is_positive: sign = 1
        elif xv.is_negative: sign = -1
        elif xv == 0: sign = 0
        else:
            return {'status': 'OPEN_BRANCH_UNDECIDED', 'schema': 'AC73_NONLINEAR_BRANCH_RESIDUE_V1',
                    'requires': ['SIGN_OR_BRANCH_WITNESS']}
        return {'status': 'PASS', 'schema': 'AC73_NONLINEAR_BRANCH_RESIDUE_V1', 'kind': k,
                'output': str(y), 'residue': {'branch_sign': sign},
                'reconstruction_rule': 'sign*sqrt(output)' if k == 'SQUARE_REAL' else 'sign*output',
                'fibre_separating': True}
    return {'status': 'OPEN_UNREGISTERED_NONLINEAR_RESIDUE', 'schema': 'AC73_NONLINEAR_BRANCH_RESIDUE_V1',
            'kind': k, 'requires': ['NONLINEAR_FIBRE_ADAPTER_OR_EXPLICIT_RESIDUE']}


def bind_dissipative_residue(current_state: Any, history: Any = None, environment: Any = None,
                              authority: Any = None) -> Dict[str, Any]:
    if authority is None or (history is None and environment is None):
        return {'status': 'OPEN_MISSING_DISSIPATIVE_COMPLEMENT', 'schema': 'AC73_DISSIPATIVE_RESIDUE_V1',
                'requires': ['HISTORY_OR_ENVIRONMENT_COMPLEMENT', 'COMPLEMENT_AUTHORITY'],
                'reason': 'forward dissipative state alone does not authorize causal reversal'}
    return {'status': 'PASS', 'schema': 'AC73_DISSIPATIVE_RESIDUE_V1', 'current_state': repr(current_state),
            'history_residue': repr(history), 'environment_residue': repr(environment),
            'authority': str(authority), 'mirror_kind': 'STRUCTURAL_REPLAY_PACKAGE',
            'causal_reverse_claimed': False, 'information_complement_preserved': True}


def bind_selection_residue(candidates: Sequence[Any], selected_index: int,
                           criterion_authority: Any = None) -> Dict[str, Any]:
    if criterion_authority is None:
        return {'status': 'OPEN_MISSING_SELECTION_AUTHORITY', 'schema': 'AC73_SELECTION_RESIDUE_V1',
                'requires': ['SELECTION_CRITERION_AUTHORITY']}
    if not candidates or not (0 <= int(selected_index) < len(candidates)):
        return {'status': 'REJECTED', 'schema': 'AC73_SELECTION_RESIDUE_V1', 'reason': 'invalid candidate population or index'}
    i = int(selected_index)
    rejected = [repr(x) for j, x in enumerate(candidates) if j != i]
    return {'status': 'PASS', 'schema': 'AC73_SELECTION_RESIDUE_V1', 'selected': repr(candidates[i]),
            'selected_index': i, 'rejected_candidates_residue': rejected,
            'criterion_authority': str(criterion_authority), 'population_reconstructible': True,
            'causal_reverse_claimed': False}


def apply_atlas_bindings(payload: Dict[str, Any], diagnosis: Dict[str, Any]) -> Dict[str, Any]:
    out: Dict[str, Any] = {'schema': SCHEMA, 'bindings': {}}
    b = out['bindings']

    req = payload.get('domain_metric_binding')
    if isinstance(req, dict) and req.get('domain') and req.get('displacement') is not None:
        kw = {k: v for k, v in req.items() if k not in {'domain', 'displacement', 'dimension'}}
        b['domain_metric'] = bind_domain_metric_weight(req['domain'], req['displacement'], req.get('dimension'), **kw)

    req = payload.get('operator_phi5_psi_binding')
    if isinstance(req, dict) and req.get('operator'):
        b['operator_phi5_psi'] = bind_operator_phi5_psi(
            req['operator'], req.get('primitive_decomposition'), req.get('explicit_delta_s'),
            req.get('psi_authority'), bool(req.get('normalize_simplex', False)))

    req = payload.get('finite_fibre_residue_binding')
    if isinstance(req, dict) and isinstance(req.get('inputs'), list) and isinstance(req.get('outputs'), list):
        b['finite_fibre_residue'] = bind_finite_fibre_residue(req['inputs'], req['outputs'])

    req = payload.get('nonlinear_residue_binding')
    if isinstance(req, dict) and req.get('kind') and req.get('x') is not None:
        b['nonlinear_residue'] = bind_nonlinear_branch_residue(req['kind'], req['x'])

    req = payload.get('dissipative_residue_binding')
    if isinstance(req, dict) and req.get('current_state') is not None:
        b['dissipative_residue'] = bind_dissipative_residue(req.get('current_state'), req.get('history'), req.get('environment'), req.get('authority'))

    req = payload.get('selection_residue_binding')
    if isinstance(req, dict) and isinstance(req.get('candidates'), list) and req.get('selected_index') is not None:
        b['selection_residue'] = bind_selection_residue(req['candidates'], int(req['selected_index']), req.get('criterion_authority'))

    statuses = [v.get('status') for v in b.values() if isinstance(v, dict)]
    open_req = sorted({r for v in b.values() if isinstance(v, dict) for r in (v.get('requires') or [])})
    out['status'] = 'PASS' if statuses and all(s == 'PASS' for s in statuses) else ('PARTIAL' if statuses else 'NO_ATLAS_BINDING_REQUEST')
    out['open_requirements'] = open_req
    out['closed_task_families'] = ['T07_DOMAIN_METRIC_ATLAS', 'T08_OPERATOR_PHI5_PSI_LIBRARY', 'T09_NONLINEAR_DISSIPATIVE_RESIDUE_LIBRARY'] if out['status'] == 'PASS' else []
    return out
