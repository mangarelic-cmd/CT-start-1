"""AUX Full Causal Coordinate Atlas v0.2

Replaces sketch letters with the complete current coordinate bases:
  - every spatial catalogue object is a native SIN2 coordinate;
  - every temporal catalogue object is a native SIN1 coordinate;
  - at the time/space membrane, each temporal coordinate has a spatialized
    address SIGMA::<temporal_id>, and each spatial coordinate has a temporalized
    address TAU::<spatial_id>.

The dual addresses are proof/geolocation coordinates, not permission to execute
an operator under the wrong mathematical semantics. Operations are validated
against their native typed coordinates; the dual frame is a linked witness.
"""
from __future__ import annotations
from collections import deque
from dataclasses import dataclass
from hashlib import sha256
from pathlib import Path
from typing import Any, Iterable
import json
ORIENTATIONS = {'NATIVE', 'TWIST', 'DUAL'}

class AtlasError(ValueError):
    pass

class DirectedGraph:

    def __init__(self, nodes: Iterable[str], edges: Iterable[tuple[str, str]]):
        self.nodes = set(nodes)
        self.up = {n: set() for n in self.nodes}
        for a, b in edges:
            if a not in self.nodes or b not in self.nodes:
                raise AtlasError(f'UNKNOWN_EDGE_ENDPOINT::{a}::{b}')
            self.up[a].add(b)

    def upward_distance(self, child: str, container: str) -> int | None:
        if child not in self.nodes or container not in self.nodes:
            return None
        if child == container:
            return 0
        q = deque([(child, 0)])
        seen = {child}
        while q:
            x, d = q.popleft()
            for y in self.up.get(x, ()):
                if y == container:
                    return d + 1
                if y not in seen:
                    seen.add(y)
                    q.append((y, d + 1))
        return None

    def upward_path(self, child: str, container: str) -> list[str] | None:
        if child not in self.nodes or container not in self.nodes:
            return None
        if child == container:
            return [child]
        q = deque([child])
        prev = {child: None}
        while q:
            x = q.popleft()
            for y in self.up.get(x, ()):
                if y in prev:
                    continue
                prev[y] = x
                if y == container:
                    path = [y]
                    while prev[path[-1]] is not None:
                        path.append(prev[path[-1]])
                    return list(reversed(path))
                q.append(y)
        return None

    def has_cycle(self) -> bool:
        indeg = {n: 0 for n in self.nodes}
        for a in self.nodes:
            for b in self.up[a]:
                indeg[b] += 1
        q = deque([n for n, d in indeg.items() if d == 0])
        seen = 0
        while q:
            n = q.popleft()
            seen += 1
            for b in self.up[n]:
                indeg[b] -= 1
                if indeg[b] == 0:
                    q.append(b)
        return seen != len(self.nodes)

@dataclass(frozen=True)
class CoordinateState:
    state_id: str
    primary_space: str
    active_spaces: tuple[str, ...]
    active_times: tuple[str, ...]
    orientation: str = 'NATIVE'

class FullCausalCoordinateAtlas:

    def __init__(self, space_catalog: str | Path, time_catalog: str | Path):
        self.space_data = json.loads(Path(space_catalog).read_text(encoding='utf-8'))
        self.time_data = json.loads(Path(time_catalog).read_text(encoding='utf-8'))
        self.space_ids = list(self.space_data['catalog'].keys())
        self.time_entries = list(self.time_data['entries'])
        self.time_ids = [e['id'] for e in self.time_entries]
        if len(self.space_ids) != len(set(self.space_ids)):
            raise AtlasError('DUPLICATE_SPATIAL_COORDINATE')
        if len(self.time_ids) != len(set(self.time_ids)):
            raise AtlasError('DUPLICATE_TEMPORAL_COORDINATE')
        self.space_index = {sid: i for i, sid in enumerate(self.space_ids)}
        self.time_index = {tid: i for i, tid in enumerate(self.time_ids)}
        self.time_entry = {e['id']: e for e in self.time_entries}
        self.space_graph = DirectedGraph(self.space_ids, [(e['contained'], e['container']) for e in self.space_data['strict_candidate_edges']])
        self.time_graph = DirectedGraph(self.time_ids, [(e['contained'], e['container']) for e in self.time_data['strict_containment_edges']])
        self.atlas_digest = self._digest({'space_ids': self.space_ids, 'time_ids': self.time_ids, 'space_edges': self.space_data['strict_candidate_edges'], 'time_edges': self.time_data['strict_containment_edges']})

    @staticmethod
    def _digest(obj: Any) -> str:
        raw = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(',', ':')).encode('utf-8')
        return sha256(raw).hexdigest()

    @staticmethod
    def spatialized_time(tid: str) -> str:
        return f'SIGMA::{tid}'

    @staticmethod
    def temporalized_space(sid: str) -> str:
        return f'TAU::{sid}'

    @staticmethod
    def native_from_dual(coord: str) -> tuple[str, str]:
        if coord.startswith('SIGMA::'):
            return ('TIME', coord.split('::', 1)[1])
        if coord.startswith('TAU::'):
            return ('SPACE', coord.split('::', 1)[1])
        raise AtlasError('NOT_A_DUAL_COORDINATE')

    def validate_state(self, s: CoordinateState) -> None:
        if s.orientation not in ORIENTATIONS:
            raise AtlasError('ORIENTATION_MUST_BE_NATIVE_TWIST_OR_DUAL')
        if s.primary_space not in self.space_index:
            raise AtlasError(f'UNKNOWN_PRIMARY_SPACE::{s.primary_space}')
        for sid in s.active_spaces:
            if sid not in self.space_index:
                raise AtlasError(f'UNKNOWN_SPATIAL_COORDINATE::{sid}')
        for tid in s.active_times:
            if tid.startswith('SIGMA::') or tid.startswith('TAU::'):
                raise AtlasError('DUAL_ADDRESS_CANNOT_REPLACE_NATIVE_TEMPORAL_SEMANTICS')
            if tid not in self.time_index:
                raise AtlasError(f'UNKNOWN_TEMPORAL_COORDINATE::{tid}')
        if s.primary_space not in s.active_spaces:
            raise AtlasError('PRIMARY_SPACE_MUST_BE_ACTIVE')

    def project(self, s: CoordinateState) -> dict[str, Any]:
        self.validate_state(s)
        native_space_idx = sorted((self.space_index[x] for x in s.active_spaces))
        native_time_idx = sorted((self.time_index[x] for x in s.active_times))
        result = {'schema': 'CT_FULL_COORDINATE_STATE_V0_2', 'state_id': s.state_id, 'atlas_digest': self.atlas_digest, 'orientation': s.orientation, 'native_provenance': {'primary_space': s.primary_space, 'spaces': list(s.active_spaces), 'times': list(s.active_times)}, 'native_sparse_vectors': {'space_dimension': len(self.space_ids), 'space_active_indices': native_space_idx, 'time_dimension': len(self.time_ids), 'time_active_indices': native_time_idx}, 'active_frame': {}}
        if s.orientation == 'NATIVE':
            result['active_frame'] = {'space_basis': 'NATIVE_SPACE', 'space_coordinates': list(s.active_spaces), 'time_basis': 'NATIVE_TIME', 'time_coordinates': list(s.active_times)}
        elif s.orientation == 'TWIST':
            result['active_frame'] = {'space_basis': 'NATIVE_SPACE_PLUS_SPATIALIZED_TIME', 'space_coordinates': list(s.active_spaces) + [self.spatialized_time(t) for t in s.active_times], 'time_basis': 'NATIVE_TIME_PLUS_TEMPORALIZED_SPACE', 'time_coordinates': list(s.active_times) + [self.temporalized_space(x) for x in s.active_spaces], 'junction': 'TIME_SPACE_MEMBRANE'}
        else:
            result['active_frame'] = {'space_basis': 'SPATIALIZED_TIME', 'space_coordinates': [self.spatialized_time(t) for t in s.active_times], 'time_basis': 'TEMPORALIZED_SPACE', 'time_coordinates': [self.temporalized_space(x) for x in s.active_spaces]}
        return result

    def full_registry(self) -> dict[str, Any]:
        return {'schema': 'CT_FULL_COORDINATE_ATLAS_V0_2', 'atlas_digest': self.atlas_digest, 'native_space_coordinate_count': len(self.space_ids), 'native_time_coordinate_count': len(self.time_ids), 'space_to_time_ratio': len(self.time_ids) / len(self.space_ids), 'native_space_coordinates': [{'index': i, 'id': sid, 'label': self.space_data['catalog'][sid], 'dual': self.temporalized_space(sid)} for i, sid in enumerate(self.space_ids)], 'native_time_coordinates': [{'index': i, 'id': e['id'], 'label': e['label'], 'kind': e['kind'], 'dual': self.spatialized_time(e['id']), 'catalog_sigma': e.get('supracausal_spatial_coordinate')} for i, e in enumerate(self.time_entries)]}

    def containment_receipt(self, child: str, container: str, domain: str) -> dict[str, Any]:
        graph = self.space_graph if domain == 'SPACE' else self.time_graph
        path = graph.upward_path(child, container)
        return {'domain': domain, 'child': child, 'container': container, 'valid': path is not None, 'distance': None if path is None else len(path) - 1, 'path': path}

    def global_self_test(self) -> dict[str, Any]:
        reversibility = []
        for tid in self.time_ids:
            kind, back = self.native_from_dual(self.spatialized_time(tid))
            reversibility.append(kind == 'TIME' and back == tid)
        for sid in self.space_ids:
            kind, back = self.native_from_dual(self.temporalized_space(sid))
            reversibility.append(kind == 'SPACE' and back == sid)
        sigma = {self.spatialized_time(t) for t in self.time_ids}
        tau = {self.temporalized_space(s) for s in self.space_ids}
        checks = {'space_count_matches_catalog': len(self.space_ids) == int(self.space_data['catalog_count']), 'time_count_matches_catalog': len(self.time_ids) == int(self.time_data['count']), 'space_indices_bijective': len(self.space_index) == len(self.space_ids), 'time_indices_bijective': len(self.time_index) == len(self.time_ids), 'all_dual_coordinates_reversible': all(reversibility), 'dual_coordinate_count': len(sigma | tau) == len(self.time_ids) + len(self.space_ids), 'space_graph_acyclic': not self.space_graph.has_cycle(), 'time_graph_acyclic': not self.time_graph.has_cycle()}
        return {'schema': 'CT_FULL_COORDINATE_ATLAS_SELF_TEST_V0_2', 'atlas_digest': self.atlas_digest, 'coordinate_counts': {'space': len(self.space_ids), 'time': len(self.time_ids), 'dual_total': len(sigma | tau)}, 'checks': checks, 'pass': all(checks.values())}

class HeatImpulseTransitionHarness:
    """Typed test problem: retarded 1D heat response to a point impulse.

    PDE: d_t u - k d_xx u = delta(t)delta(x), u(t<0)=0.
    For t>0 the response is the heat kernel. The harness tests whether the
    coordinate atlas lets the solver move through the required spaces/times
    without turning the dual coordinates into fake mathematical operators.
    """

    def __init__(self, atlas: FullCausalCoordinateAtlas, symbolic_receipt: dict[str, Any]):
        self.a = atlas
        self.symbolic = symbolic_receipt
        self.rules = {'RETARDED_CAUSALIZE': {'input_space': 'TEMPERED_DISTRIBUTION_SPACE', 'required_times': {'INSTANT_TIME_POINT_T0', 'RETARDED_GREEN_OPERATOR'}, 'output_space': 'TEMPERED_DISTRIBUTION_SPACE', 'authority': 'TYPED_OPERATION'}, 'HEAT_SEMIGROUP_REGULARIZE_DELTA': {'input_space': 'TEMPERED_DISTRIBUTION_SPACE', 'required_times': {'NONNEGATIVE_CONTINUOUS_TIME_R', 'SEMIGROUP_TIME', 'ONE_PARAMETER_SEMIGROUP_EXP_TA'}, 'output_space': 'ESPACE_DE_SCHWARTZ_S', 'authority': 'DOMAIN_THEOREM_HEAT_KERNEL_T_POSITIVE'}, 'VERIFY_HEAT_PDE': {'input_space': 'ESPACE_DE_SCHWARTZ_S', 'required_times': {'PARTIAL_TIME_DERIVATIVE_PARTIAL_T', 'FINITE_CLOSED_TIME_INTERVAL_A_B'}, 'output_space': 'ESPACE_DE_SCHWARTZ_S', 'authority': 'SYMBOLIC_IDENTITY'}, 'EMBED_SCHWARTZ_IN_L2': {'input_space': 'ESPACE_DE_SCHWARTZ_S', 'required_times': set(), 'output_space': 'L_2', 'authority': 'CATALOG_CONTAINMENT'}, 'VERIFY_L2_OBSERVABLE': {'input_space': 'L_2', 'required_times': {'EVOLUTION_OPERATOR_U_T_T0', 'NONNEGATIVE_CONTINUOUS_TIME_R'}, 'output_space': 'L_2', 'authority': 'SYMBOLIC_FINITE_L2_NORM'}}

    def _space_acceptable(self, actual: str, required: str) -> bool:
        return actual == required or self.a.space_graph.upward_distance(actual, required) is not None

    def apply(self, operation: str, state: CoordinateState, output_state: CoordinateState) -> dict[str, Any]:
        self.a.validate_state(state)
        self.a.validate_state(output_state)
        if operation not in self.rules:
            raise AtlasError(f'UNKNOWN_OPERATION::{operation}')
        r = self.rules[operation]
        missing_times = sorted(r['required_times'] - set(state.active_times))
        input_ok = self._space_acceptable(state.primary_space, r['input_space'])
        output_ok = output_state.primary_space == r['output_space']
        authority_ok = True
        authority_receipt = None
        if r['authority'] == 'CATALOG_CONTAINMENT':
            authority_receipt = self.a.containment_receipt(r['input_space'], r['output_space'], 'SPACE')
            authority_ok = authority_receipt['valid']
        elif r['authority'] == 'SYMBOLIC_IDENTITY':
            authority_receipt = {'pde_residual_zero': self.symbolic.get('pde_residual_zero', False)}
            authority_ok = bool(authority_receipt['pde_residual_zero'])
        elif r['authority'] == 'SYMBOLIC_FINITE_L2_NORM':
            authority_receipt = {'l2_norm_squared_finite_for_t_positive': self.symbolic.get('l2_norm_squared_finite_for_t_positive', False)}
            authority_ok = bool(authority_receipt['l2_norm_squared_finite_for_t_positive'])
        elif r['authority'] == 'DOMAIN_THEOREM_HEAT_KERNEL_T_POSITIVE':
            authority_receipt = {'theorem': 'DELTA_UNDER_HEAT_SEMIGROUP_IS_GAUSSIAN_SCHWARTZ_FOR_T_POSITIVE', 'declared': True}
        elif r['authority'] == 'TYPED_OPERATION':
            authority_receipt = {'typed_operation': True}
        passed = input_ok and (not missing_times) and output_ok and authority_ok
        return {'operation': operation, 'input_state': state.state_id, 'output_state': output_state.state_id, 'input_space_ok': input_ok, 'required_input_space': r['input_space'], 'actual_input_space': state.primary_space, 'missing_required_time_coordinates': missing_times, 'output_space_ok': output_ok, 'required_output_space': r['output_space'], 'actual_output_space': output_state.primary_space, 'authority': r['authority'], 'authority_receipt': authority_receipt, 'pass': passed}

    def run(self) -> dict[str, Any]:
        states = [CoordinateState('P_SOURCE_DELTA', 'TEMPERED_DISTRIBUTION_SPACE', ('TEMPERED_DISTRIBUTION_SPACE', 'ESPACE_DES_DISTRIBUTIONS_D'), ('INSTANT_TIME_POINT_T0', 'RETARDED_GREEN_OPERATOR'), 'NATIVE'), CoordinateState('CAUSAL_DISTRIBUTION', 'TEMPERED_DISTRIBUTION_SPACE', ('TEMPERED_DISTRIBUTION_SPACE', 'ESPACE_DES_DISTRIBUTIONS_D'), ('NONNEGATIVE_CONTINUOUS_TIME_R', 'SEMIGROUP_TIME', 'ONE_PARAMETER_SEMIGROUP_EXP_TA'), 'NATIVE'), CoordinateState('R_REGULARIZED_GAUSSIAN', 'ESPACE_DE_SCHWARTZ_S', ('ESPACE_DE_SCHWARTZ_S', 'L_1', 'L_2', 'L_INFTY', 'TEMPERED_DISTRIBUTION_SPACE', 'ESPACE_DES_DISTRIBUTIONS_D'), ('NONNEGATIVE_CONTINUOUS_TIME_R', 'SEMIGROUP_TIME', 'ONE_PARAMETER_SEMIGROUP_EXP_TA', 'PARTIAL_TIME_DERIVATIVE_PARTIAL_T', 'FINITE_CLOSED_TIME_INTERVAL_A_B'), 'TWIST'), CoordinateState('R_PDE_VERIFIED', 'ESPACE_DE_SCHWARTZ_S', ('ESPACE_DE_SCHWARTZ_S', 'L_1', 'L_2', 'L_INFTY', 'TEMPERED_DISTRIBUTION_SPACE', 'ESPACE_DES_DISTRIBUTIONS_D'), ('PARTIAL_TIME_DERIVATIVE_PARTIAL_T', 'FINITE_CLOSED_TIME_INTERVAL_A_B', 'NONNEGATIVE_CONTINUOUS_TIME_R'), 'TWIST'), CoordinateState('POST_L2_REALIZATION', 'L_2', ('L_2',), ('EVOLUTION_OPERATOR_U_T_T0', 'NONNEGATIVE_CONTINUOUS_TIME_R'), 'DUAL'), CoordinateState('S_SOLUTION_VERIFIED', 'L_2', ('L_2',), ('EVOLUTION_OPERATOR_U_T_T0', 'NONNEGATIVE_CONTINUOUS_TIME_R'), 'DUAL')]
        ops = ['RETARDED_CAUSALIZE', 'HEAT_SEMIGROUP_REGULARIZE_DELTA', 'VERIFY_HEAT_PDE', 'EMBED_SCHWARTZ_IN_L2', 'VERIFY_L2_OBSERVABLE']
        receipts = [self.apply(op, states[i], states[i + 1]) for i, op in enumerate(ops)]
        bad1 = self.apply('EMBED_SCHWARTZ_IN_L2', states[0], states[4])
        bad2 = self.apply('VERIFY_HEAT_PDE', states[1], states[3])
        dual_only_semantics_rejected = False
        try:
            CoordinateState('BAD_DUAL_AS_NATIVE', 'L_2', ('L_2',), ('SIGMA::PARTIAL_TIME_DERIVATIVE_PARTIAL_T',), 'DUAL')
            self.a.validate_state(CoordinateState('BAD_DUAL_AS_NATIVE', 'L_2', ('L_2',), ('SIGMA::PARTIAL_TIME_DERIVATIVE_PARTIAL_T',), 'DUAL'))
        except AtlasError:
            dual_only_semantics_rejected = True
        distances = {'time_t0_to_interval': self.a.containment_receipt('INSTANT_TIME_POINT_T0', 'FINITE_CLOSED_TIME_INTERVAL_A_B', 'TIME'), 'time_interval_to_R': self.a.containment_receipt('FINITE_CLOSED_TIME_INTERVAL_A_B', 'REAL_TIME_AXIS_R', 'TIME'), 'time_Rplus_to_R': self.a.containment_receipt('NONNEGATIVE_CONTINUOUS_TIME_R', 'REAL_TIME_AXIS_R', 'TIME'), 'space_S_to_L2': self.a.containment_receipt('ESPACE_DE_SCHWARTZ_S', 'L_2', 'SPACE'), 'space_S_to_Sprime': self.a.containment_receipt('ESPACE_DE_SCHWARTZ_S', 'TEMPERED_DISTRIBUTION_SPACE', 'SPACE'), 'space_Sprime_to_Dprime': self.a.containment_receipt('TEMPERED_DISTRIBUTION_SPACE', 'ESPACE_DES_DISTRIBUTIONS_D', 'SPACE'), 'space_Sprime_to_S_is_not_containment': self.a.containment_receipt('TEMPERED_DISTRIBUTION_SPACE', 'ESPACE_DE_SCHWARTZ_S', 'SPACE')}
        projections = [self.a.project(s) for s in states]
        checks = {'all_positive_operations_pass': all((r['pass'] for r in receipts)), 'illegal_direct_Sprime_to_L2_rejected': not bad1['pass'], 'missing_time_operator_rejected': not bad2['pass'], 'dual_address_not_executable_as_native_operator': dual_only_semantics_rejected, 'regularization_is_not_faked_as_containment': not distances['space_Sprime_to_S_is_not_containment']['valid'], 'twist_contains_both_native_and_dual_frames': projections[2]['orientation'] == 'TWIST' and any((x.startswith('SIGMA::') for x in projections[2]['active_frame']['space_coordinates'])) and any((x.startswith('TAU::') for x in projections[2]['active_frame']['time_coordinates'])), 'post_frame_is_time_as_space_and_space_as_time': projections[4]['active_frame']['space_basis'] == 'SPATIALIZED_TIME' and projections[4]['active_frame']['time_basis'] == 'TEMPORALIZED_SPACE'}
        return {'schema': 'CT_HEAT_IMPULSE_MULTI_SPACE_MULTI_TIME_TEST_V0_2', 'problem': '1D retarded heat response to point impulse', 'equation': 'partial_t u - k partial_xx u = delta(t) delta(x), u(t<0)=0', 'states': projections, 'operation_receipts': receipts, 'negative_controls': {'illegal_embedding': bad1, 'missing_time_operator': bad2}, 'structural_distance_receipts': distances, 'symbolic_domain_receipt': self.symbolic, 'checks': checks, 'pass': all(checks.values())}
