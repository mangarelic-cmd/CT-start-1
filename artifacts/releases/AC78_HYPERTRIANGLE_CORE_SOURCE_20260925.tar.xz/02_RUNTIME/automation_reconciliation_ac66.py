from __future__ import annotations

from dataclasses import dataclass
from hashlib import sha256
from typing import Any, Dict, Iterable, Tuple
import json
import math

from all_everything_wave_engine import AuxResult, Node, normalize_requirement, split_requirement

SCHEMA = 'AC66_CROSS_PROBLEM_AUTOMATION_RECONCILIATION_V1'

ADMIN_KEYS = {
    'mechanism','status','digest','receipt_digest','proof_digest','material_digest',
    'carrier_digest','provider_digest','relation_digest','semantic_id','id','wave',
    'calls_total','execution_calls','timestamp','created_at','updated_at','sha256',
    'source_digest','result_semantic','input_node','projection_color'
}

OPEN_EXACT = {
    'OPEN','PARTIAL','NEED_DATA','MISSING_CARRIER','CAPABILITY_GAP','WAITING',
    'INVALID','COUNTEREXAMPLE','UNKNOWN','UNPROVED','RESOURCE_CHECKPOINT',
    'RESOURCE_BOUND','SEARCHED','UNMATERIALIZED'
}

LOCAL_GLOBAL_CLASSES = (
    'TAIL_REMAINDER_DOMINATION',
    'COERCIVITY_HIDDEN_DIRECTION_ORIENTATION',
    'INVERSE_PROVENANCE_EXACT_RETURN_MAP',
    'UNIFORMIZATION_ROOT_INDEPENDENCE',
    'LOCAL_TO_GLOBAL_WELL_FOUNDEDNESS',
)


def canon(x: Any) -> str:
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False, default=str)


def digest(x: Any) -> str:
    return sha256(canon(x).encode()).hexdigest()


def _result(mid: str, node: Node, status: str, kind: str, **payload) -> AuxResult:
    return AuxResult(mid, status, kind, payload, node.identity())


def _list(x: Any) -> list[str]:
    if x is None:
        return []
    if isinstance(x, (list, tuple, set)):
        return [str(v) for v in x if str(v)]
    return [str(x)]


def open_like_status(status: Any) -> bool:
    """Anti-omission classification.

    AC65 exact-set checks missed enriched states such as OPEN_WITH_PAID_RESULTANT_SUPPLY.
    AC66 treats enriched OPEN/UNKNOWN/WAIT/RESOURCE states as active scientific metadata.
    """
    s = str(status or '').strip().upper()
    if not s:
        return False
    if s in OPEN_EXACT:
        return True
    prefixes = ('OPEN_', 'OPEN_WITH_', 'UNKNOWN_', 'WAITING_', 'NEED_', 'MISSING_', 'RESOURCE_', 'PARTIAL_')
    suffixes = ('_OPEN', '_UNPROVED', '_WAITING', '_NEED_DATA', '_UNKNOWN')
    return s.startswith(prefixes) or s.endswith(suffixes)


def epistemic_status(status: Any, payload: Dict[str, Any] | None = None) -> str:
    payload = payload or {}
    s = str(status or '').upper()
    if payload.get('formal_proof_verified') is True or payload.get('kernel_verified') is True:
        return 'PROVED'
    if payload.get('counterexample_verified') is True or payload.get('refutation_verified') is True:
        return 'REFUTED'
    if s in {'COUNTEREXAMPLE'} and payload.get('verified') is True:
        return 'REFUTED'
    if s == 'PASS' and payload.get('scientific_promotion') is True:
        return 'PROVED'
    return 'UNKNOWN' if open_like_status(s) or s in {'PASS','NOT_APPLICABLE'} else 'UNKNOWN'


def _strip_admin(x: Any) -> Any:
    if isinstance(x, dict):
        out = {}
        for k, v in x.items():
            if k in ADMIN_KEYS:
                continue
            if k == 'requires':
                out[k] = sorted({normalize_requirement(str(r)) for r in _list(v)})
            elif k in {'parents','provenance_ids','receipt_ids','geometry_receipt_ids'}:
                continue
            else:
                out[k] = _strip_admin(v)
        return out
    if isinstance(x, list):
        return [_strip_admin(v) for v in x]
    if isinstance(x, tuple):
        return tuple(_strip_admin(v) for v in x)
    return x


def scientific_signature(node: Node) -> str:
    """Content signature for common-trunk novelty; provenance remains separate."""
    p = _strip_admin(dict(node.payload))
    # Wrapper kinds are deliberately normalized to their scientific statement/target.
    wrapper_kinds = {
        'DATA_OBLIGATION','PROOF_OBLIGATION','PROOF_SEARCH_NODE','OPEN_RESIDUAL_CURRENT',
        'SCIENTIFIC_CONSTRUCTION_CURRENT','OBLIGATION_STRATEGY_REQUEST','DELTA_RESIDUAL',
        'FORMAL_PROOF_CURRENT'
    }
    k = 'SCIENTIFIC_CURRENT' if node.kind in wrapper_kinds else node.kind
    return digest({'kind': k, 'payload': p, 'context': list(node.context)})


def sovereign_root_identity(node: Node) -> str:
    p = node.payload
    explicit = p.get('sovereign_root_id') or p.get('root_id') or p.get('root_question_id')
    if explicit:
        return str(explicit)
    q = p.get('sovereign_question') or p.get('root_question')
    if q:
        return 'ROOT::' + digest({'question': q})[:24]
    if p.get('sovereign_focus') or p.get('scientific_focus') or node.kind == 'PROBLEM':
        stmt = p.get('statement') or p.get('obligation') or node.identity()
        return 'ROOT::' + digest({'statement': stmt, 'context': list(node.context)})[:24]
    return ''


def sovereign_root_lock(node: Node, world: Dict[str, Any]) -> AuxResult:
    rid = sovereign_root_identity(node)
    inherited = str(node.payload.get('inherited_sovereign_root_id') or '')
    if not rid and inherited:
        rid = inherited
    if not rid:
        return _result('SOVEREIGN_ROOT_LOCK', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_SOVEREIGN_ROOT_CONTEXT')
    attempted = str(node.payload.get('attempted_root_replacement') or '')
    mismatch = bool(attempted and attempted != rid)
    return _result(
        'SOVEREIGN_ROOT_LOCK', node, 'PASS', 'SOVEREIGN_ROOT_RECEIPT',
        statement='SOVEREIGN_ROOT_PRESERVED' if not mismatch else 'CHILD_ROOT_REPLACEMENT_REJECTED_AS_CONTROL_MUTATION',
        sovereign_root_id=rid,
        attempted_root_replacement=attempted or None,
        child_cannot_replace_root=True,
        repair_required=mismatch,
        supplies=['SOVEREIGN_ROOT_IDENTITY']
    )


def full_delta_compiler(node: Node, world: Dict[str, Any]) -> AuxResult:
    p = node.payload
    # Explicit first-solution-field coordinates permit exact arithmetic on a scalar/vector chart.
    cur = p.get('current_state_coordinate')
    sol = p.get('first_solution_field_coordinate')
    if cur is not None and sol is not None:
        try:
            if isinstance(cur, (list, tuple)) and isinstance(sol, (list, tuple)) and len(cur) == len(sol):
                delta = [sol[i] - cur[i] for i in range(len(cur))]
            else:
                delta = sol - cur
            return _result(
                'FULL_DELTA_COMPILER', node, 'PASS', 'FULL_DELTA_RECEIPT',
                statement='MAXIMAL_DISPLACEMENT_TO_MINIMAL_FIRST_SOLUTION_FIELD_COMPUTED',
                current_state_coordinate=cur,
                first_solution_field_coordinate=sol,
                full_delta=delta,
                semantics='MAXIMAL_DISPLACEMENT_OF_MINIMAL_SOLUTION_NOT_SMALLEST_LOCAL_STEP',
                supplies=['SOVEREIGN_FULL_DELTA']
            )
        except Exception:
            pass
    req = sorted({normalize_requirement(str(r)) for r in _list(p.get('requires')) + _list(p.get('open_requirements'))})
    if p.get('full_delta_components'):
        req = sorted({normalize_requirement(str(r)) for r in _list(p.get('full_delta_components'))})
    if not req and not (p.get('scientific_focus') or p.get('sovereign_focus') or node.kind in {'PROBLEM','OPEN_RESIDUAL','SCIENTIFIC_CURRENT'}):
        return _result('FULL_DELTA_COMPILER', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_FULL_DELTA_CONTEXT')
    return _result(
        'FULL_DELTA_COMPILER', node, 'OPEN', 'SOVEREIGN_FULL_DELTA_CURRENT',
        statement='FULL_DELTA_IS_COMPLETE_DISPLACEMENT_TO_FIRST_SOLUTION_FIELD',
        sovereign_root_id=sovereign_root_identity(node) or p.get('inherited_sovereign_root_id'),
        full_delta_components=req,
        first_solution_field_known=bool(p.get('first_solution_field') or sol is not None),
        semantics='DO_NOT_REPLACE_WITH_MINIMUM_SCHEDULER_STEP',
        requires=[] if (p.get('first_solution_field') or sol is not None) else ['FIRST_SOLUTION_FIELD_LOCATION'],
        delta_cost=[0,0,0,len(req)]
    )


def semantic_projection_bundle(node: Node, world: Dict[str, Any]) -> AuxResult:
    p = node.payload
    scientific_kinds = {
        'PROBLEM','SCIENTIFIC_CURRENT','OPEN_RESIDUAL_CURRENT','OPEN_RESIDUAL',
        'SOVEREIGN_FULL_DELTA_CURRENT','LOCAL_GLOBAL_ACTION_REQUEST',
        'SCIENTIFIC_CONSTRUCTION_CURRENT','FORMAL_PROOF_CURRENT','DELTA_RESIDUAL'
    }
    if p.get('ac66_projection_materialized') is True or node.kind.endswith('_OBSERVATION') or (node.kind not in scientific_kinds and not (p.get('scientific_focus') or p.get('sovereign_focus'))):
        return _result('SEMANTIC_PROJECTION_COMPILER', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_NEW_SEMANTIC_PROJECTION_REQUIRED')
    req = _list(p.get('requires'))
    statement = str(p.get('statement') or p.get('obligation') or p.get('target_obligation') or '')
    views: Dict[str, Any] = {
        'SOVEREIGN': {'sovereign_root_id': sovereign_root_identity(node), 'statement': statement, 'requires': req},
        'PROOF': {'formal_statement': p.get('formal_statement'), 'formal_target': p.get('formal_target') or statement, 'proof_object': p.get('proof_object'), 'proof_reconstruction_spec': p.get('proof_reconstruction_spec')},
        'GEOMETRY': {'route_points': p.get('route_points'), 'coordinates': p.get('coordinates') or p.get('common_coordinates'), 'common_coordinates': p.get('common_coordinates'), 'carrier': p.get('carrier'), 'carrier_specification': p.get('carrier_specification')},
        'ARITHMETIC': {'arithmetic_operation': p.get('arithmetic_operation'), 'arithmetic_operands': p.get('arithmetic_operands'), 'exact_rational': p.get('exact_rational')},
        'BOUND': {'exact_interval': p.get('exact_interval'), 'exact_bound': p.get('exact_bound'), 'bound_target': p.get('bound_target')},
        'TEMPORAL': {'epoch': p.get('epoch'), 'parent_epoch': p.get('parent_epoch'), 'trajectory': p.get('trajectory'), 'temporal_target': p.get('temporal_target')},
        'RELATION': {'relations': p.get('relations'), 'edges': p.get('edges'), 'derivation_map': p.get('derivation_map'), 'projection_map': p.get('projection_map'), 'exact_relation': p.get('exact_relation')},
        'MATERIAL': {'material_packet': p.get('material_packet'), 'materialization_catalog': p.get('materialization_catalog'), 'artifact_catalog': p.get('artifact_catalog'), 'reconstruction_rules': p.get('reconstruction_rules'), 'carrier_catalog': p.get('carrier_catalog')},
        'CAUSAL_GRID': {
            'causal_grid_core_status': p.get('causal_grid_core_status'),
            'causal_grid_core_diagnosis': p.get('causal_grid_core_diagnosis'),
            'causal_grid_cells': p.get('causal_grid_cells'),
            'causal_grid_grid': p.get('causal_grid_grid'),
            'causal_grid_typing_requires': p.get('causal_grid_typing_requires'),
            'causal_grid_residues': p.get('causal_grid_residues'),
            'causal_grid_structural_mirror_not_causal_inverse': p.get('causal_grid_structural_mirror_not_causal_inverse'),
            'causal_grid_metric_invented': p.get('causal_grid_metric_invented'),
        },
    }
    views = {k:v for k,v in views.items() if any(x not in (None, [], {}, '') for x in v.values())}
    return _result(
        'SEMANTIC_PROJECTION_COMPILER', node, 'PASS', 'SEMANTIC_PROJECTION_BUNDLE',
        statement='SCIENTIFIC_OBJECT_PROJECTED_INTO_AUX_LANGUAGES',
        source_scientific_signature=scientific_signature(node),
        views=views,
        projection_count=len(views),
        opaque_broadcast_only=False,
        supplies=['SEMANTIC_PROJECTIONS_AVAILABLE']
    )



def first_solution_field_localizer(node: Node, world: Dict[str, Any]) -> AuxResult:
    """Compile the target location needed by FULL_DELTA without substituting a scheduler step.

    PrimeGrid/Temporal are treated as localization evidence; they do not become truth by name.
    """
    p=node.payload
    if p.get('first_solution_field_coordinate') is not None:
        return _result(
            'FIRST_SOLUTION_FIELD_LOCALIZER', node, 'PASS', 'FIRST_SOLUTION_FIELD_RECEIPT',
            statement='FIRST_SOLUTION_FIELD_ALREADY_EXACTLY_LOCATED',
            coordinate=p.get('first_solution_field_coordinate'),
            provenance=p.get('first_solution_field_provenance') or 'EXPLICIT_INPUT',
            supplies=['FIRST_SOLUTION_FIELD_LOCATION']
        )
    pg = p.get('primegrid_solution_address') or p.get('prime_grid_solution_address') or world.get('primegrid_solution_address')
    temporal = p.get('temporal_solution_position') or world.get('temporal_solution_position')
    formula = p.get('solution_field_constraints') or p.get('full_formula_constraints') or world.get('solution_field_constraints')
    if pg is None and temporal is None and formula is None:
        if not (p.get('scientific_focus') or p.get('sovereign_focus') or node.kind in {'PROBLEM','SOVEREIGN_FULL_DELTA_CURRENT'}):
            return _result('FIRST_SOLUTION_FIELD_LOCALIZER', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_SOLUTION_FIELD_LOCALIZATION_CONTEXT')
    missing=[]
    if pg is None: missing.append('PRIMEGRID_SOLUTION_ADDRESS')
    if temporal is None: missing.append('TEMPORAL_SOLUTION_POSITION')
    if formula is None: missing.append('FULL_FORMULA_SOLUTION_CONSTRAINTS')
    if missing:
        return _result(
            'FIRST_SOLUTION_FIELD_LOCALIZER', node, 'OPEN', 'FIRST_SOLUTION_FIELD_LOCALIZATION_CURRENT',
            statement='LOCALIZE_FIRST_CAUSALLY_ADMISSIBLE_SOLUTION_FIELD_BEFORE_COMPUTING_FULL_DELTA',
            primegrid_solution_address=pg, temporal_solution_position=temporal,
            solution_field_constraints=formula, requires=missing,
            smallest_local_step_is_not_target=True, movement_blocked=False,
            delta_cost=[1,0,0,len(missing)]
        )
    # If all three are present but no exact coordinate is supplied, retain them as a localization packet.
    # AC66 must not invent a metric coordinate from addresses alone.
    return _result(
        'FIRST_SOLUTION_FIELD_LOCALIZER', node, 'OPEN', 'FIRST_SOLUTION_FIELD_LOCALIZATION_CURRENT',
        statement='LOCALIZATION_EVIDENCE_COMPLETE_BUT_EXACT_SOLUTION_COORDINATE_NOT_YET_DERIVED',
        primegrid_solution_address=pg, temporal_solution_position=temporal,
        solution_field_constraints=formula,
        requires=['DERIVE_EXACT_FIRST_SOLUTION_FIELD_COORDINATE'],
        invent_coordinate_forbidden=True, movement_blocked=False,
        delta_cost=[1,0,0,1]
    )


def _closure_action_for_requirement(req: str) -> str:
    t=str(req or '').upper()
    material_tokens=('MATERIAL','CARRIER','SERIALIZ','ENUMERAT','INDEX','STREAM','LIST','CATALOG','BYTES','PARAMETER BOX','PARAMETER_BOX')
    execute_tokens=('COMPUTE','EVALUATE','APPLY','ISOLAT','SOLVE','SEARCH','EXHAUST','COUNT','PIVOT','SCHUR','HANKEL','NEWTON')
    prove_tokens=('PROVE','CERTIF','UNIFORM','COVER','INJECT','SURJECT','BOUND','MARGIN','EQUIVAL','IMPL','NO_GAP','NO GAP','BIJECT','FINITE','GLOBAL')
    falsify_tokens=('COUNTEREXAMPLE','REFUT','OBSTRUCTION','NO_GO','NO-GO','FALSIF')
    if any(x in t for x in falsify_tokens): return 'FALSIFY_OR_CERTIFY_OBSTRUCTION'
    if any(x in t for x in material_tokens): return 'MATERIALIZE_OR_ENUMERATE'
    if any(x in t for x in execute_tokens): return 'EXECUTE_EXACT_KERNEL_THEN_CERTIFY'
    if any(x in t for x in prove_tokens): return 'PROVE_OR_CERTIFY'
    return 'CONSTRUCT_WITNESS_THEN_CERTIFY'


def closure_mode_action_compiler(node: Node, world: Dict[str, Any]) -> AuxResult:
    p=node.payload
    reqs=_list(p.get('open_requirements')) or _list(p.get('requires'))
    reqs=[normalize_requirement(str(r)) for r in reqs if str(r)]
    if not reqs or (not open_like_status(p.get('status')) and not (p.get('scientific_focus') or p.get('sovereign_focus') or node.kind in {'PROBLEM','OPEN_RESIDUAL_CURRENT','SOVEREIGN_FULL_DELTA_CURRENT','SCIENTIFIC_CONSTRUCTION_CURRENT'})):
        return _result('CLOSURE_MODE_ACTION_COMPILER', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_OPEN_REQUIREMENTS_TO_COMPILE')
    actions=[]
    for i,req in enumerate(sorted(set(reqs))):
        actions.append({
            'action_id': digest({'source':scientific_signature(node),'requirement':req})[:24],
            'requirement': req,
            'action_class': _closure_action_for_requirement(req),
            'target_root': sovereign_root_identity(node) or p.get('inherited_sovereign_root_id'),
            'success_condition': 'EXACT_REPLAYABLE_WITNESS_PROOF_OR_VERIFIED_NEGATIVE_RECEIPT',
            'falsification_is_data_not_terminal_root_refutation': True,
            'reinjection': 'RETURN_TO_SAME_SOVEREIGN_OBJECT_AND_REMEASURE_FULL_DELTA',
        })
    return _result(
        'CLOSURE_MODE_ACTION_COMPILER', node, 'OPEN', 'CLOSURE_ACTION_BUNDLE',
        statement='OPEN_REQUIREMENTS_COMPILED_TO_TYPED_CLOSURE_ACTIONS',
        actions=actions, action_count=len(actions),
        requires=['CLOSURE_ACTION_RESULT::'+a['action_id'] for a in actions],
        manual_action_request_authoring_required=False,
        delta_cost=[1,0,0,len(actions)]
    )

def negative_knowledge_skin_manager(node: Node, world: Dict[str, Any]) -> AuxResult:
    p = node.payload
    s = str(p.get('status') or '').upper()
    negative = bool(
        p.get('counterexample_verified') or p.get('refutation_verified') or p.get('no_go_verified') or
        p.get('no_gain_verified') or s in {'COUNTEREXAMPLE'} or 'NO_GO' in s or 'NO-GO' in s or 'REFUT' in s
    )
    if not negative:
        return _result('NEGATIVE_KNOWLEDGE_SKIN_MANAGER', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_NEGATIVE_KNOWLEDGE_TO_COMMIT')
    sig = str(p.get('route_signature') or p.get('negative_route_signature') or scientific_signature(node))
    store = world.setdefault('_ac66_negative_knowledge', {})
    store[sig] = {
        'scope': p.get('scope'), 'statement': p.get('statement'), 'obstruction': p.get('obstruction') or p.get('counterexample'),
        'source_node': node.identity()
    }
    return _result(
        'NEGATIVE_KNOWLEDGE_SKIN_MANAGER', node, 'PASS', 'NEGATIVE_KNOWLEDGE_RECEIPT',
        statement='NEGATIVE_RESULT_COMMITTED_TO_APPEND_ONLY_SKIN', route_signature=sig,
        scope=p.get('scope'), reusable=True, terminal_root_claim=False,
        supplies=['NEGATIVE_KNOWLEDGE::' + sig]
    )


def wrapper_eliminator(node: Node, world: Dict[str, Any]) -> AuxResult:
    reqs = _list(node.payload.get('requires'))
    normalized = sorted({normalize_requirement(r) for r in reqs})
    nested = any(len(split_requirement(r)[0]) > 1 for r in reqs)
    explicit = bool(node.payload.get('wrapper_components'))
    federation = bool(node.payload.get('coverage_exhaustive') and node.payload.get('introduces_new_law') is False and node.payload.get('introduces_new_data') is False)
    if not (nested or explicit or federation):
        return _result('NONINDEPENDENT_WRAPPER_ELIMINATOR', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_NONINDEPENDENT_WRAPPER_DETECTED')
    comps = _list(node.payload.get('wrapper_components')) or normalized
    return _result(
        'NONINDEPENDENT_WRAPPER_ELIMINATOR', node, 'PASS', 'WRAPPER_ELIMINATION_RECEIPT',
        statement='NONINDEPENDENT_WRAPPER_COLLAPSED_TO_SCIENTIFIC_COMPONENTS',
        components=comps, normalized_requirements=normalized,
        independent_scientific_debt=False,
        supplies=['WRAPPER_NORMALIZED'],
        reactivation_targets=comps
    )


def open_status_anti_omission(node: Node, world: Dict[str, Any]) -> AuxResult:
    st = str(node.payload.get('status') or '')
    if not open_like_status(st):
        return _result('OPEN_STATUS_ANTI_OMISSION', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='STATUS_NOT_OPEN_LIKE')
    return _result(
        'OPEN_STATUS_ANTI_OMISSION', node, 'PASS', 'OPEN_STATUS_RECEIPT',
        statement='ENRICHED_OPEN_STATUS_PRESERVED_AS_ACTIVE', original_status=st,
        open_like=True, must_not_be_dropped=True,
        supplies=['ACTIVE_OPEN_STATUS_ANNOTATION']
    )


def classify_local_global_deficit(text: str) -> str | None:
    t = str(text or '').upper()
    if any(k in t for k in ('TAIL','REMAINDER','DECAY','FEJER','ERROR BOUND','ERROR_BOUND')):
        return 'TAIL_REMAINDER_DOMINATION'
    if any(k in t for k in ('COERC','HIDDEN DIRECTION','HIDDEN_DIRECTION','ORIENTATION','POSITIVE DEFINITE','SPECTRAL GAP')):
        return 'COERCIVITY_HIDDEN_DIRECTION_ORIENTATION'
    if any(k in t for k in ('PROVENANCE','RETURN MAP','RETURN_MAP','INVERSE MAP','INVERSE_MAP','RECONSTRUCT SOURCE','RECONSTRUCT_SOURCE')):
        return 'INVERSE_PROVENANCE_EXACT_RETURN_MAP'
    if any(k in t for k in ('UNIFORM','ROOT-INDEPENDENT','ROOT_INDEPENDENT','FOR EVERY','FOR_ALL','GLOBAL COVERAGE','GLOBAL_COVERAGE')):
        return 'UNIFORMIZATION_ROOT_INDEPENDENCE'
    if any(k in t for k in ('WELL-FOUNDED','WELL_FOUNDED','TERMINATION','DESCENT','NO INFINITE','NO_INFINITE','LOCAL TO GLOBAL','LOCAL_TO_GLOBAL')):
        return 'LOCAL_TO_GLOBAL_WELL_FOUNDEDNESS'
    return None


def local_global_transducer(node: Node, world: Dict[str, Any]) -> AuxResult:
    p = node.payload
    text = ' '.join([str(p.get('statement') or ''), str(p.get('obligation') or ''), ' '.join(_list(p.get('requires')))])
    cls = str(p.get('local_global_deficit_class') or '') or classify_local_global_deficit(text)
    if cls not in LOCAL_GLOBAL_CLASSES:
        return _result('LOCAL_GLOBAL_TRANSDUCER', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_LOCAL_GLOBAL_DEFICIT_CLASSIFIED')
    plans = {
        'TAIL_REMAINDER_DOMINATION': ['MATERIALIZE_UNIFORM_TAIL_BOUND','COMPARE_TAIL_TO_REQUIRED_MARGIN','FALSIFY_BY_EXTREMAL_SEQUENCE'],
        'COERCIVITY_HIDDEN_DIRECTION_ORIENTATION': ['ENUMERATE_HIDDEN_DIRECTIONS','BUILD_COERCIVITY_OR_SEPARATION_WITNESS','AUDIT_ORIENTATION'],
        'INVERSE_PROVENANCE_EXACT_RETURN_MAP': ['RECOVER_SOURCE_PROVENANCE','CONSTRUCT_EXACT_INVERSE_RETURN_MAP','VERIFY_ROUNDTRIP'],
        'UNIFORMIZATION_ROOT_INDEPENDENCE': ['LIFT_POINTWISE_TO_UNIFORM_QUANTIFIERS','AUDIT_ROOT_DEPENDENCY_POLARITY','SEARCH_COUNTERMODEL_TO_UNIFORMITY'],
        'LOCAL_TO_GLOBAL_WELL_FOUNDEDNESS': ['DEFINE_GLOBAL_RANK','PROVE_STRICT_DESCENT','EXCLUDE_INFINITE_OR_APERIODIC_ESCAPE'],
    }
    target = p.get('formal_target') or p.get('target') or p.get('statement') or p.get('obligation')
    return _result(
        'LOCAL_GLOBAL_TRANSDUCER', node, 'OPEN', 'LOCAL_GLOBAL_ACTION_REQUEST',
        statement='LOCAL_RESULT_REQUIRES_GLOBAL_QUANTITATIVE_TRANSDUCTION',
        deficit_class=cls, target=target, attack_plan=plans[cls],
        requires=['COMPLETE_CONSTRUCTION::' + str(target)],
        delta_cost=[1,0,0,0], scientific_frontier=True
    )


def root_dependence_polarity_auditor(node: Node, world: Dict[str, Any]) -> AuxResult:
    p = node.payload
    root_sensitive = bool(p.get('root_sensitive') or p.get('root_dependency_polarity_receipt') or p.get('uses_root_assumption') is not None or p.get('conclusion_implies_root') is not None)
    if not root_sensitive:
        return _result('ROOT_DEPENDENCE_POLARITY_AUDITOR', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_ROOT_SENSITIVE_PROVIDER')
    fields = {
        'uses_root_assumption': p.get('uses_root_assumption'),
        'root_used_as_premise': p.get('root_used_as_premise'),
        'assumes_root_equivalent': p.get('assumes_root_equivalent'),
        'unpaid_root_equivalent_premise': p.get('unpaid_root_equivalent_premise'),
        'unpaid_root_bearing_premise': p.get('unpaid_root_bearing_premise'),
        'dependency_cycle_reaches_root': p.get('dependency_cycle_reaches_root'),
        'premise_independently_certified': p.get('premise_independently_certified'),
        'conclusion_implies_root': p.get('conclusion_implies_root'),
    }
    decisive = [fields[k] for k in ('uses_root_assumption','root_used_as_premise','assumes_root_equivalent','unpaid_root_equivalent_premise','unpaid_root_bearing_premise','dependency_cycle_reaches_root')]
    if all(v is None for v in decisive):
        return _result('ROOT_DEPENDENCE_POLARITY_AUDITOR', node, 'OPEN', 'POLARITY_OBLIGATION', statement='REQUIRE_EXPLICIT_ROOT_DEPENDENCY_POLARITY_RECEIPT', requires=['ROOT_DEPENDENCY_POLARITY_RECEIPT'])
    reject = any(v is True for v in decisive)
    # Critical correction: conclusion implies ROOT is not a rejection criterion.
    admissible = not reject
    return _result(
        'ROOT_DEPENDENCE_POLARITY_AUDITOR', node, 'PASS', 'ROOT_POLARITY_RECEIPT',
        statement='ROOT_DEPENDENCY_POLARITY_AUDITED', admissible_provider=admissible,
        rejected_for_root_assumption=reject, conclusion_implies_root=fields['conclusion_implies_root'],
        independent_provider_may_imply_root=True, truth_credit_added=0,
        fields=fields, supplies=['ROOT_POLARITY_AUDITED']
    )


def finite_scope_claim_firewall(node: Node, world: Dict[str, Any]) -> AuxResult:
    p = node.payload
    scope = str(p.get('proof_scope_kind') or p.get('scope_kind') or '').upper()
    claim_scope = str(p.get('claim_scope_kind') or p.get('target_scope_kind') or '').upper()
    if not scope and not claim_scope:
        return _result('FINITE_SCOPE_CLAIM_FIREWALL', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_SCOPE_CLAIM_TO_AUDIT')
    over = scope in {'FINITE','BOUNDED','SAMPLED','SCOPED_FINITE'} and claim_scope in {'UNIVERSAL','GLOBAL','ALL','UNBOUNDED'}
    return _result(
        'FINITE_SCOPE_CLAIM_FIREWALL', node, 'PASS', 'CLAIM_SCOPE_RECEIPT',
        statement='FINITE_SCOPE_CANNOT_PROMOTE_TO_UNIVERSAL' if over else 'CLAIM_SCOPE_COMPATIBLE',
        proof_scope_kind=scope or None, claim_scope_kind=claim_scope or None,
        scientific_promotion_allowed=not over, overpromotion_detected=over,
        supplies=['CLAIM_SCOPE_AUDITED']
    )


def route_point_grounding_auditor(node: Node, world: Dict[str, Any]) -> AuxResult:
    pts = node.payload.get('route_points')
    if not isinstance(pts, list) or not pts:
        return _result('ROUTE_POINT_GROUNDING_AUDITOR', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_ROUTE_POINTS_TO_AUDIT')
    bad=[]; internal=[]
    allowed={'DOMAIN_EXACT','DERIVED_EXACT','CARRIER_DEFINED','SOURCE_MEASUREMENT','THEOREM_DERIVED'}
    for i,p in enumerate(pts):
        if not isinstance(p,dict):
            bad.append({'index':i,'reason':'POINT_NOT_DICT'}); continue
        prov=str(p.get('coordinate_provenance_kind') or p.get('provenance_kind') or '').upper()
        role=str(p.get('coordinate_role') or '').upper()
        metric=bool(p.get('metric_authority', p.get('external_metric_authority', False)))
        if (not metric) or role in {'ORDINAL','ADMINISTRATIVE','LEDGER_COUNT','PASS_COUNT','INDEX_ONLY'} or prov in {'LEDGER_COUNT','ADMINISTRATIVE','ORDINAL_ONLY'}:
            internal.append(i)
            continue
        if metric and prov not in allowed:
            bad.append({'index':i,'reason':'METRIC_AUTHORITY_WITHOUT_GROUNDED_PROVENANCE','provenance_kind':prov})
    external_ok=(not bad and not internal)
    return _result(
        'ROUTE_POINT_GROUNDING_AUDITOR', node, 'PASS' if not bad else 'OPEN', 'ROUTE_POINT_GROUNDING_RECEIPT',
        statement='ROUTE_POINTS_EXTERNALLY_GROUNDED' if external_ok else ('ROUTE_POINTS_INTERNAL_CHART_ONLY' if not bad else 'ROUTE_POINT_GROUNDING_DEFECT'),
        point_count=len(pts), administrative_or_ordinal_indices=internal, defects=bad,
        external_metric_authority=external_ok, internal_geometry_allowed=(not bad),
        supplies=['ROUTE_POINT_GROUNDING_AUDITED']
    )


def sin2_quadrature_deriver(node: Node, world: Dict[str, Any]) -> AuxResult:
    p=node.payload
    angle=p.get('sin1_angle')
    energy=p.get('sin1_energy')
    orientation=p.get('carrier_orientation')
    if angle is None and energy is None:
        return _result('SIN2_QUADRATURE_DERIVER', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_SIN1_ANGLE_OR_ENERGY')
    if orientation not in (1,-1,'+','-','POSITIVE','NEGATIVE','CCW','CW'):
        return _result('SIN2_QUADRATURE_DERIVER', node, 'OPEN', 'ORIENTATION_OBLIGATION', statement='SIN2_QUADRATURE_NEEDS_ORIENTED_CARRIER', requires=['CARRIER_ORIENTATION'])
    sign = 1 if orientation in (1,'+','POSITIVE','CCW') else -1
    if isinstance(angle,(int,float)):
        sin2_angle=angle + sign*math.pi/2
    else:
        sin2_angle=f'({angle}) {"+" if sign>0 else "-"} pi/2' if angle is not None else None
    return _result(
        'SIN2_QUADRATURE_DERIVER', node, 'PASS', 'SIN2_QUADRATURE_RECEIPT',
        statement='SIN2_DERIVED_FROM_SIN1_BY_ORIENTED_PI_OVER_2_QUADRATURE',
        sin1_angle=angle, sin2_angle=sin2_angle, sin1_energy=energy, sin2_energy=energy,
        quadrature='PI_OVER_2', orientation_sign=sign,
        independent_second_search_required=False,
        supplies=['SIN2_DERIVED_FROM_SIN1_QUADRATURE']
    )


def dependency_readiness_auditor(node: Node, world: Dict[str, Any]) -> AuxResult:
    prereq=_list(node.payload.get('prerequisite_supplies') or node.payload.get('depends_on_supplies'))
    if not prereq:
        return _result('DEPENDENCY_READINESS_AUDITOR', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_EXPLICIT_PREREQUISITES')
    have=set(_list(node.payload.get('available_supplies')) + _list(world.get('available_supplies')))
    missing=[x for x in prereq if x not in have]
    return _result(
        'DEPENDENCY_READINESS_AUDITOR', node, 'PASS', 'DEPENDENCY_READINESS_RECEIPT',
        statement='DEPENDENCIES_READY' if not missing else 'DEPENDENCIES_NOT_YET_MATERIALIZED_KEEP_EXPLORATION_DO_NOT_PREMATURELY_CERTIFY',
        prerequisites=prereq, missing=missing, dependency_ready=not missing,
        movement_blocked=False, closure_claim_blocked=bool(missing),
        supplies=['DEPENDENCY_READINESS_AUDITED']
    )


def proof_residual_attacker(node: Node, world: Dict[str, Any]) -> AuxResult:
    residuals=node.payload.get('proof_residuals')
    if not isinstance(residuals,list) or not residuals:
        return _result('PROOF_RESIDUAL_ATTACKER', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_PROOF_RESIDUALS')
    normalized=[]
    req=[]
    for r in residuals:
        if not isinstance(r,dict):
            continue
        kind=str(r.get('kind') or 'UNPROVED_EDGE')
        edge=str(r.get('edge_id') or '')
        target=str(r.get('target') or node.payload.get('proof_target') or '')
        statement=str(r.get('statement') or '')
        rid=edge or digest({'kind':kind,'target':target,'statement':statement})[:24]
        normalized.append({'residual_id':rid,'kind':kind,'target':target,'statement':statement,'from':r.get('from')})
        req.append(f'COMPLETE_PROOF_OBJECT::{rid}')
    if not normalized:
        return _result('PROOF_RESIDUAL_ATTACKER', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_TYPED_PROOF_RESIDUALS')
    return _result(
        'PROOF_RESIDUAL_ATTACKER', node, 'OPEN', 'SCIENTIFIC_CONSTRUCTION_CURRENT',
        statement='UNPROVED_PROOF_EDGES_REINJECTED_AS_ACTIVE_CONSTRUCTION', residuals=normalized,
        requires=req, target=node.payload.get('proof_target'),
        proof_failure_is_not_refutation=True, delta_cost=[1,0,0,len(req)]
    )



def payment_remerge_auditor(node: Node, world: Dict[str, Any]) -> AuxResult:
    p=node.payload
    reqs=[normalize_requirement(x) for x in _list(p.get('requires') or p.get('open_requirements'))]
    bank=p.get('paid_requirement_receipts') or world.get('paid_requirement_receipts') or {}
    if not reqs or not bank:
        return _result('PAYMENT_REMERGE_AUDITOR', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_PAYMENT_REMERGE_CONTEXT')
    paid=[]; remaining=[]; evidence={}
    for req in reqs:
        rec=None
        if isinstance(bank,dict):
            rec=bank.get(req) or bank.get(str(req))
        elif isinstance(bank,list):
            for row in bank:
                if isinstance(row,dict) and normalize_requirement(str(row.get('requirement') or ''))==req:
                    rec=row; break
        verified=bool(isinstance(rec,dict) and (rec.get('verified') is True or rec.get('state') in {'PAID_DIRECT','PAID_BY_RETURN','PROVED','CERTIFIED'}) and (rec.get('evidence') or rec.get('digest') or rec.get('source_digest')))
        if verified:
            paid.append(req); evidence[req]=rec
        else:
            remaining.append(req)
    return _result(
        'PAYMENT_REMERGE_AUDITOR', node, 'PASS', 'REMEASURED_REQUIREMENT_LEDGER',
        statement='VERIFIED_HISTORICAL_PAYMENTS_REMERGED_BEFORE_NEW_SEARCH',
        paid_requirements=paid, remaining_requirements=remaining,
        paid_count=len(paid), remaining_count=len(remaining), evidence=evidence,
        reopen_paid_work_forbidden=True, supplies=['PAYMENT_REMERGE_AUDITED']
    )


def transitive_closure_frontier_reducer(node: Node, world: Dict[str, Any]) -> AuxResult:
    actions=node.payload.get('closure_actions') or node.payload.get('actions')
    if not isinstance(actions,list) or not actions:
        return _result('TRANSITIVE_CLOSURE_FRONTIER_REDUCER', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_TYPED_CLOSURE_ACTION_GRAPH')
    rows={}
    for a in actions:
        if not isinstance(a,dict): continue
        aid=str(a.get('action_id') or a.get('id') or '')
        if not aid: continue
        deps=[str(x) for x in _list(a.get('depends_on') or a.get('depends_on_action_ids') or a.get('prerequisites'))]
        rows[aid]={'action':a,'depends_on':[x for x in deps if x in {str(y.get('action_id') or y.get('id') or '') for y in actions if isinstance(y,dict)}]}
    if not rows:
        return _result('TRANSITIVE_CLOSURE_FRONTIER_REDUCER', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_ACTION_IDS')
    roots=sorted([aid for aid,row in rows.items() if not row['depends_on']])
    # Detect dependency cycles; a cycle cannot be silently compressed.
    visiting=set(); visited=set(); cycles=[]
    def dfs(aid,path):
        if aid in visiting:
            i=path.index(aid) if aid in path else 0
            cycles.append(path[i:]+[aid]); return
        if aid in visited: return
        visiting.add(aid)
        for d in rows.get(aid,{}).get('depends_on',[]): dfs(d,path+[aid])
        visiting.remove(aid); visited.add(aid)
    for aid in sorted(rows): dfs(aid,[])
    if cycles:
        return _result('TRANSITIVE_CLOSURE_FRONTIER_REDUCER', node, 'OPEN', 'DEPENDENCY_CYCLE_CURRENT', statement='CLOSURE_ACTION_GRAPH_HAS_DEPENDENCY_CYCLE', cycles=cycles, requires=['BREAK_DEPENDENCY_CYCLE'], delta_cost=[1,0,0,len(cycles)])
    return _result(
        'TRANSITIVE_CLOSURE_FRONTIER_REDUCER', node, 'PASS', 'TRANSITIVE_CLOSURE_FRONTIER_RECEIPT',
        statement='DOWNSTREAM_MECHANICAL_ACTIONS_REDUCED_TO_EXPLICIT_UPSTREAM_FRONTS',
        action_count=len(rows), independent_front_ids=roots, independent_front_count=len(roots),
        downstream_action_count=len(rows)-len(roots), requirements_preserved=True,
        no_downstream_action_deleted=True, supplies=['TRANSITIVE_FRONTIER_REDUCED']
    )


def resource_checkpoint_resume_compiler(node: Node, world: Dict[str, Any]) -> AuxResult:
    p=node.payload; st=str(p.get('status') or '').upper()
    is_cp=st.startswith('RESOURCE_') or node.kind in {'RESOURCE_CHECKPOINT','RESOURCE_BOUND_CURRENT'} or p.get('resource_checkpoint') is True
    if not is_cp:
        return _result('RESOURCE_CHECKPOINT_RESUME_COMPILER', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_RESOURCE_CHECKPOINT')
    target=p.get('target') or p.get('obligation') or p.get('statement') or node.identity()
    resume=p.get('resume_token') or p.get('checkpoint_id') or p.get('next_offset') or p.get('cursor') or node.identity()
    return _result(
        'RESOURCE_CHECKPOINT_RESUME_COMPILER', node, 'OPEN', 'RESUMABLE_EXECUTION_CURRENT',
        statement='RESOURCE_CUTOFF_COMPILED_TO_RESUMABLE_CURRENT_NOT_IMPOSSIBILITY',
        target=target, resume_from=resume, not_impossibility=True,
        requires=['RESUME_EXECUTION::'+str(target)], movement_blocked=False,
        delta_cost=[1,0,0,1]
    )


def sin2_continuation_rectifier(node: Node, world: Dict[str, Any]) -> AuxResult:
    p=node.payload
    sin2_context=('SIN2' in str(node.kind).upper()) or p.get('sin2_closed') is False or p.get('sin2_verified') is False
    if not sin2_context:
        return _result('SIN2_CONTINUATION_RECTIFIER', node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement='NO_UNCLOSED_SIN2_CONTEXT')
    if p.get('sin2_closed') is True or p.get('sin2_verified') is True:
        return _result('SIN2_CONTINUATION_RECTIFIER', node, 'PASS', 'SIN2_FORWARD_RECEIPT', statement='SIN2_ALREADY_CERTIFIED_FORWARD', supplies=['SIN2_CERTIFIED_FORWARD'])
    residual=p.get('scientific_residual') or p.get('residual') or p.get('first_unpaid_gate') or p.get('statement') or 'UNCLOSED_SIN2_NODE'
    return _result(
        'SIN2_CONTINUATION_RECTIFIER', node, 'OPEN', 'SCIENTIFIC_CONSTRUCTION_CURRENT',
        statement='UNCLOSED_SIN2_IMMEDIATELY_RECTIFIED_INTO_NORMAL_CHILD_CURRENT',
        residual=residual, parent_sin2_node_id=node.identity(),
        full_local_node_payload=dict(p),
        requires=['COMPLETE_CONSTRUCTION::'+str(residual)],
        waiting_state_forbidden=True, recycle_queue_forbidden=True,
        return_to_parent_required=True, delta_cost=[1,0,0,1]
    )

def scientific_novelty_guard(node: Node, world: Dict[str, Any]) -> AuxResult:
    sig=scientific_signature(node)
    seen=world.setdefault('_ac66_scientific_seen', {})
    prev=seen.get(sig)
    seen[sig]=seen.get(sig,0)+1
    return _result(
        'SCIENTIFIC_NOVELTY_GUARD', node, 'PASS', 'SCIENTIFIC_NOVELTY_RECEIPT',
        statement='NEW_SCIENTIFIC_CONTENT' if prev is None else 'SEMANTIC_CONTENT_ALREADY_SEEN_WRAPPER_OR_REPLAY',
        scientific_signature=sig, occurrence=seen[sig],
        novel=(prev is None), wrapper_replay=(prev is not None),
        supplies=['SCIENTIFIC_NOVELTY_AUDITED']
    )


def registry_fragment():
    return {
        'SOVEREIGN_ROOT_LOCK': sovereign_root_lock,
        'FULL_DELTA_COMPILER': full_delta_compiler,
        'FIRST_SOLUTION_FIELD_LOCALIZER': first_solution_field_localizer,
        'SEMANTIC_PROJECTION_COMPILER': semantic_projection_bundle,
        'CLOSURE_MODE_ACTION_COMPILER': closure_mode_action_compiler,
        'NEGATIVE_KNOWLEDGE_SKIN_MANAGER': negative_knowledge_skin_manager,
        'NONINDEPENDENT_WRAPPER_ELIMINATOR': wrapper_eliminator,
        'OPEN_STATUS_ANTI_OMISSION': open_status_anti_omission,
        'LOCAL_GLOBAL_TRANSDUCER': local_global_transducer,
        'ROOT_DEPENDENCE_POLARITY_AUDITOR': root_dependence_polarity_auditor,
        'FINITE_SCOPE_CLAIM_FIREWALL': finite_scope_claim_firewall,
        'ROUTE_POINT_GROUNDING_AUDITOR': route_point_grounding_auditor,
        'SIN2_QUADRATURE_DERIVER': sin2_quadrature_deriver,
        'DEPENDENCY_READINESS_AUDITOR': dependency_readiness_auditor,
        'PROOF_RESIDUAL_ATTACKER': proof_residual_attacker,
        'PAYMENT_REMERGE_AUDITOR': payment_remerge_auditor,
        'TRANSITIVE_CLOSURE_FRONTIER_REDUCER': transitive_closure_frontier_reducer,
        'RESOURCE_CHECKPOINT_RESUME_COMPILER': resource_checkpoint_resume_compiler,
        'SIN2_CONTINUATION_RECTIFIER': sin2_continuation_rectifier,
        'SCIENTIFIC_NOVELTY_GUARD': scientific_novelty_guard,
    }


def category_fragment():
    return {
        'SOVEREIGN_ROOT_LOCK':'SOLVER_CONTROL',
        'FULL_DELTA_COMPILER':'SOLVER_CONTROL',
        'FIRST_SOLUTION_FIELD_LOCALIZER':'SOLVER_CONTROL',
        'SEMANTIC_PROJECTION_COMPILER':'SYSTEM_FABRIC',
        'CLOSURE_MODE_ACTION_COMPILER':'SOLVER_CONTROL',
        'NEGATIVE_KNOWLEDGE_SKIN_MANAGER':'MEMORY',
        'NONINDEPENDENT_WRAPPER_ELIMINATOR':'SOLVER_CONTROL',
        'OPEN_STATUS_ANTI_OMISSION':'SOLVER_CONTROL',
        'LOCAL_GLOBAL_TRANSDUCER':'SCIENTIFIC_TRANSDUCER',
        'ROOT_DEPENDENCE_POLARITY_AUDITOR':'FORMAL_PROOF',
        'FINITE_SCOPE_CLAIM_FIREWALL':'CERTIFICATION',
        'ROUTE_POINT_GROUNDING_AUDITOR':'CAUSAL_GEOMETRY',
        'SIN2_QUADRATURE_DERIVER':'CAUSAL_GEOMETRY',
        'DEPENDENCY_READINESS_AUDITOR':'SOLVER_CONTROL',
        'PROOF_RESIDUAL_ATTACKER':'FORMAL_PROOF',
        'PAYMENT_REMERGE_AUDITOR':'SOLVER_CONTROL',
        'TRANSITIVE_CLOSURE_FRONTIER_REDUCER':'SOLVER_CONTROL',
        'RESOURCE_CHECKPOINT_RESUME_COMPILER':'SOLVER_CONTROL',
        'SIN2_CONTINUATION_RECTIFIER':'RETURN',
        'SCIENTIFIC_NOVELTY_GUARD':'SYSTEM_FABRIC',
    }
