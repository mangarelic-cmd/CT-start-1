from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
import hashlib, json
from space_gap_realizer import QuestionIdentity

class CertificationError(RuntimeError):
    pass

class ClaimKind(str, Enum):
    EXACT = 'EXACT'
    EXACT_FINITE = 'EXACT_FINITE'
    NUMERIC_CONSTRUCTION = 'NUMERIC_CONSTRUCTION'
    ATOMIC_PROOF_OBLIGATION = 'ATOMIC_PROOF_OBLIGATION'
    DERIVED_PROOF_OBLIGATION = 'DERIVED_PROOF_OBLIGATION'

class ClaimStatus(str, Enum):
    PROVED = 'PROVED'
    SUPPORTED_NUMERIC = 'SUPPORTED_NUMERIC'
    OPEN = 'OPEN'
    WAITING = 'WAITING'
    REJECTED = 'REJECTED'

class KernelStatus(str, Enum):
    PASS = 'PASS'
    OPEN = 'OPEN'
    REJECT = 'REJECT'

@dataclass(frozen=True)
class ProofReceipt:
    provider_id: str
    statement_key: str
    identity: QuestionIdentity
    proof_object_digest: str
    verifier_id: str
    verifier_status: str
    presentation_label: str = 'PROVABLE_STATEMENT'
    source_digest: Optional[str] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self):
        d = asdict(self)
        d['identity'] = asdict(self.identity)
        return d

@dataclass
class Claim:
    claim_id: str
    statement_key: str
    kind: ClaimKind
    status: ClaimStatus
    identity: Optional[QuestionIdentity] = None
    depends_on: List[str] = field(default_factory=list)
    evidence: Dict[str, Any] = field(default_factory=dict)
    receipt: Optional[ProofReceipt] = None
    presentation_label: str = 'PROVABLE_STATEMENT'

    def to_dict(self):
        d = {'claim_id': self.claim_id, 'statement_key': self.statement_key, 'kind': self.kind.value, 'status': self.status.value, 'depends_on': list(self.depends_on), 'evidence': self.evidence, 'presentation_label': self.presentation_label}
        d['identity'] = asdict(self.identity) if self.identity else None
        d['receipt'] = self.receipt.to_dict() if self.receipt else None
        return d

@dataclass
class ProofObject:
    proof_id: str
    target_statement_key: str
    claims: List[Claim]
    required_claim_ids: List[str]
    root_identity: Optional[QuestionIdentity] = None
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self):
        return {'proof_id': self.proof_id, 'target_statement_key': self.target_statement_key, 'required_claim_ids': list(self.required_claim_ids), 'root_identity': asdict(self.root_identity) if self.root_identity else None, 'claims': [c.to_dict() for c in self.claims], 'metadata': self.metadata}

@dataclass(frozen=True)
class KernelResult:
    status: KernelStatus
    open_atomic: Tuple[str, ...]
    waiting: Tuple[str, ...]
    rejected: Tuple[str, ...]
    errors: Tuple[str, ...]
    proof_digest: str

    def to_dict(self):
        return {'status': self.status.value, 'open_atomic': list(self.open_atomic), 'waiting': list(self.waiting), 'rejected': list(self.rejected), 'errors': list(self.errors), 'proof_digest': self.proof_digest}

def _canon(v: Any) -> bytes:
    return json.dumps(v, sort_keys=True, separators=(',', ':'), default=str).encode()

def proof_digest(obj: ProofObject) -> str:
    return hashlib.sha256(_canon(obj.to_dict())).hexdigest()

def same_identity(a: QuestionIdentity, b: QuestionIdentity) -> bool:
    return a == b

class CertificationKernel:
    """Fail-closed certification kernel.

    It performs no theorem search. It validates typed proof/certification objects,
    exact question identity, dependency integrity and provider receipts.
    Presentation labels (theorem/lemma/proposition/...) never identify a claim.
    """

    def _cycle(self, claims: Mapping[str, Claim]) -> Optional[List[str]]:
        visiting = set()
        done = set()
        stack = []

        def dfs(cid):
            if cid in done:
                return None
            if cid in visiting:
                i = stack.index(cid) if cid in stack else 0
                return stack[i:] + [cid]
            visiting.add(cid)
            stack.append(cid)
            for dep in claims[cid].depends_on:
                if dep in claims:
                    r = dfs(dep)
                    if r:
                        return r
            stack.pop()
            visiting.remove(cid)
            done.add(cid)
            return None
        for cid in claims:
            r = dfs(cid)
            if r:
                return r
        return None

    @staticmethod
    def _verified_exact(c: Claim) -> bool:
        v = c.evidence.get('verification') if isinstance(c.evidence, dict) else None
        return isinstance(v, dict) and v.get('status') == 'PASS' and bool(v.get('verifier_id'))

    @staticmethod
    def _receipt_valid(c: Claim) -> Tuple[bool, str]:
        r = c.receipt
        if r is None:
            return (False, 'missing receipt')
        if r.verifier_status != 'PASS':
            return (False, 'receipt verifier != PASS')
        if r.statement_key != c.statement_key:
            return (False, 'receipt statement mismatch')
        if c.identity is None:
            return (False, 'claim identity missing')
        if not same_identity(r.identity, c.identity):
            return (False, 'receipt SAME_QUESTION mismatch')
        if not r.proof_object_digest:
            return (False, 'proof object digest missing')
        if not r.verifier_id:
            return (False, 'receipt verifier id missing')
        return (True, 'PASS')

    def verify(self, obj: ProofObject) -> KernelResult:
        errors = []
        rejected = []
        open_atomic = []
        waiting = []
        ids = [c.claim_id for c in obj.claims]
        if len(ids) != len(set(ids)):
            errors.append('duplicate claim id')
        claims = {c.claim_id: c for c in obj.claims}
        for rid in obj.required_claim_ids:
            if rid not in claims:
                errors.append(f'missing required claim:{rid}')
        for c in obj.claims:
            for dep in c.depends_on:
                if dep not in claims:
                    errors.append(f'{c.claim_id}:missing dependency:{dep}')
        cyc = self._cycle(claims)
        if cyc:
            errors.append('dependency cycle:' + '->'.join(cyc))
        effective = {}
        for c in obj.claims:
            st = c.status
            if c.kind == ClaimKind.NUMERIC_CONSTRUCTION:
                if st == ClaimStatus.PROVED:
                    rejected.append(c.claim_id)
                    errors.append(f'{c.claim_id}:NUMERIC_CONSTRUCTION promoted to PROVED')
                effective[c.claim_id] = ClaimStatus.SUPPORTED_NUMERIC
                continue
            if st == ClaimStatus.PROVED:
                if c.kind in (ClaimKind.EXACT, ClaimKind.EXACT_FINITE):
                    if not self._verified_exact(c):
                        rejected.append(c.claim_id)
                        errors.append(f'{c.claim_id}:exact claim lacks verifier receipt')
                        effective[c.claim_id] = ClaimStatus.REJECTED
                    else:
                        effective[c.claim_id] = ClaimStatus.PROVED
                elif c.kind == ClaimKind.ATOMIC_PROOF_OBLIGATION:
                    ok, msg = self._receipt_valid(c)
                    if ok:
                        effective[c.claim_id] = ClaimStatus.PROVED
                    else:
                        rejected.append(c.claim_id)
                        errors.append(f'{c.claim_id}:{msg}')
                        effective[c.claim_id] = ClaimStatus.REJECTED
                elif c.kind == ClaimKind.DERIVED_PROOF_OBLIGATION:
                    d = c.evidence.get('derivation_receipt', {}) if isinstance(c.evidence, dict) else {}
                    if d.get('status') != 'PASS' or not d.get('verifier_id'):
                        rejected.append(c.claim_id)
                        errors.append(f'{c.claim_id}:derived claim lacks derivation verifier')
                        effective[c.claim_id] = ClaimStatus.REJECTED
                    else:
                        effective[c.claim_id] = ClaimStatus.PROVED
                else:
                    effective[c.claim_id] = st
            elif c.kind == ClaimKind.ATOMIC_PROOF_OBLIGATION:
                if c.receipt is not None:
                    ok, msg = self._receipt_valid(c)
                    if ok:
                        effective[c.claim_id] = ClaimStatus.PROVED
                    else:
                        rejected.append(c.claim_id)
                        errors.append(f'{c.claim_id}:{msg}')
                        effective[c.claim_id] = ClaimStatus.REJECTED
                else:
                    effective[c.claim_id] = ClaimStatus.OPEN
                    open_atomic.append(c.claim_id)
            else:
                effective[c.claim_id] = st
        for c in obj.claims:
            if c.kind == ClaimKind.DERIVED_PROOF_OBLIGATION:
                if any((effective.get(d) != ClaimStatus.PROVED for d in c.depends_on)):
                    effective[c.claim_id] = ClaimStatus.WAITING
                    if c.claim_id not in waiting:
                        waiting.append(c.claim_id)
        if errors or rejected:
            status = KernelStatus.REJECT
        else:
            incomplete = []
            for rid in obj.required_claim_ids:
                if effective.get(rid) != ClaimStatus.PROVED:
                    incomplete.append(rid)
            status = KernelStatus.PASS if not incomplete else KernelStatus.OPEN
            if status == KernelStatus.OPEN:
                for rid in incomplete:
                    c = claims[rid]
                    if c.kind == ClaimKind.ATOMIC_PROOF_OBLIGATION:
                        if rid not in open_atomic:
                            open_atomic.append(rid)
                    elif rid not in waiting:
                        waiting.append(rid)
        return KernelResult(status, tuple(sorted(set(open_atomic))), tuple(sorted(set(waiting))), tuple(sorted(set(rejected))), tuple(errors), proof_digest(obj), 0)

def receipt(provider_id: str, statement_key: str, identity: QuestionIdentity, proof_digest_value: str, verifier_id: str='CERTIFIED_PROVIDER_KERNEL', presentation_label: str='PROVABLE_STATEMENT', source_digest: Optional[str]=None, metadata: Optional[Dict[str, Any]]=None) -> ProofReceipt:
    return ProofReceipt(provider_id, statement_key, identity, proof_digest_value, verifier_id, 'PASS', presentation_label, source_digest, metadata or {})
