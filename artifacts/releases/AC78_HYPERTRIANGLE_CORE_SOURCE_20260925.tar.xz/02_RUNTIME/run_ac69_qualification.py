from __future__ import annotations
import json
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver
from causal_grid_core import compile_route, CausalGridCore

def N(**p): return Node('PROBLEM',{'statement':'AC69_QUAL','scientific_focus':True,'sovereign_root_id':'AC69_ROOT',**p},context=('AC69','QUAL'))

def main():
    checks={}
    a=compile_route({'kind':'AFFINE_SCALAR','a':2,'b':3,'c':11,'metric_weights':[3,2]})
    checks['affine_closed']=a['status']=='CLOSED' and a['proof_check'] and a['grid']['q_bounds']==['0','3/5','1']
    q=compile_route({'kind':'QUADRATIC_BRANCH','c':9})
    checks['branch_residue']=q['status']=='OPEN_TYPED' and q['cells'][0]['residue']=='BRANCH_SIGN'
    d=compile_route({'kind':'DERIVATIVE_WITH_BOUNDARY','rhs':'2*t','t0':0,'f0':3})
    checks['derivative_kernel_paid']=d['status']=='CLOSED' and d['proof_check'] and 'INTEGRATION_CONSTANT' in d['cells'][0]['residue']
    f=compile_route({'kind':'FINITE_DFT','n':4})
    checks['dft_unitary']=f['status']=='CLOSED_REPRESENTATION_BRIDGE' and f['proof_check']
    s=compile_route({'kind':'SAMPLING','n':4,'kept':[0,2]})
    checks['sampling_fail_closed']=s['status']=='OPEN_TYPED' and 'DISCARDED_COMPONENTS' in s['cells'][0]['residue']
    g=compile_route({'kind':'RIGHT_ANGLE_GATE','T':7,'S':3})
    checks['right_angle_diode']=g['proof_check'] and 'FORWARD_ONLY' in g['cells'][0]['causal_reverse']
    generic=CausalGridCore().compile_node(N(),{},0)
    checks['generic_nonblocking']=any(x.kind=='CAUSAL_GRID_TYPING_CURRENT' and x.payload.get('movement_blocked') is False for x in generic)
    run=SovereignSolver().solve_universal([N(cp016_typed_route_request=True,route_spec={'kind':'AFFINE_SCALAR','a':2,'b':3,'c':11})],max_waves=1,max_calls=1000)
    checks['core_precedes_aux']=run['world'].get('causal_grid_core_precedes_all_aux') is True
    checks['core_receipts']=run['causal_grid_core_receipt_count']>=1 and run['causal_grid_core_cell_count']>=2
    out={'schema':'AC69_CAUSAL_GRID_CORE_QUALIFICATION_V1','checks':checks,'check_count':len(checks),'pass_count':sum(bool(x) for x in checks),'pass':all(checks),'solver_summary':{'run_state':run['run_state'],'execution_calls':run['execution_calls'],'core_receipts':run['causal_grid_core_receipt_count'],'core_cells':run['causal_grid_core_cell_count'],'core_residues':run['causal_grid_core_residue_count'],'mechanisms':run['active_mechanism_count']}}
    print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__': main()
