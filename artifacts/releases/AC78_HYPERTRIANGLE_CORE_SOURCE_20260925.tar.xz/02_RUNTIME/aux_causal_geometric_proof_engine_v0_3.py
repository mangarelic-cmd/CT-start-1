"""AUX Causal Geometric Proof Engine v0.3

Purpose
=======
Turn the full 246-space / 479-time catalogue into an exact calculational proof
chart.  A route is not blocked while it is still unproved: exact symbolic
geometry is calculated first, while semantic/provenance obligations are carried
separately and can later be discharged by the solver / ZFC layer.

Core design
===========
* semantic address: one scientific space id + one scientific time id;
* local proof chart: exact coordinates (x,t) in a declared chart;
* NATIVE frame uses (x,t);
* DUAL frame after time/space inversion uses J(x,t)=(t,x);
* TWIST is the membrane point and exposes both frames without double-counting;
* each adjacent pair is resolved as a right-triangle receipt using exact SymPy
  arithmetic (Pythagore + trig ratios);
* catalogue-containment receipts are checked independently from the geometry;
* calculation may be EXACT_SYMBOLIC even when proof status remains OPEN.

This module does not treat catalogue indices as metric distances.  Metric/chart
coordinates must be supplied or derived by an upstream solver/theorem.  This is
what prevents a false numerical precision while still allowing exact symbolic
calculation.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Iterable
import json
import sympy as sp
from aux_full_causal_coordinate_atlas_v0_2 import FullCausalCoordinateAtlas

class GeometricProofError(ValueError):
    pass
ORIENTATIONS = {'NATIVE', 'TWIST', 'DUAL'}
PROVENANCE_STATES = {'CERTIFIED', 'OPEN', 'ASSUMED'}

def _expr(v: Any) -> sp.Expr:
    """Parse an exact expression. Python floats are intentionally rejected."""
    if isinstance(v, float):
        raise GeometricProofError('FLOAT_COORDINATE_FORBIDDEN_USE_EXACT_STRING_OR_RATIONAL')
    if isinstance(v, sp.Expr):
        return v
    if isinstance(v, int):
        return sp.Integer(v)
    if isinstance(v, str):
        return sp.sympify(v, evaluate=True)
    if isinstance(v, tuple) and len(v) == 2:
        return sp.Rational(v[0], v[1])
    raise GeometricProofError(f'UNSUPPORTED_EXACT_EXPRESSION::{type(v).__name__}')

def _s(e: sp.Expr) -> str:
    return sp.sstr(sp.simplify(e))

def _is_exact_expr(e: sp.Expr) -> bool:
    return not bool(e.atoms(sp.Float))

@dataclass(frozen=True)
class CausalChartPoint:
    point_id: str
    space_id: str
    time_id: str
    orientation: str
    x: Any
    t: Any
    coordinate_provenance: str = 'OPEN'
    chart_id: str = 'LOCAL_PYTHAGOREAN_PROOF_CHART'
    gx: Any = 1
    gt: Any = 1

    def parsed(self) -> 'ParsedPoint':
        if self.orientation not in ORIENTATIONS:
            raise GeometricProofError('ORIENTATION_MUST_BE_NATIVE_TWIST_OR_DUAL')
        if self.coordinate_provenance not in PROVENANCE_STATES:
            raise GeometricProofError('BAD_COORDINATE_PROVENANCE_STATE')
        gx, gt = (_expr(self.gx), _expr(self.gt))
        if gx.is_number and gx <= 0:
            raise GeometricProofError('GX_MUST_BE_POSITIVE')
        if gt.is_number and gt <= 0:
            raise GeometricProofError('GT_MUST_BE_POSITIVE')
        return ParsedPoint(point_id=self.point_id, space_id=self.space_id, time_id=self.time_id, orientation=self.orientation, x=_expr(self.x), t=_expr(self.t), coordinate_provenance=self.coordinate_provenance, chart_id=self.chart_id, gx=gx, gt=gt)

@dataclass(frozen=True)
class ParsedPoint:
    point_id: str
    space_id: str
    time_id: str
    orientation: str
    x: sp.Expr
    t: sp.Expr
    coordinate_provenance: str
    chart_id: str
    gx: sp.Expr
    gt: sp.Expr

    def frame(self, frame: str) -> tuple[sp.Expr, sp.Expr, sp.Expr, sp.Expr]:
        """Return (space_coord,time_coord,space_weight,time_weight)."""
        if frame == 'NATIVE':
            return (self.x, self.t, self.gx, self.gt)
        if frame == 'DUAL':
            return (self.t, self.x, self.gt, self.gx)
        raise GeometricProofError('FRAME_MUST_BE_NATIVE_OR_DUAL')

    def semantic_address(self) -> dict[str, Any]:
        if self.orientation == 'NATIVE':
            active = {'space': self.space_id, 'time': self.time_id}
        elif self.orientation == 'DUAL':
            active = {'space': f'SIGMA::{self.time_id}', 'time': f'TAU::{self.space_id}'}
        else:
            active = {'native': {'space': self.space_id, 'time': self.time_id}, 'dual': {'space': f'SIGMA::{self.time_id}', 'time': f'TAU::{self.space_id}'}}
        return {'point_id': self.point_id, 'orientation': self.orientation, 'native_space_id': self.space_id, 'native_time_id': self.time_id, 'active_address': active, 'chart_id': self.chart_id, 'native_chart_coordinate': {'x': _s(self.x), 't': _s(self.t)}, 'dual_chart_coordinate': {'x': _s(self.t), 't': _s(self.x)}, 'metric_native': {'gx': _s(self.gx), 'gt': _s(self.gt)}, 'coordinate_provenance': self.coordinate_provenance}

class CausalGeometricProofEngine:

    def __init__(self, atlas: FullCausalCoordinateAtlas):
        self.atlas = atlas

    def validate_point(self, p: ParsedPoint) -> None:
        if p.space_id not in self.atlas.space_index:
            raise GeometricProofError(f'UNKNOWN_SPACE_ID::{p.space_id}')
        if p.time_id not in self.atlas.time_index:
            raise GeometricProofError(f'UNKNOWN_TIME_ID::{p.time_id}')

    @staticmethod
    def _segment_frame(a: ParsedPoint, b: ParsedPoint) -> str:
        pair = (a.orientation, b.orientation)
        if pair in {('NATIVE', 'NATIVE'), ('NATIVE', 'TWIST'), ('TWIST', 'NATIVE')}:
            return 'NATIVE'
        if pair in {('TWIST', 'DUAL'), ('DUAL', 'DUAL'), ('DUAL', 'TWIST')}:
            return 'DUAL'
        if pair == ('TWIST', 'TWIST'):
            raise GeometricProofError('TWIST_TO_TWIST_REQUIRES_EXPLICIT_FRAME_CHOICE')
        raise GeometricProofError('EXPLICIT_TWIST_POINT_REQUIRED_BETWEEN_NATIVE_AND_DUAL')

    def semantic_transition_receipt(self, a: ParsedPoint, b: ParsedPoint, frame: str) -> dict[str, Any]:
        space_receipt = self.atlas.containment_receipt(a.space_id, b.space_id, 'SPACE') if a.space_id != b.space_id else {'domain': 'SPACE', 'child': a.space_id, 'container': b.space_id, 'valid': True, 'distance': 0, 'path': [a.space_id]}
        time_receipt = self.atlas.containment_receipt(a.time_id, b.time_id, 'TIME') if a.time_id != b.time_id else {'domain': 'TIME', 'child': a.time_id, 'container': b.time_id, 'valid': True, 'distance': 0, 'path': [a.time_id]}
        if frame == 'NATIVE':
            axis_interpretation = {'space_axis': 'NATIVE_SPACE_CONTAINMENT', 'time_axis': 'NATIVE_TIME_CONTAINMENT'}
        else:
            axis_interpretation = {'space_axis': 'SPATIALIZED_NATIVE_TIME_CONTAINMENT', 'time_axis': 'TEMPORALIZED_NATIVE_SPACE_CONTAINMENT'}
        return {'frame': frame, 'axis_interpretation': axis_interpretation, 'native_space_containment': space_receipt, 'native_time_containment': time_receipt, 'pass': bool(space_receipt['valid'] and time_receipt['valid'])}

    def segment(self, a0: CausalChartPoint | ParsedPoint, b0: CausalChartPoint | ParsedPoint) -> dict[str, Any]:
        a = a0.parsed() if isinstance(a0, CausalChartPoint) else a0
        b = b0.parsed() if isinstance(b0, CausalChartPoint) else b0
        self.validate_point(a)
        self.validate_point(b)
        if a.chart_id != b.chart_id:
            raise GeometricProofError('SEGMENT_POINTS_MUST_SHARE_DECLARED_CHART')
        frame = self._segment_frame(a, b)
        ax, at, agx, agt = a.frame(frame)
        bx, bt, bgx, bgt = b.frame(frame)
        if sp.simplify(agx - bgx) != 0 or sp.simplify(agt - bgt) != 0:
            raise GeometricProofError('LOCAL_METRIC_CHANGED_WITHIN_SEGMENT_SPLIT_ROUTE_AT_METRIC_BOUNDARY')
        gx, gt = (agx, agt)
        dx, dt = (sp.simplify(bx - ax), sp.simplify(bt - at))
        sx2 = sp.simplify(gx * dx ** 2)
        st2 = sp.simplify(gt * dt ** 2)
        d2 = sp.simplify(sx2 + st2)
        sx = sp.sqrt(sx2)
        st = sp.sqrt(st2)
        d = sp.sqrt(d2)
        pyth_residual = sp.simplify(d2 - sx2 - st2)
        if sp.simplify(d) == 0:
            sinv = cosv = tanv = None
            trig_residual = None
            angle = None
        else:
            sinv = sp.simplify(sx / d)
            cosv = sp.simplify(st / d)
            tanv = None if sp.simplify(st) == 0 else sp.simplify(sx / st)
            trig_residual = sp.simplify(sinv ** 2 + cosv ** 2 - 1)
            angle = sp.atan2(sx, st)
        semantic = self.semantic_transition_receipt(a, b, frame)
        exact_symbolic = all((_is_exact_expr(z) for z in (ax, at, bx, bt, gx, gt, dx, dt, sx2, st2, d2)))
        geometry_identity_pass = pyth_residual == 0 and trig_residual in {None, 0}
        provenance_certified = a.coordinate_provenance == 'CERTIFIED' and b.coordinate_provenance == 'CERTIFIED'
        return {'schema': 'CT_CAUSAL_RIGHT_TRIANGLE_SEGMENT_V0_3', 'from': a.point_id, 'to': b.point_id, 'frame': frame, 'from_active_coordinate': {'x': _s(ax), 't': _s(at)}, 'to_active_coordinate': {'x': _s(bx), 't': _s(bt)}, 'delta': {'space': _s(dx), 'time': _s(dt)}, 'metric': {'space_weight': _s(gx), 'time_weight': _s(gt)}, 'legs': {'space_squared': _s(sx2), 'time_squared': _s(st2), 'space_length': _s(sx), 'time_length': _s(st)}, 'diagonal': {'squared': _s(d2), 'length': _s(d)}, 'trigonometry': {'sin': None if sinv is None else _s(sinv), 'cos': None if cosv is None else _s(cosv), 'tan': None if tanv is None else _s(tanv), 'angle': None if angle is None else _s(angle)}, 'identity_receipts': {'pythagorean_residual': _s(pyth_residual), 'pythagorean_pass': pyth_residual == 0, 'trig_normalization_residual': None if trig_residual is None else _s(trig_residual), 'trig_normalization_pass': trig_residual in {None, 0}}, 'semantic_transition': semantic, 'calculation_status': 'EXACT_SYMBOLIC' if exact_symbolic else 'NONEXACT_NUMERIC_PRESENT', 'coordinate_provenance_certified': provenance_certified, 'proof_status': 'CERTIFIED' if exact_symbolic and geometry_identity_pass and semantic['pass'] and provenance_certified else 'OPEN'}

    @staticmethod
    def _segment_values(seg: dict[str, Any]) -> tuple[sp.Expr, sp.Expr, sp.Expr]:
        return (_expr(seg['delta']['space']), _expr(seg['delta']['time']), _expr(seg['diagonal']['length']))

    def route(self, points0: Iterable[CausalChartPoint | ParsedPoint]) -> dict[str, Any]:
        points = [p.parsed() if isinstance(p, CausalChartPoint) else p for p in points0]
        if len(points) < 2:
            raise GeometricProofError('ROUTE_REQUIRES_AT_LEAST_TWO_POINTS')
        for p in points:
            self.validate_point(p)
        twist_idx = [i for i, p in enumerate(points) if p.orientation == 'TWIST']
        if len(twist_idx) != 1:
            raise GeometricProofError('ROUTE_REQUIRES_EXACTLY_ONE_EXPLICIT_TWIST_POINT')
        k = twist_idx[0]
        if k == 0 or k == len(points) - 1:
            raise GeometricProofError('TWIST_POINT_MUST_HAVE_PRE_AND_POST_SEGMENTS')
        if any((p.orientation != 'NATIVE' for p in points[:k])):
            raise GeometricProofError('ALL_POINTS_BEFORE_TWIST_MUST_BE_NATIVE')
        if any((p.orientation != 'DUAL' for p in points[k + 1:])):
            raise GeometricProofError('ALL_POINTS_AFTER_TWIST_MUST_BE_DUAL')
        segs = [self.segment(points[i], points[i + 1]) for i in range(len(points) - 1)]
        lengths = [_expr(s['diagonal']['length']) for s in segs]
        route_length = sp.simplify(sum(lengths, sp.Integer(0)))
        pre = segs[k - 1]
        post = segs[k]
        pre_dx, pre_dt, pre_d = self._segment_values(pre)
        post_dx, post_dt, post_d = self._segment_values(post)
        twist_receipt = {'junction_point': points[k].point_id, 'J_formula': 'J(x,t)=(t,x)', 'J_squared_identity': True, 'pre_space_equals_post_time': sp.simplify(abs(pre_dx) - abs(post_dt)) == 0, 'pre_time_equals_post_space': sp.simplify(abs(pre_dt) - abs(post_dx)) == 0, 'diagonal_isometry': sp.simplify(pre_d - post_d) == 0}
        twist_receipt['pass'] = all((v for key, v in twist_receipt.items() if isinstance(v, bool)))
        calculations_exact = all((s['calculation_status'] == 'EXACT_SYMBOLIC' for s in segs))
        geometric_identities = all((s['identity_receipts']['pythagorean_pass'] and s['identity_receipts']['trig_normalization_pass'] for s in segs))
        semantics = all((s['semantic_transition']['pass'] for s in segs))
        provenance = all((p.coordinate_provenance == 'CERTIFIED' for p in points))
        zfc_obligations = []
        for i, s in enumerate(segs):
            zfc_obligations.extend([{'id': f'SEGMENT_{i}_PYTHAGORE', 'formula': f"({s['diagonal']['squared']}) = ({s['legs']['space_squared']}) + ({s['legs']['time_squared']})", 'discharged_by_exact_arithmetic': s['identity_receipts']['pythagorean_pass']}, {'id': f'SEGMENT_{i}_SPACE_CONTAINMENT_OR_IDENTITY', 'formula': f'{points[i].space_id} <= {points[i + 1].space_id}', 'discharged_by_catalog': s['semantic_transition']['native_space_containment']['valid']}, {'id': f'SEGMENT_{i}_TIME_CONTAINMENT_OR_IDENTITY', 'formula': f'{points[i].time_id} <= {points[i + 1].time_id}', 'discharged_by_catalog': s['semantic_transition']['native_time_containment']['valid']}])
        zfc_obligations.extend([{'id': 'TWIST_INVOLUTION', 'formula': 'J(J(x,t))=(x,t)', 'discharged_by_definition': True}, {'id': 'TWIST_ISOMETRY_LOCAL', 'formula': 'd_pre=d_post at paired membrane cells', 'discharged_by_exact_arithmetic': twist_receipt['diagonal_isometry']}])
        return {'schema': 'CT_CAUSAL_GEOMETRIC_ROUTE_V0_3', 'atlas_digest': self.atlas.atlas_digest, 'space_catalog_count': len(self.atlas.space_ids), 'time_catalog_count': len(self.atlas.time_ids), 'points': [p.semantic_address() for p in points], 'segments': segs, 'twist': twist_receipt, 'route_length': _s(route_length), 'calculation_status': 'EXACT_SYMBOLIC' if calculations_exact else 'MIXED', 'proof_components': {'all_pythagorean_and_trig_identities': geometric_identities, 'all_semantic_transitions_catalog_valid': semantics, 'all_coordinate_provenance_certified': provenance, 'twist_invariants': twist_receipt['pass']}, 'proof_ready': bool(calculations_exact and geometric_identities and semantics and provenance and twist_receipt['pass']), 'zfc_style_finite_obligations': zfc_obligations, 'claim_ceiling': 'EXACT_GEOMETRIC_AND_CATALOG_ROUTE_RELATIVE_TO_DECLARED_CHART_AND_CATALOG_RELATIONS'}

    def symbolic_segment_without_certification(self, a: CausalChartPoint, b: CausalChartPoint) -> dict[str, Any]:
        """Explicit direct path: calculate exact formulas even with OPEN provenance."""
        return self.segment(a, b)

def build_reference_multispace_multitime_route(atlas: FullCausalCoordinateAtlas) -> dict[str, Any]:
    """Reference qualification route using real catalogue ids.

    Geometry is a four-cell 3-4-5 construction.  Before the membrane the local
    legs are (3,4); after J they are (4,3).  Semantic transitions are actual
    catalogue containments or identity transitions.
    """
    eng = CausalGeometricProofEngine(atlas)
    pts = [CausalChartPoint('Q0_PROBLEM', 'RIGGED_TEST_SPACE_PHI', 'INSTANT_TIME_POINT_T0', 'NATIVE', 0, 0, 'CERTIFIED'), CausalChartPoint('Q1_RESPONSE_A', 'ESPACE_DE_HILBERT', 'FINITE_CLOSED_TIME_INTERVAL_A_B', 'NATIVE', 3, 4, 'CERTIFIED'), CausalChartPoint('Q2_MEMBRANE', 'ESPACE_DE_HILBERT', 'REAL_TIME_AXIS_R', 'TWIST', 6, 8, 'CERTIFIED'), CausalChartPoint('Q3_POST_TWIST', 'ESPACE_DE_HILBERT', 'EXTENDED_REAL_TIME_AXIS_INFINITY_INFINITY', 'DUAL', 9, 12, 'CERTIFIED'), CausalChartPoint('Q4_SOLUTION', 'ESPACE_DE_FOCK', 'EXTENDED_REAL_TIME_AXIS_INFINITY_INFINITY', 'DUAL', 12, 16, 'CERTIFIED')]
    return eng.route(pts)

def build_symbolic_open_demo(atlas: FullCausalCoordinateAtlas) -> dict[str, Any]:
    """Shows that lack of certification does not block exact calculation."""
    eng = CausalGeometricProofEngine(atlas)
    a = CausalChartPoint('SYM_A', 'RIGGED_TEST_SPACE_PHI', 'INSTANT_TIME_POINT_T0', 'NATIVE', 'x_0', 't_0', 'OPEN')
    b = CausalChartPoint('SYM_B', 'ESPACE_DE_HILBERT', 'FINITE_CLOSED_TIME_INTERVAL_A_B', 'NATIVE', 'x_1', 't_1', 'OPEN')
    return eng.symbolic_segment_without_certification(a, b)
if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    atlas = FullCausalCoordinateAtlas(root / 'scientific_space_containment_candidate_v3.json', root / 'scientific_temporal_catalog_v1.json')
    out = {'reference_route': build_reference_multispace_multitime_route(atlas), 'symbolic_open_demo': build_symbolic_open_demo(atlas)}
    print(json.dumps(out, ensure_ascii=False, indent=2))
