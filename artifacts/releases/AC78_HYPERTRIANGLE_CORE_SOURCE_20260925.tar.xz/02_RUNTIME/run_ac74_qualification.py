from __future__ import annotations
import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'02_RUNTIME'))

from causal_cartesian_plane_aux import SemanticType, TemporalStamp, MetricPoint, RealizationKey, CertifiedRealization
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver


def sem(name):
    return SemanticType('AC74_QUAL_AUTH','TRANSFORM','L2_FINITE','UNITARY_PLATE',name)


def make_real(name, carrier, metric_sig, t, s, receipt):
    se=sem(name)
    k=RealizationKey(se.type_id,carrier,metric_sig,TemporalStamp('E1','P1','A1'),'+','V1')
    return CertifiedRealization(se,k,MetricPoint.make(t,s,True,receipt),'RHO','SWAP_TS','PROV::'+name+'::'+carrier,True)


def payload(r):
    return {
        'semantic': {
            'authority_id':r.semantic.authority_id,'family':r.semantic.family,'domain':r.semantic.domain,
            'plate_contract':r.semantic.plate_contract,'canonical_name':r.semantic.canonical_name,
        },
        'key': {
            'type_id':r.key.type_id,'carrier_id':r.key.carrier_id,'metric_signature':r.key.metric_signature,
            'temporal': {'epoch':r.key.temporal.epoch,'phase':r.key.temporal.phase,'ancestry_digest':r.key.temporal.ancestry_digest},
            'orientation':r.key.orientation,'authority_version':r.key.authority_version,
        },
        'metric': {'t':str(r.metric.t),'s':str(r.metric.s),'orthogonal':True,'metric_receipt_id':r.metric.metric_receipt_id},
        'residual_schema':r.residual_schema,'mirror_policy':r.mirror_policy,'provenance_digest':r.provenance_digest,'certified':True,
    }


def lookup(r, carrier=None, metric_sig=None, epoch='E1'):
    return {
        'action':'LOOKUP',
        'semantic': {
            'authority_id':r.semantic.authority_id,'family':r.semantic.family,'domain':r.semantic.domain,
            'plate_contract':r.semantic.plate_contract,'canonical_name':r.semantic.canonical_name,
        },
        'key': {
            'carrier_id':carrier or r.key.carrier_id,'metric_signature':metric_sig or r.key.metric_signature,
            'temporal': {'epoch':epoch,'phase':'P1','ancestry_digest':'A1'},
            'orientation':'+','authority_version':'V1',
        }
    }


def main():
    f=make_real('FOURIER','H1','G1','3','4','M1')
    l=make_real('LAPLACE','H2','G2','5','12','M2')
    seeds=[
        Node('PROBLEM',{
            'statement':'register AC74 certified realizations','cake':'objects','plate':'library','operator':'REGISTER',
            'canonical_coordinate_library_requests':[
                {'action':'REGISTER_REALIZATION','realization':payload(f)},
                {'action':'REGISTER_REALIZATION','realization':payload(l)},
                {'action':'REGISTER_BRIDGE','bridge':{
                    'source_carrier':'H1','target_carrier':'H1_DUAL','source_metric_signature':'G1','target_metric_signature':'G1D',
                    'matrix':[['0','1'],['1','0']],'bridge_receipt_id':'BRIDGE::DUAL','isometry_certified':True}},
            ]
        }, context=('AC74','register')),
        Node('PROBLEM',{
            'statement':'lookup AC74 exact project recalc','cake':'lookup','plate':'library','operator':'LOOKUP',
            'canonical_coordinate_library_requests':[
                lookup(f),
                lookup(f,carrier='H1_DUAL',metric_sig='G1D'),
                lookup(f,carrier='NO_BRIDGE',metric_sig='G9'),
                lookup(f,epoch='E2'),
            ]
        }, context=('AC74','lookup')),
        Node('PROBLEM',{
            'statement':'problem local active grids and mirror','cake':'route','plate':'grid','operator':'BUILD',
            'canonical_coordinate_library_requests':[
                {'action':'BUILD_ACTIVE_GRID','problem_id':'Q-A','ordered_occurrences':[
                    {'occurrence_id':'F1','realization_id':f.realization_id,'rank_address':471},
                    {'occurrence_id':'L1','realization_id':l.realization_id,'rank_address':3},
                ]},
                {'action':'MIRROR_ACTIVE_GRID','problem_id':'Q-A'},
                {'action':'BUILD_ACTIVE_GRID','problem_id':'Q-B','ordered_occurrences':[
                    {'occurrence_id':'F2','realization_id':f.realization_id,'rank_address':999999},
                ]},
                {'action':'BUILD_ACTIVE_GRID','problem_id':'Q-C','ordered_occurrences':[
                    {'occurrence_id':'F3','realization_id':f.realization_id,'rank_address':1},
                ]},
                {'action':'SEMANTIC_TRANSPARENCY','direct_problem_id':'Q-B','cached_problem_id':'Q-C'},
                {'action':'SNAPSHOT'},
            ]
        }, context=('AC74','grid')),
    ]
    solver=SovereignSolver()
    result=solver.solve_universal(seeds,max_waves=1,max_calls=5000)
    known=list(solver.engine.known.values())
    coord=[n for n in known if n.kind=='CAUSAL_GRID_COORDINATE_LIBRARY_RECEIPT']
    grids=[n for n in known if n.kind=='CAUSAL_GRID_ACTIVE_GRID_RECEIPT']
    lookup_statuses=[]
    for n in coord:
        cr=n.payload.get('coordinate_receipt') or {}
        if cr.get('lookup_status'): lookup_statuses.append(cr.get('lookup_status'))
    grid_actions=[(n.payload.get('coordinate_receipt') or {}).get('action') for n in grids]
    counters=result.get('causal_grid_cp026_counters') or {}
    out={
        'schema':'AC74_QUALIFICATION_V1',
        'seed_count':len(seeds),
        'coordinate_receipt_count':len(coord),
        'active_grid_receipt_count':len(grids),
        'lookup_statuses':lookup_statuses,
        'grid_actions':grid_actions,
        'cp026_counters':counters,
        'active_mechanism_count':result.get('active_mechanism_count'),
        'execution_calls':result.get('execution_calls'),
        'run_state':result.get('run_state'),
        'world_profile_active':bool((result.get('world') or {}).get('causal_grid_cp026_canonical_coordinate_library')),
        'pass': (
            len(coord) >= 8 and len(grids) >= 5 and
            'EXACT_HIT' in lookup_statuses and 'PROJECTABLE' in lookup_statuses and
            lookup_statuses.count('RECALCULATE') >= 2 and
            counters.get('active_grids',0) >= 3 and counters.get('mirror_grids',0) >= 1 and
            result.get('active_mechanism_count') == 99 and
            bool((result.get('world') or {}).get('causal_grid_metric_borges_transport_firewall'))
        )
    }
    print(json.dumps(out,indent=2,ensure_ascii=False))

if __name__=='__main__': main()
