from __future__ import annotations
import json
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver
from causal_grid_core import CausalGridCore

def N(**p):
    return Node('PROBLEM',{'statement':'AC70_QUAL','scientific_focus':True,'sovereign_root_id':'AC70_ROOT',**p},context=('AC70','QUAL'))

def diag_for(**p):
    side=CausalGridCore().compile_node(N(**p),{},0)
    rec=next(x for x in side if x.kind=='CAUSAL_GRID_CORE_RECEIPT')
    return rec.payload['core_diagnosis']

def main():
    checks={}
    a=diag_for(equation='2*x+3=11',variable='x')
    checks['auto_affine']=a['status']=='CLOSED' and a['route_inference']['status']=='AUTO_EXTRACTED' and a['kind']=='AFFINE_SCALAR'
    q=diag_for(equation='x**2-5*x+6=0',variable='x')
    checks['auto_quadratic']=q['status']=='CLOSED_MULTI_SOLUTION' and q['kind']=='GENERAL_QUADRATIC' and q['proof_check']
    r=diag_for(equation='(x+1)/(x-2)=3',variable='x')
    checks['auto_rational']=r['status']=='CLOSED' and r['kind']=='RATIONAL_SCALAR' and r['proof_check']
    e=diag_for(equation='2**x=8',variable='x')
    checks['auto_exponential']=e['status']=='CLOSED' and e['kind']=='EXPONENTIAL_SCALAR' and e['proof_check']
    s0=diag_for(equation='sin(x)=0',variable='x')
    checks['auto_periodic_sine_zero']=s0['status']=='CLOSED_INFINITE_SOLUTION_SET' and s0['kind']=='TRIG_PERIODIC_ZERO'
    u=diag_for(equation='cos(x)+x**2=0',variable='x')
    checks['unsupported_fail_closed']=u['status']=='OPEN_TYPED' and 'ROUTE_FAMILY_CLASSIFICATION' in u.get('route_extraction_requires',[])
    run=SovereignSolver().solve_universal([N(equation='2*x+3=11',variable='x')],max_waves=1,max_calls=1000)
    checks['core_precedes_all_aux']=run['world'].get('causal_grid_core_precedes_all_aux') is True
    checks['auto_route_world_flag']=run['world'].get('causal_grid_auto_route_extraction') is True
    checks['auto_extracted_count']=run.get('causal_grid_auto_extracted_count',0)>=1
    checks['mechanisms_preserved']=run['active_mechanism_count']==99
    out={'schema':'AC70_CAUSAL_GRID_AUTOROUTE_QUALIFICATION_V1','checks':checks,'check_count':len(checks),'pass_count':sum(bool(v) for v in checks.values()),'pass':all(checks.values()),'solver_summary':{'run_state':run['run_state'],'execution_calls':run['execution_calls'],'auto_extracted':run.get('causal_grid_auto_extracted_count'),'auto_unresolved':run.get('causal_grid_auto_unresolved_count'),'mechanisms':run['active_mechanism_count']}}
    print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__': main()
