from __future__ import annotations
from dataclasses import dataclass, field, asdict
from enum import Enum
from typing import Any, Dict, Hashable, Iterable, Mapping, Optional, Sequence, Tuple
import hashlib, json

class CellRole(str, Enum):
    RESIDUAL_CONTOUR = 'RESIDUAL_CONTOUR'
    DUAL_SOLUTION_CLOSURE = 'DUAL_SOLUTION_CLOSURE'

class Orientation(str, Enum):
    AB = 'AB'
    BA = 'BA'

class Route(str, Enum):
    SIN1 = 'SIN1'
    SIN2 = 'SIN2'

class Position(str, Enum):
    FIRST = 'FIRST'
    SECOND = 'SECOND'

@dataclass(frozen=True)
class EdgeStep:
    edge_id: str
    route: Route
    position: Position
    segment: str
    source: Hashable
    target: Hashable
    witnesses: Tuple[Hashable, ...] = ()
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d['route'] = self.route.value
        d['position'] = self.position.value
        d['witnesses'] = list(self.witnesses)
        return d

@dataclass(frozen=True)
class DiagonalStep:
    source: Hashable
    target: Hashable
    diagonal_id: str = 'COS'
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self):
        return asdict(self)

@dataclass(frozen=True)
class CausalCell:
    cell_id: str
    role: CellRole
    orientation: Orientation
    start: Hashable
    sin1_mid: Hashable
    sin2_mid: Hashable
    end: Hashable
    sin1_first: EdgeStep
    sin1_second: EdgeStep
    sin2_first: EdgeStep
    sin2_second: EdgeStep
    cos: DiagonalStep
    cross_witness_pairs_1: Tuple[Tuple[Hashable, Hashable], ...] = ()
    cross_witness_pairs_2: Tuple[Tuple[Hashable, Hashable], ...] = ()
    metadata: Dict[str, Any] = field(default_factory=dict)

    def to_dict(self):
        return {'cell_id': self.cell_id, 'role': self.role.value, 'orientation': self.orientation.value, 'start': self.start, 'sin1_mid': self.sin1_mid, 'sin2_mid': self.sin2_mid, 'end': self.end, 'sin1_first': self.sin1_first.to_dict(), 'sin1_second': self.sin1_second.to_dict(), 'sin2_first': self.sin2_first.to_dict(), 'sin2_second': self.sin2_second.to_dict(), 'cos': self.cos.to_dict(), 'cross_witness_pairs_1': [list(x) for x in self.cross_witness_pairs_1], 'cross_witness_pairs_2': [list(x) for x in self.cross_witness_pairs_2], 'metadata': self.metadata}

@dataclass(frozen=True)
class CellReceipt:
    valid: bool
    cell_id: str
    role: str
    orientation: str
    continuity: bool
    route_end_agreement: bool
    cos_diagonal_matches: bool
    segment_order_valid: bool
    cross_role_twist_valid: bool
    witness_triangulation: str
    errors: Tuple[str, ...]
    cell_digest: str

    def to_dict(self):
        return asdict(self)

@dataclass(frozen=True)
class DualPassReceipt:
    valid: bool
    first_cell_id: str
    second_cell_id: str
    problem: Hashable
    residual: Hashable
    solution: Hashable
    first_orientation: str
    second_orientation: str
    first_role: str
    second_role: str
    exact_junction: bool
    coordinate_twist_squared_identity: bool
    process_two_pass_solution_closure: bool
    same_orientation_repeat_rejected: bool
    errors: Tuple[str, ...]
    digest: str

    def to_dict(self):
        return asdict(self)

def _canon(x: Any) -> bytes:
    return json.dumps(x, sort_keys=True, separators=(',', ':'), default=str).encode()

def _digest(x: Any) -> str:
    return hashlib.sha256(_canon(x)).hexdigest()

def _expected_segments(o: Orientation) -> Tuple[str, str]:
    return ('a', 'b') if o == Orientation.AB else ('b', 'a')

def cross_role_twist(label: Tuple[Route, Position]) -> Tuple[Route, Position]:
    r, p = label
    if r == Route.SIN1 and p == Position.FIRST:
        return (Route.SIN2, Position.SECOND)
    if r == Route.SIN1 and p == Position.SECOND:
        return (Route.SIN2, Position.FIRST)
    if r == Route.SIN2 and p == Position.FIRST:
        return (Route.SIN1, Position.SECOND)
    if r == Route.SIN2 and p == Position.SECOND:
        return (Route.SIN1, Position.FIRST)
    raise ValueError(label)

def coordinate_twist_squared_identity() -> bool:
    labels = [(r, p) for r in Route for p in Position]
    return all((cross_role_twist(cross_role_twist(x)) == x for x in labels))

def _bijective_pairing(left: Sequence[Hashable], right: Sequence[Hashable], pairs: Sequence[Tuple[Hashable, Hashable]]) -> str:
    if not left and (not right) and (not pairs):
        return 'NOT_MATERIALIZED'
    if len(left) != len(right) or len(pairs) != len(left):
        return 'FAIL'
    if len(set(left)) != len(left) or len(set(right)) != len(right):
        return 'FAIL'
    lp = [a for a, _ in pairs]
    rp = [b for _, b in pairs]
    if len(set(lp)) != len(lp) or len(set(rp)) != len(rp):
        return 'FAIL'
    return 'PASS' if set(lp) == set(left) and set(rp) == set(right) else 'FAIL'

def verify_cell(cell: CausalCell) -> CellReceipt:
    errors = []
    edges = [cell.sin1_first, cell.sin1_second, cell.sin2_first, cell.sin2_second]
    expected_labels = [(Route.SIN1, Position.FIRST), (Route.SIN1, Position.SECOND), (Route.SIN2, Position.FIRST), (Route.SIN2, Position.SECOND)]
    for e, (r, p) in zip(edges, expected_labels):
        if e.route != r or e.position != p:
            errors.append(f'{e.edge_id}:ROLE_POSITION_MISMATCH')
    continuity = cell.sin1_first.source == cell.start and cell.sin1_first.target == cell.sin1_mid and (cell.sin1_second.source == cell.sin1_mid) and (cell.sin1_second.target == cell.end) and (cell.sin2_first.source == cell.start) and (cell.sin2_first.target == cell.sin2_mid) and (cell.sin2_second.source == cell.sin2_mid) and (cell.sin2_second.target == cell.end)
    if not continuity:
        errors.append('EDGE_CONTINUITY_FAIL')
    route_end_agreement = cell.sin1_second.target == cell.sin2_second.target == cell.end
    if not route_end_agreement:
        errors.append('ROUTE_END_MISMATCH')
    cos_match = cell.cos.source == cell.start and cell.cos.target == cell.end
    if not cos_match:
        errors.append('COS_DIAGONAL_ENDPOINT_MISMATCH')
    first_seg, second_seg = _expected_segments(cell.orientation)
    segment_order = cell.sin1_first.segment == first_seg and cell.sin1_second.segment == second_seg and (cell.sin2_first.segment == first_seg) and (cell.sin2_second.segment == second_seg)
    if not segment_order:
        errors.append('SEGMENT_ORDER_MISMATCH')
    cross_ok = coordinate_twist_squared_identity()
    if not cross_ok:
        errors.append('CROSS_ROLE_TWIST_NOT_INVOLUTIVE')
    w1 = _bijective_pairing(cell.sin1_first.witnesses, cell.sin2_second.witnesses, cell.cross_witness_pairs_1)
    w2 = _bijective_pairing(cell.sin1_second.witnesses, cell.sin2_first.witnesses, cell.cross_witness_pairs_2)
    if 'FAIL' in (w1, w2):
        errors.append('WITNESS_TRIANGULATION_FAIL')
    witness = 'PASS' if w1 == w2 == 'PASS' else 'FAIL' if 'FAIL' in (w1, w2) else 'NOT_MATERIALIZED'
    valid = not errors
    return CellReceipt(valid, cell.cell_id, cell.role.value, cell.orientation.value, continuity, route_end_agreement, cos_match, segment_order, cross_ok, witness, tuple(errors), _digest(cell.to_dict()), 0)

def verify_dual_pass(first: CausalCell, second: CausalCell) -> DualPassReceipt:
    errors = []
    r1 = verify_cell(first)
    r2 = verify_cell(second)
    if not r1.valid:
        errors.append('FIRST_CELL_INVALID')
    if not r2.valid:
        errors.append('SECOND_CELL_INVALID')
    if first.role != CellRole.RESIDUAL_CONTOUR:
        errors.append('FIRST_ROLE_MUST_BE_RESIDUAL_CONTOUR')
    if second.role != CellRole.DUAL_SOLUTION_CLOSURE:
        errors.append('SECOND_ROLE_MUST_BE_DUAL_SOLUTION_CLOSURE')
    if first.orientation != Orientation.AB:
        errors.append('FIRST_ORIENTATION_MUST_BE_AB')
    same_repeat = second.orientation == first.orientation
    if second.orientation != Orientation.BA:
        errors.append('SECOND_ORIENTATION_MUST_BE_BA')
    if same_repeat:
        errors.append('NON_CONJUGATE_REPEAT_AB_TO_AB')
    junction = first.end == second.start
    if not junction:
        errors.append('RESIDUAL_JUNCTION_MISMATCH')
    tau2 = coordinate_twist_squared_identity()
    process = r1.valid and r2.valid and (first.role == CellRole.RESIDUAL_CONTOUR) and (second.role == CellRole.DUAL_SOLUTION_CLOSURE) and (first.orientation == Orientation.AB) and (second.orientation == Orientation.BA) and junction
    obj = {'first': r1.to_dict(), 'second': r2.to_dict(), 'junction': junction, 'tau2': tau2, 'process': process, 'problem': first.start, 'residual': first.end, 'solution': second.end}
    return DualPassReceipt(not errors, first.cell_id, second.cell_id, first.start, first.end, second.end, first.orientation.value, second.orientation.value, first.role.value, second.role.value, junction, tau2, process, same_repeat, tuple(errors), _digest(obj), 0)
