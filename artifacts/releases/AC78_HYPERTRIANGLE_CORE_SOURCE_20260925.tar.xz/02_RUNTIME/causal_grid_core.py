from __future__ import annotations
from typing import Any, Dict, List, Optional
import sympy as sp
from causal_grid_autoroute import infer_route_spec
from causal_grid_extended_routes import compile_extended_route
from causal_grid_theorem_pack import match_theorems, theorem_supplies
from causal_grid_bindings import apply_bindings
from causal_grid_atlas_bindings import apply_atlas_bindings
from causal_grid_coordinate_library import CanonicalCoordinateCore
from universal_constraint_compiler import compile_constraint_route, UniversalConstraintLedger
from periodic_cartesian_theorem_core import PeriodicCartesianTheoremCore
from hypertriangle_memory_core import HyperTriangleMemoryCore

CORE_KINDS = {
    'CAUSAL_GRID_CORE_RECEIPT','CAUSAL_GRID_CELL','CAUSAL_GRID_RESIDUE_CURRENT',
    'CAUSAL_GRID_TYPING_CURRENT','CAUSAL_GRID_METRIC_CURRENT','CAUSAL_GRID_ROUTE_EXTRACTION_CURRENT',
    'CAUSAL_GRID_THEOREM_RECEIPT','CAUSAL_GRID_BINDING_RECEIPT','CAUSAL_GRID_ATLAS_BINDING_RECEIPT',
    'CAUSAL_GRID_COORDINATE_LIBRARY_RECEIPT','CAUSAL_GRID_ACTIVE_GRID_RECEIPT',
    'CAUSAL_GRID_CONSTRAINT_RECEIPT',
    'PERIODIC_CARTESIAN_DISTANCE_RECEIPT','PERIODIC_CARTESIAN_ROUTE_RECEIPT',
    'PERIODIC_CARTESIAN_PROVIDER_RECEIPT','PERIODIC_CARTESIAN_COHERENCE_CURRENT',
    'HYPERTRIANGLE_AUX_RECEIPT','HYPERTRIANGLE_AUX_CURRENT'
}

def _sym(x: Any) -> sp.Expr:
    return x if isinstance(x, sp.Basic) else sp.sympify(x)

def symbolic_grid_weights(cells: List[Dict[str, Any]]) -> Dict[str, Any]:
    ws=[sp.Symbol(f'w_{i+1}', positive=True) for i in range(len(cells))]
    if not ws:
        return {'mode':'EMPTY','weights':[],'q_bounds':['0']}
    total=sp.Add(*ws); acc=sp.Integer(0); q=[sp.Integer(0)]
    for w in ws:
        acc=sp.simplify(acc+w); q.append(sp.simplify(acc/total))
    return {'mode':'SYMBOLIC_EXACT','weights':[str(x) for x in ws],
            'q_bounds':[str(x) for x in q],
            'metric_invented':False,
            'rule':'q_k=(w_1+...+w_k)/(w_1+...+w_n)'}

def numeric_grid_weights(weights: List[Any]) -> Dict[str, Any]:
    vals=[_sym(w) for w in weights]
    for v in vals:
        if v.is_number and not bool(v>0): raise ValueError('weights must be positive')
    total=sp.simplify(sum(vals,sp.Integer(0)))
    acc=sp.Integer(0); q=[sp.Integer(0)]
    for v in vals:
        acc=sp.simplify(acc+v); q.append(sp.simplify(acc/total))
    return {'mode':'METRIC_BOUND','weights':[str(v) for v in vals],
            'total_weight':str(total),'q_bounds':[str(x) for x in q],
            'metric_invented':False,'rule':'exact normalized cumulative grounded metric'}

def _cell(i:int, op:str, before:str, after:str, plate_before:str, plate_after:str, **kw):
    c={'display_index':i,'operation':op,'cake_before':before,'cake_after':after,
       'plate_before':plate_before,'plate_after':plate_after,
       'legal':kw.pop('legal',True),'permission':kw.pop('permission','ALLOW'),
       'residue':kw.pop('residue',None),'mirror_operator':kw.pop('mirror',None),
       'mirror_kind':kw.pop('mirror_kind','STRUCTURAL_DUAL'),
       'causal_reverse':kw.pop('causal_reverse','NOT_CLAIMED'),
       'notes':kw.pop('notes',[])}
    c.update(kw); return c

def compile_route(spec:Dict[str,Any]) -> Dict[str,Any]:
    kind=str(spec.get('kind') or '').upper()
    if kind=='UNIVERSAL_CONSTRAINT_RULE':
        out=compile_constraint_route(spec)
        # Keep the same core schema surface while exposing the AC75 route schema inside.
        out['core_schema']='AC75_CORE_ROUTE_V1'
        return out
    extended={'GENERAL_QUADRATIC','RATIONAL_SCALAR','EXPONENTIAL_SCALAR','LOGARITHMIC_SCALAR','ABSOLUTE_VALUE_SCALAR','POLYNOMIAL_FACTORED','TRIG_PERIODIC_ZERO','SIN_LINEAR_DOMINANCE_ZERO','ALGEBRAIC_ROOT_SET'}
    if kind in extended:
        out=compile_extended_route(spec)
        out['schema']='AC70_CORE_ROUTE_V1'
        return out
    cells=[]; status='OPEN_TYPED'; solution=None; required=[]; proof=True
    if kind=='AFFINE_SCALAR':
        x=sp.Symbol(spec.get('variable','x')); a=sp.sympify(spec['a']); b=sp.sympify(spec['b']); c=sp.sympify(spec['c'])
        if sp.simplify(a)==0:
            return {'schema':'AC70_CORE_ROUTE_V1','kind':kind,'status':'REJECTED','reason':'a=0 unique inverse unavailable','cells':[]}
        e0=sp.Eq(a*x+b,c); e1=sp.Eq(a*x,c-b); e2=sp.Eq(x,sp.simplify((c-b)/a))
        cells=[_cell(1,f'SUBTRACT({b})',str(e0),str(e1),'SCALAR_FIELD','SCALAR_FIELD',mirror=f'ADD({b})',mirror_kind='DIRECT_ALGEBRAIC_DUAL',causal_reverse='FORMALLY_AVAILABLE'),
               _cell(2,f'DIVIDE({a})',str(e1),str(e2),'SCALAR_FIELD','SCALAR_FIELD',mirror=f'MULTIPLY({a})',mirror_kind='DIRECT_ALGEBRAIC_DUAL',causal_reverse='FORMALLY_AVAILABLE')]
        status='CLOSED'; solution=str(e2); proof=bool(sp.solve(e0,x)==[sp.simplify((c-b)/a)])
    elif kind=='QUADRATIC_BRANCH':
        x=sp.Symbol(spec.get('variable','x'), real=True); c=sp.sympify(spec['c']); branch=spec.get('branch'); root=sp.sqrt(c)
        if c.is_number and c<0:
            return {'schema':'AC70_CORE_ROUTE_V1','kind':kind,'status':'REJECTED','reason':'no real solution on declared plate','cells':[]}
        if branch in ('positive','nonnegative','+'):
            sol=sp.Eq(x,root); cells=[_cell(1,'SQRT_BRANCH(+)',str(sp.Eq(x**2,c)),str(sol),'REAL_LINE_NONNEGATIVE','REAL_LINE_NONNEGATIVE',mirror='SQUARE',mirror_kind='CONDITIONAL_DIRECT',causal_reverse='FORMALLY_AVAILABLE')]; status='CLOSED'; solution=str(sol)
        elif branch in ('negative','-'):
            sol=sp.Eq(x,-root); cells=[_cell(1,'SQRT_BRANCH(-)',str(sp.Eq(x**2,c)),str(sol),'REAL_LINE_NONPOSITIVE','REAL_LINE_NONPOSITIVE',mirror='SQUARE',mirror_kind='CONDITIONAL_DIRECT',causal_reverse='FORMALLY_AVAILABLE')]; status='CLOSED'; solution=str(sol)
        else:
            cells=[_cell(1,'SQRT_WITHOUT_BRANCH',str(sp.Eq(x**2,c)),'x=+/-sqrt(c)','REAL_LINE','REAL_LINE',legal=False,permission='REQUIRES_RESIDUE_OR_BRANCH_SPLIT',residue='BRANCH_SIGN',mirror='SQUARE',mirror_kind='RESIDUE_LIFT_REQUIRED',causal_reverse='NOT_UNIQUE_WITHOUT_BRANCH')]
            required=['BRANCH_SIGN_OR_TWO_BRANCH_ROUTE']; status='OPEN_TYPED'; solution='x=+/-sqrt(c)'
    elif kind=='DERIVATIVE_WITH_BOUNDARY':
        t=sp.Symbol(spec.get('variable','t'), real=True); rhs=sp.sympify(spec['rhs']); t0=sp.sympify(spec.get('t0',0)); f0=sp.sympify(spec['f0'])
        ant=sp.integrate(rhs,t); C=sp.simplify(f0-ant.subs(t,t0)); sol=sp.simplify(ant+C)
        cells=[_cell(1,'INTEGRATE_WITH_BOUNDARY',f"f'({t})={rhs}; f({t0})={f0}",f'f({t})={sol}','TIME_LINE','TIME_LINE',residue=f'INTEGRATION_CONSTANT={C}',mirror='DIFFERENTIATE',mirror_kind='RESIDUE_COMPLETED_DUAL',causal_reverse='FORMALLY_AVAILABLE_ON_DECLARED_FUNCTION_CLASS')]
        status='CLOSED'; solution=f'f({t})={sol}'; proof=bool(sp.simplify(sp.diff(sol,t)-rhs)==0 and sp.simplify(sol.subs(t,t0)-f0)==0)
    elif kind=='LINEAR_SYSTEM':
        A=sp.Matrix(spec['A']); b=sp.Matrix(spec['b'])
        if A.rows==A.cols and sp.simplify(A.det())!=0:
            x=sp.simplify(A.inv()*b); cells=[_cell(1,'APPLY_MATRIX_INVERSE','A*x=b',f'x={list(x)}','VECTOR_SPACE','VECTOR_SPACE',mirror='APPLY_MATRIX',mirror_kind='DIRECT_LINEAR_DUAL',causal_reverse='FORMALLY_AVAILABLE')]; status='CLOSED'; solution=str(list(x)); proof=bool(A*x==b)
        else:
            rank=A.rank(); aug=A.row_join(b).rank(); consistent=(rank==aug)
            if consistent:
                cells=[_cell(1,'SOLVE_SINGULAR_LINEAR_MAP','A*x=b','solution fibre','VECTOR_SPACE','QUOTIENT_OR_SOLUTION_FIBRE',legal=False,permission='REQUIRES_KERNEL_RESIDUE_OR_ADDITIONAL_CONSTRAINT',residue='KER(A)_COORDINATE',mirror='PSEUDOINVERSE+KERNEL_RESIDUE',mirror_kind='RESIDUE_LIFT_REQUIRED',causal_reverse='NOT_UNIQUE')]; status='OPEN_TYPED'; required=['KER(A)_COORDINATE_OR_EXTRA_CONSTRAINT']
            else:
                cells=[_cell(1,'SOLVE_SINGULAR_LINEAR_MAP','A*x=b','inconsistent','VECTOR_SPACE','NO_SOLUTION',legal=False,permission='REJECT_INCONSISTENT',residue='CONTRADICTION_CERTIFICATE',mirror=None,mirror_kind='NO_ROUTE',causal_reverse='IMPOSSIBLE_IN_DECLARED_SCOPE')]; status='REJECTED'
    elif kind=='FINITE_DFT':
        n=int(spec.get('n',4)); I=sp.I; w=sp.exp(-2*sp.pi*I/n); F=sp.Matrix([[w**(j*k) for k in range(n)] for j in range(n)]); unitary=bool(sp.simplify(sp.conjugate(F.T)*F)==n*sp.eye(n))
        cells=[_cell(1,f'UNITARY_DFT(n={n})','time-domain vector','frequency-domain vector','TIME_CHART','FREQUENCY_CHART',legal=unitary,permission='ALLOW_UNITARY_BRIDGE' if unitary else 'REJECT_UNVERIFIED',mirror=f'INVERSE_UNITARY_DFT(n={n})',mirror_kind='UNITARY_DUAL_PLATE_BRIDGE',causal_reverse='REPRESENTATION_REVERSE_AVAILABLE; PHYSICAL_HISTORY_UNCHANGED')]; status='CLOSED_REPRESENTATION_BRIDGE' if unitary else 'REJECTED'; proof=unitary
    elif kind=='SAMPLING':
        n=int(spec.get('n',4)); kept=list(spec.get('kept',[0,2])); discarded=[i for i in range(n) if i not in kept]; contract=spec.get('reconstruction_contract')
        if contract:
            cells=[_cell(1,'SAMPLING_WITH_RECONSTRUCTION_CONTRACT',f'vector[{n}]',f'samples[{len(kept)}]','FULL_SUPPORT','SAMPLED_SUPPORT',permission='ALLOW_CONDITIONALLY',residue='IMPLICIT_IN_RECONSTRUCTION_CONTRACT',mirror='RECONSTRUCT_FROM_SAMPLES',mirror_kind='CONDITIONAL_MIRROR',causal_reverse='FORMALLY_AVAILABLE_UNDER_CONTRACT')]; status='CLOSED_CONDITIONAL'
        else:
            cells=[_cell(1,'SAMPLING',f'vector[{n}]',f'samples[{len(kept)}]','FULL_SUPPORT','SAMPLED_SUPPORT',legal=False,permission='REQUIRES_RESIDUE_OR_BANDLIMIT_CONTRACT',residue=f'DISCARDED_COMPONENTS{discarded}',mirror='INTERPOLATION/RECONSTRUCTION',mirror_kind='RESIDUE_LIFT_REQUIRED',causal_reverse='NOT_UNIQUE_WITHOUT_CONTRACT')]; status='OPEN_TYPED'; required=['DISCARDED_COMPONENTS_OR_BANDLIMIT_CONTRACT']
    elif kind=='RIGHT_ANGLE_GATE':
        T=sp.sympify(spec.get('T',7)); S=sp.sympify(spec.get('S',3)); J=sp.Matrix([[0,-1],[1,0]]); v=sp.Matrix([T,S]); o=J*v
        cells=[_cell(1,'RIGHT_ANGLE_ROLE_GATE',f'(T,S)=({T},{S})',f'J(T,S)=({o[0]},{o[1]})','PLATE_TS','PLATE_ST',permission='ALLOW_CHART_ROLE_EXCHANGE_WITH_TRANSPORT',mirror='STRUCTURAL_DUAL_CHART',mirror_kind='QUADRATURE_ROLE_EXCHANGE',causal_reverse='FORWARD_ONLY_UNLESS_DOMAIN_REVERSE_PROVED',notes=['quadrature is not reverse history'])]; status='CLOSED_STRUCTURAL_GATE'; proof=bool(J*J*v==-v)
    elif kind=='HEAT_FORWARD':
        cells=[_cell(1,'HEAT_SEMIGROUP_FORWARD','u(t0)','u(t1)','STATE_AT_T0','STATE_AT_T1',permission='ALLOW_FORWARD_EVOLUTION',residue='MICROSTATE/GENERATIVE_HISTORY_IF_REQUIRED',mirror='STRUCTURAL_TIME_DUAL',mirror_kind='STRUCTURAL_MIRROR_NOT_EXECUTABLE_INVERSE',causal_reverse='NOT_CLAIMED')]; status='CLOSED_FORWARD_ONLY'
    else:
        return {'schema':'AC70_CORE_ROUTE_V1','kind':kind,'status':'UNSUPPORTED_KIND','reason':'no core compiler for this route kind','cells':[],'requires':['ROUTE_COMPILER_OR_TYPED_OPERATOR_SIGNATURE']}
    weights=spec.get('metric_weights')
    grid=numeric_grid_weights(weights) if (weights is not None and len(weights)==len(cells)) else symbolic_grid_weights(cells)
    qb=grid.get('q_bounds',[])
    if len(qb)==len(cells)+1:
        for i,c in enumerate(cells):
            seg=chr(ord('a')+i) if i<26 else f's{i+1}'
            c['grid_address']={'segment':seg,'q_start':qb[i],'q_end':qb[i+1],'mirror_segment':seg+"'",'same_local_sigma':True}
    return {'schema':'AC70_CORE_ROUTE_V1','kind':kind,'status':status,'solution':solution,'cells':cells,'grid':grid,'requires':required,'proof_check':proof,
            'core_rules':{'cake_plate_distinct':True,'metric_invented':False,'structural_mirror_is_not_causal_inverse':True,'residue_to_cos_skin':True}}

def _first(p:Dict[str,Any], keys:List[str]):
    for k in keys:
        if p.get(k) not in (None,'',[],{}): return p.get(k)
    return None

def generic_typing(node) -> Dict[str,Any]:
    p=node.payload
    cake=_first(p,['cake','object','state','current_state','variable','input','subject'])
    plate=_first(p,['plate','carrier','domain','space','function_space','ambient_space'])
    op=_first(p,['operation','operator','transform','arithmetic_operation','action'])
    residue=_first(p,['residue','scientific_residual','kernel_residue','missing_information'])
    missing=[]
    if cake is None: missing.append('CAKE_TYPE')
    if plate is None: missing.append('PLATE_TYPE')
    if op is None: missing.append('OPERATOR_SIGNATURE')
    return {'schema':'AC70_CORE_GENERIC_TYPING_V1','status':'PASS' if not missing else 'OPEN_TYPED',
            'statement':str(p.get('statement') or ''),'cake':cake,'plate':plate,'operator':op,'residue':residue,
            'requires':missing,'nonblocking':True,'sovereign_root_preserved':True,
            'rules':{'equal_magnitude_does_not_authorize_type_substitution':True,'mirror_not_inverse_without_certificate':True}}

class CausalGridCore:
    def __init__(self):
        self.compiled_count=0; self.typed_route_count=0; self.generic_count=0; self.auto_extracted_count=0; self.auto_unresolved_count=0
        self.coordinate_library_core = CanonicalCoordinateCore()
        self.constraint_ledger = UniversalConstraintLedger()
        self.periodic_cartesian_core = PeriodicCartesianTheoremCore()
        self.hypertriangle_core = HyperTriangleMemoryCore()
        self.constraint_compiled_count=0; self.constraint_closed_count=0; self.constraint_open_count=0; self.constraint_semantic_residue_count=0
    def compile_node(self,node,world:Dict[str,Any],wave:int):
        from all_everything_wave_engine import Node
        if node.kind in CORE_KINDS or node.payload.get('ac78_core_generated') or node.payload.get('ac70_core_generated') or node.payload.get('ac69_core_generated'):
            return []
        p=node.payload
        theorem_rows=match_theorems(p)
        inference=infer_route_spec(p)
        candidate=inference.get('route_spec')
        supported={'AFFINE_SCALAR','QUADRATIC_BRANCH','DERIVATIVE_WITH_BOUNDARY','LINEAR_SYSTEM','FINITE_DFT','SAMPLING','RIGHT_ANGLE_GATE','HEAT_FORWARD','GENERAL_QUADRATIC','RATIONAL_SCALAR','EXPONENTIAL_SCALAR','LOGARITHMIC_SCALAR','ABSOLUTE_VALUE_SCALAR','POLYNOMIAL_FACTORED','TRIG_PERIODIC_ZERO','SIN_LINEAR_DOMINANCE_ZERO','ALGEBRAIC_ROOT_SET','UNIVERSAL_CONSTRAINT_RULE'}
        route_spec=candidate if isinstance(candidate,dict) and str(candidate.get('kind') or '').upper() in supported else None
        if route_spec:
            diag=compile_route(dict(route_spec)); self.typed_route_count+=1
            if inference.get('status')=='AUTO_EXTRACTED': self.auto_extracted_count+=1
            if str(route_spec.get('kind') or '').upper()=='UNIVERSAL_CONSTRAINT_RULE':
                ledger_receipt=self.constraint_ledger.register(route_spec)
                diag['constraint_ledger_receipt']=ledger_receipt
                self.constraint_compiled_count+=1
                if str(diag.get('status') or '').startswith('CLOSED_STRUCTURAL') and ledger_receipt.get('status')!='CONFLICT_OPEN': self.constraint_closed_count+=1
                else: self.constraint_open_count+=1
                self.constraint_semantic_residue_count += len(diag.get('semantic_residues') or [])
                if ledger_receipt.get('requires'):
                    diag['requires']=list(dict.fromkeys(list(diag.get('requires') or [])+list(ledger_receipt.get('requires') or [])))
            diag['route_inference']=inference
        else:
            diag=generic_typing(node); self.generic_count+=1; self.auto_unresolved_count+=1
            inferred_requires=[] if theorem_rows else list(inference.get('requires') or [])
            diag['route_extraction_requires']=inferred_requires
            if theorem_rows:
                diag['theorem_pack_structural_closure']=True
                diag['status']='THEOREM_PACK_SCOPED'
            diag['route_inference']=inference
        binding=apply_bindings(p,diag)
        atlas_binding=apply_atlas_bindings(p,diag)
        coordinate_binding=self.coordinate_library_core.apply_payload(p)
        periodic_binding=self.periodic_cartesian_core.apply_payload(p)
        hypertriangle_binding=self.hypertriangle_core.apply_payload(p)
        if binding.get('status')!='NO_BINDING_REQUEST':
            diag['grounded_bindings']=binding
            # Ground q from explicit q binding without inventing a metric.
            qb=((binding.get('bindings') or {}).get('q') or {})
            if qb.get('status')=='PASS':
                diag['grid_binding_override']=qb
        if atlas_binding.get('status')!='NO_ATLAS_BINDING_REQUEST':
            diag['atlas_bindings']=atlas_binding
        if coordinate_binding.get('status')!='NO_COORDINATE_LIBRARY_REQUEST':
            diag['canonical_coordinate_library']=coordinate_binding
        if periodic_binding.get('status')!='NO_PERIODIC_CARTESIAN_REQUEST':
            diag['periodic_cartesian_theorem_metrology']=periodic_binding
        if hypertriangle_binding.get('status')!='NO_HYPERTRIANGLE_REQUEST':
            diag['hypertriangle_memory_integration']=hypertriangle_binding
        self.compiled_count+=1
        status=diag.get('status','OPEN_TYPED')
        receipt_payload={
            'status':'PASS' if status not in {'UNSUPPORTED_KIND','OPEN_TYPED'} else 'PARTIAL',
            'statement':'AC70_CAUSAL_GRID_CORE_COMPILED',
            'source_node_id':node.identity(),'source_kind':node.kind,
            'sovereign_root_id':p.get('sovereign_root_id') or p.get('inherited_sovereign_root_id'),
            'core_diagnosis':diag,'ac70_core_generated':True,'ac69_core_generated':True,
            'scientific_focus':False,'truth_credit_added':0,'external_scientific_truth_certified':False,
            'supplies':['CAUSAL_GRID_CORE_TYPING'],
            'requires':list(dict.fromkeys(list(diag.get('requires') or [])+list(diag.get('route_extraction_requires') or []))),
        }
        out=[Node('CAUSAL_GRID_CORE_RECEIPT',receipt_payload,(node.identity(),),wave,tuple(node.context))]
        if route_spec and str(route_spec.get('kind') or '').upper()=='UNIVERSAL_CONSTRAINT_RULE':
            lr=diag.get('constraint_ledger_receipt') or {}
            out.append(Node('CAUSAL_GRID_CONSTRAINT_RECEIPT',{
                'status':'OPEN' if lr.get('status')=='CONFLICT_OPEN' else 'PASS',
                'statement':'AC76_SEMANTIC_CONSTRAINT_UNIFIER_COMPILED',
                'source_node_id':node.identity(),'rule_id':route_spec.get('rule_id'),
                'constraint_rule':route_spec,'ledger_receipt':lr,
                'ac76_core_generated':True,'ac75_core_generated':True,'ac74_core_generated':True,'ac73_core_generated':True,'ac72_core_generated':True,'ac71_core_generated':True,'ac70_core_generated':True,'ac69_core_generated':True,
                'truth_credit_added':0,'external_scientific_truth_certified':False,
                'supplies':['UNIVERSAL_CONSTRAINT_CARRIER','SEMANTIC_CONSTRAINT_PROFILE','CONSTRAINT_LEDGER_ENTRY'],
                'requires':list(lr.get('requires') or []),'movement_blocked':False
            },(node.identity(),),wave,tuple(node.context)))
        if binding.get('status')!='NO_BINDING_REQUEST':
            out.append(Node('CAUSAL_GRID_BINDING_RECEIPT',{
                'status':binding.get('status'),'statement':'AC72_CAUSAL_GRID_BINDING_RECEIPT',
                'source_node_id':node.identity(),'bindings':binding.get('bindings'),
                'open_requirements':binding.get('open_requirements'),
                'ac72_core_generated':True,'ac71_core_generated':True,'ac70_core_generated':True,'ac69_core_generated':True,
                'truth_credit_added':0,'external_scientific_truth_certified':False,
                'supplies':['CAUSAL_GRID_GROUNDED_BINDING'] if binding.get('status')=='PASS' else ['CAUSAL_GRID_BINDING_DIAGNOSIS'],
                'requires':list(binding.get('open_requirements') or [])
            },(node.identity(),),wave,tuple(node.context)))
        if atlas_binding.get('status')!='NO_ATLAS_BINDING_REQUEST':
            out.append(Node('CAUSAL_GRID_ATLAS_BINDING_RECEIPT',{
                'status':atlas_binding.get('status'),'statement':'AC73_CAUSAL_GRID_ATLAS_BINDING_RECEIPT',
                'source_node_id':node.identity(),'bindings':atlas_binding.get('bindings'),
                'open_requirements':atlas_binding.get('open_requirements'),
                'closed_task_families':atlas_binding.get('closed_task_families'),
                'ac73_core_generated':True,'ac72_core_generated':True,'ac71_core_generated':True,'ac70_core_generated':True,'ac69_core_generated':True,
                'truth_credit_added':0,'external_scientific_truth_certified':False,
                'supplies':['CAUSAL_GRID_ATLAS_BINDING'] if atlas_binding.get('status')=='PASS' else ['CAUSAL_GRID_ATLAS_BINDING_DIAGNOSIS'],
                'requires':list(atlas_binding.get('open_requirements') or [])
            },(node.identity(),),wave,tuple(node.context)))
        if coordinate_binding.get('status')!='NO_COORDINATE_LIBRARY_REQUEST':
            for action_index, cr in enumerate(coordinate_binding.get('receipts') or []):
                supplies=list(cr.get('supplies') or [])
                requires=list(cr.get('requires') or [])
                kind='CAUSAL_GRID_ACTIVE_GRID_RECEIPT' if cr.get('action') in {'BUILD_ACTIVE_GRID','MIRROR_ACTIVE_GRID','SEMANTIC_TRANSPARENCY'} else 'CAUSAL_GRID_COORDINATE_LIBRARY_RECEIPT'
                out.append(Node(kind,{
                    'status':cr.get('status'),'statement':'AC74_CANONICAL_COORDINATE_LIBRARY_RECEIPT',
                    'source_node_id':node.identity(),'action_index':action_index,
                    'coordinate_receipt':cr,
                    'profile':coordinate_binding.get('profile'),'declared_class':coordinate_binding.get('declared_class'),
                    'ac74_core_generated':True,'ac73_core_generated':True,'ac72_core_generated':True,'ac71_core_generated':True,'ac70_core_generated':True,'ac69_core_generated':True,
                    'truth_credit_added':0,'external_scientific_truth_certified':False,
                    'supplies':supplies or ['CP026_LIBRARY_REQUEST_DIAGNOSIS'],
                    'requires':requires,
                    'movement_blocked':False
                },(node.identity(),),wave,tuple(node.context)))
        if periodic_binding.get('status')!='NO_PERIODIC_CARTESIAN_REQUEST':
            presult=periodic_binding.get('result') or {}
            pschema=str(presult.get('schema') or '')
            if periodic_binding.get('ok'):
                if pschema=='PASS054_CARTESIAN_COHERENT_ROUTE_CERTIFICATE_V1':
                    pkind='PERIODIC_CARTESIAN_ROUTE_RECEIPT'
                    psupplies=['PERIODIC_CARTESIAN_ROUTE_COHERENCE','CAUSAL_CARTESIAN_CERTIFIED_THEOREM_DISPLACEMENT','THEOREM_METRIC_PROVIDER_RELATIVE']
                    if presult.get('route_pythagoras',{}).get('result')=='NOT_APPLICABLE_USE_GRAM_LAW':
                        psupplies += ['GRAM_ROUTE_COMPOSITION','FALSE_NAIVE_PYTHAGORAS_REJECTED']
                elif pschema=='PASS053_PROVIDER_REGISTRY_RESPONSE_V1':
                    pkind='PERIODIC_CARTESIAN_PROVIDER_RECEIPT'
                    psupplies=['PERIODIC_CARTESIAN_PROVIDER_REGISTRY']
                else:
                    pkind='PERIODIC_CARTESIAN_DISTANCE_RECEIPT'
                    psupplies=['PERIODIC_CARTESIAN_DISTANCE','CAUSAL_CARTESIAN_CERTIFIED_THEOREM_DISPLACEMENT','THEOREM_METRIC_PROVIDER_RELATIVE']
                out.append(Node(pkind,{
                    'status':'PASS','statement':'AC77_PERIODIC_CARTESIAN_THEOREM_METROLOGY_RECEIPT',
                    'source_node_id':node.identity(),'periodic_cartesian_receipt':periodic_binding,
                    'ac77_core_generated':True,'ac76_core_generated':True,'ac75_core_generated':True,'ac74_core_generated':True,
                    'ac73_core_generated':True,'ac72_core_generated':True,'ac71_core_generated':True,'ac70_core_generated':True,'ac69_core_generated':True,
                    'truth_credit_added':0,'external_scientific_truth_certified':False,
                    'supplies':list(dict.fromkeys(psupplies)),'requires':[], 'movement_blocked':False
                },(node.identity(),),wave,tuple(node.context)))
            else:
                out.append(Node('PERIODIC_CARTESIAN_COHERENCE_CURRENT',{
                    'status':'OPEN','statement':'AC77_PERIODIC_CARTESIAN_FAIL_CLOSED_CURRENT',
                    'source_node_id':node.identity(),'periodic_cartesian_receipt':periodic_binding,
                    'ac77_core_generated':True,'scientific_focus':True,
                    'truth_credit_added':0,'external_scientific_truth_certified':False,
                    'supplies':['PERIODIC_CARTESIAN_TYPED_DIAGNOSIS'],
                    'requires':list(periodic_binding.get('requires') or []),'movement_blocked':False
                },(node.identity(),),wave,tuple(node.context)))
        if hypertriangle_binding.get('status')!='NO_HYPERTRIANGLE_REQUEST':
            if hypertriangle_binding.get('status')=='PASS':
                henv=hypertriangle_binding.get('provider_envelope') or {}
                hmode=str(henv.get('mode') or '')
                hsup=['HYPERTRIANGLE_TYPED_PROVIDER_RECEIPT']
                if hmode.startswith('memory_144_'):
                    hsup += ['HYPERTRIANGLE_MEMORY_144_RECEIPT']
                if 'terminal' in hmode:
                    hsup += ['HYPERTRIANGLE_DECLARED_LOCAL_TERMINALITY_RECEIPT']
                out.append(Node('HYPERTRIANGLE_AUX_RECEIPT',{
                    'status':'PASS','statement':'AC78_HYPERTRIANGLE_AUX_PRE_ALL_AUX_RECEIPT',
                    'source_node_id':node.identity(),'hypertriangle_receipt':hypertriangle_binding,
                    'ac78_core_generated':True,'ac77_core_generated':True,'ac76_core_generated':True,
                    'truth_credit_added':0,'external_scientific_truth_certified':False,
                    'root_write_capability':'NONE','return_write_capability':'NONE','solver_mutation_capability':'NONE',
                    'supplies':list(dict.fromkeys(hsup)),'requires':[], 'movement_blocked':False,
                    'memory_feedback_performed':False,'implicit_slot_classification_performed':False,
                },(node.identity(),),wave,tuple(node.context)))
            else:
                out.append(Node('HYPERTRIANGLE_AUX_CURRENT',{
                    'status':'OPEN','statement':'AC78_HYPERTRIANGLE_AUX_FAIL_CLOSED_CURRENT',
                    'source_node_id':node.identity(),'hypertriangle_receipt':hypertriangle_binding,
                    'ac78_core_generated':True,'scientific_focus':True,
                    'truth_credit_added':0,'external_scientific_truth_certified':False,
                    'root_write_capability':'NONE','return_write_capability':'NONE','solver_mutation_capability':'NONE',
                    'supplies':['HYPERTRIANGLE_TYPED_DIAGNOSIS'],
                    'requires':list(hypertriangle_binding.get('requires') or []),'movement_blocked':False,
                },(node.identity(),),wave,tuple(node.context)))
        for i,c in enumerate(diag.get('cells') or []):
            cp=dict(c); cp.update({'status':'PASS' if c.get('legal',True) else 'OPEN','statement':'AC70_CAUSAL_GRID_CELL',
                                  'source_node_id':node.identity(),'route_kind':diag.get('kind'),'ac70_core_generated':True,'ac69_core_generated':True,
                                  'truth_credit_added':0,'external_scientific_truth_certified':False})
            out.append(Node('CAUSAL_GRID_CELL',cp,(node.identity(),),wave,tuple(node.context)))
            if c.get('residue'):
                out.append(Node('CAUSAL_GRID_RESIDUE_CURRENT',{
                    'status':'OPEN','statement':'AC70_ROUTE_RESIDUE_TO_COS_SKIN','residue':c.get('residue'),
                    'source_operation':c.get('operation'),'grid_address':c.get('grid_address'),
                    'source_node_id':node.identity(),'ac70_core_generated':True,'ac69_core_generated':True,'scientific_focus':True,
                    'truth_credit_added':0,'external_scientific_truth_certified':False,
                    'requires':['RESIDUE_GROUNDING_OR_DOMAIN_COMPLETION'],
                    'supplies':['RESIDUE_ROUTE_IDENTIFIED']
                },(node.identity(),),wave,tuple(node.context)))
        # Generic typing deficits are currents, not blockers.
        if not route_spec and diag.get('requires'):
            out.append(Node('CAUSAL_GRID_TYPING_CURRENT',{
                'status':'OPEN','statement':'AC70_CAUSAL_GRID_TYPING_DELTA','requires':diag['requires'],
                'source_node_id':node.identity(),'ac70_core_generated':True,'ac69_core_generated':True,'scientific_focus':True,
                'truth_credit_added':0,'external_scientific_truth_certified':False,
                'movement_blocked':False
            },(node.identity(),),wave,tuple(node.context)))
        if not route_spec and diag.get('route_extraction_requires'):
            out.append(Node('CAUSAL_GRID_ROUTE_EXTRACTION_CURRENT',{
                'status':'OPEN','statement':'AC71_CAUSAL_GRID_ROUTE_EXTRACTION_DELTA','requires':diag['route_extraction_requires'],
                'source_node_id':node.identity(),'ac71_core_generated':True,'ac70_core_generated':True,'ac69_core_generated':True,'scientific_focus':True,
                'truth_credit_added':0,'external_scientific_truth_certified':False,
                'movement_blocked':False
            },(node.identity(),),wave,tuple(node.context)))
        # AC71 theorem-pack hook: exact scoped mathematical contracts are published
        # before ALL-AUX. They discharge structural obligations without pretending
        # to be an external domain proof or a universal all-mathematics theorem.
        for th in theorem_rows:
            out.append(Node('CAUSAL_GRID_THEOREM_RECEIPT',{
                'status':'PASS',
                'statement':'AC71_CAUSAL_GRID_THEOREM_PACK_RECEIPT',
                'theorem_id':th.get('theorem_id'),
                'title':th.get('title'),
                'verdict':th.get('verdict'),
                'theorem_statement':th.get('statement'),
                'scope_conditions':list(th.get('conditions') or []),
                'no_go':th.get('no_go'),
                'discharges':list(th.get('discharges') or []),
                'supplies':list(th.get('discharges') or []) + ['CAUSAL_GRID_SCOPED_THEOREM_RECEIPT'],
                'source_node_id':node.identity(),
                'ac71_core_generated':True,
                'ac70_core_generated':True,
                'ac69_core_generated':True,
                'scientific_focus':False,
                'truth_credit_added':0,
                'external_scientific_truth_certified':False
            },(node.identity(),),wave,tuple(node.context)))
        return out
    def enrich_node(self,node,world:Dict[str,Any],wave:int):
        from all_everything_wave_engine import Node
        if node.kind in CORE_KINDS or node.payload.get('ac78_core_generated') or node.payload.get('ac77_core_generated') or node.payload.get('ac70_core_generated') or node.payload.get('ac69_core_generated') or node.payload.get('ac78_core_enriched') or node.payload.get('ac70_core_enriched') or node.payload.get('ac69_core_enriched'):
            return node, []
        side=self.compile_node(node,world,wave)
        receipt=next((x for x in side if x.kind=='CAUSAL_GRID_CORE_RECEIPT'),None)
        diag=(receipt.payload.get('core_diagnosis') if receipt else {}) or {}
        payload=dict(node.payload)
        theorem_rows=match_theorems(payload)
        theorem_tokens=theorem_supplies(payload)
        if theorem_tokens:
            payload['supplies']=list(dict.fromkeys(list(payload.get('supplies') or [])+theorem_tokens))
            existing=list(payload.get('requires') or [])
            payload['requires']=[r for r in existing if str(r) not in set(theorem_tokens)]
        periodic_diag=diag.get('periodic_cartesian_theorem_metrology')
        periodic_result=(periodic_diag or {}).get('result') if isinstance(periodic_diag,dict) else None
        hypertriangle_diag=diag.get('hypertriangle_memory_integration')
        hypertriangle_env=(hypertriangle_diag or {}).get('provider_envelope') if isinstance(hypertriangle_diag,dict) else None
        payload.update({
            'ac78_core_enriched':True,
            'ac77_core_enriched':True,
            'ac71_core_enriched':True,
            'ac70_core_enriched':True,
            'ac69_core_enriched':True,
            'causal_grid_core_status':diag.get('status'),
            'causal_grid_core_diagnosis':diag,
            'causal_grid_cells':list(diag.get('cells') or []),
            'causal_grid_grid':diag.get('grid'),
            'causal_grid_typing_requires':list(diag.get('requires') or []),
            'causal_grid_residues':[c.get('residue') for c in (diag.get('cells') or []) if c.get('residue')],
            'causal_grid_structural_mirror_not_causal_inverse':True,
            'causal_grid_metric_invented':False,
            'causal_grid_theorem_pack':[{'theorem_id':t.get('theorem_id'),'verdict':t.get('verdict'),'discharges':list(t.get('discharges') or [])} for t in theorem_rows],
            'causal_grid_theorem_supplies':theorem_tokens,
            'causal_grid_grounded_bindings':diag.get('grounded_bindings'),
            'causal_grid_atlas_bindings':diag.get('atlas_bindings'),
            'causal_grid_canonical_coordinate_library':diag.get('canonical_coordinate_library'),
            'causal_grid_cp026_profile_active':True,
            'causal_grid_metric_from_borges_rank':False,
            'causal_grid_cross_carrier_reuse_requires_certified_bridge':True,
            'periodic_cartesian_core_active':True,
            'periodic_cartesian_status':(periodic_diag or {}).get('status') if isinstance(periodic_diag,dict) else 'NO_PERIODIC_CARTESIAN_REQUEST',
            'periodic_cartesian_receipt':periodic_diag if isinstance(periodic_diag,dict) and periodic_diag.get('status')!='NO_PERIODIC_CARTESIAN_REQUEST' else None,
            'periodic_cartesian_result':periodic_result,
            'periodic_cartesian_metric_invented':False,
            'periodic_cartesian_theorem_identity_equals_route_address':False,
            'periodic_cartesian_pythagoras_requires_orthogonality':True,
            'periodic_cartesian_gram_fallback_mandatory':True,
            'periodic_cartesian_provider_independent_intrinsic_metric_claimed':False,
            'hypertriangle_core_active':True,
            'hypertriangle_status':(hypertriangle_diag or {}).get('status') if isinstance(hypertriangle_diag,dict) else 'NO_HYPERTRIANGLE_REQUEST',
            'hypertriangle_receipt':hypertriangle_diag if isinstance(hypertriangle_diag,dict) and hypertriangle_diag.get('status')!='NO_HYPERTRIANGLE_REQUEST' else None,
            'hypertriangle_provider_envelope':hypertriangle_env,
            'hypertriangle_frozen_provider_verified':True,
            'hypertriangle_truth_credit_added':0,
            'hypertriangle_root_write_capability':'NONE',
            'hypertriangle_return_write_capability':'NONE',
            'hypertriangle_solver_mutation_capability':'NONE',
            'hypertriangle_implicit_slot_classification_performed':False,
            'hypertriangle_memory_feedback_performed':False,
        })
        enriched=Node(node.kind,payload,tuple(sorted(set(node.parents+(node.identity(),)))),wave,tuple(node.context))
        return enriched, side
    def enrich_frontier(self,nodes,world:Dict[str,Any],wave:int):
        enriched=[]; side=[]
        for n in nodes:
            e,s=self.enrich_node(n,world,wave); enriched.append(e); side.extend(s)
        de={}; ds={}
        for n in enriched: de[n.semantic_identity()]=n
        for n in side: ds[n.semantic_identity()]=n
        return [de[k] for k in sorted(de)], [ds[k] for k in sorted(ds)]
    def compile_frontier(self,nodes,world:Dict[str,Any],wave:int):
        return self.enrich_frontier(nodes,world,wave)[1]
