from __future__ import annotations
from fractions import Fraction
import hashlib, json, math
from all_everything_wave_engine import AuxResult, Node, obligation_rank
from parallel_transport import normalize_anchor_observations, synthesize_minimal_transport
from materialization_engine import resolve_material, normalize_target
from universal_gap_closure import universal_gap_closure
CONTROL_KINDS = {'AUX_OBSERVATION', 'MECHANISM_OBSERVATION', 'DESCENT_GUARD_RECEIPT', 'CORRELATION_SEED', 'CORRELATION_LINK', 'COLLECTIVE_FEEDBACK', 'LOCAL_METER_RECEIPT', 'LOCAL_GROUND_RECEIPT', 'LOCAL_INSULATION_RECEIPT', 'GLOBAL_METER_RECEIPT', 'GLOBAL_GROUND_RECEIPT', 'GLOBAL_INSULATION_RECEIPT', 'FULL_TOOLBOX_RECEIPT', 'EVERYTHING_BUNDLE_RECEIPT', 'CAUSAL_GAUGE_RECEIPT', 'RESISTANCE_RECEIPT', 'TEMPORAL_RECEIPT', 'BABEL_RECEIPT', 'BORGES_RECEIPT', 'UNIVERSAL_WHEEL_RECEIPT', 'GLOBAL_ORBIT_RECEIPT', 'TRANSVERSAL_RECEIPT'}

def _result(mid, node, status, kind, **payload):
    return AuxResult(mid, status, kind, payload, node.identity())

def _obs(mid, node, statement):
    return _result(mid, node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement=statement)

def _scientific(node):
    return node.kind not in CONTROL_KINDS and (not node.kind.endswith('_OBSERVATION'))

def _tokens(node, key):
    x = node.payload.get(key) or []
    if isinstance(x, str):
        x = [x]
    return sorted({str(v) for v in x if str(v)})

def _sha(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, separators=(',', ':'), default=str).encode()).hexdigest()

def _walk_payload(x, path=()):
    if isinstance(x, dict):
        yield path, x
        for k, v in x.items():
            yield from _walk_payload(v, path + (str(k),))
    elif isinstance(x, (list, tuple)):
        for i, v in enumerate(x):
            yield from _walk_payload(v, path + (str(i),))

def _leakage_paths(payload):
    leaks=[]
    for path, d in _walk_payload(payload):
        if d.get('cross_context_leakage') is True:
            leaks.append({'path':'/'.join(path), 'flag':'cross_context_leakage'})
        if d.get('future_leakage') is True:
            leaks.append({'path':'/'.join(path), 'flag':'future_leakage'})
        if d.get('no_future_leakage') is False:
            leaks.append({'path':'/'.join(path), 'flag':'no_future_leakage=false'})
        if d.get('temporal_validity') is False:
            leaks.append({'path':'/'.join(path), 'flag':'temporal_validity=false'})
    # deterministic dedup
    uniq=[]; seen=set()
    for r in leaks:
        key=(r['path'],r['flag'])
        if key not in seen:
            seen.add(key); uniq.append(r)
    return uniq

def _global_current_analysis(node):
    sm=node.payload.get('summary')
    if not isinstance(sm, dict):
        return {'valid_summary':False,'groups':[],'faults':['MISSING_SUMMARY']}
    groups=sm.get('groups')
    if not isinstance(groups, list):
        return {'valid_summary':False,'groups':[],'faults':['GROUPS_NOT_LIST']}
    req=[]; sup=[]; statuses=[]; ground_faults=[]; malformed=[]
    for i,g in enumerate(groups):
        if not isinstance(g,dict):
            malformed.append(f'group[{i}]'); continue
        gid=str(g.get('id') or f'group[{i}]')
        statuses.append(str(g.get('status') or 'UNKNOWN'))
        r=g.get('requires') or []; s=g.get('supplies') or []
        if isinstance(r,str): r=[r]
        if isinstance(s,str): s=[s]
        req += [str(x) for x in r if str(x)]
        sup += [str(x) for x in s if str(x)]
        if g.get('ground_binding') is False:
            ground_faults.append({'group':gid,'reason':'EXPLICIT_GROUND_FALSE'})
        has_target=bool(g.get('statement') or g.get('target') or g.get('obligation') or g.get('target_obligation'))
        if not has_target:
            ground_faults.append({'group':gid,'reason':'NO_SCIENTIFIC_TARGET'})
    if node.payload.get('ground_binding') is False:
        ground_faults.insert(0,{'group':'ROOT','reason':'EXPLICIT_GROUND_FALSE'})
    reqset=set(req); supset=set(sup)
    matches=sorted(reqset & supset)
    unresolved=sorted(reqset - supset)
    unused=sorted(supset - reqset)
    leaks=_leakage_paths(node.payload)
    open_groups=sum(1 for x in statuses if x.startswith('OPEN'))
    partial_groups=sum(1 for x in statuses if x.startswith('PARTIAL'))
    invalid_groups=sum(1 for x in statuses if x.startswith(('INVALID','COUNTEREXAMPLE')))
    return {
        'valid_summary':not malformed,
        'groups':groups,
        'group_count':len(groups),
        'malformed_groups':malformed,
        'requirements':req,
        'supplies':sup,
        'requirement_count':len(req),
        'supply_count':len(sup),
        'exact_matches':matches,
        'exact_match_count':len(matches),
        'unresolved_requirements':unresolved,
        'unresolved_requirement_count':len(unresolved),
        'unused_supplies':unused,
        'open_group_count':open_groups,
        'partial_group_count':partial_groups,
        'invalid_group_count':invalid_groups,
        'ground_faults':ground_faults,
        'ground_fault_count':len(ground_faults),
        'leakage_paths':leaks,
        'leakage_count':len(leaks),
        'continuity_ratio': (len(matches)/len(reqset)) if reqset else (1.0 if groups else 0.0),
        'closed_by_exact_tokens': bool(groups) and not unresolved and invalid_groups==0,
    }

def local_multimeter(node, world):
    if not _scientific(node):
        return _obs('LOCAL_MULTIMETER', node, 'LOCAL_MULTIMETER_NO_SCIENTIFIC_TARGET')
    req = _tokens(node, 'requires')
    sup = _tokens(node, 'supplies')
    rank = node.payload.get('descent_rank', node.payload.get('target_rank'))
    matches=sorted(set(req)&set(sup)); unresolved=sorted(set(req)-set(sup))
    return _result('LOCAL_MULTIMETER', node, 'PASS', 'LOCAL_METER_RECEIPT', statement='LOCAL_MULTIMETER_MEASURED', node_kind=node.kind, require_count=len(req), supply_count=len(sup), exact_match_count=len(matches), unresolved_requirements=unresolved, continuity_ratio=(len(matches)/len(set(req))) if req else 1.0, descent_rank=rank, context_depth=len(node.context), measurement_digest=_sha({'r': req, 's': sup, 'k': node.kind, 'rank': rank}))

def _grounded(node):
    if node.payload.get('ground_binding') is False:
        return False
    return bool(node.payload.get('statement') or node.payload.get('obligation') or node.payload.get('target_obligation') or node.payload.get('target'))

def local_ground(node, world):
    if not _scientific(node):
        return _obs('LOCAL_GROUND_TESTER', node, 'LOCAL_GROUND_NO_SCIENTIFIC_TARGET')
    ok = _grounded(node)
    return _result('LOCAL_GROUND_TESTER', node, 'PASS' if ok else 'OPEN', 'LOCAL_GROUND_RECEIPT', statement='LOCAL_GROUND_PASS' if ok else 'LOCAL_GROUND_UNBOUND', grounded=ok, ground_binding_explicit=node.payload.get('ground_binding'), requires=[] if ok else ['GROUND_BINDING'])

def local_insulation(node, world):
    if not _scientific(node):
        return _obs('LOCAL_INSULATION_TESTER', node, 'LOCAL_INSULATION_NO_SCIENTIFIC_TARGET')
    leaks=_leakage_paths(node.payload)
    leak=bool(leaks)
    return _result('LOCAL_INSULATION_TESTER', node, 'INVALID' if leak else 'PASS', 'LOCAL_INSULATION_RECEIPT', statement='LOCAL_INSULATION_FAIL' if leak else 'LOCAL_INSULATION_PASS', insulated=not leak, leakage_detected=leak, leakage_paths=leaks, requires=['ISOLATION_REPAIR'] if leak else [])

def _is_global(node):
    return node.kind == 'COLLECTIVE_CURRENT' and tuple(node.context) == ()

def global_multimeter(node, world):
    if not _is_global(node):
        return _obs('GLOBAL_MULTIMETER', node, 'GLOBAL_MULTIMETER_WAIT_GLOBAL_CURRENT')
    a=_global_current_analysis(node)
    if not a['valid_summary']:
        return _result('GLOBAL_MULTIMETER', node, 'INVALID', 'GLOBAL_METER_RECEIPT', statement='GLOBAL_MULTIMETER_INVALID_SUMMARY', analysis=a, requires=['VALID_COLLECTIVE_CURRENT_SUMMARY'])
    if a['group_count']==0:
        return _result('GLOBAL_MULTIMETER', node, 'INVALID', 'GLOBAL_METER_RECEIPT', statement='GLOBAL_MULTIMETER_EMPTY_CURRENT', groups=0, analysis=a, requires=['NONEMPTY_COLLECTIVE_CURRENT'])
    measurements={
        'GROUP_COUNT':a['group_count'],
        'REQUIREMENT_COUNT':a['requirement_count'],
        'SUPPLY_COUNT':a['supply_count'],
        'MATCHED_REQUIREMENT_COUNT':a['exact_match_count'],
        'UNRESOLVED_REQUIREMENT_COUNT':a['unresolved_requirement_count'],
        'OPEN_GROUP_COUNT':a['open_group_count'],
        'PARTIAL_GROUP_COUNT':a['partial_group_count'],
        'INVALID_GROUP_COUNT':a['invalid_group_count'],
        'GROUND_FAULT_COUNT':a['ground_fault_count'],
        'LEAKAGE_COUNT':a['leakage_count'],
        'CONTINUITY_RATIO':a['continuity_ratio'],
    }
    closed=a['closed_by_exact_tokens'] and not a['ground_faults'] and not a['leakage_paths']
    status='PASS' if closed else 'PARTIAL'
    return _result('GLOBAL_MULTIMETER', node, status, 'GLOBAL_METER_RECEIPT', statement='GLOBAL_MULTIMETER_CLOSED_CURRENT' if closed else 'GLOBAL_MULTIMETER_OPEN_CURRENT', groups=a['group_count'], current_closed=closed, current_measurements=measurements, exact_requirement_supply_matches=a['exact_matches'], unresolved_requirements=a['unresolved_requirements'], unused_supplies=a['unused_supplies'], summary_digest=_sha(node.payload.get('summary') or {}), supplies=['GLOBAL_CURRENT_MEASUREMENTS'])

def global_ground(node, world):
    if not _is_global(node):
        return _obs('GLOBAL_GROUND_TESTER', node, 'GLOBAL_GROUND_WAIT_GLOBAL_CURRENT')
    a=_global_current_analysis(node)
    if not a['valid_summary'] or a['group_count']==0:
        return _result('GLOBAL_GROUND_TESTER', node, 'INVALID', 'GLOBAL_GROUND_RECEIPT', statement='GLOBAL_GROUND_NO_VALID_CURRENT', grounded=False, ground_faults=a.get('ground_faults',[]), requires=['NONEMPTY_GROUNDED_COLLECTIVE_CURRENT'])
    ok=not a['ground_faults']
    return _result('GLOBAL_GROUND_TESTER', node, 'PASS' if ok else 'INVALID', 'GLOBAL_GROUND_RECEIPT', statement='GLOBAL_GROUND_PASS' if ok else 'GLOBAL_GROUND_FAIL', grounded=ok, grounded_group_count=a['group_count']-len({x['group'] for x in a['ground_faults'] if x.get('group')!='ROOT'}), ground_faults=a['ground_faults'], requires=[] if ok else ['GLOBAL_GROUND_REPAIR'])

def global_insulation(node, world):
    if not _is_global(node):
        return _obs('GLOBAL_INSULATION_TESTER', node, 'GLOBAL_INSULATION_WAIT_GLOBAL_CURRENT')
    a=_global_current_analysis(node)
    if not a['valid_summary'] or a['group_count']==0:
        return _result('GLOBAL_INSULATION_TESTER', node, 'INVALID', 'GLOBAL_INSULATION_RECEIPT', statement='GLOBAL_INSULATION_NO_VALID_CURRENT', insulated=False, leakage_detected=False, requires=['NONEMPTY_COLLECTIVE_CURRENT'])
    leak=bool(a['leakage_paths'])
    return _result('GLOBAL_INSULATION_TESTER', node, 'INVALID' if leak else 'PASS', 'GLOBAL_INSULATION_RECEIPT', statement='GLOBAL_INSULATION_FAIL' if leak else 'GLOBAL_INSULATION_PASS', insulated=not leak, leakage_detected=leak, leakage_paths=a['leakage_paths'], requires=['GLOBAL_ISOLATION_REPAIR'] if leak else [])

def causal_space(node, world):
    if node.kind == 'ZOO_CARRIER_RECEIPT' and isinstance(node.payload.get('carrier_packet'), dict):
        cp = dict(node.payload['carrier_packet'])
        route = list(node.payload.get('route_points') or cp.get('chart', {}).get('route_points') or [])
        coords = list(node.payload.get('chart_coordinates') or cp.get('chart', {}).get('chart_coordinates') or [])
        if len(route) < 2 or len(route) != len(coords):
            return _result('CAUSAL_SPACE', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='CAUSAL_SPACE_NEEDS_COMPLETE_ZOO_ROUTE', requires=['COMPLETE_CANONICAL_ROUTE'])
        vertices = [{'id': f'Q{i}', 'point': route[i], 'coordinate': coords[i]} for i in range(len(route))]
        edges = [{'source': f'Q{i}', 'target': f'Q{i + 1}', 'relation': 'ADJACENT_ROUTE_TRANSPORT', 'delta_coordinate': coords[i + 1] - coords[i]} for i in range(len(route) - 1)]
        packet = {'schema': 'CAUSAL_SPACE_ROUTE_PACKET_V1', 'carrier_id': cp.get('carrier_id'), 'route_points': route, 'chart_coordinates': coords, 'dimension_signature': node.payload.get('dimension_signature') or cp.get('chart', {}).get('dimension_signature'), 'strict_dimension_equivalence': bool(cp.get('strict_dimension_equivalence')), 'same_carrier': bool(cp.get('same_carrier_all_points')), 'epoch': cp.get('epoch', world.get('context_version')), 'source': cp.get('source'), 'target': cp.get('target'), 'external_domain_bridge_receipt': bool(node.payload.get('external_domain_bridge_receipt', False))}
        return _result('CAUSAL_SPACE', node, 'PASS', 'CAUSAL_SPACE_RECEIPT', statement='CAUSAL_SPACE_CANONICAL_ROUTE_MATERIALIZED', vertices=vertices, edges=edges, missing_edges=[], space_digest=_sha({'v': vertices, 'e': edges}), canonical_transport_packet=packet, epoch=packet['epoch'], supplies=['CAUSAL_SPACE_PACKET', 'CANONICAL_ROUTE_SPACE'])
    if not _scientific(node):
        return _obs('CAUSAL_SPACE', node, 'CAUSAL_SPACE_NO_SCIENTIFIC_TARGET')
    req = _tokens(node, 'requires')
    sup = _tokens(node, 'supplies')
    if not req and (not sup) and (not node.payload.get('edges')):
        return _obs('CAUSAL_SPACE', node, 'CAUSAL_SPACE_NO_DECLARED_RELATIONS')
    vertices = sorted(set(req + sup))
    edges = [{'source': 'CURRENT', 'target': x, 'relation': 'REQUIRES'} for x in req] + [{'source': 'CURRENT', 'target': x, 'relation': 'SUPPLIES'} for x in sup]
    return _result('CAUSAL_SPACE', node, 'PASS', 'CAUSAL_SPACE_RECEIPT', statement='CAUSAL_SPACE_MATERIALIZED', vertices=vertices, edges=edges, missing_edges=req, space_digest=_sha({'v': vertices, 'e': edges}), supplies=['CAUSAL_SPACE_PACKET'])

def temporal(node, world):
    if node.kind == 'CAUSAL_SPACE_RECEIPT' and isinstance(node.payload.get('canonical_transport_packet'), dict):
        packet = dict(node.payload['canonical_transport_packet'])
        epoch = packet.get('epoch', world.get('context_version'))
        return _result('TEMPORAL', node, 'PASS', 'TEMPORAL_RECEIPT', statement='TEMPORAL_PRE_BIND_VALID', phase='PRE_BIND', epoch=epoch, no_future_leakage=True, ancestry_digest=_sha({'parents': sorted(node.parents), 'context': list(node.context), 'epoch': epoch}), canonical_transport_packet=packet, supplies=['TEMPORAL_PREBOUND'])
    if node.kind == 'BORGES_RECEIPT' and isinstance(node.payload.get('canonical_transport_packet'), dict):
        packet = dict(node.payload['canonical_transport_packet'])
        epoch = packet.get('epoch', world.get('context_version'))
        parent_epoch = node.payload.get('parent_epoch')
        leak = False
        try:
            if parent_epoch is not None and epoch is not None:
                leak = float(parent_epoch) > float(epoch)
        except Exception:
            leak = False
        packet['rank_unrank_roundtrip'] = bool(node.payload.get('rank_unrank_roundtrip'))
        packet['temporal_validity'] = not leak
        return _result('TEMPORAL', node, 'INVALID' if leak else 'PASS', 'TEMPORAL_RECEIPT', statement='TEMPORAL_POST_CHECK_FUTURE_LEAKAGE' if leak else 'TEMPORAL_POST_CHECK_VALID', phase='POST_CHECK', epoch=epoch, no_future_leakage=not leak, canonical_transport_packet=packet, supplies=[] if leak else ['TEMPORAL_POST_VALID'])
    if node.kind not in {'CAUSAL_SPACE_RECEIPT', 'BORGES_RECEIPT'} and (node.kind.endswith('_RECEIPT') or node.payload.get('epoch') is None):
        return _obs('TEMPORAL', node, 'TEMPORAL_NO_TYPED_EPOCH')
    epoch = node.payload.get('epoch', world.get('context_version'))
    parent_epoch = node.payload.get('parent_epoch')
    leak = False
    try:
        if parent_epoch is not None and epoch is not None:
            leak = float(parent_epoch) > float(epoch)
    except Exception:
        leak = False
    return _result('TEMPORAL', node, 'INVALID' if leak else 'PASS', 'TEMPORAL_RECEIPT', statement='TEMPORAL_FUTURE_LEAKAGE' if leak else 'TEMPORAL_VALID', epoch=epoch, no_future_leakage=not leak, ancestry_digest=_sha({'parents': sorted(node.parents), 'context': list(node.context), 'epoch': epoch}), supplies=[] if leak else ['TEMPORAL_VALIDITY'])

def babel(node, world):
    if node.kind == 'TEMPORAL_RECEIPT' and node.payload.get('phase') == 'PRE_BIND' and isinstance(node.payload.get('canonical_transport_packet'), dict):
        packet = dict(node.payload['canonical_transport_packet'])
        route = list(packet.get('route_points') or [])
        coords = list(packet.get('chart_coordinates') or [])
        normal = [{'point': route[i], 'coordinate': coords[i]} for i in range(len(route))]
        packet['babel_normalized'] = True
        return _result('BABEL', node, 'PASS', 'BABEL_RECEIPT', statement='BABEL_TRANSPORT_ROUTE_NORMALIZED', normal_form=normal, alias_map={str(i): str(i) for i in range(len(normal))}, normalization_digest=_sha(normal), canonical_transport_packet=packet, supplies=['BABEL_NORMALIZED'])
    if node.kind != 'CAUSAL_SPACE_RECEIPT':
        return _obs('BABEL', node, 'BABEL_WAIT_CAUSAL_SPACE_OR_TEMPORAL_PREBIND')
    toks = sorted({str(x) for x in node.payload.get('vertices') or []})
    normal = [x.strip() for x in toks]
    return _result('BABEL', node, 'PASS', 'BABEL_RECEIPT', statement='BABEL_NORMALIZED', normal_form=normal, alias_map={x: x for x in normal}, normalization_digest=_sha(normal), supplies=['BABEL_NORMALIZED'])

def borges(node, world):
    if node.kind != 'BABEL_RECEIPT':
        return _obs('BORGES', node, 'BORGES_WAIT_BABEL')
    normal = list(node.payload.get('normal_form') or [])
    ranked = [{'rank': i, 'value': v} for i, v in enumerate(normal)]
    payload = dict(statement='BORGES_CANONICALIZED', ranked=ranked, canonical_representative=normal[0] if normal else None, rank_unrank_roundtrip=True, borges_digest=_sha(ranked), supplies=['BORGES_ADDRESSABLE'])
    if isinstance(node.payload.get('canonical_transport_packet'), dict):
        packet = dict(node.payload['canonical_transport_packet'])
        packet['rank_unrank_roundtrip'] = True
        packet['borges_addressable'] = True
        payload['canonical_transport_packet'] = packet
        payload['statement'] = 'BORGES_CANONICAL_ROUTE_RANKED'
    return _result('BORGES', node, 'PASS', 'BORGES_RECEIPT', **payload)

def universal_wheel(node, world):
    if node.kind == 'TEMPORAL_RECEIPT' and node.payload.get('phase') == 'POST_CHECK' and isinstance(node.payload.get('canonical_transport_packet'), dict):
        packet = dict(node.payload['canonical_transport_packet'])
        if not packet.get('temporal_validity'):
            return _result('UNIVERSAL_WHEEL', node, 'INVALID', 'INVALID_RESULT', statement='UNIVERSAL_WHEEL_REJECTS_TEMPORALLY_INVALID_ROUTE')
        return _result('UNIVERSAL_WHEEL', node, 'PASS', 'UNIVERSAL_WHEEL_RECEIPT', statement='UNIVERSAL_WHEEL_CANONICAL_TRANSPORT_REINJECTION_READY', canonical_digest=_sha(packet), reinject=True, canonical_transport_packet=packet, supplies=['CANONICAL_REINJECTION_READY', 'CANONICAL_TRANSPORT_PACKET'])
    if node.kind != 'BORGES_RECEIPT':
        return _obs('UNIVERSAL_WHEEL', node, 'UNIVERSAL_WHEEL_WAIT_CANONICAL_PACKET')
    return _result('UNIVERSAL_WHEEL', node, 'PASS', 'UNIVERSAL_WHEEL_RECEIPT', statement='UNIVERSAL_WHEEL_REINJECTION_READY', canonical_digest=node.payload.get('borges_digest'), reinject=True, supplies=['CANONICAL_REINJECTION_READY'])

def causal_gauge(node, world):
    # AC67: accept legacy typed gauge channels OR measurements emitted by the global multimeter.
    if node.kind == 'GLOBAL_METER_RECEIPT' and isinstance(node.payload.get('current_measurements'), dict):
        ms=dict(node.payload['current_measurements'])
        return _result('CAUSAL_GAUGE', node, 'PASS', 'CAUSAL_GAUGE_RECEIPT', statement='CAUSAL_GAUGE_GLOBAL_CURRENT_MEASURED', typed_measurements=ms, measurement_family='GLOBAL_CURRENT', missing=[], supplies=['CAUSAL_GAUGE_MEASUREMENTS','GLOBAL_CURRENT_GAUGE_MEASUREMENTS'])
    ms = node.payload.get('gauge_measurements') or node.payload.get('measurements')
    if not isinstance(ms, dict):
        return _obs('CAUSAL_GAUGE', node, 'CAUSAL_GAUGE_NO_MEASUREMENTS')
    names = ('PHI', 'SQRT2', 'SQRT3', 'LN5', 'PI')
    present = {k: ms[k] for k in names if k in ms}
    if not present:
        # Generic typed measurements are allowed but must remain explicitly generic.
        present={str(k):v for k,v in ms.items()}
        return _result('CAUSAL_GAUGE', node, 'PASS', 'CAUSAL_GAUGE_RECEIPT', statement='CAUSAL_GAUGE_GENERIC_MEASURED', typed_measurements=present, measurement_family='GENERIC', missing=[], supplies=['CAUSAL_GAUGE_MEASUREMENTS'])
    return _result('CAUSAL_GAUGE', node, 'PASS', 'CAUSAL_GAUGE_RECEIPT', statement='CAUSAL_GAUGE_MEASURED', typed_measurements=present, measurement_family='LEGACY_CONSTANT_CHANNELS', missing=[k for k in names if k not in present], supplies=['CAUSAL_GAUGE_MEASUREMENTS'])

def resistance_bank(node, world):
    if node.kind != 'CAUSAL_GAUGE_RECEIPT':
        return _obs('RESISTANCE_BANK', node, 'RESISTANCE_BANK_WAIT_GAUGE')
    ms = node.payload.get('typed_measurements') or {}
    if not isinstance(ms,dict) or not ms:
        return _result('RESISTANCE_BANK', node, 'NEED_DATA', 'RESISTANCE_RECEIPT', statement='RESISTANCE_BANK_NO_TYPED_MEASUREMENTS', channels={}, requires=['TYPED_GAUGE_MEASUREMENTS'])
    family=node.payload.get('measurement_family')
    if family=='GLOBAL_CURRENT':
        unresolved=int(ms.get('UNRESOLVED_REQUIREMENT_COUNT',0) or 0)
        leaks=int(ms.get('LEAKAGE_COUNT',0) or 0)
        grounds=int(ms.get('GROUND_FAULT_COUNT',0) or 0)
        invalid=int(ms.get('INVALID_GROUP_COUNT',0) or 0)
        closed=(unresolved==0 and leaks==0 and grounds==0 and invalid==0 and int(ms.get('GROUP_COUNT',0) or 0)>0)
        channels={k:{'present':True,'value':v} for k,v in sorted(ms.items())}
        return _result('RESISTANCE_BANK', node, 'PASS' if closed else 'PARTIAL', 'RESISTANCE_RECEIPT', statement='GLOBAL_CURRENT_RESISTANCE_CLOSED' if closed else 'GLOBAL_CURRENT_RESISTANCE_OPEN', channels=channels, current_closed=closed, open_requirement_count=unresolved, leakage_count=leaks, ground_fault_count=grounds, resistance_digest=_sha(channels), supplies=['RESISTANCE_AUDIT'] + (['GLOBAL_CURRENT_CONTINUITY_CERTIFIED'] if closed else []))
    channels = {k: {'present': k in ms, 'value': ms.get(k)} for k in ('PHI', 'SQRT2', 'SQRT3', 'LN5', 'PI')}
    return _result('RESISTANCE_BANK', node, 'PASS', 'RESISTANCE_RECEIPT', statement='ALL_RESISTANCE_CHANNELS_AUDITED', channels=channels, resistance_digest=_sha(channels), supplies=['RESISTANCE_AUDIT'])

def _resistance_channel(mid, key):

    def fn(node, world):
        if node.kind != 'CAUSAL_GAUGE_RECEIPT':
            return _obs(mid, node, mid + '_WAIT_GAUGE')
        ms = node.payload.get('typed_measurements') or {}
        if key not in ms:
            return _result(mid, node, 'NEED_DATA', 'RESISTANCE_CHANNEL_RECEIPT', statement=mid + '_MISSING', channel=key, present=False, requires=[])
        return _result(mid, node, 'PASS', 'RESISTANCE_CHANNEL_RECEIPT', statement=mid + '_MEASURED', channel=key, present=True, value=ms[key], supplies=[mid + '_MEASURED'])
    return fn
resistance_phi = _resistance_channel('RESISTANCE_PHI', 'PHI')
resistance_sqrt2 = _resistance_channel('RESISTANCE_SQRT2', 'SQRT2')
resistance_sqrt3 = _resistance_channel('RESISTANCE_SQRT3', 'SQRT3')
resistance_ln5 = _resistance_channel('RESISTANCE_LN5', 'LN5')
resistance_pi = _resistance_channel('RESISTANCE_PI', 'PI')

def _native_cycle(mid, op):

    def fn(node, world):
        cyc = node.payload.get('native_cycle')
        if not isinstance(cyc, dict) or cyc.get('operation') != op:
            return _obs(mid, node, mid + '_NO_TYPED_OPERATION')
        return _result(mid, node, 'PASS', 'NATIVE_CYCLE_RECEIPT', statement=mid + '_EXECUTED', operation=op, input=cyc.get('input'), output=cyc.get('output'), supplies=[mid + '_DONE'])
    return fn
native_plus = _native_cycle('NATIVE_PLUS', '+')
native_minus = _native_cycle('NATIVE_MINUS', '-')
native_times = _native_cycle('NATIVE_TIMES', '*')
native_divide = _native_cycle('NATIVE_DIVIDE', '/')
native_pi1 = _native_cycle('NATIVE_PI1', '=pi1')

def _target_token(node):
    t = node.payload.get('target_obligation') or node.payload.get('obligation') or node.payload.get('statement') or ''
    return normalize_target(str(t))

def _materialish_target(t):
    u = str(t or '').upper()
    return any((k in u for k in ('MATERIAL', 'PROVIDER', 'RELATION', 'CARRIER', 'GENERATOR', 'WITNESS', 'BYTES', 'PAYLOAD', 'OBJECT', 'ENUMERATION', 'ROW', 'COEFFICIENT')))

def _catalog_has_target(world, t):
    nt = normalize_target(str(t or ''))
    for src in ('materialization_catalog', 'artifact_catalog', 'provider_candidate_bank', 'relation_candidate_bank', 'carrier_candidate_bank'):
        xs = world.get(src)
        if isinstance(xs, dict):
            xs = list(xs.values())
        if not isinstance(xs, list):
            continue
        for e in xs:
            if not isinstance(e, dict):
                continue
            vals = {normalize_target(str(e.get(k, ''))) for k in ('target', 'id', 'name', 'object_id') if e.get(k)}
            vals |= {normalize_target(str(x)) for x in e.get('targets') or []}
            if nt in vals:
                return True
    return False

def auto_carrier(node, world):
    t = _target_token(node)
    if not (node.kind == 'CARRIER_OBLIGATION' or 'CARRIER' in t or 'CARRIER' in str(node.payload.get('statement', ''))):
        return _obs('AUTO_CARRIER', node, 'AUTO_CARRIER_NO_TARGET')
    res = resolve_material(node.payload, world, t, 'carrier')
    if res['status'] == 'MATERIALIZED':
        c = res['candidate']
        return _result('AUTO_CARRIER', node, 'PASS', 'AUTO_CARRIER_MATERIALIZED', statement='AUTO_CARRIER_UNIQUE_LAST_SURVIVOR', carrier=c['payload'], carrier_digest=c.get('digest'), materialization_audit=res['audit'], supplies=sorted(set(c.get('supplies') or ['TYPED_CARRIER'])))
    if res['status'] == 'AMBIGUOUS':
        return _result('AUTO_CARRIER', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='AUTO_CARRIER_AMBIGUOUS_SURVIVORS', materialization_audit=res['audit'], requires=[f'DISAMBIGUATING_CONSTRAINT::{t}'])
    if res['status'] == 'EXTERNAL_DEFINITION_REQUIRED':
        return _result('AUTO_CARRIER', node, 'WAITING', 'DEPENDENCY_WAIT', statement='AUTO_CARRIER_EXTERNAL_DEFINITION_REQUIRED_AFTER_EXHAUSTION', materialization_audit=res['audit'], requires=[f'EXTERNAL_DEFINITION::{t}'])
    return _result('AUTO_CARRIER', node, 'PARTIAL', 'MATERIALIZATION_SEARCH_RECEIPT', statement='AUTO_CARRIER_RECOVER_RECONSTRUCT_FEDERATE_ACTIVE', materialization_audit=res['audit'], search_executed=True, requires=[f'RECOVERY_EVIDENCE::{t}'])

def auto_materialization(node, world):
    if node.kind not in {'DATA_OBLIGATION', 'OPEN_RESIDUAL', 'OBLIGATION_STRATEGY_REQUEST', 'DEPENDENCY_WAIT'}:
        return _obs('AUTO_MATERIALIZATION', node, 'AUTO_MATERIALIZATION_NO_TARGET')
    t = _target_token(node)
    if not t or (not _materialish_target(t) and (not _catalog_has_target(world, t)) and (not world.get('reconstruction_rules'))):
        return _obs('AUTO_MATERIALIZATION', node, 'AUTO_MATERIALIZATION_NO_TARGET')
    expected = 'provider' if 'PROVIDER' in t else 'relation' if 'RELATION' in t or 'ROW' in t else 'carrier' if 'CARRIER' in t else None
    res = resolve_material(node.payload, world, t, expected)
    if res['status'] == 'MATERIALIZED':
        c = res['candidate']
        return _result('AUTO_MATERIALIZATION', node, 'PASS', 'AUTO_MATERIALIZED_OBJECT', statement='AUTO_MATERIALIZATION_UNIQUE_LAST_SURVIVOR', target=t, construction_target=t, material=c['payload'], material_kind=c.get('kind'), material_digest=c.get('digest'), materialization_audit=res['audit'], provenance=c.get('provenance'), supplies=sorted(set(c.get('supplies') or [])), search_executed=True, replay_required=True)
    if res['status'] == 'AMBIGUOUS':
        return _result('AUTO_MATERIALIZATION', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='AUTO_MATERIALIZATION_AMBIGUOUS_SURVIVORS', materialization_audit=res['audit'], search_executed=True, requires=[f'DISAMBIGUATING_CONSTRAINT::{t}'])
    if res['status'] == 'EXTERNAL_DEFINITION_REQUIRED':
        return _result('AUTO_MATERIALIZATION', node, 'WAITING', 'DEPENDENCY_WAIT', statement='EXTERNAL_DEFINITION_REQUIRED_AFTER_RECOVER_RECONSTRUCT_EXHAUSTED', materialization_audit=res['audit'], search_executed=True, requires=[f'EXTERNAL_DEFINITION::{t}'])
    return _result('AUTO_MATERIALIZATION', node, 'PARTIAL', 'MATERIALIZATION_SEARCH_RECEIPT', statement='AUTO_MATERIALIZATION_RECOVER_RECONSTRUCT_FEDERATE_ACTIVE', materialization_audit=res['audit'], search_executed=True, requires=[f'RECOVERY_EVIDENCE::{t}'])

def artifact_recovery_adapter(node, world):
    t = _target_token(node)
    if not t or (not _materialish_target(t) and (not _catalog_has_target(world, t))) or node.kind not in {'DATA_OBLIGATION', 'OPEN_RESIDUAL', 'DEPENDENCY_WAIT', 'OBLIGATION_STRATEGY_REQUEST'}:
        return _obs('ARTIFACT_RECOVERY_ADAPTER', node, 'ARTIFACT_RECOVERY_NO_TARGET')
    entries = world.get('artifact_catalog') or []
    if isinstance(entries, dict):
        entries = list(entries.values())
    matches = []
    for e in entries if isinstance(entries, list) else []:
        if not isinstance(e, dict):
            continue
        vals = {normalize_target(str(e.get(k, ''))) for k in ('target', 'id', 'name', 'object_id') if e.get(k)}
        vals |= {normalize_target(str(x)) for x in e.get('targets') or []}
        if t in vals:
            matches.append(e)
    if not matches:
        return _result('ARTIFACT_RECOVERY_ADAPTER', node, 'PARTIAL', 'RECOVERY_SEARCH_RECEIPT', statement='ARTIFACT_RECOVERY_CATALOG_SEARCHED_NO_MATCH', target=t, requires=[f'RECOVERY_EVIDENCE::{t}'])
    available = [e for e in matches if e.get('bytes_available') is True or e.get('payload') is not None or e.get('material') is not None or (e.get('provider') is not None) or (e.get('relation') is not None) or (e.get('carrier') is not None)]
    if len(available) == 1 and (available[0].get('verified') is True or available[0].get('authoritative') is True or str(available[0].get('status', '')).upper() in {'VERIFIED', 'CERTIFIED', 'TERMINAL'}):
        e = available[0]
        return _result('ARTIFACT_RECOVERY_ADAPTER', node, 'PASS', 'RECOVERED_ARTIFACT', statement='AUTHORITATIVE_ARTIFACT_RECOVERED', target=t, artifact=e, supplies=['RECOVERY_EVIDENCE::' + t], artifact_digest=e.get('digest') or e.get('sha256'))
    if matches and (not available):
        return _result('ARTIFACT_RECOVERY_ADAPTER', node, 'WAITING', 'RECOVERY_BACKEND_REQUEST', statement='ARTIFACT_LOCATOR_FOUND_BYTES_UNAVAILABLE', target=t, locators=[e.get('locator') or e.get('path') or e.get('id') for e in matches], requires=[f'RECOVERY_EVIDENCE::{t}'])
    return _result('ARTIFACT_RECOVERY_ADAPTER', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='ARTIFACT_RECOVERY_AMBIGUOUS', target=t, requires=[f'DISAMBIGUATING_CONSTRAINT::{t}'])

def recursive_bridge(node, world):
    if node.payload.get('source') is not None and node.payload.get('target') is not None:
        return _result('RECURSIVE_BRIDGE_ADAPTER', node, 'PASS', 'BRIDGE_RECEIPT', statement='RECURSIVE_BRIDGE_TYPED', source=node.payload['source'], target=node.payload['target'])
    return _obs('RECURSIVE_BRIDGE_ADAPTER', node, 'RECURSIVE_BRIDGE_NO_ENDPOINTS')

def coordinate_realizer(node, world):
    anchors = node.payload.get('transport_anchors') or node.payload.get('anchor_observations')
    if anchors is not None:
        try:
            norm = normalize_anchor_observations(anchors)
        except Exception as exc:
            return _result('COORDINATE_REALIZER', node, 'INVALID', 'INVALID_RESULT', statement='ANCHOR_COORDINATE_REALIZATION_REJECTED', error=str(exc))
        route = node.payload.get('route_coordinates') or node.payload.get('chart_coordinates')
        if route is None:
            route = [a['coordinate'] for a in norm['anchors']]
        return _result('COORDINATE_REALIZER', node, 'PASS', 'COORDINATE_DYNAMICS_RECEIPT', statement='ANCHOR_COORDINATES_REALIZED_FOR_TRANSPORT_DYNAMICS', transport_anchors=norm['anchors'], anchor_state_shape=norm['shape'], anchor_components=norm['components'], route_coordinates=route, supplies=['COMMON_COORDINATES', 'EXACT_TRANSPORT_ANCHORS'])
    coords = node.payload.get('coordinates') or node.payload.get('common_coordinates')
    if coords is None:
        return _obs('COORDINATE_REALIZER', node, 'COORDINATE_REALIZER_NO_COORDINATES')
    return _result('COORDINATE_REALIZER', node, 'PASS', 'COORDINATE_RECEIPT', statement='COMMON_COORDINATES_REALIZED', coordinates=coords, supplies=['COMMON_COORDINATES'])

def fibre(node, world):
    fib = node.payload.get('fibres') or node.payload.get('fiber')
    if fib is None:
        return _obs('FIBRE', node, 'FIBRE_NO_TYPED_FIBRE')
    return _result('FIBRE', node, 'PASS', 'FIBRE_RECEIPT', statement='FIBRE_TYPED', fibre=fib, supplies=['FIBRE_TYPED'])

def bound_realizer(node, world):
    b = node.payload.get('exact_bound')
    if b is None:
        return _obs('BOUND_REALIZER', node, 'BOUND_REALIZER_NO_EXACT_BOUND')
    return _result('BOUND_REALIZER', node, 'PASS', 'BOUND_RECEIPT', statement='EXACT_BOUND_ACCEPTED', bound=b, supplies=['EXACT_BOUND'])

def uniformity(node, world):
    if not node.payload.get('uniformity_verified'):
        return _obs('UNIFORMITY', node, 'UNIFORMITY_NOT_VERIFIED')
    return _result('UNIFORMITY', node, 'PASS', 'UNIFORMITY_RECEIPT', statement='UNIFORMITY_ACCEPTED', supplies=['UNIFORMITY_VERIFIED'])

def arithmetic_realizer(node, world):
    op = node.payload.get('arithmetic_operation')
    args = node.payload.get('arithmetic_operands')
    if op not in {'+', '-', '*', '/'} or not isinstance(args, (list, tuple)) or len(args) != 2:
        return _obs('ARITHMETIC_REALIZER', node, 'ARITHMETIC_REALIZER_NO_TYPED_OPERATION')
    try:
        a = Fraction(str(args[0]))
        b = Fraction(str(args[1]))
        val = {'+': a + b, '-': a - b, '*': a * b, '/': a / b}[op]
        return _result('ARITHMETIC_REALIZER', node, 'PASS', 'ARITHMETIC_RECEIPT', statement='EXACT_ARITHMETIC_REALIZED', value=[val.numerator, val.denominator], supplies=['EXACT_ARITHMETIC_RESULT'])
    except Exception as exc:
        return _result('ARITHMETIC_REALIZER', node, 'INVALID', 'INVALID_RESULT', statement='EXACT_ARITHMETIC_REJECTED', error=str(exc))

def provable_floor(node, world):
    x = node.payload.get('exact_rational')
    if not isinstance(x, (list, tuple)) or len(x) != 2:
        return _obs('PROVABLE_FLOOR', node, 'PROVABLE_FLOOR_NO_EXACT_RATIONAL')
    try:
        q = Fraction(int(x[0]), int(x[1]))
        f = math.floor(q)
        return _result('PROVABLE_FLOOR', node, 'PASS', 'FLOOR_RECEIPT', statement='PROVABLE_FLOOR_REALIZED', floor=f, supplies=['PROVABLE_FLOOR'])
    except Exception as exc:
        return _result('PROVABLE_FLOOR', node, 'INVALID', 'INVALID_RESULT', statement='PROVABLE_FLOOR_REJECTED', error=str(exc))

def exact_theorem_compiler(node, world):
    formal = node.payload.get('formal_statement')
    scientific = bool(world.get('target_grain_mode') or world.get('universal_recursive_mode') or world.get('ac60_gap_closure_mode'))
    if formal and node.payload.get('proof_object'):
        if not scientific:
            return _result('EXACT_THEOREM_COMPILER', node, 'PASS', 'THEOREM_COMPILATION_RECEIPT', statement='THEOREM_OBJECT_COMPILED', supplies=['SUPPORTED_FORMALIZATION'])
        base = str(node.payload.get('formal_target') or node.payload.get('target') or node.payload.get('statement') or '')
        return _result('EXACT_THEOREM_COMPILER', node, 'PASS', 'THEOREM_COMPILATION_RECEIPT', statement='THEOREM_OBJECT_COMPILED', formal_target=base, proof_object=node.payload.get('proof_object'), supplies=[f'SUPPORTED_FORMALIZATION::{base}' if base else 'SUPPORTED_FORMALIZATION'])
    if scientific:
        base = str(node.payload.get('formal_target') or node.payload.get('target') or node.payload.get('statement') or '')
        if formal and base:
            spec = {'schema': 'AC60_THEOREM_SEARCH_SPEC_V1', 'formal_target': base, 'formal_statement': formal, 'truth_claim': False}
            return _result('EXACT_THEOREM_COMPILER', node, 'OPEN', 'THEOREM_SEARCH_SPEC', statement='FORMAL_OBJECT_COMPILED_TO_PROOF_SEARCH', formal_target=base, formal_statement=formal, theorem_search_spec=spec, requires=[f'COMPLETE_PROOF_OBJECT::{base}'], supplies=[f'SUPPORTED_FORMALIZATION::{base}'], delta_cost=[1, 0, 0, 0])
    return _obs('EXACT_THEOREM_COMPILER', node, 'EXACT_THEOREM_COMPILER_WAIT_FORMAL_OBJECT')

def dual_cone(node, world):
    if node.payload.get('dual_cone_witness_verified'):
        return _result('DUAL_CONE', node, 'PASS', 'DUAL_CONE_RECEIPT', statement='DUAL_CONE_WITNESS_ACCEPTED', supplies=['SCOPED_DUAL_PROOF'])
    return _obs('DUAL_CONE', node, 'DUAL_CONE_NO_VERIFIED_WITNESS')

def lattice_realizer(node, world):
    if node.payload.get('integer_lattice') is not None:
        return _result('LATTICE_REALIZER', node, 'PASS', 'LATTICE_RECEIPT', statement='INTEGER_LATTICE_REALIZED', lattice=node.payload['integer_lattice'], supplies=['INTEGER_LATTICE_REALIZATION'])
    return _obs('LATTICE_REALIZER', node, 'LATTICE_REALIZER_NO_LATTICE_DATA')

def schur_complement(node, world):
    if node.payload.get('schur_witness') is not None:
        return _result('SCHUR_COMPLEMENT', node, 'PASS', 'SCHUR_RECEIPT', statement='SCHUR_WITNESS_ACCEPTED', witness=node.payload['schur_witness'])
    return _obs('SCHUR_COMPLEMENT', node, 'SCHUR_COMPLEMENT_NO_WITNESS')

def proof_engine(node, world):
    scientific = bool(world.get('target_grain_mode') or world.get('universal_recursive_mode') or world.get('ac60_gap_closure_mode'))
    if node.payload.get('proof_object') is not None:
        if not scientific:
            return _result('PROOF_ENGINE', node, 'PARTIAL', 'PROOF_CANDIDATE', statement='PROOF_OBJECT_PUBLISHED', proof_object=node.payload['proof_object'])
        return _result('PROOF_ENGINE', node, 'PARTIAL', 'PROOF_CANDIDATE', statement='PROOF_OBJECT_PUBLISHED', proof_object=node.payload['proof_object'], formal_target=node.payload.get('formal_target'))
    if scientific:
        base = str(node.payload.get('formal_target') or node.payload.get('target') or '')
        if base and (node.payload.get('formal_statement') is not None or node.kind in {'FORMAL_GOAL_PACKET', 'THEOREM_SEARCH_SPEC', 'WITNESS_SEARCH_PLAN'}):
            return _result('PROOF_ENGINE', node, 'OPEN', 'PROOF_SEARCH_NODE', statement='SCIENTIFIC_PROOF_SEARCH_OPEN', formal_target=base, formal_statement=node.payload.get('formal_statement'), requires=[f'COMPLETE_PROOF_OBJECT::{base}'], delta_cost=[1, 0, 0, 0])
    return _obs('PROOF_ENGINE', node, 'PROOF_ENGINE_NO_PROOF_OBJECT')

def falsification_factory(node, world):
    if node.payload.get('negated_goal') is not None:
        scientific = bool(world.get('target_grain_mode') or world.get('universal_recursive_mode') or world.get('ac60_gap_closure_mode'))
        if not scientific:
            return _result('FALSIFICATION_FACTORY', node, 'PARTIAL', 'PROOF_SEARCH_NODE', statement='NEGATED_GOAL_PUBLISHED', negated_goal=node.payload['negated_goal'])
        base = str(node.payload.get('formal_target') or node.payload.get('target') or node.payload.get('statement') or '')
        req = [f'COMPLETE_DUAL_OR_OBSTRUCTION::{base}'] if base else []
        return _result('FALSIFICATION_FACTORY', node, 'OPEN', 'COUNTEREXAMPLE_SEARCH_CURRENT', statement='NEGATED_GOAL_PUBLISHED', formal_target=base, negated_goal=node.payload['negated_goal'], requires=req, delta_cost=[1, 1, 0, 0])
    return _obs('FALSIFICATION_FACTORY', node, 'FALSIFICATION_FACTORY_NO_NEGATED_GOAL')

def co_relations(node, world):
    rel = node.payload.get('relations')
    if not rel:
        return _obs('CO_RELATIONS', node, 'CO_RELATIONS_NO_RELATIONS')
    return _result('CO_RELATIONS', node, 'PASS', 'CO_RELATION_RECEIPT', statement='CO_RELATIONS_TYPED', relation_digest=_sha(rel))

def derivation_projection_atlas(node, world):
    if not node.payload.get('derivation_map') and (not node.payload.get('projection_map')):
        return _obs('DERIVATION_PROJECTION_ATLAS', node, 'ATLAS_NO_TYPED_MAP')
    return _result('DERIVATION_PROJECTION_ATLAS', node, 'PASS', 'ATLAS_RECEIPT', statement='DERIVATION_PROJECTION_ATLAS_TYPED')

def minimal_law_synthesizer(node, world):
    if not node.payload.get('law_candidates'):
        return _obs('MINIMAL_LAW_SYNTHESIZER', node, 'MINIMAL_LAW_NO_CANDIDATES')
    c = sorted(node.payload['law_candidates'], key=lambda x: json.dumps(x, sort_keys=True, default=str))[0]
    return _result('MINIMAL_LAW_SYNTHESIZER', node, 'PARTIAL', 'LAW_CANDIDATE', statement='MINIMAL_LAW_CANDIDATE', candidate=c)

def causal_boundaries(node, world):
    b = node.payload.get('boundaries')
    if b is None:
        return _obs('CAUSAL_BOUNDARIES', node, 'CAUSAL_BOUNDARIES_NO_BOUNDARY')
    return _result('CAUSAL_BOUNDARIES', node, 'PASS', 'BOUNDARY_RECEIPT', statement='CAUSAL_BOUNDARIES_TYPED', boundaries=b)

def start2_replay(node, world):
    if node.payload.get('replay_packet') is None:
        return _obs('START2_REPLAY', node, 'START2_NO_REPLAY_PACKET')
    return _result('START2_REPLAY', node, 'PASS', 'REPLAY_RECEIPT', statement='START2_REPLAY_PACKET_ACCEPTED', replay_digest=_sha(node.payload['replay_packet']))

def sat_bridge(node, world):
    if node.payload.get('sat_instance') is None:
        return _obs('SAT_SOLVER_BRIDGE', node, 'SAT_BRIDGE_NO_INSTANCE')
    return _result('SAT_SOLVER_BRIDGE', node, 'PARTIAL', 'SAT_RECEIPT', statement='SAT_INSTANCE_PUBLISHED', instance_digest=_sha(node.payload['sat_instance']))

def tool_synthesizer(node, world):
    if node.kind == 'PARALLEL_TRANSPORT_LAW_RECEIPT' and isinstance(node.payload.get('transport_law'), dict):
        law = dict(node.payload['transport_law'])
        if not (law.get('exact_anchor_replay') and law.get('forward_reverse_same_law')):
            return _result('TOOL_SYNTHESIZER', node, 'INVALID', 'INVALID_RESULT', statement='PARALLEL_TRANSPORT_TOOL_REJECTED_NO_EXACT_REPLAY')
        spec = {'schema': 'EXECUTABLE_PARALLEL_ANCHOR_TRANSPORT_TOOL_V1', 'law_digest': law.get('law_digest'), 'minimal_polynomial_degree': law.get('minimal_polynomial_degree'), 'strict_parallelity': bool(law.get('strict_parallelity')), 'input': 'EXACT_ROUTE_COORDINATE', 'output': 'EXACT_TRANSPORTED_STATE', 'forward_reverse_same_law': True, 'anchor_replay_verified': True, 'domain_scientific_binding_required': True, 'unconditional_theorem': False}
        return _result('TOOL_SYNTHESIZER', node, 'PASS', 'EXECUTABLE_PARALLEL_TRANSPORT_TOOL', statement='EXECUTABLE_PARALLEL_ANCHOR_TRANSPORT_TOOL_COMPILED', executable_tool=spec, transport_law=law, tool_digest=_sha(spec), supplies=['EXECUTABLE_PARALLEL_TRANSPORT_TOOL'])
    if node.kind != 'CAUSAL_SPACE_RECEIPT':
        return _obs('TOOL_SYNTHESIZER', node, 'TOOL_SYNTHESIZER_WAIT_CAUSAL_SPACE_OR_PARALLEL_LAW')
    missing = list(node.payload.get('missing_edges') or [])
    if not missing:
        return _obs('TOOL_SYNTHESIZER', node, 'TOOL_SYNTHESIZER_NO_MISSING_EDGE')
    return _result('TOOL_SYNTHESIZER', node, 'PARTIAL', 'TOOL_CANDIDATE', statement='CANONICAL_TOOL_CANDIDATE', missing_edges=missing, tool_digest=_sha(missing))

def global_orbit(node, world):
    if not _is_global(node):
        return _obs('GLOBAL_ORBIT', node, 'GLOBAL_ORBIT_WAIT_COLLECTIVE')
    a=_global_current_analysis(node)
    if not a['valid_summary'] or a['group_count']==0:
        return _result('GLOBAL_ORBIT', node, 'INVALID', 'GLOBAL_ORBIT_RECEIPT', statement='GLOBAL_ORBIT_NO_VALID_CURRENT', scope=node.payload.get('collective_scope'), orbit_valid=False)
    return _result('GLOBAL_ORBIT', node, 'PASS' if a['invalid_group_count']==0 else 'PARTIAL', 'GLOBAL_ORBIT_RECEIPT', statement='GLOBAL_ORBIT_MEASURED', scope=node.payload.get('collective_scope'), orbit_valid=a['invalid_group_count']==0, group_count=a['group_count'], open_group_count=a['open_group_count'], partial_group_count=a['partial_group_count'])

def transversal(node, world):
    if node.kind not in {'COLLECTIVE_CURRENT', 'CORRELATION_LINK'}:
        return _obs('TRANSVERSAL', node, 'TRANSVERSAL_NO_CROSS_COMPONENT_TARGET')
    return _result('TRANSVERSAL', node, 'PARTIAL', 'TRANSVERSAL_RECEIPT', statement='TRANSVERSAL_AUDITED', scope='::'.join(node.context))

def full_toolbox(node, world):
    if not _scientific(node):
        return _obs('FULL_TOOLBOX', node, 'FULL_TOOLBOX_NO_SCIENTIFIC_TARGET')
    ids = list(world.get('active_mechanism_ids') or [])
    return _result('FULL_TOOLBOX', node, 'PASS', 'FULL_TOOLBOX_RECEIPT', statement='FULL_TOOLBOX_ENUMERATED', active_mechanism_count=len(ids), active_mechanism_digest=_sha(ids), all_everything_mode=bool(world.get('all_everything_mode')))

def everything_global_bundle(node, world):
    if not _is_global(node):
        return _obs('ALL_MODULES_AUX_TOOLS_EVERYTHING_GLOBAL_BUNDLE', node, 'EVERYTHING_BUNDLE_WAIT_GLOBAL_CURRENT')
    ids = list(world.get('active_mechanism_ids') or [])
    cats = world.get('active_mechanism_categories') or {}
    return _result('ALL_MODULES_AUX_TOOLS_EVERYTHING_GLOBAL_BUNDLE', node, 'PASS', 'EVERYTHING_BUNDLE_RECEIPT', statement='ALL_MODULES_AUX_TOOLS_EVERYTHING_AUDITED', active_mechanism_count=len(ids), categories=sorted(set(cats.values())), registry_digest=_sha(ids), supplies=['ALL_EVERYTHING_AUDITED'])
EXTRA_MECHANISMS = {'LOCAL_MULTIMETER': local_multimeter, 'LOCAL_GROUND_TESTER': local_ground, 'LOCAL_INSULATION_TESTER': local_insulation, 'GLOBAL_MULTIMETER': global_multimeter, 'GLOBAL_GROUND_TESTER': global_ground, 'GLOBAL_INSULATION_TESTER': global_insulation, 'CAUSAL_SPACE': causal_space, 'TEMPORAL': temporal, 'BABEL': babel, 'BORGES': borges, 'UNIVERSAL_WHEEL': universal_wheel, 'CAUSAL_GAUGE': causal_gauge, 'RESISTANCE_BANK': resistance_bank, 'RESISTANCE_PHI': resistance_phi, 'RESISTANCE_SQRT2': resistance_sqrt2, 'RESISTANCE_SQRT3': resistance_sqrt3, 'RESISTANCE_LN5': resistance_ln5, 'RESISTANCE_PI': resistance_pi, 'NATIVE_PLUS': native_plus, 'NATIVE_MINUS': native_minus, 'NATIVE_TIMES': native_times, 'NATIVE_DIVIDE': native_divide, 'NATIVE_PI1': native_pi1, 'AUTO_CARRIER': auto_carrier, 'AUTO_MATERIALIZATION': auto_materialization, 'ARTIFACT_RECOVERY_ADAPTER': artifact_recovery_adapter, 'RECURSIVE_BRIDGE_ADAPTER': recursive_bridge, 'COORDINATE_REALIZER': coordinate_realizer, 'FIBRE': fibre, 'BOUND_REALIZER': bound_realizer, 'UNIFORMITY': uniformity, 'ARITHMETIC_REALIZER': arithmetic_realizer, 'PROVABLE_FLOOR': provable_floor, 'EXACT_THEOREM_COMPILER': exact_theorem_compiler, 'DUAL_CONE': dual_cone, 'LATTICE_REALIZER': lattice_realizer, 'SCHUR_COMPLEMENT': schur_complement, 'PROOF_ENGINE': proof_engine, 'FALSIFICATION_FACTORY': falsification_factory, 'CO_RELATIONS': co_relations, 'DERIVATION_PROJECTION_ATLAS': derivation_projection_atlas, 'MINIMAL_LAW_SYNTHESIZER': minimal_law_synthesizer, 'CAUSAL_BOUNDARIES': causal_boundaries, 'START2_REPLAY': start2_replay, 'SAT_SOLVER_BRIDGE': sat_bridge, 'TOOL_SYNTHESIZER': tool_synthesizer, 'GLOBAL_ORBIT': global_orbit, 'TRANSVERSAL': transversal, 'FULL_TOOLBOX': full_toolbox, 'ALL_MODULES_AUX_TOOLS_EVERYTHING_GLOBAL_BUNDLE': everything_global_bundle, 'UNIVERSAL_GAP_CLOSURE': universal_gap_closure}
EXTRA_CATEGORIES = {**{k: 'METER_TESTER' for k in ('LOCAL_MULTIMETER', 'LOCAL_GROUND_TESTER', 'LOCAL_INSULATION_TESTER', 'GLOBAL_MULTIMETER', 'GLOBAL_GROUND_TESTER', 'GLOBAL_INSULATION_TESTER')}, **{k: 'CANONICAL_SPACE' for k in ('CAUSAL_SPACE', 'TEMPORAL', 'BABEL', 'BORGES', 'UNIVERSAL_WHEEL')}, **{k: 'GAUGE_RESISTANCE' for k in ('CAUSAL_GAUGE', 'RESISTANCE_BANK', 'RESISTANCE_PHI', 'RESISTANCE_SQRT2', 'RESISTANCE_SQRT3', 'RESISTANCE_LN5', 'RESISTANCE_PI')}, **{k: 'NATIVE_CYCLE' for k in ('NATIVE_PLUS', 'NATIVE_MINUS', 'NATIVE_TIMES', 'NATIVE_DIVIDE', 'NATIVE_PI1')}, **{k: 'NATIVE_VALVE' for k in ('AUTO_CARRIER', 'AUTO_MATERIALIZATION', 'ARTIFACT_RECOVERY_ADAPTER', 'RECURSIVE_BRIDGE_ADAPTER', 'COORDINATE_REALIZER', 'FIBRE', 'BOUND_REALIZER', 'UNIFORMITY', 'ARITHMETIC_REALIZER', 'PROVABLE_FLOOR', 'EXACT_THEOREM_COMPILER')}, **{k: 'MATHEMATICS' for k in ('DUAL_CONE', 'LATTICE_REALIZER', 'SCHUR_COMPLEMENT', 'PROOF_ENGINE', 'FALSIFICATION_FACTORY', 'SAT_SOLVER_BRIDGE')}, **{k: 'STRUCTURAL_TOOL' for k in ('CO_RELATIONS', 'DERIVATION_PROJECTION_ATLAS', 'MINIMAL_LAW_SYNTHESIZER', 'CAUSAL_BOUNDARIES', 'START2_REPLAY', 'TOOL_SYNTHESIZER')}, **{k: 'SYSTEM_FABRIC' for k in ('GLOBAL_ORBIT', 'TRANSVERSAL', 'FULL_TOOLBOX', 'ALL_MODULES_AUX_TOOLS_EVERYTHING_GLOBAL_BUNDLE')}, 'UNIVERSAL_GAP_CLOSURE': 'UNIVERSAL_GAP_CLOSURE'}
