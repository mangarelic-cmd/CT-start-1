from __future__ import annotations
from pathlib import Path
import json, sys, math
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from all_everything_wave_engine import Node, AllEverythingWaveEngine
from sovereign_aux import REGISTRY, MECHANISM_CATEGORIES, correlation
from sovereign_solver import SovereignSolver
from proof_reconstruction_orchestrator import fabric_audit, reconstruct
from automation_reconciliation_ac66 import (
    sovereign_root_lock,full_delta_compiler,first_solution_field_localizer,
    semantic_projection_bundle,closure_mode_action_compiler,negative_knowledge_skin_manager,
    wrapper_eliminator,open_status_anti_omission,local_global_transducer,
    root_dependence_polarity_auditor,finite_scope_claim_firewall,route_point_grounding_auditor,
    sin2_quadrature_deriver,dependency_readiness_auditor,proof_residual_attacker,
    payment_remerge_auditor,transitive_closure_frontier_reducer,resource_checkpoint_resume_compiler,
    sin2_continuation_rectifier,scientific_signature
)

def N(kind='PROBLEM',**p): return Node(kind,p,context=('AC67','QUAL'))

def direct_checks():
    checks={}
    checks['root_lock']=sovereign_root_lock(N(statement='Q',scientific_focus=True,sovereign_root_id='R',attempted_root_replacement='C'),{}).payload['repair_required'] is True
    checks['full_delta']=full_delta_compiler(N(statement='Q',scientific_focus=True,current_state_coordinate=2,first_solution_field_coordinate=4),{}).payload['full_delta']==2
    checks['first_solution_no_invent']=first_solution_field_localizer(N(statement='Q',scientific_focus=True,primegrid_solution_address='PG',temporal_solution_position='T',solution_field_constraints=['f=0']),{}).payload.get('invent_coordinate_forbidden') is True
    p=semantic_projection_bundle(N(statement='Q',scientific_focus=True,arithmetic_operation='+',arithmetic_operands=[1,2]),{})
    eng=AllEverythingWaveEngine({},lambda *a,**k:[])
    currents=eng.compile_semantic_projection_currents([p.as_node(1,('AC67','QUAL'))],2)
    checks['projection_materialized']=any(x.payload.get('projection_view')=='ARITHMETIC' and x.payload.get('arithmetic_operation')=='+' for x in currents)
    ca=closure_mode_action_compiler(N(statement='Q',scientific_focus=True,status='OPEN_WITH_PAID_X',requires=['SERIALIZE_X','PROVE_GLOBAL_X','COMPUTE_SCHUR_X']),{})
    checks['closure_actions']=ca.payload.get('action_count')==3 and ca.payload.get('manual_action_request_authoring_required') is False
    w={}; nr=negative_knowledge_skin_manager(N(statement='NO',status='NO_GO',no_go_verified=True,route_signature='R1'),w)
    checks['negative_skin']=nr.status=='PASS' and 'R1' in w.get('_ac66_negative_knowledge',{})
    checks['wrapper']=wrapper_eliminator(N(statement='W',requires=['COMPLETE_PROOF_OBJECT::FORMAL_GOAL::X']),{}).payload.get('independent_scientific_debt') is False
    checks['enriched_open']=open_status_anti_omission(N(status='OPEN_WITH_PAID_RESULTANT_SUPPLY'),{}).payload.get('must_not_be_dropped') is True
    classes={
        'TAIL remainder':'TAIL_REMAINDER_DOMINATION',
        'coercivity hidden direction':'COERCIVITY_HIDDEN_DIRECTION_ORIENTATION',
        'return map provenance':'INVERSE_PROVENANCE_EXACT_RETURN_MAP',
        'uniform for every global':'UNIFORMIZATION_ROOT_INDEPENDENCE',
        'well-founded descent termination':'LOCAL_TO_GLOBAL_WELL_FOUNDEDNESS'}
    checks['local_global_all5']=all(local_global_transducer(N(statement=t,scientific_focus=True),{}).payload.get('deficit_class')==c for t,c in classes.items())
    pol=root_dependence_polarity_auditor(N(root_sensitive=True,uses_root_assumption=False,root_used_as_premise=False,assumes_root_equivalent=False,unpaid_root_equivalent_premise=False,unpaid_root_bearing_premise=False,dependency_cycle_reaches_root=False,premise_independently_certified=True,conclusion_implies_root=True),{})
    checks['polarity']=pol.payload.get('admissible_provider') is True
    checks['finite_scope']=finite_scope_claim_firewall(N(proof_scope_kind='FINITE',claim_scope_kind='UNIVERSAL'),{}).payload.get('scientific_promotion_allowed') is False
    rg=route_point_grounding_auditor(N(route_points=[{'x':1,'t':2,'metric_authority':False,'coordinate_role':'ORDINAL','coordinate_provenance_kind':'LEDGER_COUNT'}]),{})
    checks['route_grounding']=rg.payload.get('external_metric_authority') is False and rg.payload.get('internal_geometry_allowed') is True
    q=sin2_quadrature_deriver(N(sin1_angle=0.0,sin1_energy=0.5,carrier_orientation='CCW'),{})
    checks['sin2_quadrature']=q.payload.get('independent_second_search_required') is False and abs(q.payload.get('sin2_angle')-math.pi/2)<1e-12
    dep=dependency_readiness_auditor(N(prerequisite_supplies=['A','B'],available_supplies=['A']),{})
    checks['dependency']=dep.payload.get('movement_blocked') is False and dep.payload.get('closure_claim_blocked') is True
    remerge=payment_remerge_auditor(N(status='OPEN',requires=['A','B'],paid_requirement_receipts={'A':{'state':'PAID_DIRECT','evidence':'x'}}),{})
    checks['payment_remerge']=remerge.payload.get('paid_requirements')==['A'] and remerge.payload.get('remaining_requirements')==['B']
    tr=transitive_closure_frontier_reducer(N(closure_actions=[{'action_id':'A'},{'action_id':'B','depends_on':['A']}]),{})
    checks['transitive_frontier']=tr.payload.get('independent_front_ids')==['A']
    rc=resource_checkpoint_resume_compiler(N('RESOURCE_CHECKPOINT',status='RESOURCE_CHECKPOINT',statement='X',next_offset=4),{})
    checks['resource_resume']=rc.payload.get('not_impossibility') is True and rc.payload.get('resume_from')==4
    sx=sin2_continuation_rectifier(N('SIN2_NODE',sin2_closed=False,scientific_residual='R'),{})
    checks['sin2_rectifier']=sx.payload.get('waiting_state_forbidden') is True and sx.result_kind=='SCIENTIFIC_CONSTRUCTION_CURRENT'
    return checks

def proof_checks():
    exact={'target':'T','claims':[{'id':'A','verifier':{'kind':'SYMBOLIC_IDENTITY','symbols':['a'],'lhs':'a','rhs':'a'}},{'id':'B','verifier':{'kind':'SYMBOLIC_IDENTITY','symbols':['b'],'lhs':'b','rhs':'b'}}], 'edges':[{'id':'M','from':['A','B'],'to':'T','rule':'MULTI_PARENT_DAG_MERGE','proof_object':{'verified':True,'conclusion':'T'}}]}
    r1=reconstruct(exact)
    bad={'target':'T','claims':[{'id':'A','scientific_claim':True,'claim_scope_kind':'UNIVERSAL','verifier':{'kind':'BOOLEAN_ASSERTIONS','checks':[True],'scope_kind':'FINITE','independent_authority':True}}], 'edges':[],'geometry_evidence':[{'pythagorean_pass':True}]}
    r2=reconstruct(bad)
    attacker=proof_residual_attacker(N('FORMAL_PROOF_CURRENT',proof_target='T',proof_residuals=r2['proof_residuals']),{})
    return {'multi_parent_proved':r1['formal_proof_verified'],'finite_geometry_not_root':not r2['formal_proof_verified'],'failed_proof_unknown':r2['epistemic_status']=='UNKNOWN' and not r2['refuted_claim_ids'],'residual_reinjected':attacker.status=='OPEN' and attacker.payload.get('proof_failure_is_not_refutation') is True}

def solver_checks():
    exact={'target':'S','claims':[{'id':'A','verifier':{'kind':'SYMBOLIC_IDENTITY','symbols':['a'],'lhs':'a','rhs':'a'}}], 'edges':[{'id':'A_TO_S','from':['A'],'to':'S','rule':'EXPLICIT_PROOF_OBJECT','proof_object':{'verified':True,'conclusion':'S'}}]}
    seed=N(statement='QUAL_ROOT',scientific_focus=True,sovereign_root_id='QUAL_ROOT',proof_reconstruction_spec=exact)
    run=SovereignSolver().solve_universal([seed],max_waves=4,max_calls=15000)
    structural=Node('ROOT_RECEIPT',{'kernel_verified':True,'external_scientific_truth_certified':False})
    no_structural_root=SovereignSolver()._root([structural]) is None
    return {'formal_root_certified':run['formal_proof_verified'] is True and run['run_state']=='SOLUTION_CERTIFIED','mechanism_count':run['active_mechanism_count'],'all_mechanisms_registered':run['active_mechanism_count']==len(REGISTRY)==98,'semantic_common_trunk_present':run['scientific_common_trunk_unique_count']>0,'structural_root_rejected':no_structural_root,'execution_calls':run['execution_calls']}

def main():
    fabric=fabric_audit(); dc=direct_checks(); pc=proof_checks(); sc=solver_checks()
    out={'schema':'AC67_ELECTRICAL_GLOBAL_CURRENT_HARDENING_QUALIFICATION_V1','mechanism_count':len(REGISTRY),'mechanism_category_count':len(MECHANISM_CATEGORIES),'theorem_fabric':fabric,'direct_checks':dc,'proof_checks':pc,'solver_checks':sc}
    checks=list(dc.values())+list(pc.values())+[sc['formal_root_certified'],sc['all_mechanisms_registered'],sc['semantic_common_trunk_present'],sc['structural_root_rejected'],fabric['pass'],fabric['exact_backend_count']==217]
    out['check_count']=len(checks); out['pass_count']=sum(bool(x) for x in checks); out['pass']=all(checks)
    print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__': main()
