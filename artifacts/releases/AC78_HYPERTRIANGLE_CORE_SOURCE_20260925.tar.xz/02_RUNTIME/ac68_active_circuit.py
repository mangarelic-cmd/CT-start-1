from __future__ import annotations
import hashlib, json, re
from typing import Any, Dict, Iterable, List, Tuple
from all_everything_wave_engine import Node, AuxResult, context_can_supply
from proof_reconstruction_orchestrator import theorem_search
from universal_everything_mechanisms import _global_current_analysis

GENERIC = {
    'FORMAL','GOAL','OBJECT','CURRENT','SCIENTIFIC','PROOF','EXACT','COMPLETE','SUPPORTED',
    'REQUIREMENT','SUPPLY','RESULT','RECEIPT','TARGET','GLOBAL','LOCAL','OPEN','CLOSURE',
    'CANDIDATE','DATA','STATE','MODEL','AUX','AC68','AC67','ROOT','SEMANTIC','PROJECTION',
}

def _canon(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False, default=str)

def _sha(x):
    return hashlib.sha256(_canon(x).encode()).hexdigest()

def _list(x):
    if x is None: return []
    if isinstance(x,(list,tuple,set)): return [str(v) for v in x if str(v)]
    return [str(x)] if str(x) else []

def _tokens(s: str) -> set[str]:
    parts = {x for x in re.split(r'[^A-Z0-9]+', str(s).upper()) if len(x) >= 2}
    return {x for x in parts if x not in GENERIC and not x.isdigit()}

def _provider_surface(n: Node) -> List[str]:
    p=n.payload
    vals=[]
    vals += _list(p.get('supplies'))
    for k in ('statement','obligation','target_obligation','formal_target','formal_statement','returned_effect'):
        if p.get(k): vals.append(str(p.get(k)))
    return sorted(set(vals))

def _candidate_score(req: str, surface: str, provider: Node, consumer_ctx: Tuple[str,...]) -> Tuple[int,int,int,int]:
    rt=_tokens(req); st=_tokens(surface)
    overlap=len(rt & st)
    union=max(1,len(rt | st))
    # integer score avoids float non-determinism in ordering
    lexical=(1000*overlap)//union
    exactish=1 if str(req).upper() in str(surface).upper() or str(surface).upper() in str(req).upper() else 0
    same_context=1 if tuple(provider.context)==tuple(consumer_ctx) else 0
    rooted=1 if not provider.context else 0
    return (exactish, lexical, same_context, rooted)

def candidate_providers(req: str, nodes: Iterable[Node], consumer_ctx: Tuple[str,...], limit: int=8) -> List[Dict[str,Any]]:
    rows=[]
    for n in nodes:
        # Candidate search is intentionally broader than exact supply matching, but never promoted to truth.
        # AC68-generated closure/bridge/probe objects are excluded to prevent self-correlation resonance.
        if n.kind in {'REQUIREMENT_CLOSURE_CURRENT','CORRELATION_CANDIDATE_LINK','REQUIREMENT_BACKEND_RECEIPT'} or n.payload.get('ac68_open_circuit') or n.payload.get('candidate_is_not_exact_supply'):
            continue
        if str(n.payload.get('statement') or '').startswith('AC68_'):
            continue
        if not (context_can_supply(tuple(n.context), tuple(consumer_ctx)) or tuple(consumer_ctx)==()):
            continue
        best=None
        for s in _provider_surface(n):
            sc=_candidate_score(req,s,n,consumer_ctx)
            if sc[0]==0 and sc[1]==0:
                continue
            row={'provider_id':n.identity(),'provider_kind':n.kind,'provider_context':list(n.context),'surface':s,
                 'score':{'substring':sc[0],'lexical_milli':sc[1],'same_context':sc[2],'rooted':sc[3]},
                 'scientific_promotion':False}
            if best is None or (sc, s, n.identity()) > (tuple(best['_rank']), best['surface'], best['provider_id']):
                row['_rank']=list(sc); best=row
        if best is not None:
            rows.append(best)
    rows.sort(key=lambda r:(tuple(r['_rank']),r['surface'],r['provider_id']), reverse=True)
    out=[]
    seen=set()
    for r in rows:
        key=(r['provider_id'],r['surface'])
        if key in seen: continue
        seen.add(key); r=dict(r); r.pop('_rank',None); out.append(r)
        if len(out)>=limit: break
    return out

def _root_supplies(nodes: Iterable[Node]) -> List[str]:
    out=set()
    for n in nodes:
        if tuple(n.context)!=():
            continue
        for s in _list(n.payload.get('supplies')):
            out.add(s)
        if n.kind=='CORRELATION_LINK' and n.payload.get('token'):
            out.add(str(n.payload['token']))
        if n.kind=='NODE_RETURN_RECEIPT' and n.payload.get('returned_effect'):
            out.add(str(n.payload['returned_effect']))
    return sorted(out)

def active_correlation_nodes(nodes: Iterable[Node], wave: int, world: Dict[str,Any]) -> List[Node]:
    nodes=list(nodes); out=[]
    root_currents=[n for n in nodes if n.kind=='COLLECTIVE_CURRENT' and tuple(n.context)==()]
    for cur in root_currents:
        a=_global_current_analysis(cur)
        if not a.get('valid_summary') or a.get('group_count',0)==0:
            continue
        unresolved=list(a.get('unresolved_requirements') or [])
        continuity=a.get('continuity_ratio',0.0)
        root_id=cur.payload.get('sovereign_root_id') or cur.payload.get('inherited_sovereign_root_id')
        # Convert every open branch of the global circuit into an active scientific current.
        for req in unresolved:
            cand=candidate_providers(req,nodes,(),limit=int(world.get('ac68_candidate_provider_limit',8)))
            payload={
                'status':'OPEN','statement':'AC68_CLOSE_REQUIREMENT::'+req,
                'target_obligation':req,'requires':[req],
                'scientific_focus':True,'sovereign_focus':True,
                'sovereign_root_id':root_id,'inherited_sovereign_root_id':root_id,
                'ac68_open_circuit':True,'ac68_requirement_depth':0,
                'source_collective_current':cur.identity(),
                'global_continuity_at_spawn':continuity,
                'candidate_providers_are_separate_hypotheses_not_supplies':True,
                'truth_credit_added':0,'external_scientific_truth_certified':False,
            }
            req_node=Node('REQUIREMENT_CLOSURE_CURRENT',payload,(cur.identity(),),wave,())
            out.append(req_node)
            for c in cand[:4]:
                bridge='EXACT_BRIDGE::'+str(c['surface'])+'=>'+req
                out.append(Node('CORRELATION_CANDIDATE_LINK',{
                    'status':'PARTIAL','statement':'AC68_CANDIDATE_SUPPLY_BRIDGE::'+req,
                    'relation':'CANDIDATE_SUPPLY','target_requirement':req,
                    'candidate_provider_id':c['provider_id'],'candidate_provider_kind':c['provider_kind'],
                    'candidate_surface':c['surface'],'candidate_score':c['score'],
                    'requires':[bridge],'scientific_focus':True,'sovereign_focus':True,
                    'sovereign_root_id':root_id,'candidate_is_not_exact_supply':True,
                    'truth_credit_added':0,'external_scientific_truth_certified':False,
                    'delta_cost':[0,1000-int(c['score']['lexical_milli']),0 if c['score']['same_context'] else 1,len(req)]
                },(cur.identity(),c['provider_id']),wave,()))
        # Recalculate the current if new exact root supplies have appeared anywhere in the skin.
        root_sup=_root_supplies(nodes)
        new_exact=sorted(set(unresolved) & set(root_sup))
        if new_exact:
            groups=[dict(g) for g in (cur.payload.get('summary',{}).get('groups') or []) if isinstance(g,dict)]
            groups.append({'id':'AC68_REBROADCAST_SUPPLIES','status':'SCOPED_CLOSED','statement':'AC68 exact supplies discovered after recursive rebroadcast','requires':[],'supplies':new_exact,'ground_binding':True})
            p=dict(cur.payload)
            p.update({
                'statement':'AC68_RECOMPUTED_COLLECTIVE_CURRENT','summary':{'groups':groups},
                'ac68_recomputed':True,'ac68_new_exact_supplies':new_exact,
                'parent_collective_current':cur.identity(),
                'truth_credit_added':0,'external_scientific_truth_certified':False,
            })
            out.append(Node('COLLECTIVE_CURRENT',p,(cur.identity(),)+tuple(sorted(n.identity() for n in nodes if any(x in _list(n.payload.get('supplies')) for x in new_exact))),wave,()))
    return _dedup(out)

def _dedup(nodes: Iterable[Node]) -> List[Node]:
    d={}
    for n in nodes:
        d[n.semantic_identity()]=n
    return [d[k] for k in sorted(d)]

def requirement_backend_probe(node: Node, world: Dict[str,Any]) -> AuxResult:
    if node.kind!='REQUIREMENT_CLOSURE_CURRENT':
        return AuxResult('REQUIREMENT_BACKEND_PROBE','NOT_APPLICABLE','MECHANISM_OBSERVATION',{'statement':'REQUIREMENT_BACKEND_PROBE_WAIT_REQUIREMENT_CURRENT'},node.identity())
    req=str(node.payload.get('target_obligation') or '')
    if not req:
        return AuxResult('REQUIREMENT_BACKEND_PROBE','NEED_DATA','REQUIREMENT_BACKEND_RECEIPT',{'statement':'REQUIREMENT_BACKEND_PROBE_MISSING_TARGET','requires':['TARGET_OBLIGATION']},node.identity())
    raw={
        'statement':node.payload.get('statement'),'target_requirement':req,
        'candidate_providers':node.payload.get('candidate_providers') or [],
        'source_collective_current':node.payload.get('source_collective_current'),
        'context':list(node.context),
    }
    try:
        sr=theorem_search(raw,req)
        route=sr.get('route') or {}
        executed=int(route.get('executed_exact_count') or 0)
        detected=int(route.get('detected_exact_count') or 0)
        structural=sr.get('structural_candidates') or []
        payload={
            'statement':'REQUIREMENT_THEOREM_FABRIC_PROBED','target_requirement':req,
            'theorem_fabric_exact_backend_count':int(route.get('exact_backend_theorem_count') or 217),
            'detected_exact_count':detected,'executed_exact_count':executed,
            'theorem_route':route,'structural_candidates':structural,
            'scientific_promotion':False,'truth_credit_added':0,
            'external_scientific_truth_certified':False,
            'supplies':['BACKEND_INFORMATION::'+req],
            'requires':([] if executed else ['EXACT_THEOREM_OR_CONSTRUCTION::'+req]),
        }
        # Even an executed backend is evidence, not automatic external proof of the scientific requirement.
        if executed:
            payload['requires']=['SCIENTIFIC_PROMOTION_BRIDGE::'+req]
        return AuxResult('REQUIREMENT_BACKEND_PROBE','PARTIAL','REQUIREMENT_BACKEND_RECEIPT',payload,node.identity())
    except Exception as exc:
        return AuxResult('REQUIREMENT_BACKEND_PROBE','OPEN','REQUIREMENT_BACKEND_RECEIPT',{
            'statement':'REQUIREMENT_THEOREM_FABRIC_PROBE_ERROR','target_requirement':req,
            'error':str(exc),'requires':['THEOREM_FABRIC_REPLAY::'+req],
            'scientific_promotion':False,'truth_credit_added':0,
        },node.identity())

def registry_fragment():
    return {'REQUIREMENT_BACKEND_PROBE': requirement_backend_probe}

def category_fragment():
    return {'REQUIREMENT_BACKEND_PROBE':'ACTIVE_CORRELATION'}
