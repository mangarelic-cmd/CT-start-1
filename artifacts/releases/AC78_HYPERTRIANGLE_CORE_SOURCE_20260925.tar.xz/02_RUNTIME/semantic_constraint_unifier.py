from __future__ import annotations
from typing import Any, Dict, List, Optional, Tuple
from difflib import SequenceMatcher
import hashlib, json, re

# AC76 is deliberately conservative. Semantic similarity can expose candidate
# equivalence/overlap/conflict, but cannot create truth, precedence, or CT authority.

MODAL_RE = re.compile(r"\b(must\s+not|shall\s+not|do\s+not|should\s+not|may\s+not|must|shall|should|may|never)\b", re.I)
CONDITION_RE = re.compile(r"^(when|if|before|after|while|where|once|until)\s+(.+?),\s*(.+)$", re.I)
EXCEPTION_RE = re.compile(r"\b(unless|except(?:\s+when|\s+where|\s+for)?)\b\s+(.+?)(?:[.;]|$)", re.I)

STOP = {
    'a','an','the','this','that','these','those','of','to','for','from','with','without','and','or','but','as','at','by','on','in','into','through','across','per','via',
    'is','are','be','been','being','was','were','it','its','they','their','them','which','who','whose','where','when','while','then','than','also','only','merely','simply','does','did','one','others','other','imply','implies','passing','pass',
    'current','actual','ordinary','appropriate','relevant','material','meaningful','explicit','explicitly','genuine','genuinely','real','really','practical','normal','default',
    'must','shall','should','may','not','do','never','can','could','would','will','need','needs','required','requires','requiring','according','rather','instead','such','other',
}

# General lexical canonicalization. It is not specific to the Gold Standard.
SYN = {
    'modify':'change','modified':'change','modification':'change','changing':'change','edit':'change','edited':'change','mutate':'change','mutation':'change',
    'delete':'remove','deleted':'remove','deletion':'remove','retire':'remove','retired':'remove','discard':'remove','discarded':'remove','prune':'remove','cleanup':'remove','clean':'remove',
    'preserve':'keep','preserved':'keep','retained':'keep','retain':'keep','keeping':'keep','protect':'keep','protected':'keep','protection':'keep',
    'validate':'verify','validated':'verify','validation':'verify','verified':'verify','verification':'verify','prove':'verify','proof':'verify','check':'verify','checked':'verify',
    'inspect':'observe','inspection':'observe','inspectable':'observe','observed':'observe','observable':'observe','review':'observe','reviewed':'observe',
    'repository':'repo','repositories':'repo','git':'repo','checkout':'repo','worktree':'repo','workspace':'repo','workspaces':'repo',
    'file':'file','files':'file','folder':'file','folders':'file','directory':'file','directories':'file','path':'file','paths':'file',
    'user-owned':'userstate','user':'user','users':'user','data':'data','settings':'setting','setting':'setting','state':'state','content':'content',
    'credential':'secret','credentials':'secret','token':'secret','tokens':'secret','password':'secret','passwords':'secret','key':'secret','keys':'secret','secrets':'secret',
    'evidence':'evidence','report':'evidence','reports':'evidence','screenshot':'evidence','screenshots':'evidence','log':'evidence','logs':'evidence','artifact':'artifact','artifacts':'artifact',
    'runtime':'runtime','package':'package','packages':'package','build':'build','builds':'build','test':'test','tests':'test','testing':'test','harness':'harness','harnesses':'harness',
    'failure':'fail','failed':'fail','fails':'fail','error':'fail','errors':'fail','defect':'defect','defects':'defect','bug':'defect','bugs':'defect',
    'complete':'complete','completion':'complete','completed':'complete','finish':'complete','finished':'complete','done':'complete',
    'external':'external','public':'public','production':'production','live':'production','hosted':'hosted','remote':'remote','local':'local',
    'rule':'rule','rules':'rule','requirement':'rule','requirements':'rule','policy':'policy','policies':'policy','instruction':'instruction','instructions':'instruction',
    'safe':'safety','safely':'safety','safety':'safety','secure':'security','security':'security','privacy':'privacy','legal':'legal','licensing':'license','license':'license',
    'ownership':'owner','owner':'owner','owned':'owner','authority':'authority','authoritative':'authority','permission':'authority','permissions':'authority',
    'precedence':'precedence','priority':'precedence','priorities':'precedence','override':'precedence','overrides':'precedence','overridden':'precedence','outrank':'precedence','outranks':'precedence','govern':'precedence','governs':'precedence',
    'temporary':'temporary','transient':'temporary','disposable':'temporary','stale':'stale','old':'stale','historical':'stale','prior':'stale','previous':'stale',
    'current':'current','fresh':'current','latest':'current','newer':'current','new':'current',
    'unknown':'unknown','uncertain':'unknown','uncertainty':'unknown','unresolved':'unknown',
    'continue':'continue','continuation':'continue','resume':'continue','restart':'restart','starting':'restart','start':'restart',
    'scope':'scope','boundary':'scope','boundaries':'scope','bounded':'scope','limit':'limit','limits':'limit','limitation':'limit','limitations':'limit',
}

LEADING_ACTIONS = {
    'work':'OPERATE','treat':'TREAT_AS','follow':'FOLLOW','judge':'ASSESS','push':'EXECUTE','merge':'EXECUTE','release':'EXECUTE','deploy':'EXECUTE',
    'audit':'AUDIT','amend':'AMEND','parse':'PARSE','use':'USE','normalize':'NORMALIZE','read':'READ','persist':'PERSIST','block':'BLOCK','represent':'REPRESENT',
    'support':'SUPPORT','define':'DEFINE','maintain':'MAINTAIN','deliver':'DELIVER','inspect':'INSPECT','encode':'ENCODE','inventory':'INVENTORY','apply':'APPLY',
    'keep':'PRESERVE','preserve':'PRESERVE','retain':'PRESERVE','remove':'RETIRE','retire':'RETIRE','record':'REPORT','document':'REPORT','report':'REPORT',
    'separate':'CLASSIFY','distinguish':'CLASSIFY','classify':'CLASSIFY','prefer':'PREFER','require':'REQUIRE','ensure':'REQUIRE','provide':'REQUIRE','establish':'REQUIRE',
}

OPPOSITE_FAMILIES = {
    'REQUIRE': {'PROHIBIT'}, 'PROHIBIT': {'REQUIRE','ALLOW'}, 'ALLOW': {'PROHIBIT'},
    'PRESERVE': {'RETIRE'}, 'RETIRE': {'PRESERVE'}, 'CONTINUE': {'STOP'}, 'STOP': {'CONTINUE'},
}


def _clean(s: Any) -> str:
    s=str(s or '').replace('\u2011','-').replace('\u2013','-').replace('\u2014','-').replace('\ufffe','')
    s=re.sub(r'\s+',' ',s).strip()
    return re.sub(r'^\s*\d+\.\s*','',s)


def _sha(x: Any) -> str:
    return hashlib.sha256(json.dumps(x,sort_keys=True,separators=(',',':'),ensure_ascii=False,default=str).encode()).hexdigest()


def canonical_operator(text: str, fallback: Optional[str]=None) -> str:
    t=_clean(text); u=' '+t.upper()+' '
    cm=CONDITION_RE.match(t)
    if cm:
        return canonical_operator(cm.group(3), fallback)
    # Explicit precedence/declarative relations are checked before leading nouns.
    if re.search(r'\b(OUTRANKS?|TAKES?\s+PRECEDENCE|OVERRIDES?|GOVERNS?)\b',u): return 'PRECEDENCE'
    if re.search(r'\b(MUST\s+NOT|SHALL\s+NOT|DO\s+NOT|NEVER|MAY\s+NOT)\b',u): return 'PROHIBIT'
    if re.search(r'\b(MUST|SHALL|IS\s+REQUIRED\s+TO|ARE\s+REQUIRED\s+TO|REQUIRES?|NEEDS?)\b',u): return 'REQUIRE'
    if re.search(r'\bSHOULD\s+NOT\b',u): return 'PREFER_NOT'
    if re.search(r'\bSHOULD\b',u): return 'PREFER'
    if re.search(r'\bMAY\b',u): return 'ALLOW'
    if re.search(r'\b(IS|ARE)\s+NOT\s+EVIDENCE\b',u): return 'EVIDENCE_BOUNDARY'
    if re.search(r'\bNOT\s+(AUTOMATIC\s+TRUTH|A\s+QUALITY\s+METRIC|PROOF|EVIDENCE)\b',u): return 'EVIDENCE_BOUNDARY'
    if ' EVIDENCE ' in u and re.search(r'\bWORSE\s+THAN\b',u): return 'EVIDENCE_BOUNDARY'
    if re.search(r'\bBASELINE\b',u) and re.search(r'\bSTANDARD\b',u): return 'DEFINE'
    if re.search(r'\bFOLLOW\b',u): return 'FOLLOW'
    if re.search(r'\bMEANS?\b',u): return 'DEFINE'
    if re.search(r'\bBELONGS?\s+IN\b',u): return 'CLASSIFY'
    if re.search(r'\b(IS|ARE)\s+PART\s+OF\b',u): return 'INCLUDE'
    if re.search(r'\b(IS|ARE)\b.{0,80}\bDEFECTS?\b',u): return 'CLASSIFY'
    if re.search(r'\bREMAINS?\s+ISOLATED\b',u): return 'ISOLATE'
    if re.search(r'\b(IS|ARE)\s+DISPOSABLE\b',u): return 'RETIRE'
    # Semantic verbs anywhere in a declarative sentence can own the directive.
    anywhere=[
        (r'\b(PRESERVE|RETAIN|KEEP)\b','PRESERVE'),(r'\b(RETIRE|REMOVE|DELETE|CLEAN\s+UP)\b','RETIRE'),
        (r'\b(VALIDATE|VERIFY|PROVE|CHECK)\b','VALIDATE'),(r'\b(CLASSIFY|DISTINGUISH|SEPARATE)\b','CLASSIFY'),
        (r'\b(INVENTORY)\b','INVENTORY'),(r'\b(ENCODE)\b','ENCODE'),(r'\b(AUDIT)\b','AUDIT'),
        (r'\b(CONTINUE)\b','CONTINUE'),(r'\b(STOP)\b','STOP'),(r'\b(BLOCK)\b','BLOCK'),
        (r'\b(REPORT|STATE|IDENTIFY|RECORD|DOCUMENT)\b','REPORT'),
    ]
    for pat,op in anywhere:
        if re.search(pat,u): return op
    m=re.match(r'^([A-Za-z][A-Za-z-]+)\b',t)
    if m:
        lead=m.group(1).lower()
        if lead in LEADING_ACTIONS: return LEADING_ACTIONS[lead]
    if fallback and not str(fallback).startswith('ACTION::'): return str(fallback).upper()
    return 'DECLARE'


def _stem(w: str) -> str:
    w=w.lower().strip("'\"")
    if w in SYN: return SYN[w]
    # Conservative morphology; avoid aggressive linguistic guessing.
    if len(w)>6 and w.endswith('ies'): w=w[:-3]+'y'
    elif len(w)>6 and w.endswith('ing'): w=w[:-3]
    elif len(w)>5 and w.endswith('ed'): w=w[:-2]
    elif len(w)>5 and w.endswith('es'): w=w[:-2]
    elif len(w)>4 and w.endswith('s'): w=w[:-1]
    return SYN.get(w,w)


def canonical_atoms(text: str) -> List[str]:
    t=_clean(text).lower()
    t=MODAL_RE.sub(' ',t)
    # Normalize a few general multiword concepts before tokenization.
    t=re.sub(r'\buser[- ]owned\b',' userstate ',t)
    t=re.sub(r'\bhigh[- ]impact\b',' highimpact ',t)
    t=re.sub(r'\bsource[- ]shape\b',' sourceform ',t)
    t=re.sub(r'\bfalse[- ]green\b',' falsegreen ',t)
    words=re.findall(r"[a-z0-9]+(?:-[a-z0-9]+)?",t)
    out=[]
    for w in words:
        c=_stem(w)
        if not c or c in STOP or len(c)<2: continue
        out.append(c)
    return sorted(set(out))


def _split_rule(text: str) -> List[str]:
    t=_clean(text)
    if not t: return []
    # Semicolon and sentence boundaries are strong clause boundaries for governance prose.
    parts=re.split(r'(?<=[.!?])\s+|\s*;\s*',t)
    return [p.strip(' .') for p in parts if p.strip(' .')]


def _condition(text: str) -> Optional[str]:
    m=CONDITION_RE.match(_clean(text))
    return f'{m.group(1).upper()} {m.group(2).strip()}' if m else None


def _exception(text: str) -> Optional[str]:
    m=EXCEPTION_RE.search(_clean(text))
    return f'{m.group(1).upper()} {m.group(2).strip()}' if m else None


def _target(text: str) -> str:
    t=_clean(text)
    m=CONDITION_RE.match(t)
    if m: t=m.group(3).strip()
    t=MODAL_RE.sub(' ',t, count=1)
    return re.sub(r'\s+',' ',t).strip(' .')


def atomize_constraint(spec: Dict[str,Any]) -> List[Dict[str,Any]]:
    text=_clean(spec.get('text'))
    clauses=_split_rule(text) or [text]
    out=[]
    inherited_condition=spec.get('condition')
    inherited_exception=spec.get('exception')
    for i,clause in enumerate(clauses,1):
        op=canonical_operator(clause, spec.get('operator'))
        target=_target(clause)
        cond=_condition(clause) or inherited_condition
        exc=_exception(clause) or inherited_exception
        atoms=canonical_atoms(target)
        # Pure prose with no content atoms stays explicit rather than fabricated.
        sem_key=_sha({'scope':canonical_atoms(spec.get('scope')),'condition':canonical_atoms(cond or ''),'target_atoms':atoms})
        out.append({
            'atom_id':f"{spec.get('rule_id')}:{i}",'rule_id':str(spec.get('rule_id')),'clause_index':i,'text':clause,
            'operator':op,'target':target,'condition':cond,'exception':exc,'scope':spec.get('scope'),'authority':spec.get('authority'),
            'precedence':spec.get('precedence'),'semantic_atoms':atoms,'semantic_target_key':sem_key,
        })
    return out


def enrich_constraint_spec(spec: Dict[str,Any]) -> Dict[str,Any]:
    out=dict(spec)
    declared_op=str(out.get('operator') or '')
    if out.get('parse_mode')=='EXPLICIT_STRUCTURED' and declared_op and not declared_op.startswith('ACTION::') and declared_op!='DECLARE':
        out['operator']=declared_op.upper()
    else:
        out['operator']=canonical_operator(str(out.get('text') or ''), declared_op)
    atoms=atomize_constraint(out)
    out['atomic_constraints']=atoms
    all_atoms=sorted(set(a for row in atoms for a in row.get('semantic_atoms') or []))
    out['semantic_profile']={
        'schema':'AC76_SEMANTIC_CONSTRAINT_PROFILE_V1','rule_id':str(out.get('rule_id')),'operator':out.get('operator'),
        'atomic_count':len(atoms),'semantic_atoms':all_atoms,
        'semantic_rule_key':_sha({'scope':canonical_atoms(out.get('scope')),'atoms':[x['semantic_target_key'] for x in atoms]}),
        'external_authority_only':True,'ct_axiom_promoted':False,
    }
    return out


def _jaccard(a:set,b:set)->float:
    if not a and not b: return 1.0
    if not a or not b: return 0.0
    return len(a&b)/len(a|b)


def _contain(a:set,b:set)->float:
    # Fraction of a contained in b.
    return len(a&b)/len(a) if a else 0.0


def _opposite(a:str,b:str)->bool:
    a=a.upper(); b=b.upper()
    return b in OPPOSITE_FAMILIES.get(a,set()) or a in OPPOSITE_FAMILIES.get(b,set())


def compare_atoms(a:Dict[str,Any],b:Dict[str,Any])->Dict[str,Any]:
    A=set(a.get('semantic_atoms') or []); B=set(b.get('semantic_atoms') or [])
    jac=_jaccard(A,B); ca=_contain(A,B); cb=_contain(B,A)
    seq=SequenceMatcher(None,' '.join(sorted(A)),' '.join(sorted(B))).ratio() if (A or B) else 1.0
    same_op=str(a.get('operator')).upper()==str(b.get('operator')).upper()
    opposite=_opposite(str(a.get('operator')),str(b.get('operator')))
    exact=A==B and bool(A)
    relation='DISTINCT'; confidence='LOW'; deterministic=False
    if exact and same_op:
        relation='REDUNDANT_DETERMINISTIC'; confidence='EXACT'; deterministic=True
    elif exact and opposite:
        relation='CONFLICT_DETERMINISTIC'; confidence='EXACT'; deterministic=True
    elif same_op and jac>=0.90 and seq>=0.82 and min(len(A),len(B))>=3:
        relation='REDUNDANT_HIGH_CONFIDENCE'; confidence='HIGH'
    elif same_op and max(ca,cb)>=0.88 and jac>=0.58 and abs(len(A)-len(B))>=2:
        relation='SPECIALIZATION' if len(A)!=len(B) else 'OVERLAP_REVIEW'; confidence='HIGH'
    elif opposite and jac>=0.78 and min(len(A),len(B))>=2:
        relation='CONFLICT_CANDIDATE'; confidence='HIGH'
    elif jac>=0.52 and min(len(A),len(B))>=3:
        relation='OVERLAP_REVIEW'; confidence='MEDIUM'
    return {'relation':relation,'confidence':confidence,'deterministic':deterministic,'jaccard':round(jac,6),'contain_a_in_b':round(ca,6),'contain_b_in_a':round(cb,6),'sequence':round(seq,6),'shared_atoms':sorted(A&B)}


def compare_specs(a:Dict[str,Any],b:Dict[str,Any])->Dict[str,Any]:
    A=(a.get('atomic_constraints') or atomize_constraint(a)); B=(b.get('atomic_constraints') or atomize_constraint(b))
    best=None
    order={'CONFLICT_DETERMINISTIC':7,'REDUNDANT_DETERMINISTIC':7,'CONFLICT_CANDIDATE':6,'REDUNDANT_HIGH_CONFIDENCE':5,'SPECIALIZATION':4,'OVERLAP_REVIEW':3,'DISTINCT':0}
    for aa in A:
        for bb in B:
            rel=compare_atoms(aa,bb)
            cand={**rel,'a_atom_id':aa.get('atom_id'),'b_atom_id':bb.get('atom_id'),'a_operator':aa.get('operator'),'b_operator':bb.get('operator')}
            score=(order.get(rel['relation'],0), rel['jaccard'], rel['sequence'])
            if best is None or score>best[0]: best=(score,cand)
    out=(best[1] if best else {'relation':'DISTINCT','confidence':'LOW','deterministic':False,'jaccard':0.0,'shared_atoms':[]})
    out.update({'rule_a':str(a.get('rule_id')),'rule_b':str(b.get('rule_id'))})
    return out
