from __future__ import annotations

from pathlib import Path
from typing import Any, Dict, Optional
import copy
import re

from pass053_provider_typed_distance_api import DEFAULT_PROVIDER, DistanceAPIError
from pass054_cartesian_space_time_coherence import CartesianSpaceTimeCoherenceEngine

THEOREM_ID_RE = re.compile(r"^T\d{3}$")
PACKAGE_ROOT = Path(__file__).resolve().parents[1]

ERROR_REQUIREMENTS = {
    "UNKNOWN_THEOREM_ID": "REGISTERED_THEOREM_ID_REQUIRED",
    "UNKNOWN_METRIC_PROVIDER": "REGISTERED_METRIC_PROVIDER_REQUIRED",
    "UNCERTIFIED_CROSS_PROVIDER_CONVERSION_FORBIDDEN": "CERTIFIED_CROSS_PROVIDER_SCALE_ADAPTER_REQUIRED",
    "ROUTE_CONTEXT_BINDING_NOT_EXACT": "EXACT_THEOREM_ROUTE_CONTEXT_BINDING_REQUIRED",
    "INVALID_DISTANCE_REQUEST": "VALID_PERIODIC_CARTESIAN_REQUEST_REQUIRED",
    "CARTESIAN_COHERENCE_ERROR": "CARTESIAN_COHERENCE_REPAIR_REQUIRED",
}


class PeriodicCartesianTheoremCore:
    """AC77 native pre-ALL-AUX integration of Periodic Cartesian PASS053/PASS054.

    The core is intentionally provider-relative and fail-closed.  It never turns
    route address, Borges rank, temporal order, table slot, or semantic similarity
    into metric distance.  It exposes the frozen PASS021/PASS019R EFFECT_RESPONSE
    metric, PASS039 Q4/residual decomposition, PASS048/049 local chart atlas,
    PASS050 theorem/address binding, PASS052 scale firewall, PASS053 distance API,
    and PASS054 Pythagoras/Gram coherence gate.

    This core adds zero scientific ROOT truth credit.  A distance/coherence receipt
    can prune, diagnose, or constrain a route; it cannot by itself prove a theorem.
    """

    def __init__(self, root: Optional[Path | str] = None):
        self.root = Path(root) if root is not None else PACKAGE_ROOT
        self._engine_instance: Optional[CartesianSpaceTimeCoherenceEngine] = None
        self.request_count = 0
        self.auto_route_count = 0
        self.auto_pair_count = 0
        self.success_count = 0
        self.fail_closed_count = 0
        self.false_pythagoras_rejection_count = 0
        self.gram_route_count = 0
        self.distance_count = 0
        self.route_count = 0
        self.provider_registry_count = 0

    @property
    def engine(self) -> CartesianSpaceTimeCoherenceEngine:
        if self._engine_instance is None:
            self._engine_instance = CartesianSpaceTimeCoherenceEngine(self.root)
        return self._engine_instance

    @staticmethod
    def _valid_theorem_route(value: Any) -> bool:
        return (
            isinstance(value, (list, tuple))
            and len(value) >= 2
            and all(isinstance(x, str) and THEOREM_ID_RE.fullmatch(x) for x in value)
        )

    @staticmethod
    def _valid_theorem_pair(a: Any, b: Any) -> bool:
        return (
            isinstance(a, str) and isinstance(b, str)
            and THEOREM_ID_RE.fullmatch(a) is not None
            and THEOREM_ID_RE.fullmatch(b) is not None
        )

    def infer_request(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        explicit = payload.get("periodic_cartesian_request")
        if isinstance(explicit, dict):
            req = copy.deepcopy(explicit)
            req.setdefault("metric_provider_id", DEFAULT_PROVIDER)
            return {"status": "EXPLICIT_REQUEST", "request": req}

        # A theorem route is already an exact enough semantic trigger: AC77 measures
        # it automatically before ALL-AUX, without assuming Pythagoras.
        route = payload.get("theorem_route")
        if self._valid_theorem_route(route):
            req: Dict[str, Any] = {
                "operation": "coherent_route",
                "theorem_route": list(route),
                "metric_provider_id": payload.get("metric_provider_id", DEFAULT_PROVIDER),
            }
            contexts = payload.get("theorem_endpoint_contexts") or payload.get("endpoint_contexts")
            if contexts is not None:
                req["endpoint_contexts"] = contexts
            return {"status": "AUTO_ROUTE", "request": req}

        a = payload.get("source_theorem_id")
        b = payload.get("target_theorem_id")
        if payload.get("periodic_cartesian_auto_pair") is True and self._valid_theorem_pair(a, b):
            req = {
                "operation": "coherent_distance",
                "source_theorem_id": a,
                "target_theorem_id": b,
                "metric_provider_id": payload.get("metric_provider_id", DEFAULT_PROVIDER),
            }
            if isinstance(payload.get("route_context"), dict):
                req["route_context"] = payload["route_context"]
            return {"status": "AUTO_PAIR", "request": req}

        return {"status": "NO_PERIODIC_CARTESIAN_REQUEST", "request": None}

    @staticmethod
    def _pythagoras_claimed(payload: Dict[str, Any], request: Dict[str, Any]) -> bool:
        tokens = {
            str(payload.get("route_composition_law") or "").upper(),
            str(payload.get("composition_law") or "").upper(),
            str(request.get("route_composition_law") or "").upper(),
        }
        return (
            payload.get("claim_route_pythagoras") is True
            or request.get("claim_route_pythagoras") is True
            or "PYTHAGORAS" in tokens
            or "PYTHAGOREAN" in tokens
        )

    def execute_request(self, request: Dict[str, Any]) -> Dict[str, Any]:
        self.request_count += 1
        try:
            result = self.engine.execute(request)
        except DistanceAPIError as exc:
            self.fail_closed_count += 1
            code = getattr(exc, "code", "DISTANCE_API_ERROR")
            return {
                "schema": "AC77_PERIODIC_CARTESIAN_THEOREM_CORE_RECEIPT_V1",
                "status": "OPEN_FAIL_CLOSED",
                "ok": False,
                "request": copy.deepcopy(request),
                "error": exc.as_dict(),
                "requires": [ERROR_REQUIREMENTS.get(code, "PERIODIC_CARTESIAN_TYPED_REPAIR_REQUIRED")],
                "truth_credit_added": 0,
                "external_scientific_truth_certified": False,
                "movement_blocked": False,
                "metric_invented": False,
            }

        self.success_count += 1
        op = str(request.get("operation") or "coherent_distance")
        if op in {"coherent_distance", "distance"}:
            self.distance_count += 1
        elif op in {"coherent_route", "route_distance"}:
            self.route_count += 1
            if result.get("route_pythagoras", {}).get("result") == "NOT_APPLICABLE_USE_GRAM_LAW":
                self.gram_route_count += 1
        elif op == "provider_registry":
            self.provider_registry_count += 1

        return {
            "schema": "AC77_PERIODIC_CARTESIAN_THEOREM_CORE_RECEIPT_V1",
            "status": "PASS",
            "ok": True,
            "request": copy.deepcopy(request),
            "result": result,
            "requires": [],
            "truth_credit_added": 0,
            "external_scientific_truth_certified": False,
            "movement_blocked": False,
            "metric_invented": False,
        }

    def apply_payload(self, payload: Dict[str, Any]) -> Dict[str, Any]:
        inferred = self.infer_request(payload)
        if inferred["status"] == "NO_PERIODIC_CARTESIAN_REQUEST":
            return {"status": inferred["status"], "request": None}
        if inferred["status"] == "AUTO_ROUTE":
            self.auto_route_count += 1
        elif inferred["status"] == "AUTO_PAIR":
            self.auto_pair_count += 1

        receipt = self.execute_request(inferred["request"])
        receipt["request_mode"] = inferred["status"]
        if not receipt.get("ok"):
            return receipt

        result = receipt["result"]
        claim_rejected = False
        if result.get("schema") == "PASS054_CARTESIAN_COHERENT_ROUTE_CERTIFICATE_V1":
            claimed = self._pythagoras_claimed(payload, inferred["request"])
            applicable = bool(result.get("route_pythagoras", {}).get("applicable"))
            if claimed and not applicable:
                claim_rejected = True
                self.false_pythagoras_rejection_count += 1
                receipt["requires"] = ["USE_GRAM_LAW_FOR_NONORTHOGONAL_THEOREM_ROUTE"]

        receipt["coherence_gate"] = {
            "claim_rejected": claim_rejected,
            "false_naive_route_pythagoras_allowed": False,
            "pythagoras_requires_certified_mutual_orthogonality": True,
            "gram_fallback_mandatory_when_oblique": True,
            "theorem_identity_equals_route_address": False,
            "cross_provider_arithmetic_requires_certified_adapter": True,
            "global_fixed_time_axis_claimed": False,
            "provider_independent_intrinsic_metric_claimed": False,
        }
        return receipt

    def counters(self) -> Dict[str, int]:
        return {
            "requests": self.request_count,
            "auto_routes": self.auto_route_count,
            "auto_pairs": self.auto_pair_count,
            "success": self.success_count,
            "fail_closed": self.fail_closed_count,
            "distance_receipts": self.distance_count,
            "route_receipts": self.route_count,
            "provider_registry_receipts": self.provider_registry_count,
            "gram_routes": self.gram_route_count,
            "false_pythagoras_claims_rejected": self.false_pythagoras_rejection_count,
        }
