from __future__ import annotations
import json, sys, time
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / '02_RUNTIME'))

from all_everything_wave_engine import Node
from causal_grid_core import CausalGridCore
from sovereign_aux import REGISTRY
from sovereign_solver import SovereignSolver


def main():
    t0 = time.time()
    core = CausalGridCore()
    verify = core.hypertriangle_core.verification()
    solver = SovereignSolver()

    init = solver.hypertriangle({'request_id':'Q_INIT','mode':'memory_144_init','payload':{}})
    state = init['receipt']['state']
    drop = solver.hypertriangle({
        'request_id':'Q_DROP','mode':'memory_144_drop','payload':{
            'state':state,'datum_id':'Q1',
            'signals':[{'operator':'IDENTITY_SEED','certified':True,'projection':'qualification'}],
        }
    })

    explicit = Node('PROBLEM', {
        'statement':'AC78_QUALIFICATION_EXPLICIT_REQUEST',
        'hypertriangle_request':{'request_id':'Q_NODE','mode':'memory_144_catalog','payload':{}},
    }, context=('AC78','QUALIFICATION'))
    enriched, side = core.enrich_node(explicit, {}, 0)
    hrows = [x for x in side if x.kind == 'HYPERTRIANGLE_AUX_RECEIPT']

    ordinary = Node('PROBLEM', {'statement':'NO_IMPLICIT_CLASSIFICATION','operator':'IDENTITY_SEED'})
    ordinary_enriched, ordinary_side = core.enrich_node(ordinary, {}, 0)

    bad = Node('PROBLEM', {'statement':'BAD_REQUEST','hypertriangle_request':'infer it'})
    bad_enriched, bad_side = core.enrich_node(bad, {}, 0)

    periodic = solver.periodic_cartesian({
        'operation':'coherent_distance','source_theorem_id':'T003','target_theorem_id':'T072'
    })
    world = solver._prepare_world({})
    fake_aux_terminal = Node('HYPERTRIANGLE_AUX_RECEIPT', {
        'status':'PASS','external_scientific_truth_certified':False,'truth_credit_added':0,
        'root_write_capability':'NONE','statement':'LOCAL_AUX_TERMINAL_ONLY'
    })
    solve_probe = solver.solve_universal([Node('PROBLEM',{
        'statement':'AC78_QUALIFICATION_SOLVER_PROBE',
        'hypertriangle_request':{'request_id':'Q_SOLVE','mode':'memory_144_init','payload':{}},
    },context=('AC78','QUALIFICATION','SOLVER'))], max_waves=1, max_calls=150, stable_waves=1)

    checks = {
        'frozen_provider_sha_exact': verify['frozen_zip_sha256']=='fa82b76a200703afe38e1f3e6ecabe2b1cb363f4fbb89c34ca00adf24ea23295',
        'frozen_provider_abi_counts': verify['capability_count']==61 and verify['slot_count']==144 and verify['schema_count']==35,
        'direct_memory_init_start1': state['trace_start']==1 and state['next_trace']==1 and state['slot_count']==144,
        'typed_data_drops_to_declared_F001': drop['receipt']['memory_valid'] is True and list(drop['receipt']['flagged_slots'])==['F001'],
        'explicit_pre_all_aux_receipt': len(hrows)==1 and enriched.payload.get('hypertriangle_status')=='PASS',
        'no_implicit_slot_classification': ordinary_enriched.payload.get('hypertriangle_status')=='NO_HYPERTRIANGLE_REQUEST' and not any(x.kind.startswith('HYPERTRIANGLE_') for x in ordinary_side),
        'untyped_request_fails_closed_nonblocking': bad_enriched.payload.get('hypertriangle_status')=='OPEN_FAIL_CLOSED' and len([x for x in bad_side if x.kind=='HYPERTRIANGLE_AUX_CURRENT'])==1,
        'authority_firewall_zero_root_return_mutation': init['truth_credit']==0 and init['root_write_capability']=='NONE' and init['return_write_capability']=='NONE' and init['solver_mutation_capability']=='NONE',
        'aux_receipt_cannot_be_scientific_root': solver._root([fake_aux_terminal]) is None,
        'ac77_periodic_cartesian_preserved': periodic.get('ok') is True and periodic['result']['schema']=='PASS054_CARTESIAN_COHERENT_DISTANCE_CERTIFICATE_V1',
        'all_aux_registry_99_preserved': len(REGISTRY)==99 and world.get('active_mechanism_count')==99,
        'ac78_world_contract_active': world.get('context_version')==78 and world.get('ac78_hypertriangle_memory_integration_core') is True and world.get('ac78_hypertriangle_implicit_slot_classification') is False and world.get('ac78_hypertriangle_memory_feedback') is False,
        'full_solver_run_surfaces_aux_without_root': solve_probe.get('version')=='AC78' and solve_probe.get('hypertriangle_receipt_count')==1 and solve_probe.get('solution_certified') is False and solve_probe.get('active_mechanism_count')==99,
    }
    out = {
        'schema':'AC78_HYPERTRIANGLE_MEMORY_INTEGRATION_QUALIFICATION_V1',
        'version':'AC78','base':'AC77',
        'elapsed_seconds':round(time.time()-t0,3),
        'checks':checks,
        'pass_count':sum(bool(v) for v in checks.values()),
        'check_count':len(checks),
        'pass':all(checks.values()),
        'integration':{
            'provider':'HYPERTRIANGLE_SOLVER_AUX','provider_version':'1.0.0',
            'frozen_zip_sha256':verify['frozen_zip_sha256'],
            'pre_all_aux':True,'active_mechanisms':len(REGISTRY),'new_registry_mechanisms_added':0,
            'explicit_request_field':'hypertriangle_request',
            'direct_solver_method':'SovereignSolver.hypertriangle(request)',
            'implicit_slot_classification':False,'memory_feedback':False,
            'root_truth_credit_added':0,'root_write_capability':'NONE','return_write_capability':'NONE','solver_mutation_capability':'NONE',
        },
        'hypertriangle_counters':core.hypertriangle_core.counters(),
    }
    print(json.dumps(out, indent=2, ensure_ascii=False))
    if not out['pass']:
        raise SystemExit(1)

if __name__ == '__main__':
    main()
