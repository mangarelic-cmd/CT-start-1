from __future__ import annotations
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver

CASES=[
    ('T10_QUOTIENT_GAUGE_COVERING_ADAPTERS', {
        'statement':'Materialize concrete quotient/gauge/covering adapter library: quotient sections, gauge fixing/holonomy, covering lift/monodromy.',
        'cake':'quotient/gauge/covering state','plate':'typed fibre bundle / quotient / covering','operator':'LIFT_AND_RECONSTRUCT',
        'requires':['CONCRETE_QUOTIENT_SECTION_ADAPTERS','GAUGE_FIXING_HOLONOMY_ADAPTERS','COVERING_LIFT_MONODROMY_ADAPTERS']
    }),
    ('T11_PROSE_DOMAIN_LAW_AUTHORITY', {
        'statement':'Expand ambiguity-preserving prose-to-domain-law authority binding coverage without inventing laws.',
        'cake':'natural-language problem packet','plate':'registered law/theorem authority catalog','operator':'PARSE_BIND_AND_ROUTE',
        'requires':['AUTHORITY_RESOLVER_COVERAGE','AMBIGUITY_LEDGER','DOMAIN_LAW_BINDINGS']
    }),
    ('T12_DECLARED_CLASS_SATURATION', {
        'statement':'Run declared-class saturation campaign over solved benchmarks and infinite-family proof schemas until semantic fixed point modulo equivalence.',
        'cake':'declared solved benchmark class','plate':'causal grid atlas','operator':'SATURATE_ATLAS',
        'requires':['DECLARED_CLASS_C','GENERATOR_UNIVERSE_U','BENCHMARK_SWEEP','INFINITE_FAMILY_SCHEMAS','NEGATIVE_KNOWLEDGE_FIXED_POINT']
    }),
    ('T13_COMPLETENESS_CERTIFICATE', {
        'statement':'Produce declared-class completeness certificate with coverage proof, independent cold replay, and zero untyped family seal.',
        'cake':'saturated declared-class atlas','plate':'coverage/certification framework','operator':'CERTIFY_COMPLETENESS',
        'requires':['COVERAGE_PROOF','INDEPENDENT_COLD_REPLAY','ZERO_UNTYPED_FAMILY_SEAL']
    }),
]

def main():
    seeds=[]
    for tid,p in CASES:
        p=dict(p); p['task_id']=tid
        seeds.append(Node('PROBLEM',p,context=('CP021',tid)))
    s=SovereignSolver(); r=s.solve_universal(seeds,max_waves=2,max_calls=10000)
    known=list(s.engine.known.values())
    coverage={m:0 for m in r.get('active_mechanism_ids',[])}
    for e in r.get('execution_log',[]): coverage[e['mechanism']]=coverage.get(e['mechanism'],0)+1
    out={
        'schema':'CP021_REMAINING_TASKS_ALL_AUX_V1',
        'task_ids':[x[0] for x in CASES],
        'active_mechanism_count':r.get('active_mechanism_count'),
        'mechanisms_touched':sum(1 for v in coverage.values() if v>0),
        'execution_calls':r.get('execution_calls'),
        'run_state':r.get('run_state'),
        'open_residual_count':r.get('open_residual_count'),
        'open_residuals':r.get('open_residuals'),
        'mechanism_execution_counts':coverage,
        'theorem_receipts':[n.to_dict() for n in known if n.kind=='CAUSAL_GRID_THEOREM_RECEIPT'],
        'atlas_binding_receipts':[n.to_dict() for n in known if n.kind=='CAUSAL_GRID_ATLAS_BINDING_RECEIPT'],
    }
    print(json.dumps(out,indent=2,ensure_ascii=False))
if __name__=='__main__': main()
