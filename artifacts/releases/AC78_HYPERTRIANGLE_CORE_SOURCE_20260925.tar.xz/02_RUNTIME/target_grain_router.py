from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Dict, Iterable, Tuple
from all_everything_wave_engine import Node, context_can_supply, contexts_compatible, requirement_family
from automation_reconciliation_ac66 import open_like_status, scientific_signature
ELECTRICAL_PIPELINE_KINDS = {'GLOBAL_METER_RECEIPT', 'CAUSAL_GAUGE_RECEIPT'}
GEOMETRIC_KINDS = {'FORMAL_PROOF_RECEIPT', 'FORMAL_PROOF_CURRENT', 'CAUSAL_GEOMETRIC_PROOF_RECEIPT', 'CAUSAL_GEOMETRIC_CANONICAL_TRANSPORT_RECEIPT', 'TRIANGULATED_TRANSPORT_RECEIPT', 'TRIANGULATION_TWIST_RECEIPT', 'UNIVERSAL_WHEEL_RECEIPT', 'HYPERCUBE_COORDINATE_RECEIPT', 'CAUSAL_SPACE_RECEIPT', 'TEMPORAL_RECEIPT', 'BABEL_RECEIPT', 'BORGES_RECEIPT'}

def _list(x):
    if x is None:
        return []
    if isinstance(x, (list, tuple, set)):
        return [str(v) for v in x if str(v)]
    return [str(x)]

def focus_tokens(node: Node) -> Tuple[str, ...]:
    p = node.payload
    xs = []
    xs += _list(p.get('requires'))
    xs += _list(p.get('required_effects'))
    xs += _list(p.get('required_effect'))
    xs += _list(p.get('expected_supplies'))
    if p.get('target_obligation'):
        xs.append(str(p['target_obligation']))
    if p.get('obligation'):
        xs.append(str(p['obligation']))
    return tuple(sorted(set(xs)))

def supplies(node: Node) -> Tuple[str, ...]:
    xs = _list(node.payload.get('supplies'))
    if node.kind == 'CORRELATION_LINK' and node.payload.get('token'):
        xs.append(str(node.payload['token']))
    if node.kind == 'NODE_RETURN_RECEIPT' and node.payload.get('returned_effect'):
        xs.append(str(node.payload['returned_effect']))
    return tuple(sorted(set(xs)))

def requirements(node: Node) -> Tuple[str, ...]:
    return tuple(sorted(set(_list(node.payload.get('requires')))))

def residual_focus_tokens(node: Node, known: Dict[str, Node]) -> Tuple[str, ...]:
    req = list(focus_tokens(node))
    out = []
    for tok in req:
        if not any((tok in supplies(n) and context_can_supply(tuple(n.context), tuple(node.context)) for n in known.values())):
            out.append(tok)
    return tuple(sorted(set(out)))

def is_sovereign_focus(node: Node) -> bool:
    if node.payload.get('sovereign_focus') or node.payload.get('scientific_focus'):
        return True
    return node.kind in {'PROBLEM', 'SCIENTIFIC_CURRENT', 'OPEN_RESIDUAL', 'DELTA_RESIDUAL', 'SOVEREIGN_DELTA_CURRENT', 'CYCLE_BREAKER_CURRENT'}

def debt_class(node: Node) -> str:
    p = node.payload
    explicit = str(p.get('debt_class') or p.get('obligation_class') or '').upper()
    if explicit:
        return explicit
    req = focus_tokens(node)
    if not req:
        return 'GENERAL'
    fam = requirement_family(req[0])
    return 'MATERIAL_RECOVERY' if 'MATERIAL' in fam or 'CARRIER' in fam or 'PROVIDER' in fam else 'SCIENTIFIC'

@dataclass(frozen=True)
class GrainDecision:
    semantic_id: str
    classification: str
    active: bool
    reason: str
    source_focus_id: str | None = None
    matched: Tuple[str, ...] = ()

class TargetGrainRouter:
    """Full-discovery selector without a gate queue.

    All AUX run first. Geometry, exact supplies, open scientific currents, and return receipts
    remain active. Non-applicable or unrelated observations are compact memory only.
    """

    def __init__(self):
        self.relation_bank = {}
        self.dormant_flags = {}
        self.decisions = []
        self.reactivated_flag_count = 0
        self.node_return_requests = set()
        self.active_scientific_signatures = set()

    def _decision(self, source: Node | None, n: Node, known: Dict[str, Node]):
        sid = n.semantic_identity()
        fid = source.semantic_identity() if source else None
        st = str(n.payload.get('status') or '')
        if st == 'NOT_APPLICABLE':
            return GrainDecision(sid, 'MEMORY', False, 'not_applicable', fid)
        if n.kind in ELECTRICAL_PIPELINE_KINDS:
            return GrainDecision(sid, 'ELECTRICAL_PIPELINE', True, 'typed_electrical_pipeline_continuation', fid)
        if n.kind in GEOMETRIC_KINDS or n.payload.get('proof_ready') or (isinstance(n.payload.get('result'), dict) and n.payload.get('result', {}).get('proof_ready')):
            return GrainDecision(sid, 'GEOMETRIC', True, 'causal_geometric_evidence', fid)
        if n.kind in {'ROOT_RECEIPT', 'NODE_RETURN_RECEIPT', 'OPEN_RESIDUAL_CURRENT', 'CLOSURE_STATE'}:
            return GrainDecision(sid, 'RETURN_OR_RESIDUAL', True, 'closure_or_residual_current', fid)
        f = set(focus_tokens(source)) if source else set()
        sp = set(supplies(n))
        matched = tuple(sorted(f & sp))
        if matched:
            return GrainDecision(sid, 'DIRECT_EFFECT', True, 'supplies_current_focus', fid, matched)
        if open_like_status(st) and n.kind not in {'AUX_OBSERVATION', 'MECHANISM_OBSERVATION'}:
            ss = scientific_signature(n)
            if ss in self.active_scientific_signatures and n.kind not in {'FORMAL_PROOF_RECEIPT','KERNEL_RECEIPT','NODE_RETURN_RECEIPT','NEGATIVE_KNOWLEDGE_RECEIPT'}:
                return GrainDecision(sid, 'MEMORY', False, 'semantic_duplicate_wrapper_or_replay', fid)
            self.active_scientific_signatures.add(ss)
            return GrainDecision(sid, 'OPEN_ROUTE', True, 'observable_scientific_current', fid)
        if n.kind in {'PROVIDER_OBJECT', 'MATERIALIZED_OBJECT', 'CARRIER_OBJECT', 'PROOF_CANDIDATE', 'KERNEL_RECEIPT', 'DUAL_PASS_RECEIPT', 'REMEASURE_RECEIPT', 'DELTA_CANDIDATE'}:
            return GrainDecision(sid, 'STRUCTURE', True, 'reusable_scientific_structure', fid)
        return GrainDecision(sid, 'MEMORY', False, 'unrelated_observation', fid)

    def route(self, frontier: Iterable[Node], candidates: Iterable[Node], known: Dict[str, Node], world: Dict[str, Any]):
        frontier = list(frontier)
        candidates = list(candidates)
        active = []
        decisions = {}
        source_by_id = {n.identity(): n for n in frontier}
        for n in candidates:
            src = None
            for p in n.parents:
                if p in source_by_id:
                    src = source_by_id[p]
                    break
            if src is None and frontier:
                src = frontier[0] if len(frontier) == 1 else None
            d = self._decision(src, n, known)
            decisions[n.semantic_identity()] = d
            self.decisions.append(d)
            if d.active:
                active.append(n)
            else:
                self.relation_bank[n.semantic_identity()] = {'kind': n.kind, 'payload': dict(n.payload), 'context': list(n.context)}
        return (active, decisions)

    @staticmethod
    def _geometric_receipts(src: Node, known: Dict[str, Node]):
        out = []
        for n in known.values():
            if n.kind != 'CAUSAL_GEOMETRIC_PROOF_RECEIPT':
                continue
            if not contexts_compatible(tuple(n.context), tuple(src.context)):
                continue
            res = n.payload.get('result') or {}
            if n.payload.get('status') == 'PASS' and (res.get('proof_ready') is True or n.payload.get('proof_ready') is True):
                out.append(n)
        return sorted(out, key=lambda n: n.semantic_identity())

    def closure_requests(self, frontier: Iterable[Node], known: Dict[str, Node], wave: int):
        out = []
        for src in frontier:
            if not is_sovereign_focus(src):
                continue
            fid = src.semantic_identity()
            req = focus_tokens(src)
            unresolved = residual_focus_tokens(src, known)
            resolved = tuple(x for x in req if x not in set(unresolved))
            geo = self._geometric_receipts(src, known)
            state_key=(fid,bool(geo),tuple(unresolved))
            if state_key in self.node_return_requests:
                continue
            self.node_return_requests.add(state_key)
            geo_ids = [n.identity() for n in geo]
            geo_result = [n.payload.get('result') for n in geo]
            payload = {'statement': 'NODE_2SIN1COS_DIRECT_CLOSURE', 'focus_id': fid, 'source_statement': src.payload.get('statement'), 'source_node_id': src.identity(), 'parent_node_ids': list(src.parents), 'resolved_effects': list(resolved), 'open_effect_annotations': list(unresolved), 'sin1_verified': True, 'sin2_derived': bool(geo), 'cos_derived': bool(geo), 'geometry_receipt_ids': geo_ids, 'geometry_results': geo_result, 'closure_mode': 'DIRECT_CAUSAL_TRIANGULATION', 'closure_state': 'GEOMETRIC_COMPLETE' if geo else 'OPEN_RESIDUAL_NO_GEOMETRY'}
            out.append(Node('NODE_2SIN1COS_REQUEST', payload, (src.identity(),) + tuple(geo_ids), wave, tuple(src.context)))
        return out
