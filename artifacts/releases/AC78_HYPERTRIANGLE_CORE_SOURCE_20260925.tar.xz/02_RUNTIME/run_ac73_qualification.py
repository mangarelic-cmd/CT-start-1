from __future__ import annotations
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver

CASES=[
    Node('PROBLEM',{'statement':'euclidean metric atlas','cake':'d','plate':'R2','operator':'MOVE','domain_metric_binding':{'domain':'EUCLIDEAN_RN','dimension':2,'displacement':[3,4]}},context=('AC73','metric-euclidean')),
    Node('PROBLEM',{'statement':'l2 metric atlas','cake':'signal','plate':'L2','operator':'MOVE','domain_metric_binding':{'domain':'L2_FINITE','dimension':2,'displacement':[1,2],'quadrature_weights':[2,3]}},context=('AC73','metric-l2')),
    Node('PROBLEM',{'statement':'h1 metric atlas','cake':'function','plate':'H1','operator':'MOVE','domain_metric_binding':{'domain':'H1_DISCRETE','dimension':2,'displacement':[1,1],'derivative_matrix':[[-1,1]]}},context=('AC73','metric-h1')),
    Node('PROBLEM',{'statement':'primitive psi','cake':'operation','plate':'Phi5','operator':'ADD','operator_phi5_psi_binding':{'operator':'ADD'}},context=('AC73','psi-primitive')),
    Node('PROBLEM',{'statement':'composite psi','cake':'operation','plate':'Phi5','operator':'AFFINE','operator_phi5_psi_binding':{'operator':'AFFINE','primitive_decomposition':['MULTIPLY','ADD']}},context=('AC73','psi-composite')),
    Node('PROBLEM',{'statement':'finite fibre residue','cake':'map','plate':'finite-set','operator':'SQUARE','finite_fibre_residue_binding':{'inputs':[-2,-1,0,1,2],'outputs':[4,1,0,1,4]}},context=('AC73','residue-finite')),
    Node('PROBLEM',{'statement':'nonlinear branch residue','cake':'x','plate':'R','operator':'SQUARE','nonlinear_residue_binding':{'kind':'SQUARE_REAL','x':-3}},context=('AC73','residue-nonlinear')),
    Node('PROBLEM',{'statement':'dissipative complement','cake':'u1','plate':'evolution','operator':'HEAT','dissipative_residue_binding':{'current_state':'u1','history':['u0'],'environment':{'bath':'e'},'authority':'QUALIFIED_HISTORY'}},context=('AC73','residue-dissipative')),
    Node('PROBLEM',{'statement':'selection residue','cake':'candidate-set','plate':'optimization','operator':'ARGMIN','selection_residue_binding':{'candidates':['a','b','c'],'selected_index':1,'criterion_authority':'QUALIFIED_ARGMIN'}},context=('AC73','residue-selection')),
]

def main():
    s=SovereignSolver(); r=s.solve_universal(CASES,max_waves=1,max_calls=8000)
    known=list(s.engine.known.values())
    receipts=[n for n in known if n.kind=='CAUSAL_GRID_ATLAS_BINDING_RECEIPT']
    passed=[n for n in receipts if n.payload.get('status')=='PASS']
    out={'schema':'AC73_QUALIFICATION_V1','case_count':len(CASES),'atlas_receipt_count':len(receipts),
         'passing_atlas_receipts':len(passed),'active_mechanism_count':r.get('active_mechanism_count'),
         'execution_calls':r.get('execution_calls'),'run_state':r.get('run_state'),
         'pass':len(receipts)==len(CASES) and len(passed)==len(CASES) and r.get('active_mechanism_count')==99}
    print(json.dumps(out,indent=2,ensure_ascii=False))
if __name__=='__main__': main()
