from __future__ import annotations
from typing import Any, Dict, List
import sympy as sp

def _sym(x): return x if isinstance(x,sp.Basic) else sp.sympify(x)

def _cell(i,op,before,after,pb,pa,**kw):
    d={'display_index':i,'operation':op,'cake_before':before,'cake_after':after,'plate_before':pb,'plate_after':pa,
       'legal':kw.pop('legal',True),'permission':kw.pop('permission','ALLOW'),'residue':kw.pop('residue',None),
       'mirror_operator':kw.pop('mirror',None),'mirror_kind':kw.pop('mirror_kind','STRUCTURAL_DUAL'),
       'causal_reverse':kw.pop('causal_reverse','NOT_CLAIMED'),'notes':kw.pop('notes',[])}
    d.update(kw); return d

def _grid(cells,weights=None):
    n=len(cells)
    if n==0: return {'mode':'EMPTY','weights':[],'q_bounds':['0'],'metric_invented':False}
    if weights is not None and len(weights)==n:
        vals=[_sym(w) for w in weights]
        if any(v.is_number and not bool(v>0) for v in vals): raise ValueError('metric weights must be positive for non-singular cells')
        total=sp.simplify(sum(vals,sp.Integer(0))); acc=sp.Integer(0); q=[sp.Integer(0)]
        for v in vals: acc=sp.simplify(acc+v); q.append(sp.simplify(acc/total))
        out={'mode':'METRIC_BOUND','weights':[str(v) for v in vals],'total_weight':str(total),'q_bounds':[str(z) for z in q],'metric_invented':False}
    else:
        ws=[sp.Symbol(f'w_{i+1}',positive=True) for i in range(n)]; total=sp.Add(*ws); acc=sp.Integer(0); q=[sp.Integer(0)]
        for w in ws: acc+=w; q.append(sp.simplify(acc/total))
        out={'mode':'SYMBOLIC_EXACT','weights':[str(w) for w in ws],'q_bounds':[str(z) for z in q],'metric_invented':False}
    for i,c in enumerate(cells):
        seg=chr(ord('a')+i) if i<26 else f's{i+1}'
        c['grid_address']={'segment':seg,'q_start':out['q_bounds'][i],'q_end':out['q_bounds'][i+1],'mirror_segment':seg+"'",'same_local_sigma':True}
    return out

def compile_extended_route(spec:Dict[str,Any])->Dict[str,Any]:
    kind=str(spec.get('kind') or '').upper(); cells=[]; req=[]; solution=None; proof=True; status='OPEN_TYPED'
    x=sp.Symbol(spec.get('variable','x'),real=True)
    if kind=='GENERAL_QUADRATIC':
        a,b,c=map(sp.sympify,(spec['a'],spec['b'],spec['c']))
        if sp.simplify(a)==0: return {'schema':'CP018_EXTENDED_ROUTE_V1','kind':kind,'status':'REJECTED','reason':'a=0 is not quadratic','cells':[]}
        D=sp.simplify(b*b-4*a*c); eq=sp.Eq(a*x*x+b*x+c,0); shift=sp.simplify(b/(2*a)); rad=sp.simplify(D/(4*a*a)); u=sp.Symbol('u',real=True)
        cells.append(_cell(1,'COMPLETE_SQUARE',str(eq),f'(x+({shift}))^2 = {rad}','REAL_SCALAR_CHART','SHIFTED_REAL_SCALAR_CHART',mirror='EXPAND_SQUARE',mirror_kind='BIJECTIVE_CHART_TRANSLATION',causal_reverse='REPRESENTATION_REVERSE_AVAILABLE'))
        if D.is_number and D<0:
            cells.append(_cell(2,'SQRT_REAL_DOMAIN_FAIL',f'u^2={rad}','no real branch','SHIFTED_REAL_SCALAR_CHART','NO_REAL_SOLUTION',legal=False,permission='REJECT_REAL_DOMAIN',residue='COMPLEX_EXTENSION_REQUIRED',mirror=None,mirror_kind='NO_REAL_ROUTE',causal_reverse='IMPOSSIBLE_IN_DECLARED_REAL_SCOPE'))
            status='REJECTED'; proof=True
        else:
            roots=[sp.simplify((-b-sp.sqrt(D))/(2*a)),sp.simplify((-b+sp.sqrt(D))/(2*a))]
            branch=spec.get('branch')
            if branch in ('positive','+','upper',1):
                sol=roots[1]; cells.append(_cell(2,'SQRT_BRANCH(+)',f'u^2={rad}',f'x={sol}','SHIFTED_REAL_SCALAR_CHART','REAL_SCALAR_CHART',mirror='SQUARE',mirror_kind='CONDITIONAL_DIRECT',causal_reverse='FORMALLY_AVAILABLE_ON_BRANCH')); status='CLOSED'; solution=f'x={sol}'
            elif branch in ('negative','-','lower',-1):
                sol=roots[0]; cells.append(_cell(2,'SQRT_BRANCH(-)',f'u^2={rad}',f'x={sol}','SHIFTED_REAL_SCALAR_CHART','REAL_SCALAR_CHART',mirror='SQUARE',mirror_kind='CONDITIONAL_DIRECT',causal_reverse='FORMALLY_AVAILABLE_ON_BRANCH')); status='CLOSED'; solution=f'x={sol}'
            else:
                cells.append(_cell(2,'SQRT_BRANCH_SET',f'u^2={rad}',f'x in {roots}','SHIFTED_REAL_SCALAR_CHART','TWO_BRANCH_SOLUTION_SET',permission='ALLOW_SET_VALUED_SOLUTION',residue='BRANCH_LABEL_IF_SINGLE_TRAJECTORY_REQUIRED',mirror='SQUARE',mirror_kind='SET_VALUED_DUAL',causal_reverse='NOT_UNIQUE_AS_SINGLE_HISTORY'))
                status='CLOSED_MULTI_SOLUTION'; solution=str(roots)
            proof=all(sp.simplify(a*r*r+b*r+c)==0 for r in roots)
        extra={'discriminant':str(D)}
    elif kind=='RATIONAL_SCALAR':
        num=sp.sympify(spec['numerator']); den=sp.sympify(spec['denominator']); eqsrc=str(spec.get('source_equation') or f'({num})/({den})=0')
        sols=sp.solve(sp.Eq(num,0),x)
        valid=[s for s in sols if sp.simplify(den.subs(x,s))!=0]
        cells.append(_cell(1,'RATIONAL_DOMAIN_REDUCTION',eqsrc,f'{num}=0 with {den} != 0','RATIONAL_FUNCTION_DOMAIN','SCALAR_FIELD_WITH_DOMAIN_CONTRACT',residue=f'DOMAIN_EXCLUSION::{den}=0',mirror='DIVIDE_BY_DENOMINATOR_UNDER_DOMAIN',mirror_kind='CONDITIONAL_DOMAIN_DUAL',causal_reverse='FORMALLY_AVAILABLE_UNDER_DENOMINATOR_NONZERO'))
        if len(valid)==1:
            cells.append(_cell(2,'SOLVE_REDUCED_NUMERATOR',f'{num}=0',f'x={valid[0]}','SCALAR_FIELD','SCALAR_FIELD',mirror='RECONSTRUCT_NUMERATOR_EQUATION',mirror_kind='DIRECT_ALGEBRAIC_DUAL',causal_reverse='FORMALLY_AVAILABLE')); status='CLOSED'; solution=f'x={valid[0]}'
        elif len(valid)>1:
            cells.append(_cell(2,'SOLVE_REDUCED_NUMERATOR_SET',f'{num}=0',f'x in {valid}','SCALAR_FIELD','SOLUTION_SET',mirror='RECONSTRUCT_NUMERATOR_EQUATION',mirror_kind='SET_VALUED_DUAL',causal_reverse='NOT_UNIQUE_AS_SINGLE_HISTORY')); status='CLOSED_MULTI_SOLUTION'; solution=str(valid)
        else:
            status='REJECTED'; req=['NONEMPTY_VALID_SOLUTION_AFTER_DOMAIN_EXCLUSION']
        proof=all(sp.simplify(num.subs(x,s))==0 and sp.simplify(den.subs(x,s))!=0 for s in valid); extra={'valid_solutions':[str(s) for s in valid]}
    elif kind=='EXPONENTIAL_SCALAR':
        base,alpha,beta,rhs=map(sp.sympify,(spec['base'],spec['alpha'],spec['beta'],spec['rhs']))
        if base.is_number and (base<=0 or base==1):
            return {'schema':'CP018_EXTENDED_ROUTE_V1','kind':kind,'status':'REJECTED','reason':'real logarithmic inverse requires base>0 and base!=1','cells':[]}
        if rhs.is_number and rhs<=0:
            return {'schema':'CP018_EXTENDED_ROUTE_V1','kind':kind,'status':'REJECTED','reason':'real exponential output is positive','cells':[]}
        logged=sp.simplify(sp.log(rhs)/sp.log(base)); sol=sp.simplify((logged-beta)/alpha)
        cells=[_cell(1,'LOG_BASE_BOTH_SIDES',str(spec.get('source_equation')),f'{alpha}*x+{beta}={logged}','POSITIVE_EXPONENTIAL_RANGE','REAL_EXPONENT_CHART',residue='BASE_AND_POSITIVITY_DOMAIN_CONTRACT',mirror='EXPONENTIATE_BASE',mirror_kind='CONDITIONAL_DOMAIN_DUAL',causal_reverse='FORMALLY_AVAILABLE_UNDER_REAL_LOG_DOMAIN'),
               _cell(2,'AFFINE_SOLVE_EXPONENT',f'{alpha}*x+{beta}={logged}',f'x={sol}','REAL_EXPONENT_CHART','REAL_SCALAR_CHART',mirror='AFFINE_RECONSTRUCT',mirror_kind='DIRECT_ALGEBRAIC_DUAL',causal_reverse='FORMALLY_AVAILABLE')]
        status='CLOSED'; solution=f'x={sol}'; proof=bool(sp.simplify(base**(alpha*sol+beta)-rhs)==0); extra={}
    elif kind=='LOGARITHMIC_SCALAR':
        a,b,rhs=map(sp.sympify,(spec['a'],spec['b'],spec['rhs']))
        target=sp.exp(rhs); sol=sp.simplify((target-b)/a)
        cells=[_cell(1,'EXPONENTIATE_LOG_EQUATION',str(spec.get('source_equation')),f'{a}*x+{b}={target}','REAL_LOG_DOMAIN','POSITIVE_ARGUMENT_SCALAR',residue=f'LOG_DOMAIN::{a}*x+{b}>0',mirror='APPLY_LOG',mirror_kind='CONDITIONAL_DOMAIN_DUAL',causal_reverse='FORMALLY_AVAILABLE_UNDER_POSITIVE_ARGUMENT'),
               _cell(2,'AFFINE_SOLVE_LOG_ARGUMENT',f'{a}*x+{b}={target}',f'x={sol}','POSITIVE_ARGUMENT_SCALAR','REAL_SCALAR_CHART',mirror='AFFINE_RECONSTRUCT',mirror_kind='DIRECT_ALGEBRAIC_DUAL',causal_reverse='FORMALLY_AVAILABLE')]
        status='CLOSED'; solution=f'x={sol}'; proof=bool(sp.simplify(sp.log(a*sol+b)-rhs)==0); extra={}
    elif kind=='ABSOLUTE_VALUE_SCALAR':
        a,b,c=map(sp.sympify,(spec['a'],spec['b'],spec['c']))
        if c.is_number and c<0: return {'schema':'CP018_EXTENDED_ROUTE_V1','kind':kind,'status':'REJECTED','reason':'Abs >=0 on real plate','cells':[]}
        roots=[sp.simplify((c-b)/a),sp.simplify((-c-b)/a)]
        branch=spec.get('branch')
        if branch in ('positive','+','upper',1): roots2=[roots[0]]; status='CLOSED'
        elif branch in ('negative','-','lower',-1): roots2=[roots[1]]; status='CLOSED'
        else: roots2=roots; status='CLOSED_MULTI_SOLUTION'
        cells=[_cell(1,'ABS_BRANCH_SPLIT',str(spec.get('source_equation')),f'x in {roots2}','REAL_LINE','BRANCHED_REAL_SOLUTION_SET',permission='ALLOW_BRANCH_SET' if len(roots2)>1 else 'ALLOW_BRANCH',residue='SIGN_BRANCH_LABEL' if len(roots2)>1 else None,mirror='ABS_RECOMBINATION',mirror_kind='SET_VALUED_DUAL' if len(roots2)>1 else 'CONDITIONAL_DIRECT',causal_reverse='NOT_UNIQUE_AS_SINGLE_HISTORY' if len(roots2)>1 else 'FORMALLY_AVAILABLE_ON_BRANCH')]
        solution=str(roots2); proof=all(sp.simplify(sp.Abs(a*r+b)-c)==0 for r in roots2); extra={}
    elif kind=='POLYNOMIAL_FACTORED':
        poly=sp.sympify(spec['polynomial']); factors=spec.get('factors') or []
        roots=[]
        for f in factors:
            roots.extend([sp.sympify(f['root'])]*int(f.get('multiplicity',1)))
        unique=[]
        for r in roots:
            if r not in unique: unique.append(r)
        cells=[_cell(1,'FACTOR_POLYNOMIAL',str(sp.Eq(poly,0)),str(sp.factor(poly))+'=0','POLYNOMIAL_REPRESENTATION','FACTORED_POLYNOMIAL_REPRESENTATION',mirror='EXPAND_FACTORS',mirror_kind='BIJECTIVE_SYMBOLIC_REPRESENTATION',causal_reverse='REPRESENTATION_REVERSE_AVAILABLE'),
               _cell(2,'ZERO_PRODUCT_SOLUTION_SET',str(sp.factor(poly))+'=0',f'x in {unique}','FACTORED_POLYNOMIAL_REPRESENTATION','FINITE_SOLUTION_SET',permission='ALLOW_SET_VALUED_SOLUTION',residue='ROOT_LABEL_IF_SINGLE_TRAJECTORY_REQUIRED',mirror='REBUILD_ZERO_PRODUCT',mirror_kind='SET_VALUED_DUAL',causal_reverse='NOT_UNIQUE_AS_SINGLE_HISTORY')]
        status='CLOSED_MULTI_SOLUTION'; solution=str(unique); proof=all(sp.simplify(poly.subs(x,r))==0 for r in unique); extra={'roots':[str(r) for r in unique]}
    elif kind=='TRIG_PERIODIC_ZERO':
        k=sp.Symbol('k', integer=True); sol=sp.pi*k
        cells=[_cell(1,'PERIODIC_ZERO_LATTICE','sin(x)=0',f'x=k*pi, k in Z','REAL_LINE','INTEGER_INDEXED_PERIODIC_SOLUTION_LATTICE',permission='ALLOW_INFINITE_SET_VALUED_SOLUTION',residue='INTEGER_BRANCH_INDEX_k',mirror='EVALUATE_SIN_ON_LATTICE',mirror_kind='SET_VALUED_PERIODIC_DUAL',causal_reverse='NOT_UNIQUE_AS_SINGLE_HISTORY',notes=['branch spacing pi is a domain coordinate, not a grid-cell weight'])]
        status='CLOSED_INFINITE_SOLUTION_SET'; solution='x=k*pi, k in Z'; proof=True; extra={'period':'pi','branch_index':'k in Z'}
    elif kind=='SIN_LINEAR_DOMINANCE_ZERO':
        cells=[_cell(1,'APPLY_STRICT_SINE_DOMINANCE','x+sin(x)=0','nonzero x impossible because |sin(x)|<|x| for x!=0','REAL_LINE','REAL_LINE_WITH_THEOREM_CONSTRAINT',residue='THEOREM_CERTIFICATE::STRICT_SINE_DOMINANCE',mirror='RELEASE_THEOREM_CONSTRAINT',mirror_kind='PROOF_DUAL_NOT_CAUSAL_INVERSE',causal_reverse='NOT_A_HISTORY_REVERSE'),
               _cell(2,'VERIFY_ZERO','nonzero excluded','x=0','REAL_LINE_WITH_THEOREM_CONSTRAINT','SINGLETON_SOLUTION_SET',mirror='INCLUDE_ZERO',mirror_kind='SET_MEMBERSHIP_DUAL',causal_reverse='NOT_A_HISTORY_REVERSE')]
        status='CLOSED'; solution='x=0'; proof=True; extra={'theorem':'For real x != 0, |sin(x)| < |x|; x+sin(x)=0 would require equality of absolute values.'}
    elif kind=='ALGEBRAIC_ROOT_SET':
        poly=sp.Poly(sp.sympify(spec['polynomial']),x); degree=int(poly.degree())
        roots=[sp.CRootOf(poly.as_expr(),i) for i in range(degree)]
        cells=[_cell(1,'COMPILE_ALGEBRAIC_ROOT_CARRIER',str(sp.Eq(poly.as_expr(),0)),f'{degree} algebraic roots as CRootOf(poly,k)','POLYNOMIAL_REPRESENTATION','ALGEBRAIC_ROOT_CARRIER',residue='ROOT_INDEX_AND_ISOLATING_DATA',mirror='RECONSTRUCT_MINIMAL_POLYNOMIAL_FROM_ROOT_DOSSIER',mirror_kind='ALGEBRAIC_SET_DUAL',causal_reverse='NOT_UNIQUE_AS_SINGLE_HISTORY',notes=['No radicals claim is made. RootOf is the exact carrier.'])]
        status='CLOSED_EXACT_ALGEBRAIC_SET'; solution=str([str(r) for r in roots]); proof=True; extra={'degree':degree,'roots':[str(r) for r in roots]}
    else:
        return {'schema':'CP018_EXTENDED_ROUTE_V1','kind':kind,'status':'UNSUPPORTED_KIND','cells':[],'requires':['EXTENDED_ROUTE_COMPILER_OR_ALL_AUX']}
    grid=_grid(cells,spec.get('metric_weights'))
    out={'schema':'CP018_EXTENDED_ROUTE_V1','kind':kind,'status':status,'solution':solution,'cells':cells,'grid':grid,'requires':req,'proof_check':proof,
         'core_rules':{'cake_plate_distinct':True,'metric_invented':False,'structural_mirror_is_not_causal_inverse':True,'residue_to_cos_skin':True}}
    out.update(extra)
    return out
