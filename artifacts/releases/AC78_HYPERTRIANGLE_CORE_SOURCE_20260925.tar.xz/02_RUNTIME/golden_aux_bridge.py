from __future__ import annotations
from typing import Any, Dict, Iterable, List
import re
import sympy as sp
from all_everything_wave_engine import Node, AuxResult
AUX_ID = 'GOLDEN_2SIN1COS_AUX'
_RELEVANT = {'bilateral_nonloop_orbit', 'closure_distinct_from_traversal', 'orientation_anchor', 'rank2_residual_sector', 'rank1_solution_sector', 'orthonormal_metric', 'unit_normalization', 'typed_role_binding', 'normalized_unit_carrier', 'exact_metrics_materialized', 'same_state_same_carrier', 'native_square_bridge_receipt', 'golden_selector_exact', 'orientation_seeded', 'equal_sin_gauge_exact', 'external_domain_bridge_receipt', 'transport_id', 'route_digest', 'carrier_id', 's1', 's2', 'r', 'c', 'sin1', 'sin2', 'resultant', 'cosine', 'metrics', 'golden_metrics'}
_DECIMAL_RE = re.compile('^[+-]?(?:\\d+\\.\\d*|\\d*\\.\\d+)(?:[eE][+-]?\\d+)?$')

def _result(node: Node, status: str, kind: str, statement: str, **payload: Any) -> AuxResult:
    return AuxResult(AUX_ID, status, kind, {'statement': statement, **payload}, node.identity())

def _parse_exact(v: Any):
    if isinstance(v, float):
        raise TypeError('floating point input forbidden')
    if isinstance(v, int):
        return sp.Integer(v)
    if isinstance(v, sp.Basic):
        return v
    if isinstance(v, str):
        t = v.strip()
        if not t or _DECIMAL_RE.match(t):
            raise ValueError('decimal literal forbidden')
        x = sp.sympify(t, locals={'sqrt': sp.sqrt})
        if x.has(sp.Float):
            raise ValueError('inexact scalar forbidden')
        return sp.simplify(x)
    raise TypeError('unsupported exact scalar type')

def _packet_from_node(node: Node) -> Dict[str, Any] | None:
    p = node.payload
    if isinstance(p.get('golden_aux_packet'), dict):
        return dict(p['golden_aux_packet'])
    if isinstance(p.get('golden_fragment'), dict):
        return dict(p['golden_fragment'])
    packet = {k: p[k] for k in _RELEVANT if k in p}
    metrics = p.get('golden_metrics') or p.get('metrics')
    if isinstance(metrics, dict):
        packet['metrics'] = dict(metrics)
    if not packet:
        text = str(p.get('statement', '')) + ' ' + node.kind
        if 'GOLDEN' not in text and '2SIN1COS' not in text:
            return None
    return packet

def _metric_values(packet: Dict[str, Any]) -> Dict[str, Any] | None:
    m = packet.get('metrics')
    if isinstance(m, dict) and all((k in m for k in ('s1', 's2', 'r', 'c'))):
        return {k: m[k] for k in ('s1', 's2', 'r', 'c')}
    aliases = {'s1': packet.get('s1', packet.get('sin1')), 's2': packet.get('s2', packet.get('sin2')), 'r': packet.get('r', packet.get('resultant')), 'c': packet.get('c', packet.get('cosine'))}
    return aliases if all((v is not None for v in aliases.values())) else None

def _scope_lattice(packet: Dict[str, Any], golden: bool, equal_sin: bool) -> Dict[str, Any]:
    role_closed = packet.get('typed_role_binding') is True
    metric_closed = all((packet.get(k) is True for k in ('rank2_residual_sector', 'rank1_solution_sector', 'orthonormal_metric', 'unit_normalization')))
    return {'schema': 'GOLDEN_SCOPE_LATTICE_SOLVER_ONLY_V1', 'L0_ROLE': 'CLOSED' if role_closed else 'OPEN', 'L1_METRIC': 'CLOSED' if metric_closed else 'OPEN', 'L2_GOLDEN_STATE': 'CLOSED_SCOPED' if golden else 'OPEN', 'L3_CANONICAL_EQUAL_SIN_GAUGE': 'CLOSED_SCOPED' if golden and equal_sin and (packet.get('orientation_seeded') is True) else 'OPEN', 'L4_EXTERNAL_REALIZATION': 'CLOSED_SCOPED' if packet.get('external_domain_bridge_receipt') is True else 'OPEN_BY_DESIGN', 'no_upward_promotion_without_receipt': True, 'verification_note': 0}

def golden_aux(node: Node, world: Dict[str, Any]) -> AuxResult:
    packet = _packet_from_node(node)
    if packet is None:
        return _result(node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', 'GOLDEN_AUX_NOT_APPLICABLE')
    try:
        fragment = dict(packet)
        if packet.get('typed_role_binding') is not True:
            if packet.get('bilateral_nonloop_orbit') is True and packet.get('closure_distinct_from_traversal') is True and packet.get('orientation_anchor'):
                fragment['typed_role_binding'] = True
            else:
                return _result(node, 'NEED_DATA', 'ROLE_BINDING_OBLIGATION', 'GOLDEN_AUX_NEED_TYPED_ROLE_BINDING', requires=['TYPED_ROLE_BINDING'], golden_fragment=fragment)
        missing = [k for k in ('rank2_residual_sector', 'rank1_solution_sector', 'orthonormal_metric', 'unit_normalization') if packet.get(k) is not True]
        if missing:
            return _result(node, 'MISSING_CARRIER', 'CARRIER_OBLIGATION', 'GOLDEN_AUX_MISSING_METRIC_CARRIER', requires=['GOLDEN_METRIC_CARRIER'], missing=missing, golden_fragment=fragment)
        if packet.get('normalized_unit_carrier') is not True:
            if packet.get('unit_normalization') is True:
                fragment['normalized_unit_carrier'] = True
            else:
                return _result(node, 'NEED_DATA', 'DATA_OBLIGATION', 'GOLDEN_AUX_NEED_UNIT_NORMALIZATION', requires=['UNIT_NORMALIZATION_RECEIPT'], golden_fragment=fragment)
        vals = _metric_values(packet)
        if vals is None or packet.get('exact_metrics_materialized') is not True:
            return _result(node, 'NEED_DATA', 'DATA_OBLIGATION', 'GOLDEN_AUX_NEED_EXACT_METRIC_PACKET', requires=['EXACT_GOLDEN_METRICS'], golden_fragment=fragment)
        if packet.get('same_state_same_carrier') is not True:
            return _result(node, 'NEED_DATA', 'DATA_OBLIGATION', 'GOLDEN_AUX_NEED_SAME_STATE_SAME_CARRIER', requires=['SAME_STATE_SAME_CARRIER_RECEIPT'], golden_fragment=fragment)
        e = {k: _parse_exact(v) for k, v in vals.items()}
        tri1 = sp.simplify(e['s1'] ** 2 + e['s2'] ** 2 - e['r'] ** 2)
        tri2 = sp.simplify(e['r'] ** 2 + e['c'] ** 2 - 1)
        bridge = sp.simplify(e['r'] ** 2 - e['c'])
        equal_sin = sp.simplify(e['s1'] - e['s2']) == 0
        valid = tri1 == 0 and tri2 == 0
        golden = valid and bridge == 0
        classification = {'status': 'INVALID_2SIN1COS_METRIC_GEOMETRY' if not valid else 'GOLDEN_STATE_EXACT' if golden else 'VALID_NON_GOLDEN_2SIN1COS_STATE', 'triangle1_residual': str(tri1), 'triangle2_residual': str(tri2), 'square_bridge_residual': str(bridge), 'golden_state': golden, 'canonical_equal_sin_gauge': equal_sin}
        scope = _scope_lattice(packet, golden, equal_sin)
        if not valid:
            return _result(node, 'INVALID', 'INVALID_RESULT', 'GOLDEN_AUX_INVALID_2SIN1COS_METRIC_GEOMETRY', classification=classification, scope_lattice=scope, supplies=['GOLDEN_AUX_TYPED_DEFECT'], golden_fragment=fragment)
        if not golden:
            return _result(node, 'PASS', 'GOLDEN_AUX_RESULT', 'GOLDEN_AUX_NON_GOLDEN_EXACT', classification=classification, scope_lattice=scope, supplies=['NON_GOLDEN_EXACT', 'METRIC_2SIN1COS_CARRIER'], golden_fragment=fragment)
        return _result(node, 'PASS', 'GOLDEN_STATE_RECEIPT', 'GOLDEN_STATE_CERTIFIED_EXACT_SCOPED', classification=classification, scope_lattice=scope, canonical_equal_sin_gauge=equal_sin, supplies=['GOLDEN_STATE_CERTIFIED', 'GOLDEN_SELECTOR_EXACT', 'METRIC_2SIN1COS_CARRIER'], golden_fragment=fragment, universal_truth_authority=False)
    except (TypeError, ValueError, KeyError) as exc:
        return _result(node, 'INVALID', 'INVALID_RESULT', 'GOLDEN_AUX_EXACT_ARITHMETIC_POLICY_REJECTED', error_type=type(exc).__name__, error=str(exc), supplies=['GOLDEN_AUX_TYPED_DEFECT'], golden_fragment=packet)

def golden_correlation_nodes(nodes: Iterable[Node], wave: int) -> List[Node]:
    frags = []
    for n in nodes:
        f = n.payload.get('golden_fragment')
        if isinstance(f, dict) and f:
            frags.append((n, dict(f)))
    if len(frags) < 2:
        return []
    merged = {}
    parents = []
    conflicts = {}
    for n, f in sorted(frags, key=lambda x: x[0].identity()):
        parents.append(n.identity())
        for k, v in f.items():
            if k not in merged:
                merged[k] = v
            elif merged[k] != v:
                conflicts.setdefault(k, [merged[k]])
                if v not in conflicts[k]:
                    conflicts[k].append(v)
    if conflicts:
        return [Node('GOLDEN_FRAGMENT_CONFLICT', {'statement': 'GOLDEN_AUX_FRAGMENT_CONFLICT', 'conflicts': conflicts, 'status': 'INVALID'}, tuple(sorted(set(parents))), wave)]
    return [Node('GOLDEN_AUX_COMPOSITE_INPUT', {'statement': 'GOLDEN_AUX_CORRELATED_INPUT', 'golden_aux_packet': merged, 'correlated_fragment_count': len(frags)}, tuple(sorted(set(parents))), wave)]
