from __future__ import annotations
import hashlib, json
from all_everything_wave_engine import Node, AuxResult, context_can_supply, context_prefix, obligation_rank, requirement_wrapper_depth
from dual_cell_geometry import *
from certification_kernel import CertificationKernel, Claim, ClaimKind, ClaimStatus, ProofObject, receipt, KernelStatus
from space_gap_realizer import QuestionIdentity
from causal_zfc.logic import V, Eq
from causal_zfc.synthesizer import CausalZFCSynthesizer
from causal_zfc.kernel import ZFCKernel
from zfc_v110_integration import golden_selector_analysis, cell1_invariant_packet, cell2_invariant_packet, bridge_request_nodes, execute_bridge_request, triangulation_transport_analysis
from golden_aux_bridge import golden_aux, golden_correlation_nodes
from triangulated_transport import hypercube_coordinate_search, zoo_carrier, continuous_triangulation_transport, triangulation_correlation_nodes, time_space_twist_witness, triangulated_tool_compiler
from parallel_transport import parallel_anchor_transport
from universal_everything_mechanisms import EXTRA_MECHANISMS, EXTRA_CATEGORIES
from materialization_engine import resolve_material, normalize_target
from proof_reconstruction_ac65_bridge import registry_fragment as proof_reconstruction_registry_fragment, category_fragment as proof_reconstruction_category_fragment
from causal_geometric_ac64_bridge import registry_fragment as causal_geometric_registry_fragment, category_fragment as causal_geometric_category_fragment
from automation_reconciliation_ac66 import registry_fragment as ac66_registry_fragment, category_fragment as ac66_category_fragment
from ac68_active_circuit import active_correlation_nodes, registry_fragment as ac68_registry_fragment, category_fragment as ac68_category_fragment

def result(aux, node, status, kind, **payload):
    return AuxResult(aux, status, kind, payload, node.identity())

def s(node):
    return json.dumps(node.payload, sort_keys=True, default=str)

def sha(x):
    return hashlib.sha256(json.dumps(x, sort_keys=True, default=str, separators=(',', ':')).encode()).hexdigest()

def target(node):
    explicit = node.payload.get('target_obligation') or node.payload.get('obligation')
    if explicit:
        return str(explicit)
    if node.kind in {'AUX_OBSERVATION', 'MECHANISM_OBSERVATION', 'DESCENT_GUARD_RECEIPT', 'CORRELATION_SEED', 'CORRELATION_LINK', 'COLLECTIVE_CURRENT', 'COLLECTIVE_FEEDBACK'} or node.kind.endswith('_RECEIPT'):
        return ''
    return str(node.payload.get('statement') or '')

def _materialish_target(t):
    u = str(t or '').upper()
    return any((k in u for k in ('MATERIAL', 'PROVIDER', 'RELATION', 'CARRIER', 'GENERATOR', 'WITNESS', 'BYTES', 'PAYLOAD', 'OBJECT', 'ENUMERATION', 'ROW', 'COEFFICIENT')))

def _materialized_result(mid, node, res, statement='UNIQUE_LAST_SURVIVOR_MATERIALIZED'):
    c = res['candidate']
    payload = c['payload']
    kind = c.get('kind') or 'object'
    supplies = list(c.get('supplies') or [])
    if isinstance(payload, dict):
        supplies = sorted(set(supplies + list(payload.get('supplies') or [])))
    return result(mid, node, 'PASS', 'MATERIALIZED_OBJECT', statement=statement, target=normalize_target(target(node)), construction_target=normalize_target(target(node)), material=payload, material_kind=kind, material_digest=c.get('digest'), materialization_audit=res.get('audit'), provenance=c.get('provenance'), supplies=supplies, delta_cost=[0, 0, 0, 0])

def materialization(node, world):
    if isinstance(node.payload.get('material_packet'), dict):
        supplies = list(node.payload['material_packet'].get('supplies') or [])
        return result('MATERIALIZATION', node, 'PASS', 'MATERIALIZED_OBJECT', statement='EXPLICIT_MATERIAL_PACKET_ACCEPTED', target=normalize_target(target(node)), construction_target=normalize_target(target(node)), material=node.payload['material_packet'], supplies=supplies, delta_cost=[0, 0, 0, 0])
    t = target(node)
    if not t and node.kind not in {'DATA_OBLIGATION', 'OPEN_RESIDUAL', 'OBLIGATION_STRATEGY_REQUEST'}:
        return result('MATERIALIZATION', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_MATERIALIZATION_ACTION')
    if not t:
        t = str(node.payload.get('obligation') or node.payload.get('target_obligation') or node.payload.get('statement') or '')
    if node.kind == 'OBLIGATION_STRATEGY_REQUEST' and (not _materialish_target(t)):
        return result('MATERIALIZATION', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_MATERIALIZATION_ACTION')
    if node.kind == 'OPEN_RESIDUAL' and (not _materialish_target(t)) and (not node.payload.get('materialization_catalog')):
        return result('MATERIALIZATION', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_MATERIALIZATION_ACTION')
    res = resolve_material(node.payload, world, t, None)
    if res['status'] == 'MATERIALIZED':
        return _materialized_result('MATERIALIZATION', node, res)
    if res['status'] == 'AMBIGUOUS':
        return result('MATERIALIZATION', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='MATERIALIZATION_AMBIGUOUS_LAST_SURVIVORS', materialization_audit=res['audit'], candidate_digests=[c.get('digest') for c in res['candidates']], requires=[f'DISAMBIGUATING_CONSTRAINT::{normalize_target(t)}'])
    if res['status'] == 'EXTERNAL_DEFINITION_REQUIRED':
        return result('MATERIALIZATION', node, 'WAITING', 'DEPENDENCY_WAIT', statement='EXTERNAL_DEFINITION_REQUIRED_AFTER_RECOVERY_AND_RECONSTRUCTION_EXHAUSTED', materialization_audit=res['audit'], requires=[f'EXTERNAL_DEFINITION::{normalize_target(t)}'])
    return result('MATERIALIZATION', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='RECOVERY_OR_RECONSTRUCTION_REQUIRED', materialization_audit=res['audit'], requires=[f'RECOVERY_EVIDENCE::{normalize_target(t)}'])

def carrier(node, world):
    if isinstance(node.payload.get('carrier_specification'), dict):
        spec = node.payload['carrier_specification']
        supplies = list(spec.get('supplies') or [])
        return result('CARRIER_REALIZER', node, 'PASS', 'CARRIER_OBJECT', statement='EXPLICIT_TYPED_CARRIER_ACCEPTED', carrier=spec, supplies=supplies, delta_cost=[0, 0, 0, 0])
    req = set((str(x) for x in node.payload.get('requires') or []))
    t = target(node)
    applicable = node.kind == 'CARRIER_OBLIGATION' or 'CARRIER' in t or any(('CARRIER' in x for x in req)) or (node.kind == 'OBLIGATION_STRATEGY_REQUEST' and node.payload.get('strategy') == 'CONSTRUCT_CARRIER')
    if not applicable:
        return result('CARRIER_REALIZER', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_CARRIER_ACTION')
    res = resolve_material(node.payload, world, t, 'carrier')
    if res['status'] == 'MATERIALIZED':
        c = res['candidate']
        return result('CARRIER_REALIZER', node, 'PASS', 'CARRIER_OBJECT', statement='UNIQUE_LAST_SURVIVOR_CARRIER_MATERIALIZED', target=normalize_target(t), construction_target=normalize_target(t), carrier=c['payload'], carrier_digest=c.get('digest'), materialization_audit=res['audit'], supplies=sorted(set(c.get('supplies') or ['TYPED_CARRIER'])), delta_cost=[0, 0, 0, 0])
    if res['status'] == 'AMBIGUOUS':
        return result('CARRIER_REALIZER', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='CARRIER_LAST_SURVIVOR_AMBIGUOUS', materialization_audit=res['audit'], requires=[f'DISAMBIGUATING_CONSTRAINT::{normalize_target(t)}'])
    if res['status'] == 'EXTERNAL_DEFINITION_REQUIRED':
        return result('CARRIER_REALIZER', node, 'WAITING', 'DEPENDENCY_WAIT', statement='EXTERNAL_CARRIER_DEFINITION_REQUIRED_AFTER_EXHAUSTION', materialization_audit=res['audit'], requires=[f'EXTERNAL_DEFINITION::{normalize_target(t)}'])
    return result('CARRIER_REALIZER', node, 'MISSING_CARRIER', 'CARRIER_OBLIGATION', statement='CARRIER_RECOVERY_OR_RECONSTRUCTION_REQUIRED', materialization_audit=res['audit'], requires=[f'RECOVERY_EVIDENCE::{normalize_target(t)}'])

def proof_defect(node, world):
    st = node.payload.get('status')
    if node.payload.get('fault') or st in {'INVALID', 'COUNTEREXAMPLE'} or node.kind in {'INVALID_RESULT', 'COUNTEREXAMPLE'}:
        return result('PROOF_DEFECT', node, 'OPEN', 'DEFECT_OBJECT', statement='TYPED_DEFECT', requires=['FAULT_LOCATION'])
    req = [str(x) for x in node.payload.get('requires') or []]
    scientific = bool(world.get('target_grain_mode') or world.get('universal_recursive_mode') or world.get('ac60_gap_closure_mode'))
    if scientific and node.kind == 'OPEN_RESIDUAL' and node.payload.get('obligation') and (not req):
        req = [str(node.payload['obligation'])]
    if scientific and req:
        cands = [{'id': r, 'cost': [obligation_rank(r), requirement_wrapper_depth(r), 0, len(r)]} for r in sorted(set(req))]
        return result('PROOF_DEFECT', node, 'OPEN', 'DEFECT_OBJECT', statement='TYPED_RESIDUAL_PROOF_DEFECT', residual_requirements=sorted(set(req)), delta_candidates=cands)
    if node.kind in {'PROOF_OBLIGATION', 'PROOF_SEARCH_NODE'} or any(('PROOF' in x or 'FORMAL' in x or 'CERTIFICATE' in x for x in req + [target(node)])):
        t = target(node) or node.payload.get('formal_target') or 'CURRENT'
        return result('PROOF_DEFECT', node, 'OPEN', 'PROOF_OBLIGATION', statement='FORMAL_PROOF_OBJECT_REQUIRED', requires=[f'FORMAL_GOAL::{t}'])
    return result('PROOF_DEFECT', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_PROOF_DEFECT_ACTION')

def fault(node, world):
    if node.payload.get('status') in {'INVALID', 'COUNTEREXAMPLE'} or node.kind in {'INVALID_RESULT', 'COUNTEREXAMPLE'}:
        return result('FAULT_DETECTOR', node, 'PASS', 'FAULT_LOCALIZATION', statement='FAULT_TYPED', supplies=['FAULT_LOCATION'], fault_zero=False)
    return result('FAULT_DETECTOR', node, 'PASS', 'FAULT_RECEIPT', statement='FAULT_ZERO_FOR_NODE', supplies=['FAULT_ZERO'], fault_zero=True)

def interval(node, world):
    if isinstance(node.payload.get('exact_interval'), dict):
        iv = node.payload['exact_interval']
        if all((k in iv for k in ('lower', 'upper'))):
            return result('INTERVAL_CERTIFIER', node, 'PASS', 'INTERVAL_RECEIPT', statement='EXACT_INTERVAL_CERTIFIED', interval=iv, supplies=list(iv.get('supplies') or ['EXACT_INTERVAL_CERTIFICATE']))
    req = [str(x) for x in node.payload.get('requires') or []]
    if any(('INTERVAL' in x or 'BOUND' in x for x in req + [target(node)])):
        return result('INTERVAL_CERTIFIER', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='EXACT_INTERVAL_DATA_REQUIRED', requires=['EXACT_INTERVAL_DATA'])
    return result('INTERVAL_CERTIFIER', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_INTERVAL_TARGET')

def farkas(node, world):
    if node.payload.get('farkas_witness_verified') is True:
        return result('FARKAS_DUAL', node, 'PASS', 'PROOF_CANDIDATE', statement='FARKAS_DUAL_WITNESS_ACCEPTED', witness=node.payload.get('farkas_witness'), supplies=list(node.payload.get('farkas_supplies') or ['SCOPED_DUAL_PROOF']))
    if node.kind == 'OBLIGATION_STRATEGY_REQUEST' and node.payload.get('strategy') in {'DUALIZE', 'FORMALIZE_OR_REFUTE'}:
        return result('FARKAS_DUAL', node, 'NEED_DATA', 'PROOF_OBLIGATION', statement='DUAL_WITNESS_REQUIRED', requires=[f'DUAL_OR_OBSTRUCTION_WITNESS::{target(node)}'])
    return result('FARKAS_DUAL', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_DUAL_ACTION')

def newton(node, world):
    if node.payload.get('newton_transition_verified') is True:
        return result('NEWTON_TRANSITION', node, 'PASS', 'TRANSITION_OBJECT', statement='EXACT_NEWTON_TRANSITION_ACCEPTED', transition=node.payload.get('newton_transition'), supplies=list(node.payload.get('newton_supplies') or ['NEWTON_RELATION']))
    if any(('NEWTON' in str(x) for x in node.payload.get('requires') or [])):
        return result('NEWTON_TRANSITION', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='EXACT_NEWTON_DATA_REQUIRED', requires=['EXACT_NEWTON_TRANSITION_DATA'])
    return result('NEWTON_TRANSITION', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_NEWTON_ACTION')

def provider_synthesizer(node, world):
    spec = node.payload.get('provider_specification')
    if isinstance(spec, dict) and spec.get('verified') is True:
        return result('PROVIDER_SYNTHESIZER', node, 'PASS', 'PROVIDER_OBJECT', statement='VERIFIED_PROVIDER_MATERIALIZED', provider=spec, supplies=list(spec.get('supplies') or []), delta_cost=list(spec.get('delta_cost') or [0, 0, 0, 0]))
    t = target(node)
    applicable = 'PROVIDER' in t or node.payload.get('provider_request') is True
    if not applicable:
        return result('PROVIDER_SYNTHESIZER', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_PROVIDER_ACTION')
    res = resolve_material(node.payload, world, t, 'provider')
    if res['status'] == 'MATERIALIZED':
        c = res['candidate']
        return result('PROVIDER_SYNTHESIZER', node, 'PASS', 'PROVIDER_OBJECT', statement='UNIQUE_LAST_SURVIVOR_PROVIDER_MATERIALIZED', target=normalize_target(t), construction_target=normalize_target(t), provider=c['payload'], provider_digest=c.get('digest'), materialization_audit=res['audit'], supplies=sorted(set(c.get('supplies') or [])), delta_cost=[0, 0, 0, 0])
    if res['status'] == 'AMBIGUOUS':
        return result('PROVIDER_SYNTHESIZER', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='PROVIDER_LAST_SURVIVOR_AMBIGUOUS', materialization_audit=res['audit'], requires=[f'DISAMBIGUATING_CONSTRAINT::{normalize_target(t)}'])
    if res['status'] == 'EXTERNAL_DEFINITION_REQUIRED':
        return result('PROVIDER_SYNTHESIZER', node, 'WAITING', 'DEPENDENCY_WAIT', statement='EXTERNAL_PROVIDER_DEFINITION_REQUIRED_AFTER_EXHAUSTION', materialization_audit=res['audit'], requires=[f'EXTERNAL_DEFINITION::{normalize_target(t)}'])
    return result('PROVIDER_SYNTHESIZER', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='PROVIDER_RECOVERY_RECONSTRUCTION_FEDERATION_REQUIRED', materialization_audit=res['audit'], requires=[f'RECOVERY_EVIDENCE::{normalize_target(t)}'])

def relation_synthesizer(node, world):
    rel = node.payload.get('exact_relation')
    if rel is not None and node.payload.get('relation_verified') is True:
        return result('RELATION_SYNTHESIZER', node, 'PASS', 'RELATION_OBJECT', statement='VERIFIED_EXACT_RELATION_ACCEPTED', relation=rel, supplies=list(node.payload.get('relation_supplies') or ['EXACT_RELATION']))
    t = target(node)
    applicable = 'RELATION' in t or 'ROW' in t or node.payload.get('relation_request') is True
    if not applicable:
        return result('RELATION_SYNTHESIZER', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_RELATION_ACTION')
    res = resolve_material(node.payload, world, t, 'relation')
    if res['status'] == 'MATERIALIZED':
        c = res['candidate']
        return result('RELATION_SYNTHESIZER', node, 'PASS', 'RELATION_OBJECT', statement='UNIQUE_LAST_SURVIVOR_RELATION_MATERIALIZED', target=normalize_target(t), construction_target=normalize_target(t), relation=c['payload'], relation_digest=c.get('digest'), materialization_audit=res['audit'], supplies=sorted(set(c.get('supplies') or ['EXACT_RELATION'])))
    if res['status'] == 'AMBIGUOUS':
        return result('RELATION_SYNTHESIZER', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='RELATION_LAST_SURVIVOR_AMBIGUOUS', materialization_audit=res['audit'], requires=[f'DISAMBIGUATING_CONSTRAINT::{normalize_target(t)}'])
    if res['status'] == 'EXTERNAL_DEFINITION_REQUIRED':
        return result('RELATION_SYNTHESIZER', node, 'WAITING', 'DEPENDENCY_WAIT', statement='EXTERNAL_RELATION_DEFINITION_REQUIRED_AFTER_EXHAUSTION', materialization_audit=res['audit'], requires=[f'EXTERNAL_DEFINITION::{normalize_target(t)}'])
    return result('RELATION_SYNTHESIZER', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='RELATION_RECOVERY_RECONSTRUCTION_REQUIRED', materialization_audit=res['audit'], requires=[f'RECOVERY_EVIDENCE::{normalize_target(t)}'])

def minimal_delta(node, world):
    if node.kind == 'DELTA_SET':
        cs = node.payload.get('candidates', [])
        if not cs:
            return result('MINIMAL_DELTA', node, 'OPEN', 'DELTA_RESIDUAL', statement='NO_DELTA_CANDIDATE', requires=['DELTA_CANDIDATE'])
        best = min(cs, key=lambda x: (tuple(x.get('cost', [999] * 4)), x.get('id', '')))
        return result('MINIMAL_DELTA', node, 'PASS', 'DELTA_SELECTED', statement='SCHEDULING_DELTA_SELECTED_NOT_SOVEREIGN_FULL_DELTA', selected=best, delta_semantics='SCHEDULER_STEP_ONLY', supplies=['SELECTED_DELTA'])
    if node.payload.get('delta_candidates'):
        cs = [{'id': x['id'], 'cost': x['cost'], 'source': node.identity()} for x in node.payload['delta_candidates']]
        return result('MINIMAL_DELTA', node, 'PASS', 'DELTA_SET', statement='DELTA_SET', candidates=cs)
    req = node.payload.get('requires') or []
    if isinstance(req, str):
        req = [req]
    scientific = bool(world.get('target_grain_mode') or world.get('universal_recursive_mode') or world.get('ac60_gap_closure_mode'))
    if scientific and node.kind == 'OPEN_RESIDUAL' and node.payload.get('obligation') and (not req):
        req = [node.payload['obligation']]
    if scientific and req:
        cs = [{'id': str(r), 'cost': [obligation_rank(str(r)), requirement_wrapper_depth(str(r)), 0, len(str(r))], 'source': node.identity()} for r in sorted(set((str(x) for x in req)))]
        return result('MINIMAL_DELTA', node, 'PASS', 'DELTA_SET', statement='AUTO_SCHEDULING_DELTA_SET_FROM_FULL_DELTA_COMPONENTS', delta_semantics='COMPONENTS_OF_SOVEREIGN_FULL_DELTA', candidates=cs)
    dc = node.payload.get('delta_cost')
    if dc is not None:
        return result('MINIMAL_DELTA', node, 'PARTIAL', 'DELTA_CANDIDATE', statement='DELTA_CANDIDATE', candidate_id=node.identity(), cost=dc, target=node.payload.get('statement'))
    return result('MINIMAL_DELTA', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_DELTA_DATA')

def _edge(eid, route, pos, seg, src, dst):
    return EdgeStep(eid, route, pos, seg, src, dst, ())

def _cell(cid, role, ori, start, end):
    mid1 = cid + '::SIN1_MID'
    mid2 = cid + '::SIN2_MID'
    fs, ss = ('a', 'b') if ori == Orientation.AB else ('b', 'a')
    return CausalCell(cid, role, ori, start, mid1, mid2, end, _edge(cid + '::S1A', Route.SIN1, Position.FIRST, fs, start, mid1), _edge(cid + '::S1B', Route.SIN1, Position.SECOND, ss, mid1, end), _edge(cid + '::S2A', Route.SIN2, Position.FIRST, fs, start, mid2), _edge(cid + '::S2B', Route.SIN2, Position.SECOND, ss, mid2, end), DiagonalStep(start, end, cid + '::COS'))

def cell_from_dict(d):

    def e(x):
        return EdgeStep(x['edge_id'], Route(x['route']), Position(x['position']), x['segment'], x['source'], x['target'], tuple(x.get('witnesses', [])), x.get('metadata', {}))
    c = d['cos']
    return CausalCell(d['cell_id'], CellRole(d['role']), Orientation(d['orientation']), d['start'], d['sin1_mid'], d['sin2_mid'], d['end'], e(d['sin1_first']), e(d['sin1_second']), e(d['sin2_first']), e(d['sin2_second']), DiagonalStep(c['source'], c['target'], c.get('diagonal_id', 'COS'), c.get('metadata', {})), tuple((tuple(x) for x in d.get('cross_witness_pairs_1', []))), tuple((tuple(x) for x in d.get('cross_witness_pairs_2', []))), d.get('metadata', {}))

def geometry(node, world):
    if node.kind == 'PROBLEM' and node.payload.get('requires_dual_cell'):
        end = 'R::' + node.identity()[:16]
        c = _cell('CELL1::' + node.identity()[:12], CellRole.RESIDUAL_CONTOUR, Orientation.AB, node.identity(), end)
        vr = verify_cell(c)
        return result('DUAL_CELL_GEOMETRY', node, 'PASS', 'CAUSAL_CELL', statement='RESIDUAL_CONTOUR_RETURNED', cell=c.to_dict(), cell_valid=vr.valid, supplies=['AB_CELL', 'SIN1_RETURNED', 'SIN2_RETURNED', 'COS_CALCULATED'])
    if node.kind == 'CAUSAL_CELL' and node.payload.get('cell', {}).get('role') == CellRole.RESIDUAL_CONTOUR.value:
        c1 = cell_from_dict(node.payload['cell'])
        end = 'S::' + node.identity()[:16]
        c2 = _cell('CELL2::' + node.identity()[:12], CellRole.DUAL_SOLUTION_CLOSURE, Orientation.BA, c1.end, end)
        dr = verify_dual_pass(c1, c2)
        return result('DUAL_CELL_GEOMETRY', node, 'PASS' if dr.valid else 'INVALID', 'DUAL_PASS_RECEIPT', statement='DUAL_SOLUTION_CLOSURE_RETURNED', dual_pass=dr.to_dict(), supplies=['DUAL_PASS_VERIFIED', 'SIN1_RETURNED', 'SIN2_RETURNED', 'COS_CALCULATED'] if dr.valid else [])
    return result('DUAL_CELL_GEOMETRY', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_CELL_ACTION')

def zfc(node, world):
    if node.kind == 'GOLDEN_STATE_RECEIPT' and node.payload.get('statement') == 'GOLDEN_STATE_CERTIFIED_EXACT_SCOPED':
        try:
            ga = golden_selector_analysis(node)
            a = ga['analysis']
            return result('ZFC_PROOF_SYNTHESIZER', node, 'PASS' if a.get('STATE_SELECTOR_VERIFIED') else 'OPEN', 'CAUSAL_STATE_ANALYSIS', statement='GOLDEN_SELECTOR_ZFC_KERNEL_VERIFIED_SCOPED' if a.get('STATE_SELECTOR_VERIFIED') else 'GOLDEN_SELECTOR_FORMALIZATION_OPEN', zfc_version='V1.10_PASS011', causal_state=a, selector_receipt=ga['selector_receipt'], formalization_mode=ga['formalization_mode'], supplies=['STATE_SELECTOR_VERIFIED', 'STRUCTURAL_CLOSURE'] if a.get('STATE_SELECTOR_VERIFIED') else ['STATE_SELECTOR_OBLIGATION'])
        except Exception as exc:
            return result('ZFC_PROOF_SYNTHESIZER', node, 'INVALID', 'INVALID_RESULT', statement='GOLDEN_SELECTOR_ZFC_FORMALIZATION_REJECTED', error=str(exc))
    if node.kind == 'CAUSAL_CELL' and node.payload.get('cell_valid'):
        try:
            cp = cell1_invariant_packet(node)
            return result('ZFC_PROOF_SYNTHESIZER', node, 'PASS', 'CAUSAL_STATE_PACKET', statement='CELL1_OUTPUT_INVARIANT_PACKET', zfc_version='V1.10_PASS011', **cp, supplies=['CELL1_OUTPUT_INVARIANT'])
        except Exception as exc:
            return result('ZFC_PROOF_SYNTHESIZER', node, 'INVALID', 'INVALID_RESULT', statement='CELL1_INVARIANT_PACKET_REJECTED', error=str(exc))
    if node.kind == 'DUAL_PASS_RECEIPT' and node.payload.get('dual_pass', {}).get('valid'):
        try:
            cp = cell2_invariant_packet(node)
            return result('ZFC_PROOF_SYNTHESIZER', node, 'PASS', 'CAUSAL_STATE_PACKET', statement='CELL2_INPUT_INVARIANT_PACKET', zfc_version='V1.10_PASS011', **cp, supplies=['CELL2_INPUT_INVARIANT'])
        except Exception as exc:
            return result('ZFC_PROOF_SYNTHESIZER', node, 'INVALID', 'INVALID_RESULT', statement='CELL2_INVARIANT_PACKET_REJECTED', error=str(exc))
    if node.kind == 'CAUSAL_TWO_CELL_BRIDGE_REQUEST':
        try:
            br = execute_bridge_request(node)
            if br.get('closed'):
                return result('ZFC_PROOF_SYNTHESIZER', node, 'PASS', 'CAUSAL_INVARIANT_BRIDGE_RECEIPT', statement='CELL1_TO_CELL2_FORMAL_INVARIANT_BRIDGE_CLOSED', zfc_version='V1.10_PASS011', bridge=br, invariant_bridge_verified=True, supplies=['CAUSAL_INVARIANT_BRIDGE_VERIFIED'])
            return result('ZFC_PROOF_SYNTHESIZER', node, 'OPEN', 'PROOF_SEARCH_NODE', statement='CELL1_TO_CELL2_FORMAL_INVARIANT_BRIDGE_OPEN', zfc_version='V1.10_PASS011', bridge=br, requires=['INVARIANT_BRIDGE_PROOF'])
        except Exception as exc:
            return result('ZFC_PROOF_SYNTHESIZER', node, 'INVALID', 'INVALID_RESULT', statement='CELL1_TO_CELL2_FORMAL_INVARIANT_BRIDGE_REJECTED', error=str(exc))
    if node.kind == 'TRIANGULATION_TWIST_RECEIPT':
        try:
            ta = triangulation_transport_analysis(node)
            return result('ZFC_PROOF_SYNTHESIZER', node, 'PASS', 'TRIANGULATED_TRANSPORT_ZFC_RECEIPT', statement='FORWARD_REVERSE_TRIANGULATION_TRANSPORT_FORMALLY_BOUND', zfc_version='V1.10_PASS011', transport_id=ta.get('transport_id'), carrier_id=ta.get('carrier_id'), transport_kernel_verified=ta.get('transport_kernel_verified'), transport_analysis=ta, external_domain_bridge_receipt=ta.get('external_domain_bridge_receipt'), supplies=['TRIANGULATED_TRANSPORT_FORMALLY_BOUND'])
        except Exception as exc:
            return result('ZFC_PROOF_SYNTHESIZER', node, 'INVALID', 'INVALID_RESULT', statement='TRIANGULATED_TRANSPORT_FORMALIZATION_REJECTED', error=str(exc))
    g = node.payload.get('zfc_goal')
    if not g:
        req = [str(x) for x in node.payload.get('requires') or []]
        proofish = node.kind in {'PROOF_SEARCH_NODE', 'PROOF_CANDIDATE', 'PROOF_OBLIGATION'} or any(('PROOF' in x or 'FORMAL' in x or 'CERTIFICATE' in x for x in req + [target(node)]))
        if proofish:
            return result('ZFC_PROOF_SYNTHESIZER', node, 'NEED_DATA', 'PROOF_SEARCH_NODE', statement='ZFC_GOAL_NOT_MATERIALIZED', requires=['FORMAL_GOAL'], zfc_version='V1.10_PASS011')
        return result('ZFC_PROOF_SYNTHESIZER', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_ZFC_ACTION', zfc_version='V1.10_PASS011')
    if (world.get('target_grain_mode') or world.get('universal_recursive_mode') or world.get('ac60_gap_closure_mode')) and g.get('kind') in {'OPAQUE_ATOM', 'OPAQUE_NEGATION'}:
        base = str(g.get('atom') or node.payload.get('formal_target') or node.payload.get('target') or node.payload.get('statement') or 'CURRENT')
        return result('ZFC_PROOF_SYNTHESIZER', node, 'OPEN', 'PROOF_SEARCH_NODE', statement='OPAQUE_SCIENTIFIC_GOAL_FORMALIZED_SEARCH_OPEN', formal_target=base, zfc_goal=g, zfc_version='V1.10_PASS011', requires=[f'COMPLETE_PROOF_OBJECT::{base}'])
    if g.get('kind') == 'EQ_REFL':
        goal = Eq(V(g.get('var', 'x')), V(g.get('var', 'x')))
        syn = CausalZFCSynthesizer(budget=50, max_depth=6)
        sr = syn.synthesize(goal, ())
        if sr.status == 'PROVED':
            kd = ZFCKernel().verify(sr.proof)
            pd = sha({'goal': str(goal), 'rule': sr.proof.rule, 'explored': sr.explored, 'zfc_version': 'V1.10_PASS011'})
            return result('ZFC_PROOF_SYNTHESIZER', node, 'PASS', 'ZFC_PROOF_TERM', statement=node.payload.get('statement', 'FORMAL_GOAL'), zfc_status=sr.status, zfc_kernel_ok=kd.ok, proof_digest=pd, zfc_version='V1.10_PASS011', supplies=['COMPLETE_PROOF_OBJECT', 'ZFC_PROOF_TERM'])
        return result('ZFC_PROOF_SYNTHESIZER', node, 'OPEN', 'PROOF_SEARCH_NODE', statement='ZFC_SEARCH_OPEN', residual=sr.residual, zfc_version='V1.10_PASS011')
    return result('ZFC_PROOF_SYNTHESIZER', node, 'OPEN', 'PROOF_SEARCH_NODE', statement='UNSUPPORTED_FORMAL_GOAL', zfc_version='V1.10_PASS011', requires=['SUPPORTED_FORMALIZATION'])

def cert_kernel(node, world):
    if node.kind != 'ZFC_PROOF_TERM' or not node.payload.get('zfc_kernel_ok'):
        proofish = node.kind in {'PROOF_SEARCH_NODE', 'PROOF_CANDIDATE', 'PROOF_OBLIGATION'} or any(('PROOF' in str(x) or 'FORMAL' in str(x) for x in node.payload.get('requires') or []))
        if proofish:
            return result('CERTIFICATION_KERNEL', node, 'NEED_DATA', 'PROOF_OBLIGATION', statement='KERNEL_NEEDS_COMPLETE_VERIFIED_PROOF_OBJECT', requires=['COMPLETE_PROOF_OBJECT'])
        return result('CERTIFICATION_KERNEL', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_KERNEL_ACTION')
    ident = QuestionIdentity('AC59_SOLVER_QUALIFICATION', 'CURRENT', 'ROOT_DISCHARGE_RECEIPT', '20260919', 'SOLVER_ONLY')
    key = node.payload.get('statement', 'FORMAL_GOAL')
    rr = receipt('ZFC_V1_10_PASS011', key, ident, node.payload['proof_digest'], 'ZFC_KERNEL', 'provable_statement')
    cl = Claim('ROOT_ATOMIC', key, ClaimKind.ATOMIC_PROOF_OBLIGATION, ClaimStatus.OPEN, ident, receipt=rr)
    po = ProofObject('AC59_ROOT_PROOF', key, [cl], ['ROOT_ATOMIC'], ident, {'zfc_proof_digest': node.payload['proof_digest']})
    kr = CertificationKernel().verify(po)
    if kr.status == KernelStatus.PASS:
        return result('CERTIFICATION_KERNEL', node, 'PASS', 'KERNEL_RECEIPT', statement=key, formal_target=node.payload.get('formal_target') or key, kernel_verified=True, proof_digest=node.payload['proof_digest'], supplies=['KERNEL_VERIFIED_PROOF'])
    return result('CERTIFICATION_KERNEL', node, 'INVALID', 'KERNEL_REJECT', statement=key, kernel_verified=False, rejected=list(kr.rejected))

def apply_remeasure(node, world):
    if node.kind == 'KERNEL_RECEIPT' and node.payload.get('kernel_verified'):
        return result('APPLY_REMEASURE', node, 'PASS', 'REMEASURE_RECEIPT', statement='APPLY_THEN_REMEASURE_ZERO', applied=True, residual_zero=True, supplies=['REMEASURE_ZERO'])
    if node.kind == 'FAULT_LOCALIZATION':
        return result('APPLY_REMEASURE', node, 'PARTIAL', 'REPAIR_CURRENT', statement='FAULT_REPAIR_REMEASURE', requires=['SELECTED_DELTA'])
    if node.kind in {'REPAIR_CURRENT', 'DELTA_SELECTED'}:
        return result('APPLY_REMEASURE', node, 'WAITING', 'APPLY_WAIT', statement='APPLY_WAITS_FOR_KERNEL_OR_FAULT', requires=['KERNEL_VERIFIED_PROOF'])
    return result('APPLY_REMEASURE', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_APPLY_ACTION')

def return_manager(node, world):
    if node.kind == 'CLOSURE_STATE' and all((node.payload.get(k) for k in ['kernel_verified', 'dual_pass_verified', 'invariant_bridge_verified', 'fault_zero', 'remeasure_zero'])):
        return result('RETURN_MANAGER', node, 'PASS', 'ROOT_RECEIPT', statement='STRUCTURAL_ROOT_RETURN_RECEIPT_REQUIRES_EXTERNAL_FORMAL_PROOF_FOR_SCIENTIFIC_ROOT', kernel_verified=True, truth_credit_added=0, external_scientific_truth_certified=False, supplies=['STRUCTURAL_ROOT_RETURN'])
    if node.kind == 'CLOSURE_STATE':
        return result('RETURN_MANAGER', node, 'OPEN', 'OPEN_RESIDUAL_CURRENT', statement='CLOSURE_STATE_STILL_OPEN', closure_state=dict(node.payload))
    return result('RETURN_MANAGER', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_RETURN_ACTION')

def target_grain_return_manager(node, world):
    if node.kind != 'NODE_2SIN1COS_REQUEST':
        return result('TARGET_GRAIN_RETURN_MANAGER', node, 'NOT_APPLICABLE', 'AUX_OBSERVATION', statement='NO_TARGET_GRAIN_RETURN_ACTION')
    fid = str(node.payload.get('focus_id') or '')
    results = [x for x in node.payload.get('geometry_results') or [] if isinstance(x, dict)]
    ready = bool(node.payload.get('sin2_derived') and node.payload.get('cos_derived') and results)
    segments = []
    for rr in results:
        if rr.get('proof_ready') is not True:
            ready = False
        for seg in rr.get('segments') or []:
            if isinstance(seg, dict):
                legs = seg.get('legs') or {}
                diag = seg.get('diagonal') or {}
                ident = seg.get('identity_receipts') or {}
                segments.append({'from': seg.get('from'), 'to': seg.get('to'), 'frame': seg.get('frame'), 'sin1_time_energy': legs.get('time_squared'), 'sin2_space_energy': legs.get('space_squared'), 'cos_solution_energy': diag.get('squared'), 'pythagorean_pass': ident.get('pythagorean_pass'), 'quadrature': 'PI_OVER_2'})
                if ident.get('pythagorean_pass') is not True:
                    ready = False
    resolved = list(node.payload.get('resolved_effects') or [])
    if ready:
        supplies = ['NODE_RETURN::' + fid, 'SIN2_DERIVED_FROM_SIN1_QUADRATURE', 'COS_DERIVED_FROM_CAUSAL_TRIANGULATION', 'CAUSAL_SOLUTION_GEOMETRY_READY']
        supplies += ['CERTIFIED::' + str(x) for x in resolved]
        return result('TARGET_GRAIN_RETURN_MANAGER', node, 'PASS', 'NODE_RETURN_RECEIPT', statement='NODE_DIRECT_CAUSAL_TRIANGULATION_RETURN', focus_id=fid, source_node_id=node.payload.get('source_node_id'), parent_node_ids=node.payload.get('parent_node_ids', []), sin1_verified=True, sin2_derived=True, cos_derived=True, causal_solution_geometry_ready=True, triangulated_segments=segments, returned_effect='NODE_RETURN::' + fid, returned_effects=resolved, supplies=sorted(set(supplies)), truth_credit_added=0, external_scientific_truth_certified=False)
    return result('TARGET_GRAIN_RETURN_MANAGER', node, 'OPEN', 'OPEN_RESIDUAL_CURRENT', statement='DIRECT_CAUSAL_TRIANGULATION_AWAITS_ROUTE_POINTS', focus_id=fid, source_node_id=node.payload.get('source_node_id'), parent_node_ids=node.payload.get('parent_node_ids', []), sin1_verified=True, sin2_derived=False, cos_derived=False, causal_solution_geometry_ready=False, known_geometry_receipts=node.payload.get('geometry_receipt_ids', []), resolved_effects=resolved)

def correlation_aux(node, world):
    return result('CORRELATION', node, 'PARTIAL', 'CORRELATION_SEED', statement='PUBLISH_FOR_CORRELATION')
CORE_REGISTRY = {'MATERIALIZATION': materialization, 'CARRIER_REALIZER': carrier, 'PROOF_DEFECT': proof_defect, 'FAULT_DETECTOR': fault, 'INTERVAL_CERTIFIER': interval, 'FARKAS_DUAL': farkas, 'NEWTON_TRANSITION': newton, 'PROVIDER_SYNTHESIZER': provider_synthesizer, 'RELATION_SYNTHESIZER': relation_synthesizer, 'MINIMAL_DELTA': minimal_delta, 'DUAL_CELL_GEOMETRY': geometry, 'ZFC_PROOF_SYNTHESIZER': zfc, 'CERTIFICATION_KERNEL': cert_kernel, 'APPLY_REMEASURE': apply_remeasure, 'RETURN_MANAGER': return_manager, 'TARGET_GRAIN_RETURN_MANAGER': target_grain_return_manager, 'CORRELATION': correlation_aux, 'GOLDEN_2SIN1COS_AUX': golden_aux, 'HYPERCUBE_COORDINATE_SEARCH': hypercube_coordinate_search, 'ZOO_CARRIER': zoo_carrier, 'CONTINUOUS_2SIN1COS_TRIANGULATION_TRANSPORT': continuous_triangulation_transport, 'TIME_SPACE_BASIS_COORDINATE_TWIST': time_space_twist_witness, 'TRIANGULATED_TOOL_COMPILER': triangulated_tool_compiler, 'PARALLEL_ANCHOR_FINITE_DIFFERENCE_TRANSPORT': parallel_anchor_transport}
CORE_CATEGORIES = {'MATERIALIZATION': 'CORE_AUX', 'CARRIER_REALIZER': 'CORE_AUX', 'PROOF_DEFECT': 'CORE_AUX', 'FAULT_DETECTOR': 'CORE_AUX', 'INTERVAL_CERTIFIER': 'MATHEMATICS', 'FARKAS_DUAL': 'MATHEMATICS', 'NEWTON_TRANSITION': 'MATHEMATICS', 'PROVIDER_SYNTHESIZER': 'CORE_AUX', 'RELATION_SYNTHESIZER': 'CORE_AUX', 'MINIMAL_DELTA': 'SOLVER_CONTROL', 'DUAL_CELL_GEOMETRY': 'CAUSAL_GEOMETRY', 'ZFC_PROOF_SYNTHESIZER': 'MATHEMATICS', 'CERTIFICATION_KERNEL': 'CERTIFICATION', 'APPLY_REMEASURE': 'SOLVER_CONTROL', 'RETURN_MANAGER': 'RETURN', 'TARGET_GRAIN_RETURN_MANAGER': 'RETURN', 'CORRELATION': 'CORRELATION', 'GOLDEN_2SIN1COS_AUX': 'CAUSAL_GEOMETRY', 'HYPERCUBE_COORDINATE_SEARCH': 'CAUSAL_GEOMETRY', 'ZOO_CARRIER': 'NATIVE_VALVE', 'CONTINUOUS_2SIN1COS_TRIANGULATION_TRANSPORT': 'CAUSAL_GEOMETRY', 'TIME_SPACE_BASIS_COORDINATE_TWIST': 'CAUSAL_GEOMETRY', 'TRIANGULATED_TOOL_COMPILER': 'STRUCTURAL_TOOL', 'PARALLEL_ANCHOR_FINITE_DIFFERENCE_TRANSPORT': 'CAUSAL_GEOMETRY'}
CAUSAL_GEOMETRIC_REGISTRY = causal_geometric_registry_fragment()
CAUSAL_GEOMETRIC_CATEGORIES = causal_geometric_category_fragment()
PROOF_RECONSTRUCTION_REGISTRY = proof_reconstruction_registry_fragment()
AC66_AUTOMATION_REGISTRY = ac66_registry_fragment()
PROOF_RECONSTRUCTION_CATEGORIES = proof_reconstruction_category_fragment()
AC68_ACTIVE_CORRELATION_REGISTRY = ac68_registry_fragment()
REGISTRY = dict(sorted({**CORE_REGISTRY, **EXTRA_MECHANISMS, **CAUSAL_GEOMETRIC_REGISTRY, **PROOF_RECONSTRUCTION_REGISTRY, **AC66_AUTOMATION_REGISTRY, **AC68_ACTIVE_CORRELATION_REGISTRY}.items()))
MECHANISM_CATEGORIES = {**CORE_CATEGORIES, **EXTRA_CATEGORIES, **CAUSAL_GEOMETRIC_CATEGORIES, **PROOF_RECONSTRUCTION_CATEGORIES, **ac66_category_fragment(), **ac68_category_fragment()}
assert set(REGISTRY) == set(MECHANISM_CATEGORIES)

def correlation(raw, wave, known, world):
    nodes = list(known.values())
    out = []
    sup = {}
    req = []
    for n in nodes:
        for t in n.payload.get('supplies', []):
            sup.setdefault(t, []).append(n)
        for t in n.payload.get('requires', []):
            req.append((t, n))
    for tok, c in req:
        for p in sup.get(tok, []):
            if not context_can_supply(tuple(p.context), tuple(c.context)):
                continue
            ctx = c.context if len(c.context) >= len(p.context) else p.context
            out.append(Node('CORRELATION_LINK', {'statement': 'SUPPLY_LINK::' + tok, 'relation': 'SUPPLIES', 'token': tok, 'provider': p.identity(), 'consumer': c.identity()}, tuple(sorted((p.identity(), c.identity()))), wave, tuple(ctx)))
    byctx = {}
    for n in nodes:
        if n.kind == 'DELTA_CANDIDATE':
            byctx.setdefault(tuple(n.context), []).append({'id': n.payload.get('candidate_id', n.identity()), 'cost': n.payload.get('cost', [999] * 4), 'source': n.identity()})
    for ctx, cs in sorted(byctx.items()):
        cs = sorted({json.dumps(x, sort_keys=True): x for x in cs}.values(), key=lambda x: (tuple(x['cost']), x['id']))
        out.append(Node('DELTA_SET', {'statement': 'DELTA_SET', 'candidates': cs}, tuple((x['source'] for x in cs)), wave, ctx))
    contexts = sorted({tuple(n.context) for n in nodes}) or [()]

    def scoped(ctx):
        if not ctx:
            return [n for n in nodes if not n.context]
        return [n for n in nodes if not n.context or context_prefix(ctx, tuple(n.context)) or context_prefix(tuple(n.context), ctx)]
    for ctx in contexts:
        local = scoped(ctx)
        kv = any((n.kind == 'KERNEL_RECEIPT' and n.payload.get('kernel_verified') for n in local))
        dv = any((n.kind == 'DUAL_PASS_RECEIPT' and n.payload.get('dual_pass', {}).get('valid') for n in local))
        fz = any((n.kind == 'FAULT_RECEIPT' and n.payload.get('fault_zero') for n in local))
        rz = any((n.kind == 'REMEASURE_RECEIPT' and n.payload.get('residual_zero') for n in local))
        ivb = any((n.kind == 'CAUSAL_INVARIANT_BRIDGE_RECEIPT' and n.payload.get('invariant_bridge_verified') for n in local))
        if kv and dv and ivb and fz and rz:
            parents = tuple(sorted((n.identity() for n in local if n.kind in {'KERNEL_RECEIPT', 'DUAL_PASS_RECEIPT', 'CAUSAL_INVARIANT_BRIDGE_RECEIPT', 'FAULT_RECEIPT', 'REMEASURE_RECEIPT'})))
            out.append(Node('CLOSURE_STATE', {'statement': 'CLOSURE_STATE', 'kernel_verified': True, 'dual_pass_verified': True, 'invariant_bridge_verified': True, 'fault_zero': True, 'remeasure_zero': True}, parents, wave, ctx))
    # AC68: transform open global-current branches into active scientific currents, probe
    # candidate providers recursively, and rebuild the current whenever an exact supply appears.
    out.extend(active_correlation_nodes(nodes, wave, world))
    for ctx in contexts:
        local = scoped(ctx)
        for m in golden_correlation_nodes(local, wave):
            out.append(Node(m.kind, m.payload, m.parents, m.wave, ctx))
        for m in triangulation_correlation_nodes(local, wave):
            out.append(Node(m.kind, m.payload, m.parents, m.wave, ctx))
        for m in bridge_request_nodes(local, wave):
            out.append(Node(m.kind, m.payload, m.parents, m.wave, ctx))
    return out
