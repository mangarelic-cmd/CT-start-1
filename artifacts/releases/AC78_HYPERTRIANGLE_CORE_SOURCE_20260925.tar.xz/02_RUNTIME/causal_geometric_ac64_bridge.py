"""AC64 direct causal-geometric bridge.

The geometric AUX is used as an active proof constructor. Any exact route points already
present in a node are collected automatically. Consecutive space/time points are triangulated,
SIN1/SIN2 are read as the orthogonal legs, and COS as the common diagonal/closure channel.
No separate gate queue is created when information is absent; the trace simply remains open.
"""
from __future__ import annotations
from copy import deepcopy
from hashlib import sha256
import json
from typing import Any, Mapping
from all_everything_wave_engine import AuxResult, Node
from causal_geometric_solver_adapter_v0_6 import ENGINE_MECHANISM_ID, TRANSPORT_VALIDATOR_ID, REQUEST_FIELD, REQUEST_SCHEMA, causal_geometric_proof_engine as _native_engine, causal_geometric_canonical_transport_validator as _native_validator
CATEGORY = 'CAUSAL_GEOMETRY'
BRIDGE_SCHEMA = 'CT_AC64_DIRECT_CAUSAL_TRIANGULATION_AUTOCLOSURE_V1'

def _canon(x: Any) -> str:
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True, default=str)

def _digest(x: Any) -> str:
    return sha256(_canon(x).encode()).hexdigest()

def _clean(x: Any) -> Any:
    if isinstance(x, Mapping):
        return {k:_clean(v) for k,v in x.items()}
    if isinstance(x, list):
        return [_clean(v) for v in x]
    if isinstance(x, tuple):
        return tuple((_clean(v) for v in x))
    return x

def _find_request(value: Any, depth: int=0):
    if depth > 6:
        return None
    if isinstance(value, Mapping):
        d = value.get(REQUEST_FIELD)
        if isinstance(d, Mapping):
            return d
        if value.get('schema') in {REQUEST_SCHEMA, 'CT_CAUSAL_GEOMETRIC_SOLVER_REQUEST_V0_5'} and value.get('operation'):
            return value
        for k in ('causal_geometric_request_spec', 'material', 'provider', 'payload', 'result', 'resolved_provider_payloads'):
            if k in value:
                got = _find_request(value[k], depth + 1)
                if got is not None:
                    return got
        for v in value.values():
            got = _find_request(v, depth + 1)
            if got is not None:
                return got
    elif isinstance(value, (list, tuple)):
        for v in value:
            got = _find_request(v, depth + 1)
            if got is not None:
                return got
    return None

def _point_like(d: Mapping[str, Any]) -> bool:
    return all((k in d for k in ('space_id', 'time_id', 'x', 't')))

def _normalize_point(d: Mapping[str, Any], fallback_id: str) -> dict[str, Any]:
    return {'point_id': str(d.get('point_id') or d.get('id') or fallback_id), 'space_id': str(d['space_id']), 'time_id': str(d['time_id']), 'orientation': str(d.get('orientation') or 'NATIVE').upper(), 'x': deepcopy(d['x']), 't': deepcopy(d['t']), 'coordinate_provenance': str(d.get('coordinate_provenance') or ('CERTIFIED' if d.get('coordinate_certified') else 'DECLARED')), 'coordinate_provenance_kind': str(d.get('coordinate_provenance_kind') or d.get('provenance_kind') or ('DERIVED_EXACT' if d.get('coordinate_certified') else 'DECLARED')).upper(), 'coordinate_role': str(d.get('coordinate_role') or 'DOMAIN').upper(), 'external_metric_authority': bool(d.get('external_metric_authority', d.get('metric_authority', d.get('coordinate_certified', False)))), **({'gx': deepcopy(d['gx'])} if 'gx' in d else {}), **({'gt': deepcopy(d['gt'])} if 'gt' in d else {})}

def _collect_points(value: Any, prefix='P', depth: int=0):
    if depth > 8:
        return []
    out = []
    if isinstance(value, Mapping):
        if _point_like(value):
            out.append(_normalize_point(value, prefix))
        for k, v in value.items():
            if k == REQUEST_FIELD:
                continue
            out.extend(_collect_points(v, f'{prefix}_{k}', depth + 1))
    elif isinstance(value, (list, tuple)):
        for i, v in enumerate(value):
            out.extend(_collect_points(v, f'{prefix}_{i}', depth + 1))
    seen = set()
    ans = []
    for p in out:
        h = _digest(p)
        if h not in seen:
            seen.add(h)
            ans.append(p)
    return ans

def _trace_key(node: Node) -> str:
    p = node.payload
    return str(p.get('question_identity') or p.get('root_target') or p.get('source_statement') or ('CTX::' + '::'.join(node.context) if node.context else p.get('statement') or node.semantic_identity()))

def _request_from_trace(node: Node, world: dict[str, Any]):
    points = _collect_points(node.payload, node.kind)
    bank = world.setdefault('_ac64_causal_route_bank', {})
    key = _trace_key(node)
    rows = list(bank.get(key) or [])
    rows.extend(_collect_points((world.get('causal_route_points') or {}).get(key, []) if isinstance(world.get('causal_route_points'), dict) else world.get('causal_route_points') or [], 'WORLD'))
    rows.extend(points)
    uniq = []
    seen = set()
    for p in rows:
        h = _digest(p)
        if h in seen:
            continue
        seen.add(h)
        uniq.append(p)
    bank[key] = uniq
    if len(uniq) < 2:
        return None
    return {'schema': REQUEST_SCHEMA, 'operation': 'ROUTE', 'points': uniq}

def _segment_roles(seg: Mapping[str, Any]) -> dict[str, Any]:
    legs = seg.get('legs') or {}
    diag = seg.get('diagonal') or {}
    trig = seg.get('trigonometry') or {}
    return {'from': seg.get('from'), 'to': seg.get('to'), 'frame': seg.get('frame'), 'sin1_time_energy': legs.get('time_squared'), 'sin2_space_energy': legs.get('space_squared'), 'cos_solution_energy': diag.get('squared'), 'identity': 'SIN1_TIME^2 + SIN2_SPACE^2 = COS_DIAGONAL^2', 'pythagorean_pass': (seg.get('identity_receipts') or {}).get('pythagorean_pass'), 'question_angle_to_time_axis': trig.get('angle'), 'sin_ratio': trig.get('sin'), 'cos_ratio': trig.get('cos'), 'tan_ratio': trig.get('tan'), 'quadrature': 'SIN2_ORTHOGONAL_TO_SIN1__ANGLE_SEPARATION_PI_OVER_2'}

def _completion_payload(payload: dict[str, Any]) -> dict[str, Any]:
    payload = _clean(payload)
    result = payload.get('result') or {}
    segs = list(result.get('segments') or []) if isinstance(result, Mapping) else []
    roles = [_segment_roles(s) for s in segs]
    proof_ready = bool(result.get('proof_ready')) if isinstance(result, Mapping) else False
    payload['ac64_direct_bridge'] = BRIDGE_SCHEMA
    payload['automatic_route_point_count'] = len((payload.get('request') or {}).get('points') or [])
    payload['causal_triangulation'] = roles
    payload['sin1_role'] = 'QUESTION_OUTBOUND_TIME'
    payload['sin2_role'] = 'ORTHOGONAL_RESPONSE_RETURN_SPACE'
    payload['cos_role'] = 'COMMON_SOLUTION_CLOSURE_DIAGONAL'
    payload['sin2_geometry_derived'] = bool(proof_ready and roles)
    payload['cos_geometry_derived'] = bool(proof_ready and roles)
    payload['causal_solution_geometry_ready'] = bool(proof_ready and roles and all((r.get('pythagorean_pass') is True for r in roles)))
    supplies = list(payload.get('supplies') or [])
    if payload['sin2_geometry_derived']:
        supplies += ['SIN2_DERIVED_FROM_SIN1_QUADRATURE']
    if payload['cos_geometry_derived']:
        supplies += ['COS_DERIVED_FROM_CAUSAL_TRIANGULATION', 'CAUSAL_GEOMETRIC_SOLUTION_TRIANGULATED']
    payload['supplies'] = sorted(set((str(x) for x in supplies)))
    return payload

def causal_geometric_proof_engine_ac64(node: Node, world: dict[str, Any]) -> AuxResult:
    p = dict(node.payload)
    request = _find_request(p)
    auto = False
    if request is None:
        request = _request_from_trace(node, world)
        auto = request is not None
    if request is None:
        return AuxResult(ENGINE_MECHANISM_ID, 'NOT_APPLICABLE', 'AUX_OBSERVATION', {'schema': BRIDGE_SCHEMA, 'statement': 'CAUSAL_GEOMETRIC_TRACE_HAS_FEWER_THAN_TWO_EXACT_POINTS', 'trace_key': _trace_key(node), 'trace_point_count': len(world.get('_ac64_causal_route_bank', {}).get(_trace_key(node), []))}, node.identity())
    p[REQUEST_FIELD] = deepcopy(dict(request))
    effective = Node(node.kind, p, node.parents, node.wave, node.context)
    r = _native_engine(effective, world)
    payload = _completion_payload(dict(r.payload))
    payload['request_was_automatic'] = auto
    return AuxResult(ENGINE_MECHANISM_ID, r.status, r.result_kind, payload, node.identity())

def causal_geometric_canonical_transport_validator_ac64(node: Node, world: dict[str, Any]) -> AuxResult:
    r = _native_validator(node, world)
    payload = _clean(dict(r.payload))
    payload['ac64_direct_bridge'] = BRIDGE_SCHEMA
    if r.status == 'INVALID':
        payload['statement'] = 'CAUSAL_GEOMETRIC_CANONICAL_TRANSPORT_OPEN_RESIDUAL'
        return AuxResult(TRANSPORT_VALIDATOR_ID, 'OPEN', 'OPEN_RESIDUAL_CURRENT', payload, node.identity())
    return AuxResult(TRANSPORT_VALIDATOR_ID, r.status, r.result_kind, payload, node.identity())

def registry_fragment():
    return {ENGINE_MECHANISM_ID: causal_geometric_proof_engine_ac64, TRANSPORT_VALIDATOR_ID: causal_geometric_canonical_transport_validator_ac64}

def category_fragment():
    return {k: CATEGORY for k in registry_fragment()}
