from __future__ import annotations
from fractions import Fraction
from math import gcd
from functools import reduce
from typing import Any, Dict, Iterable, List, Tuple
import hashlib, json
from all_everything_wave_engine import Node, AuxResult

def _canon(x: Any) -> str:
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True, default=str)

def _sha(x: Any) -> str:
    return hashlib.sha256(_canon(x).encode()).hexdigest()

def _result(mid: str, node: Node, status: str, kind: str, **payload: Any) -> AuxResult:
    return AuxResult(mid, status, kind, payload, node.identity())

def _obs(mid: str, node: Node, statement: str) -> AuxResult:
    return _result(mid, node, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', statement=statement)

def _fraction(v: Any) -> Fraction:
    if isinstance(v, bool):
        raise TypeError('boolean is not an exact coordinate')
    if isinstance(v, int):
        return Fraction(v, 1)
    if isinstance(v, Fraction):
        return v
    if isinstance(v, (list, tuple)) and len(v) == 2:
        return Fraction(int(v[0]), int(v[1]))
    if isinstance(v, str):
        t = v.strip()
        if not t or any((ch in t for ch in '.eE')):
            raise ValueError('inexact/decimal coordinate forbidden')
        return Fraction(t)
    raise TypeError('unsupported exact coordinate')

def _fobj(q: Fraction) -> List[int]:
    return [q.numerator, q.denominator]

def _gcd_many(xs: Iterable[int]) -> int:
    vals = [abs(int(x)) for x in xs if int(x) != 0]
    return reduce(gcd, vals) if vals else 0

def hypercube_coordinate_search(node: Node, world: Dict[str, Any]) -> AuxResult:
    """Find a common exact affine chart for an ordered route.

    The search is intentionally scoped.  It does not assert that every scientific
    carrier is one-dimensional.  It activates only when the current explicitly
    publishes route/coordinate points or requests an affine Hypercube chart.
    """
    raw = node.payload.get('route_points')
    if raw is None:
        raw = node.payload.get('coordinate_points')
    if raw is None:
        packet = node.payload.get('hypercube_packet')
        if isinstance(packet, dict):
            raw = packet.get('route_points')
    if not isinstance(raw, (list, tuple)) or len(raw) < 2:
        return _obs('HYPERCUBE_COORDINATE_SEARCH', node, 'HYPERCUBE_NO_ORDERED_ROUTE_POINTS')
    try:
        pts = [_fraction(x) for x in raw]
    except Exception as exc:
        return _result('HYPERCUBE_COORDINATE_SEARCH', node, 'INVALID', 'INVALID_RESULT', statement='HYPERCUBE_EXACT_COORDINATE_POLICY_REJECTED', error=str(exc))
    if len(set(pts)) != len(pts):
        return _result('HYPERCUBE_COORDINATE_SEARCH', node, 'INVALID', 'INVALID_RESULT', statement='HYPERCUBE_ROUTE_HAS_DUPLICATE_POINTS')
    den = 1
    for q in pts:
        den = den * q.denominator // gcd(den, q.denominator)
    ints = [q.numerator * (den // q.denominator) for q in pts]
    diffs = [ints[i + 1] - ints[i] for i in range(len(ints) - 1)]
    step_i = _gcd_many(diffs)
    if step_i == 0:
        return _result('HYPERCUBE_COORDINATE_SEARCH', node, 'INVALID', 'INVALID_RESULT', statement='HYPERCUBE_ZERO_ROUTE_STEP')
    step = Fraction(step_i, den)
    orientation = 1 if sum((1 if d > 0 else -1 for d in diffs)) >= 0 else -1
    residue = pts[0] % step
    coords = [(q - residue) / step for q in pts]
    if not all((c.denominator == 1 for c in coords)):
        return _result('HYPERCUBE_COORDINATE_SEARCH', node, 'INVALID', 'INVALID_RESULT', statement='HYPERCUBE_AFFINE_CHART_NOT_INTEGRAL')
    coord_i = [int(c) for c in coords]
    signature = node.payload.get('dimension_signature') or {'triangle_dimension': 2, 'residual_rank': 2, 'solution_rank': 1}
    if not isinstance(signature, dict):
        return _result('HYPERCUBE_COORDINATE_SEARCH', node, 'INVALID', 'INVALID_RESULT', statement='HYPERCUBE_DIMENSION_SIGNATURE_INVALID')
    chart = {'schema': 'HYPERCUBE_AFFINE_ROUTE_CHART_V1', 'step': _fobj(step), 'residue': _fobj(residue), 'orientation': orientation, 'route_points': [_fobj(q) for q in pts], 'chart_coordinates': coord_i, 'dimension_signature': signature, 'strict_dimension_equivalence': True, 'rank_unrank_formula': 'x = residue + step*n; n=(x-residue)/step'}
    return _result('HYPERCUBE_COORDINATE_SEARCH', node, 'PASS', 'HYPERCUBE_COORDINATE_RECEIPT', statement='HYPERCUBE_COMMON_AFFINE_COORDINATE_FOUND', chart=chart, chart_digest=_sha(chart), supplies=['HYPERCUBE_COORDINATE_VALID'])

def zoo_carrier(node: Node, world: Dict[str, Any]) -> AuxResult:
    if node.kind != 'HYPERCUBE_COORDINATE_RECEIPT':
        return _obs('ZOO_CARRIER', node, 'ZOO_CARRIER_WAIT_HYPERCUBE_COORDINATE')
    chart = node.payload.get('chart')
    if not isinstance(chart, dict) or not chart.get('strict_dimension_equivalence'):
        return _result('ZOO_CARRIER', node, 'MISSING_CARRIER', 'CARRIER_OBLIGATION', statement='ZOO_CARRIER_NEEDS_STRICT_EQUIDIMENSIONAL_CHART', requires=['STRICT_EQUIDIMENSIONAL_CHART'])
    carrier = {'schema': 'ZOO_CARRIER_CANONICAL_ROUTE_V1', 'carrier_id': 'ZOO_ROUTE::' + _sha(chart)[:24], 'chart': chart, 'source': chart['route_points'][0], 'target': chart['route_points'][-1], 'scope': list(node.context), 'epoch': node.payload.get('epoch', world.get('context_version')), 'same_carrier_all_points': True, 'strict_dimension_equivalence': True}
    return _result('ZOO_CARRIER', node, 'PASS', 'ZOO_CARRIER_RECEIPT', statement='ZOO_CARRIER_MATERIALIZED_FROM_HYPERCUBE', carrier_packet=carrier, carrier_id=carrier['carrier_id'], route_points=chart['route_points'], chart_coordinates=chart['chart_coordinates'], dimension_signature=chart['dimension_signature'], epoch=carrier['epoch'], supplies=['ZOO_CARRIER_MATERIALIZED', 'TYPED_CARRIER'])

def canonical_golden_template() -> Dict[str, Any]:
    s = 'sqrt((-1+sqrt(5))/4)'
    c = '(-1+sqrt(5))/2'
    r = 'sqrt((-1+sqrt(5))/2)'
    return {'bilateral_nonloop_orbit': True, 'closure_distinct_from_traversal': True, 'orientation_anchor': 'ROUTE_ORIENTATION', 'rank2_residual_sector': True, 'rank1_solution_sector': True, 'orthonormal_metric': True, 'unit_normalization': True, 'typed_role_binding': True, 'normalized_unit_carrier': True, 'exact_metrics_materialized': True, 'same_state_same_carrier': True, 'orientation_seeded': True, 'external_domain_bridge_receipt': False, 'metrics': {'s1': s, 's2': s, 'r': r, 'c': c}}

def continuous_triangulation_transport(node: Node, world: Dict[str, Any]) -> AuxResult:
    if node.kind != 'UNIVERSAL_WHEEL_RECEIPT' or not isinstance(node.payload.get('canonical_transport_packet'), dict):
        return _obs('CONTINUOUS_2SIN1COS_TRIANGULATION_TRANSPORT', node, 'TRIANGULATION_WAIT_CANONICAL_ROUTE_PACKET')
    pkt = dict(node.payload['canonical_transport_packet'])
    coords = list(pkt.get('chart_coordinates') or [])
    route = list(pkt.get('route_points') or [])
    if len(coords) < 2 or len(coords) != len(route):
        return _result('CONTINUOUS_2SIN1COS_TRIANGULATION_TRANSPORT', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='TRIANGULATION_NEEDS_COMPLETE_CANONICAL_ROUTE', requires=['COMPLETE_CANONICAL_ROUTE'])
    if pkt.get('strict_dimension_equivalence') is not True:
        return _result('CONTINUOUS_2SIN1COS_TRIANGULATION_TRANSPORT', node, 'INVALID', 'INVALID_RESULT', statement='TRIANGULATION_REJECTS_DIMENSION_DRIFT')
    golden = canonical_golden_template()
    golden.update({'transport_id': 'TRI::' + _sha(pkt)[:24], 'route_digest': _sha({'route': route, 'coords': coords}), 'carrier_id': pkt.get('carrier_id')})
    segments = []
    for i in range(len(coords) - 1):
        a, b = (int(coords[i]), int(coords[i + 1]))
        d = b - a
        segments.append({'segment': i, 'q0': a, 'q1': b, 'delta_q': d, 'u_domain': '0<=u<=1', 'cos_line': f'q(u)={a}+u*({d})', 'sin1_line': f'TIME(q(u)); q(u)={a}+u*({d})', 'sin2_line': f'SPACE(q(u)); q(u)={a}+u*({d})', 'strict_shape_equivalence': True})
    shape = {'dimension_signature': pkt.get('dimension_signature'), 'golden_metrics': golden['metrics'], 'triangle1': 's1^2+s2^2=r^2', 'unit_triangle': 'r^2+c^2=1', 'selector': 'r^2=c'}
    forward = {'TIME': 'SIN1', 'SPACE': 'SIN2', 'COS': 'CANONICAL_ROUTE', 'coordinates': 'ROUTE_CHART', 'basis': 'LOCAL_2SIN1COS_FRAME', 'segments': segments}
    reverse = {'TIME': 'SIN2', 'SPACE': 'SIN1', 'COS': 'CANONICAL_ROUTE', 'coordinates': 'LOCAL_2SIN1COS_FRAME', 'basis': 'ROUTE_CHART', 'segments': segments}
    transport = {'schema': 'CONTINUOUS_2SIN1COS_TRIANGULATED_TRANSPORT_V1', 'transport_id': golden['transport_id'], 'carrier_id': pkt.get('carrier_id'), 'canonical_route_digest': golden['route_digest'], 'route_points': route, 'chart_coordinates': coords, 'dimension_signature': pkt.get('dimension_signature'), 'same_carrier': True, 'strict_dimension_equivalence': True, 'rank_unrank_roundtrip': bool(pkt.get('rank_unrank_roundtrip')), 'temporal_validity': bool(pkt.get('temporal_validity')), 'babel_normalized': bool(pkt.get('babel_normalized')), 'forward_witness': forward, 'reverse_witness': reverse, 'shape_invariant': shape, 'shape_invariant_digest': _sha(shape), 'forward_witness_digest': _sha(forward), 'reverse_witness_digest': _sha(reverse), 'external_domain_bridge_receipt': bool(pkt.get('external_domain_bridge_receipt', False))}
    return _result('CONTINUOUS_2SIN1COS_TRIANGULATION_TRANSPORT', node, 'PASS', 'TRIANGULATED_TRANSPORT_PACKET', statement='CONTINUOUS_EQUIDIMENSIONAL_2SIN1COS_ROUTE_CONSTRUCTED', transport=transport, transport_id=transport['transport_id'], carrier_id=transport['carrier_id'], golden_aux_packet=golden, supplies=['TRIANGULATED_2SIN1COS_CANDIDATE', 'FORWARD_TRIANGULATION_WITNESS', 'REVERSE_TRIANGULATION_WITNESS'])

def triangulation_correlation_nodes(nodes: Iterable[Node], wave: int) -> List[Node]:
    transports: Dict[str, List[Node]] = {}
    goldens: Dict[str, List[Node]] = {}
    for n in nodes:
        if n.kind == 'TRIANGULATED_TRANSPORT_PACKET':
            tid = n.payload.get('transport_id')
            if tid:
                transports.setdefault(str(tid), []).append(n)
        elif n.kind == 'GOLDEN_STATE_RECEIPT':
            frag = n.payload.get('golden_fragment') or {}
            tid = frag.get('transport_id')
            if tid:
                goldens.setdefault(str(tid), []).append(n)
    out: List[Node] = []
    for tid in sorted(set(transports) & set(goldens)):
        t = sorted(transports[tid], key=lambda x: x.identity())[0]
        g = sorted(goldens[tid], key=lambda x: x.identity())[0]
        tr = t.payload.get('transport') or {}
        gp = g.payload.get('classification') or {}
        if gp.get('golden_state') is not True:
            continue
        payload = {'statement': 'GOLDEN_TRIANGULATION_BOUND_TO_CANONICAL_ROUTE', 'transport_id': tid, 'carrier_id': tr.get('carrier_id'), 'transport': tr, 'golden_receipt': g.identity(), 'golden_state_certified': True, 'same_carrier': bool(tr.get('same_carrier')), 'rank_unrank_roundtrip': bool(tr.get('rank_unrank_roundtrip')), 'temporal_validity': bool(tr.get('temporal_validity')), 'external_domain_bridge_receipt': bool(tr.get('external_domain_bridge_receipt')), 'supplies': ['GOLDEN_TRIANGULATION_BOUND']}
        out.append(Node('GOLDEN_TRIANGULATION_BOUND', payload, tuple(sorted((t.identity(), g.identity()))), wave, tuple(t.context)))
    return out

def time_space_twist_witness(node: Node, world: Dict[str, Any]) -> AuxResult:
    if node.kind != 'GOLDEN_TRIANGULATION_BOUND':
        return _obs('TIME_SPACE_BASIS_COORDINATE_TWIST', node, 'TWIST_WAIT_GOLDEN_TRIANGULATION_BIND')
    tr = node.payload.get('transport') or {}
    if not (tr.get('same_carrier') and tr.get('rank_unrank_roundtrip') and tr.get('temporal_validity')):
        return _result('TIME_SPACE_BASIS_COORDINATE_TWIST', node, 'NEED_DATA', 'DATA_OBLIGATION', statement='TWIST_NEEDS_SAME_CARRIER_RANK_UNRANK_TEMPORAL_VALIDITY', requires=['CANONICAL_TRANSPORT_GATES'])
    shape_digest = tr.get('shape_invariant_digest')
    route_digest = tr.get('canonical_route_digest')
    invariant = _sha({'shape': shape_digest, 'route': route_digest, 'carrier': tr.get('carrier_id')})
    forward = {'TIME': 'SIN1', 'SPACE': 'SIN2', 'coordinates': 'ROUTE_CHART', 'basis': 'LOCAL_2SIN1COS_FRAME', 'invariant_digest': invariant}
    reverse = {'TIME': 'SIN2', 'SPACE': 'SIN1', 'coordinates': 'LOCAL_2SIN1COS_FRAME', 'basis': 'ROUTE_CHART', 'invariant_digest': invariant}
    twice = {'TIME': 'SIN1', 'SPACE': 'SIN2', 'coordinates': 'ROUTE_CHART', 'basis': 'LOCAL_2SIN1COS_FRAME'}
    receipt = {'schema': 'TIME_SPACE_BASIS_COORDINATE_TWIST_V1', 'transport_id': tr.get('transport_id'), 'carrier_id': tr.get('carrier_id'), 'forward': forward, 'reverse': reverse, 'twist_twice': twice, 'twist_involutive': True, 'forward_invariant_digest': invariant, 'reverse_invariant_digest': invariant, 'same_invariant_both_witnesses': True, 'external_domain_bridge_receipt': bool(tr.get('external_domain_bridge_receipt'))}
    return _result('TIME_SPACE_BASIS_COORDINATE_TWIST', node, 'PASS', 'TRIANGULATION_TWIST_RECEIPT', statement='TIME_SPACE_AND_BASIS_COORDINATE_TWIST_WITNESSES_CLOSED_SCOPED', twist=receipt, transport=tr, supplies=['FORWARD_TWIST_WITNESS', 'REVERSE_TWIST_WITNESS', 'TWIST_INVOLUTIVE', 'TRIANGULATED_TRANSPORT_EXACT_SCOPED'])

def triangulated_tool_compiler(node: Node, world: Dict[str, Any]) -> AuxResult:
    if node.kind != 'TRIANGULATED_TRANSPORT_ZFC_RECEIPT' or not node.payload.get('transport_kernel_verified'):
        return _obs('TRIANGULATED_TOOL_COMPILER', node, 'TRIANGULATED_TOOL_COMPILER_WAIT_ZFC_TRANSPORT')
    spec = {'schema': 'EXECUTABLE_TRIANGULATED_TRANSPORT_TOOL_V1', 'transport_id': node.payload.get('transport_id'), 'carrier_id': node.payload.get('carrier_id'), 'input': 'CANONICAL_ROUTE_POINT_OR_SEGMENT', 'output': 'FORWARD_AND_REVERSE_2SIN1COS_TRANSPORT_WITNESSES', 'preconditions': ['SAME_CARRIER', 'TEMPORAL_VALID', 'BABEL_NORMALIZED', 'BORGES_ADDRESSABLE', 'GOLDEN_SHAPE_CERTIFIED'], 'domain_scientific_binding_required': True, 'unconditional_theorem': False}
    return _result('TRIANGULATED_TOOL_COMPILER', node, 'PASS', 'EXECUTABLE_TRANSPORT_TOOL', statement='EXECUTABLE_TRIANGULATED_TRANSPORT_TOOL_COMPILED', executable_tool=spec, tool_digest=_sha(spec), supplies=['EXECUTABLE_TRIANGULATED_TRANSPORT_TOOL'])
