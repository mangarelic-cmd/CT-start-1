from __future__ import annotations

from dataclasses import dataclass, asdict
from fractions import Fraction
from hashlib import sha256
from typing import Dict, Iterable, List, Mapping, Optional, Sequence, Tuple
import json


FINAL_PROFILE_ID = "CP026_CANONICAL_COORDINATE_LIBRARY_V1"
DECLARED_CLASS_ID = "C024_REGISTERED_CAUSAL_PLANE_D4_V1"


class PlaneContractError(ValueError):
    pass


def _frac(value) -> Fraction:
    if isinstance(value, Fraction):
        return value
    if isinstance(value, int):
        return Fraction(value, 1)
    if isinstance(value, str):
        return Fraction(value)
    if isinstance(value, float):
        # Float ingestion is explicit and exact to its decimal spelling, not binary payload.
        return Fraction(str(value))
    raise TypeError(f"Unsupported exact scalar: {type(value)!r}")


def _canonical_json(obj) -> bytes:
    return json.dumps(obj, sort_keys=True, separators=(",", ":"), ensure_ascii=True).encode("utf-8")


def digest(obj) -> str:
    return sha256(_canonical_json(obj)).hexdigest()


@dataclass(frozen=True)
class SemanticType:
    authority_id: str
    family: str
    domain: str
    plate_contract: str
    canonical_name: str

    @property
    def type_id(self) -> str:
        return digest(asdict(self))[:24]


@dataclass(frozen=True)
class TemporalStamp:
    epoch: str
    phase: str
    ancestry_digest: str = ""


@dataclass(frozen=True)
class MetricPoint:
    t: Fraction
    s: Fraction
    orthogonal: bool
    metric_receipt_id: str

    @classmethod
    def make(cls, t, s, orthogonal: bool, metric_receipt_id: str) -> "MetricPoint":
        if not metric_receipt_id:
            raise PlaneContractError("A metric point requires an authoritative metric receipt id")
        return cls(_frac(t), _frac(s), bool(orthogonal), metric_receipt_id)

    @property
    def pythagorean_weight(self) -> Fraction:
        if not self.orthogonal:
            raise PlaneContractError("Pythagorean weight requested without orthogonality receipt")
        return self.t * self.t + self.s * self.s

    @property
    def polarity_numerator(self) -> Fraction:
        if not self.orthogonal:
            raise PlaneContractError("Polarity requires the orthogonal T/S chart")
        return self.t * self.t - self.s * self.s

    def mirror_ts(self) -> "MetricPoint":
        return MetricPoint(self.s, self.t, self.orthogonal, self.metric_receipt_id)


@dataclass(frozen=True)
class RealizationKey:
    type_id: str
    carrier_id: str
    metric_signature: str
    temporal: TemporalStamp
    orientation: str
    authority_version: str

    @property
    def key(self) -> str:
        raw = {
            "type_id": self.type_id,
            "carrier_id": self.carrier_id,
            "metric_signature": self.metric_signature,
            "temporal": asdict(self.temporal),
            "orientation": self.orientation,
            "authority_version": self.authority_version,
        }
        return digest(raw)


@dataclass(frozen=True)
class CertifiedRealization:
    semantic: SemanticType
    key: RealizationKey
    metric: MetricPoint
    residual_schema: str
    mirror_policy: str
    provenance_digest: str
    certified: bool = True

    def __post_init__(self):
        if self.key.type_id != self.semantic.type_id:
            raise PlaneContractError("Realization key/type mismatch")
        if not self.certified:
            raise PlaneContractError("Only certified realizations may enter the canonical library")
        if not self.provenance_digest:
            raise PlaneContractError("Certified realization requires provenance")

    @property
    def realization_id(self) -> str:
        return digest({
            "semantic": asdict(self.semantic),
            "key": {
                **asdict(self.key),
                "temporal": asdict(self.key.temporal),
            },
            "metric": {
                "t": str(self.metric.t), "s": str(self.metric.s),
                "orthogonal": self.metric.orthogonal,
                "metric_receipt_id": self.metric.metric_receipt_id,
            },
            "residual_schema": self.residual_schema,
            "mirror_policy": self.mirror_policy,
            "provenance_digest": self.provenance_digest,
        })


@dataclass(frozen=True)
class LinearBridge:
    source_carrier: str
    target_carrier: str
    source_metric_signature: str
    target_metric_signature: str
    # 2x2 exact matrix on (T,S)
    matrix: Tuple[Tuple[Fraction, Fraction], Tuple[Fraction, Fraction]]
    bridge_receipt_id: str
    isometry_certified: bool

    @classmethod
    def make(cls, source_carrier, target_carrier, source_metric_signature,
             target_metric_signature, matrix, bridge_receipt_id, isometry_certified):
        m = tuple(tuple(_frac(x) for x in row) for row in matrix)
        if len(m) != 2 or any(len(row) != 2 for row in m):
            raise PlaneContractError("Bridge matrix must be 2x2")
        if not bridge_receipt_id:
            raise PlaneContractError("Bridge requires receipt")
        return cls(source_carrier, target_carrier, source_metric_signature,
                   target_metric_signature, m, bridge_receipt_id, bool(isometry_certified))

    def apply(self, p: MetricPoint) -> MetricPoint:
        a,b = self.matrix[0]
        c,d = self.matrix[1]
        return MetricPoint(a*p.t+b*p.s, c*p.t+d*p.s, p.orthogonal, self.bridge_receipt_id)


@dataclass(frozen=True)
class LookupResult:
    status: str  # EXACT_HIT | PROJECTABLE | RECALCULATE
    realization: Optional[CertifiedRealization]
    reason: str
    bridge: Optional[LinearBridge] = None


class CanonicalCoordinateLibrary:
    """
    Non-semantic cache/address layer.

    It NEVER creates a metric, authority, carrier equivalence, proof, or ROOT truth.
    Exact lookup requires exact carrier/metric/Temporal/orientation/version identity.
    Projection requires an explicit certified bridge. Otherwise the caller must recalculate.
    """
    def __init__(self):
        self._types: Dict[str, SemanticType] = {}
        self._realizations: Dict[str, CertifiedRealization] = {}
        self._by_type: Dict[str, List[str]] = {}
        self._bridges: Dict[Tuple[str,str,str,str], LinearBridge] = {}

    def register_type(self, semantic: SemanticType):
        prev = self._types.get(semantic.type_id)
        if prev is not None and prev != semantic:
            raise PlaneContractError("Type digest collision / inconsistent type")
        self._types[semantic.type_id] = semantic

    def register_realization(self, r: CertifiedRealization):
        self.register_type(r.semantic)
        rid = r.realization_id
        prev = self._realizations.get(rid)
        if prev is not None and prev != r:
            raise PlaneContractError("Realization digest collision")
        self._realizations[rid] = r
        bucket = self._by_type.setdefault(r.semantic.type_id, [])
        if rid not in bucket:
            bucket.append(rid)
            bucket.sort()

    def register_bridge(self, bridge: LinearBridge):
        k=(bridge.source_carrier,bridge.target_carrier,
           bridge.source_metric_signature,bridge.target_metric_signature)
        self._bridges[k]=bridge

    def exact_lookup(self, key: RealizationKey) -> LookupResult:
        for rid in self._by_type.get(key.type_id, []):
            r=self._realizations[rid]
            if r.key == key:
                return LookupResult("EXACT_HIT", r, "exact certified realization")
        return LookupResult("RECALCULATE", None, "no exact realization for carrier/metric/time/orientation/version")

    def lookup_or_project(self, target_key: RealizationKey) -> LookupResult:
        hit=self.exact_lookup(target_key)
        if hit.status == "EXACT_HIT":
            return hit
        for rid in self._by_type.get(target_key.type_id, []):
            src=self._realizations[rid]
            # Temporal/orientation/version remain semantic firewalls; a carrier bridge does not erase them.
            if (src.key.temporal != target_key.temporal or
                src.key.orientation != target_key.orientation or
                src.key.authority_version != target_key.authority_version):
                continue
            bk=(src.key.carrier_id,target_key.carrier_id,
                src.key.metric_signature,target_key.metric_signature)
            bridge=self._bridges.get(bk)
            if bridge is None or not bridge.isometry_certified:
                continue
            p2=bridge.apply(src.metric)
            projected=CertifiedRealization(
                semantic=src.semantic,
                key=target_key,
                metric=p2,
                residual_schema=src.residual_schema,
                mirror_policy=src.mirror_policy,
                provenance_digest=digest({"source":src.provenance_digest,"bridge":bridge.bridge_receipt_id}),
                certified=True,
            )
            return LookupResult("PROJECTABLE", projected, "explicit certified carrier/metric bridge", bridge)
        return LookupResult("RECALCULATE", None, "no exact hit or certified compatible bridge")

    def to_dict(self) -> dict:
        def f(x): return str(x) if isinstance(x, Fraction) else x
        return {
            "profile": FINAL_PROFILE_ID,
            "declared_class": DECLARED_CLASS_ID,
            "types": [asdict(self._types[k]) for k in sorted(self._types)],
            "realizations": [
                {
                    "semantic": asdict(r.semantic),
                    "key": {
                        "type_id": r.key.type_id,
                        "carrier_id": r.key.carrier_id,
                        "metric_signature": r.key.metric_signature,
                        "temporal": asdict(r.key.temporal),
                        "orientation": r.key.orientation,
                        "authority_version": r.key.authority_version,
                    },
                    "metric": {"t":str(r.metric.t),"s":str(r.metric.s),"orthogonal":r.metric.orthogonal,"metric_receipt_id":r.metric.metric_receipt_id},
                    "residual_schema": r.residual_schema,
                    "mirror_policy": r.mirror_policy,
                    "provenance_digest": r.provenance_digest,
                    "certified": r.certified,
                } for r in sorted(self._realizations.values(), key=lambda x:x.realization_id)
            ],
            "bridges": [
                {
                    "source_carrier":b.source_carrier,"target_carrier":b.target_carrier,
                    "source_metric_signature":b.source_metric_signature,"target_metric_signature":b.target_metric_signature,
                    "matrix":[[str(x) for x in row] for row in b.matrix],
                    "bridge_receipt_id":b.bridge_receipt_id,"isometry_certified":b.isometry_certified,
                } for b in sorted(self._bridges.values(), key=lambda x:(x.source_carrier,x.target_carrier,x.source_metric_signature,x.target_metric_signature))
            ],
        }

    @classmethod
    def from_dict(cls, d: Mapping) -> "CanonicalCoordinateLibrary":
        lib=cls()
        for row in d.get("types", []):
            lib.register_type(SemanticType(**row))
        for row in d.get("bridges", []):
            lib.register_bridge(LinearBridge.make(
                row["source_carrier"],row["target_carrier"],row["source_metric_signature"],row["target_metric_signature"],
                row["matrix"],row["bridge_receipt_id"],row["isometry_certified"]
            ))
        for row in d.get("realizations", []):
            sem=SemanticType(**row["semantic"])
            k=row["key"]
            key=RealizationKey(k["type_id"],k["carrier_id"],k["metric_signature"],TemporalStamp(**k["temporal"]),k["orientation"],k["authority_version"])
            m=row["metric"]
            metric=MetricPoint.make(m["t"],m["s"],m["orthogonal"],m["metric_receipt_id"])
            lib.register_realization(CertifiedRealization(sem,key,metric,row["residual_schema"],row["mirror_policy"],row["provenance_digest"],row["certified"]))
        return lib


@dataclass(frozen=True)
class ActiveCell:
    occurrence_id: str
    realization_id: str
    semantic_type_id: str
    weight: Fraction
    rank_address: int
    q0: Fraction
    q1: Fraction
    mirror_occurrence_id: str
    metric_point: MetricPoint

    def point_at(self, sigma) -> Fraction:
        z=_frac(sigma)
        if z < 0 or z > 1:
            raise PlaneContractError("sigma must be in [0,1]")
        return self.q0 + z*(self.q1-self.q0)


@dataclass(frozen=True)
class ActiveGrid:
    problem_id: str
    cells: Tuple[ActiveCell, ...]
    total_weight: Fraction
    grid_digest: str

    def mirror(self) -> "ActiveGrid":
        mirrored=[]
        for c in self.cells:
            mp=c.metric_point.mirror_ts()
            mirrored.append(ActiveCell(
                occurrence_id=c.mirror_occurrence_id,
                realization_id=c.realization_id,
                semantic_type_id=c.semantic_type_id,
                weight=c.weight,
                rank_address=c.rank_address,
                q0=c.q0,q1=c.q1,
                mirror_occurrence_id=c.occurrence_id,
                metric_point=mp,
            ))
        payload=_grid_payload(self.problem_id+"::MIRROR", mirrored, self.total_weight)
        return ActiveGrid(self.problem_id+"::MIRROR", tuple(mirrored), self.total_weight, digest(payload))


def _grid_payload(problem_id, cells, total):
    return {
        "problem_id":problem_id,
        "total_weight":str(total),
        "cells":[{
            "occurrence_id":c.occurrence_id,"realization_id":c.realization_id,
            "semantic_type_id":c.semantic_type_id,"weight":str(c.weight),
            "rank_address":c.rank_address,"q0":str(c.q0),"q1":str(c.q1),
            "mirror_occurrence_id":c.mirror_occurrence_id,
            "metric":{"t":str(c.metric_point.t),"s":str(c.metric_point.s),"orthogonal":c.metric_point.orthogonal,"metric_receipt_id":c.metric_point.metric_receipt_id}
        } for c in cells]
    }


def build_active_grid(problem_id: str, ordered_occurrences: Sequence[Tuple[str, CertifiedRealization, int]]) -> ActiveGrid:
    """Build the dynamic metric grid ONLY from the cells active in this problem.

    Each tuple is (occurrence_id, certified_realization, Borges/transport rank).
    The rank is an address/order field ONLY; it never enters the metric weight.
    """
    if not ordered_occurrences:
        raise PlaneContractError("Active route cannot be empty")
    weights=[]
    for _,r,_ in ordered_occurrences:
        weights.append(r.metric.pythagorean_weight)
    if any(w <= 0 for w in weights):
        raise PlaneContractError("Active cell weights must be positive")
    total=sum(weights, Fraction(0,1))
    q=Fraction(0,1)
    cells=[]
    for (occ,r,rank),w in zip(ordered_occurrences,weights):
        q0=q; q=q+w/total
        cells.append(ActiveCell(
            occurrence_id=occ,
            realization_id=r.realization_id,
            semantic_type_id=r.semantic.type_id,
            weight=w,
            rank_address=int(rank),
            q0=q0,q1=q,
            mirror_occurrence_id=occ+"'",
            metric_point=r.metric,
        ))
    if q != 1:
        raise PlaneContractError("Active grid did not close on q=1")
    payload=_grid_payload(problem_id,cells,total)
    return ActiveGrid(problem_id,tuple(cells),total,digest(payload))


def validate_grid(grid: ActiveGrid) -> List[str]:
    errors=[]
    if not grid.cells: errors.append("EMPTY")
    if grid.cells and grid.cells[0].q0 != 0: errors.append("START_NOT_ZERO")
    if grid.cells and grid.cells[-1].q1 != 1: errors.append("END_NOT_ONE")
    for a,b in zip(grid.cells,grid.cells[1:]):
        if a.q1 != b.q0: errors.append("HOLE_OR_OVERLAP")
    if sum((c.weight for c in grid.cells),Fraction(0,1)) != grid.total_weight:
        errors.append("WEIGHT_SUM_MISMATCH")
    for c in grid.cells:
        if c.metric_point.pythagorean_weight != c.weight: errors.append("METRIC_WEIGHT_MISMATCH")
    return errors


def semantic_transparency_receipt(direct: ActiveGrid, cached: ActiveGrid) -> dict:
    """Cache/address reuse is allowed only if it reproduces the same active metric grid."""
    same = (
        direct.total_weight == cached.total_weight and
        len(direct.cells) == len(cached.cells) and
        all((a.semantic_type_id,a.weight,a.q0,a.q1,a.metric_point) ==
            (b.semantic_type_id,b.weight,b.q0,b.q1,b.metric_point)
            for a,b in zip(direct.cells,cached.cells))
    )
    return {"same_semantics":same,"direct_digest":direct.grid_digest,"cached_digest":cached.grid_digest}
