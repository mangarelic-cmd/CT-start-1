"""Causal Geometric Proof Engine solver adapter v0.6.

v0.6 closes the native canonical-space handshake that v0.5 only described.
A ROUTE computation now publishes a *transport-only ordinal chart seed* at the
receipt boundary.  DC01's existing HYPERCUBE -> ZOO_CARRIER -> CAUSAL_SPACE ->
TEMPORAL(PRE) -> BABEL -> BORGES -> TEMPORAL(POST) -> UNIVERSAL_WHEEL stack can
therefore consume the geometric result without any special cases in those
mechanisms.

The ordinal chart is deliberately NOT the geometric metric.  Exact space/time
legs, Pythagorean diagonals, trigonometry, containment and twist receipts remain
inside the source CAUSAL_GEOMETRIC_PROOF_RECEIPT.  The ordinal chart only gives
native solver transport a stable exact order for the already-computed route.

A second v0.6 mechanism observes the resulting UNIVERSAL_WHEEL_RECEIPT and
verifies that the Space/Temporal/Babel/Borges canonical packet preserved the
geometric binding and closed all native transport gates.  Neither mechanism has
RETURN authority or adds formal authority.
"""
from __future__ import annotations
import ast
from copy import deepcopy
from hashlib import sha256
import json
from pathlib import Path
from typing import Any, Mapping
from all_everything_wave_engine import AuxResult, Node
from aux_full_causal_coordinate_atlas_v0_2 import FullCausalCoordinateAtlas
from aux_causal_geometric_proof_engine_v0_3 import CausalChartPoint, CausalGeometricProofEngine, GeometricProofError
from aux_causal_geometric_proof_engine_v0_4 import TemporalTorusState, build_negative_qualification, build_prime_torus_wheel_qualification, mod210_wheel_receipt, prime_temporal_bridge, prime_temporal_s003, prime_temporal_s013, temporal_torus_orbit, universal_wheel_trig_identity_receipt, wheel_metric_intertwiner, wheel_twist_commuting_square
from triangulated_transport import hypercube_coordinate_search, zoo_carrier
from universal_everything_mechanisms import causal_space, temporal, babel, borges, universal_wheel
ENGINE_MECHANISM_ID = 'CAUSAL_GEOMETRIC_PROOF_ENGINE_V06'
TRANSPORT_VALIDATOR_ID = 'CAUSAL_GEOMETRIC_CANONICAL_TRANSPORT_VALIDATOR_V06'
CATEGORY = 'CAUSAL_GEOMETRY'
REQUEST_FIELD = 'causal_geometric_request'
REQUEST_SCHEMA = 'CT_CAUSAL_GEOMETRIC_SOLVER_REQUEST_V0_6'
RECEIPT_SCHEMA = 'CT_CAUSAL_GEOMETRIC_SOLVER_RECEIPT_V0_6'
TRANSPORT_BRIDGE_SCHEMA = 'CT_CAUSAL_GEOMETRIC_NATIVE_TRANSPORT_BINDING_V0_6'
TRANSPORT_RECEIPT_SCHEMA = 'CT_CAUSAL_GEOMETRIC_CANONICAL_TRANSPORT_RECEIPT_V0_6'
SUPPORTED_OPERATIONS = {'ATLAS_SELFTEST', 'CONTAINMENT', 'SEGMENT', 'ROUTE', 'PRIME_TEMPORAL_BRIDGE', 'TEMPORAL_TORUS', 'MOD210_PREFILTER', 'UNIVERSAL_WHEEL_TRIG_IDENTITY', 'WHEEL_METRIC', 'WHEEL_TWIST_SQUARE', 'REFERENCE_QUALIFICATION', 'NEGATIVE_QUALIFICATION'}
_ALLOWED_FUNCS = {'sqrt', 'Rational', 'Integer', 'Abs', 'sin', 'cos', 'tan'}
_AST_ALLOWED = (ast.Expression, ast.BinOp, ast.UnaryOp, ast.Add, ast.Sub, ast.Mult, ast.Div, ast.Pow, ast.UAdd, ast.USub, ast.Name, ast.Load, ast.Constant, ast.Call)

def _canon(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=False, allow_nan=False, default=str)

def _digest(value: Any) -> str:
    return sha256(_canon(value).encode()).hexdigest()

def _plain(value: Any, path: str='request') -> None:
    if value is None or type(value) in (str, bool, int):
        return
    if type(value) is float:
        raise ValueError(f'FLOAT_FORBIDDEN_USE_EXACT_JSON_OR_STRING:{path}')
    if isinstance(value, list):
        for i, item in enumerate(value):
            _plain(item, f'{path}[{i}]')
        return
    if isinstance(value, dict) and all((isinstance(k, str) for k in value)):
        for k, item in value.items():
            _plain(item, f'{path}.{k}')
        return
    raise ValueError(f'JSON_DATA_REQUIRED:{path}')

def _validate_exact_expr(value: Any, path: str) -> None:
    if type(value) is int:
        return
    if isinstance(value, list) and len(value) == 2 and all((type(x) is int for x in value)):
        return
    if not isinstance(value, str) or not value.strip():
        raise ValueError(f'EXACT_EXPRESSION_REQUIRED:{path}')
    tree = ast.parse(value.replace('^', '**'), mode='eval')
    for term in ast.walk(tree):
        if not isinstance(term, _AST_ALLOWED):
            raise ValueError(f'EXACT_EXPRESSION_GRAMMAR_ONLY:{path}')
        if isinstance(term, ast.Call):
            if not isinstance(term.func, ast.Name) or term.func.id not in _ALLOWED_FUNCS or term.keywords:
                raise ValueError(f'EXACT_FUNCTION_NOT_ALLOWLISTED:{path}')
        if isinstance(term, ast.Name):
            if term.id.startswith('_') or '__' in term.id:
                raise ValueError(f'EXACT_SYMBOL_FORBIDDEN:{path}')
        if isinstance(term, ast.Constant) and type(term.value) not in (int,):
            raise ValueError(f'EXACT_INTEGER_CONSTANTS_ONLY:{path}')

def _validate_point(row: Mapping[str, Any], path: str) -> None:
    required = {'point_id', 'space_id', 'time_id', 'orientation', 'x', 't'}
    missing = sorted(required - set(row))
    if missing:
        raise ValueError(f"MISSING_POINT_FIELDS:{path}:{','.join(missing)}")
    allowed = required | {'coordinate_provenance', 'chart_id', 'gx', 'gt'}
    extra = sorted(set(row) - allowed)
    if extra:
        raise ValueError(f"UNKNOWN_POINT_FIELDS:{path}:{','.join(extra)}")
    for key in ('point_id', 'space_id', 'time_id', 'orientation'):
        if not isinstance(row[key], str) or not row[key]:
            raise ValueError(f'NONEMPTY_STRING_REQUIRED:{path}.{key}')
    for key in ('x', 't', 'gx', 'gt'):
        if key in row:
            _validate_exact_expr(row[key], f'{path}.{key}')

def _package_root() -> Path:
    here = Path(__file__).resolve()
    solver_root = here.parents[1]
    candidate = solver_root / '04_FIXTURES' / 'CAUSAL_GEOMETRIC_ATLAS'
    if candidate.exists():
        return solver_root
    for parent in (here.parent, *here.parents):
        if (parent / 'scientific_space_containment_candidate_v3.json').exists():
            return parent
        if (parent / '04_FIXTURES' / 'CAUSAL_GEOMETRIC_ATLAS').exists():
            return parent
    raise FileNotFoundError('CAUSAL_GEOMETRIC_ATLAS_FIXTURES_NOT_FOUND')

def _atlas_paths() -> tuple[Path, Path]:
    root = _package_root()
    nested = root / '04_FIXTURES' / 'CAUSAL_GEOMETRIC_ATLAS'
    if nested.exists():
        return (nested / 'scientific_space_containment_candidate_v3.json', nested / 'scientific_temporal_catalog_v1.json')
    return (root / 'scientific_space_containment_candidate_v3.json', root / 'scientific_temporal_catalog_v1.json')

def load_atlas() -> FullCausalCoordinateAtlas:
    space, time = _atlas_paths()
    return FullCausalCoordinateAtlas(space, time)

def _exact_value(value: Any) -> Any:
    if isinstance(value, list) and len(value) == 2 and all((type(x) is int for x in value)):
        return (value[0], value[1])
    return value

def _point(row: Mapping[str, Any]) -> CausalChartPoint:
    return CausalChartPoint(point_id=row['point_id'], space_id=row['space_id'], time_id=row['time_id'], orientation=row['orientation'], x=_exact_value(row['x']), t=_exact_value(row['t']), coordinate_provenance=row.get('coordinate_provenance', 'OPEN'), chart_id=row.get('chart_id', 'LOCAL_PYTHAGOREAN_PROOF_CHART'), gx=_exact_value(row.get('gx', 1)), gt=_exact_value(row.get('gt', 1)))

def _canonical_request(request: Mapping[str, Any]) -> dict[str, Any]:
    if not isinstance(request, Mapping):
        raise ValueError('CAUSAL_GEOMETRIC_REQUEST_MAPPING_REQUIRED')
    req = deepcopy(dict(request))
    _plain(req)
    allowed = {'schema', 'operation', 'points', 'point_a', 'point_b', 'domain', 'child', 'container', 'n', 'C_tau', 'kappa', 'alignment_i', 'q', 'C_delta', 'initial', 'omega_phi', 'omega_S', 't_P', 'steps', 'segment', 'pre_segment', 'post_segment'}
    extra = sorted(set(req) - allowed)
    if extra:
        raise ValueError('CAUSAL_GEOMETRIC_UNKNOWN_REQUEST_FIELDS:' + ','.join(extra))
    schema = req.get('schema', REQUEST_SCHEMA)
    if schema not in {REQUEST_SCHEMA, 'CT_CAUSAL_GEOMETRIC_SOLVER_REQUEST_V0_5'}:
        raise ValueError('CAUSAL_GEOMETRIC_REQUEST_SCHEMA_MISMATCH')
    req['schema'] = REQUEST_SCHEMA
    op = req.get('operation')
    if op not in SUPPORTED_OPERATIONS:
        raise ValueError('CAUSAL_GEOMETRIC_UNSUPPORTED_OPERATION:' + str(op))
    if op == 'ROUTE':
        if not isinstance(req.get('points'), list) or len(req['points']) < 2:
            raise ValueError('ROUTE_REQUIRES_POINT_ARRAY')
        for i, row in enumerate(req['points']):
            if not isinstance(row, dict):
                raise ValueError(f'POINT_MAPPING_REQUIRED:points[{i}]')
            _validate_point(row, f'points[{i}]')
    elif op == 'SEGMENT':
        for key in ('point_a', 'point_b'):
            row = req.get(key)
            if not isinstance(row, dict):
                raise ValueError(f'SEGMENT_REQUIRES_{key.upper()}')
            _validate_point(row, key)
    elif op == 'CONTAINMENT':
        if req.get('domain') not in {'SPACE', 'TIME'}:
            raise ValueError('CONTAINMENT_DOMAIN_MUST_BE_SPACE_OR_TIME')
        for key in ('child', 'container'):
            if not isinstance(req.get(key), str) or not req[key]:
                raise ValueError(f'CONTAINMENT_{key.upper()}_REQUIRED')
    elif op == 'PRIME_TEMPORAL_BRIDGE':
        for key in ('n', 'kappa', 'alignment_i', 'q'):
            if key not in req:
                raise ValueError('PRIME_TEMPORAL_BRIDGE_MISSING:' + key)
        for key in ('C_tau', 'kappa', 'alignment_i', 'q', 'C_delta'):
            if key in req:
                _validate_exact_expr(req[key], key)
    elif op == 'TEMPORAL_TORUS':
        initial = req.get('initial')
        if not isinstance(initial, dict) or set(initial) - {'theta_phi', 'theta_S', 'cycle_index'}:
            raise ValueError('TEMPORAL_TORUS_INITIAL_STATE_INVALID')
        for key in ('theta_phi', 'theta_S'):
            _validate_exact_expr(initial.get(key), 'initial.' + key)
        for key in ('omega_phi', 'omega_S', 't_P'):
            if key not in req:
                raise ValueError('TEMPORAL_TORUS_MISSING:' + key)
            _validate_exact_expr(req[key], key)
        if type(req.get('steps')) is not int or req['steps'] < 0:
            raise ValueError('TEMPORAL_TORUS_STEPS_NONNEGATIVE_INTEGER_REQUIRED')
    elif op == 'MOD210_PREFILTER':
        if type(req.get('n')) is not int or req['n'] <= 0:
            raise ValueError('MOD210_POSITIVE_INTEGER_REQUIRED')
    return req

def _route_result(req: dict[str, Any]) -> dict[str, Any]:
    atlas = load_atlas()
    engine = CausalGeometricProofEngine(atlas)
    return engine.route([_point(row) for row in req['points']])

def _segment_result(req: dict[str, Any]) -> dict[str, Any]:
    atlas = load_atlas()
    engine = CausalGeometricProofEngine(atlas)
    return engine.segment(_point(req['point_a']), _point(req['point_b']))

def dispatch_request(request: Mapping[str, Any]) -> dict[str, Any]:
    req = _canonical_request(request)
    op = req['operation']
    atlas = load_atlas()
    if op == 'ATLAS_SELFTEST':
        out = {'schema': 'CT_CAUSAL_ATLAS_SELFTEST_V0_6', 'atlas_digest': atlas.atlas_digest, 'space_count': len(atlas.space_ids), 'time_count': len(atlas.time_ids), 'space_graph_acyclic': not atlas.space_graph.has_cycle(), 'time_graph_acyclic': not atlas.time_graph.has_cycle()}
        out['pass'] = bool(out['space_graph_acyclic'] and out['time_graph_acyclic'])
        return out
    if op == 'CONTAINMENT':
        return atlas.containment_receipt(req['child'], req['container'], req['domain'])
    if op == 'SEGMENT':
        return _segment_result(req)
    if op == 'ROUTE':
        return _route_result(req)
    if op == 'PRIME_TEMPORAL_BRIDGE':
        s013 = prime_temporal_s013(req['n'], _exact_value(req.get('C_tau', 1)))
        s003 = prime_temporal_s003(req['n'], kappa=_exact_value(req['kappa']), alignment_i=_exact_value(req['alignment_i']), q=_exact_value(req['q']), C_delta=_exact_value(req.get('C_delta', 1)))
        return {'s013': s013, 's003': s003, 'bridge': prime_temporal_bridge(s013, s003)}
    if op == 'TEMPORAL_TORUS':
        initial = req['initial']
        return temporal_torus_orbit(TemporalTorusState(_exact_value(initial['theta_phi']), _exact_value(initial['theta_S']), initial.get('cycle_index', 0)), omega_phi=_exact_value(req['omega_phi']), omega_S=_exact_value(req['omega_S']), t_P=_exact_value(req['t_P']), steps=req['steps'])
    if op == 'MOD210_PREFILTER':
        return mod210_wheel_receipt(req['n'])
    if op == 'UNIVERSAL_WHEEL_TRIG_IDENTITY':
        return universal_wheel_trig_identity_receipt()
    if op == 'WHEEL_METRIC':
        if not isinstance(req.get('segment'), dict):
            raise ValueError('WHEEL_METRIC_SEGMENT_REQUIRED')
        return wheel_metric_intertwiner(req['segment'])
    if op == 'WHEEL_TWIST_SQUARE':
        if not isinstance(req.get('pre_segment'), dict) or not isinstance(req.get('post_segment'), dict):
            raise ValueError('WHEEL_TWIST_PRE_POST_SEGMENTS_REQUIRED')
        return wheel_twist_commuting_square(req['pre_segment'], req['post_segment'])
    if op == 'REFERENCE_QUALIFICATION':
        return build_prime_torus_wheel_qualification(atlas)
    if op == 'NEGATIVE_QUALIFICATION':
        return build_negative_qualification(atlas)
    raise AssertionError(op)

def _status_for_result(result: Mapping[str, Any]) -> str:
    if result.get('proof_ready') is True or result.get('pass') is True or result.get('internal_exact_model_pass') is True:
        return 'PASS'
    if result.get('valid') is True or result.get('calculation_status') == 'EXACT_SYMBOLIC' or result.get('exact_symbolic') is True:
        return 'PARTIAL'
    if result.get('bridge_pass') is False or result.get('fail_closed') is True:
        return 'PARTIAL'
    return 'PARTIAL'

def _native_transport_binding(canonical: Mapping[str, Any], result: Mapping[str, Any], request_digest: str, result_digest: str, source_status: str) -> dict[str, Any] | None:
    """Compile a native DC01 transport seed for ROUTE only.

    The route points are exact ordinal coordinates 0..N-1.  They encode ordering
    only.  They never replace the proof engine's x/t metric coordinates.
    """
    if canonical.get('operation') != 'ROUTE':
        return None
    rows = list(canonical.get('points') or [])
    if len(rows) < 2:
        return None
    point_ids = [str(r['point_id']) for r in rows]
    ordinal = list(range(len(point_ids)))
    binding_core = {'point_ids': point_ids, 'ordinal_chart_coordinates': ordinal, 'request_digest': request_digest, 'result_digest': result_digest}
    binding_digest = _digest(binding_core)
    return {'schema': TRANSPORT_BRIDGE_SCHEMA, 'route_points': ordinal, 'dimension_signature': {'triangle_dimension': 2, 'residual_rank': 2, 'solution_rank': 1, 'causal_geometric_bridge_schema': TRANSPORT_BRIDGE_SCHEMA, 'causal_geometric_engine': ENGINE_MECHANISM_ID, 'geometric_request_digest': request_digest, 'geometric_result_digest': result_digest, 'geometric_point_ids': point_ids, 'ordinal_chart_coordinates': ordinal, 'transport_route_binding_digest': binding_digest, 'transport_chart_semantics': 'ORDER_ONLY_CANONICAL_TRANSPORT_NOT_GEOMETRIC_METRIC', 'source_geometric_status': source_status, 'source_geometric_proof_ready': bool(result.get('proof_ready'))}, 'binding_digest': binding_digest}

def _run_native_canonical_stack(source_node: Any, transport: Mapping[str, Any], world: Mapping[str, Any]) -> dict[str, Any]:
    """Execute the existing DC01 canonical-space stack as a bounded pure bridge.

    This is not a scheduler: it is one deterministic call through the already-existing
    native transport adapters, with no search, no recursion, no RETURN and no truth
    promotion.  It exists so the geometric AUX can be reconciled even when target-grain
    compaction keeps the broadcast copies dormant.
    """
    context = tuple(getattr(source_node, 'context', ()) or ())
    bridge_seed = Node('CAUSAL_GEOMETRIC_TRANSPORT_SEED', {'route_points': list(transport['route_points']), 'dimension_signature': deepcopy(transport['dimension_signature']), 'statement': 'CAUSAL_GEOMETRIC_NATIVE_STACK_SEED'}, context=context)
    stages = []
    current = bridge_seed
    pipeline = [('HYPERCUBE_COORDINATE_SEARCH', hypercube_coordinate_search), ('ZOO_CARRIER', zoo_carrier), ('CAUSAL_SPACE', causal_space), ('TEMPORAL_PRE_BIND', temporal), ('BABEL', babel), ('BORGES', borges), ('TEMPORAL_POST_CHECK', temporal), ('UNIVERSAL_WHEEL', universal_wheel)]
    for wave, (stage_name, fn) in enumerate(pipeline, 1):
        result = fn(current, dict(world))
        stage = {'stage': stage_name, 'mechanism': result.mechanism, 'status': result.status, 'result_kind': result.result_kind, 'statement': result.payload.get('statement'), 'payload_digest': _digest(result.payload)}
        stages.append(stage)
        if result.status != 'PASS':
            return {'schema': 'CT_CAUSAL_GEOMETRIC_NATIVE_STACK_V0_6', 'closed': False, 'failed_stage': stage_name, 'stages': stages}
        current = result.as_node(wave, context)
    wheel_node = current
    validator = causal_geometric_canonical_transport_validator(wheel_node, dict(world))
    if validator.status != 'PASS':
        return {'schema': 'CT_CAUSAL_GEOMETRIC_NATIVE_STACK_V0_6', 'closed': False, 'failed_stage': 'CAUSAL_GEOMETRIC_CANONICAL_TRANSPORT_VALIDATOR_V06', 'stages': stages, 'validator': validator.payload}
    packet = deepcopy(wheel_node.payload.get('canonical_transport_packet') or {})
    point_ids = list(transport['dimension_signature'].get('geometric_point_ids') or [])
    coords = list(packet.get('chart_coordinates') or [])
    bindings = [{'point_id': point_ids[i], 'borges_rank': i, 'canonical_transport_coordinate': coords[i]} for i in range(min(len(point_ids), len(coords)))]
    return {'schema': 'CT_CAUSAL_GEOMETRIC_NATIVE_STACK_V0_6', 'closed': True, 'stages': stages, 'canonical_transport_packet_digest': _digest(packet), 'carrier_id': packet.get('carrier_id'), 'epoch': packet.get('epoch'), 'point_address_bindings': bindings, 'transport_validator_receipt': validator.payload, 'stack_semantics': {'CAUSAL_SPACE': 'materializes the ordered common carrier/path', 'TEMPORAL_PRE_BIND': 'binds epoch before normalization', 'BABEL': 'normalizes the canonical route representation', 'BORGES': 'assigns reversible rank/address order', 'TEMPORAL_POST_CHECK': 'checks future leakage after addressing', 'UNIVERSAL_WHEEL': 'marks canonical reinjection readiness'}, 'geometric_metric_replaced_by_order_chart': False, 'external_scientific_truth_certified': False}

def causal_geometric_proof_engine(node: Any, world: dict[str, Any]) -> AuxResult:
    request = node.payload.get(REQUEST_FIELD)
    if request is None:
        return AuxResult(ENGINE_MECHANISM_ID, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', {'statement': 'CAUSAL_GEOMETRIC_ENGINE_AWAITING_TYPED_REQUEST', 'request_field': REQUEST_FIELD, 'request_schema': REQUEST_SCHEMA, 'supported_operations': sorted(SUPPORTED_OPERATIONS)}, node.identity())
    try:
        canonical = _canonical_request(request)
        result = dispatch_request(canonical)
        request_digest = _digest(canonical)
        result_digest = _digest(result)
        status = _status_for_result(result)
        supply = 'CAUSAL_GEOMETRIC_MATERIAL::' + request_digest
        transport = _native_transport_binding(canonical, result, request_digest, result_digest, status)
        native_stack = _run_native_canonical_stack(node, transport, world) if transport is not None else None
        payload = {'schema': RECEIPT_SCHEMA, 'statement': 'CAUSAL_GEOMETRIC_SCOPED_COMPUTATION', 'request': canonical, 'request_digest': request_digest, 'result': result, 'result_digest': result_digest, 'supplies': [supply] if status in {'PASS', 'PARTIAL'} else [], 'requires': [], 'candidate_effect': supply, 'authority': 'MATERIAL_CANDIDATE_ONLY', 'reconciliation_scope': 'AC_DC_SHARED_CAUSAL_GEOMETRY', 'native_canonical_transport_requested': bool(transport), 'native_canonical_transport': native_stack}
        if transport is not None:
            payload['route_points'] = transport['route_points']
            payload['dimension_signature'] = transport['dimension_signature']
            payload['native_transport_binding_digest'] = transport['binding_digest']
            payload['native_transport_chart_semantics'] = 'ORDER_ONLY; SOURCE_RECEIPT_RETAINS_TRUE_GEOMETRIC_METRIC'
        body = dict(payload)
        payload['receipt_digest'] = _digest(body)
        return AuxResult(ENGINE_MECHANISM_ID, status, 'CAUSAL_GEOMETRIC_PROOF_RECEIPT', payload, node.identity())
    except (ValueError, TypeError, KeyError, GeometricProofError, SyntaxError) as exc:
        return AuxResult(ENGINE_MECHANISM_ID, 'INVALID', 'INVALID_RESULT', {'statement': 'CAUSAL_GEOMETRIC_TYPED_REQUEST_REJECTED', 'error': {'type': type(exc).__name__, 'message': str(exc)}, 'supplies': [], 'requires': []}, node.identity())

def causal_geometric_canonical_transport_validator(node: Any, world: dict[str, Any]) -> AuxResult:
    """Close the native Space/Temporal/Babel/Borges handshake for a v0.6 route.

    This validates canonical transport only.  It does not certify the external
    scientific interpretation and does not promote the geometric candidate to ROOT.
    """
    if node.kind != 'UNIVERSAL_WHEEL_RECEIPT' or not isinstance(node.payload.get('canonical_transport_packet'), dict):
        return AuxResult(TRANSPORT_VALIDATOR_ID, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', {'statement': 'CAUSAL_GEOMETRIC_TRANSPORT_VALIDATOR_WAIT_CANONICAL_WHEEL_PACKET'}, node.identity())
    packet = dict(node.payload['canonical_transport_packet'])
    sig = packet.get('dimension_signature')
    if not isinstance(sig, dict) or sig.get('causal_geometric_bridge_schema') != TRANSPORT_BRIDGE_SCHEMA:
        return AuxResult(TRANSPORT_VALIDATOR_ID, 'NOT_APPLICABLE', 'MECHANISM_OBSERVATION', {'statement': 'CANONICAL_PACKET_NOT_FROM_CAUSAL_GEOMETRIC_V06'}, node.identity())
    point_ids = sig.get('geometric_point_ids')
    ordinal = sig.get('ordinal_chart_coordinates')
    req_digest = sig.get('geometric_request_digest')
    res_digest = sig.get('geometric_result_digest')
    expected_binding = sig.get('transport_route_binding_digest')
    computed_binding = None
    if isinstance(point_ids, list) and isinstance(ordinal, list) and isinstance(req_digest, str) and isinstance(res_digest, str):
        computed_binding = _digest({'point_ids': point_ids, 'ordinal_chart_coordinates': ordinal, 'request_digest': req_digest, 'result_digest': res_digest})
    gates = {'causal_space_packet': packet.get('schema') == 'CAUSAL_SPACE_ROUTE_PACKET_V1', 'same_carrier': packet.get('same_carrier') is True, 'strict_dimension_equivalence': packet.get('strict_dimension_equivalence') is True, 'temporal_prebind_implied_by_babel': packet.get('babel_normalized') is True, 'babel_normalized': packet.get('babel_normalized') is True, 'borges_addressable': packet.get('borges_addressable') is True, 'rank_unrank_roundtrip': packet.get('rank_unrank_roundtrip') is True, 'temporal_post_valid': packet.get('temporal_validity') is True, 'universal_wheel_reinjection_ready': bool(node.payload.get('reinject')), 'ordinal_chart_preserved': list(packet.get('chart_coordinates') or []) == list(ordinal or []), 'geometric_binding_preserved': computed_binding is not None and computed_binding == expected_binding}
    closed = all(gates.values())
    payload = {'schema': TRANSPORT_RECEIPT_SCHEMA, 'statement': 'CAUSAL_GEOMETRIC_NATIVE_CANONICAL_TRANSPORT_CLOSED' if closed else 'CAUSAL_GEOMETRIC_NATIVE_CANONICAL_TRANSPORT_REJECTED', 'transport_gates': gates, 'canonical_transport_closed': closed, 'geometric_request_digest': req_digest, 'geometric_result_digest': res_digest, 'geometric_point_ids': point_ids, 'carrier_id': packet.get('carrier_id'), 'epoch': packet.get('epoch'), 'source_geometric_status': sig.get('source_geometric_status'), 'source_geometric_proof_ready': bool(sig.get('source_geometric_proof_ready')), 'native_stack': ['HYPERCUBE_COORDINATE_SEARCH', 'ZOO_CARRIER', 'CAUSAL_SPACE', 'TEMPORAL_PRE_BIND', 'BABEL', 'BORGES', 'TEMPORAL_POST_CHECK', 'UNIVERSAL_WHEEL'], 'proof_authority': 'CANONICAL_TRANSPORT_ONLY', 'external_scientific_truth_certified': False, 'supplies': ['CAUSAL_GEOMETRIC_CANONICAL_TRANSPORT_CLOSED'] if closed else [], 'requires': [] if closed else [k for k, v in gates.items() if not v]}
    payload['receipt_digest'] = _digest(payload)
    return AuxResult(TRANSPORT_VALIDATOR_ID, 'PASS' if closed else 'INVALID', 'CAUSAL_GEOMETRIC_CANONICAL_TRANSPORT_RECEIPT' if closed else 'INVALID_RESULT', payload, node.identity())

def registry_fragment() -> dict[str, Any]:
    return {ENGINE_MECHANISM_ID: causal_geometric_proof_engine, TRANSPORT_VALIDATOR_ID: causal_geometric_canonical_transport_validator}

def category_fragment() -> dict[str, str]:
    return {k: CATEGORY for k in registry_fragment()}
