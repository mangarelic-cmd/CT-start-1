from __future__ import annotations
from fractions import Fraction
import copy, hashlib, json
from typing import Any, Dict, Iterable, List, Tuple

def canon(x):
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False, default=str)

def digest(x):
    return hashlib.sha256(canon(x).encode()).hexdigest()

def _get(obj, path, default=None):
    cur = obj
    for p in str(path).split('.'):
        if isinstance(cur, dict) and p in cur:
            cur = cur[p]
        else:
            return default
    return cur

def _deep_merge(a: Dict[str, Any], b: Dict[str, Any]):
    out = copy.deepcopy(a)
    conflicts = []
    for k, v in b.items():
        if k not in out:
            out[k] = copy.deepcopy(v)
            continue
        if isinstance(out[k], dict) and isinstance(v, dict):
            merged, sub = _deep_merge(out[k], v)
            out[k] = merged
            conflicts.extend([f'{k}.{x}' for x in sub])
        elif out[k] != v:
            conflicts.append(k)
    return (out, conflicts)

def normalize_target(target: str) -> str:
    t = str(target or '').strip()
    wrappers = {'MATERIAL_SPECIFICATION', 'PROVIDER_SPECIFICATION', 'RELATION_SIGNATURE', 'CARRIER_SPECIFICATION', 'RECOVERY_EVIDENCE', 'RECONSTRUCTION_RULE', 'DISAMBIGUATING_CONSTRAINT', 'EXTERNAL_DEFINITION'}
    parts = [p for p in t.split('::') if p]
    while parts and parts[0] in wrappers:
        parts = parts[1:]
    return '::'.join(parts) if parts else t

def _entry_targets(entry):
    vals = []
    for k in ('target', 'object_id', 'id', 'name'):
        if entry.get(k) is not None:
            vals.append(str(entry[k]))
    vals.extend((str(x) for x in entry.get('targets') or []))
    vals.extend((str(x) for x in entry.get('aliases') or []))
    return {normalize_target(x) for x in vals if x}

def _kind_compatible(entry_kind, expected_kind):
    if not expected_kind:
        return True
    ek = str(entry_kind or '').lower()
    want = str(expected_kind).lower()
    if ek in {'object', 'material', 'materialized_object', 'recovered_object'}:
        return True
    return ek == want or ek == want + '_object'

def _is_authoritative(entry):
    return bool(entry.get('verified') is True or entry.get('authoritative') is True or str(entry.get('status', '')).upper() in {'VERIFIED', 'CERTIFIED', 'TERMINAL'})

def _candidate_payload(entry):
    for k in ('payload', 'material', 'object', 'provider', 'relation', 'carrier', 'value'):
        if k in entry:
            return copy.deepcopy(entry[k])
    meta = {'target', 'targets', 'aliases', 'kind', 'verified', 'authoritative', 'status', 'digest', 'sha256', 'supplies', 'provenance', 'object_id', 'id', 'name', 'fragments'}
    return {k: copy.deepcopy(v) for k, v in entry.items() if k not in meta}

def _constraints(node_payload, world, target):
    out = {}
    for src in (world.get('materialization_constraints', {}), node_payload.get('materialization_constraints', {}), node_payload.get('constraints', {})):
        if not isinstance(src, dict):
            continue
        keyed = src.get(target) or src.get(normalize_target(target))
        m = keyed if isinstance(keyed, dict) else src if any((k in src for k in ('equals', 'required_fields', 'sha256', 'digest', 'kind', 'predicate_receipts'))) else None
        if not isinstance(m, dict):
            continue
        for k, v in m.items():
            if k == 'equals' and isinstance(v, dict):
                out.setdefault('equals', {}).update(v)
            elif k == 'required_fields':
                out.setdefault('required_fields', []).extend(v if isinstance(v, list) else [v])
            elif k == 'predicate_receipts':
                out.setdefault('predicate_receipts', []).extend(v if isinstance(v, list) else [v])
            else:
                out[k] = v
    out['required_fields'] = sorted(set((str(x) for x in out.get('required_fields', []))))
    return out

def _match_constraints(payload, entry, constraints):
    reasons = []
    for field in constraints.get('required_fields', []):
        if _get(payload, field, None) is None:
            reasons.append('MISSING_FIELD:' + field)
    for field, want in (constraints.get('equals') or {}).items():
        got = _get(payload, field, None)
        if got != want:
            reasons.append(f'EQUALS_FAIL:{field}')
    expected = constraints.get('sha256') or constraints.get('digest')
    if expected:
        got = entry.get('sha256') or entry.get('digest') or digest(payload)
        if str(got) != str(expected):
            reasons.append('DIGEST_MISMATCH')
    if constraints.get('kind') and (not _kind_compatible(entry.get('kind'), constraints['kind'])):
        reasons.append('KIND_MISMATCH')
    receipts = entry.get('predicate_receipts') or {}
    for p in constraints.get('predicate_receipts', []):
        if receipts.get(p) is not True:
            reasons.append('PREDICATE_RECEIPT_MISSING:' + str(p))
    return (not reasons, reasons)

def _collect_catalog(node_payload, world, target, expected_kind=None):
    entries = []
    sources = [('NODE_CATALOG', node_payload.get('materialization_catalog')), ('NODE_CANDIDATES', node_payload.get('recovery_candidates')), ('WORLD_CATALOG', world.get('materialization_catalog')), ('WORLD_ARTIFACTS', world.get('artifact_catalog')), ('WORLD_DYNAMIC_ARTIFACTS', world.get('dynamic_artifact_catalog')), ('WORLD_PROVIDERS', world.get('provider_candidate_bank')), ('WORLD_RELATIONS', world.get('relation_candidate_bank')), ('WORLD_CARRIERS', world.get('carrier_candidate_bank'))]
    nt = normalize_target(target)
    for source, xs in sources:
        if isinstance(xs, dict):
            if nt in xs and isinstance(xs[nt], (dict, list)):
                ys = xs[nt] if isinstance(xs[nt], list) else [xs[nt]]
            else:
                ys = list(xs.values())
        elif isinstance(xs, list):
            ys = xs
        else:
            continue
        for e in ys:
            if not isinstance(e, dict):
                continue
            if nt not in _entry_targets(e):
                continue
            if not _kind_compatible(e.get('kind'), expected_kind):
                continue
            q = copy.deepcopy(e)
            q['_catalog_source'] = source
            entries.append(q)
    return entries

def _federate(entries):
    groups = {}
    for e in entries:
        gid = str(e.get('object_id') or e.get('id') or e.get('target') or e.get('name') or digest(_candidate_payload(e)))
        groups.setdefault((gid, str(e.get('kind', 'object'))), []).append(e)
    out = []
    for (gid, kind), gs in sorted(groups.items()):
        if len(gs) == 1:
            out.append(gs[0])
            continue
        payload = {}
        conflicts = []
        all_auth = True
        supplies = []
        provenance = []
        for g in gs:
            payload, c = _deep_merge(payload, _candidate_payload(g))
            conflicts.extend(c)
            all_auth = all_auth and _is_authoritative(g)
            supplies.extend(g.get('supplies') or [])
            provenance.append({'source': g.get('_catalog_source'), 'id': g.get('id') or g.get('name'), 'digest': g.get('digest') or g.get('sha256')})
        if conflicts:
            continue
        out.append({'id': gid, 'object_id': gid, 'target': gs[0].get('target'), 'kind': kind, 'payload': payload, 'verified': all_auth, 'supplies': sorted(set(supplies)), 'provenance': provenance, 'federated_fragment_count': len(gs), '_catalog_source': 'FEDERATED'})
    return out

def _fraction(x):
    if isinstance(x, Fraction):
        return x
    if isinstance(x, int):
        return Fraction(x, 1)
    if isinstance(x, (list, tuple)) and len(x) == 2:
        return Fraction(int(x[0]), int(x[1]))
    if isinstance(x, str):
        if '.' in x:
            raise ValueError('decimal forbidden in exact reconstruction')
        return Fraction(x)
    raise ValueError('unsupported exact scalar')

def _rules(node_payload, world, target, expected_kind=None):
    xs = []
    for src in (node_payload.get('reconstruction_rules'), world.get('reconstruction_rules')):
        if isinstance(src, dict):
            nt = normalize_target(target)
            y = src.get(nt) or src.get(target)
            if isinstance(y, dict):
                xs.append(y)
            elif isinstance(y, list):
                xs.extend(y)
        elif isinstance(src, list):
            xs.extend(src)
    nt = normalize_target(target)
    return [copy.deepcopy(r) for r in xs if isinstance(r, dict) and (not r.get('targets') or nt in {normalize_target(x) for x in r.get('targets', [])}) and _kind_compatible(r.get('kind'), expected_kind)]

def _reconstruct(rule, node_payload, world, target):
    rt = str(rule.get('rule_type', '')).upper()
    if rule.get('verified_rule') is not True:
        return (None, 'RULE_NOT_VERIFIED')
    if rt == 'EXACT_OBJECT':
        return (copy.deepcopy(rule.get('payload') or {}), None)
    if rt == 'ORDERED_ARITHMETIC_SEQUENCE':
        start = _fraction(rule['start'])
        step = _fraction(rule['step'])
        count = int(rule['count'])
        vals = [start + i * step for i in range(count)]
        enc = [[v.numerator, v.denominator] for v in vals]
        return ({str(rule.get('field', 'values')): enc, 'count': count}, None)
    if rt == 'POWER_BASIS':
        beta = _fraction(rule['beta'])
        degree = int(rule['degree'])
        vals = [beta ** i for i in range(degree + 1)]
        if rule.get('append_zero'):
            vals.append(Fraction(0, 1))
        return ({str(rule.get('field', 'features')): [[v.numerator, v.denominator] for v in vals]}, None)
    if rt == 'FIELD_MAP':
        sources = {**(world.get('source_values') or {}), **(node_payload.get('source_values') or {}), **(rule.get('source_values') or {})}
        out = {}
        for dst, src in (rule.get('mapping') or {}).items():
            if src not in sources:
                return (None, 'FIELD_MAP_SOURCE_MISSING:' + str(src))
            out[dst] = copy.deepcopy(sources[src])
        return (out, None)
    if rt == 'AFFINE_FROM_ANCHORS':
        anchors = rule.get('anchors') or node_payload.get('transport_anchors') or world.get('transport_anchors')
        coords = rule.get('route_coordinates') or node_payload.get('route_coordinates') or world.get('route_coordinates')
        if not anchors or not coords:
            return (None, 'AFFINE_ANCHORS_MISSING')
        from parallel_transport import synthesize_minimal_transport
        law = synthesize_minimal_transport(anchors, coords)
        if not law.get('exact_anchor_replay') or not law.get('forward_reverse_same_law'):
            return (None, 'ANCHOR_REPLAY_FAIL')
        if rule.get('require_parallel', True) and (not law.get('strict_parallelity')):
            return (None, 'NOT_STRICT_PARALLEL')
        return ({'transport_law': law}, None)
    return (None, 'UNSUPPORTED_RECONSTRUCTION_RULE:' + rt)

def resolve_material(node_payload: Dict[str, Any], world: Dict[str, Any], target: str, expected_kind=None):
    """Deterministic recover/reconstruct/federate/eliminate/last-survivor pipeline.

    Returns a receipt dictionary. It never claims a scientific theorem; it only
    materializes an exact object when an authoritative/replayable unique candidate survives.
    """
    target = normalize_target(target)
    constraints = _constraints(node_payload, world, target)
    raw = _collect_catalog(node_payload, world, target, expected_kind)
    federated = _federate(raw)
    candidates = []
    rejected = []
    for e in federated:
        payload = _candidate_payload(e)
        ok, reasons = _match_constraints(payload, e, constraints)
        auth = _is_authoritative(e)
        if ok and auth:
            candidates.append({'id': str(e.get('id') or e.get('object_id') or digest(payload)), 'kind': e.get('kind') or expected_kind or 'object', 'payload': payload, 'supplies': list(e.get('supplies') or []), 'digest': e.get('digest') or e.get('sha256') or digest(payload), 'provenance': copy.deepcopy(e.get('provenance') or {'catalog_source': e.get('_catalog_source')}), 'route': 'RECOVER_OR_FEDERATE'})
        else:
            rejected.append({'id': str(e.get('id') or e.get('object_id') or '?'), 'reasons': reasons + ([] if auth else ['NOT_AUTHORITATIVE'])})
    reconstruction_attempts = []
    for r in _rules(node_payload, world, target, expected_kind):
        payload, err = _reconstruct(r, node_payload, world, target)
        reconstruction_attempts.append({'rule_id': r.get('rule_id') or r.get('rule_type'), 'error': err})
        if err is not None:
            continue
        entry = {'kind': r.get('kind') or expected_kind or 'object', 'verified': True, 'digest': digest(payload)}
        ok, reasons = _match_constraints(payload, entry, constraints)
        if ok:
            candidates.append({'id': str(r.get('rule_id') or 'RECONSTRUCTED::' + target), 'kind': entry['kind'], 'payload': payload, 'supplies': list(r.get('supplies') or []), 'digest': entry['digest'], 'provenance': {'reconstruction_rule': r.get('rule_id') or r.get('rule_type')}, 'route': 'RECONSTRUCT'})
        else:
            rejected.append({'id': str(r.get('rule_id') or 'RECONSTRUCTED'), 'reasons': reasons})
    uniq = {}
    for c in candidates:
        key = digest({'kind': c['kind'], 'payload': c['payload']})
        if key not in uniq:
            uniq[key] = c
        else:
            p = uniq[key].setdefault('equivalent_provenance', [])
            p.append(c['provenance'])
            uniq[key]['supplies'] = sorted(set(uniq[key]['supplies'] + c['supplies']))
    survivors = list(uniq.values())
    audit = {'schema': 'AC59_MATERIALIZATION_RESOLUTION_V1', 'target': target, 'expected_kind': expected_kind, 'catalog_candidates_seen': len(raw), 'federated_candidates_seen': len(federated), 'reconstruction_rules_seen': len(_rules(node_payload, world, target, expected_kind)), 'reconstruction_attempts': reconstruction_attempts, 'rejected': rejected, 'survivor_count': len(survivors), 'constraints': constraints, 'search_scopes': sorted(set((str(x) for x in node_payload.get('search_scopes') or world.get('search_scopes') or [])))}
    if len(survivors) == 1:
        c = survivors[0]
        audit['status'] = 'UNIQUE_LAST_SURVIVOR'
        audit['survivor_digest'] = c['digest']
        return {'status': 'MATERIALIZED', 'candidate': c, 'audit': audit}
    if len(survivors) > 1:
        audit['status'] = 'AMBIGUOUS_SURVIVORS'
        audit['survivor_ids'] = [c['id'] for c in survivors]
        return {'status': 'AMBIGUOUS', 'candidates': survivors, 'audit': audit}
    exhausted = bool(node_payload.get('recovery_scope_exhausted') or world.get('recovery_scope_exhausted'))
    authoritative_definition_absent = bool(node_payload.get('authoritative_definition_absent') or world.get('authoritative_definition_absent'))
    audit['status'] = 'EXHAUSTED_NO_SURVIVOR' if exhausted else 'SEARCH_INCOMPLETE_NO_SURVIVOR'
    if exhausted and authoritative_definition_absent:
        return {'status': 'EXTERNAL_DEFINITION_REQUIRED', 'audit': audit}
    return {'status': 'NEED_RECOVERY_OR_RECONSTRUCTION', 'audit': audit}
