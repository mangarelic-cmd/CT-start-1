"""AUX Causal Geometric Proof Engine v0.4

v0.4 keeps the full v0.3 246-space / 479-time geometric proof engine and adds
four exact *derived-coordinate* families motivated by the CT corpus without
silently promoting conjectural source claims into universal facts:

1. S013 prime-indexed time      tau_n = C_tau / p_n
2. S003 prime-indexed event time lambda_n = kappa*i(p_n)^q,
                                 Delta t_n = C_delta/lambda_n
3. S013 discrete temporal torus T_{n+1}=T_n+omega*t_P (mod 2*pi)
4. S066 mod-210 arithmetic wheel as an exact prime-preserving prefilter

It also adds an exact L1 metric intertwiner between the Universal-Wheel
Pythagorean carrier (P_e,Q_e,k_e) and a local v0.3 right-triangle receipt.
This intertwiner proves metric compatibility only.  It deliberately does NOT
claim the still-open material/physical identity between Universal Wheel and
CT Prime / external reality.

Design rule
-----------
Calculation is never blocked by lack of final proof.  Exact symbolic objects are
computed first.  Every stronger interpretation carries a separate source/model
status and a proof obligation.
"""
from __future__ import annotations
from dataclasses import dataclass
from hashlib import sha256
from math import gcd
from pathlib import Path
from typing import Any, Iterable
import json
import sympy as sp
from aux_causal_geometric_proof_engine_v0_3 import CausalChartPoint, CausalGeometricProofEngine, GeometricProofError, _expr, _s, build_reference_multispace_multitime_route
from aux_full_causal_coordinate_atlas_v0_2 import FullCausalCoordinateAtlas
CT_DERIVED_TIME_COORDINATES = [{'id': 'CT_PRIME_INDEXED_TIME_S013', 'formula': 'tau_n=C_tau/p_n', 'source': 'S013', 'source_status': 'CONJECTURAL_TEMPORAL_HYPOTHESIS'}, {'id': 'CT_PRIME_INDEXED_EVENT_TIME_S003', 'formula': 'lambda_n=kappa*i(p_n)^q; Delta_t_n=C_delta/lambda_n', 'source': 'S003', 'source_status': 'DOMAIN_MODEL_HYPOTHESIS'}, {'id': 'CT_DISCRETE_TEMPORAL_TORUS_S013', 'formula': 'T(n+1)=T(n)+(omega_phi,omega_S)t_P mod 2pi', 'source': 'S013', 'source_status': 'CONJECTURAL_TEMPORAL_PHASE_MODEL'}, {'id': 'CT_CYCLE_PHASE_CONTEXT_S070', 'formula': 'state=(visible_value,cycle_index,phase_context)', 'source': 'S070', 'source_status': 'REPAIR_COORDINATE_REQUIRED_TO_AVOID_FIXED_POINT_ITERATION_COLLISION'}]

def _canon(value: Any) -> str:
    return json.dumps(value, sort_keys=True, separators=(',', ':'), ensure_ascii=True, default=str)

def _digest(value: Any) -> str:
    return sha256(_canon(value).encode()).hexdigest()

def _require_positive_integer(n: Any, name: str='n') -> int:
    if type(n) is not int or n <= 0:
        raise GeometricProofError(f'{name.upper()}_MUST_BE_POSITIVE_INTEGER')
    return n

def nth_prime_exact(n: int) -> int:
    """Exact deterministic prime index for finite qualification / coordinate use."""
    _require_positive_integer(n)
    return int(sp.prime(n))

def prime_temporal_s013(n: int, C_tau: Any=1) -> dict[str, Any]:
    """Exact conditional realization of S013 tau_n proportional p_n^-1.

    The proportionality constant is explicit.  The arithmetic is exact; source
    universality remains whatever status the caller assigns to the S013 model.
    """
    p = nth_prime_exact(n)
    c = _expr(C_tau)
    tau = sp.simplify(c / p)
    return {'schema': 'CT_PRIME_TEMPORAL_S013_RECEIPT_V0_4', 'n': n, 'p_n': p, 'C_tau': _s(c), 'tau_n': _s(tau), 'exact_arithmetic': True, 'source_status': 'CONJECTURAL_TEMPORAL_HYPOTHESIS', 'claim_scope': 'EXACT_CONDITIONAL_ARITHMETIC_GIVEN_S013_LAW'}

def prime_temporal_s003(n: int, *, kappa: Any, alignment_i: Any, q: Any, C_delta: Any=1) -> dict[str, Any]:
    """Exact conditional realization of S003 prime-indexed temporal spectrum."""
    p = nth_prime_exact(n)
    k = _expr(kappa)
    i = _expr(alignment_i)
    qq = _expr(q)
    c = _expr(C_delta)
    if k.is_number and k == 0:
        raise GeometricProofError('KAPPA_MUST_BE_NONZERO')
    if i.is_number and i <= 0:
        raise GeometricProofError('ALIGNMENT_I_MUST_BE_POSITIVE_FOR_REAL_PRIME_TEMPORAL_MODE')
    lam = sp.simplify(k * i ** qq)
    delta = sp.simplify(c / lam)
    return {'schema': 'CT_PRIME_TEMPORAL_S003_RECEIPT_V0_4', 'n': n, 'p_n': p, 'kappa': _s(k), 'alignment_i': _s(i), 'q': _s(qq), 'C_delta': _s(c), 'lambda_n': _s(lam), 'delta_t_n': _s(delta), 'exact_symbolic': not bool(lam.atoms(sp.Float) | delta.atoms(sp.Float)), 'source_status': 'DOMAIN_MODEL_HYPOTHESIS', 'claim_scope': 'EXACT_CONDITIONAL_ARITHMETIC_GIVEN_S003_LAW'}

def prime_temporal_bridge(s013: dict[str, Any], s003: dict[str, Any]) -> dict[str, Any]:
    """Derive and test the exact bridge condition between S013 and S003.

    tau_n = Delta t_n iff
        i(p_n)^q = (C_delta/(kappa*C_tau))*p_n.

    This supplies the missing algebraic intertwiner *condition*.  It does not
    assert that the corpus has independently established that condition.
    """
    if s013['p_n'] != s003['p_n'] or s013['n'] != s003['n']:
        raise GeometricProofError('PRIME_TEMPORAL_BRIDGE_INDEX_MISMATCH')
    p = sp.Integer(s013['p_n'])
    tau = _expr(s013['tau_n'])
    delta = _expr(s003['delta_t_n'])
    i = _expr(s003['alignment_i'])
    q = _expr(s003['q'])
    kappa = _expr(s003['kappa'])
    C_tau = _expr(s013['C_tau'])
    C_delta = _expr(s003['C_delta'])
    required_power = sp.simplify(C_delta * p / (kappa * C_tau))
    actual_power = sp.simplify(i ** q)
    law_residual = sp.simplify(actual_power - required_power)
    time_residual = sp.simplify(tau - delta)
    equivalent_on_packet = (law_residual == 0) == (time_residual == 0)
    return {'schema': 'CT_PRIME_TEMPORAL_INTERTWINER_V0_4', 'n': int(s013['n']), 'p_n': int(s013['p_n']), 'derived_iff': 'tau_n=Delta_t_n iff i(p_n)^q=(C_delta/(kappa*C_tau))*p_n', 'required_alignment_power': _s(required_power), 'actual_alignment_power': _s(actual_power), 'alignment_law_residual': _s(law_residual), 'time_equality_residual': _s(time_residual), 'bridge_pass': bool(law_residual == 0 and time_residual == 0), 'packet_equivalence_check': bool(equivalent_on_packet), 'source_bridge_status': 'DERIVED_CONDITION_AVAILABLE_SOURCE_ASSERTION_STILL_OPEN', 'claim_scope': 'EXACT_ALGEBRAIC_IFF_CONDITIONAL_ON_TWO_DECLARED_SOURCE_LAWS'}

def mod210_wheel_receipt(n: int) -> dict[str, Any]:
    """Exact S066 wheel prefilter receipt; never upgrades survival to primality."""
    _require_positive_integer(n)
    residue = n % 210
    g = gcd(n, 210)
    return {'schema': 'CT_MOD210_WHEEL_PREFILTER_RECEIPT_V0_4', 'n': n, 'residue_mod_210': residue, 'gcd_n_210': g, 'admissible': g == 1, 'wheel_claim': 'PRIME_P_GT_7_IMPLIES_ADMISSIBLE', 'primality_conclusion': 'WITHHELD', 'claim_scope': 'EXACT_STANDARD_MOD210_PREFILTER_ONLY'}

def _reduce_angle_0_2pi(angle: sp.Expr) -> sp.Expr:
    angle = sp.simplify(angle)
    coeff = sp.simplify(angle / sp.pi)
    if coeff.is_Rational:
        return sp.simplify(sp.Mod(coeff, 2) * sp.pi)
    return sp.Mod(angle, 2 * sp.pi)

@dataclass(frozen=True)
class TemporalTorusState:
    theta_phi: Any
    theta_S: Any
    cycle_index: int = 0

    def parsed(self) -> tuple[sp.Expr, sp.Expr, int]:
        if type(self.cycle_index) is not int or self.cycle_index < 0:
            raise GeometricProofError('TORUS_CYCLE_INDEX_MUST_BE_NONNEGATIVE_INTEGER')
        return (_reduce_angle_0_2pi(_expr(self.theta_phi)), _reduce_angle_0_2pi(_expr(self.theta_S)), self.cycle_index)

def temporal_torus_step(state: TemporalTorusState, *, omega_phi: Any, omega_S: Any, t_P: Any) -> TemporalTorusState:
    a, b, n = state.parsed()
    op = _expr(omega_phi)
    os = _expr(omega_S)
    tp = _expr(t_P)
    return TemporalTorusState(_reduce_angle_0_2pi(a + op * tp), _reduce_angle_0_2pi(b + os * tp), n + 1)

def temporal_torus_orbit(initial: TemporalTorusState, *, omega_phi: Any, omega_S: Any, t_P: Any, steps: int) -> dict[str, Any]:
    if type(steps) is not int or steps < 0:
        raise GeometricProofError('TORUS_STEPS_MUST_BE_NONNEGATIVE_INTEGER')
    init_a, init_b, init_n = initial.parsed()
    states = [TemporalTorusState(init_a, init_b, init_n)]
    cur = states[0]
    for _ in range(steps):
        cur = temporal_torus_step(cur, omega_phi=omega_phi, omega_S=omega_S, t_P=t_P)
        states.append(cur)
    fa, fb, _ = states[-1].parsed()
    closed = sp.simplify(fa - init_a) == 0 and sp.simplify(fb - init_b) == 0
    rows = []
    for s in states:
        a, b, n = s.parsed()
        rows.append({'cycle_index': n, 'theta_phi': _s(a), 'theta_S': _s(b)})
    return {'schema': 'CT_DISCRETE_TEMPORAL_TORUS_ORBIT_V0_4', 'initial': rows[0], 'omega_phi': _s(_expr(omega_phi)), 'omega_S': _s(_expr(omega_S)), 't_P': _s(_expr(t_P)), 'steps': steps, 'states': rows, 'closed_to_initial_phase': bool(closed), 'exact_symbolic': True, 'source_status': 'CONJECTURAL_TEMPORAL_PHASE_MODEL', 'claim_scope': 'EXACT_ITERATION_GIVEN_DECLARED_TORUS_UPDATE'}

def cycle_state_key(visible_value: Any, cycle_index: int, phase_context: Any) -> str:
    if type(cycle_index) is not int or cycle_index < 0:
        raise GeometricProofError('CYCLE_INDEX_MUST_BE_NONNEGATIVE_INTEGER')
    return 'CT_CYCLE_STATE::' + _digest({'visible_value': visible_value, 'cycle_index': cycle_index, 'phase_context': phase_context})[:24]

def universal_wheel_trig_identity_receipt() -> dict[str, Any]:
    A, B = sp.symbols('A B', real=True)
    residual = sp.trigsimp(2 * sp.sin(A) * sp.sin(B) - (sp.cos(A - B) - sp.cos(A + B)))
    return {'schema': 'CT_UNIVERSAL_WHEEL_TRIG_IDENTITY_V0_4', 'identity': '2*sin(A)*sin(B)=cos(A-B)-cos(A+B)', 'residual': _s(residual), 'pass': bool(residual == 0), 'claim_scope': 'EXACT_TRIGONOMETRIC_IDENTITY'}

def wheel_metric_intertwiner(segment: dict[str, Any]) -> dict[str, Any]:
    """Map a local geometric segment to Wheel metric carrier (P_e,Q_e,k_e)."""
    P = _expr(segment['legs']['space_length'])
    Q = _expr(segment['legs']['time_length'])
    k = _expr(segment['diagonal']['length'])
    residual = sp.simplify(P ** 2 + Q ** 2 - k ** 2)
    return {'schema': 'CT_WHEEL_GEOMETRIC_L1_METRIC_INTERTWINER_V0_4', 'segment': f"{segment['from']}->{segment['to']}", 'mapping': {'P_e': _s(P), 'Q_e': _s(Q), 'k_e': _s(k)}, 'wheel_metric_residual': _s(residual), 'metric_intertwiner_pass': bool(residual == 0), 'intertwiner_level': 'L1_METRIC_ONLY', 'material_intertwiner': False, 'claim_scope': 'EXACT_METRIC_CARRIER_COMPATIBILITY_NOT_EXTERNAL_MODEL_IDENTITY'}

def wheel_twist_commuting_square(pre_segment: dict[str, Any], post_segment: dict[str, Any]) -> dict[str, Any]:
    """Prove F o J_wheel = J_geom o F on a paired local metric cell."""
    pre = wheel_metric_intertwiner(pre_segment)
    post = wheel_metric_intertwiner(post_segment)
    P, Q, k = map(_expr, (pre['mapping']['P_e'], pre['mapping']['Q_e'], pre['mapping']['k_e']))
    P2, Q2, k2 = map(_expr, (post['mapping']['P_e'], post['mapping']['Q_e'], post['mapping']['k_e']))
    residuals = {'post_P_minus_pre_Q': sp.simplify(P2 - Q), 'post_Q_minus_pre_P': sp.simplify(Q2 - P), 'post_k_minus_pre_k': sp.simplify(k2 - k)}
    passed = all((v == 0 for v in residuals.values()))
    return {'schema': 'CT_WHEEL_GEOMETRIC_TWIST_COMMUTING_SQUARE_V0_4', 'J_wheel': '(P_e,Q_e,k_e)->(Q_e,P_e,k_e)', 'J_geom': '(Delta_x,Delta_t,D)->(Delta_t,Delta_x,D)', 'residuals': {k: _s(v) for k, v in residuals.items()}, 'commutes': bool(passed), 'J_wheel_squared_identity': True, 'metric_isometry': bool(sp.simplify(k2 - k) == 0), 'intertwiner_level': 'L1_METRIC_ONLY', 'material_intertwiner': False, 'claim_scope': 'EXACT_COMMUTING_METRIC_SQUARE_NOT_MATERIAL_EQUIVALENCE'}

def build_prime_torus_wheel_qualification(atlas: FullCausalCoordinateAtlas) -> dict[str, Any]:
    """Integrated qualification over the real 246/479 atlas and v0.3 route."""
    base = build_reference_multispace_multitime_route(atlas)
    prime_packets = []
    for n in range(1, 6):
        p = nth_prime_exact(n)
        a = prime_temporal_s013(n, 1)
        b = prime_temporal_s003(n, kappa=1, alignment_i=p ** 2, q=(1, 2), C_delta=1)
        br = prime_temporal_bridge(a, b)
        prime_packets.append({'s013': a, 's003': b, 'bridge': br, 'mod210': mod210_wheel_receipt(p)})
    torus = temporal_torus_orbit(TemporalTorusState(0, 0, 0), omega_phi=1, omega_S=2, t_P='pi/3', steps=6)
    wheel_segments = [wheel_metric_intertwiner(s) for s in base['segments']]
    commute = wheel_twist_commuting_square(base['segments'][1], base['segments'][2])
    trig = universal_wheel_trig_identity_receipt()
    cycle_keys = [cycle_state_key('VISIBLE_CONSTANT', i, torus['states'][i % len(torus['states'])]) for i in range(5)]
    internal_pass = all([base['proof_ready'], all((x['bridge']['bridge_pass'] for x in prime_packets)), torus['closed_to_initial_phase'], all((x['metric_intertwiner_pass'] for x in wheel_segments)), commute['commutes'], trig['pass'], len(set(cycle_keys)) == len(cycle_keys)])
    return {'schema': 'CT_PRIME_TORUS_WHEEL_GEOMETRIC_QUALIFICATION_V0_4', 'atlas_digest': atlas.atlas_digest, 'native_space_count': len(atlas.space_ids), 'native_time_count': len(atlas.time_ids), 'ct_derived_time_coordinate_count': len(CT_DERIVED_TIME_COORDINATES), 'ct_derived_time_coordinates': CT_DERIVED_TIME_COORDINATES, 'base_geometric_route': base, 'prime_temporal_packets': prime_packets, 'temporal_torus': torus, 'wheel_metric_segments': wheel_segments, 'wheel_twist_commuting_square': commute, 'universal_wheel_trig_identity': trig, 'cycle_state_keys': cycle_keys, 'internal_exact_model_pass': bool(internal_pass), 'external_material_intertwiner_status': 'OPEN_NOT_CLAIMED', 'source_truth_promotion': False, 'claim_ceiling': 'EXACT_INTERNAL_ALGEBRA_GEOMETRY_AND_CONDITIONAL_INTERTWINERS; SOURCE_PHYSICAL_UNIVERSALITY_WITHHELD'}

def build_negative_qualification(atlas: FullCausalCoordinateAtlas) -> dict[str, Any]:
    """Deliberately violate the prime bridge and Wheel diagonal to prove fail-closed behavior."""
    base = build_reference_multispace_multitime_route(atlas)
    n = 5
    p = nth_prime_exact(n)
    s013 = prime_temporal_s013(n, 1)
    s003 = prime_temporal_s003(n, kappa=1, alignment_i=p, q=(1, 2), C_delta=1)
    bridge = prime_temporal_bridge(s013, s003)
    seg = json.loads(json.dumps(base['segments'][0]))
    seg['diagonal']['length'] = '6'
    wheel = wheel_metric_intertwiner(seg)
    return {'schema': 'CT_PRIME_TORUS_WHEEL_NEGATIVE_QUALIFICATION_V0_4', 'prime_bridge_expected_fail': not bridge['bridge_pass'], 'wheel_metric_expected_fail': not wheel['metric_intertwiner_pass'], 'prime_bridge': bridge, 'wheel_metric': wheel, 'fail_closed': bool(not bridge['bridge_pass'] and (not wheel['metric_intertwiner_pass']))}
if __name__ == '__main__':
    root = Path(__file__).resolve().parent
    atlas = FullCausalCoordinateAtlas(root / 'scientific_space_containment_candidate_v3.json', root / 'scientific_temporal_catalog_v1.json')
    out = {'positive': build_prime_torus_wheel_qualification(atlas), 'negative': build_negative_qualification(atlas)}
    print(json.dumps(out, ensure_ascii=False, indent=2))
