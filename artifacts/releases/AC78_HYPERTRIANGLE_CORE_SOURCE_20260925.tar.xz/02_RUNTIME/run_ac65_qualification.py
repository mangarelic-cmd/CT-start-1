\
from pathlib import Path
import json,sys
HERE=Path(__file__).resolve().parent
sys.path.insert(0,str(HERE))
from proof_reconstruction_orchestrator import fabric_audit,reconstruct
from sovereign_solver import SovereignSolver
from all_everything_wave_engine import Node

def main():
    aud=fabric_audit()
    exact={'target':'S','claims':[{'id':'A','statement':'a=a','verifier':{'kind':'SYMBOLIC_IDENTITY','symbols':['a'],'lhs':'a','rhs':'a'}}], 'edges':[{'id':'A_TO_S','from':['A'],'to':'S','rule':'EXPLICIT_PROOF_OBJECT','proof_object':{'verified':True,'conclusion':'S'}}], 'theorem_search_raw':{'a':1}}
    r1=reconstruct(exact)
    geometric={'target':'C','claims':[{'id':'ER3','verifier':{'kind':'SYMBOLIC_IDENTITY','symbols':['q','xr','p','ar'],'lhs':'2**ar*(q*((3*xr+1)/2**ar)-p)','rhs':'3*(q*xr-p)+q+(3-2**ar)*p'}}], 'edges':[], 'geometry_evidence':[{'pythagorean_pass':True}], 'theorem_search_raw':{'recurrence':'3-adic','complexity':'high'}}
    r2=reconstruct(geometric)
    seed=Node('PROBLEM',{'statement':'QUALIFICATION_FORMAL_ROOT','scientific_focus':True,'proof_reconstruction_spec':exact},context=('AC65','QUAL'))
    run=SovereignSolver().solve_universal([seed],max_waves=4,max_calls=10000)
    out={'schema':'AC65_QUALIFICATION_V1','theorem_fabric':aud,'exact_reconstruction':r1,'geometry_only_reconstruction':r2,'solver_run_state':run['run_state'],'solver_formal_proof_verified':run['formal_proof_verified'],'mechanism_count':run['active_mechanism_count']}
    out['pass']=bool(aud['pass'] and r1['formal_proof_verified'] and not r2['formal_proof_verified'] and run['formal_proof_verified'])
    print(json.dumps(out,indent=2,sort_keys=True))
if __name__=='__main__': main()
