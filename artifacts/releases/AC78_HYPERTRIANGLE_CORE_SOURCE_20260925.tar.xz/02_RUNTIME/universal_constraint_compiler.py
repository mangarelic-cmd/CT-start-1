from __future__ import annotations
from typing import Any, Dict, List, Optional
import hashlib, json, re
from semantic_constraint_unifier import enrich_constraint_spec, compare_specs

RULE_KEYS = ('constraint_rule','normative_rule','declarative_rule','rule_packet')
OPPOSITES = {
    'REQUIRE': {'PROHIBIT'}, 'PROHIBIT': {'REQUIRE','ALLOW'}, 'ALLOW': {'PROHIBIT'},
    'PRESERVE': {'RETIRE','DELETE'}, 'RETIRE': {'PRESERVE','RETAIN'}, 'RETAIN': {'RETIRE','DELETE'},
    'CONTINUE': {'STOP'}, 'STOP': {'CONTINUE'},
}


def _canon(x: Any) -> str:
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=False, default=str)

def _sha(x: Any) -> str:
    return hashlib.sha256(_canon(x).encode()).hexdigest()

def _clean_text(s: Any) -> str:
    s = str(s or '').replace('\u2011','-').replace('\u2013','-').replace('\u2014','-').replace('\ufffe','')
    s = re.sub(r'\s+', ' ', s).strip()
    s = re.sub(r'^\s*\d+\.\s*', '', s)
    return s

def _explicit_packet(payload: Dict[str,Any]) -> Optional[Dict[str,Any]]:
    for k in RULE_KEYS:
        v=payload.get(k)
        if isinstance(v,dict):
            out=dict(v); out.setdefault('source',k); return out
    return None

def _operator_from_text(text: str) -> str:
    u=' '+text.upper()+' '
    patterns=[
        (r'\b(MUST\s+NOT|SHALL\s+NOT|DO\s+NOT|NEVER|MAY\s+NOT)\b','PROHIBIT'),
        (r'\b(MUST|SHALL|IS\s+REQUIRED\s+TO|ARE\s+REQUIRED\s+TO|REQUIRES?)\b','REQUIRE'),
        (r'\bSHOULD\s+NOT\b','PREFER_NOT'),
        (r'\bSHOULD\b','PREFER'),
        (r'\bMAY\b','ALLOW'),
        (r'\bPRESERVE\b','PRESERVE'),
        (r'\b(VALIDATE|VERIFY|PROVE|CHECK)\b','VALIDATE'),
        (r'\b(CLASSIFY|DISTINGUISH|SEPARATE)\b','CLASSIFY'),
        (r'\b(RETAIN|KEEP)\b','RETAIN'),
        (r'\b(RETIRE|REMOVE|DELETE|CLEAN\s+UP)\b','RETIRE'),
        (r'\bCONTINUE\b','CONTINUE'),
        (r'\bSTOP\b','STOP'),
        (r'\b(REPORT|STATE|IDENTIFY|RECORD|DOCUMENT)\b','REPORT'),
        (r'\b(PREFER)\b','PREFER'),
    ]
    for pat,op in patterns:
        if re.search(pat,u): return op
    # Imperative leading verb is still a typed action, not an unresolved equation.
    m=re.match(r'^([A-Za-z][A-Za-z-]+)\b', text)
    if m: return 'ACTION::'+m.group(1).upper()
    return 'DECLARE'

def _condition_from_text(text: str) -> Optional[str]:
    m=re.match(r'^(When|If|Before|After|While|Where|Once|Until)\s+(.+?),\s*(.+)$', text, flags=re.I)
    if m: return f'{m.group(1).upper()} {m.group(2).strip()}'
    m=re.search(r'\bprovided\s+that\s+(.+?)(?:[.;]|$)', text, flags=re.I)
    return ('PROVIDED '+m.group(1).strip()) if m else None

def _exception_from_text(text: str) -> Optional[str]:
    m=re.search(r'\b(unless|except(?:\s+when|\s+where|\s+for)?)\b\s+(.+?)(?:[.;]|$)', text, flags=re.I)
    return f'{m.group(1).upper()} {m.group(2).strip()}' if m else None


def _body_after_condition(text: str) -> str:
    m=re.match(r'^(When|If|Before|After|While|Where|Once|Until)\s+.+?,\s*(.+)$', text, flags=re.I)
    return m.group(2).strip() if m else text

def _target_from_text(text: str) -> str:
    t=text
    m=re.match(r'^(When|If|Before|After|While|Where|Once|Until)\s+.+?,\s*(.+)$', t, flags=re.I)
    if m: t=m.group(2).strip()
    # remove strongest modal phrase but retain semantic body
    t=re.sub(r'\b(MUST\s+NOT|SHALL\s+NOT|DO\s+NOT|SHOULD\s+NOT|MUST|SHALL|SHOULD|MAY|NEVER)\b', '', t, count=1, flags=re.I)
    return re.sub(r'\s+',' ',t).strip(' .')

def _constraint_key(scope: str, condition: Any, target: str) -> str:
    norm=lambda x: re.sub(r'[^a-z0-9]+',' ',str(x or '').lower()).strip()
    return _sha({'scope':norm(scope),'condition':norm(condition),'target':norm(target)})

def infer_constraint_route(payload: Dict[str,Any]) -> Optional[Dict[str,Any]]:
    explicit=_explicit_packet(payload)
    if explicit is not None:
        text=_clean_text(explicit.get('text') or explicit.get('rule_text') or payload.get('rule_text') or payload.get('statement'))
        op=str(explicit.get('operator') or explicit.get('operation') or _operator_from_text(_body_after_condition(text))).upper()
        scope=str(explicit.get('scope') or payload.get('scope') or payload.get('plate') or payload.get('domain') or 'DECLARED_SCOPE')
        condition=explicit.get('condition') if explicit.get('condition') not in ('',None) else _condition_from_text(text)
        target=str(explicit.get('target') or explicit.get('object') or _target_from_text(text) or 'DECLARED_TARGET')
        exception=explicit.get('exception') if explicit.get('exception') not in ('',None) else _exception_from_text(text)
        authority=str(explicit.get('authority') or payload.get('authority') or 'DECLARED_RULESET')
        precedence=explicit.get('precedence', payload.get('precedence'))
        rule_id=str(explicit.get('rule_id') or payload.get('rule_id') or payload.get('id') or _sha(text)[:16])
        validation=explicit.get('validation_condition') or explicit.get('postcondition') or payload.get('validation_condition')
        key=str(explicit.get('constraint_key') or _constraint_key(scope,condition,target))
        spec={'kind':'UNIVERSAL_CONSTRAINT_RULE','rule_id':rule_id,'text':text,'operator':op,'scope':scope,'condition':condition,
              'authority':authority,'target':target,'exception':exception,'precedence':precedence,'validation_condition':validation,
              'constraint_key':key,'parse_mode':'EXPLICIT_STRUCTURED','auto_extracted':True}
        spec=enrich_constraint_spec(spec)
        return {'status':'AUTO_EXTRACTED','route_spec':spec,'requires':[],'source':explicit.get('source','structured_rule_packet')}

    # Plain-rule carrier is opt-in by rule_text, declared normative cake, or rule_id.
    declared = payload.get('rule_text') is not None or payload.get('rule_id') is not None or str(payload.get('cake') or '').upper() in {
        'NORMATIVE_GOVERNANCE_RULE','NORMATIVE_RULE','CONSTRAINT_RULE','DECLARATIVE_RULE','RULE'
    }
    if not declared: return None
    text=_clean_text(payload.get('rule_text') or payload.get('statement'))
    if not text:
        return {'status':'NEED_DATA','route_spec':None,'requires':['RULE_TEXT_OR_STRUCTURED_RULE_PACKET'],'source':'constraint_carrier'}
    op=str(payload.get('operator') or payload.get('operation') or _operator_from_text(_body_after_condition(text))).upper()
    scope=str(payload.get('scope') or payload.get('plate') or payload.get('domain') or 'DECLARED_SCOPE')
    condition=payload.get('condition') if payload.get('condition') not in ('',None) else _condition_from_text(text)
    target=str(payload.get('target') or _target_from_text(text) or 'DECLARED_TARGET')
    exception=payload.get('exception') if payload.get('exception') not in ('',None) else _exception_from_text(text)
    authority=str(payload.get('authority') or 'DECLARED_RULESET')
    precedence=payload.get('precedence')
    validation=payload.get('validation_condition') or payload.get('postcondition')
    rule_id=str(payload.get('rule_id') or _sha(text)[:16])
    key=str(payload.get('constraint_key') or _constraint_key(scope,condition,target))
    spec={'kind':'UNIVERSAL_CONSTRAINT_RULE','rule_id':rule_id,'text':text,'operator':op,'scope':scope,'condition':condition,
          'authority':authority,'target':target,'exception':exception,'precedence':precedence,'validation_condition':validation,
          'constraint_key':key,'parse_mode':'DETERMINISTIC_RULE_TEXT','auto_extracted':True}
    spec=enrich_constraint_spec(spec)
    return {'status':'AUTO_EXTRACTED','route_spec':spec,'requires':[],'source':'constraint_carrier'}


def _cell(i:int, op:str, before:str, after:str, plate:str, **kw):
    c={'display_index':i,'operation':op,'cake_before':before,'cake_after':after,'plate_before':plate,'plate_after':plate,
       'legal':kw.pop('legal',True),'permission':kw.pop('permission','ALLOW'),'residue':kw.pop('residue',None),
       'mirror_operator':kw.pop('mirror',None),'mirror_kind':kw.pop('mirror_kind','STRUCTURAL_DUAL'),
       'causal_reverse':kw.pop('causal_reverse','NOT_CLAIMED'),'notes':kw.pop('notes',[])}
    c.update(kw); return c


def compile_constraint_route(spec: Dict[str,Any]) -> Dict[str,Any]:
    op=str(spec.get('operator') or 'DECLARE').upper(); scope=str(spec.get('scope') or 'DECLARED_SCOPE')
    target=str(spec.get('target') or 'DECLARED_TARGET'); condition=spec.get('condition'); exception=spec.get('exception')
    authority=str(spec.get('authority') or 'DECLARED_RULESET'); validation=spec.get('validation_condition')
    missing=[]
    if not target or target=='DECLARED_TARGET': missing.append('TARGET_SEMANTICS')
    if not op: missing.append('OPERATOR_SEMANTICS')
    cells=[
        _cell(1,'NORMALIZE_RULE',spec.get('text',''),f'RULE[{spec.get("rule_id")}]',scope,mirror='DENORMALIZE_WITH_PROVENANCE',causal_reverse='REPRESENTATION_REVERSE_AVAILABLE'),
        _cell(2,'EVALUATE_CONDITION',str(condition or 'ALWAYS'),str(condition or 'ALWAYS'),scope,mirror='CONDITION_TRACE',causal_reverse='NOT_TEMPORAL_REVERSE'),
        _cell(3,'APPLY_AUTHORITY_PRECEDENCE',authority,f'{authority}; precedence={spec.get("precedence")}',scope,mirror='PRECEDENCE_AUDIT',causal_reverse='NOT_CLAIMED'),
        _cell(4,f'APPLY_{op}',target,target,scope,mirror='OPERATOR_DUAL_IF_DECLARED',causal_reverse='NOT_CLAIMED'),
        _cell(5,'APPLY_EXCEPTIONS',str(exception or 'NONE'),str(exception or 'NONE'),scope,mirror='EXCEPTION_TRACE',causal_reverse='NOT_CLAIMED'),
        _cell(6,'VALIDATE_POSTCONDITION',str(validation or 'DECLARED_RULE_EFFECT'),str(validation or 'DECLARED_RULE_EFFECT'),scope,mirror='NEGATIVE_CONTROL',causal_reverse='NOT_CLAIMED'),
        _cell(7,'EMIT_RULE_STATUS','UNRESOLVED','SAT|CONFLICT|OVERRIDDEN|NOT_APPLICABLE',scope,mirror='STATUS_AUDIT',causal_reverse='NOT_CLAIMED'),
    ]
    # Structural compilation closes the carrier even when applicability is runtime-conditional.
    # Unknown imperative verbs remain as semantic skin instead of being silently mapped to a stronger operator.
    semantic_residues=[]
    if op=='DECLARE' or op.startswith('ACTION::'):
        semantic_residues.append('OPERATOR_SEMANTIC_CLASSIFICATION_OPTIONAL')
        cells[3]['residue']='OPERATOR_SEMANTIC_CLASSIFICATION_OPTIONAL'
    status=('CLOSED_STRUCTURAL_WITH_RESIDUE' if semantic_residues else 'CLOSED_STRUCTURAL') if not missing else 'OPEN_TYPED'
    return {'schema':'AC76_SEMANTIC_CONSTRAINT_ROUTE_V1','compatibility_schema':'AC75_UNIVERSAL_CONSTRAINT_ROUTE_V1','kind':'UNIVERSAL_CONSTRAINT_RULE','status':status,
            'solution':'STRUCTURED_CONSTRAINT_CARRIER','cells':cells,'grid':None,'requires':missing,'proof_check':True,
            'semantic_residues':semantic_residues,'constraint_rule':dict(spec),'core_rules':{
                'truth_not_inferred_from_rule_text':True,'precedence_not_invented':True,'scope_preserved':True,
                'exception_preserved':True,'conflict_requires_explicit_resolution':True,'semantic_skin_append_only':True,
                'external_rule_not_promoted_to_ct_axiom':True,'semantic_similarity_never_creates_truth':True}}


class UniversalConstraintLedger:
    def __init__(self):
        self.by_key: Dict[str,List[Dict[str,Any]]] = {}
        self.rows: List[Dict[str,Any]] = []
        self.semantic_pair_index: Dict[str,set] = {}
        self.semantic_key_index: Dict[str,set] = {}
        self.semantic_pairs_screened=0; self.semantic_pairs_compared=0
        self.total=0; self.active=0; self.redundant=0; self.conflict_open=0; self.overridden=0
        self.semantic_redundant_pairs=0; self.semantic_high_redundancy_pairs=0
        self.semantic_specialization_pairs=0; self.semantic_overlap_review_pairs=0
        self.semantic_conflict_candidate_pairs=0; self.semantic_deterministic_conflict_pairs=0
        self.semantic_distinct_pairs=0

    @staticmethod
    def _priority(v:Any):
        if v is None: return None
        try: return float(v)
        except Exception: return None

    def _record_relation(self, rel:Dict[str,Any]):
        r=rel.get('relation')
        if r=='REDUNDANT_DETERMINISTIC': self.semantic_redundant_pairs+=1
        elif r=='REDUNDANT_HIGH_CONFIDENCE': self.semantic_high_redundancy_pairs+=1
        elif r=='SPECIALIZATION': self.semantic_specialization_pairs+=1
        elif r=='OVERLAP_REVIEW': self.semantic_overlap_review_pairs+=1
        elif r=='CONFLICT_CANDIDATE': self.semantic_conflict_candidate_pairs+=1
        elif r=='CONFLICT_DETERMINISTIC': self.semantic_deterministic_conflict_pairs+=1
        else: self.semantic_distinct_pairs+=1

    def register(self,spec:Dict[str,Any]) -> Dict[str,Any]:
        spec=enrich_constraint_spec(spec)
        key=str(spec.get('constraint_key') or _constraint_key(spec.get('scope'),spec.get('condition'),spec.get('target')))
        op=str(spec.get('operator') or 'DECLARE').upper(); pri=self._priority(spec.get('precedence'))
        prior=self.by_key.setdefault(key,[])
        status='ACTIVE'; conflict_with=[]; overrides=[]; semantic_relations=[]

        # AC75 exact-key behavior remains authoritative and backward compatible.
        for row in prior:
            pop=str(row.get('operator') or '').upper(); ppri=self._priority(row.get('precedence'))
            if pop==op:
                status='REDUNDANT'; break
            if pop in OPPOSITES.get(op,set()) or op in OPPOSITES.get(pop,set()):
                conflict_with.append(row.get('rule_id'))
                if pri is not None and ppri is not None and pri!=ppri:
                    if pri>ppri:
                        status='ACTIVE'; overrides.append(row.get('rule_id'))
                    else:
                        status='OVERRIDDEN'
                else:
                    status='CONFLICT_OPEN'

        # AC76 semantic comparison is corpus-wide but uses a deterministic inverted
        # semantic-atom index. This avoids O(N^2 * clause^2) blind comparison while
        # preserving all candidates that share a meaningful canonical atom.
        self.semantic_pairs_screened += len(self.rows)
        spec_atoms=set((spec.get('semantic_profile') or {}).get('semantic_atoms') or [])
        semantic_pair_keys=set()
        for atom in spec.get('atomic_constraints') or []:
            toks=sorted(set(atom.get('semantic_atoms') or []))
            if len(toks)>10:
                # Deterministic min-hash token sketch: controls long-clause combinatorics
                # without selecting document-specific vocabulary.
                toks=sorted(toks, key=lambda x:_sha(x))[:10]
            if len(toks)==1:
                semantic_pair_keys.add('S:'+toks[0])
            else:
                # Pair keys stay inside one clause, preventing cross-clause false candidates.
                for i in range(len(toks)):
                    for j in range(i+1,len(toks)):
                        semantic_pair_keys.add('P:'+toks[i]+'|'+toks[j])
        candidate_indices=set()
        for pk in semantic_pair_keys:
            candidate_indices.update(self.semantic_pair_index.get(pk,set()))
        # Exact semantic rule keys are always candidates, including zero/one-token rules.
        srk=(spec.get('semantic_profile') or {}).get('semantic_rule_key')
        if srk: candidate_indices.update(self.semantic_key_index.get(srk,set()))
        candidate_indices=sorted(candidate_indices)
        for idx in candidate_indices:
            row=self.rows[idx]
            if row.get('rule_id')==spec.get('rule_id'): continue
            self.semantic_pairs_compared += 1
            rel=compare_specs(spec,row)
            self._record_relation(rel)
            if rel.get('relation')!='DISTINCT':
                semantic_relations.append(rel)
            if status=='ACTIVE' and rel.get('relation')=='REDUNDANT_DETERMINISTIC':
                status='REDUNDANT'
            elif rel.get('relation')=='CONFLICT_DETERMINISTIC':
                rid=row.get('rule_id'); conflict_with.append(rid)
                ppri=self._priority(row.get('precedence'))
                if pri is not None and ppri is not None and pri!=ppri:
                    if pri>ppri:
                        status='ACTIVE'; overrides.append(rid)
                    else:
                        status='OVERRIDDEN'
                else:
                    status='CONFLICT_OPEN'

        row=dict(spec); row['ledger_status']=status; row['semantic_relations']=semantic_relations
        prior.append(row)
        row_idx=len(self.rows); self.rows.append(row)
        for pk in semantic_pair_keys: self.semantic_pair_index.setdefault(pk,set()).add(row_idx)
        if srk: self.semantic_key_index.setdefault(srk,set()).add(row_idx)
        self.total+=1
        if status=='ACTIVE': self.active+=1
        elif status=='REDUNDANT': self.redundant+=1
        elif status=='CONFLICT_OPEN': self.conflict_open+=1
        elif status=='OVERRIDDEN': self.overridden+=1
        requires=[]
        if status=='CONFLICT_OPEN': requires.append('EXPLICIT_PRECEDENCE_OR_SCOPE_DISAMBIGUATION')
        if any(x.get('relation')=='CONFLICT_CANDIDATE' for x in semantic_relations): requires.append('SEMANTIC_CONFLICT_REVIEW')
        return {'schema':'AC76_SEMANTIC_CONSTRAINT_LEDGER_RECEIPT_V1','compatibility_schema':'AC75_UNIVERSAL_CONSTRAINT_LEDGER_RECEIPT_V1',
                'status':status,'rule_id':spec.get('rule_id'),'constraint_key':key,'operator':op,'precedence':spec.get('precedence'),
                'conflict_with':list(dict.fromkeys(conflict_with)),'overrides':list(dict.fromkeys(overrides)),
                'semantic_relations':semantic_relations,'semantic_relation_count':len(semantic_relations),
                'requires':list(dict.fromkeys(requires)),'sovereign_root_preserved':True,'truth_credit_added':0,
                'external_authority_only':True,'ct_axiom_promoted':False}

    def counters(self):
        return {'total':self.total,'active':self.active,'redundant':self.redundant,'conflict_open':self.conflict_open,'overridden':self.overridden,
                'keys':len(self.by_key),'semantic_redundant_pairs':self.semantic_redundant_pairs,
                'semantic_high_redundancy_pairs':self.semantic_high_redundancy_pairs,
                'semantic_specialization_pairs':self.semantic_specialization_pairs,
                'semantic_overlap_review_pairs':self.semantic_overlap_review_pairs,
                'semantic_conflict_candidate_pairs':self.semantic_conflict_candidate_pairs,
                'semantic_deterministic_conflict_pairs':self.semantic_deterministic_conflict_pairs,
                'semantic_distinct_pairs':self.semantic_distinct_pairs,
                'semantic_pairs_screened':self.semantic_pairs_screened,'semantic_pairs_compared':self.semantic_pairs_compared,
                'semantic_pair_total':self.semantic_redundant_pairs+self.semantic_high_redundancy_pairs+self.semantic_specialization_pairs+self.semantic_overlap_review_pairs+self.semantic_conflict_candidate_pairs+self.semantic_deterministic_conflict_pairs+self.semantic_distinct_pairs}

