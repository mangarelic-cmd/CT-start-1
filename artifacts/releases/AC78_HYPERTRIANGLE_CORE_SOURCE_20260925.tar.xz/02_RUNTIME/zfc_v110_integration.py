from __future__ import annotations
import hashlib, json
from typing import Any, Dict, Iterable, List, Tuple
from all_everything_wave_engine import Node
from causal_zfc.logic import Prop
from causal_zfc.synthesizer import CausalZFCSynthesizer
from causal_zfc.kernel import ZFCKernel
from causal_zfc.causal_invariant_adapter import analyze_causal_state_packet
from causal_zfc.causal_api import run_two_cell_bridge

def _canon(x: Any) -> str:
    return json.dumps(x, sort_keys=True, separators=(',', ':'), ensure_ascii=True, default=str)

def _sha(x: Any) -> str:
    return hashlib.sha256(_canon(x).encode()).hexdigest()

def _provider_receipt(prop_name: str, source: str) -> Dict[str, Any]:
    """Kernel-verifiable formalization of an already exact scoped receipt.

    The proposition is carried as an explicit premise; this does NOT re-prove the
    scientific algebra inside ZFC. It certifies the logical/formal transport of the
    exact scoped receipt and therefore remains conditional on that receipt.
    """
    goal = Prop(prop_name)
    syn = CausalZFCSynthesizer(budget=50, max_depth=6)
    sr = syn.synthesize(goal, (goal,))
    if sr.status != 'PROVED' or sr.proof is None:
        raise ValueError('FORMALIZATION_SEARCH_FAILED')
    kr = ZFCKernel().verify(sr.proof)
    if not kr.ok:
        raise ValueError(f'FORMALIZATION_KERNEL_REJECT::{kr.code}::{kr.detail}')
    return {'kind': 'result', 'name': prop_name, 'provider': source, 'source': source, 'proof': sr.proof.to_obj(), 'formalization_mode': 'KERNEL_VERIFIED_TRANSPORT_FROM_EXACT_SCOPED_RECEIPT', 'unconditional_theorem': False}

def golden_selector_analysis(golden_node: Node) -> Dict[str, Any]:
    p = golden_node.payload
    if p.get('statement') != 'GOLDEN_STATE_CERTIFIED_EXACT_SCOPED':
        raise ValueError('NOT_GOLDEN_CERTIFIED_NODE')
    cls = p.get('classification') or {}
    if cls.get('golden_state') is not True:
        raise ValueError('GOLDEN_CLASSIFICATION_NOT_TRUE')
    frag = p.get('golden_fragment') or {}
    if frag.get('typed_role_binding') is not True or frag.get('same_state_same_carrier') is not True:
        raise ValueError('GOLDEN_BINDING_GATES_NOT_VERIFIED')
    if frag.get('normalized_unit_carrier') is not True:
        raise ValueError('GOLDEN_NORMALIZED_CARRIER_NOT_VERIFIED')
    state_material = {'metrics': frag.get('metrics'), 'square_bridge': (cls.get('residuals') or {}).get('square_bridge'), 'triangle1': (cls.get('residuals') or {}).get('triangle1'), 'unit_triangle': (cls.get('residuals') or {}).get('unit_triangle'), 'role_binding': True}
    state_digest = _sha(state_material)
    carrier_id = 'CT_PRIME_2SIN1COS_NORMALIZED_EXACT_V1'
    state_id = 'GOLDEN_STATE::' + state_digest[:24]
    source = 'GOLDEN_2SIN1COS_AUX::' + golden_node.identity()
    tri1 = _provider_receipt(f'TRIANGLE1::{state_id}', source)
    unit = _provider_receipt(f'UNIT_TRIANGLE::{state_id}', source)
    selector = _provider_receipt(f'STATE_SELECTOR::{state_id}::R2_EQ_C', source)
    packet = {'schema': 'CAUSAL_STATE_INVARIANT_PACKET_V1', 'carrier_id': carrier_id, 'state_id': state_id, 'bridge_state_id': state_id, 'typed_role_binding': True, 'normalized_carrier': True, 'same_state_same_carrier': True, 'selector_required': True, 'required_structural_roles': ['TRIANGLE_1', 'UNIT_TRIANGLE'], 'structural_receipts': {'TRIANGLE_1': tri1, 'UNIT_TRIANGLE': unit}, 'state_selector_receipt': selector, 'exact_metadata': {'scientific_receipt_digest': golden_node.identity(), 'selector': 'r^2=c', 'triangle1': 's1^2+s2^2=r^2', 'unit_triangle': 'r^2+c^2=1', 'authority_scope': 'GOLDEN_AUX_EXACT_SCOPED'}, 'coordinate_gauge': {'canonical_equal_sin_gauge': bool(p.get('canonical_equal_sin_gauge'))}, 'metric_packet': frag.get('metrics') or {}}
    analysis = analyze_causal_state_packet(packet)
    return {'packet': packet, 'analysis': analysis, 'selector_receipt': selector, 'formalization_mode': 'CONDITIONAL_ON_EXACT_GOLDEN_SCIENTIFIC_RECEIPT'}

def _cell_carrier(problem: Any) -> str:
    return 'AC51_DUAL_CELL_CARRIER::' + _sha({'problem': problem})[:24]

def _bridge_prop(residual: Any) -> str:
    return 'CELL_JUNCTION_INVARIANT::' + _sha({'residual': residual})[:24]

def cell1_invariant_packet(cell_node: Node) -> Dict[str, Any]:
    p = cell_node.payload
    cell = p.get('cell') or {}
    if p.get('cell_valid') is not True or cell.get('role') != 'RESIDUAL_CONTOUR':
        raise ValueError('INVALID_CELL1_FOR_INVARIANT_PACKET')
    residual = cell.get('end')
    problem = cell.get('start')
    carrier = _cell_carrier(problem)
    inv = _provider_receipt(_bridge_prop(residual), 'DUAL_CELL_GEOMETRY::' + cell_node.identity())
    structural = _provider_receipt('CELL1_VALID::' + str(cell.get('cell_id')), 'DUAL_CELL_GEOMETRY::' + cell_node.identity())
    packet = {'schema': 'CAUSAL_STATE_INVARIANT_PACKET_V1', 'carrier_id': carrier, 'state_id': str(residual), 'bridge_state_id': str(residual), 'typed_role_binding': True, 'normalized_carrier': True, 'same_state_same_carrier': True, 'selector_required': False, 'required_structural_roles': ['CELL1_VALID'], 'structural_receipts': {'CELL1_VALID': structural}, 'output_invariant_receipt': inv, 'exact_metadata': {'cell_id': str(cell.get('cell_id')), 'orientation': 'AB', 'role': 'RESIDUAL_CONTOUR'}}
    analysis = analyze_causal_state_packet(packet)
    return {'cell_position': 'CELL1', 'packet': packet, 'analysis': analysis, 'bridge_key': str(residual)}

def cell2_invariant_packet(dual_node: Node) -> Dict[str, Any]:
    p = dual_node.payload
    dual = p.get('dual_pass') or {}
    if dual.get('valid') is not True or dual.get('second_role') != 'DUAL_SOLUTION_CLOSURE':
        raise ValueError('INVALID_CELL2_FOR_INVARIANT_PACKET')
    residual = dual.get('residual')
    problem = dual.get('problem')
    carrier = _cell_carrier(problem)
    inv = _provider_receipt(_bridge_prop(residual), 'DUAL_CELL_GEOMETRY::' + dual_node.identity())
    structural = _provider_receipt('CELL2_VALID::' + str(dual.get('second_cell_id')), 'DUAL_CELL_GEOMETRY::' + dual_node.identity())
    packet = {'schema': 'CAUSAL_STATE_INVARIANT_PACKET_V1', 'carrier_id': carrier, 'state_id': str(dual.get('solution')), 'bridge_state_id': str(residual), 'typed_role_binding': True, 'normalized_carrier': True, 'same_state_same_carrier': True, 'selector_required': False, 'required_structural_roles': ['CELL2_VALID'], 'structural_receipts': {'CELL2_VALID': structural}, 'input_invariant_receipt': inv, 'exact_metadata': {'cell_id': str(dual.get('second_cell_id')), 'orientation': 'BA', 'role': 'DUAL_SOLUTION_CLOSURE'}}
    analysis = analyze_causal_state_packet(packet)
    return {'cell_position': 'CELL2', 'packet': packet, 'analysis': analysis, 'bridge_key': str(residual)}

def bridge_request_nodes(nodes: Iterable[Node], wave: int) -> List[Node]:
    left: Dict[Tuple[str, str], List[Node]] = {}
    right: Dict[Tuple[str, str], List[Node]] = {}
    for n in nodes:
        if n.kind != 'CAUSAL_STATE_PACKET':
            continue
        pkt = n.payload.get('packet') or {}
        key = (str(pkt.get('carrier_id')), str(pkt.get('bridge_state_id')))
        pos = n.payload.get('cell_position')
        if pos == 'CELL1':
            left.setdefault(key, []).append(n)
        elif pos == 'CELL2':
            right.setdefault(key, []).append(n)
    out: List[Node] = []
    for key in sorted(set(left) & set(right)):
        a = sorted(left[key], key=lambda n: n.identity())[0]
        b = sorted(right[key], key=lambda n: n.identity())[0]
        out.append(Node('CAUSAL_TWO_CELL_BRIDGE_REQUEST', {'statement': 'CELL1_TO_CELL2_FORMAL_INVARIANT_BRIDGE_REQUEST', 'carrier_id': key[0], 'bridge_state_id': key[1], 'cell1_packet': a.payload['packet'], 'cell2_packet': b.payload['packet']}, tuple(sorted((a.identity(), b.identity()))), wave))
    return out

def execute_bridge_request(node: Node) -> Dict[str, Any]:
    p = node.payload
    r = run_two_cell_bridge(p['cell1_packet'], p['cell2_packet'])
    return r

def triangulation_transport_analysis(twist_node: Node) -> Dict[str, Any]:
    """Kernel-verify the formal transport of an already exact triangulation receipt.

    This is a logical transport certificate conditional on the exact geometric receipt;
    it is not an unconditional theorem about an external scientific domain.
    """
    if twist_node.kind != 'TRIANGULATION_TWIST_RECEIPT':
        raise ValueError('NOT_TRIANGULATION_TWIST_RECEIPT')
    tw = twist_node.payload.get('twist') or {}
    tr = twist_node.payload.get('transport') or {}
    if tw.get('twist_involutive') is not True:
        raise ValueError('TWIST_NOT_INVOLUTIVE')
    if tw.get('same_invariant_both_witnesses') is not True:
        raise ValueError('FORWARD_REVERSE_INVARIANT_MISMATCH')
    if tw.get('forward_invariant_digest') != tw.get('reverse_invariant_digest'):
        raise ValueError('INVARIANT_DIGEST_MISMATCH')
    if not (tr.get('same_carrier') and tr.get('rank_unrank_roundtrip') and tr.get('temporal_validity') and tr.get('babel_normalized')):
        raise ValueError('CANONICAL_TRANSPORT_GATES_NOT_CLOSED')
    tid = str(tw.get('transport_id') or tr.get('transport_id'))
    source = 'AC56_TRIANGULATED_TRANSPORT::' + twist_node.identity()
    fw = _provider_receipt(f'FORWARD_TRIANGULATION::{tid}', source)
    rv = _provider_receipt(f'REVERSE_TRIANGULATION::{tid}', source)
    inv = _provider_receipt(f'COMMON_TRANSPORT_INVARIANT::{tid}', source)
    return {'closed': True, 'transport_id': tid, 'carrier_id': tr.get('carrier_id'), 'forward_receipt': fw, 'reverse_receipt': rv, 'invariant_receipt': inv, 'transport_kernel_verified': True, 'formalization_mode': 'KERNEL_VERIFIED_TRANSPORT_FROM_EXACT_TRIANGULATION_RECEIPT', 'external_domain_bridge_receipt': bool(tw.get('external_domain_bridge_receipt')), 'unconditional_theorem': False}
