\
from __future__ import annotations
from all_everything_wave_engine import AuxResult, Node
from proof_reconstruction_orchestrator import reconstruct
MECHANISM_ID='PROOF_RECONSTRUCTION_ORCHESTRATOR'
CATEGORY='FORMAL_PROOF'
def proof_reconstruction_orchestrator(node:Node,world:dict)->AuxResult:
    spec=node.payload.get('proof_reconstruction_spec')
    if not isinstance(spec,dict):
        return AuxResult(MECHANISM_ID,'NOT_APPLICABLE','AUX_OBSERVATION',{'statement':'NO_PROOF_RECONSTRUCTION_SPEC'},node.identity())
    receipt=reconstruct(spec)
    if receipt.get('formal_proof_verified'):
        return AuxResult(MECHANISM_ID,'PASS','FORMAL_PROOF_RECEIPT',{'statement':'FORMAL_PROOF_RECONSTRUCTED','formal_proof_verified':True,'proof_receipt':receipt,'proof_target':receipt.get('target')},node.identity())
    residuals=receipt.get('proof_residuals') or []
    req=[]
    for r in residuals:
        if isinstance(r,dict):
            rid=str(r.get('edge_id') or r.get('target') or 'PROOF_RESIDUAL')
            req.append('COMPLETE_PROOF_OBJECT::'+rid)
    return AuxResult(MECHANISM_ID,'OPEN','FORMAL_PROOF_CURRENT',{'statement':'FORMAL_PROOF_RESIDUAL','formal_proof_verified':False,'epistemic_status':'UNKNOWN','failed_proof_is_refutation':False,'proof_receipt':receipt,'proof_target':receipt.get('target'),'proof_residuals':residuals,'requires':sorted(set(req))},node.identity())
def registry_fragment(): return {MECHANISM_ID:proof_reconstruction_orchestrator}
def category_fragment(): return {MECHANISM_ID:CATEGORY}
