from __future__ import annotations
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver

CASES=[
    Node('PROBLEM',{'statement':'metric','cake':'d','plate':'R2','operator':'MOVE','metric_binding':{'displacement':[3,4],'metric':[[1,0],[0,1]]}},context=('AC72','metric')),
    Node('PROBLEM',{'statement':'q','cake':'route','plate':'grid','operator':'ADDRESS','q_binding':{'weights':[1,2,3]}},context=('AC72','q')),
    Node('PROBLEM',{'statement':'residue','cake':'x','plate':'R2','operator':'LINEAR_MAP','linear_residue_binding':{'A':[[1,1],[2,2]],'x':[3,1]}},context=('AC72','residue')),
    Node('PROBLEM',{'statement':'gate','cake':'v','plate':'TS','operator':'CLASSIFY','role_classifier_binding':{'operator':[[0,-1],[1,0]],'metric':[[1,0],[0,1]]}},context=('AC72','gate')),
    Node('PROBLEM',{'statement':'phi5','cake':'state','plate':'Phi5','operator':'BIND','phi5_binding':{'delta_s':[1,2],'metric':[[2,0],[0,3]],'psi_authority':'QUALIFIED_TEST_PSI'}},context=('AC72','phi5')),
    Node('PROBLEM',{'statement':'quotient','cake':'[x]','plate':'quotient','operator':'LIFT','quotient_lift_binding':{'visible_class':'[x]','fibre_coordinate':'g','section_authority':'QUALIFIED_TEST_SECTION'}},context=('AC72','quotient')),
]

def main():
    s=SovereignSolver(); r=s.solve_universal(CASES,max_waves=1,max_calls=5000)
    known=list(s.engine.known.values())
    receipts=[n for n in known if n.kind=='CAUSAL_GRID_BINDING_RECEIPT']
    passed=[n for n in receipts if n.payload.get('status')=='PASS']
    out={
        'schema':'AC72_QUALIFICATION_V1','case_count':len(CASES),'binding_receipt_count':len(receipts),
        'passing_binding_receipts':len(passed),'active_mechanism_count':r.get('active_mechanism_count'),
        'execution_calls':r.get('execution_calls'),'run_state':r.get('run_state'),
        'pass':len(receipts)==len(CASES) and len(passed)==len(CASES) and r.get('active_mechanism_count')==99
    }
    print(json.dumps(out,indent=2,ensure_ascii=False))
if __name__=='__main__': main()
