from __future__ import annotations
from copy import deepcopy
from .api import run_request
from .semantic import sequent_key
from .logic import formula_from_obj
from .axioms import SchemaInstance
from .causal_invariant_adapter import analyze_causal_state_packet, bridge_causal_cells

def _schema_instances_from_request(req: dict):
    out = []
    for s in req.get('schema_instances', []):
        out.append(SchemaInstance(s['schema'], formula_from_obj(s['predicate']), s.get('source_var', 'u'), s.get('target_var', 'v'), tuple(s.get('parameters', []))))
    return tuple(out)

def run_causal_request(req: dict) -> dict:
    """Run ordinary ZFC synthesis plus optional causal invariant analysis.

    The causal layer never creates formal authority. If the ordinary synthesizer proves the target,
    its proof can be used as the packet's FORMAL_TARGET receipt automatically.
    """
    base = run_request(req)
    packet = deepcopy(req.get('causal_state_packet') or {})
    if not packet:
        return {'schema': 'CAUSAL_ZFC_SYNTHESIS_RESULT_V7', 'zfc': base, 'causal_state': None, 'truth_authority': 'ZFCKernel'}
    if base.get('proof') is not None and packet.get('formal_target_receipt') is None:
        packet['formal_target_receipt'] = {'kind': 'result', 'name': 'SYNTHESIZED_FORMAL_TARGET', 'provider': 'AUX_CAUSAL_ZFC_PROOF_SYNTHESIZER', 'proof': base['proof']}
        goal = formula_from_obj(req['goal'])
        ctx = tuple((formula_from_obj(x) for x in req.get('context', [])))
        packet.setdefault('target_statement_identity', sequent_key(ctx, goal))
    state = analyze_causal_state_packet(packet, _schema_instances_from_request(req))
    return {'schema': 'CAUSAL_ZFC_SYNTHESIS_RESULT_V7', 'zfc': base, 'causal_state': state, 'truth_authority': 'ZFCKernel', 'promotion_allowed': state['promotion_allowed']}

def run_two_cell_bridge(cell1_packet: dict, cell2_packet: dict, bridge_receipt: dict | None=None, schema_instances=()) -> dict:
    return bridge_causal_cells(cell1_packet, cell2_packet, bridge_receipt, schema_instances)
