from __future__ import annotations
from .logic import *
from .proof import *
from .axioms import SchemaInstance
from .kernel import ZFCKernel
from .semantic import CertifiedStatement
from .setdefs import *
from .derived_library import _assume, _forall_elim, _and_l, _and_r, _imp_elim, _iff_l, _iff_r, _weaken, build_empty_unique
from .mathematics_library import OmegaSpec, CartesianProductSpec, build_cartesian_product_exists, build_ordered_pair_code_exists, build_successor_unique
from .arithmetic_library import GraphValueSpec, build_ordered_pair_injective, _op_injective_instance
from .recursion_library import RecursionCandidateSpec, build_omega_recursion_uniqueness, _function_unique_instance, build_ordered_pair_code_unique
from .natural_arithmetic_pass009 import *

def AddSectionHidden(f: Term, w: Term, m: Term) -> Formula:
    return Exists('gA', AdditionSectionSpec(f, w, m, V('gA')))

def MulSectionHidden(f: Term, w: Term, m: Term) -> Formula:
    addRec = RecursionCandidateSpec(V('aM'), w, w, m, V('gM'), 'za', 'na', 'sa', 'xa', 'ya')
    mulRec = RecursionCandidateSpec(f, w, w, V('zM'), V('aM'), 'zm', 'nm', 'sm', 'xm', 'ym')
    body = And(SuccessorFunctionSpec(V('gM'), w, 'sx', 'sy'), And(addRec, And(EmptySpec(V('zM'), 'ez'), And(Mem(V('zM'), w), mulRec))))
    return Exists('gM', Exists('aM', Exists('zM', body)))

def ExpSectionHidden(f: Term, w: Term, m: Term) -> Formula:
    addRec = RecursionCandidateSpec(V('aE'), w, w, m, V('gE'), 'za', 'na', 'sa', 'xa', 'ya')
    mulRec = RecursionCandidateSpec(V('uE'), w, w, V('zE'), V('aE'), 'zm', 'nm', 'sm', 'xm', 'ym')
    expRec = RecursionCandidateSpec(f, w, w, V('oE'), V('uE'), 'ze', 'ne', 'se', 'xe', 'ye')
    body = And(SuccessorFunctionSpec(V('gE'), w, 'sx', 'sy'), And(addRec, And(EmptySpec(V('zE'), 'ez'), And(Mem(V('zE'), w), And(mulRec, And(SuccessorSpec(V('oE'), V('zE'), 'uo'), And(Mem(V('oE'), w), expRec)))))))
    return Exists('gE', Exists('aE', Exists('zE', Exists('uE', Exists('oE', body)))))

def section_exists_formula(hidden) -> Formula:
    return Forall('w', Forall('m', Imp(And(OmegaSpec(V('w'), 'j', 'k'), Mem(V('m'), V('w'))), Exists('f', hidden(V('f'), V('w'), V('m'))))))

def build_add_section_hidden_exists(add_pf: Proof | None=None) -> Proof:
    add_pf = add_pf or build_addition_section_exists_unique()
    goal = section_exists_formula(AddSectionHidden)
    core = goal.body.body
    ctx = (core.left,)
    hb = _assume(core.left, ctx)
    ap = _weaken(add_pf, ctx)
    ap = _forall_elim(_forall_elim(ap, 'w'), 'm')
    exg = _imp_elim(ap, hb)
    assert isinstance(exg.conclusion, Exists)
    G = 'Gah'
    ig = substitute(exg.conclusion.body, exg.conclusion.var, V(G))
    ctxG = ctx + (ig,)
    hg = _assume(ig, ctxG)
    exf = hg
    assert isinstance(exf.conclusion, Exists)
    F = 'Fah'
    iff = substitute(exf.conclusion.body, exf.conclusion.var, V(F))
    ctxF = ctxG + (iff,)
    hf = _assume(iff, ctxF)
    cand = _and_l(hf)
    hidden = AddSectionHidden(V(F), V('w'), V('m'))
    ih = substitute(hidden.body, hidden.var, V(G))
    eg = Proof('exists_intro', hidden, ctxF, (cand,), (('term', {'var': G}),))
    tf = substitute(core.right.body, core.right.var, V(F))
    ef = Proof('exists_intro', core.right, ctxF, (eg,), (('term', {'var': F}),))
    af = Proof('exists_elim', core.right, ctxG, (exf, ef), (('eigenvar', F),))
    ag = Proof('exists_elim', core.right, ctx, (exg, af), (('eigenvar', G),))
    ip = Proof('imp_intro', core, (), (ag,))
    qm = Proof('forall_intro', goal.body, (), (ip,))
    return Proof('forall_intro', goal, (), (qm,))

def build_mul_section_hidden_exists(add_hidden_pf: Proof | None=None, mul_mod_pf: Proof | None=None) -> Proof:
    add_hidden_pf = add_hidden_pf or build_add_section_hidden_exists()
    mul_mod_pf = mul_mod_pf or build_multiplication_from_addition()
    goal = section_exists_formula(MulSectionHidden)
    core = goal.body.body
    ctx = (core.left,)
    hb = _assume(core.left, ctx)
    om = _and_l(hb)
    mw = _and_r(hb)
    ap = _weaken(add_hidden_pf, ctx)
    ap = _forall_elim(_forall_elim(ap, 'w'), 'm')
    exA = _imp_elim(ap, hb)
    assert isinstance(exA.conclusion, Exists)
    A = 'Amh'
    iA = substitute(exA.conclusion.body, exA.conclusion.var, V(A))
    ctxA = ctx + (iA,)
    hAh = _assume(iA, ctxA)
    exG = hAh
    assert isinstance(exG.conclusion, Exists)
    G = 'Gmh'
    iG = substitute(exG.conclusion.body, exG.conclusion.var, V(G))
    ctxG = ctxA + (iG,)
    addCand = _assume(iG, ctxG)
    hSucc = _and_l(addCand)
    addRec = _and_r(addCand)
    ex0 = _and_l(_and_l(_weaken(om, ctxG)))
    assert isinstance(ex0.conclusion, Exists)
    Z = 'Zmh'
    iZ = substitute(ex0.conclusion.body, ex0.conclusion.var, V(Z))
    ctxZ = ctxG + (iZ,)
    hZ = _assume(iZ, ctxZ)
    Zw = _and_l(hZ)
    emptyZ = _and_r(hZ)
    mp = _weaken(mul_mod_pf, ctxZ)
    for nm in ['w', 'm', G, A, Z]:
        mp = _forall_elim(mp, nm)
    ante = mp.conclusion.left
    t4 = Proof('and_intro', ante.right.right.right.right, ctxZ, (_weaken(emptyZ, ctxZ), _weaken(Zw, ctxZ)))
    t3 = Proof('and_intro', ante.right.right.right, ctxZ, (_weaken(addRec, ctxZ), t4))
    t2 = Proof('and_intro', ante.right.right, ctxZ, (_weaken(hSucc, ctxZ), t3))
    t1 = Proof('and_intro', ante.right, ctxZ, (_weaken(mw, ctxZ), t2))
    aa = Proof('and_intro', ante, ctxZ, (_weaken(om, ctxZ), t1))
    exM = _imp_elim(mp, aa)
    assert isinstance(exM.conclusion, Exists)
    M = 'Fmh'
    iM = substitute(exM.conclusion.body, exM.conclusion.var, V(M))
    ctxM = ctxZ + (iM,)
    hMpack = _assume(iM, ctxM)
    mulRec = _and_l(hMpack)
    hidden = MulSectionHidden(V(M), V('w'), V('m'))
    q = hidden.body
    qG = substitute(q, hidden.var, V(G))
    qA = substitute(qG.body, qG.var, V(A))
    qZ = substitute(qA.body, qA.var, V(Z))
    body = qZ
    b4 = Proof('and_intro', body.right.right.right, ctxM, (_weaken(Zw, ctxM), mulRec))
    b3 = Proof('and_intro', body.right.right, ctxM, (_weaken(emptyZ, ctxM), b4))
    b2 = Proof('and_intro', body.right, ctxM, (_weaken(addRec, ctxM), b3))
    ball = Proof('and_intro', body, ctxM, (_weaken(hSucc, ctxM), b2))
    ez = Proof('exists_intro', qA, ctxM, (ball,), (('term', {'var': Z}),))
    ea = Proof('exists_intro', qG, ctxM, (ez,), (('term', {'var': A}),))
    eg = Proof('exists_intro', hidden, ctxM, (ea,), (('term', {'var': G}),))
    tf = substitute(core.right.body, core.right.var, V(M))
    em = Proof('exists_intro', core.right, ctxM, (eg,), (('term', {'var': M}),))
    aM = Proof('exists_elim', core.right, ctxZ, (exM, em), (('eigenvar', M),))
    aZ = Proof('exists_elim', core.right, ctxG, (ex0, aM), (('eigenvar', Z),))
    aG = Proof('exists_elim', core.right, ctxA, (exG, aZ), (('eigenvar', G),))
    aA = Proof('exists_elim', core.right, ctx, (exA, aG), (('eigenvar', A),))
    ip = Proof('imp_intro', core, (), (aA,))
    qm = Proof('forall_intro', goal.body, (), (ip,))
    return Proof('forall_intro', goal, (), (qm,))

def build_exp_section_hidden_exists(mul_hidden_pf: Proof | None=None, exp_mod_pf: Proof | None=None) -> Proof:
    mul_hidden_pf = mul_hidden_pf or build_mul_section_hidden_exists()
    exp_mod_pf = exp_mod_pf or build_exponentiation_from_multiplication()
    goal = section_exists_formula(ExpSectionHidden)
    core = goal.body.body
    ctx = (core.left,)
    hb = _assume(core.left, ctx)
    om = _and_l(hb)
    mw = _and_r(hb)
    mp = _weaken(mul_hidden_pf, ctx)
    mp = _forall_elim(_forall_elim(mp, 'w'), 'm')
    exM = _imp_elim(mp, hb)
    assert isinstance(exM.conclusion, Exists)
    M = 'Meh'
    iM = substitute(exM.conclusion.body, exM.conclusion.var, V(M))
    ctxM = ctx + (iM,)
    hMh = _assume(iM, ctxM)
    exG = hMh
    G = 'Geh'
    iG = substitute(exG.conclusion.body, exG.conclusion.var, V(G))
    ctxG = ctxM + (iG,)
    hG = _assume(iG, ctxG)
    exA = hG
    A = 'Aeh'
    iA = substitute(exA.conclusion.body, exA.conclusion.var, V(A))
    ctxA = ctxG + (iA,)
    hA = _assume(iA, ctxA)
    exZ = hA
    Z = 'Zeh'
    iZ = substitute(exZ.conclusion.body, exZ.conclusion.var, V(Z))
    ctxZ = ctxA + (iZ,)
    pack = _assume(iZ, ctxZ)
    hSucc = _and_l(pack)
    r1 = _and_r(pack)
    addRec = _and_l(r1)
    r2 = _and_r(r1)
    emptyZ = _and_l(r2)
    r3 = _and_r(r2)
    Zw = _and_l(r3)
    mulRec = _and_r(r3)
    closed = _and_r(_and_l(_weaken(om, ctxZ)))
    q1 = _forall_elim(closed, Z)
    exO = _imp_elim(q1, Zw)
    assert isinstance(exO.conclusion, Exists)
    O = 'Oeh'
    iO = substitute(exO.conclusion.body, exO.conclusion.var, V(O))
    ctxO = ctxZ + (iO,)
    hO = _assume(iO, ctxO)
    Ow = _and_l(hO)
    succO = _and_r(hO)
    ep = _weaken(exp_mod_pf, ctxO)
    for nm in ['w', 'm', G, A, Z, M, O]:
        ep = _forall_elim(ep, nm)
    ante = ep.conclusion.left
    tail6 = Proof('and_intro', ante.right.right.right.right.right.right, ctxO, (_weaken(succO, ctxO), _weaken(Ow, ctxO)))
    tail5 = Proof('and_intro', ante.right.right.right.right.right, ctxO, (_weaken(mulRec, ctxO), tail6))
    tail4 = Proof('and_intro', ante.right.right.right.right, ctxO, (_weaken(Zw, ctxO), tail5))
    tail3 = Proof('and_intro', ante.right.right.right, ctxO, (_weaken(emptyZ, ctxO), tail4))
    tail2 = Proof('and_intro', ante.right.right, ctxO, (_weaken(addRec, ctxO), tail3))
    tail1 = Proof('and_intro', ante.right, ctxO, (_weaken(mw, ctxO), Proof('and_intro', ante.right.right, ctxO, (_weaken(hSucc, ctxO), tail2)))) if False else None
    n7 = Proof('and_intro', ante.right.right.right.right.right.right.right, ctxO, (_weaken(succO, ctxO), _weaken(Ow, ctxO)))
    n6 = Proof('and_intro', ante.right.right.right.right.right.right, ctxO, (_weaken(mulRec, ctxO), n7))
    n5 = Proof('and_intro', ante.right.right.right.right.right, ctxO, (_weaken(Zw, ctxO), n6))
    n4 = Proof('and_intro', ante.right.right.right.right, ctxO, (_weaken(emptyZ, ctxO), n5))
    n3 = Proof('and_intro', ante.right.right.right, ctxO, (_weaken(addRec, ctxO), n4))
    n2 = Proof('and_intro', ante.right.right, ctxO, (_weaken(hSucc, ctxO), n3))
    n1 = Proof('and_intro', ante.right, ctxO, (_weaken(mw, ctxO), n2))
    allp = Proof('and_intro', ante, ctxO, (_weaken(om, ctxO), n1))
    exE = _imp_elim(ep, allp)
    assert isinstance(exE.conclusion, Exists)
    E = 'Feh'
    iE = substitute(exE.conclusion.body, exE.conclusion.var, V(E))
    ctxE = ctxO + (iE,)
    hEpack = _assume(iE, ctxE)
    expRec = _and_l(hEpack)
    hidden = ExpSectionHidden(V(E), V('w'), V('m'))
    q = hidden.body
    qG = substitute(q, hidden.var, V(G))
    qA = substitute(qG.body, qG.var, V(A))
    qZ = substitute(qA.body, qA.var, V(Z))
    qM = substitute(qZ.body, qZ.var, V(M))
    qO = substitute(qM.body, qM.var, V(O))
    body = qO
    b7 = Proof('and_intro', body.right.right.right.right.right.right, ctxE, (_weaken(Ow, ctxE), expRec))
    b6 = Proof('and_intro', body.right.right.right.right.right, ctxE, (_weaken(succO, ctxE), b7))
    b5 = Proof('and_intro', body.right.right.right.right, ctxE, (_weaken(mulRec, ctxE), b6))
    b4 = Proof('and_intro', body.right.right.right, ctxE, (_weaken(Zw, ctxE), b5))
    b3 = Proof('and_intro', body.right.right, ctxE, (_weaken(emptyZ, ctxE), b4))
    b2 = Proof('and_intro', body.right, ctxE, (_weaken(addRec, ctxE), b3))
    ball = Proof('and_intro', body, ctxE, (_weaken(hSucc, ctxE), b2))
    eO = Proof('exists_intro', qM, ctxE, (ball,), (('term', {'var': O}),))
    eM = Proof('exists_intro', qZ, ctxE, (eO,), (('term', {'var': M}),))
    eZ = Proof('exists_intro', qA, ctxE, (eM,), (('term', {'var': Z}),))
    eA = Proof('exists_intro', qG, ctxE, (eZ,), (('term', {'var': A}),))
    eG = Proof('exists_intro', hidden, ctxE, (eA,), (('term', {'var': G}),))
    ef = Proof('exists_intro', core.right, ctxE, (eG,), (('term', {'var': E}),))
    aE = Proof('exists_elim', core.right, ctxO, (exE, ef), (('eigenvar', E),))
    aO = Proof('exists_elim', core.right, ctxZ, (exO, aE), (('eigenvar', O),))
    aZ = Proof('exists_elim', core.right, ctxA, (exZ, aO), (('eigenvar', Z),))
    aA = Proof('exists_elim', core.right, ctxG, (exA, aZ), (('eigenvar', A),))
    aG = Proof('exists_elim', core.right, ctxM, (exG, aA), (('eigenvar', G),))
    aM = Proof('exists_elim', core.right, ctx, (exM, aG), (('eigenvar', M),))
    ip = Proof('imp_intro', core, (), (aM,))
    qm = Proof('forall_intro', goal.body, (), (ip,))
    return Proof('forall_intro', goal, (), (qm,))

def multiplication_section_canonical_formula() -> Formula:
    om = OmegaSpec(V('w'), 'j', 'k')
    mw = Mem(V('m'), V('w'))

    def pack(g, a, z, f, sfx):
        add = RecursionCandidateSpec(V(a), V('w'), V('w'), V('m'), V(g), f'za{sfx}', f'na{sfx}', f'sa{sfx}', f'xa{sfx}', f'ya{sfx}')
        mul = RecursionCandidateSpec(V(f), V('w'), V('w'), V(z), V(a), f'zm{sfx}', f'nm{sfx}', f'sm{sfx}', f'xm{sfx}', f'ym{sfx}')
        return And(SuccessorFunctionSpec(V(g), V('w'), f'sx{sfx}', f'sy{sfx}'), And(add, And(EmptySpec(V(z), f'ez{sfx}'), And(Mem(V(z), V('w')), mul))))
    prem = And(om, And(mw, And(pack('g', 'a', 'z', 'f', '1'), pack('g2', 'a2', 'z2', 'h', '2'))))
    return Forall('w', Forall('m', Forall('g', Forall('a', Forall('z', Forall('f', Forall('g2', Forall('a2', Forall('z2', Forall('h', Imp(prem, Eq(V('f'), V('h')))))))))))))

def build_multiplication_section_canonical(addcanon: Proof | None=None, emptyuniq: Proof | None=None, recuniq: Proof | None=None) -> Proof:
    addcanon = addcanon or build_addition_section_canonical()
    emptyuniq = emptyuniq or build_empty_unique()
    recuniq = recuniq or build_omega_recursion_uniqueness()
    goal = multiplication_section_canonical_formula()
    q = goal
    for _ in range(10):
        q = q.body
    core = q
    ctx = (core.left,)
    hp = _assume(core.left, ctx)
    om = _and_l(hp)
    r1 = _and_r(hp)
    mw = _and_l(r1)
    both = _and_r(r1)
    p1 = _and_l(both)
    p2 = _and_r(both)
    sg1 = _and_l(p1)
    t1 = _and_r(p1)
    add1 = _and_l(t1)
    u1 = _and_r(t1)
    emp1 = _and_l(u1)
    v1 = _and_r(u1)
    z1w = _and_l(v1)
    mul1 = _and_r(v1)
    sg2 = _and_l(p2)
    t2 = _and_r(p2)
    add2 = _and_l(t2)
    u2 = _and_r(t2)
    emp2 = _and_l(u2)
    v2 = _and_r(u2)
    z2w = _and_l(v2)
    mul2 = _and_r(v2)
    ac = _weaken(addcanon, ctx)
    for nm in ['w', 'm', 'g', 'a', 'g2', 'a2']:
        ac = _forall_elim(ac, nm)
    ap = ac.conclusion.left
    ar4 = Proof('and_intro', ap.right.right.right.right, ctx, (sg2, add2))
    ar3 = Proof('and_intro', ap.right.right.right, ctx, (add1, ar4))
    ar2 = Proof('and_intro', ap.right.right, ctx, (sg1, ar3))
    ar1 = Proof('and_intro', ap.right, ctx, (mw, ar2))
    aall = Proof('and_intro', ap, ctx, (om, ar1))
    eqa = _imp_elim(ac, aall)
    eu = _weaken(emptyuniq, ctx)
    eu = _forall_elim(_forall_elim(eu, 'z'), 'z2')
    ep = eu.conclusion.left
    eqz = _imp_elim(eu, Proof('and_intro', ep, ctx, (emp1, emp2)))
    mul2a = Proof('eq_subst', substitute(mul2.conclusion, 'a2', V('a')), ctx, (eqa, mul2), (('direction', 'rl'),))
    mul2az = Proof('eq_subst', substitute(mul2a.conclusion, 'z2', V('z')), ctx, (eqz, mul2a), (('direction', 'rl'),))
    ru = _weaken(recuniq, ctx)
    for nm in ['w', 'w', 'z', 'a', 'f', 'h']:
        ru = _forall_elim(ru, nm)
    rp = ru.conclusion.left
    addfun = _and_l(add1)
    tail = Proof('and_intro', rp.right.right.right, ctx, (mul1, mul2az))
    mid = Proof('and_intro', rp.right.right, ctx, (addfun, tail))
    rr = Proof('and_intro', rp.right, ctx, (z1w, mid))
    aa = Proof('and_intro', rp, ctx, (om, rr))
    eq = _imp_elim(ru, aa)
    p = Proof('imp_intro', core, (), (eq,))
    bodies = []
    zf = goal
    while isinstance(zf, Forall):
        bodies.append(zf)
        zf = zf.body
    for b in reversed(bodies):
        p = Proof('forall_intro', b, (), (p,))
    return p

def exponentiation_section_canonical_formula() -> Formula:
    om = OmegaSpec(V('w'), 'j', 'k')
    mw = Mem(V('m'), V('w'))

    def pack(g, a, z, mul, one, exp, sfx):
        add = RecursionCandidateSpec(V(a), V('w'), V('w'), V('m'), V(g), f'za{sfx}', f'na{sfx}', f'sa{sfx}', f'xa{sfx}', f'ya{sfx}')
        mu = RecursionCandidateSpec(V(mul), V('w'), V('w'), V(z), V(a), f'zm{sfx}', f'nm{sfx}', f'sm{sfx}', f'xm{sfx}', f'ym{sfx}')
        ex = RecursionCandidateSpec(V(exp), V('w'), V('w'), V(one), V(mul), f'ze{sfx}', f'ne{sfx}', f'se{sfx}', f'xe{sfx}', f'ye{sfx}')
        return And(SuccessorFunctionSpec(V(g), V('w'), f'sx{sfx}', f'sy{sfx}'), And(add, And(EmptySpec(V(z), f'ez{sfx}'), And(Mem(V(z), V('w')), And(mu, And(SuccessorSpec(V(one), V(z), f'uo{sfx}'), And(Mem(V(one), V('w')), ex)))))))
    prem = And(om, And(mw, And(pack('g', 'a', 'z', 'u', 'o', 'f', '1'), pack('g2', 'a2', 'z2', 'u2', 'o2', 'h', '2'))))
    names = ['w', 'm', 'g', 'a', 'z', 'u', 'o', 'f', 'g2', 'a2', 'z2', 'u2', 'o2', 'h']
    core = Imp(prem, Eq(V('f'), V('h')))
    for nm in reversed(names):
        core = Forall(nm, core)
    return core

def build_exponentiation_section_canonical(mulcanon: Proof | None=None, emptyuniq: Proof | None=None, succuniq: Proof | None=None, recuniq: Proof | None=None) -> Proof:
    mulcanon = mulcanon or build_multiplication_section_canonical()
    emptyuniq = emptyuniq or build_empty_unique()
    succuniq = succuniq or build_successor_unique()
    recuniq = recuniq or build_omega_recursion_uniqueness()
    goal = exponentiation_section_canonical_formula()
    q = goal
    for _ in range(14):
        q = q.body
    core = q
    ctx = (core.left,)
    hp = _assume(core.left, ctx)
    om = _and_l(hp)
    r1 = _and_r(hp)
    mw = _and_l(r1)
    both = _and_r(r1)
    p1 = _and_l(both)
    p2 = _and_r(both)

    def unpack(p):
        sg = _and_l(p)
        t = _and_r(p)
        add = _and_l(t)
        u = _and_r(t)
        emp = _and_l(u)
        v = _and_r(u)
        zw = _and_l(v)
        v2 = _and_r(v)
        mul = _and_l(v2)
        v3 = _and_r(v2)
        su = _and_l(v3)
        v4 = _and_r(v3)
        ow = _and_l(v4)
        exp = _and_r(v4)
        return (sg, add, emp, zw, mul, su, ow, exp)
    sg1, add1, emp1, z1w, mul1, su1, o1w, exp1 = unpack(p1)
    sg2, add2, emp2, z2w, mul2, su2, o2w, exp2 = unpack(p2)
    mc = _weaken(mulcanon, ctx)
    for nm in ['w', 'm', 'g', 'a', 'z', 'u', 'g2', 'a2', 'z2', 'u2']:
        mc = _forall_elim(mc, nm)
    mp = mc.conclusion.left
    pack1 = And(sg1.conclusion, And(add1.conclusion, And(emp1.conclusion, And(z1w.conclusion, mul1.conclusion))))
    pp1 = Proof('and_intro', pack1, ctx, (sg1, Proof('and_intro', pack1.right, ctx, (add1, Proof('and_intro', pack1.right.right, ctx, (emp1, Proof('and_intro', pack1.right.right.right, ctx, (z1w, mul1))))))))
    pack2 = And(sg2.conclusion, And(add2.conclusion, And(emp2.conclusion, And(z2w.conclusion, mul2.conclusion))))
    pp2 = Proof('and_intro', pack2, ctx, (sg2, Proof('and_intro', pack2.right, ctx, (add2, Proof('and_intro', pack2.right.right, ctx, (emp2, Proof('and_intro', pack2.right.right.right, ctx, (z2w, mul2))))))))
    mb = Proof('and_intro', mp.right.right, ctx, (pp1, pp2))
    mr = Proof('and_intro', mp.right, ctx, (mw, mb))
    mall = Proof('and_intro', mp, ctx, (om, mr))
    equ = _imp_elim(mc, mall)
    eu = _weaken(emptyuniq, ctx)
    eu = _forall_elim(_forall_elim(eu, 'z'), 'z2')
    eqz = _imp_elim(eu, Proof('and_intro', eu.conclusion.left, ctx, (emp1, emp2)))
    su2z = Proof('eq_subst', substitute(su2.conclusion, 'z2', V('z')), ctx, (eqz, su2), (('direction', 'rl'),))
    squ = _weaken(succuniq, ctx)
    for nm in ['z', 'o', 'o2']:
        squ = _forall_elim(squ, nm)
    eqo = _imp_elim(squ, Proof('and_intro', squ.conclusion.left, ctx, (su1, su2z)))
    exp2u = Proof('eq_subst', substitute(exp2.conclusion, 'u2', V('u')), ctx, (equ, exp2), (('direction', 'rl'),))
    exp2uo = Proof('eq_subst', substitute(exp2u.conclusion, 'o2', V('o')), ctx, (eqo, exp2u), (('direction', 'rl'),))
    ru = _weaken(recuniq, ctx)
    for nm in ['w', 'w', 'o', 'u', 'f', 'h']:
        ru = _forall_elim(ru, nm)
    rp = ru.conclusion.left
    mulfun = _and_l(mul1)
    tail = Proof('and_intro', rp.right.right.right, ctx, (exp1, exp2uo))
    mid = Proof('and_intro', rp.right.right, ctx, (mulfun, tail))
    rr = Proof('and_intro', rp.right, ctx, (o1w, mid))
    aa = Proof('and_intro', rp, ctx, (om, rr))
    eq = _imp_elim(ru, aa)
    p = Proof('imp_intro', core, (), (eq,))
    bodies = []
    zf = goal
    while isinstance(zf, Forall):
        bodies.append(zf)
        zf = zf.body
    for b in reversed(bodies):
        p = Proof('forall_intro', b, (), (p,))
    return p

def section_hidden_unique_formula(hidden) -> Formula:
    prem = And(OmegaSpec(V('w'), 'j', 'k'), And(Mem(V('m'), V('w')), And(hidden(V('f'), V('w'), V('m')), hidden(V('h'), V('w'), V('m')))))
    return Forall('w', Forall('m', Forall('f', Forall('h', Imp(prem, Eq(V('f'), V('h')))))))

def hidden_function_projection_formula(hidden) -> Formula:
    return Forall('w', Forall('m', Forall('f', Imp(hidden(V('f'), V('w'), V('m')), FunctionGraphSpec(V('f'), V('w'), V('w'), 'p', 'x', 'y', 'y2')))))

def SectionValueSpec(hidden, w: Term, m: Term, n: Term, y: Term) -> Formula:
    return Exists('fs', And(hidden(V('fs'), w, m), GraphValueSpec(V('fs'), n, y, 'pg')))

def section_value_total_formula(hidden) -> Formula:
    ante = And(OmegaSpec(V('w'), 'j', 'k'), And(Mem(V('m'), V('w')), Mem(V('n'), V('w'))))
    return Forall('w', Forall('m', Forall('n', Imp(ante, Exists('y', And(Mem(V('y'), V('w')), SectionValueSpec(hidden, V('w'), V('m'), V('n'), V('y'))))))))

def section_value_unique_formula(hidden) -> Formula:
    v1 = SectionValueSpec(hidden, V('w'), V('m'), V('n'), V('y'))
    v2 = SectionValueSpec(hidden, V('w'), V('m'), V('n'), V('y2'))
    ante = And(OmegaSpec(V('w'), 'j', 'k'), And(Mem(V('m'), V('w')), And(Mem(V('n'), V('w')), And(Mem(V('y'), V('w')), And(Mem(V('y2'), V('w')), And(v1, v2))))))
    return Forall('w', Forall('m', Forall('n', Forall('y', Forall('y2', Imp(ante, Eq(V('y'), V('y2'))))))))

def build_add_hidden_unique_from_canonical() -> Proof:
    can = addition_section_canonical_formula()
    goal = Imp(can, section_hidden_unique_formula(AddSectionHidden))
    ctx0 = (can,)
    hcan = _assume(can, ctx0)
    target = goal.right
    q = target
    for _ in range(4):
        q = q.body
    core = q
    ctx = ctx0 + (core.left,)
    hp = _assume(core.left, ctx)
    om = _and_l(hp)
    r1 = _and_r(hp)
    mw = _and_l(r1)
    hs = _and_r(r1)
    hf = _and_l(hs)
    hh = _and_r(hs)
    G = 'Gau'
    iG = substitute(hf.conclusion.body, hf.conclusion.var, V(G))
    ctxG = ctx + (iG,)
    cf = _assume(iG, ctxG)
    H = 'Gbu'
    hhw = _weaken(hh, ctxG)
    iH = substitute(hhw.conclusion.body, hhw.conclusion.var, V(H))
    ctxH = ctxG + (iH,)
    ch = _assume(iH, ctxH)
    ac = _weaken(hcan, ctxH)
    for nm in ['w', 'm', G, 'f', H, 'h']:
        ac = _forall_elim(ac, nm)
    ap = ac.conclusion.left
    t4 = Proof('and_intro', ap.right.right.right.right, ctxH, (_and_l(ch), _and_r(ch)))
    t3 = Proof('and_intro', ap.right.right.right, ctxH, (_weaken(_and_r(cf), ctxH), t4))
    t2 = Proof('and_intro', ap.right.right, ctxH, (_weaken(_and_l(cf), ctxH), t3))
    t1 = Proof('and_intro', ap.right, ctxH, (_weaken(mw, ctxH), t2))
    aa = Proof('and_intro', ap, ctxH, (_weaken(om, ctxH), t1))
    eq = _imp_elim(ac, aa)
    aH = Proof('exists_elim', Eq(V('f'), V('h')), ctxG, (hhw, eq), (('eigenvar', H),))
    aG = Proof('exists_elim', Eq(V('f'), V('h')), ctx, (hf, aH), (('eigenvar', G),))
    ip = Proof('imp_intro', core, ctx0, (aG,))
    p = ip
    forms = []
    z = target
    while isinstance(z, Forall):
        forms.append(z)
        z = z.body
    for b in reversed(forms):
        p = Proof('forall_intro', b, ctx0, (p,))
    return Proof('imp_intro', goal, (), (p,))

def _build_hidden_unique_from_canonical(hidden, canonical_formula: Formula, var_count: int, unpack_names: list[str], pack_builder) -> Proof:
    goal = Imp(canonical_formula, section_hidden_unique_formula(hidden))
    ctx0 = (canonical_formula,)
    hcan = _assume(canonical_formula, ctx0)
    target = goal.right
    q = target
    for _ in range(4):
        q = q.body
    core = q
    ctx = ctx0 + (core.left,)
    hp = _assume(core.left, ctx)
    om = _and_l(hp)
    r1 = _and_r(hp)
    mw = _and_l(r1)
    hs = _and_r(r1)
    hf = _and_l(hs)
    hh = _and_r(hs)

    def open_hidden(hproof, prefix, ctxbase, names):
        ex = hproof
        curctx = ctxbase
        vals = []
        for nm in names:
            inst = substitute(ex.conclusion.body, ex.conclusion.var, V(prefix + nm))
            nctx = curctx + (inst,)
            ass = _assume(inst, nctx)
            vals.append((ex, prefix + nm, curctx, nctx, ass))
            ex = ass
            curctx = nctx
        return (vals, ex, curctx)
    v1, b1, c1 = open_hidden(hf, 'A', ctx, unpack_names)
    hhw = _weaken(hh, c1)
    v2, b2, c2 = open_hidden(hhw, 'B', c1, unpack_names)
    can = _weaken(hcan, c2)
    inst_names = pack_builder([x[1] for x in v1], [x[1] for x in v2])
    for nm in inst_names:
        can = _forall_elim(can, nm)
    ante = can.conclusion.left
    p1 = b1
    p2 = b2
    both = Proof('and_intro', ante.right.right, c2, (_weaken(p1, c2), p2))
    rest = Proof('and_intro', ante.right, c2, (_weaken(mw, c2), both))
    allp = Proof('and_intro', ante, c2, (_weaken(om, c2), rest))
    eq = _imp_elim(can, allp)
    result = eq
    for ex, nm, bc, nc, ass in reversed(v2):
        result = Proof('exists_elim', Eq(V('f'), V('h')), bc, (ex, result), (('eigenvar', nm),))
    for ex, nm, bc, nc, ass in reversed(v1):
        result = Proof('exists_elim', Eq(V('f'), V('h')), bc, (ex, result), (('eigenvar', nm),))
    ip = Proof('imp_intro', core, ctx0, (result,))
    p = ip
    forms = []
    z = target
    while isinstance(z, Forall):
        forms.append(z)
        z = z.body
    for b in reversed(forms):
        p = Proof('forall_intro', b, ctx0, (p,))
    return Proof('imp_intro', goal, (), (p,))

def build_mul_hidden_unique_from_canonical() -> Proof:
    return _build_hidden_unique_from_canonical(MulSectionHidden, multiplication_section_canonical_formula(), 10, ['g', 'a', 'z'], lambda a, b: ['w', 'm', a[0], a[1], a[2], 'f', b[0], b[1], b[2], 'h'])

def build_exp_hidden_unique_from_canonical() -> Proof:
    return _build_hidden_unique_from_canonical(ExpSectionHidden, exponentiation_section_canonical_formula(), 14, ['g', 'a', 'z', 'u', 'o'], lambda a, b: ['w', 'm', a[0], a[1], a[2], a[3], a[4], 'f', b[0], b[1], b[2], b[3], b[4], 'h'])

def build_hidden_function_projection(hidden, kind: str) -> Proof:
    goal = hidden_function_projection_formula(hidden)
    q = goal
    for _ in range(3):
        q = q.body
    core = q
    ctx = (core.left,)
    hh = _assume(core.left, ctx)
    if kind == 'add':
        names = ['G']
    elif kind == 'mul':
        names = ['G', 'A', 'Z']
    else:
        names = ['G', 'A', 'Z', 'M', 'O']
    ex = hh
    curctx = ctx
    chain = []
    for nm in names:
        inst = substitute(ex.conclusion.body, ex.conclusion.var, V(nm + 'proj'))
        nctx = curctx + (inst,)
        ass = _assume(inst, nctx)
        chain.append((ex, nm + 'proj', curctx, nctx))
        ex = ass
        curctx = nctx
    body = ex
    if kind == 'add':
        rec = _and_r(body)
    elif kind == 'mul':
        rec = _and_r(_and_r(_and_r(_and_r(body))))
    else:
        rec = _and_r(_and_r(_and_r(_and_r(_and_r(_and_r(_and_r(body)))))))
    fun = _and_l(rec)
    result = fun
    for ex0, nm, bc, nc in reversed(chain):
        result = Proof('exists_elim', core.right, bc, (ex0, result), (('eigenvar', nm),))
    ip = Proof('imp_intro', core, (), (result,))
    p = ip
    forms = []
    z = goal
    while isinstance(z, Forall):
        forms.append(z)
        z = z.body
    for b in reversed(forms):
        p = Proof('forall_intro', b, (), (p,))
    return p

def build_value_total_from_interfaces(hidden) -> Proof:
    E = section_exists_formula(hidden)
    P = hidden_function_projection_formula(hidden)
    goal = Imp(And(E, P), section_value_total_formula(hidden))
    ctx0 = (goal.left,)
    hp = _assume(goal.left, ctx0)
    hE = _and_l(hp)
    hP = _and_r(hp)
    target = goal.right
    q = target
    for _ in range(3):
        q = q.body
    core = q
    ctx = ctx0 + (core.left,)
    hb = _assume(core.left, ctx)
    om = _and_l(hb)
    rr = _and_r(hb)
    mw = _and_l(rr)
    nw = _and_r(rr)
    se = _weaken(hE, ctx)
    se = _forall_elim(_forall_elim(se, 'w'), 'm')
    ante = se.conclusion.left
    ab = Proof('and_intro', ante, ctx, (_weaken(om, ctx), _weaken(mw, ctx)))
    exf = _imp_elim(se, ab)
    assert isinstance(exf.conclusion, Exists)
    F = 'Fvt'
    iF = substitute(exf.conclusion.body, exf.conclusion.var, V(F))
    ctxF = ctx + (iF,)
    hHidden = _assume(iF, ctxF)
    pp = _weaken(hP, ctxF)
    pp = _forall_elim(_forall_elim(_forall_elim(pp, 'w'), 'm'), F)
    fun = _imp_elim(pp, hHidden)
    total = _and_l(_and_r(fun))
    qt = _forall_elim(total, 'n')
    exy = _imp_elim(qt, _weaken(nw, ctxF))
    assert isinstance(exy.conclusion, Exists)
    Y = 'Yvt'
    iY = substitute(exy.conclusion.body, exy.conclusion.var, V(Y))
    ctxY = ctxF + (iY,)
    hy = _assume(iY, ctxY)
    yw = _and_l(hy)
    gv = _and_r(hy)
    val = SectionValueSpec(hidden, V('w'), V('m'), V('n'), V(Y))
    iv = substitute(val.body, val.var, V(F))
    cv = Proof('and_intro', iv, ctxY, (_weaken(hHidden, ctxY), gv))
    ev = Proof('exists_intro', val, ctxY, (cv,), (('term', {'var': F}),))
    outbody = substitute(core.right.body, core.right.var, V(Y))
    co = Proof('and_intro', outbody, ctxY, (yw, ev))
    ey = Proof('exists_intro', core.right, ctxY, (co,), (('term', {'var': Y}),))
    ay = Proof('exists_elim', core.right, ctxF, (exy, ey), (('eigenvar', Y),))
    af = Proof('exists_elim', core.right, ctx, (exf, ay), (('eigenvar', F),))
    ip = Proof('imp_intro', core, ctx0, (af,))
    p = ip
    forms = []
    z = target
    while isinstance(z, Forall):
        forms.append(z)
        z = z.body
    for b in reversed(forms):
        p = Proof('forall_intro', b, ctx0, (p,))
    return Proof('imp_intro', goal, (), (p,))

def build_value_unique_from_interfaces(hidden) -> Proof:
    U = section_hidden_unique_formula(hidden)
    P = hidden_function_projection_formula(hidden)
    goal = Imp(And(U, P), section_value_unique_formula(hidden))
    ctx0 = (goal.left,)
    hp = _assume(goal.left, ctx0)
    hU = _and_l(hp)
    hP = _and_r(hp)
    target = goal.right
    q = target
    for _ in range(5):
        q = q.body
    core = q
    ctx = ctx0 + (core.left,)
    hb = _assume(core.left, ctx)
    om = _and_l(hb)
    r1 = _and_r(hb)
    mw = _and_l(r1)
    r2 = _and_r(r1)
    nw = _and_l(r2)
    r3 = _and_r(r2)
    yw = _and_l(r3)
    r4 = _and_r(r3)
    y2w = _and_l(r4)
    vals = _and_r(r4)
    v1 = _and_l(vals)
    v2 = _and_r(vals)
    F = 'Fvu'
    iF = substitute(v1.conclusion.body, v1.conclusion.var, V(F))
    ctxF = ctx + (iF,)
    h1 = _assume(iF, ctxF)
    hf = _and_l(h1)
    gv1 = _and_r(h1)
    H = 'Hvu'
    v2w = _weaken(v2, ctxF)
    iH = substitute(v2w.conclusion.body, v2w.conclusion.var, V(H))
    ctxH = ctxF + (iH,)
    h2 = _assume(iH, ctxH)
    hh = _and_l(h2)
    gv2 = _and_r(h2)
    uq = _weaken(hU, ctxH)
    for nm in ['w', 'm', F, H]:
        uq = _forall_elim(uq, nm)
    ua = uq.conclusion.left
    ub = Proof('and_intro', ua.right.right, ctxH, (_weaken(hf, ctxH), hh))
    ur = Proof('and_intro', ua.right, ctxH, (_weaken(mw, ctxH), ub))
    uall = Proof('and_intro', ua, ctxH, (_weaken(om, ctxH), ur))
    eqfh = _imp_elim(uq, uall)
    gv2f = Proof('eq_subst', substitute(gv2.conclusion, H, V(F)), ctxH, (eqfh, gv2), (('direction', 'rl'),))
    pp = _weaken(hP, ctxH)
    pp = _forall_elim(_forall_elim(_forall_elim(pp, 'w'), 'm'), F)
    fun = _imp_elim(pp, _weaken(hf, ctxH))
    eqyy = _function_unique_instance(fun, 'n', 'y', 'y2', _weaken(nw, ctxH), _weaken(yw, ctxH), _weaken(y2w, ctxH), _weaken(gv1, ctxH), gv2f, ctxH)
    aH = Proof('exists_elim', Eq(V('y'), V('y2')), ctxF, (v2w, eqyy), (('eigenvar', H),))
    aF = Proof('exists_elim', Eq(V('y'), V('y2')), ctx, (v1, aH), (('eigenvar', F),))
    ip = Proof('imp_intro', core, ctx0, (aF,))
    p = ip
    forms = []
    z = target
    while isinstance(z, Forall):
        forms.append(z)
        z = z.body
    for b in reversed(forms):
        p = Proof('forall_intro', b, ctx0, (p,))
    return Proof('imp_intro', goal, (), (p,))

def BinaryGraphValueSpec(F: Term, m: Term, n: Term, y: Term) -> Formula:
    return Exists('mnv', And(OrderedPairCode(V('mnv'), m, n, 'ia', 'ib'), GraphValueSpec(F, V('mnv'), y, 'vp')))

def GlobalPairPredicate(p: Term, w: Term, hidden) -> Formula:
    body = And(Mem(V('mg'), w), And(Mem(V('ng'), w), And(Mem(V('yg'), w), And(OrderedPairCode(V('mng'), V('mg'), V('ng'), 'ma', 'mb'), And(OrderedPairCode(p, V('mng'), V('yg'), 'pa', 'pb'), SectionValueSpec(hidden, w, V('mg'), V('ng'), V('yg')))))))
    return Exists('mg', Exists('ng', Exists('yg', Exists('mng', body))))

def GlobalOperationSpec(F: Term, d: Term, w: Term, hidden) -> Formula:
    fun = FunctionGraphSpec(F, d, w, 'pf', 'xf', 'yf', 'yf2')
    mems = And(Mem(V('m'), w), And(Mem(V('n'), w), Mem(V('y'), w)))
    exact = Forall('m', Forall('n', Forall('y', Imp(mems, Iff(BinaryGraphValueSpec(F, V('m'), V('n'), V('y')), SectionValueSpec(hidden, w, V('m'), V('n'), V('y')))))))
    return And(fun, exact)

def global_operation_exists_formula(hidden) -> Formula:
    deps = And(section_value_total_formula(hidden), section_value_unique_formula(hidden))
    out = Forall('w', Imp(OmegaSpec(V('w'), 'j', 'k'), Exists('d', And(CartesianProductSpec(V('d'), V('w'), V('w'), 'pd'), Exists('F', GlobalOperationSpec(V('F'), V('d'), V('w'), hidden))))))
    return Imp(deps, out)
ADD_GLOBAL_SEPARATION_SCHEMA = SchemaInstance('SEPARATION', GlobalPairPredicate(V('p'), V('w'), AddSectionHidden), source_var='p', parameters=('w',))
MUL_GLOBAL_SEPARATION_SCHEMA = SchemaInstance('SEPARATION', GlobalPairPredicate(V('p'), V('w'), MulSectionHidden), source_var='p', parameters=('w',))
EXP_GLOBAL_SEPARATION_SCHEMA = SchemaInstance('SEPARATION', GlobalPairPredicate(V('p'), V('w'), ExpSectionHidden), source_var='p', parameters=('w',))
PASS010_SCHEMA_INSTANCES = tuple(PASS009_SCHEMA_INSTANCES) + (ADD_GLOBAL_SEPARATION_SCHEMA, MUL_GLOBAL_SEPARATION_SCHEMA, EXP_GLOBAL_SEPARATION_SCHEMA)

def _cart_member_from_components(cart: Proof, pair: str, x: str, y: str, xin: Proof, yin: Proof, op: Proof, ctx) -> Proof:
    q = _forall_elim(_weaken(cart, ctx), pair)
    pred = q.conclusion.right
    ix = substitute(pred.body, pred.var, V(x))
    ey = ix.right
    iy = substitute(ey.body, ey.var, V(y))
    cy = Proof('and_intro', iy, ctx, (_weaken(yin, ctx), _weaken(op, ctx)))
    eyy = Proof('exists_intro', ey, ctx, (cy,), (('term', {'var': y}),))
    cx = Proof('and_intro', ix, ctx, (_weaken(xin, ctx), eyy))
    exx = Proof('exists_intro', pred, ctx, (cx,), (('term', {'var': x}),))
    return _imp_elim(_iff_r(q), exx)

def _open_cart_member(cart: Proof, pair: str, pin: Proof, ctx, prefix: str):
    q = _forall_elim(_weaken(cart, ctx), pair)
    pred = _imp_elim(_iff_l(q), _weaken(pin, ctx))
    assert isinstance(pred.conclusion, Exists)
    X = prefix + 'x'
    ix = substitute(pred.conclusion.body, pred.conclusion.var, V(X))
    ctxX = ctx + (ix,)
    hx = _assume(ix, ctxX)
    xin = _and_l(hx)
    exy = _and_r(hx)
    assert isinstance(exy.conclusion, Exists)
    Y = prefix + 'y'
    iy = substitute(exy.conclusion.body, exy.conclusion.var, V(Y))
    ctxY = ctxX + (iy,)
    hy = _assume(iy, ctxY)
    yin = _and_l(hy)
    op = _and_r(hy)
    return (pred, X, ctxX, hx, exy, Y, ctxY, hy, xin, yin, op)

def _build_global_operation_exists(hidden, separation_schema: SchemaInstance, schema_index: int) -> Proof:
    goal = global_operation_exists_formula(hidden)
    deps = goal.left
    out = goal.right
    ctx0 = (deps,)
    hd = _assume(deps, ctx0)
    hVT = _and_l(hd)
    hVU = _and_r(hd)
    core = out.body
    ctx = (deps, core.left)
    hom = _assume(core.left, ctx)
    target = core.right
    cartpf = build_cartesian_product_exists(1)
    oppf = build_ordered_pair_code_exists()
    opinj = build_ordered_pair_injective()
    cp = _weaken(cartpf, ctx)
    cp = _forall_elim(_forall_elim(cp, 'w'), 'w')
    assert isinstance(cp.conclusion, Exists)
    D = 'Dglob'
    iD = substitute(cp.conclusion.body, cp.conclusion.var, V(D))
    ctxD = ctx + (iD,)
    hD = _assume(iD, ctxD)
    cb = _weaken(cartpf, ctxD)
    cb = _forall_elim(_forall_elim(cb, D), 'w')
    assert isinstance(cb.conclusion, Exists)
    B = 'Bglob'
    iB = substitute(cb.conclusion.body, cb.conclusion.var, V(B))
    ctxB = ctxD + (iB,)
    hB = _assume(iB, ctxB)
    ax = Proof('axiom_schema', separation_schema.generated(), ctxB, (), (('schema_index', schema_index),))
    sq = _forall_elim(_forall_elim(ax, 'w'), B)
    assert isinstance(sq.conclusion, Exists)
    F = 'Fglob'
    iF = substitute(sq.conclusion.body, sq.conclusion.var, V(F))
    ctxF = ctxB + (iF,)
    hSep = _assume(iF, ctxF)
    spec = GlobalOperationSpec(V(F), V(D), V('w'), hidden)
    fun = spec.left
    exact = spec.right
    m, n, y = (exact.var, exact.body.var, exact.body.body.var)
    ie = exact.body.body.body
    ctxE = ctxF + (ie.left,)
    hmem = _assume(ie.left, ctxE)
    mw = _and_l(hmem)
    rr = _and_r(hmem)
    nw = _and_l(rr)
    yw = _and_r(rr)
    bgv = ie.right.left
    sval = ie.right.right
    ctxL = ctxE + (bgv,)
    hbg = _assume(bgv, ctxL)
    MN = 'MNex'
    iMN = substitute(hbg.conclusion.body, hbg.conclusion.var, V(MN))
    ctxMN = ctxL + (iMN,)
    hMN = _assume(iMN, ctxMN)
    opMN = _and_l(hMN)
    gv = _and_r(hMN)
    P = 'Pex'
    iP = substitute(gv.conclusion.body, gv.conclusion.var, V(P))
    ctxP = ctxMN + (iP,)
    hP = _assume(iP, ctxP)
    Pin = _and_l(hP)
    opP = _and_r(hP)
    sepP = _forall_elim(_weaken(hSep, ctxP), P)
    sepR = _imp_elim(_iff_l(sepP), Pin)
    predP = _and_r(sepR)
    ex = predP
    names = ['M2', 'N2', 'Y2', 'MN2']
    chain = []
    ccur = ctxP
    for nm0 in names:
        inst = substitute(ex.conclusion.body, ex.conclusion.var, V(nm0))
        nc = ccur + (inst,)
        ha = _assume(inst, nc)
        chain.append((ex, nm0, ccur, nc))
        ex = ha
        ccur = nc
    body = ex
    m2w = _and_l(body)
    t = _and_r(body)
    n2w = _and_l(t)
    t = _and_r(t)
    y2w = _and_l(t)
    t = _and_r(t)
    opMN2 = _and_l(t)
    last = _and_r(t)
    opP2 = _and_l(last)
    sv2 = _and_r(last)
    inj1 = _op_injective_instance(_weaken(opinj, ccur), P, MN, y, 'MN2', 'Y2', _weaken(opP, ccur), opP2, ccur)
    eqMN = _and_l(inj1)
    eqY = _and_r(inj1)
    opMN2a = Proof('eq_subst', substitute(opMN2.conclusion, 'MN2', V(MN)), ccur, (eqMN, opMN2), (('direction', 'rl'),))
    inj2 = _op_injective_instance(_weaken(opinj, ccur), MN, m, n, 'M2', 'N2', _weaken(opMN, ccur), opMN2a, ccur)
    eqM = _and_l(inj2)
    eqN = _and_r(inj2)
    sv = sv2
    sv = Proof('eq_subst', substitute(sv.conclusion, 'M2', V(m)), ccur, (eqM, sv), (('direction', 'rl'),))
    sv = Proof('eq_subst', substitute(sv.conclusion, 'N2', V(n)), ccur, (eqN, sv), (('direction', 'rl'),))
    sv = Proof('eq_subst', substitute(sv.conclusion, 'Y2', V(y)), ccur, (eqY, sv), (('direction', 'rl'),))
    fwd = sv
    for ex0, nm0, bc, nc in reversed(chain):
        fwd = Proof('exists_elim', sval, bc, (ex0, fwd), (('eigenvar', nm0),))
    fwd = Proof('exists_elim', sval, ctxMN, (gv, fwd), (('eigenvar', P),))
    fwd = Proof('exists_elim', sval, ctxL, (hbg, fwd), (('eigenvar', MN),))
    fimp = Proof('imp_intro', Imp(bgv, sval), ctxE, (fwd,))
    ctxR = ctxE + (sval,)
    hsv = _assume(sval, ctxR)
    opmn = _weaken(oppf, ctxR)
    opmn = _forall_elim(_forall_elim(opmn, m), n)
    assert isinstance(opmn.conclusion, Exists)
    MNR = 'MNrv'
    iMNR = substitute(opmn.conclusion.body, opmn.conclusion.var, V(MNR))
    ctxMR = ctxR + (iMNR,)
    hOpMN = _assume(iMNR, ctxMR)
    mnD = _cart_member_from_components(_weaken(hD, ctxMR), MNR, m, n, _weaken(mw, ctxMR), _weaken(nw, ctxMR), hOpMN, ctxMR)
    opp = _weaken(oppf, ctxMR)
    opp = _forall_elim(_forall_elim(opp, MNR), y)
    assert isinstance(opp.conclusion, Exists)
    PR = 'Prv'
    iPR = substitute(opp.conclusion.body, opp.conclusion.var, V(PR))
    ctxPR = ctxMR + (iPR,)
    hOpP = _assume(iPR, ctxPR)
    pB = _cart_member_from_components(_weaken(hB, ctxPR), PR, MNR, y, _weaken(mnD, ctxPR), _weaken(yw, ctxPR), hOpP, ctxPR)
    gp = GlobalPairPredicate(V(PR), V('w'), hidden)
    q1 = substitute(gp.body, gp.var, V(m))
    q2 = substitute(q1.body, q1.var, V(n))
    q3 = substitute(q2.body, q2.var, V(y))
    q4 = substitute(q3.body, q3.var, V(MNR))
    gbody = q4
    g5 = Proof('and_intro', gbody.right.right.right.right, ctxPR, (_weaken(hOpP, ctxPR), _weaken(hsv, ctxPR)))
    g4 = Proof('and_intro', gbody.right.right.right, ctxPR, (_weaken(hOpMN, ctxPR), g5))
    g3 = Proof('and_intro', gbody.right.right, ctxPR, (_weaken(yw, ctxPR), g4))
    g2 = Proof('and_intro', gbody.right, ctxPR, (_weaken(nw, ctxPR), g3))
    gall = Proof('and_intro', gbody, ctxPR, (_weaken(mw, ctxPR), g2))
    emn = Proof('exists_intro', q3, ctxPR, (gall,), (('term', {'var': MNR}),))
    eyv = Proof('exists_intro', q2, ctxPR, (emn,), (('term', {'var': y}),))
    env = Proof('exists_intro', q1, ctxPR, (eyv,), (('term', {'var': n}),))
    emv = Proof('exists_intro', gp, ctxPR, (env,), (('term', {'var': m}),))
    sepPR = _forall_elim(_weaken(hSep, ctxPR), PR)
    sr = Proof('and_intro', sepPR.conclusion.right, ctxPR, (pB, emv))
    pF = _imp_elim(_iff_r(sepPR), sr)
    gvF = GraphValueSpec(V(F), V(MNR), V(y), 'vpg')
    igv = substitute(gvF.body, gvF.var, V(PR))
    cgv = Proof('and_intro', igv, ctxPR, (pF, hOpP))
    egv = Proof('exists_intro', gvF, ctxPR, (cgv,), (('term', {'var': PR}),))
    bgr = BinaryGraphValueSpec(V(F), V(m), V(n), V(y))
    ibr = substitute(bgr.body, bgr.var, V(MNR))
    cbgr = Proof('and_intro', ibr, ctxPR, (_weaken(hOpMN, ctxPR), egv))
    ebgr = Proof('exists_intro', bgr, ctxPR, (cbgr,), (('term', {'var': MNR}),))
    aPR = Proof('exists_elim', bgr, ctxMR, (opp, ebgr), (('eigenvar', PR),))
    aMR = Proof('exists_elim', bgr, ctxR, (opmn, aPR), (('eigenvar', MNR),))
    rimp = Proof('imp_intro', Imp(sval, bgv), ctxE, (aMR,))
    iffpf = Proof('iff_intro', ie.right, ctxE, (fimp, rimp))
    iepf = Proof('imp_intro', ie, ctxF, (iffpf,))
    qy = Proof('forall_intro', exact.body.body, ctxF, (iepf,))
    qn = Proof('forall_intro', exact.body, ctxF, (qy,))
    exactpf = Proof('forall_intro', exact, ctxF, (qn,))
    rel = fun.left
    pr = rel.var
    ir = rel.body
    ctxRel = ctxF + (ir.left,)
    hPin = _assume(ir.left, ctxRel)
    sep = _forall_elim(_weaken(hSep, ctxRel), pr)
    srr = _imp_elim(_iff_l(sep), hPin)
    pinB = _and_l(srr)
    parts = _open_cart_member(_weaken(hB, ctxRel), pr, pinB, ctxRel, 'R')
    exx, X, ctxX, hx, exy, Y, ctxY, hy, XD, YW, opR = parts
    relout = ir.right
    iy = substitute(relout.body, relout.var, V(X))
    eyy = iy.right
    iyy = substitute(eyy.body, eyy.var, V(Y))
    cy = Proof('and_intro', iyy, ctxY, (_weaken(YW, ctxY), opR))
    ey2 = Proof('exists_intro', eyy, ctxY, (cy,), (('term', {'var': Y}),))
    cx = Proof('and_intro', iy, ctxY, (_weaken(XD, ctxY), ey2))
    ex2 = Proof('exists_intro', relout, ctxY, (cx,), (('term', {'var': X}),))
    ay = Proof('exists_elim', relout, ctxX, (exy, ex2), (('eigenvar', Y),))
    ax = Proof('exists_elim', relout, ctxRel, (exx, ay), (('eigenvar', X),))
    rip = Proof('imp_intro', ir, ctxF, (ax,))
    relpf = Proof('forall_intro', rel, ctxF, (rip,))
    total = fun.right.left
    xx = total.var
    it = total.body
    ctxT = ctxF + (it.left,)
    xD = _assume(it.left, ctxT)
    partsD = _open_cart_member(_weaken(hD, ctxT), xx, xD, ctxT, 'T')
    exm, M, ctxM, hm, exn, N, ctxN, hn, MW, NW, opX = partsD
    vt = _weaken(hVT, ctxN)
    for nm0 in ['w', M, N]:
        vt = _forall_elim(vt, nm0)
    va = vt.conclusion.left
    vr = Proof('and_intro', va.right, ctxN, (_weaken(MW, ctxN), _weaken(NW, ctxN)))
    vall = Proof('and_intro', va, ctxN, (_weaken(hom, ctxN), vr))
    exY = _imp_elim(vt, vall)
    assert isinstance(exY.conclusion, Exists)
    YT = 'YT'
    iYT = substitute(exY.conclusion.body, exY.conclusion.var, V(YT))
    ctxYT = ctxN + (iYT,)
    hyT = _assume(iYT, ctxYT)
    YW2 = _and_l(hyT)
    SV = _and_r(hyT)
    exq = _weaken(exactpf, ctxYT)
    for nm0 in [M, N, YT]:
        exq = _forall_elim(exq, nm0)
    em = exq.conclusion.left
    emr = Proof('and_intro', em.right, ctxYT, (_weaken(NW, ctxYT), _weaken(YW2, ctxYT)))
    ema = Proof('and_intro', em, ctxYT, (_weaken(MW, ctxYT), emr))
    iff = _imp_elim(exq, ema)
    bg = _imp_elim(_iff_r(iff), SV)
    MNB = 'MNB'
    iMNB = substitute(bg.conclusion.body, bg.conclusion.var, V(MNB))
    ctxMNB = ctxYT + (iMNB,)
    hbg2 = _assume(iMNB, ctxMNB)
    opMNB = _and_l(hbg2)
    gvMNB = _and_r(hbg2)
    inj = _op_injective_instance(_weaken(opinj, ctxMNB), xx, M, N, M, N, _weaken(opX, ctxMNB), opMNB, ctxMNB) if False else None
    ou = build_ordered_pair_code_unique()
    ou = _weaken(ou, ctxMNB)
    for nm0 in [xx, MNB, M, N]:
        ou = _forall_elim(ou, nm0)
    eqXM = _imp_elim(ou, Proof('and_intro', ou.conclusion.left, ctxMNB, (_weaken(opX, ctxMNB), opMNB)))
    gvX = Proof('eq_subst', substitute(gvMNB.conclusion, MNB, V(xx)), ctxMNB, (eqXM, gvMNB), (('direction', 'rl'),))
    outY = it.right
    iout = substitute(outY.body, outY.var, V(YT))
    cout = Proof('and_intro', iout, ctxMNB, (_weaken(YW2, ctxMNB), gvX))
    eout = Proof('exists_intro', outY, ctxMNB, (cout,), (('term', {'var': YT}),))
    aMNB = Proof('exists_elim', outY, ctxYT, (bg, eout), (('eigenvar', MNB),))
    aYT = Proof('exists_elim', outY, ctxN, (exY, aMNB), (('eigenvar', YT),))
    aN = Proof('exists_elim', outY, ctxM, (exn, aYT), (('eigenvar', N),))
    aM = Proof('exists_elim', outY, ctxT, (exm, aN), (('eigenvar', M),))
    tip = Proof('imp_intro', it, ctxF, (aM,))
    totalpf = Proof('forall_intro', total, ctxF, (tip,))
    unique = fun.right.right
    xu = unique.var
    yu = unique.body.var
    y2u = unique.body.body.var
    iu = unique.body.body.body
    ctxU = ctxF + (iu.left,)
    hu = _assume(iu.left, ctxU)
    L = _and_l(hu)
    R = _and_r(hu)
    xDu = _and_l(L)
    yw1 = _and_r(L)
    y2w = _and_l(R)
    bothgv = _and_r(R)
    gv1 = _and_l(bothgv)
    gv2 = _and_r(bothgv)
    partsU = _open_cart_member(_weaken(hD, ctxU), xu, xDu, ctxU, 'U')
    exmu, MU, ctxMU, hmu, exnu, NU, ctxNU, hnu, MWU, NWU, opXU = partsU

    def section_from_gv(gv0, yname):
        b = BinaryGraphValueSpec(V(F), V(MU), V(NU), V(yname))
        ib = substitute(b.body, b.var, V(xu))
        cb = Proof('and_intro', ib, ctxNU, (_weaken(opXU, ctxNU), _weaken(gv0, ctxNU)))
        eb = Proof('exists_intro', b, ctxNU, (cb,), (('term', {'var': xu}),))
        eqp = _weaken(exactpf, ctxNU)
        for nm0 in [MU, NU, yname]:
            eqp = _forall_elim(eqp, nm0)
        ea = eqp.conclusion.left
        er = Proof('and_intro', ea.right, ctxNU, (_weaken(NWU, ctxNU), _weaken(yw1 if yname == yu else y2w, ctxNU)))
        eaa = Proof('and_intro', ea, ctxNU, (_weaken(MWU, ctxNU), er))
        iff0 = _imp_elim(eqp, eaa)
        return _imp_elim(_iff_l(iff0), eb)
    sv1 = section_from_gv(gv1, yu)
    sv2 = section_from_gv(gv2, y2u)
    vu = _weaken(hVU, ctxNU)
    for nm0 in ['w', MU, NU, yu, y2u]:
        vu = _forall_elim(vu, nm0)
    ua = vu.conclusion.left
    n5 = Proof('and_intro', ua.right.right.right.right.right, ctxNU, (sv1, sv2))
    n4 = Proof('and_intro', ua.right.right.right.right, ctxNU, (_weaken(y2w, ctxNU), n5))
    n3 = Proof('and_intro', ua.right.right.right, ctxNU, (_weaken(yw1, ctxNU), n4))
    n2 = Proof('and_intro', ua.right.right, ctxNU, (_weaken(NWU, ctxNU), n3))
    n1 = Proof('and_intro', ua.right, ctxNU, (_weaken(MWU, ctxNU), n2))
    nu = Proof('and_intro', ua, ctxNU, (_weaken(hom, ctxNU), n1))
    eqyy = _imp_elim(vu, nu)
    aNU = Proof('exists_elim', Eq(V(yu), V(y2u)), ctxMU, (exnu, eqyy), (('eigenvar', NU),))
    aMU = Proof('exists_elim', Eq(V(yu), V(y2u)), ctxU, (exmu, aNU), (('eigenvar', MU),))
    uip = Proof('imp_intro', iu, ctxF, (aMU,))
    qy2 = Proof('forall_intro', unique.body.body, ctxF, (uip,))
    qy1 = Proof('forall_intro', unique.body, ctxF, (qy2,))
    uniquepf = Proof('forall_intro', unique, ctxF, (qy1,))
    funpf = Proof('and_intro', fun, ctxF, (relpf, Proof('and_intro', fun.right, ctxF, (totalpf, uniquepf))))
    specpf = Proof('and_intro', spec, ctxF, (funpf, exactpf))
    tD = substitute(target.body, target.var, V(D))
    exFtarget = tD.right if isinstance(tD, And) else None
    inner = tD.right
    assert isinstance(inner, Exists)
    eF = Proof('exists_intro', inner, ctxF, (specpf,), (('term', {'var': F}),))
    aF = Proof('exists_elim', inner, ctxB, (sq, eF), (('eigenvar', F),))
    aB = Proof('exists_elim', inner, ctxD, (cb, aF), (('eigenvar', B),))
    dbody = And(CartesianProductSpec(V(D), V('w'), V('w'), 'pd'), inner)
    cd = Proof('and_intro', dbody, ctxD, (hD, aB))
    eD = Proof('exists_intro', target, ctxD, (cd,), (('term', {'var': D}),))
    aD = Proof('exists_elim', target, ctx, (cp, eD), (('eigenvar', D),))
    iw = Proof('imp_intro', core, ctx0, (aD,))
    fw = Proof('forall_intro', out, ctx0, (iw,))
    return Proof('imp_intro', goal, (), (fw,))

def build_add_global_operation_exists(schema_index: int=11) -> Proof:
    return _build_global_operation_exists(AddSectionHidden, ADD_GLOBAL_SEPARATION_SCHEMA, schema_index)

def build_mul_global_operation_exists(schema_index: int=12) -> Proof:
    return _build_global_operation_exists(MulSectionHidden, MUL_GLOBAL_SEPARATION_SCHEMA, schema_index)

def build_exp_global_operation_exists(schema_index: int=13) -> Proof:
    return _build_global_operation_exists(ExpSectionHidden, EXP_GLOBAL_SEPARATION_SCHEMA, schema_index)

def add_hidden_exists_adapter_formula() -> Formula:
    return Imp(addition_section_exists_unique_formula(), section_exists_formula(AddSectionHidden))

def build_add_hidden_exists_adapter() -> Proof:
    src = addition_section_exists_unique_formula()
    goal = add_hidden_exists_adapter_formula()
    ctx0 = (src,)
    hs = _assume(src, ctx0)
    target = goal.right
    core = target.body.body
    ctx = ctx0 + (core.left,)
    hb = _assume(core.left, ctx)
    sp = _weaken(hs, ctx)
    sp = _forall_elim(_forall_elim(sp, 'w'), 'm')
    exg = _imp_elim(sp, hb)
    assert isinstance(exg.conclusion, Exists)
    G = 'Gada'
    iG = substitute(exg.conclusion.body, exg.conclusion.var, V(G))
    ctxG = ctx + (iG,)
    hG = _assume(iG, ctxG)
    exf = hG
    assert isinstance(exf.conclusion, Exists)
    F = 'Fada'
    iF = substitute(exf.conclusion.body, exf.conclusion.var, V(F))
    ctxF = ctxG + (iF,)
    hF = _assume(iF, ctxF)
    cand = _and_l(hF)
    hidden = AddSectionHidden(V(F), V('w'), V('m'))
    ih = substitute(hidden.body, hidden.var, V(G))
    eg = Proof('exists_intro', hidden, ctxF, (cand,), (('term', {'var': G}),))
    ef = Proof('exists_intro', core.right, ctxF, (eg,), (('term', {'var': F}),))
    af = Proof('exists_elim', core.right, ctxG, (exf, ef), (('eigenvar', F),))
    ag = Proof('exists_elim', core.right, ctx, (exg, af), (('eigenvar', G),))
    ip = Proof('imp_intro', core, ctx0, (ag,))
    qm = Proof('forall_intro', target.body, ctx0, (ip,))
    fw = Proof('forall_intro', target, ctx0, (qm,))
    return Proof('imp_intro', goal, (), (fw,))

def mul_hidden_exists_adapter_formula() -> Formula:
    return Imp(And(section_exists_formula(AddSectionHidden), multiplication_from_addition_formula()), section_exists_formula(MulSectionHidden))

def build_mul_hidden_exists_adapter() -> Proof:
    goal = mul_hidden_exists_adapter_formula()
    ctx0 = (goal.left,)
    hp = _assume(goal.left, ctx0)
    hAE = _and_l(hp)
    hMM = _and_r(hp)
    target = goal.right
    core = target.body.body
    ctx = ctx0 + (core.left,)
    hb = _assume(core.left, ctx)
    om = _and_l(hb)
    mw = _and_r(hb)
    ae = _weaken(hAE, ctx)
    ae = _forall_elim(_forall_elim(ae, 'w'), 'm')
    exA = _imp_elim(ae, hb)
    assert isinstance(exA.conclusion, Exists)
    A = 'Ama'
    iA = substitute(exA.conclusion.body, exA.conclusion.var, V(A))
    ctxA = ctx + (iA,)
    hAh = _assume(iA, ctxA)
    exG = hAh
    assert isinstance(exG.conclusion, Exists)
    G = 'Gma'
    iG = substitute(exG.conclusion.body, exG.conclusion.var, V(G))
    ctxG = ctxA + (iG,)
    addCand = _assume(iG, ctxG)
    sg = _and_l(addCand)
    addRec = _and_r(addCand)
    ex0 = _and_l(_and_l(_weaken(om, ctxG)))
    assert isinstance(ex0.conclusion, Exists)
    Z = 'Zma'
    iZ = substitute(ex0.conclusion.body, ex0.conclusion.var, V(Z))
    ctxZ = ctxG + (iZ,)
    hz = _assume(iZ, ctxZ)
    zw = _and_l(hz)
    emp = _and_r(hz)
    mm = _weaken(hMM, ctxZ)
    for nm in ['w', 'm', G, A, Z]:
        mm = _forall_elim(mm, nm)
    ante = mm.conclusion.left
    n4 = Proof('and_intro', ante.right.right.right.right, ctxZ, (_weaken(emp, ctxZ), _weaken(zw, ctxZ)))
    n3 = Proof('and_intro', ante.right.right.right, ctxZ, (_weaken(addRec, ctxZ), n4))
    n2 = Proof('and_intro', ante.right.right, ctxZ, (_weaken(sg, ctxZ), n3))
    n1 = Proof('and_intro', ante.right, ctxZ, (_weaken(mw, ctxZ), n2))
    aa = Proof('and_intro', ante, ctxZ, (_weaken(om, ctxZ), n1))
    exM = _imp_elim(mm, aa)
    assert isinstance(exM.conclusion, Exists)
    M = 'Mma'
    iM = substitute(exM.conclusion.body, exM.conclusion.var, V(M))
    ctxM = ctxZ + (iM,)
    hMpack = _assume(iM, ctxM)
    mulRec = _and_l(hMpack)
    hidden = MulSectionHidden(V(M), V('w'), V('m'))
    q = hidden.body
    qG = substitute(q, hidden.var, V(G))
    qA = substitute(qG.body, qG.var, V(A))
    qZ = substitute(qA.body, qA.var, V(Z))
    body = qZ
    b4 = Proof('and_intro', body.right.right.right, ctxM, (_weaken(zw, ctxM), mulRec))
    b3 = Proof('and_intro', body.right.right, ctxM, (_weaken(emp, ctxM), b4))
    b2 = Proof('and_intro', body.right, ctxM, (_weaken(addRec, ctxM), b3))
    ball = Proof('and_intro', body, ctxM, (_weaken(sg, ctxM), b2))
    ez = Proof('exists_intro', qA, ctxM, (ball,), (('term', {'var': Z}),))
    ea = Proof('exists_intro', qG, ctxM, (ez,), (('term', {'var': A}),))
    eg = Proof('exists_intro', hidden, ctxM, (ea,), (('term', {'var': G}),))
    em = Proof('exists_intro', core.right, ctxM, (eg,), (('term', {'var': M}),))
    aM = Proof('exists_elim', core.right, ctxZ, (exM, em), (('eigenvar', M),))
    aZ = Proof('exists_elim', core.right, ctxG, (ex0, aM), (('eigenvar', Z),))
    aG = Proof('exists_elim', core.right, ctxA, (exG, aZ), (('eigenvar', G),))
    aA = Proof('exists_elim', core.right, ctx, (exA, aG), (('eigenvar', A),))
    ip = Proof('imp_intro', core, ctx0, (aA,))
    qm = Proof('forall_intro', target.body, ctx0, (ip,))
    fw = Proof('forall_intro', target, ctx0, (qm,))
    return Proof('imp_intro', goal, (), (fw,))

def exp_hidden_exists_adapter_formula() -> Formula:
    return Imp(And(section_exists_formula(MulSectionHidden), exponentiation_from_multiplication_formula()), section_exists_formula(ExpSectionHidden))

def build_exp_hidden_exists_adapter() -> Proof:
    goal = exp_hidden_exists_adapter_formula()
    ctx0 = (goal.left,)
    hp = _assume(goal.left, ctx0)
    hME = _and_l(hp)
    hEE = _and_r(hp)
    target = goal.right
    core = target.body.body
    ctx = ctx0 + (core.left,)
    hb = _assume(core.left, ctx)
    om = _and_l(hb)
    mw = _and_r(hb)
    me = _weaken(hME, ctx)
    me = _forall_elim(_forall_elim(me, 'w'), 'm')
    exM = _imp_elim(me, hb)
    assert isinstance(exM.conclusion, Exists)
    M = 'Memod'
    iM = substitute(exM.conclusion.body, exM.conclusion.var, V(M))
    ctxM = ctx + (iM,)
    hM = _assume(iM, ctxM)
    exG = hM
    G = 'Gemod'
    iG = substitute(exG.conclusion.body, exG.conclusion.var, V(G))
    ctxG = ctxM + (iG,)
    hG = _assume(iG, ctxG)
    exA = hG
    A = 'Aemod'
    iA = substitute(exA.conclusion.body, exA.conclusion.var, V(A))
    ctxA = ctxG + (iA,)
    hA = _assume(iA, ctxA)
    exZ = hA
    Z = 'Zemod'
    iZ = substitute(exZ.conclusion.body, exZ.conclusion.var, V(Z))
    ctxZ = ctxA + (iZ,)
    pack = _assume(iZ, ctxZ)
    hSucc = _and_l(pack)
    r1 = _and_r(pack)
    addRec = _and_l(r1)
    r2 = _and_r(r1)
    emptyZ = _and_l(r2)
    r3 = _and_r(r2)
    Zw = _and_l(r3)
    mulRec = _and_r(r3)
    closed = _and_r(_and_l(_weaken(om, ctxZ)))
    q1 = _forall_elim(closed, Z)
    exO = _imp_elim(q1, Zw)
    assert isinstance(exO.conclusion, Exists)
    O = 'Oemod'
    iO = substitute(exO.conclusion.body, exO.conclusion.var, V(O))
    ctxO = ctxZ + (iO,)
    hO = _assume(iO, ctxO)
    Ow = _and_l(hO)
    succO = _and_r(hO)
    ep = _weaken(hEE, ctxO)
    for nm in ['w', 'm', G, A, Z, M, O]:
        ep = _forall_elim(ep, nm)
    ante = ep.conclusion.left
    n7 = Proof('and_intro', ante.right.right.right.right.right.right.right, ctxO, (_weaken(succO, ctxO), _weaken(Ow, ctxO)))
    n6 = Proof('and_intro', ante.right.right.right.right.right.right, ctxO, (_weaken(mulRec, ctxO), n7))
    n5 = Proof('and_intro', ante.right.right.right.right.right, ctxO, (_weaken(Zw, ctxO), n6))
    n4 = Proof('and_intro', ante.right.right.right.right, ctxO, (_weaken(emptyZ, ctxO), n5))
    n3 = Proof('and_intro', ante.right.right.right, ctxO, (_weaken(addRec, ctxO), n4))
    n2 = Proof('and_intro', ante.right.right, ctxO, (_weaken(hSucc, ctxO), n3))
    n1 = Proof('and_intro', ante.right, ctxO, (_weaken(mw, ctxO), n2))
    allp = Proof('and_intro', ante, ctxO, (_weaken(om, ctxO), n1))
    exE = _imp_elim(ep, allp)
    assert isinstance(exE.conclusion, Exists)
    E = 'Eemod'
    iE = substitute(exE.conclusion.body, exE.conclusion.var, V(E))
    ctxE = ctxO + (iE,)
    expRec = _and_l(_assume(iE, ctxE))
    hidden = ExpSectionHidden(V(E), V('w'), V('m'))
    q = hidden.body
    qG = substitute(q, hidden.var, V(G))
    qA = substitute(qG.body, qG.var, V(A))
    qZ = substitute(qA.body, qA.var, V(Z))
    qM = substitute(qZ.body, qZ.var, V(M))
    qO = substitute(qM.body, qM.var, V(O))
    body = qO
    b7 = Proof('and_intro', body.right.right.right.right.right.right, ctxE, (_weaken(Ow, ctxE), expRec))
    b6 = Proof('and_intro', body.right.right.right.right.right, ctxE, (_weaken(succO, ctxE), b7))
    b5 = Proof('and_intro', body.right.right.right.right, ctxE, (_weaken(mulRec, ctxE), b6))
    b4 = Proof('and_intro', body.right.right.right, ctxE, (_weaken(Zw, ctxE), b5))
    b3 = Proof('and_intro', body.right.right, ctxE, (_weaken(emptyZ, ctxE), b4))
    b2 = Proof('and_intro', body.right, ctxE, (_weaken(addRec, ctxE), b3))
    ball = Proof('and_intro', body, ctxE, (_weaken(hSucc, ctxE), b2))
    eO = Proof('exists_intro', qM, ctxE, (ball,), (('term', {'var': O}),))
    eM = Proof('exists_intro', qZ, ctxE, (eO,), (('term', {'var': M}),))
    eZ = Proof('exists_intro', qA, ctxE, (eM,), (('term', {'var': Z}),))
    eA = Proof('exists_intro', qG, ctxE, (eZ,), (('term', {'var': A}),))
    eG = Proof('exists_intro', hidden, ctxE, (eA,), (('term', {'var': G}),))
    ef = Proof('exists_intro', core.right, ctxE, (eG,), (('term', {'var': E}),))
    aE = Proof('exists_elim', core.right, ctxO, (exE, ef), (('eigenvar', E),))
    aO = Proof('exists_elim', core.right, ctxZ, (exO, aE), (('eigenvar', O),))
    aZ = Proof('exists_elim', core.right, ctxA, (exZ, aO), (('eigenvar', Z),))
    aA = Proof('exists_elim', core.right, ctxG, (exA, aZ), (('eigenvar', A),))
    aG = Proof('exists_elim', core.right, ctxM, (exG, aA), (('eigenvar', G),))
    aM = Proof('exists_elim', core.right, ctx, (exM, aG), (('eigenvar', M),))
    ip = Proof('imp_intro', core, ctx0, (aM,))
    qm = Proof('forall_intro', target.body, ctx0, (ip,))
    fw = Proof('forall_intro', target, ctx0, (qm,))
    return Proof('imp_intro', goal, (), (fw,))

def _and_chain_for(target: Formula, proofs: list[Proof], ctx) -> Proof:
    if len(proofs) == 1:
        return _weaken(proofs[0], ctx)
    assert isinstance(target, And)
    return Proof('and_intro', target, tuple(ctx), (_weaken(proofs[0], ctx), _and_chain_for(target.right, proofs[1:], ctx)))

def _imp_chain_formula(premises: list[Formula], conclusion: Formula) -> Formula:
    out = conclusion
    for p in reversed(premises):
        out = Imp(p, out)
    return out

def _close_imp_chain(p: Proof, premises: list[Formula]) -> Proof:
    cur = p
    for i in range(len(premises) - 1, -1, -1):
        newctx = tuple(premises[:i])
        cur = Proof('imp_intro', Imp(premises[i], cur.conclusion), newctx, (cur,))
    return cur

def _forall_wrap(names: list[str], body: Formula) -> Formula:
    out = body
    for nm in reversed(names):
        out = Forall(nm, out)
    return out

def _forall_close(p: Proof, names: list[str]) -> Proof:
    cur = p
    body = cur.conclusion
    forms = []
    out = body
    for nm in reversed(names):
        out = Forall(nm, out)
    cur_formula = body
    for nm in reversed(names):
        cur_formula = Forall(nm, cur_formula)
        cur = Proof('forall_intro', cur_formula, (), (cur,))
    return cur

def _global_exact_to_binary(global_pf: Proof, hidden, m: str, n: str, y: str, mw: Proof, nw: Proof, yw: Proof, sv: Proof, ctx) -> Proof:
    exact = _and_r(global_pf)
    for nm in [m, n, y]:
        exact = _forall_elim(exact, nm)
    ante = exact.conclusion.left
    memp = _and_chain_for(ante, [mw, nw, yw], ctx)
    iff = _imp_elim(exact, memp)
    return _imp_elim(_iff_r(iff), sv)

def add_one_one_formula() -> Formula:
    w, z, o, t, F, d = map(V, ['w', 'z', 'o', 't', 'F', 'd'])
    premises = [OmegaSpec(w, 'j', 'k'), EmptySpec(z, 'ez'), Mem(z, w), SuccessorSpec(o, z, 'so'), Mem(o, w), SuccessorSpec(t, o, 'st'), Mem(t, w), GlobalOperationSpec(F, d, w, AddSectionHidden), section_exists_formula(AddSectionHidden), addition_zero_law_formula(), addition_successor_law_formula()]
    return _forall_wrap(['w', 'z', 'o', 't', 'F', 'd'], _imp_chain_formula(premises, BinaryGraphValueSpec(F, o, o, t)))

def build_add_one_one() -> Proof:
    w, z, o, t, F, d = ('w', 'z', 'o', 't', 'F', 'd')
    W, Z, O, T, FF, DD = map(V, [w, z, o, t, F, d])
    premises = [OmegaSpec(W, 'j', 'k'), EmptySpec(Z, 'ez'), Mem(Z, W), SuccessorSpec(O, Z, 'so'), Mem(O, W), SuccessorSpec(T, O, 'st'), Mem(T, W), GlobalOperationSpec(FF, DD, W, AddSectionHidden), section_exists_formula(AddSectionHidden), addition_zero_law_formula(), addition_successor_law_formula()]
    ctx = tuple(premises)
    h = [_assume(x, ctx) for x in premises]
    om, emp, zw, s1, ow, s2, tw, gop, se, zlaw, slaw = h
    qse = _forall_elim(_forall_elim(se, w), o)
    ab = _and_chain_for(qse.conclusion.left, [om, ow], ctx)
    exF = _imp_elim(qse, ab)
    assert isinstance(exF.conclusion, Exists)
    fs = 'Faddcalc'
    iF = substitute(exF.conclusion.body, exF.conclusion.var, V(fs))
    ctxF = ctx + (iF,)
    hHidden = _assume(iF, ctxF)
    exG = hHidden
    G = 'Gaddcalc'
    iG = substitute(exG.conclusion.body, exG.conclusion.var, V(G))
    ctxG = ctxF + (iG,)
    cand = _assume(iG, ctxG)
    sg = _and_l(cand)
    rec = _and_r(cand)
    zl = _weaken(zlaw, ctxG)
    for nm in [fs, w, o, G, z]:
        zl = _forall_elim(zl, nm)
    zante = _and_chain_for(zl.conclusion.left, [rec, _weaken(emp, ctxG)], ctxG)
    gv0 = _imp_elim(zl, zante)
    sl = _weaken(slaw, ctxG)
    for nm in [fs, w, o, G, z, o, o, t]:
        sl = _forall_elim(sl, nm)
    sante = _and_chain_for(sl.conclusion.left, [rec, sg, _weaken(zw, ctxG), _weaken(ow, ctxG), _weaken(s1, ctxG), gv0, _weaken(tw, ctxG), _weaken(s2, ctxG)], ctxG)
    gv1 = _imp_elim(sl, sante)
    gvF = Proof('exists_elim', gv1.conclusion, ctxF, (hHidden, gv1), (('eigenvar', G),))
    sv = SectionValueSpec(AddSectionHidden, W, O, O, T)
    iv = substitute(sv.body, sv.var, V(fs))
    cv = Proof('and_intro', iv, ctxF, (hHidden, gvF))
    esv = Proof('exists_intro', sv, ctxF, (cv,), (('term', {'var': fs}),))
    sv0 = Proof('exists_elim', sv, ctx, (exF, esv), (('eigenvar', fs),))
    out = _global_exact_to_binary(gop, AddSectionHidden, o, o, t, ow, ow, tw, sv0, ctx)
    return _forall_close(_close_imp_chain(out, premises), [w, z, o, t, F, d])

def mul_two_one_formula() -> Formula:
    w, z, o, t, F, d = map(V, ['w', 'z', 'o', 't', 'F', 'd'])
    premises = [OmegaSpec(w, 'j', 'k'), EmptySpec(z, 'ez'), Mem(z, w), SuccessorSpec(o, z, 'so'), Mem(o, w), SuccessorSpec(t, o, 'st'), Mem(t, w), GlobalOperationSpec(F, d, w, MulSectionHidden), section_exists_formula(MulSectionHidden), addition_zero_law_formula(), multiplication_zero_law_formula(), multiplication_successor_law_formula()]
    return _forall_wrap(['w', 'z', 'o', 't', 'F', 'd'], _imp_chain_formula(premises, BinaryGraphValueSpec(F, t, o, t)))

def build_mul_two_one() -> Proof:
    w, z, o, t, F, d = ('w', 'z', 'o', 't', 'F', 'd')
    W, Z, O, T, FF, DD = map(V, [w, z, o, t, F, d])
    premises = [OmegaSpec(W, 'j', 'k'), EmptySpec(Z, 'ez'), Mem(Z, W), SuccessorSpec(O, Z, 'so'), Mem(O, W), SuccessorSpec(T, O, 'st'), Mem(T, W), GlobalOperationSpec(FF, DD, W, MulSectionHidden), section_exists_formula(MulSectionHidden), addition_zero_law_formula(), multiplication_zero_law_formula(), multiplication_successor_law_formula()]
    ctx = tuple(premises)
    om, emp, zw, s1, ow, s2, tw, gop, se, az, mz, ms = [_assume(x, ctx) for x in premises]
    qse = _forall_elim(_forall_elim(se, w), t)
    ab = _and_chain_for(qse.conclusion.left, [om, tw], ctx)
    exF = _imp_elim(qse, ab)
    fs = 'Fmulcalc'
    iF = substitute(exF.conclusion.body, exF.conclusion.var, V(fs))
    ctxF = ctx + (iF,)
    hHidden = _assume(iF, ctxF)
    G = 'Gmulcalc'
    iG = substitute(hHidden.conclusion.body, hHidden.conclusion.var, V(G))
    ctxG = ctxF + (iG,)
    hG = _assume(iG, ctxG)
    A = 'Amulcalc'
    iA = substitute(hG.conclusion.body, hG.conclusion.var, V(A))
    ctxA = ctxG + (iA,)
    hA = _assume(iA, ctxA)
    Zi = 'Zmulcalc'
    iZ = substitute(hA.conclusion.body, hA.conclusion.var, V(Zi))
    ctxZ = ctxA + (iZ,)
    body = _assume(iZ, ctxZ)
    sg = _and_l(body)
    r1 = _and_r(body)
    addRec = _and_l(r1)
    r2 = _and_r(r1)
    empI = _and_l(r2)
    r3 = _and_r(r2)
    zIw = _and_l(r3)
    mulRec = _and_r(r3)
    al = _weaken(az, ctxZ)
    for nm in [A, w, t, G, z]:
        al = _forall_elim(al, nm)
    agv = _imp_elim(al, _and_chain_for(al.conclusion.left, [addRec, _weaken(emp, ctxZ)], ctxZ))
    ml = _weaken(mz, ctxZ)
    for nm in [fs, w, Zi, A]:
        ml = _forall_elim(ml, nm)
    mgvi = _imp_elim(ml, _and_chain_for(ml.conclusion.left, [mulRec, empI], ctxZ))
    eu = _weaken(build_empty_unique(), ctxZ)
    eu = _forall_elim(_forall_elim(eu, Zi), z)
    eqz = _imp_elim(eu, _and_chain_for(eu.conclusion.left, [empI, _weaken(emp, ctxZ)], ctxZ))
    mgv = Proof('eq_subst', substitute(mgvi.conclusion, Zi, Z), ctxZ, (eqz, mgvi), (('direction', 'lr'),))
    sl = _weaken(ms, ctxZ)
    for nm in [fs, w, Zi, A, z, o, z, t]:
        sl = _forall_elim(sl, nm)
    sante = _and_chain_for(sl.conclusion.left, [mulRec, _weaken(zw, ctxZ), _weaken(ow, ctxZ), _weaken(s1, ctxZ), mgv, agv], ctxZ)
    gv1 = _imp_elim(sl, sante)
    res = gv1
    for ex, nm, bc in [(hA, Zi, ctxA), (hG, A, ctxG), (hHidden, G, ctxF)]:
        res = Proof('exists_elim', gv1.conclusion, bc, (ex, res), (('eigenvar', nm),))
    gvF = res
    sv = SectionValueSpec(MulSectionHidden, W, T, O, T)
    iv = substitute(sv.body, sv.var, V(fs))
    cv = Proof('and_intro', iv, ctxF, (hHidden, gvF))
    esv = Proof('exists_intro', sv, ctxF, (cv,), (('term', {'var': fs}),))
    sv0 = Proof('exists_elim', sv, ctx, (exF, esv), (('eigenvar', fs),))
    out = _global_exact_to_binary(gop, MulSectionHidden, t, o, t, tw, ow, tw, sv0, ctx)
    return _forall_close(_close_imp_chain(out, premises), [w, z, o, t, F, d])

def exp_two_zero_formula() -> Formula:
    w, z, o, t, F, d = map(V, ['w', 'z', 'o', 't', 'F', 'd'])
    premises = [OmegaSpec(w, 'j', 'k'), EmptySpec(z, 'ez'), Mem(z, w), SuccessorSpec(o, z, 'so'), Mem(o, w), SuccessorSpec(t, o, 'st'), Mem(t, w), GlobalOperationSpec(F, d, w, ExpSectionHidden), section_exists_formula(ExpSectionHidden), exponentiation_zero_law_formula()]
    return _forall_wrap(['w', 'z', 'o', 't', 'F', 'd'], _imp_chain_formula(premises, BinaryGraphValueSpec(F, t, z, o)))

def build_exp_two_zero() -> Proof:
    w, z, o, t, F, d = ('w', 'z', 'o', 't', 'F', 'd')
    W, Z, O, T, FF, DD = map(V, [w, z, o, t, F, d])
    premises = [OmegaSpec(W, 'j', 'k'), EmptySpec(Z, 'ez'), Mem(Z, W), SuccessorSpec(O, Z, 'so'), Mem(O, W), SuccessorSpec(T, O, 'st'), Mem(T, W), GlobalOperationSpec(FF, DD, W, ExpSectionHidden), section_exists_formula(ExpSectionHidden), exponentiation_zero_law_formula()]
    ctx = tuple(premises)
    om, emp, zw, s1, ow, s2, tw, gop, se, ezlaw = [_assume(x, ctx) for x in premises]
    qse = _forall_elim(_forall_elim(se, w), t)
    ab = _and_chain_for(qse.conclusion.left, [om, tw], ctx)
    exF = _imp_elim(qse, ab)
    fs = 'Fexpcalc'
    iF = substitute(exF.conclusion.body, exF.conclusion.var, V(fs))
    ctxF = ctx + (iF,)
    hHidden = _assume(iF, ctxF)
    names = ['Gec', 'Aec', 'Zec', 'Mec', 'Oec']
    ex = hHidden
    c = ctxF
    chain = []
    for nm in names:
        inst = substitute(ex.conclusion.body, ex.conclusion.var, V(nm))
        nc = c + (inst,)
        ass = _assume(inst, nc)
        chain.append((ex, nm, c))
        ex = ass
        c = nc
    body = ex
    G, A, Zi, M, Oi = names
    sg = _and_l(body)
    r1 = _and_r(body)
    addRec = _and_l(r1)
    r2 = _and_r(r1)
    empI = _and_l(r2)
    r3 = _and_r(r2)
    zIw = _and_l(r3)
    r4 = _and_r(r3)
    mulRec = _and_l(r4)
    r5 = _and_r(r4)
    succOi = _and_l(r5)
    r6 = _and_r(r5)
    Oiw = _and_l(r6)
    expRec = _and_r(r6)
    el = _weaken(ezlaw, c)
    for nm in [fs, w, Oi, M, z]:
        el = _forall_elim(el, nm)
    gvOi = _imp_elim(el, _and_chain_for(el.conclusion.left, [expRec, _weaken(emp, c)], c))
    eu = _weaken(build_empty_unique(), c)
    eu = _forall_elim(_forall_elim(eu, Zi), z)
    eqz = _imp_elim(eu, _and_chain_for(eu.conclusion.left, [empI, _weaken(emp, c)], c))
    succOiz = Proof('eq_subst', substitute(succOi.conclusion, Zi, Z), c, (eqz, succOi), (('direction', 'lr'),))
    su = _weaken(build_successor_unique(), c)
    for nm in [z, Oi, o]:
        su = _forall_elim(su, nm)
    eqo = _imp_elim(su, _and_chain_for(su.conclusion.left, [succOiz, _weaken(s1, c)], c))
    gvO = Proof('eq_subst', substitute(gvOi.conclusion, Oi, O), c, (eqo, gvOi), (('direction', 'lr'),))
    res = gvO
    for ex0, nm, bc in reversed(chain):
        res = Proof('exists_elim', gvO.conclusion, bc, (ex0, res), (('eigenvar', nm),))
    gvF = res
    sv = SectionValueSpec(ExpSectionHidden, W, T, Z, O)
    iv = substitute(sv.body, sv.var, V(fs))
    cv = Proof('and_intro', iv, ctxF, (hHidden, gvF))
    esv = Proof('exists_intro', sv, ctxF, (cv,), (('term', {'var': fs}),))
    sv0 = Proof('exists_elim', sv, ctx, (exF, esv), (('eigenvar', fs),))
    out = _global_exact_to_binary(gop, ExpSectionHidden, t, z, o, tw, zw, ow, sv0, ctx)
    return _forall_close(_close_imp_chain(out, premises), [w, z, o, t, F, d])
