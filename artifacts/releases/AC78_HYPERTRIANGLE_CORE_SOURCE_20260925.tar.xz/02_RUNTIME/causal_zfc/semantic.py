from __future__ import annotations
from dataclasses import dataclass
import hashlib, json
from .logic import Formula, formula_to_obj, digest_formula, equivalent
from .proof import Proof, proof_digest, ctx_equiv
STATEMENT_KIND_ALIASES = {'theorem', 'lemma', 'proposition', 'corollary', 'claim', 'result', 'statement', 'fact', 'law', 'identity', 'formula', 'assertion', 'consequence', 'obligation', 'goal', 'subgoal'}
CANONICAL_STATEMENT_KIND = 'PROVABLE_STATEMENT'

def normalize_statement_kind(kind: str | None) -> str:
    if kind is None:
        return CANONICAL_STATEMENT_KIND
    k = str(kind).strip().lower().replace('-', '_').replace(' ', '_')
    if k in STATEMENT_KIND_ALIASES or k.upper() == CANONICAL_STATEMENT_KIND:
        return CANONICAL_STATEMENT_KIND
    return CANONICAL_STATEMENT_KIND

def sequent_key(context: tuple[Formula, ...], conclusion: Formula) -> str:
    ctx = sorted((digest_formula(f) for f in context))
    payload = {'context': ctx, 'conclusion': digest_formula(conclusion)}
    raw = json.dumps(payload, sort_keys=True, separators=(',', ':')).encode()
    return hashlib.sha256(raw).hexdigest()

@dataclass(frozen=True)
class CertifiedStatement:
    proof: Proof
    name: str = ''
    kind: str = CANONICAL_STATEMENT_KIND
    source: str = ''

    @property
    def canonical_kind(self) -> str:
        return normalize_statement_kind(self.kind)

    @property
    def identity(self) -> str:
        return sequent_key(self.proof.context, self.proof.conclusion)

@dataclass(frozen=True)
class NormalizedLibraryEntry:
    proof: Proof
    identity: str
    aliases: tuple[str, ...]
    source_labels: tuple[str, ...]
    canonical_kind: str = CANONICAL_STATEMENT_KIND

def normalize_certified_library(records: tuple[CertifiedStatement, ...], kernel) -> tuple[NormalizedLibraryEntry, ...]:
    groups: dict[str, dict] = {}
    for rec in records:
        kr = kernel.verify(rec.proof)
        if not kr.ok:
            raise ValueError(f"uncertified proof-library item {rec.name or '<unnamed>'}: {kr.detail}")
        sid = rec.identity
        g = groups.setdefault(sid, {'proof': rec.proof, 'aliases': set(), 'labels': set()})
        if rec.name:
            g['aliases'].add(rec.name)
        if rec.kind:
            g['labels'].add(str(rec.kind))
        if proof_digest(rec.proof) < proof_digest(g['proof']):
            g['proof'] = rec.proof
    out = []
    for sid in sorted(groups):
        g = groups[sid]
        out.append(NormalizedLibraryEntry(proof=g['proof'], identity=sid, aliases=tuple(sorted(g['aliases'])), source_labels=tuple(sorted(g['labels']))))
    return tuple(out)
