import json, sys
from .api import run_request
if len(sys.argv) != 2:
    raise SystemExit('usage: python -m causal_zfc request.json')
with open(sys.argv[1], encoding='utf-8') as f:
    req = json.load(f)
print(json.dumps(run_request(req), indent=2, sort_keys=True, ensure_ascii=False))
