from __future__ import annotations
from .proof import proof_from_obj
from .semantic import CertifiedStatement, normalize_statement_kind
LABEL_FIELDS = ('statement_kind', 'kind', 'object_type', 'result_type', 'claim_type')
NAME_FIELDS = ('name', 'id', 'statement_id', 'theorem_id', 'lemma_id', 'proposition_id')

def certified_statement_from_provider(payload: dict) -> CertifiedStatement:
    """Bind any theorem/lemma/proposition-like provider output by proof content, never by lexical label."""
    if not isinstance(payload, dict):
        raise ValueError('provider payload must be an object')
    if 'proof' not in payload:
        raise ValueError('UNVERIFIED_PROVIDER_STATEMENT: proof object missing')
    label = next((payload[k] for k in LABEL_FIELDS if k in payload), 'statement')
    name = next((str(payload[k]) for k in NAME_FIELDS if k in payload), '')
    source = str(payload.get('source', payload.get('provider', '')))
    return CertifiedStatement(proof_from_obj(payload['proof']), name, normalize_statement_kind(str(label)), source)
