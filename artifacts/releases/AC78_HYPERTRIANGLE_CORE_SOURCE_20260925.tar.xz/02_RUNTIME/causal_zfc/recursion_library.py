from __future__ import annotations
from .logic import *
from .proof import *
from .kernel import ZFCKernel
from .semantic import CertifiedStatement
from .setdefs import FunctionGraphSpec, OrderedPairCode, SingletonSpec, PairSpec, EmptySpec, SuccessorSpec, SubsetSpec, InductiveSetSpec
from .arithmetic_library import GraphValueSpec, build_ordered_pair_injective, _op_injective_instance
from .derived_library import _ax, _assume, _forall_elim, _and_l, _and_r, _imp_elim, _iff_l, _iff_r, _weaken

def CommonValueSpec(f: Term, h: Term, d: Term, c: Term, x: str='x', y: str='y') -> Formula:
    return Forall(x, Imp(Mem(V(x), d), Exists(y, And(Mem(V(y), c), And(GraphValueSpec(f, V(x), V(y), 'q'), GraphValueSpec(h, V(x), V(y), 'r'))))))

def function_common_value_extensionality_formula() -> Formula:
    f, h, d, c = map(V, ['f', 'h', 'd', 'c'])
    ff = FunctionGraphSpec(f, d, c, 'pf', 'xf', 'yf', 'yf2')
    hh = FunctionGraphSpec(h, d, c, 'ph', 'xh', 'yh', 'yh2')
    cv = CommonValueSpec(f, h, d, c, 'x', 'y')
    return Forall('f', Forall('h', Forall('d', Forall('c', Imp(And(ff, And(hh, cv)), Eq(f, h))))))

def _gv_from_pair(f: str, x: str, y: str, p: str, p_mem: Proof, op: Proof, ctx) -> Proof:
    gv = GraphValueSpec(V(f), V(x), V(y), 'q')
    inst = substitute(gv.body, gv.var, V(p))
    conj = Proof('and_intro', inst, ctx, (_weaken(p_mem, ctx), _weaken(op, ctx)))
    return Proof('exists_intro', gv, ctx, (conj,), (('term', {'var': p}),))

def _function_unique_instance(funpf: Proof, x: str, y: str, y2: str, xd: Proof, yc: Proof, y2c: Proof, gv1: Proof, gv2: Proof, ctx) -> Proof:
    unique = _and_r(_and_r(_weaken(funpf, ctx)))
    q = unique
    for nm in [x, y, y2]:
        q = _forall_elim(q, nm)
    ante = q.conclusion.left
    left = Proof('and_intro', ante.left, ctx, (_weaken(xd, ctx), _weaken(yc, ctx)))
    both = Proof('and_intro', ante.right.right, ctx, (_weaken(gv1, ctx), _weaken(gv2, ctx)))
    right = Proof('and_intro', ante.right, ctx, (_weaken(y2c, ctx), both))
    allante = Proof('and_intro', ante, ctx, (left, right))
    return _imp_elim(q, allante)

def _membership_transfer(src_fun: Proof, dst_fun: Proof, common: Proof, opuniq: Proof, src_name: str, dst_name: str, d: str, c: str, p: str, p_mem: Proof, ctx) -> Proof:
    rel = _and_l(_weaken(src_fun, ctx))
    rp = _forall_elim(rel, p)
    exx = _imp_elim(rp, _weaken(p_mem, ctx))
    assert isinstance(exx.conclusion, Exists)
    X = 'X_' + src_name + dst_name + p
    instX = substitute(exx.conclusion.body, exx.conclusion.var, V(X))
    ctxX = ctx + (instX,)
    hX = _assume(instX, ctxX)
    Xd = _and_l(hX)
    exy = _and_r(hX)
    assert isinstance(exy.conclusion, Exists)
    Y = 'Y_' + src_name + dst_name + p
    instY = substitute(exy.conclusion.body, exy.conclusion.var, V(Y))
    ctxY = ctxX + (instY,)
    hY = _assume(instY, ctxY)
    Yc = _and_l(hY)
    op_pXY = _and_r(hY)
    gv_src_Y = _gv_from_pair(src_name, X, Y, p, _weaken(p_mem, ctxY), op_pXY, ctxY)
    cvx = _forall_elim(_weaken(common, ctxY), X)
    exz = _imp_elim(cvx, _weaken(Xd, ctxY))
    assert isinstance(exz.conclusion, Exists)
    Z = 'Z_' + src_name + dst_name + p
    instZ = substitute(exz.conclusion.body, exz.conclusion.var, V(Z))
    ctxZ = ctxY + (instZ,)
    hZ = _assume(instZ, ctxZ)
    Zc = _and_l(hZ)
    gvs = _and_r(hZ)
    if src_name == 'f':
        gv_src_Z = _and_l(gvs)
        gv_dst_Z = _and_r(gvs)
    else:
        gv_src_Z = _and_r(gvs)
        gv_dst_Z = _and_l(gvs)
    eqYZ = _function_unique_instance(_weaken(src_fun, ctxZ), X, Y, Z, _weaken(Xd, ctxZ), _weaken(Yc, ctxZ), Zc, _weaken(gv_src_Y, ctxZ), gv_src_Z, ctxZ)
    assert isinstance(gv_dst_Z.conclusion, Exists)
    Q = 'Q_' + src_name + dst_name + p
    instQ = substitute(gv_dst_Z.conclusion.body, gv_dst_Z.conclusion.var, V(Q))
    ctxQ = ctxZ + (instQ,)
    hQ = _assume(instQ, ctxQ)
    QinDst = _and_l(hQ)
    op_qXZ = _and_r(hQ)
    op_qXY_concl = substitute(op_qXZ.conclusion, Z, V(Y))
    op_qXY = Proof('eq_subst', op_qXY_concl, ctxQ, (_weaken(eqYZ, ctxQ), op_qXZ), (('direction', 'rl'),))
    uq = _weaken(opuniq, ctxQ)
    for nm in [p, Q, X, Y]:
        uq = _forall_elim(uq, nm)
    eqpQ = _imp_elim(uq, Proof('and_intro', uq.conclusion.left, ctxQ, (_weaken(op_pXY, ctxQ), op_qXY)))
    pinDst = Proof('eq_subst', Mem(V(p), V(dst_name)), ctxQ, (eqpQ, QinDst), (('direction', 'rl'),))
    afterQ = Proof('exists_elim', Mem(V(p), V(dst_name)), ctxZ, (gv_dst_Z, pinDst), (('eigenvar', Q),))
    afterZ = Proof('exists_elim', Mem(V(p), V(dst_name)), ctxY, (exz, afterQ), (('eigenvar', Z),))
    afterY = Proof('exists_elim', Mem(V(p), V(dst_name)), ctxX, (exy, afterZ), (('eigenvar', Y),))
    return Proof('exists_elim', Mem(V(p), V(dst_name)), ctx, (exx, afterY), (('eigenvar', X),))

def build_function_common_value_extensionality(opuniq_pf: Proof | None=None) -> Proof:
    opuniq_pf = opuniq_pf or build_ordered_pair_code_unique()
    goal = function_common_value_extensionality_formula()
    core = goal.body.body.body.body
    prem = core.left
    ctx = (prem,)
    hp = _assume(prem, ctx)
    ff = _and_l(hp)
    rest = _and_r(hp)
    hh = _and_l(rest)
    cv = _and_r(rest)
    ext = _forall_elim(_forall_elim(_ax('EXTENSIONALITY', ctx), 'f'), 'h')
    need = ext.conclusion.left
    p = need.var
    pmf = Mem(V(p), V('f'))
    pmh = Mem(V(p), V('h'))
    ctxf = ctx + (pmf,)
    hfmem = _assume(pmf, ctxf)
    f2h = _membership_transfer(_weaken(ff, ctxf), _weaken(hh, ctxf), _weaken(cv, ctxf), _weaken(opuniq_pf, ctxf), 'f', 'h', 'd', 'c', p, hfmem, ctxf)
    ifh = Proof('imp_intro', Imp(pmf, pmh), ctx, (f2h,))
    ctxh = ctx + (pmh,)
    hhmem = _assume(pmh, ctxh)
    h2f = _membership_transfer(_weaken(hh, ctxh), _weaken(ff, ctxh), _weaken(cv, ctxh), _weaken(opuniq_pf, ctxh), 'h', 'f', 'd', 'c', p, hhmem, ctxh)
    ihf = Proof('imp_intro', Imp(pmh, pmf), ctx, (h2f,))
    iff = Proof('iff_intro', Iff(pmf, pmh), ctx, (ifh, ihf))
    allp = Proof('forall_intro', need, ctx, (iff,))
    eq = _imp_elim(ext, allp)
    imp = Proof('imp_intro', core, (), (eq,))
    qc = Proof('forall_intro', goal.body.body.body, (), (imp,))
    qd = Proof('forall_intro', goal.body.body, (), (qc,))
    qh = Proof('forall_intro', goal.body, (), (qd,))
    return Proof('forall_intro', goal, (), (qh,))
PASS006_STAGE = 'FUNCTION_EXTensionality_PREREQUISITE'

def singleton_spec_unique_formula() -> Formula:
    x, a, b = (V('x'), V('a'), V('b'))
    return Forall('x', Forall('a', Forall('b', Imp(And(SingletonSpec(a, x, 'z'), SingletonSpec(b, x, 'u')), Eq(a, b)))))

def build_singleton_spec_unique() -> Proof:
    goal = singleton_spec_unique_formula()
    core = goal.body.body.body
    prem = core.left
    ctx = (prem,)
    hp = _assume(prem, ctx)
    sa = _and_l(hp)
    sb = _and_r(hp)
    ext = _forall_elim(_forall_elim(_ax('EXTENSIONALITY', ctx), 'a'), 'b')
    need = ext.conclusion.left
    z = need.var
    ma = Mem(V(z), V('a'))
    mb = Mem(V(z), V('b'))
    qa = _forall_elim(sa, z)
    qb = _forall_elim(sb, z)
    ctxa = ctx + (ma,)
    hma = _assume(ma, ctxa)
    eqx = _imp_elim(_weaken(_iff_l(qa), ctxa), hma)
    mbp = _imp_elim(_weaken(_iff_r(qb), ctxa), eqx)
    iab = Proof('imp_intro', Imp(ma, mb), ctx, (mbp,))
    ctxb = ctx + (mb,)
    hmb = _assume(mb, ctxb)
    eqx2 = _imp_elim(_weaken(_iff_l(qb), ctxb), hmb)
    mapf = _imp_elim(_weaken(_iff_r(qa), ctxb), eqx2)
    iba = Proof('imp_intro', Imp(mb, ma), ctx, (mapf,))
    iff = Proof('iff_intro', Iff(ma, mb), ctx, (iab, iba))
    allz = Proof('forall_intro', need, ctx, (iff,))
    eq = _imp_elim(ext, allz)
    imp = Proof('imp_intro', core, (), (eq,))
    qbnd = Proof('forall_intro', goal.body.body, (), (imp,))
    qa2 = Proof('forall_intro', goal.body, (), (qbnd,))
    return Proof('forall_intro', goal, (), (qa2,))

def ordered_pair_code_unique_formula() -> Formula:
    p, q, x, y = map(V, ['p', 'q', 'x', 'y'])
    return Forall('p', Forall('q', Forall('x', Forall('y', Imp(And(OrderedPairCode(p, x, y, 'a', 'b'), OrderedPairCode(q, x, y, 'c', 'd')), Eq(p, q))))))

def build_ordered_pair_code_unique(singleton_unique_pf: Proof | None=None, pair_unique_pf: Proof | None=None) -> Proof:
    from .mathematics_library import build_pair_unique
    singleton_unique_pf = singleton_unique_pf or build_singleton_spec_unique()
    pair_unique_pf = pair_unique_pf or build_pair_unique()
    goal = ordered_pair_code_unique_formula()
    core = goal.body.body.body.body
    prem = core.left
    ctx0 = (prem,)
    hp = _assume(prem, ctx0)
    op1 = _and_l(hp)
    op2 = _and_r(hp)
    A = 'Aop'
    instA = substitute(op1.conclusion.body, op1.conclusion.var, V(A))
    ctxA = ctx0 + (instA,)
    hA = _assume(instA, ctxA)
    B = 'Bop'
    instB = substitute(hA.conclusion.body, hA.conclusion.var, V(B))
    ctxB = ctxA + (instB,)
    hB = _assume(instB, ctxB)
    sA = _and_l(hB)
    rest1 = _and_r(hB)
    pB = _and_l(rest1)
    outerP = _and_r(rest1)
    op2b = _weaken(op2, ctxB)
    C = 'Cop'
    instC = substitute(op2b.conclusion.body, op2b.conclusion.var, V(C))
    ctxC = ctxB + (instC,)
    hC = _assume(instC, ctxC)
    D = 'Dop'
    instD = substitute(hC.conclusion.body, hC.conclusion.var, V(D))
    ctxD = ctxC + (instD,)
    hD = _assume(instD, ctxD)
    sC = _and_l(hD)
    rest2 = _and_r(hD)
    pD = _and_l(rest2)
    outerQ = _and_r(rest2)
    su = _weaken(singleton_unique_pf, ctxD)
    for nm in ['x', A, C]:
        su = _forall_elim(su, nm)
    eqAC = _imp_elim(su, Proof('and_intro', su.conclusion.left, ctxD, (_weaken(sA, ctxD), sC)))
    pu = _weaken(pair_unique_pf, ctxD)
    for nm in ['x', 'y', B, D]:
        pu = _forall_elim(pu, nm)
    eqBD = _imp_elim(pu, Proof('and_intro', pu.conclusion.left, ctxD, (_weaken(pB, ctxD), pD)))
    qAB1_concl = substitute(outerQ.conclusion, C, V(A))
    qAB1 = Proof('eq_subst', qAB1_concl, ctxD, (eqAC, outerQ), (('direction', 'rl'),))
    qAB_concl = substitute(qAB1.conclusion, D, V(B))
    qAB = Proof('eq_subst', qAB_concl, ctxD, (eqBD, qAB1), (('direction', 'rl'),))
    outu = _weaken(pair_unique_pf, ctxD)
    for nm in [A, B, 'p', 'q']:
        outu = _forall_elim(outu, nm)
    eqpq = _imp_elim(outu, Proof('and_intro', outu.conclusion.left, ctxD, (_weaken(outerP, ctxD), qAB)))
    afterD = Proof('exists_elim', Eq(V('p'), V('q')), ctxC, (hC, eqpq), (('eigenvar', D),))
    afterC = Proof('exists_elim', Eq(V('p'), V('q')), ctxB, (op2b, afterD), (('eigenvar', C),))
    afterB = Proof('exists_elim', Eq(V('p'), V('q')), ctxA, (hA, afterC), (('eigenvar', B),))
    afterA = Proof('exists_elim', Eq(V('p'), V('q')), ctx0, (op1, afterB), (('eigenvar', A),))
    imp = Proof('imp_intro', core, (), (afterA,))
    qy = Proof('forall_intro', goal.body.body.body, (), (imp,))
    qx = Proof('forall_intro', goal.body.body, (), (qy,))
    qq = Proof('forall_intro', goal.body, (), (qx,))
    return Proof('forall_intro', goal, (), (qq,))
from .mathematics_library import OmegaSpec
from .arithmetic_library import PASS005_SCHEMA_INSTANCES, build_omega_induction_subset
from .axioms import SchemaInstance

def CommonAtSpec(n: Term, f: Term, h: Term, c: Term, y: str='y') -> Formula:
    return Exists(y, And(Mem(V(y), c), And(GraphValueSpec(f, n, V(y), 'q'), GraphValueSpec(h, n, V(y), 'r'))))

def RecursionCandidateSpec(f: Term, w: Term, c: Term, a: Term, g: Term, z: str='z', n: str='n', s: str='s', x: str='x', y: str='y') -> Formula:
    fun = FunctionGraphSpec(f, w, c, 'pf', 'xf', 'yf', 'yf2')
    initial = Forall(z, Imp(EmptySpec(V(z), 'u'), GraphValueSpec(f, V(z), a, 'pi')))
    step_ante = And(Mem(V(n), w), And(Mem(V(s), w), And(SuccessorSpec(V(s), V(n), 'u'), And(GraphValueSpec(f, V(n), V(x), 'pn'), GraphValueSpec(g, V(x), V(y), 'pg')))))
    step = Forall(n, Forall(s, Forall(x, Forall(y, Imp(step_ante, GraphValueSpec(f, V(s), V(y), 'ps'))))))
    return And(fun, And(initial, step))

def omega_recursion_uniqueness_formula() -> Formula:
    w, c, a, g, f, h = map(V, ['w', 'c', 'a', 'g', 'f', 'h'])
    om = OmegaSpec(w, 'j', 'k')
    gf = FunctionGraphSpec(g, c, c, 'pg', 'xg', 'yg', 'yg2')
    rf = RecursionCandidateSpec(f, w, c, a, g, 'zf', 'nf', 'sf', 'xf', 'yf')
    rh = RecursionCandidateSpec(h, w, c, a, g, 'zh', 'nh', 'sh', 'xh', 'yh')
    prem = And(om, And(Mem(a, c), And(gf, And(rf, rh))))
    return Forall('w', Forall('c', Forall('a', Forall('g', Forall('f', Forall('h', Imp(prem, Eq(f, h))))))))
AGREEMENT_SEPARATION_SCHEMA = SchemaInstance('SEPARATION', CommonAtSpec(V('n'), V('f'), V('h'), V('c'), 'y'), source_var='n', parameters=('f', 'h', 'c'))
PASS006_SCHEMA_INSTANCES = tuple(PASS005_SCHEMA_INSTANCES) + (AGREEMENT_SEPARATION_SCHEMA,)

def _rec_parts(rec: Proof, ctx):
    q = _weaken(rec, ctx)
    fun = _and_l(q)
    rr = _and_r(q)
    initial = _and_l(rr)
    step = _and_r(rr)
    return (fun, initial, step)

def _apply_rec_step(step: Proof, n: str, s: str, x: str, y: str, nw: Proof, sw: Proof, succ: Proof, gvf: Proof, gvg: Proof, ctx) -> Proof:
    q = _weaken(step, ctx)
    for nm in [n, s, x, y]:
        q = _forall_elim(q, nm)
    ante = q.conclusion.left
    last = Proof('and_intro', ante.right.right.right, ctx, (_weaken(gvf, ctx), _weaken(gvg, ctx)))
    c2 = Proof('and_intro', ante.right.right, ctx, (_weaken(succ, ctx), last))
    c1 = Proof('and_intro', ante.right, ctx, (_weaken(sw, ctx), c2))
    allc = Proof('and_intro', ante, ctx, (_weaken(nw, ctx), c1))
    return _imp_elim(q, allc)

def build_omega_recursion_uniqueness(agreement_schema_index: int=5, omega_induction_pf: Proof | None=None, function_ext_pf: Proof | None=None) -> Proof:
    omega_induction_pf = omega_induction_pf or build_omega_induction_subset()
    function_ext_pf = function_ext_pf or build_function_common_value_extensionality()
    goal = omega_recursion_uniqueness_formula()
    core = goal.body.body.body.body.body.body
    prem = core.left
    ctx0 = (prem,)
    hp = _assume(prem, ctx0)
    om = _and_l(hp)
    r1 = _and_r(hp)
    ac = _and_l(r1)
    r2 = _and_r(r1)
    gfun = _and_l(r2)
    r3 = _and_r(r2)
    rf = _and_l(r3)
    rh = _and_r(r3)
    ffun, finit, fstep = _rec_parts(rf, ctx0)
    hfun, hinit, hstep = _rec_parts(rh, ctx0)
    ax = Proof('axiom_schema', AGREEMENT_SEPARATION_SCHEMA.generated(), ctx0, (), (('schema_index', agreement_schema_index),))
    q = ax
    for nm in ['f', 'h', 'c', 'w']:
        q = _forall_elim(q, nm)
    assert isinstance(q.conclusion, Exists)
    E = 'Eagree'
    specE = substitute(q.conclusion.body, q.conclusion.var, V(E))
    ctxE = ctx0 + (specE,)
    hE = _assume(specE, ctxE)
    subset = SubsetSpec(V(E), V('w'), 'nsub')
    nsub = subset.var
    impS = subset.body
    ctxN = ctxE + (impS.left,)
    hNE = _assume(impS.left, ctxN)
    sepN = _forall_elim(_weaken(hE, ctxN), nsub)
    rhsN = _imp_elim(_iff_l(sepN), hNE)
    Nw = _and_l(rhsN)
    isub = Proof('imp_intro', impS, ctxE, (Nw,))
    subpf = Proof('forall_intro', subset, ctxE, (isub,))
    wind = _and_l(_weaken(om, ctxE))
    ex0 = _and_l(wind)
    assert isinstance(ex0.conclusion, Exists)
    Z = 'Z0'
    instZ = substitute(ex0.conclusion.body, ex0.conclusion.var, V(Z))
    ctxZ = ctxE + (instZ,)
    hZ = _assume(instZ, ctxZ)
    Zw = _and_l(hZ)
    emptyZ = _and_r(hZ)
    qfi = _forall_elim(_weaken(finit, ctxZ), Z)
    gvf0 = _imp_elim(qfi, _weaken(emptyZ, ctxZ))
    qhi = _forall_elim(_weaken(hinit, ctxZ), Z)
    gvh0 = _imp_elim(qhi, _weaken(emptyZ, ctxZ))
    commonZ = CommonAtSpec(V(Z), V('f'), V('h'), V('c'), 'y')
    instA = substitute(commonZ.body, commonZ.var, V('a'))
    pairA = Proof('and_intro', instA.right, ctxZ, (gvf0, gvh0))
    bodyA = Proof('and_intro', instA, ctxZ, (_weaken(ac, ctxZ), pairA))
    exA = Proof('exists_intro', commonZ, ctxZ, (bodyA,), (('term', {'var': 'a'}),))
    sepZ = _forall_elim(_weaken(hE, ctxZ), Z)
    rhsZ = Proof('and_intro', sepZ.conclusion.right, ctxZ, (_weaken(Zw, ctxZ), exA))
    ZE = _imp_elim(_iff_r(sepZ), rhsZ)
    emptyMemberGoal = Exists('e', And(Mem(V('e'), V(E)), EmptySpec(V('e'), 'z')))
    instEmp = substitute(emptyMemberGoal.body, emptyMemberGoal.var, V(Z))
    cEmp = Proof('and_intro', instEmp, ctxZ, (ZE, _weaken(emptyZ, ctxZ)))
    exEmp = Proof('exists_intro', emptyMemberGoal, ctxZ, (cEmp,), (('term', {'var': Z}),))
    baseE = Proof('exists_elim', emptyMemberGoal, ctxE, (ex0, exEmp), (('eigenvar', Z),))
    closed = Forall('n', Imp(Mem(V('n'), V(E)), Exists('s', And(Mem(V('s'), V(E)), SuccessorSpec(V('s'), V('n'), 'z')))))
    n = 'n'
    impC = closed.body
    ctxn = ctxE + (impC.left,)
    hnE = _assume(impC.left, ctxn)
    sep_n = _forall_elim(_weaken(hE, ctxn), n)
    rhs_n = _imp_elim(_iff_l(sep_n), hnE)
    nw = _and_l(rhs_n)
    common_n = _and_r(rhs_n)
    assert isinstance(common_n.conclusion, Exists)
    wclosed = _and_r(_and_l(_weaken(om, ctxn)))
    qs = _forall_elim(wclosed, n)
    exs = _imp_elim(qs, nw)
    assert isinstance(exs.conclusion, Exists)
    S = 'Srec'
    instS = substitute(exs.conclusion.body, exs.conclusion.var, V(S))
    ctxS = ctxn + (instS,)
    hS = _assume(instS, ctxS)
    Sw = _and_l(hS)
    succSn = _and_r(hS)
    X = 'Xrec'
    instX = substitute(common_n.conclusion.body, common_n.conclusion.var, V(X))
    ctxX = ctxS + (instX,)
    hX = _assume(instX, ctxX)
    Xc = _and_l(hX)
    valsX = _and_r(hX)
    gvfn = _and_l(valsX)
    gvhn = _and_r(valsX)
    gtotal = _and_l(_and_r(_weaken(gfun, ctxX)))
    qg = _forall_elim(gtotal, X)
    exy = _imp_elim(qg, Xc)
    assert isinstance(exy.conclusion, Exists)
    Y = 'Yrec'
    instY = substitute(exy.conclusion.body, exy.conclusion.var, V(Y))
    ctxY = ctxX + (instY,)
    hY = _assume(instY, ctxY)
    Yc = _and_l(hY)
    gvg = _and_r(hY)
    gvfs = _apply_rec_step(_weaken(fstep, ctxY), n, S, X, Y, _weaken(nw, ctxY), _weaken(Sw, ctxY), _weaken(succSn, ctxY), _weaken(gvfn, ctxY), gvg, ctxY)
    gvhs = _apply_rec_step(_weaken(hstep, ctxY), n, S, X, Y, _weaken(nw, ctxY), _weaken(Sw, ctxY), _weaken(succSn, ctxY), _weaken(gvhn, ctxY), gvg, ctxY)
    commonS = CommonAtSpec(V(S), V('f'), V('h'), V('c'), 'yy')
    instCS = substitute(commonS.body, commonS.var, V(Y))
    pairS = Proof('and_intro', instCS.right, ctxY, (gvfs, gvhs))
    bodyS = Proof('and_intro', instCS, ctxY, (Yc, pairS))
    exCS = Proof('exists_intro', commonS, ctxY, (bodyS,), (('term', {'var': Y}),))
    sepS = _forall_elim(_weaken(hE, ctxY), S)
    rhsS = Proof('and_intro', sepS.conclusion.right, ctxY, (_weaken(Sw, ctxY), exCS))
    SE = _imp_elim(_iff_r(sepS), rhsS)
    outSBody = And(Mem(V(S), V(E)), SuccessorSpec(V(S), V(n), 'z'))
    outS = Proof('and_intro', outSBody, ctxY, (SE, _weaken(succSn, ctxY)))
    exSE = Proof('exists_intro', impC.right, ctxY, (outS,), (('term', {'var': S}),))
    afterY = Proof('exists_elim', impC.right, ctxX, (exy, exSE), (('eigenvar', Y),))
    afterX = Proof('exists_elim', impC.right, ctxS, (_weaken(common_n, ctxS), afterY), (('eigenvar', X),))
    afterS = Proof('exists_elim', impC.right, ctxn, (exs, afterX), (('eigenvar', S),))
    ic = Proof('imp_intro', impC, ctxE, (afterS,))
    closepf = Proof('forall_intro', closed, ctxE, (ic,))
    indE = InductiveSetSpec(V(E), 'e', 'n', 's', 'z')
    indpf = Proof('and_intro', indE, ctxE, (baseE, closepf))
    oi = _weaken(omega_induction_pf, ctxE)
    for nm in ['w', E]:
        oi = _forall_elim(oi, nm)
    ante = oi.conclusion.left
    restind = Proof('and_intro', ante.right, ctxE, (subpf, indpf))
    allind = Proof('and_intro', ante, ctxE, (_weaken(om, ctxE), restind))
    eqEw = _imp_elim(oi, allind)
    cv = CommonValueSpec(V('f'), V('h'), V('w'), V('c'), 'ncv', 'ycv')
    ncv = cv.var
    impcv = cv.body
    ctxcv = ctxE + (impcv.left,)
    hnW = _assume(impcv.left, ctxcv)
    nE = Proof('eq_subst', Mem(V(ncv), V(E)), ctxcv, (_weaken(eqEw, ctxcv), hnW), (('direction', 'rl'),))
    sepCV = _forall_elim(_weaken(hE, ctxcv), ncv)
    rhsCV = _imp_elim(_iff_l(sepCV), nE)
    commonCV = _and_r(rhsCV)
    icv = Proof('imp_intro', impcv, ctxE, (commonCV,))
    cvpf = Proof('forall_intro', cv, ctxE, (icv,))
    fe = _weaken(function_ext_pf, ctxE)
    for nm in ['f', 'h', 'w', 'c']:
        fe = _forall_elim(fe, nm)
    fante = fe.conclusion.left
    rr = Proof('and_intro', fante.right, ctxE, (_weaken(hfun, ctxE), cvpf))
    fa = Proof('and_intro', fante, ctxE, (_weaken(ffun, ctxE), rr))
    eqfh = _imp_elim(fe, fa)
    afterE = Proof('exists_elim', Eq(V('f'), V('h')), ctx0, (q, eqfh), (('eigenvar', E),))
    imp = Proof('imp_intro', core, (), (afterE,))
    qh = Proof('forall_intro', goal.body.body.body.body.body, (), (imp,))
    qf = Proof('forall_intro', goal.body.body.body.body, (), (qh,))
    qg = Proof('forall_intro', goal.body.body.body, (), (qf,))
    qa = Proof('forall_intro', goal.body.body, (), (qg,))
    qc = Proof('forall_intro', goal.body, (), (qa,))
    return Proof('forall_intro', goal, (), (qc,))

def omega_recursion_existence_formula() -> Formula:
    w, c, a, g = map(V, ['w', 'c', 'a', 'g'])
    base = And(OmegaSpec(w, 'j', 'k'), And(Mem(a, c), FunctionGraphSpec(g, c, c, 'pg', 'xg', 'yg', 'yg2')))
    return Forall('w', Forall('c', Forall('a', Forall('g', Imp(base, Exists('f', RecursionCandidateSpec(V('f'), w, c, a, g, 'zf', 'nf', 'sf', 'xf', 'yf')))))))

def omega_recursion_unique_if_exists_formula() -> Formula:
    w, c, a, g = map(V, ['w', 'c', 'a', 'g'])
    base = And(OmegaSpec(w, 'j', 'k'), And(Mem(a, c), FunctionGraphSpec(g, c, c, 'pg', 'xg', 'yg', 'yg2')))
    candf = RecursionCandidateSpec(V('f'), w, c, a, g, 'zf', 'nf', 'sf', 'xf', 'yf')
    candh = RecursionCandidateSpec(V('h'), w, c, a, g, 'zh', 'nh', 'sh', 'xh', 'yh')
    unique = Forall('h', Imp(candh, Eq(V('h'), V('f'))))
    return Forall('w', Forall('c', Forall('a', Forall('g', Imp(base, Imp(Exists('f', candf), Exists('f', And(candf, unique))))))))

def build_omega_recursion_unique_if_exists(rec_unique_pf: Proof | None=None) -> Proof:
    rec_unique_pf = rec_unique_pf or build_omega_recursion_uniqueness()
    goal = omega_recursion_unique_if_exists_formula()
    outer = goal.body.body.body.body
    base = outer.left
    eximp = outer.right
    ctxb = (base,)
    hbase = _assume(base, ctxb)
    ctxe = ctxb + (eximp.left,)
    hex = _assume(eximp.left, ctxe)
    F = 'Frec'
    candF = substitute(hex.conclusion.body, hex.conclusion.var, V(F))
    ctxF = ctxe + (candF,)
    hF = _assume(candF, ctxF)
    targetF = substitute(eximp.right.body, eximp.right.var, V(F))
    unique = targetF.right
    H = 'h'
    impH = unique.body
    ctxH = ctxF + (impH.left,)
    hH = _assume(impH.left, ctxH)
    ru = _weaken(rec_unique_pf, ctxH)
    for nm in ['w', 'c', 'a', 'g', F, H]:
        ru = _forall_elim(ru, nm)
    om = _and_l(_weaken(hbase, ctxH))
    br = _and_r(_weaken(hbase, ctxH))
    ac = _and_l(br)
    gf = _and_r(br)
    tail = Proof('and_intro', ru.conclusion.left.right.right.right, ctxH, (_weaken(hF, ctxH), hH))
    mid = Proof('and_intro', ru.conclusion.left.right.right, ctxH, (gf, tail))
    rr = Proof('and_intro', ru.conclusion.left.right, ctxH, (ac, mid))
    allp = Proof('and_intro', ru.conclusion.left, ctxH, (om, rr))
    eqFH = _imp_elim(ru, allp)
    eqHF = Proof('eq_symm', Eq(V(H), V(F)), ctxH, (eqFH,))
    ih = Proof('imp_intro', impH, ctxF, (eqHF,))
    qh = Proof('forall_intro', unique, ctxF, (ih,))
    both = Proof('and_intro', targetF, ctxF, (hF, qh))
    exF = Proof('exists_intro', eximp.right, ctxF, (both,), (('term', {'var': F}),))
    afterF = Proof('exists_elim', eximp.right, ctxe, (hex, exF), (('eigenvar', F),))
    i2 = Proof('imp_intro', eximp, ctxb, (afterF,))
    i1 = Proof('imp_intro', outer, (), (i2,))
    qg = Proof('forall_intro', goal.body.body.body, (), (i1,))
    qa = Proof('forall_intro', goal.body.body, (), (qg,))
    qc = Proof('forall_intro', goal.body, (), (qa,))
    return Proof('forall_intro', goal, (), (qc,))

def _preverified_pass006(records):
    from .semantic import NormalizedLibraryEntry
    return tuple((NormalizedLibraryEntry(r.proof, r.identity, (r.name,) if r.name else (), (str(r.kind),) if r.kind else ()) for r in records))

def build_pass006_library(schema_prefix: tuple[SchemaInstance, ...]=()) -> tuple[CertifiedStatement, ...]:
    from .arithmetic_library import build_pass005_library, PASS005_FULL_LIBRARY
    offset = len(schema_prefix)
    schemas = tuple(schema_prefix) + PASS006_SCHEMA_INSTANCES
    k = ZFCKernel(schemas)
    base = list(PASS005_FULL_LIBRARY if not schema_prefix else build_pass005_library(schema_prefix))
    su = build_singleton_spec_unique()
    opu = build_ordered_pair_code_unique(su)
    fext = build_function_common_value_extensionality(opu)
    runiq = build_omega_recursion_uniqueness(offset + 5, function_ext_pf=fext)
    uie = build_omega_recursion_unique_if_exists(runiq)
    cex = build_omega_constant_step_recursion_exists()
    cuq = build_omega_constant_step_recursion_unique(cex, runiq)
    extra = [('ZFC_SINGLETON_SPEC_UNIQUE', 'lemma', su), ('ZFC_KURATOWSKI_CODE_UNIQUE', 'theorem', opu), ('ZFC_FUNCTION_COMMON_VALUE_EXTENSIONALITY', 'proposition', fext), ('ZFC_OMEGA_RECURSION_UNIQUENESS', 'theorem', runiq), ('ZFC_OMEGA_RECURSION_UNIQUE_IF_EXISTS', 'corollary', uie), ('ZFC_OMEGA_CONSTANT_STEP_RECURSION_EXISTS', 'theorem', cex), ('ZFC_OMEGA_CONSTANT_STEP_RECURSION_UNIQUE', 'corollary', cuq)]
    for name, kind, p in extra:
        kr = k.verify(p)
        if not kr.ok:
            raise ValueError(f'PASS006_KERNEL_REJECT:{name}:{kr.detail}')
        base.append(CertifiedStatement(p, name=name, kind=kind, source='PASS006_RECURSION_LIBRARY'))
    return tuple(base)

def ConstantStepSpec(g: Term, a: Term, x: str='x', y: str='y') -> Formula:
    return Forall(x, Forall(y, Imp(GraphValueSpec(g, V(x), V(y), 'p'), Eq(V(y), a))))

def omega_constant_step_recursion_exists_formula() -> Formula:
    w, c, a, g = map(V, ['w', 'c', 'a', 'g'])
    base = And(OmegaSpec(w, 'j', 'k'), And(Mem(a, c), And(FunctionGraphSpec(g, c, c, 'pg', 'xg', 'yg', 'yg2'), ConstantStepSpec(g, a, 'x', 'y'))))
    return Forall('w', Forall('c', Forall('a', Forall('g', Imp(base, Exists('f', RecursionCandidateSpec(V('f'), w, c, a, g, 'zf', 'nf', 'sf', 'xf', 'yf')))))))

def build_omega_constant_step_recursion_exists(constant_function_pf: Proof | None=None, empty_unique_pf: Proof | None=None) -> Proof:
    from .arithmetic_library import build_constant_function_exists
    from .derived_library import build_empty_unique
    constant_function_pf = constant_function_pf or build_constant_function_exists()
    empty_unique_pf = empty_unique_pf or build_empty_unique()
    goal = omega_constant_step_recursion_exists_formula()
    core = goal.body.body.body.body
    base = core.left
    target = core.right
    ctx0 = (base,)
    hb = _assume(base, ctx0)
    om = _and_l(hb)
    r1 = _and_r(hb)
    ac = _and_l(r1)
    r2 = _and_r(r1)
    gfun = _and_l(r2)
    cstep = _and_r(r2)
    cf = _weaken(constant_function_pf, ctx0)
    for nm in ['w', 'c', 'a']:
        cf = _forall_elim(cf, nm)
    exf = _imp_elim(cf, ac)
    assert isinstance(exf.conclusion, Exists)
    F = 'Fconstrec'
    specF = substitute(exf.conclusion.body, exf.conclusion.var, V(F))
    ctxF = ctx0 + (specF,)
    hF = _assume(specF, ctxF)
    ffun = _and_l(hF)
    fvals = _and_r(hF)
    rec = RecursionCandidateSpec(V(F), V('w'), V('c'), V('a'), V('g'), 'z', 'n', 's', 'x', 'y')
    init = rec.right.left
    step = rec.right.right
    z = init.var
    impI = init.body
    ctxz = ctxF + (impI.left,)
    hzempty = _assume(impI.left, ctxz)
    wind = _and_l(_weaken(om, ctxz))
    ex0 = _and_l(wind)
    assert isinstance(ex0.conclusion, Exists)
    E = 'E0rec'
    instE = substitute(ex0.conclusion.body, ex0.conclusion.var, V(E))
    ctxE = ctxz + (instE,)
    hE = _assume(instE, ctxE)
    Ew = _and_l(hE)
    Eempty = _and_r(hE)
    eu = _weaken(empty_unique_pf, ctxE)
    for nm in [z, E]:
        eu = _forall_elim(eu, nm)
    eqzE = _imp_elim(eu, Proof('and_intro', eu.conclusion.left, ctxE, (_weaken(hzempty, ctxE), Eempty)))
    zw = Proof('eq_subst', Mem(V(z), V('w')), ctxE, (eqzE, Ew), (('direction', 'rl'),))
    fvz = _forall_elim(_weaken(fvals, ctxE), z)
    gvza = _imp_elim(fvz, zw)
    afterE = Proof('exists_elim', impI.right, ctxz, (ex0, gvza), (('eigenvar', E),))
    iinit = Proof('imp_intro', impI, ctxF, (afterE,))
    initpf = Proof('forall_intro', init, ctxF, (iinit,))
    q = step
    names = [q.var, q.body.var, q.body.body.var, q.body.body.body.var]
    body = q.body.body.body.body
    ctxs = ctxF + (body.left,)
    hs = _assume(body.left, ctxs)
    n, s, x, y = names
    nw = _and_l(hs)
    rr = _and_r(hs)
    sw = _and_l(rr)
    rr2 = _and_r(rr)
    succ = _and_l(rr2)
    vals = _and_r(rr2)
    gvfn = _and_l(vals)
    gvg = _and_r(vals)
    cs = _weaken(cstep, ctxs)
    cs = _forall_elim(_forall_elim(cs, x), y)
    eqa = _imp_elim(cs, gvg)
    fvs = _forall_elim(_weaken(fvals, ctxs), s)
    gvsa = _imp_elim(fvs, sw)
    goalg = body.right
    gvsy = Proof('eq_subst', goalg, ctxs, (eqa, gvsa), (('direction', 'rl'),))
    istep = Proof('imp_intro', body, ctxF, (gvsy,))
    qy = Proof('forall_intro', q.body.body.body, ctxF, (istep,))
    qx = Proof('forall_intro', q.body.body, ctxF, (qy,))
    qs = Proof('forall_intro', q.body, ctxF, (qx,))
    steppf = Proof('forall_intro', q, ctxF, (qs,))
    rest = Proof('and_intro', rec.right, ctxF, (initpf, steppf))
    recpf = Proof('and_intro', rec, ctxF, (ffun, rest))
    exrec = Proof('exists_intro', target, ctxF, (recpf,), (('term', {'var': F}),))
    afterF = Proof('exists_elim', target, ctx0, (exf, exrec), (('eigenvar', F),))
    imp = Proof('imp_intro', core, (), (afterF,))
    qg = Proof('forall_intro', goal.body.body.body, (), (imp,))
    qa = Proof('forall_intro', goal.body.body, (), (qg,))
    qc = Proof('forall_intro', goal.body, (), (qa,))
    return Proof('forall_intro', goal, (), (qc,))

def omega_constant_step_recursion_unique_formula() -> Formula:
    w, c, a, g = map(V, ['w', 'c', 'a', 'g'])
    base = And(OmegaSpec(w, 'j', 'k'), And(Mem(a, c), And(FunctionGraphSpec(g, c, c, 'pg', 'xg', 'yg', 'yg2'), ConstantStepSpec(g, a, 'x', 'y'))))
    cand = RecursionCandidateSpec(V('f'), w, c, a, g, 'zf', 'nf', 'sf', 'xf', 'yf')
    uniq = Forall('h', Imp(RecursionCandidateSpec(V('h'), w, c, a, g, 'zh', 'nh', 'sh', 'xh', 'yh'), Eq(V('h'), V('f'))))
    return Forall('w', Forall('c', Forall('a', Forall('g', Imp(base, Exists('f', And(cand, uniq)))))))

def build_omega_constant_step_recursion_unique(exists_pf: Proof | None=None, rec_unique_pf: Proof | None=None) -> Proof:
    exists_pf = exists_pf or build_omega_constant_step_recursion_exists()
    rec_unique_pf = rec_unique_pf or build_omega_recursion_uniqueness()
    goal = omega_constant_step_recursion_unique_formula()
    core = goal.body.body.body.body
    base = core.left
    target = core.right
    ctx = (base,)
    hb = _assume(base, ctx)
    ex = _weaken(exists_pf, ctx)
    for nm in ['w', 'c', 'a', 'g']:
        ex = _forall_elim(ex, nm)
    ex = _imp_elim(ex, hb)
    assert isinstance(ex.conclusion, Exists)
    F = 'Fconstuniq'
    candF = substitute(ex.conclusion.body, ex.conclusion.var, V(F))
    ctxF = ctx + (candF,)
    hF = _assume(candF, ctxF)
    tF = substitute(target.body, target.var, V(F))
    uq = tF.right
    H = uq.var
    impH = uq.body
    ctxH = ctxF + (impH.left,)
    hH = _assume(impH.left, ctxH)
    om = _and_l(_weaken(hb, ctxH))
    rr = _and_r(_weaken(hb, ctxH))
    ac = _and_l(rr)
    r2 = _and_r(rr)
    gf = _and_l(r2)
    ru = _weaken(rec_unique_pf, ctxH)
    for nm in ['w', 'c', 'a', 'g', F, H]:
        ru = _forall_elim(ru, nm)
    tail = Proof('and_intro', ru.conclusion.left.right.right.right, ctxH, (_weaken(hF, ctxH), hH))
    mid = Proof('and_intro', ru.conclusion.left.right.right, ctxH, (gf, tail))
    rr3 = Proof('and_intro', ru.conclusion.left.right, ctxH, (ac, mid))
    allp = Proof('and_intro', ru.conclusion.left, ctxH, (om, rr3))
    eqFH = _imp_elim(ru, allp)
    eqHF = Proof('eq_symm', Eq(V(H), V(F)), ctxH, (eqFH,))
    ih = Proof('imp_intro', impH, ctxF, (eqHF,))
    qu = Proof('forall_intro', uq, ctxF, (ih,))
    both = Proof('and_intro', tF, ctxF, (hF, qu))
    ext = Proof('exists_intro', target, ctxF, (both,), (('term', {'var': F}),))
    after = Proof('exists_elim', target, ctx, (ex, ext), (('eigenvar', F),))
    ip = Proof('imp_intro', core, (), (after,))
    qg = Proof('forall_intro', goal.body.body.body, (), (ip,))
    qa = Proof('forall_intro', goal.body.body, (), (qg,))
    qc = Proof('forall_intro', goal.body, (), (qa,))
    return Proof('forall_intro', goal, (), (qc,))
PASS006_FULL_LIBRARY = build_pass006_library(())
PASS006_NORMALIZED_LIBRARY = _preverified_pass006(PASS006_FULL_LIBRARY)

def successor_injective_formula() -> Formula:
    x, y, s = map(V, ['x', 'y', 's'])
    return Forall('x', Forall('y', Forall('s', Imp(And(SuccessorSpec(s, x, 'u'), SuccessorSpec(s, y, 'v')), Eq(x, y)))))

def _member_of_pair(pair_pf: Proof, elt: str, left: str, right: str, choose_left: bool, ctx) -> Proof:
    q = _forall_elim(_weaken(pair_pf, ctx), elt)
    eq = Proof('eq_refl', Eq(V(elt), V(left if choose_left else right)), ctx)
    disj = Proof('or_intro_left' if choose_left else 'or_intro_right', q.conclusion.right, ctx, (eq,))
    return _imp_elim(_iff_r(q), disj)

def _extract_or_left_with_not_right(disj: Proof, not_right: Proof, target_left: Formula, ctx) -> Proof:
    assert isinstance(disj.conclusion, Or)
    l = disj.conclusion.left
    r = disj.conclusion.right
    ctxL = tuple(ctx) + (l,)
    hl = _assume(l, ctxL)
    ctxR = tuple(ctx) + (r,)
    hr = _assume(r, ctxR)
    bot = _imp_elim(_weaken(not_right, ctxR), hr)
    outR = Proof('bottom_elim', target_left, ctxR, (bot,))
    return Proof('or_elim', target_left, tuple(ctx), (disj, hl, outR))

def build_successor_injective() -> Proof:
    goal = successor_injective_formula()
    core = goal.body.body.body
    prem = core.left
    ctx = (prem,)
    hp = _assume(prem, ctx)
    sx = _and_l(hp)
    sy = _and_r(hp)
    target = Eq(V('x'), V('y'))
    neg = Not(target)
    ctxN = ctx + (neg,)
    hneg = _assume(neg, ctxN)
    qsx = _forall_elim(_weaken(sx, ctxN), 'x')
    rx = Proof('or_intro_right', qsx.conclusion.right, ctxN, (Proof('eq_refl', Eq(V('x'), V('x')), ctxN),))
    xinS = _imp_elim(_iff_r(qsx), rx)
    qsyx = _forall_elim(_weaken(sy, ctxN), 'x')
    dx = _imp_elim(_iff_l(qsyx), xinS)
    xinY = _extract_or_left_with_not_right(dx, hneg, Mem(V('x'), V('y')), ctxN)
    qsy = _forall_elim(_weaken(sy, ctxN), 'y')
    ry = Proof('or_intro_right', qsy.conclusion.right, ctxN, (Proof('eq_refl', Eq(V('y'), V('y')), ctxN),))
    yinS = _imp_elim(_iff_r(qsy), ry)
    qsxy = _forall_elim(_weaken(sx, ctxN), 'y')
    dy = _imp_elim(_iff_l(qsxy), yinS)
    l = dy.conclusion.left
    r = dy.conclusion.right
    ctxL = ctxN + (l,)
    hl = _assume(l, ctxL)
    ctxR = ctxN + (r,)
    hr = _assume(r, ctxR)
    eqxy = Proof('eq_symm', target, ctxR, (hr,))
    botr = _imp_elim(_weaken(hneg, ctxR), eqxy)
    outR = Proof('bottom_elim', Mem(V('y'), V('x')), ctxR, (botr,))
    yinX = Proof('or_elim', Mem(V('y'), V('x')), ctxN, (dy, hl, outR))
    pair = _forall_elim(_forall_elim(_ax('PAIRING', ctxN), 'x'), 'y')
    assert isinstance(pair.conclusion, Exists)
    P = 'Pxy'
    specP = substitute(pair.conclusion.body, pair.conclusion.var, V(P))
    ctxP = ctxN + (specP,)
    hP = _assume(specP, ctxP)
    xinP = _member_of_pair(hP, 'x', 'x', 'y', True, ctxP)
    yinP = _member_of_pair(hP, 'y', 'x', 'y', False, ctxP)
    nonempty = Exists('m', Mem(V('m'), V(P)))
    exx = Proof('exists_intro', nonempty, ctxP, (xinP,), (('term', {'var': 'x'}),))
    found = _forall_elim(_weaken(_ax('FOUNDATION', ctxP), ctxP), P)
    minimal = _imp_elim(found, exx)
    assert isinstance(minimal.conclusion, Exists)
    M = 'Mmin'
    instM = substitute(minimal.conclusion.body, minimal.conclusion.var, V(M))
    ctxM = ctxP + (instM,)
    hM = _assume(instM, ctxM)
    MinP = _and_l(hM)
    nohit = _and_r(hM)
    pm = _forall_elim(_weaken(hP, ctxM), M)
    cases = _imp_elim(_iff_l(pm), MinP)
    eqMx = cases.conclusion.left
    ctxX = ctxM + (eqMx,)
    hMx = _assume(eqMx, ctxX)
    yinM = Proof('eq_subst', Mem(V('y'), V(M)), ctxX, (hMx, _weaken(yinX, ctxX)), (('direction', 'rl'),))
    wi = And(Mem(V('y'), V(M)), Mem(V('y'), V(P)))
    cwi = Proof('and_intro', wi, ctxX, (yinM, _weaken(yinP, ctxX)))
    hit = Exists('z', And(Mem(V('z'), V(M)), Mem(V('z'), V(P))))
    exhit = Proof('exists_intro', hit, ctxX, (cwi,), (('term', {'var': 'y'}),))
    botX = _imp_elim(_weaken(nohit, ctxX), exhit)
    eqMy = cases.conclusion.right
    ctxY = ctxM + (eqMy,)
    hMy = _assume(eqMy, ctxY)
    xinM = Proof('eq_subst', Mem(V('x'), V(M)), ctxY, (hMy, _weaken(xinY, ctxY)), (('direction', 'rl'),))
    wi2 = And(Mem(V('x'), V(M)), Mem(V('x'), V(P)))
    cwi2 = Proof('and_intro', wi2, ctxY, (xinM, _weaken(xinP, ctxY)))
    exhit2 = Proof('exists_intro', hit, ctxY, (cwi2,), (('term', {'var': 'x'}),))
    botY = _imp_elim(_weaken(nohit, ctxY), exhit2)
    botM = Proof('or_elim', FALSE, ctxM, (cases, botX, botY))
    botP = Proof('exists_elim', FALSE, ctxP, (minimal, botM), (('eigenvar', M),))
    bot = Proof('exists_elim', FALSE, ctxN, (pair, botP), (('eigenvar', P),))
    eq = Proof('classical_reductio', target, ctx, (bot,))
    imp = Proof('imp_intro', core, (), (eq,))
    qs = Proof('forall_intro', goal.body.body, (), (imp,))
    qy = Proof('forall_intro', goal.body, (), (qs,))
    return Proof('forall_intro', goal, (), (qy,))

def zero_not_successor_formula() -> Formula:
    e, n = map(V, ['e', 'n'])
    return Forall('e', Forall('n', Imp(EmptySpec(e, 'z'), Not(SuccessorSpec(e, n, 'u')))))

def build_zero_not_successor() -> Proof:
    goal = zero_not_successor_formula()
    core = goal.body.body
    emp = core.left
    ctx = (emp,)
    he = _assume(emp, ctx)
    neg = core.right
    succ = neg.left
    ctxS = ctx + (succ,)
    hs = _assume(succ, ctxS)
    q = _forall_elim(hs, 'n')
    disj = Proof('or_intro_right', q.conclusion.right, ctxS, (Proof('eq_refl', Eq(V('n'), V('n')), ctxS),))
    nin = _imp_elim(_iff_r(q), disj)
    nne = _forall_elim(_weaken(he, ctxS), 'n')
    bot = _imp_elim(nne, nin)
    ns = Proof('imp_intro', neg, ctx, (bot,))
    ie = Proof('imp_intro', core, (), (ns,))
    qn = Proof('forall_intro', goal.body, (), (ie,))
    return Proof('forall_intro', goal, (), (qn,))

def OmegaGeneratedElementSpec(n: Term, w: Term, p: str='p') -> Formula:
    avoid = {n.name, w.name}
    if p in avoid:
        i = 0
        while f'{p}_{i}' in avoid:
            i += 1
        p = f'{p}_{i}'
    return Or(EmptySpec(n, 'z'), Exists(p, And(Mem(V(p), w), SuccessorSpec(n, V(p), 'u'))))
OMEGA_GENERATED_SEPARATION_SCHEMA = SchemaInstance('SEPARATION', OmegaGeneratedElementSpec(V('n'), V('w'), 'p'), source_var='n', parameters=('w',))

def omega_every_element_zero_or_successor_formula() -> Formula:
    w, n = map(V, ['w', 'n'])
    return Forall('w', Imp(OmegaSpec(w, 'j', 'k'), Forall('n', Imp(Mem(n, w), OmegaGeneratedElementSpec(n, w, 'p')))))

def build_omega_every_element_zero_or_successor(schema_index: int=6, omega_induction_pf: Proof | None=None) -> Proof:
    omega_induction_pf = omega_induction_pf or build_omega_induction_subset()
    goal = omega_every_element_zero_or_successor_formula()
    outer = goal.body
    om = outer.left
    ctx = (om,)
    hom = _assume(om, ctx)
    sep = Proof('axiom_schema', OMEGA_GENERATED_SEPARATION_SCHEMA.generated(), ctx, (), (('schema_index', schema_index),))
    sepw = _forall_elim(_forall_elim(sep, 'w'), 'w')
    assert isinstance(sepw.conclusion, Exists)
    K = 'Kgen'
    specK = substitute(sepw.conclusion.body, sepw.conclusion.var, V(K))
    ctxK = ctx + (specK,)
    hK = _assume(specK, ctxK)
    sub = SubsetSpec(V(K), V('w'), 'q')
    q = sub.var
    iq = sub.body
    ctxq = ctxK + (iq.left,)
    hq = _assume(iq.left, ctxq)
    sq = _forall_elim(_weaken(hK, ctxq), q)
    rhs = _imp_elim(_iff_l(sq), hq)
    qw = _and_l(rhs)
    isub = Proof('imp_intro', iq, ctxK, (qw,))
    subpf = Proof('forall_intro', sub, ctxK, (isub,))
    indw = _and_l(_weaken(hom, ctxK))
    ex0 = _and_l(indw)
    assert isinstance(ex0.conclusion, Exists)
    E = 'Egen'
    instE = substitute(ex0.conclusion.body, ex0.conclusion.var, V(E))
    ctxE = ctxK + (instE,)
    hE = _assume(instE, ctxE)
    Ew = _and_l(hE)
    emptyE = _and_r(hE)
    predE = OmegaGeneratedElementSpec(V(E), V('w'), 'p')
    leftPred = Proof('or_intro_left', predE, ctxE, (_weaken(emptyE, ctxE),))
    sepE = _forall_elim(_weaken(hK, ctxE), E)
    rr = Proof('and_intro', sepE.conclusion.right, ctxE, (Ew, leftPred))
    EK = _imp_elim(_iff_r(sepE), rr)
    emptyKgoal = Exists('e', And(Mem(V('e'), V(K)), EmptySpec(V('e'), 'z')))
    bodyE = substitute(emptyKgoal.body, emptyKgoal.var, V(E))
    cE = Proof('and_intro', bodyE, ctxE, (EK, _weaken(emptyE, ctxE)))
    exEK = Proof('exists_intro', emptyKgoal, ctxE, (cE,), (('term', {'var': E}),))
    baseK = Proof('exists_elim', emptyKgoal, ctxK, (ex0, exEK), (('eigenvar', E),))
    closed = Forall('n', Imp(Mem(V('n'), V(K)), Exists('s', And(Mem(V('s'), V(K)), SuccessorSpec(V('s'), V('n'), 'z')))))
    n = closed.var
    ic = closed.body
    ctxn = ctxK + (ic.left,)
    hnK = _assume(ic.left, ctxn)
    sepn = _forall_elim(_weaken(hK, ctxn), n)
    rhsn = _imp_elim(_iff_l(sepn), hnK)
    nw = _and_l(rhsn)
    wclosed = _and_r(_and_l(_weaken(hom, ctxn)))
    qs = _forall_elim(wclosed, n)
    exs = _imp_elim(qs, nw)
    assert isinstance(exs.conclusion, Exists)
    S = 'Sgen'
    instS = substitute(exs.conclusion.body, exs.conclusion.var, V(S))
    ctxS = ctxn + (instS,)
    hS = _assume(instS, ctxS)
    Sw = _and_l(hS)
    succSn = _and_r(hS)
    predS = OmegaGeneratedElementSpec(V(S), V('w'), 'p')
    exPred = predS.right
    pbody = substitute(exPred.body, exPred.var, V(n))
    cp = Proof('and_intro', pbody, ctxS, (_weaken(nw, ctxS), _weaken(succSn, ctxS)))
    exp = Proof('exists_intro', exPred, ctxS, (cp,), (('term', {'var': n}),))
    rightPred = Proof('or_intro_right', predS, ctxS, (exp,))
    sepS = _forall_elim(_weaken(hK, ctxS), S)
    rs = Proof('and_intro', sepS.conclusion.right, ctxS, (Sw, rightPred))
    SK = _imp_elim(_iff_r(sepS), rs)
    ob = substitute(ic.right.body, ic.right.var, V(S))
    cob = Proof('and_intro', ob, ctxS, (SK, _weaken(succSn, ctxS)))
    exout = Proof('exists_intro', ic.right, ctxS, (cob,), (('term', {'var': S}),))
    afterS = Proof('exists_elim', ic.right, ctxn, (exs, exout), (('eigenvar', S),))
    impc = Proof('imp_intro', ic, ctxK, (afterS,))
    closepf = Proof('forall_intro', closed, ctxK, (impc,))
    indK = InductiveSetSpec(V(K), 'e', 'n', 's', 'z')
    indpf = Proof('and_intro', indK, ctxK, (baseK, closepf))
    oi = _weaken(omega_induction_pf, ctxK)
    for nm in ['w', K]:
        oi = _forall_elim(oi, nm)
    ante = oi.conclusion.left
    rr2 = Proof('and_intro', ante.right, ctxK, (subpf, indpf))
    allp = Proof('and_intro', ante, ctxK, (_weaken(hom, ctxK), rr2))
    eqKw = _imp_elim(oi, allp)
    alln = outer.right
    n2 = alln.var
    impn = alln.body
    ctx2 = ctxK + (impn.left,)
    hnW = _assume(impn.left, ctx2)
    nK = Proof('eq_subst', Mem(V(n2), V(K)), ctx2, (_weaken(eqKw, ctx2), hnW), (('direction', 'rl'),))
    sep2 = _forall_elim(_weaken(hK, ctx2), n2)
    rhs2 = _imp_elim(_iff_l(sep2), nK)
    pred = _and_r(rhs2)
    ipin = Proof('imp_intro', impn, ctxK, (pred,))
    allnpf = Proof('forall_intro', alln, ctxK, (ipin,))
    afterK = Proof('exists_elim', alln, ctx, (sepw, allnpf), (('eigenvar', K),))
    iouter = Proof('imp_intro', outer, (), (afterK,))
    return Proof('forall_intro', goal, (), (iouter,))
PASS007_SCHEMA_INSTANCES = tuple(PASS006_SCHEMA_INSTANCES) + (OMEGA_GENERATED_SEPARATION_SCHEMA,)

def AdjoinSpec(b: Term, a: Term, x: Term, z: str='z') -> Formula:
    avoid = {b.name, a.name, x.name}
    if z in avoid:
        i = 0
        while f'{z}_{i}' in avoid:
            i += 1
        z = f'{z}_{i}'
    return Forall(z, Iff(Mem(V(z), b), Or(Mem(V(z), a), Eq(V(z), x))))

def adjoin_exists_formula() -> Formula:
    return Forall('a', Forall('x', Exists('b', AdjoinSpec(V('b'), V('a'), V('x'), 'z'))))

def build_adjoin_exists(singleton_pf: Proof | None=None, binary_union_pf: Proof | None=None) -> Proof:
    from .derived_library import build_singleton_exists
    from .mathematics_library import build_binary_union_exists, BinaryUnionSpec
    singleton_pf = singleton_pf or build_singleton_exists()
    binary_union_pf = binary_union_pf or build_binary_union_exists()
    goal = adjoin_exists_formula()
    body = goal.body.body
    ctx = ()
    a = 'a'
    x = 'x'
    sx = _forall_elim(singleton_pf, x)
    assert isinstance(sx.conclusion, Exists)
    S = 'Sad'
    specS = substitute(sx.conclusion.body, sx.conclusion.var, V(S))
    ctxS = (specS,)
    hS = _assume(specS, ctxS)
    bu = _forall_elim(_forall_elim(_weaken(binary_union_pf, ctxS), a), S)
    assert isinstance(bu.conclusion, Exists)
    B = 'Bad'
    specB = substitute(bu.conclusion.body, bu.conclusion.var, V(B))
    ctxB = ctxS + (specB,)
    hB = _assume(specB, ctxB)
    target = AdjoinSpec(V(B), V(a), V(x), 'z')
    z = target.var
    iff = target.body
    L = iff.left
    R = iff.right
    qb = _forall_elim(hB, z)
    ctxL = ctxB + (L,)
    hL = _assume(L, ctxL)
    disj = _imp_elim(_weaken(_iff_l(qb), ctxL), hL)
    la = disj.conclusion.left
    ctxA = ctxL + (la,)
    hA = _assume(la, ctxA)
    outA = Proof('or_intro_left', R, ctxA, (hA,))
    rs = disj.conclusion.right
    ctxRS = ctxL + (rs,)
    hRS = _assume(rs, ctxRS)
    qs = _forall_elim(_weaken(hS, ctxRS), z)
    eqzx = _imp_elim(_iff_l(qs), hRS)
    outS = Proof('or_intro_right', R, ctxRS, (eqzx,))
    rout = Proof('or_elim', R, ctxL, (disj, outA, outS))
    l2r = Proof('imp_intro', Imp(L, R), ctxB, (rout,))
    ctxR = ctxB + (R,)
    hR = _assume(R, ctxR)
    ma = R.left
    ctxMA = ctxR + (ma,)
    hMA = _assume(ma, ctxMA)
    db = Proof('or_intro_left', qb.conclusion.right, ctxMA, (hMA,))
    outMA = _imp_elim(_weaken(_iff_r(qb), ctxMA), db)
    eq = R.right
    ctxEQ = ctxR + (eq,)
    hEQ = _assume(eq, ctxEQ)
    qs2 = _forall_elim(_weaken(hS, ctxEQ), z)
    zs = _imp_elim(_iff_r(qs2), hEQ)
    db2 = Proof('or_intro_right', qb.conclusion.right, ctxEQ, (zs,))
    outEQ = _imp_elim(_weaken(_iff_r(qb), ctxEQ), db2)
    lout = Proof('or_elim', L, ctxR, (hR, outMA, outEQ))
    r2l = Proof('imp_intro', Imp(R, L), ctxB, (lout,))
    iffpf = Proof('iff_intro', iff, ctxB, (l2r, r2l))
    spec = Proof('forall_intro', target, ctxB, (iffpf,))
    exB = Proof('exists_intro', body, ctxB, (spec,), (('term', {'var': B}),))
    afterB = Proof('exists_elim', body, ctxS, (bu, exB), (('eigenvar', B),))
    afterS = Proof('exists_elim', body, ctx, (sx, afterB), (('eigenvar', S),))
    qx = Proof('forall_intro', goal.body, (), (afterS,))
    return Proof('forall_intro', goal, (), (qx,))

def _adjoin_cases(spec: Proof, elem: str, mempf: Proof, ctx) -> Proof:
    q = _forall_elim(_weaken(spec, ctx), elem)
    return _imp_elim(_iff_l(q), _weaken(mempf, ctx))

def _adjoin_mem_left(spec: Proof, elem: str, mema: Proof, ctx) -> Proof:
    q = _forall_elim(_weaken(spec, ctx), elem)
    dis = Proof('or_intro_left', q.conclusion.right, ctx, (_weaken(mema, ctx),))
    return _imp_elim(_iff_r(q), dis)

def _adjoin_mem_eq(spec: Proof, elem: str, x: str, eq: Proof, ctx) -> Proof:
    q = _forall_elim(_weaken(spec, ctx), elem)
    dis = Proof('or_intro_right', q.conclusion.right, ctx, (_weaken(eq, ctx),))
    return _imp_elim(_iff_r(q), dis)

def function_extend_fresh_formula() -> Formula:
    d, c, f, s, y = map(V, ['d', 'c', 'f', 's', 'y'])
    prem = And(FunctionGraphSpec(f, d, c, 'pf', 'xf', 'yf', 'yf2'), And(Mem(y, c), Not(Mem(s, d))))
    out = Exists('d2', Exists('p', Exists('f2', And(AdjoinSpec(V('d2'), d, s, 'z'), And(OrderedPairCode(V('p'), s, y, 'a', 'b'), And(AdjoinSpec(V('f2'), f, V('p'), 'q'), FunctionGraphSpec(V('f2'), V('d2'), c, 'r', 'u', 'v', 'v2')))))))
    return Forall('d', Forall('c', Forall('f', Forall('s', Forall('y', Imp(prem, out))))))

def build_function_extend_fresh(adjoin_pf: Proof | None=None, ordered_pair_pf: Proof | None=None, opinj_pf: Proof | None=None) -> Proof:
    from .derived_library import build_ordered_pair_code_exists
    adjoin_pf = adjoin_pf or build_adjoin_exists()
    ordered_pair_pf = ordered_pair_pf or build_ordered_pair_code_exists()
    opinj_pf = opinj_pf or build_ordered_pair_injective()
    goal = function_extend_fresh_formula()
    core = goal.body.body.body.body.body
    prem = core.left
    target = core.right
    ctx0 = (prem,)
    hp = _assume(prem, ctx0)
    ffun = _and_l(hp)
    rr = _and_r(hp)
    yc = _and_l(rr)
    nsd = _and_r(rr)
    ad = _weaken(adjoin_pf, ctx0)
    ad = _forall_elim(_forall_elim(ad, 'd'), 's')
    assert isinstance(ad.conclusion, Exists)
    D = 'Dext'
    specD = substitute(ad.conclusion.body, ad.conclusion.var, V(D))
    ctxD = ctx0 + (specD,)
    hD = _assume(specD, ctxD)
    op = _weaken(ordered_pair_pf, ctxD)
    op = _forall_elim(_forall_elim(op, 's'), 'y')
    assert isinstance(op.conclusion, Exists)
    P = 'Pext'
    specP = substitute(op.conclusion.body, op.conclusion.var, V(P))
    ctxP = ctxD + (specP,)
    hP = _assume(specP, ctxP)
    af = _weaken(adjoin_pf, ctxP)
    af = _forall_elim(_forall_elim(af, 'f'), P)
    assert isinstance(af.conclusion, Exists)
    F = 'Fext'
    specF = substitute(af.conclusion.body, af.conclusion.var, V(F))
    ctxF = ctxP + (specF,)
    hF = _assume(specF, ctxF)
    fun = FunctionGraphSpec(V(F), V(D), V('c'), 'r', 'u', 'v', 'v2')
    rel = fun.left
    total = fun.right.left
    unique = fun.right.right
    oldrel = _and_l(_weaken(ffun, ctxF))
    oldtotal = _and_l(_and_r(_weaken(ffun, ctxF)))
    olduniq = _and_r(_and_r(_weaken(ffun, ctxF)))
    pF = _adjoin_mem_eq(hF, P, P, Proof('eq_refl', Eq(V(P), V(P)), ctxF), ctxF)
    sD = _adjoin_mem_eq(hD, 's', 's', Proof('eq_refl', Eq(V('s'), V('s')), ctxF), ctxF)

    def lift_old_gv(gv: Proof, xname: str, zname: str, ctx) -> Proof:
        ex = gv
        assert isinstance(ex.conclusion, Exists)
        Q = 'Qlift' + xname + zname
        inst = substitute(ex.conclusion.body, ex.conclusion.var, V(Q))
        ctxQ = tuple(ctx) + (inst,)
        hq = _assume(inst, ctxQ)
        qf = _and_l(hq)
        opq = _and_r(hq)
        qF = _adjoin_mem_left(_weaken(hF, ctxQ), Q, qf, ctxQ)
        tgt = GraphValueSpec(V(F), V(xname), V(zname), 'qq')
        body = substitute(tgt.body, tgt.var, V(Q))
        cb = Proof('and_intro', body, ctxQ, (qF, opq))
        exF = Proof('exists_intro', tgt, ctxQ, (cb,), (('term', {'var': Q}),))
        return Proof('exists_elim', tgt, tuple(ctx), (ex, exF), (('eigenvar', Q),))

    def fv_to_old(gvF: Proof, xname: str, zname: str, xD: Proof, ctx) -> Proof:
        ex = gvF
        assert isinstance(ex.conclusion, Exists)
        Q = 'Qold' + xname + zname
        inst = substitute(ex.conclusion.body, ex.conclusion.var, V(Q))
        ctxQ = tuple(ctx) + (inst,)
        hq = _assume(inst, ctxQ)
        qFin = _and_l(hq)
        opqxz = _and_r(hq)
        cases = _adjoin_cases(_weaken(hF, ctxQ), Q, qFin, ctxQ)
        tgt = GraphValueSpec(V('f'), V(xname), V(zname), 'qo')
        l = cases.conclusion.left
        ctxL = ctxQ + (l,)
        hl = _assume(l, ctxL)
        bodyL = substitute(tgt.body, tgt.var, V(Q))
        cL = Proof('and_intro', bodyL, ctxL, (hl, _weaken(opqxz, ctxL)))
        outL = Proof('exists_intro', tgt, ctxL, (cL,), (('term', {'var': Q}),))
        r = cases.conclusion.right
        ctxR = ctxQ + (r,)
        hr = _assume(r, ctxR)
        opP_xz = Proof('eq_subst', OrderedPairCode(V(P), V(xname), V(zname), 'aa', 'bb'), ctxR, (hr, _weaken(opqxz, ctxR)), (('direction', 'lr'),))
        inj = _op_injective_instance(_weaken(opinj_pf, ctxR), P, xname, zname, 's', 'y', opP_xz, _weaken(hP, ctxR), ctxR)
        eqxs = _and_l(inj)
        sDin = Proof('eq_subst', Mem(V('s'), V('d')), ctxR, (eqxs, _weaken(xD, ctxR)), (('direction', 'lr'),))
        bot = _imp_elim(_weaken(nsd, ctxR), sDin)
        outR = Proof('bottom_elim', tgt, ctxR, (bot,))
        out = Proof('or_elim', tgt, ctxQ, (cases, outL, outR))
        return Proof('exists_elim', tgt, tuple(ctx), (ex, out), (('eigenvar', Q),))

    def fv_at_fresh_eq_y(gvF: Proof, zname: str, ctx) -> Proof:
        ex = gvF
        assert isinstance(ex.conclusion, Exists)
        Q = 'Qfresh' + zname
        inst = substitute(ex.conclusion.body, ex.conclusion.var, V(Q))
        ctxQ = tuple(ctx) + (inst,)
        hq = _assume(inst, ctxQ)
        qFin = _and_l(hq)
        opqsz = _and_r(hq)
        cases = _adjoin_cases(_weaken(hF, ctxQ), Q, qFin, ctxQ)
        tgt = Eq(V(zname), V('y'))
        l = cases.conclusion.left
        ctxL = ctxQ + (l,)
        hl = _assume(l, ctxL)
        qr = _forall_elim(_weaken(oldrel, ctxL), Q)
        exu = _imp_elim(qr, hl)
        assert isinstance(exu.conclusion, Exists)
        U = 'Uold' + zname
        iu = substitute(exu.conclusion.body, exu.conclusion.var, V(U))
        ctxU = ctxL + (iu,)
        hu = _assume(iu, ctxU)
        Ud = _and_l(hu)
        exv = _and_r(hu)
        assert isinstance(exv.conclusion, Exists)
        W = 'Wold' + zname
        iv = substitute(exv.conclusion.body, exv.conclusion.var, V(W))
        ctxW = ctxU + (iv,)
        hw = _assume(iv, ctxW)
        Wc = _and_l(hw)
        opqUW = _and_r(hw)
        inj = _op_injective_instance(_weaken(opinj_pf, ctxW), Q, U, W, 's', zname, opqUW, _weaken(opqsz, ctxW), ctxW)
        eqUs = _and_l(inj)
        sDin = Proof('eq_subst', Mem(V('s'), V('d')), ctxW, (eqUs, _weaken(Ud, ctxW)), (('direction', 'lr'),))
        bot = _imp_elim(_weaken(nsd, ctxW), sDin)
        outW = Proof('bottom_elim', tgt, ctxW, (bot,))
        outU = Proof('exists_elim', tgt, ctxU, (exv, outW), (('eigenvar', W),))
        outL = Proof('exists_elim', tgt, ctxL, (exu, outU), (('eigenvar', U),))
        r = cases.conclusion.right
        ctxR = ctxQ + (r,)
        hr = _assume(r, ctxR)
        opPsz = Proof('eq_subst', OrderedPairCode(V(P), V('s'), V(zname), 'aa', 'bb'), ctxR, (hr, _weaken(opqsz, ctxR)), (('direction', 'lr'),))
        inj2 = _op_injective_instance(_weaken(opinj_pf, ctxR), P, 's', zname, 's', 'y', opPsz, _weaken(hP, ctxR), ctxR)
        outR = _and_r(inj2)
        outQ = Proof('or_elim', tgt, ctxQ, (cases, outL, outR))
        return Proof('exists_elim', tgt, tuple(ctx), (ex, outQ), (('eigenvar', Q),))
    q = rel.var
    ir = rel.body
    ctxq = ctxF + (ir.left,)
    hqF = _assume(ir.left, ctxq)
    cases = _adjoin_cases(_weaken(hF, ctxq), q, hqF, ctxq)
    l = cases.conclusion.left
    ctxL = ctxq + (l,)
    hl = _assume(l, ctxL)
    qr = _forall_elim(_weaken(oldrel, ctxL), q)
    exx = _imp_elim(qr, hl)
    assert isinstance(exx.conclusion, Exists)
    X = 'Xrel'
    ix = substitute(exx.conclusion.body, exx.conclusion.var, V(X))
    ctxX = ctxL + (ix,)
    hx = _assume(ix, ctxX)
    Xd = _and_l(hx)
    exz = _and_r(hx)
    assert isinstance(exz.conclusion, Exists)
    Z = 'Zrel'
    iz = substitute(exz.conclusion.body, exz.conclusion.var, V(Z))
    ctxZ = ctxX + (iz,)
    hz = _assume(iz, ctxZ)
    Zc = _and_l(hz)
    opqXZ = _and_r(hz)
    XD = _adjoin_mem_left(_weaken(hD, ctxZ), X, Xd, ctxZ)
    newXBody = substitute(ir.right.body, ir.right.var, V(X))
    newYEx = newXBody.right
    newYBody = substitute(newYEx.body, newYEx.var, V(Z))
    cY = Proof('and_intro', newYBody, ctxZ, (_weaken(Zc, ctxZ), opqXZ))
    eY = Proof('exists_intro', newYEx, ctxZ, (cY,), (('term', {'var': Z}),))
    cX = Proof('and_intro', newXBody, ctxZ, (XD, eY))
    eX = Proof('exists_intro', ir.right, ctxZ, (cX,), (('term', {'var': X}),))
    afterZ = Proof('exists_elim', ir.right, ctxX, (exz, eX), (('eigenvar', Z),))
    outOld = Proof('exists_elim', ir.right, ctxL, (exx, afterZ), (('eigenvar', X),))
    r = cases.conclusion.right
    ctxR = ctxq + (r,)
    hr = _assume(r, ctxR)
    opq = Proof('eq_subst', OrderedPairCode(V(q), V('s'), V('y'), 'aa', 'bb'), ctxR, (hr, _weaken(hP, ctxR)), (('direction', 'rl'),))
    freshXBody = substitute(ir.right.body, ir.right.var, V('s'))
    freshYEx = freshXBody.right
    freshYBody = substitute(freshYEx.body, freshYEx.var, V('y'))
    cy = Proof('and_intro', freshYBody, ctxR, (_weaken(yc, ctxR), opq))
    ey = Proof('exists_intro', freshYEx, ctxR, (cy,), (('term', {'var': 'y'}),))
    cx = Proof('and_intro', freshXBody, ctxR, (_weaken(sD, ctxR), ey))
    ex = Proof('exists_intro', ir.right, ctxR, (cx,), (('term', {'var': 's'}),))
    outRel = Proof('or_elim', ir.right, ctxq, (cases, outOld, ex))
    irpf = Proof('imp_intro', ir, ctxF, (outRel,))
    relpf = Proof('forall_intro', rel, ctxF, (irpf,))
    x = total.var
    it = total.body
    ctxx = ctxF + (it.left,)
    hxD = _assume(it.left, ctxx)
    dcases = _adjoin_cases(_weaken(hD, ctxx), x, hxD, ctxx)
    dl = dcases.conclusion.left
    ctxDL = ctxx + (dl,)
    hdl = _assume(dl, ctxDL)
    qt = _forall_elim(_weaken(oldtotal, ctxDL), x)
    exz = _imp_elim(qt, hdl)
    assert isinstance(exz.conclusion, Exists)
    ZT = 'Ztot'
    izt = substitute(exz.conclusion.body, exz.conclusion.var, V(ZT))
    ctxZT = ctxDL + (izt,)
    hzt = _assume(izt, ctxZT)
    zc = _and_l(hzt)
    gvold = _and_r(hzt)
    gvnew = lift_old_gv(gvold, x, ZT, ctxZT)
    bout = substitute(it.right.body, it.right.var, V(ZT))
    cb = Proof('and_intro', bout, ctxZT, (zc, gvnew))
    ez = Proof('exists_intro', it.right, ctxZT, (cb,), (('term', {'var': ZT}),))
    outDL = Proof('exists_elim', it.right, ctxDL, (exz, ez), (('eigenvar', ZT),))
    dr = dcases.conclusion.right
    ctxDR = ctxx + (dr,)
    hdr = _assume(dr, ctxDR)
    opPxy = Proof('eq_subst', OrderedPairCode(V(P), V(x), V('y'), 'aa', 'bb'), ctxDR, (hdr, _weaken(hP, ctxDR)), (('direction', 'rl'),))
    gv = GraphValueSpec(V(F), V(x), V('y'), 'qq')
    bg = substitute(gv.body, gv.var, V(P))
    cg = Proof('and_intro', bg, ctxDR, (_weaken(pF, ctxDR), opPxy))
    eg = Proof('exists_intro', gv, ctxDR, (cg,), (('term', {'var': P}),))
    bout2 = substitute(it.right.body, it.right.var, V('y'))
    cb2 = Proof('and_intro', bout2, ctxDR, (_weaken(yc, ctxDR), eg))
    ey2 = Proof('exists_intro', it.right, ctxDR, (cb2,), (('term', {'var': 'y'}),))
    outTot = Proof('or_elim', it.right, ctxx, (dcases, outDL, ey2))
    itpf = Proof('imp_intro', it, ctxF, (outTot,))
    totalpf = Proof('forall_intro', total, ctxF, (itpf,))
    ux = unique.var
    uz = unique.body.var
    uz2 = unique.body.body.var
    iu = unique.body.body.body
    ctxu = ctxF + (iu.left,)
    hu = _assume(iu.left, ctxu)
    left = _and_l(hu)
    right = _and_r(hu)
    xD2 = _and_l(left)
    zc = _and_r(left)
    z2c = _and_l(right)
    both = _and_r(right)
    gv1 = _and_l(both)
    gv2 = _and_r(both)
    xcases = _adjoin_cases(_weaken(hD, ctxu), ux, xD2, ctxu)
    ol = xcases.conclusion.left
    ctxOL = ctxu + (ol,)
    hol = _assume(ol, ctxOL)
    go1 = fv_to_old(_weaken(gv1, ctxOL), ux, uz, hol, ctxOL)
    go2 = fv_to_old(_weaken(gv2, ctxOL), ux, uz2, hol, ctxOL)
    qu = _weaken(olduniq, ctxOL)
    for nm in [ux, uz, uz2]:
        qu = _forall_elim(qu, nm)
    ante = qu.conclusion.left
    lcon = Proof('and_intro', ante.left, ctxOL, (_weaken(hol, ctxOL), _weaken(zc, ctxOL)))
    bcon = Proof('and_intro', ante.right.right, ctxOL, (go1, go2))
    rcon = Proof('and_intro', ante.right, ctxOL, (_weaken(z2c, ctxOL), bcon))
    acon = Proof('and_intro', ante, ctxOL, (lcon, rcon))
    eqold = _imp_elim(qu, acon)
    orr = xcases.conclusion.right
    ctxOR = ctxu + (orr,)
    hor = _assume(orr, ctxOR)
    gv1s = Proof('eq_subst', GraphValueSpec(V(F), V('s'), V(uz), 'q1'), ctxOR, (hor, _weaken(gv1, ctxOR)), (('direction', 'lr'),))
    gv2s = Proof('eq_subst', GraphValueSpec(V(F), V('s'), V(uz2), 'q2'), ctxOR, (hor, _weaken(gv2, ctxOR)), (('direction', 'lr'),))
    e1 = fv_at_fresh_eq_y(gv1s, uz, ctxOR)
    e2 = fv_at_fresh_eq_y(gv2s, uz2, ctxOR)
    y2z2 = Proof('eq_symm', Eq(V('y'), V(uz2)), ctxOR, (e2,))
    eqfr = Proof('eq_trans', Eq(V(uz), V(uz2)), ctxOR, (e1, y2z2))
    equ = Proof('or_elim', Eq(V(uz), V(uz2)), ctxu, (xcases, eqold, eqfr))
    iupf = Proof('imp_intro', iu, ctxF, (equ,))
    q2 = Proof('forall_intro', unique.body.body, ctxF, (iupf,))
    q1 = Proof('forall_intro', unique.body, ctxF, (q2,))
    uniqpf = Proof('forall_intro', unique, ctxF, (q1,))
    rest = Proof('and_intro', fun.right, ctxF, (totalpf, uniqpf))
    funpf = Proof('and_intro', fun, ctxF, (relpf, rest))
    payload = And(specD, And(specP, And(specF, fun)))
    tD = substitute(target.body, target.var, V(D))
    tP = substitute(tD.body, tD.var, V(P))
    tF = substitute(tP.body, tP.var, V(F))
    c3 = Proof('and_intro', tF.right.right, ctxF, (_weaken(hF, ctxF), funpf))
    c2 = Proof('and_intro', tF.right, ctxF, (_weaken(hP, ctxF), c3))
    c1 = Proof('and_intro', tF, ctxF, (_weaken(hD, ctxF), c2))
    exF = Proof('exists_intro', tP, ctxF, (c1,), (('term', {'var': F}),))
    afterF = Proof('exists_elim', tP, ctxP, (af, exF), (('eigenvar', F),))
    exP = Proof('exists_intro', tD, ctxP, (afterF,), (('term', {'var': P}),))
    afterP = Proof('exists_elim', tD, ctxD, (op, exP), (('eigenvar', P),))
    exD = Proof('exists_intro', target, ctxD, (afterP,), (('term', {'var': D}),))
    afterD = Proof('exists_elim', target, ctx0, (ad, exD), (('eigenvar', D),))
    imp = Proof('imp_intro', core, (), (afterD,))
    qy = Proof('forall_intro', goal.body.body.body.body, (), (imp,))
    qs = Proof('forall_intro', goal.body.body.body, (), (qy,))
    qf = Proof('forall_intro', goal.body.body, (), (qs,))
    qc = Proof('forall_intro', goal.body, (), (qf,))
    return Proof('forall_intro', goal, (), (qc,))

def omega_nonzero_unique_predecessor_formula() -> Formula:
    pred = Exists('p', And(Mem(V('p'), V('w')), And(SuccessorSpec(V('n'), V('p'), 'u'), Forall('q', Imp(And(Mem(V('q'), V('w')), SuccessorSpec(V('n'), V('q'), 'v')), Eq(V('q'), V('p')))))))
    return Forall('w', Imp(OmegaSpec(V('w'), 'j', 'k'), Forall('n', Imp(Mem(V('n'), V('w')), Imp(Not(EmptySpec(V('n'), 'z')), pred)))))

def build_omega_nonzero_unique_predecessor(generated_pf: Proof | None=None, succinj_pf: Proof | None=None) -> Proof:
    generated_pf = generated_pf or build_omega_every_element_zero_or_successor()
    succinj_pf = succinj_pf or build_successor_injective()
    goal = omega_nonzero_unique_predecessor_formula()
    outer = goal.body
    om = outer.left
    ctx = (om,)
    hom = _assume(om, ctx)
    alln = outer.right
    n = alln.var
    impn = alln.body
    ctxn = ctx + (impn.left,)
    hn = _assume(impn.left, ctxn)
    inner = impn.right
    ctxne = ctxn + (inner.left,)
    hne = _assume(inner.left, ctxne)
    gp = _weaken(generated_pf, ctxne)
    gp = _forall_elim(gp, 'w')
    gp = _imp_elim(gp, _weaken(hom, ctxne))
    gp = _forall_elim(gp, n)
    cases = _imp_elim(gp, _weaken(hn, ctxne))
    le = cases.conclusion.left
    ctxE = ctxne + (le,)
    hE = _assume(le, ctxE)
    bot = _imp_elim(_weaken(hne, ctxE), hE)
    outE = Proof('bottom_elim', inner.right, ctxE, (bot,))
    re = cases.conclusion.right
    ctxR = ctxne + (re,)
    hR = _assume(re, ctxR)
    assert isinstance(re, Exists)
    P = 'Pred'
    instP = substitute(re.body, re.var, V(P))
    ctxP = ctxR + (instP,)
    hP = _assume(instP, ctxP)
    Pw = _and_l(hP)
    succNP = _and_r(hP)
    targetP = substitute(inner.right.body, inner.right.var, V(P))
    uq = targetP.right.right
    q = uq.var
    iuq = uq.body
    ctxQ = ctxP + (iuq.left,)
    hq = _assume(iuq.left, ctxQ)
    qw = _and_l(hq)
    succNQ = _and_r(hq)
    si = _weaken(succinj_pf, ctxQ)
    for nm in [P, q, n]:
        pass
    si = _forall_elim(_forall_elim(_forall_elim(si, P), q), n)
    acon = Proof('and_intro', si.conclusion.left, ctxQ, (_weaken(succNP, ctxQ), succNQ))
    eqPq = _imp_elim(si, acon)
    eqQp = Proof('eq_symm', Eq(V(q), V(P)), ctxQ, (eqPq,))
    iuqpf = Proof('imp_intro', iuq, ctxP, (eqQp,))
    uqpf = Proof('forall_intro', uq, ctxP, (iuqpf,))
    rr = Proof('and_intro', targetP.right, ctxP, (_weaken(succNP, ctxP), uqpf))
    allb = Proof('and_intro', targetP, ctxP, (_weaken(Pw, ctxP), rr))
    exP = Proof('exists_intro', inner.right, ctxP, (allb,), (('term', {'var': P}),))
    outR = Proof('exists_elim', inner.right, ctxR, (hR, exP), (('eigenvar', P),))
    out = Proof('or_elim', inner.right, ctxne, (cases, outE, outR))
    ine = Proof('imp_intro', inner, ctxn, (out,))
    inmem = Proof('imp_intro', impn, ctx, (ine,))
    qn = Proof('forall_intro', alln, ctx, (inmem,))
    iom = Proof('imp_intro', outer, (), (qn,))
    return Proof('forall_intro', goal, (), (iom,))

def build_pass007_library(schema_prefix: tuple[SchemaInstance, ...]=()) -> tuple[CertifiedStatement, ...]:
    offset = len(schema_prefix)
    schemas = tuple(schema_prefix) + PASS007_SCHEMA_INSTANCES
    k = ZFCKernel(schemas)
    base = list(PASS006_FULL_LIBRARY if not schema_prefix else build_pass006_library(schema_prefix))
    sg = build_omega_every_element_zero_or_successor(offset + 6)
    si = build_successor_injective()
    extras = [('ZFC_SUCCESSOR_INJECTIVE', 'theorem', si), ('ZFC_EMPTY_NOT_SUCCESSOR', 'lemma', build_zero_not_successor()), ('ZFC_OMEGA_ZERO_OR_SUCCESSOR', 'theorem', sg), ('ZFC_OMEGA_NONZERO_UNIQUE_PREDECESSOR', 'corollary', build_omega_nonzero_unique_predecessor(sg, si)), ('ZFC_ADJOIN_EXISTS', 'lemma', build_adjoin_exists()), ('ZFC_FUNCTION_FRESH_POINT_EXTENSION', 'theorem', build_function_extend_fresh())]
    for name, kind, p in extras:
        kr = k.verify(p)
        if not kr.ok:
            raise ValueError(f'PASS007_KERNEL_REJECT:{name}:{kr.detail}')
        base.append(CertifiedStatement(p, name=name, kind=kind, source='PASS007_RECURSION_EXISTENCE_PREREQUISITES'))
    return tuple(base)
PASS007_FULL_LIBRARY = build_pass007_library(())
PASS007_NORMALIZED_LIBRARY = _preverified_pass006(PASS007_FULL_LIBRARY)
