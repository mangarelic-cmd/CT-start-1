from __future__ import annotations
from dataclasses import dataclass
from .logic import *
from .proof import *
from .axioms import FIXED_AXIOMS, SchemaInstance
from .kernel import ZFCKernel
from .semantic import CertifiedStatement, normalize_certified_library, CANONICAL_STATEMENT_KIND

@dataclass
class SynthesisResult:
    status: str
    proof: Proof | None
    explored: int
    residual: dict | None
    sin1_frontier: int = 0
    sin2_frontier: int = 0
    cos_matches: int = 0
    canonical_statement_kind: str = CANONICAL_STATEMENT_KIND
    library_entries: int = 0

class CausalZFCSynthesizer:
    """Fail-closed proof-term constructor. Labels are metadata; sequents are mathematical identity."""

    def __init__(self, schema_instances: tuple[SchemaInstance, ...]=(), budget: int=2000, proof_library: tuple[CertifiedStatement, ...]=(), max_depth: int=18, foundation_library: bool=False, mathematics_library: bool=False, arithmetic_library: bool=False, recursion_library: bool=False):
        user_schemas = tuple(schema_instances)
        user_library = tuple(proof_library)
        if recursion_library:
            from .recursion_library import PASS007_SCHEMA_INSTANCES
            self.schema_instances = user_schemas + tuple(PASS007_SCHEMA_INSTANCES)
        elif arithmetic_library:
            from .arithmetic_library import PASS005_SCHEMA_INSTANCES
            self.schema_instances = user_schemas + tuple(PASS005_SCHEMA_INSTANCES)
        elif mathematics_library:
            from .mathematics_library import PASS004_SCHEMA_INSTANCES
            self.schema_instances = user_schemas + tuple(PASS004_SCHEMA_INSTANCES)
        else:
            self.schema_instances = user_schemas
        self.kernel = ZFCKernel(self.schema_instances)
        if recursion_library and (not user_schemas) and (not user_library):
            from .recursion_library import PASS007_NORMALIZED_LIBRARY
            self.library = PASS007_NORMALIZED_LIBRARY
        elif arithmetic_library and (not user_schemas) and (not user_library):
            from .arithmetic_library import PASS005_NORMALIZED_LIBRARY
            self.library = PASS005_NORMALIZED_LIBRARY
        elif mathematics_library and (not user_schemas) and (not user_library):
            from .mathematics_library import PASS004_NORMALIZED_LIBRARY
            self.library = PASS004_NORMALIZED_LIBRARY
        else:
            proof_library = user_library
            if foundation_library or mathematics_library or arithmetic_library or recursion_library:
                from .derived_library import FOUNDATION_LIBRARY
                proof_library = tuple(proof_library) + tuple(FOUNDATION_LIBRARY)
            if recursion_library:
                from .recursion_library import build_pass007_library
                proof_library = tuple(user_library) + tuple(build_pass007_library(user_schemas))
            elif arithmetic_library:
                from .arithmetic_library import build_pass005_library
                proof_library = tuple(user_library) + tuple(build_pass005_library(user_schemas))
            elif mathematics_library:
                from .mathematics_library import PASS004_MATH_LIBRARY, build_pass004_math_library
                proof_library = tuple(proof_library) + (tuple(PASS004_MATH_LIBRARY) if not user_schemas else tuple(build_pass004_math_library(user_schemas)))
            self.library = normalize_certified_library(tuple(proof_library), self.kernel)
        self.budget = budget
        self.max_depth = max_depth
        self.explored = 0
        self.memo = {}
        self.in_progress = set()
        self.sin1_count = 0
        self.sin2_count = 0
        self.cos_count = 0

    def synthesize(self, goal: Formula, context: tuple[Formula, ...]=()) -> SynthesisResult:
        self.explored = 0
        self.memo = {}
        self.in_progress = set()
        self.sin1_count = 0
        self.sin2_count = 0
        self.cos_count = 0
        p = self._prove(goal, context, 0, frozenset())
        if p is not None:
            k = self.kernel.verify(p)
            if not k.ok:
                return SynthesisResult('INTERNAL_KERNEL_REJECT', None, self.explored, {'code': k.code, 'detail': k.detail}, self.sin1_count, self.sin2_count, self.cos_count, library_entries=len(self.library))
            return SynthesisResult('PROVED', p, self.explored, None, self.sin1_count, self.sin2_count, self.cos_count, library_entries=len(self.library))
        return SynthesisResult('OPEN', None, self.explored, {'class': 'PROOF_SEARCH_RESIDUAL', 'canonical_object_class': CANONICAL_STATEMENT_KIND, 'canonical_kind': CANONICAL_STATEMENT_KIND, 'goal': pretty(goal), 'goal_digest': digest_formula(goal), 'budget_exhausted': self.explored >= self.budget, 'dispatch': 'PROOF_DEFECT_OR_SOLVER'}, self.sin1_count, self.sin2_count, self.cos_count, library_entries=len(self.library))

    def _key(self, goal, ctx, blocked):
        return (str(alpha_key(goal)), tuple(sorted((str(alpha_key(x)) for x in ctx))), tuple(sorted(blocked)))

    def _tick(self):
        self.explored += 1
        return self.explored <= self.budget

    def _adapt_context(self, p: Proof, ctx: tuple[Formula, ...]) -> Proof | None:
        if ctx_equiv(p.context, ctx):
            return p
        if ctx_subset_equiv(p.context, ctx):
            return Proof('weakening', p.conclusion, ctx, (p,))
        return None

    def _closed_authorized(self, goal, ctx):
        for aid, f in FIXED_AXIOMS.items():
            if equivalent(goal, f):
                return Proof('axiom_fixed', goal, ctx, (), (('axiom_id', aid),))
        for i, s in enumerate(self.schema_instances):
            if equivalent(goal, s.generated()):
                return Proof('axiom_schema', goal, ctx, (), (('schema_index', i),))
        for entry in self.library:
            if equivalent(goal, entry.proof.conclusion):
                q = self._adapt_context(entry.proof, ctx)
                if q is not None:
                    return q
        return None

    def _available_authorized(self, ctx):
        out = []
        for aid, f in FIXED_AXIOMS.items():
            out.append(Proof('axiom_fixed', f, ctx, (), (('axiom_id', aid),)))
        for i, s in enumerate(self.schema_instances):
            out.append(Proof('axiom_schema', s.generated(), ctx, (), (('schema_index', i),)))
        for entry in self.library:
            q = self._adapt_context(entry.proof, ctx)
            if q is not None:
                out.append(q)
        return out

    def _prove(self, goal, ctx, depth, blocked):
        if depth > self.max_depth or not self._tick():
            return None
        key = self._key(goal, ctx, blocked)
        if key in self.memo:
            return self.memo[key]
        if key in self.in_progress:
            return None
        self.in_progress.add(key)
        try:
            result = self._prove_uncached(goal, ctx, depth, blocked)
            self.memo[key] = result
            return result
        finally:
            self.in_progress.remove(key)

    def _prove_uncached(self, goal, ctx, depth, blocked):
        self.sin2_count += 1
        for h in ctx:
            if equivalent(goal, h):
                self.cos_count += 1
                return Proof('assumption', goal, ctx)
        ax = self._closed_authorized(goal, ctx)
        if ax:
            self.cos_count += 1
            return ax
        if isinstance(goal, Eq) and goal.left == goal.right:
            self.cos_count += 1
            return Proof('eq_refl', goal, ctx)
        for h in ctx:
            if isinstance(h, Bottom):
                self.cos_count += 1
                return Proof('bottom_elim', goal, ctx, (Proof('assumption', h, ctx),))
        gd0 = self._goal_directed_authorized(goal, ctx, self._available_authorized(ctx))
        if gd0 is not None:
            self.cos_count += 1
            return gd0
        if isinstance(goal, Imp):
            q = self._prove(goal.right, ctx_add(ctx, goal.left), depth + 1, blocked)
            if q:
                return Proof('imp_intro', goal, ctx, (q,))
        if isinstance(goal, And):
            a = self._prove(goal.left, ctx, depth + 1, blocked)
            b = self._prove(goal.right, ctx, depth + 1, blocked)
            if a and b:
                return Proof('and_intro', goal, ctx, (a, b))
        if isinstance(goal, Or):
            a = self._prove(goal.left, ctx, depth + 1, blocked)
            if a:
                return Proof('or_intro_left', goal, ctx, (a,))
            b = self._prove(goal.right, ctx, depth + 1, blocked)
            if b:
                return Proof('or_intro_right', goal, ctx, (b,))
        if isinstance(goal, Iff):
            a = self._prove(Imp(goal.left, goal.right), ctx, depth + 1, blocked)
            b = self._prove(Imp(goal.right, goal.left), ctx, depth + 1, blocked)
            if a and b:
                return Proof('iff_intro', goal, ctx, (a, b))
        if isinstance(goal, Forall):
            if not any((goal.var in free_vars(h) for h in ctx)):
                q = self._prove(goal.body, ctx, depth + 1, blocked)
                if q:
                    return Proof('forall_intro', goal, ctx, (q,))
        p = self._forward_find(goal, ctx)
        if p is not None:
            self.cos_count += 1
            return p
        if isinstance(goal, Exists):
            candidates = sorted(self._candidate_vars(goal, ctx))
            for v in candidates:
                body = substitute(goal.body, goal.var, V(v))
                q = self._prove(body, ctx, depth + 1, blocked)
                if q:
                    return Proof('exists_intro', goal, ctx, (q,), (('term', {'var': v}),))
        for i, h in enumerate(ctx):
            marker = f'OR:{i}:{digest_formula(h)}'
            if marker in blocked or not isinstance(h, Or):
                continue
            disj = Proof('assumption', h, ctx)
            b2 = blocked | {marker}
            l = self._prove(goal, ctx_add(ctx, h.left), depth + 1, b2)
            if l is None:
                continue
            r = self._prove(goal, ctx_add(ctx, h.right), depth + 1, b2)
            if r is not None:
                return Proof('or_elim', goal, ctx, (disj, l, r))
        for i, h in enumerate(ctx):
            marker = f'EX:{i}:{digest_formula(h)}'
            if marker in blocked or not isinstance(h, Exists):
                continue
            avoid = all_vars(goal) | {v for f in ctx for v in all_vars(f)}
            eigen = self._fresh_eigen('e', avoid)
            inst = substitute(h.body, h.var, V(eigen))
            b2 = blocked | {marker}
            branch = self._prove(goal, ctx_add(ctx, inst), depth + 1, b2)
            if branch is not None:
                ex = Proof('assumption', h, ctx)
                return Proof('exists_elim', goal, ctx, (ex, branch), (('eigenvar', eigen),))
        if not isinstance(goal, Bottom):
            marker = f'RAA:{digest_formula(goal)}'
            if marker not in blocked:
                q = self._prove(FALSE, ctx_add(ctx, Not(goal)), depth + 1, blocked | {marker})
                if q is not None:
                    return Proof('classical_reductio', goal, ctx, (q,))
        return None

    def _fresh_eigen(self, base, avoid):
        if base not in avoid:
            return base
        i = 0
        while f'{base}_{i}' in avoid:
            i += 1
        return f'{base}_{i}'

    def _candidate_vars(self, goal, ctx):
        s = free_vars(goal)
        for h in ctx:
            s |= free_vars(h)
        s |= {'x', 'y', 'z', 'w', 'u', 'v'}
        return s

    def _match_meta_formula(self, pat, tgt, metas, subst, bound=None):
        bound = {} if bound is None else dict(bound)
        if type(pat) is not type(tgt):
            return False

        def mt(a, b):
            if a.name in bound:
                return bound[a.name] == b.name
            if a.name in metas:
                old = subst.get(a.name)
                if old is None:
                    subst[a.name] = b.name
                    return True
                return old == b.name
            return a.name == b.name
        if isinstance(pat, (Prop, Bottom)):
            return isinstance(pat, Bottom) or pat.name == tgt.name
        if isinstance(pat, (Eq, Mem)):
            return mt(pat.left, tgt.left) and mt(pat.right, tgt.right)
        if isinstance(pat, (Imp, And, Or, Iff)):
            return self._match_meta_formula(pat.left, tgt.left, metas, subst, bound) and self._match_meta_formula(pat.right, tgt.right, metas, subst, bound)
        if isinstance(pat, (Forall, Exists)):
            b2 = dict(bound)
            b2[pat.var] = tgt.var
            return self._match_meta_formula(pat.body, tgt.body, metas, subst, b2)
        return False

    def _instantiate_top_foralls(self, p, vars_, subst, ctx):
        q = p
        for v in vars_:
            name = subst.get(v)
            if name is None:
                return None
            concl = substitute(q.conclusion.body, q.conclusion.var, V(name))
            q = Proof('forall_elim', concl, ctx, (q,), (('term', {'var': name}),))
        return q

    def _goal_directed_authorized(self, goal, ctx, bases):
        for base in bases:
            core = base.conclusion
            vars_ = []
            while isinstance(core, Forall):
                vars_.append(core.var)
                core = core.body
            if not vars_:
                continue
            metas = set(vars_)
            if isinstance(core, Imp):
                s0 = {}
                if self._match_meta_formula(core.right, goal, metas, s0):
                    for h in ctx:
                        ss = dict(s0)
                        if self._match_meta_formula(core.left, h, metas, ss):
                            q = self._instantiate_top_foralls(base, vars_, ss, ctx)
                            if q is not None and isinstance(q.conclusion, Imp) and equivalent(q.conclusion.right, goal) and equivalent(q.conclusion.left, h):
                                self.sin1_count += 1
                                return Proof('imp_elim', goal, ctx, (q, Proof('assumption', h, ctx)))
            ss = {}
            if self._match_meta_formula(core, goal, metas, ss):
                q = self._instantiate_top_foralls(base, vars_, ss, ctx)
                if q is not None and equivalent(q.conclusion, goal):
                    self.sin1_count += 1
                    return q
        return None

    def _forward_find(self, goal, ctx):
        vars_ = sorted(self._candidate_vars(goal, ctx))

        def kf(f):
            return str(alpha_key(f))

        def closure(seed, max_rounds=10):
            known = {kf(p.conclusion): p for p in seed}
            if kf(goal) in known:
                return known[kf(goal)]
            for _round in range(max_rounds):
                new_count = 0
                snapshot = list(known.values())
                additions = []
                for p in snapshot:
                    if isinstance(p.conclusion, And):
                        additions += [Proof('and_elim_left', p.conclusion.left, ctx, (p,)), Proof('and_elim_right', p.conclusion.right, ctx, (p,))]
                    if isinstance(p.conclusion, Iff):
                        additions += [Proof('iff_elim_left', Imp(p.conclusion.left, p.conclusion.right), ctx, (p,)), Proof('iff_elim_right', Imp(p.conclusion.right, p.conclusion.left), ctx, (p,))]
                    if isinstance(p.conclusion, Forall):
                        for v in vars_:
                            tgt = substitute(p.conclusion.body, p.conclusion.var, V(v))
                            additions.append(Proof('forall_elim', tgt, ctx, (p,), (('term', {'var': v}),)))
                    if isinstance(p.conclusion, Eq) and p.conclusion.left != p.conclusion.right:
                        additions.append(Proof('eq_symm', Eq(p.conclusion.right, p.conclusion.left), ctx, (p,)))
                for p in additions:
                    key = kf(p.conclusion)
                    if key not in known:
                        known[key] = p
                        self.sin1_count += 1
                        new_count += 1
                        if key == kf(goal):
                            return p
                snapshot = list(known.values())
                more = []
                for p in snapshot:
                    if isinstance(p.conclusion, Imp):
                        q = known.get(kf(p.conclusion.left))
                        if q is not None:
                            more.append(Proof('imp_elim', p.conclusion.right, ctx, (p, q)))
                eqs = [p for p in snapshot if isinstance(p.conclusion, Eq)]
                for a in eqs:
                    for b in eqs:
                        if a.conclusion.right == b.conclusion.left:
                            more.append(Proof('eq_trans', Eq(a.conclusion.left, b.conclusion.right), ctx, (a, b)))
                for ep in eqs:
                    for fp in snapshot:
                        if fp is ep:
                            continue
                        for direction, src, tgt in (('lr', ep.conclusion.left, ep.conclusion.right), ('rl', ep.conclusion.right, ep.conclusion.left)):
                            out = substitute(fp.conclusion, src.name, tgt)
                            if kf(out) != kf(fp.conclusion):
                                more.append(Proof('eq_subst', out, ctx, (ep, fp), (('direction', direction),)))
                for p in more:
                    key = kf(p.conclusion)
                    if key not in known:
                        known[key] = p
                        self.sin1_count += 1
                        new_count += 1
                        if key == kf(goal):
                            return p
                if new_count == 0:
                    break
            return None
        facts = [Proof('assumption', h, ctx) for h in ctx]
        self.sin1_count += len(facts)
        hit = closure(facts)
        if hit is not None:
            return hit
        bases = self._available_authorized(ctx)
        gd = self._goal_directed_authorized(goal, ctx, bases)
        if gd is not None:
            return gd
        direct_terms = sorted(free_vars(goal) | {v for h in ctx for v in free_vars(h)})
        if not direct_terms:
            direct_terms = ['x']
        for base in bases:
            frontier = [base]
            for _ in range(6):
                nxt = []
                for q in frontier:
                    if equivalent(q.conclusion, goal):
                        self.sin1_count += 1
                        return q
                    if isinstance(q.conclusion, Imp) and equivalent(q.conclusion.right, goal):
                        for h in ctx:
                            if equivalent(q.conclusion.left, h):
                                self.sin1_count += 1
                                return Proof('imp_elim', goal, ctx, (q, Proof('assumption', h, ctx)))
                    if isinstance(q.conclusion, Forall):
                        for v in direct_terms:
                            concl = substitute(q.conclusion.body, q.conclusion.var, V(v))
                            nxt.append(Proof('forall_elim', concl, ctx, (q,), (('term', {'var': v}),)))
                if not nxt:
                    break
                frontier = nxt
        candidate_map = {}
        direct_hit = [None]
        frontier_cap = max(32, min(1200, self.budget * 4))

        def expand(p, depth):
            if direct_hit[0] is not None or len(candidate_map) >= frontier_cap:
                return
            key = kf(p.conclusion)
            if key not in candidate_map:
                candidate_map[key] = p
            if key == kf(goal):
                direct_hit[0] = p
                return
            if depth <= 0 or not isinstance(p.conclusion, Forall):
                return
            for v in vars_:
                concl = substitute(p.conclusion.body, p.conclusion.var, V(v))
                q = Proof('forall_elim', concl, ctx, (p,), (('term', {'var': v}),))
                expand(q, depth - 1)
                if direct_hit[0] is not None:
                    return
        for a in bases:
            expand(a, 4)
            if direct_hit[0] is not None:
                self.sin1_count += len(candidate_map)
                return direct_hit[0]
            if len(candidate_map) >= frontier_cap:
                break
        cands = list(candidate_map.values())
        self.sin1_count += len(cands)
        if kf(goal) in candidate_map:
            return candidate_map[kf(goal)]
        return closure(facts + cands)
