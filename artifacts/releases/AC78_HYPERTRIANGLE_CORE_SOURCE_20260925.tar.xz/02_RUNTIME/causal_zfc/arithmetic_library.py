from __future__ import annotations
from .logic import *
from .proof import *
from .axioms import SchemaInstance
from .kernel import ZFCKernel
from .semantic import CertifiedStatement, NormalizedLibraryEntry
from .setdefs import *
from .setdefs import _fresh_local
from .derived_library import _assume, _forall_elim, _and_l, _and_r, _imp_elim, _iff_l, _iff_r, _weaken, FOUNDATION_LIBRARY
from .mathematics_library import PASS004_SCHEMA_INSTANCES, PASS004_MATH_LIBRARY, build_pass004_math_library, build_successor_unique, build_ordered_pair_code_exists, build_cartesian_product_exists, successor_unique_formula, CartesianProductSpec, CartesianProductPredicate, OmegaSpec, omega_exists_formula

def GraphValueSpec(f: Term, x: Term, y: Term, p: str='p') -> Formula:
    avoid = {f.name, x.name, y.name}
    p = _fresh_local(p, avoid)
    return Exists(p, And(Mem(V(p), f), OrderedPairCode(V(p), x, y, 'a', 'b')))

def DiagonalPairPredicate(p: Term, d: Term, x: str='x') -> Formula:
    x = _fresh_local(x, {p.name, d.name})
    return Exists(x, And(Mem(V(x), d), OrderedPairCode(p, V(x), V(x), 'a', 'b')))

def IdentityFunctionSpec(f: Term, d: Term, x: str='x') -> Formula:
    x = _fresh_local(x, {f.name, d.name})
    return And(FunctionGraphSpec(f, d, d, 'p', 'a', 'b', 'b2'), Forall(x, Imp(Mem(V(x), d), GraphValueSpec(f, V(x), V(x), 'q'))))

def ordered_pair_injective_formula() -> Formula:
    p, x, y, u, v = map(V, ['p', 'x', 'y', 'u', 'v'])
    op1 = OrderedPairCode(p, x, y, 'a', 'b')
    op2 = OrderedPairCode(p, u, v, 'c', 'd')
    return Forall('p', Forall('x', Forall('y', Forall('u', Forall('v', Imp(And(op1, op2), And(Eq(x, u), Eq(y, v))))))))

def identity_function_exists_formula() -> Formula:
    return Forall('d', Exists('f', IdentityFunctionSpec(V('f'), V('d'), 'x')))

def omega_induction_subset_formula() -> Formula:
    return Forall('w', Forall('a', Imp(And(OmegaSpec(V('w'), 'j', 'x'), And(SubsetSpec(V('a'), V('w'), 'z'), InductiveSetSpec(V('a'), 'e', 'y', 's', 'q'))), Eq(V('a'), V('w')))))

def omega_zero_one_chain_formula() -> Formula:
    return Forall('w', Imp(OmegaSpec(V('w'), 'j', 'x'), Exists('z0', Exists('z1', And(And(EmptySpec(V('z0'), 'q'), Mem(V('z0'), V('w'))), And(SuccessorSpec(V('z1'), V('z0'), 'r'), Mem(V('z1'), V('w'))))))))

def successor_image_exists_formula() -> Formula:
    return Forall('a', Exists('b', Forall('v', Iff(Mem(V('v'), V('b')), Exists('u', And(Mem(V('u'), V('a')), SuccessorSpec(V('v'), V('u'), 'z')))))))

def ConstantPairPredicate(p: Term, d: Term, k: Term, x: str='x') -> Formula:
    x = _fresh_local(x, {p.name, d.name, k.name})
    return Exists(x, And(Mem(V(x), d), OrderedPairCode(p, V(x), k, 'a', 'b')))

def ConstantFunctionSpec(f: Term, d: Term, c: Term, k: Term, x: str='x') -> Formula:
    x = _fresh_local(x, {f.name, d.name, c.name, k.name})
    return And(FunctionGraphSpec(f, d, c, 'p', 'a', 'b', 'b2'), Forall(x, Imp(Mem(V(x), d), GraphValueSpec(f, V(x), k, 'q'))))

def constant_function_exists_formula() -> Formula:
    return Forall('d', Forall('c', Forall('k', Imp(Mem(V('k'), V('c')), Exists('f', ConstantFunctionSpec(V('f'), V('d'), V('c'), V('k'), 'x'))))))
IDENTITY_SEPARATION_SCHEMA = SchemaInstance('SEPARATION', DiagonalPairPredicate(V('p'), V('d'), 'x'), source_var='p', parameters=('d',))
SUCCESSOR_REPLACEMENT_SCHEMA = SchemaInstance('REPLACEMENT', SuccessorSpec(V('v'), V('u'), 'z'), source_var='u', target_var='v', parameters=())
CONSTANT_SEPARATION_SCHEMA = SchemaInstance('SEPARATION', ConstantPairPredicate(V('p'), V('d'), V('k'), 'x'), source_var='p', parameters=('d', 'k'))
PASS005_SCHEMA_INSTANCES = tuple(PASS004_SCHEMA_INSTANCES) + (IDENTITY_SEPARATION_SCHEMA, SUCCESSOR_REPLACEMENT_SCHEMA, CONSTANT_SEPARATION_SCHEMA)

def _mem_singleton(spec: Proof, elem: str, target: str, ctx) -> Proof:
    q = _forall_elim(_weaken(spec, ctx), elem)
    eq = Proof('eq_refl', Eq(V(elem), V(target)), ctx) if elem == target else None
    if eq is None:
        raise ValueError('mem_singleton only refl helper')
    return _imp_elim(_iff_r(q), eq)

def _mem_pair_side(spec: Proof, elem: str, left: str, right: str, side: str, ctx) -> Proof:
    q = _forall_elim(_weaken(spec, ctx), elem)
    if side == 'left':
        eq = Proof('eq_refl', Eq(V(elem), V(left)), ctx)
        disj = Proof('or_intro_left', q.conclusion.right, ctx, (eq,))
    else:
        eq = Proof('eq_refl', Eq(V(elem), V(right)), ctx)
        disj = Proof('or_intro_right', q.conclusion.right, ctx, (eq,))
    return _imp_elim(_iff_r(q), disj)

def _singleton_eq_from_mem(spec: Proof, elem: str, ctx) -> Proof:
    q = _forall_elim(_weaken(spec, ctx), elem)
    return _iff_l(q)

def _pair_cases_from_mem(spec: Proof, elem: str, mempf: Proof, ctx) -> Proof:
    q = _forall_elim(_weaken(spec, ctx), elem)
    return _imp_elim(_iff_l(q), _weaken(mempf, ctx))

def build_ordered_pair_injective() -> Proof:
    goal = ordered_pair_injective_formula()
    p, x, y, u, v = ('p', 'x', 'y', 'u', 'v')
    op1 = OrderedPairCode(V(p), V(x), V(y), 'a', 'b')
    op2 = OrderedPairCode(V(p), V(u), V(v), 'c', 'd')
    prem = And(op1, op2)
    target = And(Eq(V(x), V(u)), Eq(V(y), V(v)))
    ctx0 = (prem,)
    hp = _assume(prem, ctx0)
    e1 = _and_l(hp)
    e2 = _and_r(hp)
    A = 'A'
    instA = substitute(e1.conclusion.body, e1.conclusion.var, V(A))
    ctxA = ctx0 + (instA,)
    hAex = _assume(instA, ctxA)
    B = 'B'
    instB = substitute(hAex.conclusion.body, hAex.conclusion.var, V(B))
    ctxAB = ctxA + (instB,)
    hAB = _assume(instB, ctxAB)
    e2AB = _weaken(e2, ctxAB)
    C = 'C'
    instC = substitute(e2AB.conclusion.body, e2AB.conclusion.var, V(C))
    ctxC = ctxAB + (instC,)
    hCex = _assume(instC, ctxC)
    D = 'D'
    instD = substitute(hCex.conclusion.body, hCex.conclusion.var, V(D))
    ctxD = ctxC + (instD,)
    hCD = _assume(instD, ctxD)
    hA1 = _and_l(_weaken(hAB, ctxD))
    rr1 = _and_r(_weaken(hAB, ctxD))
    hB1 = _and_l(rr1)
    hP1 = _and_r(rr1)
    hC1 = _and_l(hCD)
    rr2 = _and_r(hCD)
    hD1 = _and_l(rr2)
    hP2 = _and_r(rr2)
    xA = _mem_singleton(hA1, x, x, ctxD)
    xB = _mem_pair_side(hB1, x, x, y, 'left', ctxD)
    Cinp = _mem_pair_side(hP2, C, C, D, 'left', ctxD)
    c_cases = _pair_cases_from_mem(hP1, C, Cinp, ctxD)
    l = c_cases.conclusion.left
    ctxL = ctxD + (l,)
    hl = _assume(l, ctxL)
    xC_l = Proof('eq_subst', Mem(V(x), V(C)), ctxL, (hl, _weaken(xA, ctxL)), (('direction', 'rl'),))
    r = c_cases.conclusion.right
    ctxR = ctxD + (r,)
    hr = _assume(r, ctxR)
    xC_r = Proof('eq_subst', Mem(V(x), V(C)), ctxR, (hr, _weaken(xB, ctxR)), (('direction', 'rl'),))
    xC = Proof('or_elim', Mem(V(x), V(C)), ctxD, (c_cases, xC_l, xC_r))
    xu = _imp_elim(_singleton_eq_from_mem(hC1, x, ctxD), xC)
    yB = _mem_pair_side(hB1, y, x, y, 'right', ctxD)
    Binp = _mem_pair_side(hP1, B, A, B, 'right', ctxD)
    b_cases = _pair_cases_from_mem(hP2, B, Binp, ctxD)
    Y = Or(Eq(V(y), V(x)), Eq(V(y), V(v)))
    bl = b_cases.conclusion.left
    ctxBL = ctxD + (bl,)
    hbl = _assume(bl, ctxBL)
    yC = Proof('eq_subst', Mem(V(y), V(C)), ctxBL, (hbl, _weaken(yB, ctxBL)), (('direction', 'lr'),))
    yu = _imp_elim(_singleton_eq_from_mem(hC1, y, ctxBL), yC)
    ux = Proof('eq_symm', Eq(V(u), V(x)), ctxBL, (_weaken(xu, ctxBL),))
    yx = Proof('eq_trans', Eq(V(y), V(x)), ctxBL, (yu, ux))
    outBL = Proof('or_intro_left', Y, ctxBL, (yx,))
    br = b_cases.conclusion.right
    ctxBR = ctxD + (br,)
    hbr = _assume(br, ctxBR)
    yD = Proof('eq_subst', Mem(V(y), V(D)), ctxBR, (hbr, _weaken(yB, ctxBR)), (('direction', 'lr'),))
    yd_cases = _pair_cases_from_mem(hD1, y, yD, ctxBR)
    ydu = yd_cases.conclusion.left
    ctxYDU = ctxBR + (ydu,)
    hydu = _assume(ydu, ctxYDU)
    ux2 = Proof('eq_symm', Eq(V(u), V(x)), ctxYDU, (_weaken(xu, ctxYDU),))
    yx2 = Proof('eq_trans', Eq(V(y), V(x)), ctxYDU, (hydu, ux2))
    outYDU = Proof('or_intro_left', Y, ctxYDU, (yx2,))
    ydv = yd_cases.conclusion.right
    ctxYDV = ctxBR + (ydv,)
    hydv = _assume(ydv, ctxYDV)
    outYDV = Proof('or_intro_right', Y, ctxYDV, (hydv,))
    outBR = Proof('or_elim', Y, ctxBR, (yd_cases, outYDU, outYDV))
    y_cases = Proof('or_elim', Y, ctxD, (b_cases, outBL, outBR))
    vD = _mem_pair_side(hD1, v, u, v, 'right', ctxD)
    Dinp = _mem_pair_side(hP2, D, C, D, 'right', ctxD)
    d_cases = _pair_cases_from_mem(hP1, D, Dinp, ctxD)
    Vv = Or(Eq(V(v), V(x)), Eq(V(v), V(y)))
    dl = d_cases.conclusion.left
    ctxDL = ctxD + (dl,)
    hdl = _assume(dl, ctxDL)
    vA = Proof('eq_subst', Mem(V(v), V(A)), ctxDL, (hdl, _weaken(vD, ctxDL)), (('direction', 'lr'),))
    vx = _imp_elim(_singleton_eq_from_mem(hA1, v, ctxDL), vA)
    outDL = Proof('or_intro_left', Vv, ctxDL, (vx,))
    dr = d_cases.conclusion.right
    ctxDR = ctxD + (dr,)
    hdr = _assume(dr, ctxDR)
    vB = Proof('eq_subst', Mem(V(v), V(B)), ctxDR, (hdr, _weaken(vD, ctxDR)), (('direction', 'lr'),))
    vb_cases = _pair_cases_from_mem(hB1, v, vB, ctxDR)
    _vl = vb_cases.conclusion.left
    _cvl = ctxDR + (_vl,)
    _hvl = _assume(_vl, _cvl)
    _ovl = Proof('or_intro_left', Vv, _cvl, (_hvl,))
    _vr = vb_cases.conclusion.right
    _cvr = ctxDR + (_vr,)
    _hvr = _assume(_vr, _cvr)
    _ovr = Proof('or_intro_right', Vv, _cvr, (_hvr,))
    outDR = Proof('or_elim', Vv, ctxDR, (vb_cases, _ovl, _ovr))
    v_cases = Proof('or_elim', Vv, ctxD, (d_cases, outDL, outDR))
    yl = y_cases.conclusion.left
    ctxYL = ctxD + (yl,)
    hyl = _assume(yl, ctxYL)
    vv = _weaken(v_cases, ctxYL)
    vl = vv.conclusion.left
    ctxYLVL = ctxYL + (vl,)
    hvl = _assume(vl, ctxYLVL)
    xv = Proof('eq_symm', Eq(V(x), V(v)), ctxYLVL, (hvl,))
    yv1 = Proof('eq_trans', Eq(V(y), V(v)), ctxYLVL, (_weaken(hyl, ctxYLVL), xv))
    vr = vv.conclusion.right
    ctxYLVR = ctxYL + (vr,)
    hvr = _assume(vr, ctxYLVR)
    yv2 = Proof('eq_symm', Eq(V(y), V(v)), ctxYLVR, (hvr,))
    fromV = Proof('or_elim', Eq(V(y), V(v)), ctxYL, (vv, yv1, yv2))
    yr = y_cases.conclusion.right
    ctxYR = ctxD + (yr,)
    hyr = _assume(yr, ctxYR)
    yv = Proof('or_elim', Eq(V(y), V(v)), ctxD, (y_cases, fromV, hyr))
    final = Proof('and_intro', target, ctxD, (xu, yv))
    afterD = Proof('exists_elim', target, ctxC, (hCex, final), (('eigenvar', D),))
    afterC = Proof('exists_elim', target, ctxAB, (e2AB, afterD), (('eigenvar', C),))
    afterB = Proof('exists_elim', target, ctxA, (hAex, afterC), (('eigenvar', B),))
    afterA = Proof('exists_elim', target, ctx0, (e1, afterB), (('eigenvar', A),))
    imp = Proof('imp_intro', Imp(prem, target), (), (afterA,))
    q = Proof('forall_intro', Forall('v', imp.conclusion), (), (imp,))
    q = Proof('forall_intro', Forall('u', q.conclusion), (), (q,))
    q = Proof('forall_intro', Forall('y', q.conclusion), (), (q,))
    q = Proof('forall_intro', Forall('x', q.conclusion), (), (q,))
    q = Proof('forall_intro', goal, (), (q,))
    return q

def build_omega_induction_subset() -> Proof:
    goal = omega_induction_subset_formula()
    w, a = ('w', 'a')
    prem = goal.body.body.left
    ctx = (prem,)
    hp = _assume(prem, ctx)
    om = _and_l(hp)
    rest = _and_r(hp)
    a_sub_w = _and_l(rest)
    ind_a = _and_r(rest)
    minpart = _and_r(om)
    qa = _forall_elim(minpart, a)
    w_sub_a = _imp_elim(qa, ind_a)
    ext = _forall_elim(_forall_elim(Proof('axiom_fixed', __import__('causal_zfc.axioms', fromlist=['FIXED_AXIOMS']).FIXED_AXIOMS['EXTENSIONALITY'], ctx, (), (('axiom_id', 'EXTENSIONALITY'),)), a), w)
    need = ext.conclusion.left
    z = need.var
    A = Mem(V(z), V(a))
    W = Mem(V(z), V(w))
    sa = _forall_elim(a_sub_w, z)
    sw = _forall_elim(w_sub_a, z)
    iff = Proof('iff_intro', Iff(A, W), ctx, (_iff_l(Proof('iff_intro', Iff(A, W), ctx, (Proof('imp_intro', Imp(A, W), ctx, (_imp_elim(_weaken(sa, ctx + (A,)), _assume(A, ctx + (A,))),)), Proof('imp_intro', Imp(W, A), ctx, (_imp_elim(_weaken(sw, ctx + (W,)), _assume(W, ctx + (W,))),))))), _iff_r(Proof('iff_intro', Iff(A, W), ctx, (Proof('imp_intro', Imp(A, W), ctx, (_imp_elim(_weaken(sa, ctx + (A,)), _assume(A, ctx + (A,))),)), Proof('imp_intro', Imp(W, A), ctx, (_imp_elim(_weaken(sw, ctx + (W,)), _assume(W, ctx + (W,))),)))))))
    allz = Proof('forall_intro', need, ctx, (iff,))
    eq = _imp_elim(ext, allz)
    imp = Proof('imp_intro', goal.body.body, (), (eq,))
    qa = Proof('forall_intro', goal.body, (), (imp,))
    return Proof('forall_intro', goal, (), (qa,))

def build_omega_zero_one_chain() -> Proof:
    goal = omega_zero_one_chain_formula()
    w = 'w'
    om = goal.body.left
    target = goal.body.right
    ctx = (om,)
    hom = _assume(om, ctx)
    ind = _and_l(hom)
    empty_ex = _and_l(ind)
    closed = _and_r(ind)
    E = 'E'
    instE = substitute(empty_ex.conclusion.body, empty_ex.conclusion.var, V(E))
    ctxE = ctx + (instE,)
    hE = _assume(instE, ctxE)
    Ein = _and_l(hE)
    emptyE = _and_r(hE)
    qe = _forall_elim(_weaken(closed, ctxE), E)
    succ_ex = _imp_elim(qe, Ein)
    S = 'S'
    instS = substitute(succ_ex.conclusion.body, succ_ex.conclusion.var, V(S))
    ctxS = ctxE + (instS,)
    hS = _assume(instS, ctxS)
    Sin = _and_l(hS)
    succS = _and_r(hS)
    inner = target.body.body
    innerES = substitute(substitute(inner, 'z0', V(E)), 'z1', V(S))
    conj = Proof('and_intro', innerES, ctxS, (Proof('and_intro', innerES.left, ctxS, (_weaken(emptyE, ctxS), _weaken(Ein, ctxS))), Proof('and_intro', innerES.right, ctxS, (succS, Sin))))
    exS = Proof('exists_intro', substitute(target.body, 'z0', V(E)), ctxS, (conj,), (('term', {'var': S}),))
    afterS = Proof('exists_elim', substitute(target.body, 'z0', V(E)), ctxE, (succ_ex, exS), (('eigenvar', S),))
    exE = Proof('exists_intro', target, ctxE, (afterS,), (('term', {'var': E}),))
    afterE = Proof('exists_elim', target, ctx, (empty_ex, exE), (('eigenvar', E),))
    imp = Proof('imp_intro', goal.body, (), (afterE,))
    return Proof('forall_intro', goal, (), (imp,))

def build_successor_image_exists(schema_index: int, succ_unique_pf: Proof | None=None) -> Proof:
    succ_unique_pf = succ_unique_pf or build_successor_unique()
    axf = SUCCESSOR_REPLACEMENT_SCHEMA.generated()
    ax = Proof('axiom_schema', axf, (), (), (('schema_index', schema_index),))
    return Proof('imp_elim', successor_image_exists_formula(), (), (ax, succ_unique_pf))

def _preverified(records):
    return tuple((NormalizedLibraryEntry(r.proof, r.identity, (r.name,) if r.name else (), (str(r.kind),) if r.kind else ()) for r in records))

def _op_injective_instance(opinj: Proof, p: str, x: str, y: str, u: str, v: str, op1: Proof, op2: Proof, ctx) -> Proof:
    q = _weaken(opinj, ctx)
    for nm in [p, x, y, u, v]:
        q = _forall_elim(q, nm)
    ante = q.conclusion.left
    conj = Proof('and_intro', ante, ctx, (_weaken(op1, ctx), _weaken(op2, ctx)))
    return _imp_elim(q, conj)

def build_identity_function_exists(identity_schema_index: int=2, cartesian_schema_index: int=1, opinj_pf: Proof | None=None, ordered_pair_pf: Proof | None=None, cartesian_pf: Proof | None=None) -> Proof:
    opinj_pf = opinj_pf or build_ordered_pair_injective()
    ordered_pair_pf = ordered_pair_pf or build_ordered_pair_code_exists()
    cartesian_pf = cartesian_pf or build_cartesian_product_exists(cartesian_schema_index)
    goal = identity_function_exists_formula()
    d = 'd'
    body = goal.body
    ctx = ()
    cp = _forall_elim(_forall_elim(cartesian_pf, d), d)
    assert isinstance(cp.conclusion, Exists)
    C = 'C'
    specC = substitute(cp.conclusion.body, cp.conclusion.var, V(C))
    ctxC = (specC,)
    hC = _assume(specC, ctxC)
    sa = Proof('axiom_schema', IDENTITY_SEPARATION_SCHEMA.generated(), ctxC, (), (('schema_index', identity_schema_index),))
    sd = _forall_elim(sa, d)
    sc = _forall_elim(sd, C)
    assert isinstance(sc.conclusion, Exists)
    F = 'F'
    specF = substitute(sc.conclusion.body, sc.conclusion.var, V(F))
    ctxF = ctxC + (specF,)
    hSep = _assume(specF, ctxF)
    ids = IdentityFunctionSpec(V(F), V(d), 'x')
    fun = ids.left
    diagall = ids.right
    rel = fun.left
    pvar = rel.var
    impR = rel.body
    ctxp = ctxF + (impR.left,)
    hp = _assume(impR.left, ctxp)
    sepP = _forall_elim(_weaken(hSep, ctxp), pvar)
    rhs = _imp_elim(_iff_l(sepP), hp)
    diag = _and_r(rhs)
    assert isinstance(diag.conclusion, Exists)
    T = 'T'
    instT = substitute(diag.conclusion.body, diag.conclusion.var, V(T))
    ctxT = ctxp + (instT,)
    hT = _assume(instT, ctxT)
    Td = _and_l(hT)
    opTT = _and_r(hT)
    rex = impR.right
    instX = substitute(rex.body, rex.var, V(T))
    exY = instX.right
    instY = substitute(exY.body, exY.var, V(T))
    cy = Proof('and_intro', instY, ctxT, (_weaken(Td, ctxT), opTT))
    ey = Proof('exists_intro', exY, ctxT, (cy,), (('term', {'var': T}),))
    cx = Proof('and_intro', instX, ctxT, (_weaken(Td, ctxT), ey))
    exx = Proof('exists_intro', rex, ctxT, (cx,), (('term', {'var': T}),))
    relout = Proof('exists_elim', rex, ctxp, (diag, exx), (('eigenvar', T),))
    ir = Proof('imp_intro', impR, ctxF, (relout,))
    relpf = Proof('forall_intro', rel, ctxF, (ir,))

    def diag_value(xname: str, xmem: Proof, base_ctx: tuple[Formula, ...], pair_eigen: str) -> Proof:
        opx = _forall_elim(_forall_elim(_weaken(ordered_pair_pf, base_ctx), xname), xname)
        assert isinstance(opx.conclusion, Exists)
        P = pair_eigen
        instP = substitute(opx.conclusion.body, opx.conclusion.var, V(P))
        ctxP = base_ctx + (instP,)
        hOP = _assume(instP, ctxP)
        cP = _forall_elim(_weaken(hC, ctxP), P)
        pred = cP.conclusion.right
        assert isinstance(pred, Exists)
        ix = substitute(pred.body, pred.var, V(xname))
        ey = ix.right
        iy = substitute(ey.body, ey.var, V(xname))
        cy = Proof('and_intro', iy, ctxP, (_weaken(xmem, ctxP), hOP))
        exy = Proof('exists_intro', ey, ctxP, (cy,), (('term', {'var': xname}),))
        cx = Proof('and_intro', ix, ctxP, (_weaken(xmem, ctxP), exy))
        expred = Proof('exists_intro', pred, ctxP, (cx,), (('term', {'var': xname}),))
        PC = _imp_elim(_iff_r(cP), expred)
        dp = DiagonalPairPredicate(V(P), V(d), 'x')
        idp = substitute(dp.body, dp.var, V(xname))
        cdp = Proof('and_intro', idp, ctxP, (_weaken(xmem, ctxP), hOP))
        edp = Proof('exists_intro', dp, ctxP, (cdp,), (('term', {'var': xname}),))
        sp = _forall_elim(_weaken(hSep, ctxP), P)
        srhs = Proof('and_intro', sp.conclusion.right, ctxP, (PC, edp))
        PF = _imp_elim(_iff_r(sp), srhs)
        gv = GraphValueSpec(V(F), V(xname), V(xname), 'q')
        igv = substitute(gv.body, gv.var, V(P))
        cgv = Proof('and_intro', igv, ctxP, (PF, hOP))
        egv = Proof('exists_intro', gv, ctxP, (cgv,), (('term', {'var': P}),))
        return Proof('exists_elim', gv, base_ctx, (opx, egv), (('eigenvar', P),))
    total = fun.right.left
    xvar = total.var
    impT = total.body
    ctxx = ctxF + (impT.left,)
    hx = _assume(impT.left, ctxx)
    gv = diag_value(xvar, hx, ctxx, 'Ptot')
    assert isinstance(gv.conclusion, Exists)
    P = 'PV'
    instP = substitute(gv.conclusion.body, gv.conclusion.var, V(P))
    ctxPV = ctxx + (instP,)
    hPV = _assume(instP, ctxPV)
    PF = _and_l(hPV)
    opxx = _and_r(hPV)
    outY = impT.right
    instY = substitute(outY.body, outY.var, V(xvar))
    exPair = instY.right
    instPair = substitute(exPair.body, exPair.var, V(P))
    cp2 = Proof('and_intro', instPair, ctxPV, (PF, opxx))
    ep2 = Proof('exists_intro', exPair, ctxPV, (cp2,), (('term', {'var': P}),))
    cy2 = Proof('and_intro', instY, ctxPV, (_weaken(hx, ctxPV), ep2))
    ey2 = Proof('exists_intro', outY, ctxPV, (cy2,), (('term', {'var': xvar}),))
    totalout = Proof('exists_elim', outY, ctxx, (gv, ey2), (('eigenvar', P),))
    it = Proof('imp_intro', impT, ctxF, (totalout,))
    totalpf = Proof('forall_intro', total, ctxF, (it,))
    unique = fun.right.right
    av = unique.var
    bv = unique.body.var
    b2v = unique.body.body.var
    impU = unique.body.body.body
    ctxu = ctxF + (impU.left,)
    hu = _assume(impU.left, ctxu)
    left = _and_l(hu)
    right = _and_r(hu)
    aD = _and_l(left)
    bD = _and_r(left)
    b2D = _and_l(right)
    pairboth = _and_r(right)
    ex1 = _and_l(pairboth)
    ex2 = _and_r(pairboth)
    P1 = 'P1'
    inst1 = substitute(ex1.conclusion.body, ex1.conclusion.var, V(P1))
    ctx1 = ctxu + (inst1,)
    h1 = _assume(inst1, ctx1)
    ex2w = _weaken(ex2, ctx1)
    P2 = 'P2'
    inst2 = substitute(ex2w.conclusion.body, ex2w.conclusion.var, V(P2))
    ctx2 = ctx1 + (inst2,)
    h2 = _assume(inst2, ctx2)
    P1F = _and_l(_weaken(h1, ctx2))
    op1 = _and_r(_weaken(h1, ctx2))
    P2F = _and_l(h2)
    op2 = _and_r(h2)

    def output_equals_input(Pname: str, PF: Proof, opxy: Proof, yname: str, base_ctx: tuple[Formula, ...], eigen: str) -> Proof:
        sp = _forall_elim(_weaken(hSep, base_ctx), Pname)
        sr = _imp_elim(_iff_l(sp), _weaken(PF, base_ctx))
        dp = _and_r(sr)
        assert isinstance(dp.conclusion, Exists)
        Tn = eigen
        inst = substitute(dp.conclusion.body, dp.conclusion.var, V(Tn))
        ctxe = base_ctx + (inst,)
        he = _assume(inst, ctxe)
        opTT = _and_r(he)
        inj = _op_injective_instance(opinj_pf, Pname, av, yname, Tn, Tn, _weaken(opxy, ctxe), opTT, ctxe)
        xa = _and_l(inj)
        yy = _and_r(inj)
        tx = Proof('eq_symm', Eq(V(Tn), V(av)), ctxe, (xa,))
        yx = Proof('eq_trans', Eq(V(yname), V(av)), ctxe, (yy, tx))
        return Proof('exists_elim', Eq(V(yname), V(av)), base_ctx, (dp, yx), (('eigenvar', Tn),))
    b_eq_a = output_equals_input(P1, P1F, op1, bv, ctx2, 'T1')
    b2_eq_a = output_equals_input(P2, P2F, op2, b2v, ctx2, 'T2')
    a_eq_b2 = Proof('eq_symm', Eq(V(av), V(b2v)), ctx2, (b2_eq_a,))
    bb2 = Proof('eq_trans', Eq(V(bv), V(b2v)), ctx2, (b_eq_a, a_eq_b2))
    after2 = Proof('exists_elim', Eq(V(bv), V(b2v)), ctx1, (ex2w, bb2), (('eigenvar', P2),))
    after1 = Proof('exists_elim', Eq(V(bv), V(b2v)), ctxu, (ex1, after2), (('eigenvar', P1),))
    iu = Proof('imp_intro', impU, ctxF, (after1,))
    q2 = Proof('forall_intro', unique.body.body, ctxF, (iu,))
    q1 = Proof('forall_intro', unique.body, ctxF, (q2,))
    uniquepf = Proof('forall_intro', unique, ctxF, (q1,))
    rest = Proof('and_intro', fun.right, ctxF, (totalpf, uniquepf))
    funpf = Proof('and_intro', fun, ctxF, (relpf, rest))
    xv = diagall.var
    impD = diagall.body
    ctxd = ctxF + (impD.left,)
    hxd = _assume(impD.left, ctxd)
    val = diag_value(xv, hxd, ctxd, 'Pid')
    idi = Proof('imp_intro', impD, ctxF, (val,))
    diagpf = Proof('forall_intro', diagall, ctxF, (idi,))
    idpf = Proof('and_intro', ids, ctxF, (funpf, diagpf))
    exF = Proof('exists_intro', body, ctxF, (idpf,), (('term', {'var': F}),))
    afterF = Proof('exists_elim', body, ctxC, (sc, exF), (('eigenvar', F),))
    afterC = Proof('exists_elim', body, ctx, (cp, afterF), (('eigenvar', C),))
    return Proof('forall_intro', goal, ctx, (afterC,))

def SuccessorImageSpec(b: Term, a: Term, v: str='v', u: str='u') -> Formula:
    avoid = {b.name, a.name}
    v = _fresh_local(v, avoid)
    avoid.add(v)
    u = _fresh_local(u, avoid)
    return Forall(v, Iff(Mem(V(v), b), Exists(u, And(Mem(V(u), a), SuccessorSpec(V(v), V(u), 'z')))))

def omega_successor_image_closed_formula() -> Formula:
    return Forall('w', Imp(OmegaSpec(V('w'), 'j', 'x'), Exists('b', And(SuccessorImageSpec(V('b'), V('w'), 'v', 'u'), SubsetSpec(V('b'), V('w'), 'q')))))

def build_omega_successor_image_closed(successor_image_pf: Proof, succ_unique_pf: Proof | None=None) -> Proof:
    succ_unique_pf = succ_unique_pf or build_successor_unique()
    goal = omega_successor_image_closed_formula()
    w = 'w'
    om = goal.body.left
    target = goal.body.right
    ctx = (om,)
    hom = _assume(om, ctx)
    si = _forall_elim(_weaken(successor_image_pf, ctx), w)
    assert isinstance(si.conclusion, Exists)
    B = 'B'
    specB = substitute(si.conclusion.body, si.conclusion.var, V(B))
    ctxB = ctx + (specB,)
    hB = _assume(specB, ctxB)
    subset = SubsetSpec(V(B), V(w), 'q')
    q = subset.var
    imp = subset.body
    ctxq = ctxB + (imp.left,)
    hq = _assume(imp.left, ctxq)
    imgq = _forall_elim(_weaken(hB, ctxq), q)
    exu = _imp_elim(_iff_l(imgq), hq)
    assert isinstance(exu.conclusion, Exists)
    U = 'U'
    instU = substitute(exu.conclusion.body, exu.conclusion.var, V(U))
    ctxU = ctxq + (instU,)
    hU = _assume(instU, ctxU)
    Uw = _and_l(hU)
    succ_qU = _and_r(hU)
    ind = _and_l(_weaken(hom, ctxU))
    closed = _and_r(ind)
    qu = _forall_elim(closed, U)
    exs = _imp_elim(qu, Uw)
    assert isinstance(exs.conclusion, Exists)
    S = 'S'
    instS = substitute(exs.conclusion.body, exs.conclusion.var, V(S))
    ctxS = ctxU + (instS,)
    hS = _assume(instS, ctxS)
    Sw = _and_l(hS)
    succ_SU = _and_r(hS)
    un = _weaken(succ_unique_pf, ctxS)
    for nm in [U, q, S]:
        un = _forall_elim(un, nm)
    ante = un.conclusion.left
    c = Proof('and_intro', ante, ctxS, (_weaken(succ_qU, ctxS), succ_SU))
    eq_qS = _imp_elim(un, c)
    qw = Proof('eq_subst', Mem(V(q), V(w)), ctxS, (eq_qS, Sw), (('direction', 'rl'),))
    afterS = Proof('exists_elim', Mem(V(q), V(w)), ctxU, (exs, qw), (('eigenvar', S),))
    afterU = Proof('exists_elim', Mem(V(q), V(w)), ctxq, (exu, afterS), (('eigenvar', U),))
    iq = Proof('imp_intro', imp, ctxB, (afterU,))
    subpf = Proof('forall_intro', subset, ctxB, (iq,))
    targetB = substitute(target.body, target.var, V(B))
    both = Proof('and_intro', targetB, ctxB, (hB, subpf))
    exB = Proof('exists_intro', target, ctxB, (both,), (('term', {'var': B}),))
    afterB = Proof('exists_elim', target, ctx, (si, exB), (('eigenvar', B),))
    imppf = Proof('imp_intro', goal.body, (), (afterB,))
    return Proof('forall_intro', goal, (), (imppf,))

def build_pass005_library(schema_prefix: tuple[SchemaInstance, ...]=()) -> tuple[CertifiedStatement, ...]:
    offset = len(schema_prefix)
    schemas = tuple(schema_prefix) + PASS005_SCHEMA_INSTANCES
    k = ZFCKernel(schemas)
    pass004 = build_pass004_math_library(schema_prefix)
    opinj = build_ordered_pair_injective()
    ind = build_omega_induction_subset()
    z01 = build_omega_zero_one_chain()
    succimg = build_successor_image_exists(offset + 3)
    omimg = build_omega_successor_image_closed(succimg)
    ident = build_identity_function_exists(offset + 2, offset + 1, opinj_pf=opinj)
    constf = build_constant_function_exists(offset + 4, offset + 1, opinj_pf=opinj)
    selfun = build_self_function_exists(ident)
    constgraph = build_constant_function_graph_exists(constf)
    fisrel = build_function_is_relation()
    fhas = build_function_has_value()
    funiq = build_function_value_unique()
    extra = [('ZFC_KURATOWSKI_ORDERED_PAIR_INJECTIVE', 'theorem', opinj), ('ZFC_OMEGA_SUBSET_INDUCTION', 'theorem', ind), ('ZFC_OMEGA_ZERO_ONE_CHAIN', 'lemma', z01), ('ZFC_SUCCESSOR_IMAGE_EXISTS_REPLACEMENT', 'theorem', succimg), ('ZFC_OMEGA_SUCCESSOR_IMAGE_SUBSET', 'proposition', omimg), ('ZFC_IDENTITY_FUNCTION_EXISTS_ALL_DOMAINS', 'theorem', ident), ('ZFC_CONSTANT_FUNCTION_EXISTS_WITH_CODOMAIN_WITNESS', 'theorem', constf), ('ZFC_SELF_FUNCTION_EXISTS_ALL_DOMAINS', 'corollary', selfun), ('ZFC_CONSTANT_FUNCTION_GRAPH_EXISTS', 'corollary', constgraph), ('ZFC_FUNCTION_IS_RELATION', 'lemma', fisrel), ('ZFC_FUNCTION_HAS_VALUE_ON_DOMAIN', 'proposition', fhas), ('ZFC_FUNCTION_VALUE_UNIQUE', 'theorem', funiq)]
    records = list(FOUNDATION_LIBRARY) + list(pass004)
    for name, kind, p in extra:
        kr = k.verify(p)
        if not kr.ok:
            raise ValueError(f'PASS005_KERNEL_REJECT:{name}:{kr.detail}')
        records.append(CertifiedStatement(p, name=name, kind=kind, source='PASS005_OMEGA_FUNCTION_LIBRARY'))
    return tuple(records)

def build_constant_function_exists(const_schema_index: int=4, cartesian_schema_index: int=1, opinj_pf: Proof | None=None, ordered_pair_pf: Proof | None=None, cartesian_pf: Proof | None=None) -> Proof:
    opinj_pf = opinj_pf or build_ordered_pair_injective()
    ordered_pair_pf = ordered_pair_pf or build_ordered_pair_code_exists()
    cartesian_pf = cartesian_pf or build_cartesian_product_exists(cartesian_schema_index)
    goal = constant_function_exists_formula()
    d, c, k = ('d', 'c', 'k')
    kc = goal.body.body.body.left
    body = goal.body.body.body.right
    ctx0 = (kc,)
    hkc = _assume(kc, ctx0)
    cp = _forall_elim(_forall_elim(_weaken(cartesian_pf, ctx0), d), c)
    assert isinstance(cp.conclusion, Exists)
    C = 'Cprod'
    specC = substitute(cp.conclusion.body, cp.conclusion.var, V(C))
    ctxC = ctx0 + (specC,)
    hC = _assume(specC, ctxC)
    sa = Proof('axiom_schema', CONSTANT_SEPARATION_SCHEMA.generated(), ctxC, (), (('schema_index', const_schema_index),))
    sd = _forall_elim(sa, d)
    sk = _forall_elim(sd, k)
    sc = _forall_elim(sk, C)
    assert isinstance(sc.conclusion, Exists)
    F = 'Fconst'
    specF = substitute(sc.conclusion.body, sc.conclusion.var, V(F))
    ctxF = ctxC + (specF,)
    hSep = _assume(specF, ctxF)
    cs = ConstantFunctionSpec(V(F), V(d), V(c), V(k), 'x')
    fun = cs.left
    valall = cs.right
    rel = fun.left
    pv = rel.var
    impR = rel.body
    ctxp = ctxF + (impR.left,)
    hp = _assume(impR.left, ctxp)
    sp = _forall_elim(_weaken(hSep, ctxp), pv)
    sr = _imp_elim(_iff_l(sp), hp)
    pred = _and_r(sr)
    assert isinstance(pred.conclusion, Exists)
    T = 'T'
    instT = substitute(pred.conclusion.body, pred.conclusion.var, V(T))
    ctxT = ctxp + (instT,)
    ht = _assume(instT, ctxT)
    Td = _and_l(ht)
    opTk = _and_r(ht)
    rex = impR.right
    ix = substitute(rex.body, rex.var, V(T))
    ey = ix.right
    iy = substitute(ey.body, ey.var, V(k))
    cy = Proof('and_intro', iy, ctxT, (_weaken(hkc, ctxT), opTk))
    exy = Proof('exists_intro', ey, ctxT, (cy,), (('term', {'var': k}),))
    cx = Proof('and_intro', ix, ctxT, (Td, exy))
    exx = Proof('exists_intro', rex, ctxT, (cx,), (('term', {'var': T}),))
    rout = Proof('exists_elim', rex, ctxp, (pred, exx), (('eigenvar', T),))
    rip = Proof('imp_intro', impR, ctxF, (rout,))
    relpf = Proof('forall_intro', rel, ctxF, (rip,))

    def const_value(xname: str, xmem: Proof, base_ctx: tuple[Formula, ...], peigen: str) -> Proof:
        opx = _forall_elim(_forall_elim(_weaken(ordered_pair_pf, base_ctx), xname), k)
        assert isinstance(opx.conclusion, Exists)
        P = peigen
        inst = substitute(opx.conclusion.body, opx.conclusion.var, V(P))
        ctxP = base_ctx + (inst,)
        hop = _assume(inst, ctxP)
        cpP = _forall_elim(_weaken(hC, ctxP), P)
        predC = cpP.conclusion.right
        ix = substitute(predC.body, predC.var, V(xname))
        ey = ix.right
        iy = substitute(ey.body, ey.var, V(k))
        cy = Proof('and_intro', iy, ctxP, (_weaken(hkc, ctxP), hop))
        exy = Proof('exists_intro', ey, ctxP, (cy,), (('term', {'var': k}),))
        cx = Proof('and_intro', ix, ctxP, (_weaken(xmem, ctxP), exy))
        epred = Proof('exists_intro', predC, ctxP, (cx,), (('term', {'var': xname}),))
        PinC = _imp_elim(_iff_r(cpP), epred)
        dp = ConstantPairPredicate(V(P), V(d), V(k), 'x')
        idp = substitute(dp.body, dp.var, V(xname))
        cdp = Proof('and_intro', idp, ctxP, (_weaken(xmem, ctxP), hop))
        edp = Proof('exists_intro', dp, ctxP, (cdp,), (('term', {'var': xname}),))
        sepP = _forall_elim(_weaken(hSep, ctxP), P)
        rhs = Proof('and_intro', sepP.conclusion.right, ctxP, (PinC, edp))
        PinF = _imp_elim(_iff_r(sepP), rhs)
        gv = GraphValueSpec(V(F), V(xname), V(k), 'q')
        ig = substitute(gv.body, gv.var, V(P))
        cg = Proof('and_intro', ig, ctxP, (PinF, hop))
        eg = Proof('exists_intro', gv, ctxP, (cg,), (('term', {'var': P}),))
        return Proof('exists_elim', gv, base_ctx, (opx, eg), (('eigenvar', P),))
    total = fun.right.left
    xv = total.var
    it = total.body
    ctxx = ctxF + (it.left,)
    hx = _assume(it.left, ctxx)
    gv = const_value(xv, hx, ctxx, 'Ptotc')
    P = 'PVc'
    inst = substitute(gv.conclusion.body, gv.conclusion.var, V(P))
    ctxPV = ctxx + (inst,)
    hpv = _assume(inst, ctxPV)
    PF = _and_l(hpv)
    opxk = _and_r(hpv)
    outY = it.right
    iy = substitute(outY.body, outY.var, V(k))
    exPair = iy.right
    ip = substitute(exPair.body, exPair.var, V(P))
    cp2 = Proof('and_intro', ip, ctxPV, (PF, opxk))
    ep = Proof('exists_intro', exPair, ctxPV, (cp2,), (('term', {'var': P}),))
    cy2 = Proof('and_intro', iy, ctxPV, (_weaken(hkc, ctxPV), ep))
    ey2 = Proof('exists_intro', outY, ctxPV, (cy2,), (('term', {'var': k}),))
    tout = Proof('exists_elim', outY, ctxx, (gv, ey2), (('eigenvar', P),))
    tip = Proof('imp_intro', it, ctxF, (tout,))
    totalpf = Proof('forall_intro', total, ctxF, (tip,))
    unique = fun.right.right
    av = unique.var
    bv = unique.body.var
    b2v = unique.body.body.var
    iu = unique.body.body.body
    ctxu = ctxF + (iu.left,)
    hu = _assume(iu.left, ctxu)
    L = _and_l(hu)
    R = _and_r(hu)
    pairboth = _and_r(R)
    ex1 = _and_l(pairboth)
    ex2 = _and_r(pairboth)
    P1 = 'CP1'
    inst1 = substitute(ex1.conclusion.body, ex1.conclusion.var, V(P1))
    ctx1 = ctxu + (inst1,)
    h1 = _assume(inst1, ctx1)
    ex2w = _weaken(ex2, ctx1)
    P2 = 'CP2'
    inst2 = substitute(ex2w.conclusion.body, ex2w.conclusion.var, V(P2))
    ctx2 = ctx1 + (inst2,)
    h2 = _assume(inst2, ctx2)
    P1F = _and_l(_weaken(h1, ctx2))
    op1 = _and_r(_weaken(h1, ctx2))
    P2F = _and_l(h2)
    op2 = _and_r(h2)

    def out_eq_k(Pname: str, PF: Proof, opxy: Proof, yname: str, base_ctx: tuple[Formula, ...], eigen: str) -> Proof:
        sp = _forall_elim(_weaken(hSep, base_ctx), Pname)
        sr = _imp_elim(_iff_l(sp), _weaken(PF, base_ctx))
        dp = _and_r(sr)
        assert isinstance(dp.conclusion, Exists)
        Tn = eigen
        inst = substitute(dp.conclusion.body, dp.conclusion.var, V(Tn))
        ctxe = base_ctx + (inst,)
        he = _assume(inst, ctxe)
        opTk = _and_r(he)
        inj = _op_injective_instance(opinj_pf, Pname, av, yname, Tn, k, _weaken(opxy, ctxe), opTk, ctxe)
        return Proof('exists_elim', Eq(V(yname), V(k)), base_ctx, (dp, _and_r(inj)), (('eigenvar', Tn),))
    bk = out_eq_k(P1, P1F, op1, bv, ctx2, 'CT1')
    b2k = out_eq_k(P2, P2F, op2, b2v, ctx2, 'CT2')
    kb2 = Proof('eq_symm', Eq(V(k), V(b2v)), ctx2, (b2k,))
    bb2 = Proof('eq_trans', Eq(V(bv), V(b2v)), ctx2, (bk, kb2))
    a2 = Proof('exists_elim', Eq(V(bv), V(b2v)), ctx1, (ex2w, bb2), (('eigenvar', P2),))
    a1 = Proof('exists_elim', Eq(V(bv), V(b2v)), ctxu, (ex1, a2), (('eigenvar', P1),))
    iup = Proof('imp_intro', iu, ctxF, (a1,))
    q2 = Proof('forall_intro', unique.body.body, ctxF, (iup,))
    q1 = Proof('forall_intro', unique.body, ctxF, (q2,))
    uniquepf = Proof('forall_intro', unique, ctxF, (q1,))
    rest = Proof('and_intro', fun.right, ctxF, (totalpf, uniquepf))
    funpf = Proof('and_intro', fun, ctxF, (relpf, rest))
    xvv = valall.var
    iv = valall.body
    ctxv = ctxF + (iv.left,)
    hv = _assume(iv.left, ctxv)
    vpf = const_value(xvv, hv, ctxv, 'Pvalc')
    vip = Proof('imp_intro', iv, ctxF, (vpf,))
    valpf = Proof('forall_intro', valall, ctxF, (vip,))
    cspf = Proof('and_intro', cs, ctxF, (funpf, valpf))
    exF = Proof('exists_intro', body, ctxF, (cspf,), (('term', {'var': F}),))
    afterF = Proof('exists_elim', body, ctxC, (sc, exF), (('eigenvar', F),))
    afterC = Proof('exists_elim', body, ctx0, (cp, afterF), (('eigenvar', C),))
    imp = Proof('imp_intro', goal.body.body.body, (), (afterC,))
    qk = Proof('forall_intro', goal.body.body, (), (imp,))
    qc = Proof('forall_intro', goal.body, (), (qk,))
    return Proof('forall_intro', goal, (), (qc,))

def self_function_exists_formula() -> Formula:
    return Forall('d', Exists('f', FunctionGraphSpec(V('f'), V('d'), V('d'), 'p', 'x', 'y', 'y2')))

def constant_function_graph_exists_formula() -> Formula:
    return Forall('d', Forall('c', Forall('k', Imp(Mem(V('k'), V('c')), Exists('f', FunctionGraphSpec(V('f'), V('d'), V('c'), 'p', 'x', 'y', 'y2'))))))

def function_is_relation_formula() -> Formula:
    return Forall('f', Forall('d', Forall('c', Imp(FunctionGraphSpec(V('f'), V('d'), V('c'), 'p', 'x', 'y', 'y2'), RelationGraphSpec(V('f'), V('d'), V('c'), 'p', 'x', 'y')))))

def function_has_value_formula() -> Formula:
    fun = FunctionGraphSpec(V('f'), V('d'), V('c'), 'p', 'x', 'y', 'y2')
    return Forall('f', Forall('d', Forall('c', Forall('x', Imp(And(fun, Mem(V('x'), V('d'))), Exists('y', And(Mem(V('y'), V('c')), GraphValueSpec(V('f'), V('x'), V('y'), 'q'))))))))

def function_value_unique_formula() -> Formula:
    fun = FunctionGraphSpec(V('f'), V('d'), V('c'), 'p', 'x0', 'y0', 'y20')
    ante = And(fun, And(Mem(V('x'), V('d')), And(Mem(V('y'), V('c')), And(Mem(V('y2'), V('c')), And(GraphValueSpec(V('f'), V('x'), V('y'), 'q'), GraphValueSpec(V('f'), V('x'), V('y2'), 'r'))))))
    return Forall('f', Forall('d', Forall('c', Forall('x', Forall('y', Forall('y2', Imp(ante, Eq(V('y'), V('y2')))))))))

def build_self_function_exists(identity_pf: Proof) -> Proof:
    goal = self_function_exists_formula()
    d = 'd'
    body = goal.body
    ex = _forall_elim(identity_pf, d)
    assert isinstance(ex.conclusion, Exists)
    F = 'SF'
    inst = substitute(ex.conclusion.body, ex.conclusion.var, V(F))
    ctx = (inst,)
    hi = _assume(inst, ctx)
    fun = _and_l(hi)
    ef = Proof('exists_intro', body, ctx, (fun,), (('term', {'var': F}),))
    out = Proof('exists_elim', body, (), (ex, ef), (('eigenvar', F),))
    return Proof('forall_intro', goal, (), (out,))

def build_constant_function_graph_exists(const_pf: Proof) -> Proof:
    goal = constant_function_graph_exists_formula()
    d, c, k = ('d', 'c', 'k')
    prem = goal.body.body.body.left
    body = goal.body.body.body.right
    ctx = (prem,)
    ex = _forall_elim(_forall_elim(_forall_elim(_weaken(const_pf, ctx), d), c), k)
    ex = _imp_elim(ex, _assume(prem, ctx))
    assert isinstance(ex.conclusion, Exists)
    F = 'CF'
    inst = substitute(ex.conclusion.body, ex.conclusion.var, V(F))
    ctxF = ctx + (inst,)
    hi = _assume(inst, ctxF)
    fun = _and_l(hi)
    ef = Proof('exists_intro', body, ctxF, (fun,), (('term', {'var': F}),))
    out = Proof('exists_elim', body, ctx, (ex, ef), (('eigenvar', F),))
    imp = Proof('imp_intro', goal.body.body.body, (), (out,))
    qk = Proof('forall_intro', goal.body.body, (), (imp,))
    qc = Proof('forall_intro', goal.body, (), (qk,))
    return Proof('forall_intro', goal, (), (qc,))

def build_function_is_relation() -> Proof:
    goal = function_is_relation_formula()
    fun = goal.body.body.body.left
    ctx = (fun,)
    hf = _assume(fun, ctx)
    rel = _and_l(hf)
    imp = Proof('imp_intro', goal.body.body.body, (), (rel,))
    qc = Proof('forall_intro', goal.body.body, (), (imp,))
    qd = Proof('forall_intro', goal.body, (), (qc,))
    return Proof('forall_intro', goal, (), (qd,))

def build_function_has_value() -> Proof:
    goal = function_has_value_formula()
    ante = goal.body.body.body.body.left
    ctx = (ante,)
    h = _assume(ante, ctx)
    fun = _and_l(h)
    xd = _and_r(h)
    total = _and_l(_and_r(fun))
    q = _forall_elim(total, 'x')
    out = _imp_elim(q, xd)
    imp = Proof('imp_intro', goal.body.body.body.body, (), (out,))
    qx = Proof('forall_intro', goal.body.body.body, (), (imp,))
    qc = Proof('forall_intro', goal.body.body, (), (qx,))
    qd = Proof('forall_intro', goal.body, (), (qc,))
    return Proof('forall_intro', goal, (), (qd,))

def build_function_value_unique() -> Proof:
    goal = function_value_unique_formula()
    ante = goal.body.body.body.body.body.body.left
    ctx = (ante,)
    h = _assume(ante, ctx)
    fun = _and_l(h)
    r1 = _and_r(h)
    xd = _and_l(r1)
    r2 = _and_r(r1)
    yd = _and_l(r2)
    r3 = _and_r(r2)
    y2d = _and_l(r3)
    vals = _and_r(r3)
    gv1 = _and_l(vals)
    gv2 = _and_r(vals)
    unique = _and_r(_and_r(fun))
    q = unique
    for nm in ['x', 'y', 'y2']:
        q = _forall_elim(q, nm)
    uante = q.conclusion.left
    left = Proof('and_intro', uante.left, ctx, (xd, yd))
    exright = uante.right.right
    ex1 = gv1
    ex2 = gv2
    rr = Proof('and_intro', uante.right.right, ctx, (ex1, ex2))
    right = Proof('and_intro', uante.right, ctx, (y2d, rr))
    allante = Proof('and_intro', uante, ctx, (left, right))
    eq = _imp_elim(q, allante)
    imp = Proof('imp_intro', goal.body.body.body.body.body.body, (), (eq,))
    qy2 = Proof('forall_intro', goal.body.body.body.body.body, (), (imp,))
    qy = Proof('forall_intro', goal.body.body.body.body, (), (qy2,))
    qx = Proof('forall_intro', goal.body.body.body, (), (qy,))
    qc = Proof('forall_intro', goal.body.body, (), (qx,))
    qd = Proof('forall_intro', goal.body, (), (qc,))
    return Proof('forall_intro', goal, (), (qd,))
PASS005_FULL_LIBRARY = build_pass005_library(())
PASS005_NORMALIZED_LIBRARY = _preverified(PASS005_FULL_LIBRARY)
