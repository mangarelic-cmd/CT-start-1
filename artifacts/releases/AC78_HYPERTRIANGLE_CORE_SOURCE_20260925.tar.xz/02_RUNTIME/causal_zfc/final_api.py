from __future__ import annotations
import hashlib
from pathlib import Path
from .logic import digest_formula
from .proof import proof_digest
from .kernel import ZFCKernel
from .semantic import CANONICAL_STATEMENT_KIND
from .final_global_arithmetic import PASS010_SCHEMA_INSTANCES, build_add_global_operation_exists, build_mul_global_operation_exists, build_exp_global_operation_exists, build_add_one_one, build_mul_two_one, build_exp_two_zero, add_one_one_formula, mul_two_one_formula, exp_two_zero_formula, global_operation_exists_formula, AddSectionHidden, MulSectionHidden, ExpSectionHidden
_BUILDERS = {'ADD_GLOBAL_GRAPH': build_add_global_operation_exists, 'MUL_GLOBAL_GRAPH': build_mul_global_operation_exists, 'EXP_GLOBAL_GRAPH': build_exp_global_operation_exists, 'ADD_1_1_EQ_2': build_add_one_one, 'MUL_2_1_EQ_2': build_mul_two_one, 'EXP_2_0_EQ_1': build_exp_two_zero}
_FORMULAS = {'ADD_GLOBAL_GRAPH': lambda: global_operation_exists_formula(AddSectionHidden), 'MUL_GLOBAL_GRAPH': lambda: global_operation_exists_formula(MulSectionHidden), 'EXP_GLOBAL_GRAPH': lambda: global_operation_exists_formula(ExpSectionHidden), 'ADD_1_1_EQ_2': add_one_one_formula, 'MUL_2_1_EQ_2': mul_two_one_formula, 'EXP_2_0_EQ_1': exp_two_zero_formula}

def final_capability_registry() -> dict:
    return {'schema': 'CAUSAL_ZFC_FINAL_CAPABILITY_REGISTRY_V1', 'version': '1.10', 'pass': 'PASS011_CAUSAL_INVARIANT', 'canonical_statement_kind': CANONICAL_STATEMENT_KIND, 'truth_authority': 'ZFCKernel', 'schema_instance_count': len(PASS010_SCHEMA_INSTANCES), 'capabilities': {k: {'formula_digest': digest_formula(v())} for k, v in _FORMULAS.items()}, 'open_result_dispatch': 'PROOF_DEFECT_OR_SOLVER', 'ac_two_cell_geometry_embedded': False, 'causal_two_cell_invariant_bridge': True, 'causal_state_gates': ['STRUCTURAL_CLOSURE', 'STATE_SELECTOR_VERIFIED', 'FORMAL_PROOF_CLOSED'], 'coordinate_gauge_authoritative': False}

def build_final_proof(capability: str):
    if capability not in _BUILDERS:
        raise KeyError(capability)
    p = _BUILDERS[capability]()
    r = ZFCKernel(PASS010_SCHEMA_INSTANCES).verify(p)
    if not r.ok:
        raise RuntimeError(f'kernel reject {r.code}: {r.detail}')
    return p

def final_proof_receipt(capability: str) -> dict:
    p = build_final_proof(capability)
    return {'capability': capability, 'formula_digest': digest_formula(p.conclusion), 'proof_digest': proof_digest(p), 'kernel': 'PASS'}
