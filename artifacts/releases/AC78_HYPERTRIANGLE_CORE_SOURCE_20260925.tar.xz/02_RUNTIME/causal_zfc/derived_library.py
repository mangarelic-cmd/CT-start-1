from __future__ import annotations
from dataclasses import dataclass
from .logic import *
from .proof import *
from .axioms import FIXED_AXIOMS
from .kernel import ZFCKernel
from .semantic import CertifiedStatement
from .setdefs import *

def _ax(aid: str, ctx=()) -> Proof:
    return Proof('axiom_fixed', FIXED_AXIOMS[aid], tuple(ctx), (), (('axiom_id', aid),))

def _assume(f: Formula, ctx) -> Proof:
    return Proof('assumption', f, tuple(ctx))

def _forall_elim(p: Proof, name: str, ctx=None) -> Proof:
    assert isinstance(p.conclusion, Forall)
    c = substitute(p.conclusion.body, p.conclusion.var, V(name))
    return Proof('forall_elim', c, p.context if ctx is None else tuple(ctx), (p,), (('term', {'var': name}),))

def _and_l(p: Proof) -> Proof:
    assert isinstance(p.conclusion, And)
    return Proof('and_elim_left', p.conclusion.left, p.context, (p,))

def _and_r(p: Proof) -> Proof:
    assert isinstance(p.conclusion, And)
    return Proof('and_elim_right', p.conclusion.right, p.context, (p,))

def _imp_elim(pi: Proof, pa: Proof) -> Proof:
    assert isinstance(pi.conclusion, Imp)
    return Proof('imp_elim', pi.conclusion.right, pi.context, (pi, pa))

def _iff_l(p: Proof) -> Proof:
    assert isinstance(p.conclusion, Iff)
    return Proof('iff_elim_left', Imp(p.conclusion.left, p.conclusion.right), p.context, (p,))

def _iff_r(p: Proof) -> Proof:
    assert isinstance(p.conclusion, Iff)
    return Proof('iff_elim_right', Imp(p.conclusion.right, p.conclusion.left), p.context, (p,))

def _weaken(p: Proof, ctx) -> Proof:
    return p if ctx_equiv(p.context, tuple(ctx)) else Proof('weakening', p.conclusion, tuple(ctx), (p,))

def empty_exists_formula() -> Formula:
    return Exists('e', EmptySpec(V('e'), 'z'))

def singleton_exists_formula() -> Formula:
    return Forall('x', Exists('s', SingletonSpec(V('s'), V('x'), 'w')))

def unordered_pair_exists_formula() -> Formula:
    return Forall('x', Forall('y', Exists('p', PairSpec(V('p'), V('x'), V('y'), 'w'))))

def ordered_pair_code_exists_formula() -> Formula:
    return Forall('x', Forall('y', Exists('p', OrderedPairCode(V('p'), V('x'), V('y'), 'a', 'b'))))

def union_exists_formula() -> Formula:
    return Forall('x', Exists('u', UnionSpec(V('u'), V('x'), 'z', 'w')))

def power_set_exists_formula() -> Formula:
    return Forall('x', Exists('p', PowerSetSpec(V('p'), V('x'), 'z', 'w')))

def inductive_set_exists_formula() -> Formula:
    return Exists('i', InductiveSetSpec(V('i'), 'e', 'y', 's', 'z'))

def subset_reflexive_formula() -> Formula:
    return Forall('x', SubsetSpec(V('x'), V('x'), 'z'))

def empty_unique_formula() -> Formula:
    e, d = (V('e'), V('d'))
    return Forall('e', Forall('d', Imp(And(EmptySpec(e, 'z'), EmptySpec(d, 'u')), Eq(e, d))))

def build_empty_exists() -> Proof:
    goal = empty_exists_formula()
    ctx = ()
    inf = _ax('INFINITY', ctx)
    assert isinstance(inf.conclusion, Exists)
    X = 'I'
    instX = substitute(inf.conclusion.body, inf.conclusion.var, V(X))
    ctx1 = (instX,)
    hX = _assume(instX, ctx1)
    left = _and_l(hX)
    assert isinstance(left.conclusion, Exists)
    E = 'E'
    instE = substitute(left.conclusion.body, left.conclusion.var, V(E))
    ctx2 = ctx1 + (instE,)
    hE = _assume(instE, ctx2)
    emptyE = _and_r(hE)
    exE = Proof('exists_intro', goal, ctx2, (emptyE,), (('term', {'var': E}),))
    inner = Proof('exists_elim', goal, ctx1, (_weaken(left, ctx1), exE), (('eigenvar', E),))
    return Proof('exists_elim', goal, ctx, (inf, inner), (('eigenvar', X),))

def build_singleton_exists() -> Proof:
    goal = singleton_exists_formula()
    x = 'x'
    ctx = ()
    inner_goal = goal.body
    pair = _ax('PAIRING', ctx)
    px = _forall_elim(pair, x)
    pxx = _forall_elim(px, x)
    assert isinstance(pxx.conclusion, Exists)
    S = 'S'
    spec_pair = substitute(pxx.conclusion.body, pxx.conclusion.var, V(S))
    ctx1 = (spec_pair,)
    hspec = _assume(spec_pair, ctx1)
    w = 'w'
    iff_dup = _forall_elim(hspec, w)
    A = Mem(V(w), V(S))
    B = Eq(V(w), V(x))
    target_iff = Iff(A, B)
    ctxA = ctx1 + (A,)
    hiffA = _weaken(iff_dup, ctxA)
    AtoOr = _iff_l(hiffA)
    hA = _assume(A, ctxA)
    disj = _imp_elim(AtoOr, hA)
    assert isinstance(disj.conclusion, Or)
    ctxAB = ctxA + (B,)
    b1 = _assume(B, ctxAB)
    b2 = _assume(B, ctxAB)
    or_to_b = Proof('or_elim', B, ctxA, (disj, b1, b2))
    AimpB = Proof('imp_intro', Imp(A, B), ctx1, (or_to_b,))
    ctxB = ctx1 + (B,)
    hB = _assume(B, ctxB)
    bor = Proof('or_intro_left', Or(B, B), ctxB, (hB,))
    hiffB = _weaken(iff_dup, ctxB)
    OrtoA = _iff_r(hiffB)
    aval = _imp_elim(OrtoA, bor)
    BimpA = Proof('imp_intro', Imp(B, A), ctx1, (aval,))
    iff = Proof('iff_intro', target_iff, ctx1, (AimpB, BimpA))
    singleton = Proof('forall_intro', SingletonSpec(V(S), V(x), 'w'), ctx1, (iff,))
    exS = Proof('exists_intro', inner_goal, ctx1, (singleton,), (('term', {'var': S}),))
    body = Proof('exists_elim', inner_goal, ctx, (pxx, exS), (('eigenvar', S),))
    return Proof('forall_intro', goal, ctx, (body,))

def build_unordered_pair_exists() -> Proof:
    goal = unordered_pair_exists_formula()
    return Proof('axiom_fixed', goal, (), (), (('axiom_id', 'PAIRING'),))

def build_union_exists() -> Proof:
    return Proof('axiom_fixed', union_exists_formula(), (), (), (('axiom_id', 'UNION'),))

def build_power_set_exists() -> Proof:
    return Proof('axiom_fixed', power_set_exists_formula(), (), (), (('axiom_id', 'POWER_SET'),))

def build_inductive_set_exists() -> Proof:
    return Proof('axiom_fixed', inductive_set_exists_formula(), (), (), (('axiom_id', 'INFINITY'),))

def build_subset_reflexive() -> Proof:
    goal = subset_reflexive_formula()
    x = 'x'
    z = 'z'
    ctx = ()
    mem = Mem(V(z), V(x))
    ctx1 = (mem,)
    hm = _assume(mem, ctx1)
    imp = Proof('imp_intro', Imp(mem, mem), (), (hm,))
    allz = Proof('forall_intro', SubsetSpec(V(x), V(x), 'z'), (), (imp,))
    return Proof('forall_intro', goal, (), (allz,))

def build_empty_unique() -> Proof:
    goal = empty_unique_formula()
    e, d = (V('e'), V('d'))
    premise = And(EmptySpec(e, 'z'), EmptySpec(d, 'u'))
    ctx = (premise,)
    hp = _assume(premise, ctx)
    ee = _and_l(hp)
    dd = _and_r(hp)
    ext = _ax('EXTENSIONALITY', ctx)
    exte = _forall_elim(ext, 'e')
    exted = _forall_elim(exte, 'd')
    need = exted.conclusion.left
    assert isinstance(need, Forall)
    z = need.var
    A = Mem(V(z), e)
    B = Mem(V(z), d)
    ctxA = ctx + (A,)
    eeA = _weaken(ee, ctxA)
    ne = _forall_elim(eeA, z)
    hA = _assume(A, ctxA)
    bot = _imp_elim(ne, hA)
    b = Proof('bottom_elim', B, ctxA, (bot,))
    AimpB = Proof('imp_intro', Imp(A, B), ctx, (b,))
    ctxB = ctx + (B,)
    ddB = _weaken(dd, ctxB)
    nd = _forall_elim(ddB, z)
    hB = _assume(B, ctxB)
    bot2 = _imp_elim(nd, hB)
    a = Proof('bottom_elim', A, ctxB, (bot2,))
    BimpA = Proof('imp_intro', Imp(B, A), ctx, (a,))
    iff = Proof('iff_intro', Iff(A, B), ctx, (AimpB, BimpA))
    allz = Proof('forall_intro', need, ctx, (iff,))
    eq = _imp_elim(exted, allz)
    imp = Proof('imp_intro', Imp(premise, Eq(e, d)), (), (eq,))
    alld = Proof('forall_intro', goal.body, (), (imp,))
    return Proof('forall_intro', goal, (), (alld,))

def build_ordered_pair_code_exists(singleton_pf: Proof | None=None) -> Proof:
    singleton_pf = singleton_pf or build_singleton_exists()
    goal = ordered_pair_code_exists_formula()
    ctx = ()
    x = 'x'
    y = 'y'
    body_y = goal.body.body
    sx = _forall_elim(singleton_pf, x)
    assert isinstance(sx.conclusion, Exists)
    Aname = 'A'
    specA = substitute(sx.conclusion.body, sx.conclusion.var, V(Aname))
    ctxA = (specA,)
    hA = _assume(specA, ctxA)
    pairA = _ax('PAIRING', ctxA)
    p1 = _forall_elim(pairA, x)
    p2 = _forall_elim(p1, y)
    Bname = 'B'
    specB = substitute(p2.conclusion.body, p2.conclusion.var, V(Bname))
    ctxB = ctxA + (specB,)
    hB = _assume(specB, ctxB)
    pairB = _ax('PAIRING', ctxB)
    q1 = _forall_elim(pairB, Aname)
    q2 = _forall_elim(q1, Bname)
    Pname = 'P'
    specP = substitute(q2.conclusion.body, q2.conclusion.var, V(Pname))
    ctxP = ctxB + (specP,)
    hP = _assume(specP, ctxP)
    code = OrderedPairCode(V(Pname), V(x), V(y), 'a', 'b')
    conjBP = Proof('and_intro', And(specB, specP), ctxP, (_weaken(hB, ctxP), hP))
    conj = Proof('and_intro', And(specA, And(specB, specP)), ctxP, (_weaken(hA, ctxP), conjBP))
    code_after_a = substitute(code.body, 'a', V(Aname))
    exb = Proof('exists_intro', code_after_a, ctxP, (conj,), (('term', {'var': Bname}),))
    exa = Proof('exists_intro', code, ctxP, (exb,), (('term', {'var': Aname}),))
    exp = Proof('exists_intro', body_y, ctxP, (exa,), (('term', {'var': Pname}),))
    afterP = Proof('exists_elim', body_y, ctxB, (q2, exp), (('eigenvar', Pname),))
    afterB = Proof('exists_elim', body_y, ctxA, (p2, afterP), (('eigenvar', Bname),))
    afterA = Proof('exists_elim', body_y, ctx, (sx, afterB), (('eigenvar', Aname),))
    ally = Proof('forall_intro', goal.body, ctx, (afterA,))
    return Proof('forall_intro', goal, ctx, (ally,))

def build_foundation_library() -> tuple[CertifiedStatement, ...]:
    builders = [('ZFC_DERIVED_EMPTY_EXISTS', 'theorem', build_empty_exists), ('ZFC_DERIVED_SINGLETON_EXISTS', 'lemma', build_singleton_exists), ('ZFC_PAIRING_EXISTS', 'proposition', build_unordered_pair_exists), ('ZFC_UNION_EXISTS', 'lemma', build_union_exists), ('ZFC_POWER_SET_EXISTS', 'theorem', build_power_set_exists), ('ZFC_INDUCTIVE_SET_EXISTS', 'result', build_inductive_set_exists), ('ZFC_SUBSET_REFLEXIVE', 'result', build_subset_reflexive), ('ZFC_EMPTY_UNIQUE', 'corollary', build_empty_unique)]
    proofs = []
    kernel = ZFCKernel()
    for name, kind, b in builders:
        p = b()
        kr = kernel.verify(p)
        if not kr.ok:
            raise ValueError(f'DERIVED_LIBRARY_KERNEL_REJECT:{name}:{kr.detail}')
        proofs.append(CertifiedStatement(p, name=name, kind=kind, source='PASS003_FOUNDATION_LIBRARY'))
    op = build_ordered_pair_code_exists(proofs[1].proof)
    kr = kernel.verify(op)
    if not kr.ok:
        raise ValueError(f'DERIVED_LIBRARY_KERNEL_REJECT:ORDERED_PAIR:{kr.detail}')
    proofs.append(CertifiedStatement(op, name='ZFC_DERIVED_KURATOWSKI_ORDERED_PAIR_CODE_EXISTS', kind='theorem', source='PASS003_FOUNDATION_LIBRARY'))
    return tuple(proofs)
FOUNDATION_LIBRARY = build_foundation_library()
