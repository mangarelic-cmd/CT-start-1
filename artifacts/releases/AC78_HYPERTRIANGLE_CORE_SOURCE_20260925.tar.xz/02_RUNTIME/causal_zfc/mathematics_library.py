from __future__ import annotations
from .logic import *
from .proof import *
from .axioms import FIXED_AXIOMS, SchemaInstance
from .kernel import ZFCKernel
from .semantic import CertifiedStatement
from .setdefs import *
from .derived_library import _ax, _assume, _forall_elim, _and_l, _and_r, _imp_elim, _iff_l, _iff_r, _weaken, build_empty_exists, build_empty_unique, build_singleton_exists, build_ordered_pair_code_exists, FOUNDATION_LIBRARY

def BinaryUnionSpec(u: Term, a: Term, b: Term, z: str='z') -> Formula:
    return Forall(z, Iff(Mem(V(z), u), Or(Mem(V(z), a), Mem(V(z), b))))

def OmegaPredicate(x: Term, j: str='j') -> Formula:
    return Forall(j, Imp(InductiveSetSpec(V(j), 'e', 'y', 's', 'z'), Mem(x, V(j))))

def OmegaSpec(w: Term, j: str='j', x: str='x') -> Formula:
    return And(InductiveSetSpec(w, 'e', 'y', 's', 'z'), Forall(j, Imp(InductiveSetSpec(V(j), 'e2', 'y2', 's2', 'z2'), SubsetSpec(w, V(j), x))))

def CartesianProductPredicate(p: Term, a: Term, b: Term, x: str='x', y: str='y') -> Formula:
    return Exists(x, And(Mem(V(x), a), Exists(y, And(Mem(V(y), b), OrderedPairCode(p, V(x), V(y), 'q', 'r')))))

def CartesianProductSpec(c: Term, a: Term, b: Term, p: str='p') -> Formula:
    return Forall(p, Iff(Mem(V(p), c), CartesianProductPredicate(V(p), a, b, 'x', 'y')))

def pair_unique_formula() -> Formula:
    x, y, p, q = (V('x'), V('y'), V('p'), V('q'))
    return Forall('x', Forall('y', Forall('p', Forall('q', Imp(And(PairSpec(p, x, y, 'z'), PairSpec(q, x, y, 'u')), Eq(p, q))))))

def successor_unique_formula() -> Formula:
    x, s, t = (V('x'), V('s'), V('t'))
    return Forall('x', Forall('s', Forall('t', Imp(And(SuccessorSpec(s, x, 'z'), SuccessorSpec(t, x, 'u')), Eq(s, t)))))

def successor_exists_formula() -> Formula:
    return Forall('x', Exists('s', SuccessorSpec(V('s'), V('x'), 'z')))

def binary_union_exists_formula() -> Formula:
    return Forall('a', Forall('b', Exists('u', BinaryUnionSpec(V('u'), V('a'), V('b'), 'z'))))

def omega_exists_formula() -> Formula:
    return Exists('w', OmegaSpec(V('w'), 'j', 'x'))

def cartesian_product_exists_formula() -> Formula:
    return Forall('a', Forall('b', Exists('c', CartesianProductSpec(V('c'), V('a'), V('b'), 'p'))))

def empty_relation_exists_formula() -> Formula:
    return Forall('d', Forall('c', Exists('r', And(EmptySpec(V('r'), 'z'), RelationGraphSpec(V('r'), V('d'), V('c'), 'p', 'x', 'y')))))

def empty_function_exists_formula() -> Formula:
    return Forall('c', Exists('e', And(EmptySpec(V('e'), 'z'), FunctionGraphSpec(V('e'), V('e'), V('c'), 'p', 'x', 'y', 'y2'))))

def _iff_via_common(a: Formula, b: Formula, common: Formula, pa: Proof, pb: Proof, ctx: tuple[Formula, ...]) -> Proof:
    ctxa = ctx_add(ctx, a)
    ha = _assume(a, ctxa)
    a2c = _weaken(_iff_l(pa), ctxa)
    c = _imp_elim(a2c, ha)
    c2b = _weaken(_iff_r(pb), ctxa)
    bout = _imp_elim(c2b, c)
    ai = Proof('imp_intro', Imp(a, b), ctx, (bout,))
    ctxb = ctx_add(ctx, b)
    hb = _assume(b, ctxb)
    b2c = _weaken(_iff_l(pb), ctxb)
    c2 = _imp_elim(b2c, hb)
    c2a = _weaken(_iff_r(pa), ctxb)
    aout = _imp_elim(c2a, c2)
    bi = Proof('imp_intro', Imp(b, a), ctx, (aout,))
    return Proof('iff_intro', Iff(a, b), ctx, (ai, bi))

def _build_spec_unique(spec_fn, formula: Formula) -> Proof:
    if formula == pair_unique_formula():
        x, y, p, q = (V('x'), V('y'), V('p'), V('q'))
        prem = And(PairSpec(p, x, y, 'z'), PairSpec(q, x, y, 'u'))
        ctx = (prem,)
        hp = _assume(prem, ctx)
        sp = _and_l(hp)
        sq = _and_r(hp)
        ext = _forall_elim(_forall_elim(_ax('EXTENSIONALITY', ctx), 'p'), 'q')
        need = ext.conclusion.left
        assert isinstance(need, Forall)
        z = need.var
        pz = _forall_elim(sp, z)
        qz = _forall_elim(sq, z)
        a = Mem(V(z), p)
        b = Mem(V(z), q)
        common = Or(Eq(V(z), x), Eq(V(z), y))
        iff = _iff_via_common(a, b, common, pz, qz, ctx)
        allz = Proof('forall_intro', need, ctx, (iff,))
        eq = _imp_elim(ext, allz)
        imp = Proof('imp_intro', Imp(prem, Eq(p, q)), (), (eq,))
        qp = Proof('forall_intro', formula.body.body.body, (), (imp,))
        pp = Proof('forall_intro', formula.body.body, (), (qp,))
        yy = Proof('forall_intro', formula.body, (), (pp,))
        return Proof('forall_intro', formula, (), (yy,))
    x, s, t = (V('x'), V('s'), V('t'))
    prem = And(SuccessorSpec(s, x, 'z'), SuccessorSpec(t, x, 'u'))
    ctx = (prem,)
    hp = _assume(prem, ctx)
    ss = _and_l(hp)
    st = _and_r(hp)
    ext = _forall_elim(_forall_elim(_ax('EXTENSIONALITY', ctx), 's'), 't')
    need = ext.conclusion.left
    assert isinstance(need, Forall)
    z = need.var
    sz = _forall_elim(ss, z)
    tz = _forall_elim(st, z)
    a = Mem(V(z), s)
    b = Mem(V(z), t)
    common = Or(Mem(V(z), x), Eq(V(z), x))
    iff = _iff_via_common(a, b, common, sz, tz, ctx)
    allz = Proof('forall_intro', need, ctx, (iff,))
    eq = _imp_elim(ext, allz)
    imp = Proof('imp_intro', Imp(prem, Eq(s, t)), (), (eq,))
    tt = Proof('forall_intro', formula.body.body, (), (imp,))
    ssq = Proof('forall_intro', formula.body, (), (tt,))
    return Proof('forall_intro', formula, (), (ssq,))

def build_pair_unique() -> Proof:
    return _build_spec_unique(PairSpec, pair_unique_formula())

def build_successor_unique() -> Proof:
    return _build_spec_unique(SuccessorSpec, successor_unique_formula())

def _member_from_pair_spec(spec: Proof, elem: str, side: str, ctx) -> Proof:
    iff = _forall_elim(_weaken(spec, ctx), elem)
    if side == 'left':
        eq = Proof('eq_refl', Eq(V(elem), iff.conclusion.right.left.right if False else V(elem)), ctx)
    raise RuntimeError('unused')

def build_successor_exists(singleton_pf: Proof | None=None) -> Proof:
    singleton_pf = singleton_pf or build_singleton_exists()
    goal = successor_exists_formula()
    x = 'x'
    ctx = ()
    body = goal.body
    sx = _forall_elim(singleton_pf, x)
    assert isinstance(sx.conclusion, Exists)
    A = 'A'
    specA = substitute(sx.conclusion.body, sx.conclusion.var, V(A))
    ctxA = (specA,)
    hA = _assume(specA, ctxA)
    pair = _ax('PAIRING', ctxA)
    px = _forall_elim(pair, x)
    pxa = _forall_elim(px, A)
    assert isinstance(pxa.conclusion, Exists)
    P = 'P'
    specP = substitute(pxa.conclusion.body, pxa.conclusion.var, V(P))
    ctxP = ctxA + (specP,)
    hP = _assume(specP, ctxP)
    uni = _ax('UNION', ctxP)
    up = _forall_elim(uni, P)
    assert isinstance(up.conclusion, Exists)
    S = 'S'
    specU = substitute(up.conclusion.body, up.conclusion.var, V(S))
    ctxS = ctxP + (specU,)
    hU = _assume(specU, ctxS)
    z = 'z'
    Agoal = Mem(V(z), V(S))
    Bgoal = Or(Mem(V(z), V(x)), Eq(V(z), V(x)))
    uz = _forall_elim(hU, z)
    ctxM = ctxS + (Agoal,)
    hmem = _assume(Agoal, ctxM)
    eximp = _weaken(_iff_l(uz), ctxM)
    exw = _imp_elim(eximp, hmem)
    W = 'W'
    instW = substitute(exw.conclusion.body, exw.conclusion.var, V(W))
    ctxW = ctxM + (instW,)
    hW = _assume(instW, ctxW)
    zW = _and_l(hW)
    Wp = _and_r(hW)
    pW = _forall_elim(_weaken(hP, ctxW), W)
    disj = _imp_elim(_iff_l(pW), Wp)
    left = disj.conclusion.left
    ctxL = ctxW + (left,)
    hL = _assume(left, ctxL)
    zW_L = _weaken(zW, ctxL)
    zX = Proof('eq_subst', Mem(V(z), V(x)), ctxL, (hL, zW_L), (('direction', 'lr'),))
    outL = Proof('or_intro_left', Bgoal, ctxL, (zX,))
    right = disj.conclusion.right
    ctxR = ctxW + (right,)
    hR = _assume(right, ctxR)
    zW_R = _weaken(zW, ctxR)
    zA = Proof('eq_subst', Mem(V(z), V(A)), ctxR, (hR, zW_R), (('direction', 'lr'),))
    sa = _forall_elim(_weaken(hA, ctxR), z)
    zEqX = _imp_elim(_iff_l(sa), zA)
    outR = Proof('or_intro_right', Bgoal, ctxR, (zEqX,))
    B_at_W = Proof('or_elim', Bgoal, ctxW, (disj, outL, outR))
    B_from_ex = Proof('exists_elim', Bgoal, ctxM, (exw, B_at_W), (('eigenvar', W),))
    AtoB = Proof('imp_intro', Imp(Agoal, Bgoal), ctxS, (B_from_ex,))
    ctxB = ctxS + (Bgoal,)
    hB = _assume(Bgoal, ctxB)
    lB = Bgoal.left
    ctxBL = ctxB + (lB,)
    hlB = _assume(lB, ctxBL)
    pz_x = _forall_elim(_weaken(hP, ctxBL), x)
    reflx = Proof('eq_refl', Eq(V(x), V(x)), ctxBL)
    orxx = Proof('or_intro_left', pz_x.conclusion.right, ctxBL, (reflx,))
    xP = _imp_elim(_iff_r(pz_x), orxx)
    conjx = Proof('and_intro', And(lB, Mem(V(x), V(P))), ctxBL, (hlB, xP))
    exwx = Proof('exists_intro', uz.conclusion.right, ctxBL, (conjx,), (('term', {'var': x}),))
    memS_L = _imp_elim(_weaken(_iff_r(uz), ctxBL), exwx)
    rB = Bgoal.right
    ctxBR = ctxB + (rB,)
    hrB = _assume(rB, ctxBR)
    saz = _forall_elim(_weaken(hA, ctxBR), z)
    zA2 = _imp_elim(_iff_r(saz), hrB)
    pA = _forall_elim(_weaken(hP, ctxBR), A)
    reflA = Proof('eq_refl', Eq(V(A), V(A)), ctxBR)
    orA = Proof('or_intro_right', pA.conclusion.right, ctxBR, (reflA,))
    AP = _imp_elim(_iff_r(pA), orA)
    conjA = Proof('and_intro', And(Mem(V(z), V(A)), Mem(V(A), V(P))), ctxBR, (zA2, AP))
    exwA = Proof('exists_intro', uz.conclusion.right, ctxBR, (conjA,), (('term', {'var': A}),))
    memS_R = _imp_elim(_weaken(_iff_r(uz), ctxBR), exwA)
    memS = Proof('or_elim', Agoal, ctxB, (hB, memS_L, memS_R))
    BtoA = Proof('imp_intro', Imp(Bgoal, Agoal), ctxS, (memS,))
    iff = Proof('iff_intro', Iff(Agoal, Bgoal), ctxS, (AtoB, BtoA))
    succ = Proof('forall_intro', SuccessorSpec(V(S), V(x), 'z'), ctxS, (iff,))
    exS = Proof('exists_intro', body, ctxS, (succ,), (('term', {'var': S}),))
    afterS = Proof('exists_elim', body, ctxP, (up, exS), (('eigenvar', S),))
    afterP = Proof('exists_elim', body, ctxA, (pxa, afterS), (('eigenvar', P),))
    afterA = Proof('exists_elim', body, ctx, (sx, afterP), (('eigenvar', A),))
    return Proof('forall_intro', goal, ctx, (afterA,))

def _prove_empty_relation_from(empty_pf: Proof, r: str, d: str, c: str, ctx: tuple[Formula, ...]) -> Proof:
    goal = RelationGraphSpec(V(r), V(d), V(c), 'p', 'x', 'y')
    p = 'p'
    body = goal.body
    mem = Mem(V(p), V(r))
    ctxm = ctx + (mem,)
    hm = _assume(mem, ctxm)
    ne = _forall_elim(_weaken(empty_pf, ctxm), p)
    bot = _imp_elim(ne, hm)
    rhs = body.right
    ex = Proof('bottom_elim', rhs, ctxm, (bot,))
    imp = Proof('imp_intro', body, ctx, (ex,))
    return Proof('forall_intro', goal, ctx, (imp,))

def _prove_empty_function_from(empty_pf: Proof, e: str, c: str, ctx: tuple[Formula, ...]) -> Proof:
    goal = FunctionGraphSpec(V(e), V(e), V(c), 'p', 'x', 'y', 'y2')
    rel = _prove_empty_relation_from(empty_pf, e, e, c, ctx)
    total = goal.right.left
    assert isinstance(total, Forall)
    x = total.var
    impf = total.body
    memx = impf.left
    ctxx = ctx + (memx,)
    hmx = _assume(memx, ctxx)
    ne = _forall_elim(_weaken(empty_pf, ctxx), x)
    bot = _imp_elim(ne, hmx)
    ex = Proof('bottom_elim', impf.right, ctxx, (bot,))
    imp = Proof('imp_intro', impf, ctx, (ex,))
    totalpf = Proof('forall_intro', total, ctx, (imp,))
    unique = goal.right.right
    x = unique.var
    y = unique.body.var
    y2 = unique.body.body.var
    impu = unique.body.body.body
    ante = impu.left
    ctxa = ctx + (ante,)
    ha = _assume(ante, ctxa)
    left = _and_l(ha)
    xmem = _and_l(left)
    ne2 = _forall_elim(_weaken(empty_pf, ctxa), x)
    bot2 = _imp_elim(ne2, xmem)
    eq = Proof('bottom_elim', impu.right, ctxa, (bot2,))
    ii = Proof('imp_intro', impu, ctx, (eq,))
    q2 = Proof('forall_intro', unique.body.body, ctx, (ii,))
    q1 = Proof('forall_intro', unique.body, ctx, (q2,))
    unipf = Proof('forall_intro', unique, ctx, (q1,))
    rest = Proof('and_intro', goal.right, ctx, (totalpf, unipf))
    return Proof('and_intro', goal, ctx, (rel, rest))

def build_empty_relation_exists(empty_exists_pf: Proof | None=None) -> Proof:
    empty_exists_pf = empty_exists_pf or build_empty_exists()
    goal = empty_relation_exists_formula()
    ctx = ()
    d = 'd'
    c = 'c'
    body_c = goal.body.body
    ex = empty_exists_pf
    assert isinstance(ex.conclusion, Exists)
    E = 'E'
    spec = substitute(ex.conclusion.body, ex.conclusion.var, V(E))
    ctxE = (spec,)
    he = _assume(spec, ctxE)
    rel = _prove_empty_relation_from(he, E, d, c, ctxE)
    conj = Proof('and_intro', And(spec, rel.conclusion), ctxE, (he, rel))
    exr = Proof('exists_intro', body_c, ctxE, (conj,), (('term', {'var': E}),))
    body = Proof('exists_elim', body_c, ctx, (ex, exr), (('eigenvar', E),))
    qc = Proof('forall_intro', goal.body, ctx, (body,))
    return Proof('forall_intro', goal, ctx, (qc,))

def build_empty_function_exists(empty_exists_pf: Proof | None=None) -> Proof:
    empty_exists_pf = empty_exists_pf or build_empty_exists()
    goal = empty_function_exists_formula()
    ctx = ()
    c = 'c'
    body = goal.body
    ex = empty_exists_pf
    E = 'E'
    spec = substitute(ex.conclusion.body, ex.conclusion.var, V(E))
    ctxE = (spec,)
    he = _assume(spec, ctxE)
    fun = _prove_empty_function_from(he, E, c, ctxE)
    conj = Proof('and_intro', And(spec, fun.conclusion), ctxE, (he, fun))
    exe = Proof('exists_intro', body, ctxE, (conj,), (('term', {'var': E}),))
    bodypf = Proof('exists_elim', body, ctx, (ex, exe), (('eigenvar', E),))
    return Proof('forall_intro', goal, ctx, (bodypf,))
OMEGA_SEPARATION_SCHEMA = SchemaInstance('SEPARATION', OmegaPredicate(V('u'), 'j'), source_var='u', parameters=())
CARTESIAN_SEPARATION_SCHEMA = SchemaInstance('SEPARATION', CartesianProductPredicate(V('p'), V('a'), V('b'), 'x', 'y'), source_var='p', parameters=('a', 'b'))
PASS004_SCHEMA_INSTANCES = (OMEGA_SEPARATION_SCHEMA, CARTESIAN_SEPARATION_SCHEMA)

def build_core_pass004_library() -> tuple[CertifiedStatement, ...]:
    base = {r.name: r for r in FOUNDATION_LIBRARY}
    builders = [('ZFC_PAIR_SPEC_UNIQUE', 'lemma', build_pair_unique), ('ZFC_SUCCESSOR_SPEC_UNIQUE', 'lemma', build_successor_unique), ('ZFC_SUCCESSOR_EXISTS', 'theorem', lambda: build_successor_exists(base['ZFC_DERIVED_SINGLETON_EXISTS'].proof)), ('ZFC_EMPTY_RELATION_EXISTS', 'proposition', lambda: build_empty_relation_exists(base['ZFC_DERIVED_EMPTY_EXISTS'].proof)), ('ZFC_EMPTY_FUNCTION_EXISTS', 'result', lambda: build_empty_function_exists(base['ZFC_DERIVED_EMPTY_EXISTS'].proof))]
    k = ZFCKernel()
    out = []
    for name, kind, b in builders:
        p = b()
        kr = k.verify(p)
        if not kr.ok:
            raise ValueError(f'PASS004_CORE_KERNEL_REJECT:{name}:{kr.detail}')
        out.append(CertifiedStatement(p, name=name, kind=kind, source='PASS004_MATHEMATICS_LIBRARY'))
    return tuple(out)
PASS004_CORE_LIBRARY = build_core_pass004_library()

def build_binary_union_exists() -> Proof:
    goal = binary_union_exists_formula()
    ctx = ()
    a = 'a'
    b = 'b'
    body_b = goal.body.body
    pair = _ax('PAIRING', ctx)
    pa = _forall_elim(pair, a)
    pab = _forall_elim(pa, b)
    assert isinstance(pab.conclusion, Exists)
    P = 'P'
    specP = substitute(pab.conclusion.body, pab.conclusion.var, V(P))
    ctxP = (specP,)
    hP = _assume(specP, ctxP)
    uni = _ax('UNION', ctxP)
    up = _forall_elim(uni, P)
    assert isinstance(up.conclusion, Exists)
    U = 'U'
    specU = substitute(up.conclusion.body, up.conclusion.var, V(U))
    ctxU = ctxP + (specU,)
    hU = _assume(specU, ctxU)
    z = 'z'
    L = Mem(V(z), V(U))
    R = Or(Mem(V(z), V(a)), Mem(V(z), V(b)))
    uz = _forall_elim(hU, z)
    ctxL = ctxU + (L,)
    hL = _assume(L, ctxL)
    exw = _imp_elim(_weaken(_iff_l(uz), ctxL), hL)
    W = 'W'
    instW = substitute(exw.conclusion.body, exw.conclusion.var, V(W))
    ctxW = ctxL + (instW,)
    hW = _assume(instW, ctxW)
    zW = _and_l(hW)
    WP = _and_r(hW)
    pw = _forall_elim(_weaken(hP, ctxW), W)
    disj = _imp_elim(_iff_l(pw), WP)
    la = disj.conclusion.left
    ctxA = ctxW + (la,)
    hA = _assume(la, ctxA)
    za = Proof('eq_subst', Mem(V(z), V(a)), ctxA, (hA, _weaken(zW, ctxA)), (('direction', 'lr'),))
    outA = Proof('or_intro_left', R, ctxA, (za,))
    rb = disj.conclusion.right
    ctxB = ctxW + (rb,)
    hB = _assume(rb, ctxB)
    zb = Proof('eq_subst', Mem(V(z), V(b)), ctxB, (hB, _weaken(zW, ctxB)), (('direction', 'lr'),))
    outB = Proof('or_intro_right', R, ctxB, (zb,))
    Rout = Proof('or_elim', R, ctxW, (disj, outA, outB))
    Rfrom = Proof('exists_elim', R, ctxL, (exw, Rout), (('eigenvar', W),))
    LtoR = Proof('imp_intro', Imp(L, R), ctxU, (Rfrom,))
    ctxR = ctxU + (R,)
    hR = _assume(R, ctxR)
    ma = R.left
    ctxRA = ctxR + (ma,)
    hma = _assume(ma, ctxRA)
    pwa = _forall_elim(_weaken(hP, ctxRA), a)
    raa = Proof('eq_refl', Eq(V(a), V(a)), ctxRA)
    ora = Proof('or_intro_left', pwa.conclusion.right, ctxRA, (raa,))
    aP = _imp_elim(_iff_r(pwa), ora)
    ca = Proof('and_intro', And(ma, Mem(V(a), V(P))), ctxRA, (hma, aP))
    exa = Proof('exists_intro', uz.conclusion.right, ctxRA, (ca,), (('term', {'var': a}),))
    outLA = _imp_elim(_weaken(_iff_r(uz), ctxRA), exa)
    mb = R.right
    ctxRB = ctxR + (mb,)
    hmb = _assume(mb, ctxRB)
    pwb = _forall_elim(_weaken(hP, ctxRB), b)
    rbb = Proof('eq_refl', Eq(V(b), V(b)), ctxRB)
    orb = Proof('or_intro_right', pwb.conclusion.right, ctxRB, (rbb,))
    bP = _imp_elim(_iff_r(pwb), orb)
    cb = Proof('and_intro', And(mb, Mem(V(b), V(P))), ctxRB, (hmb, bP))
    exb = Proof('exists_intro', uz.conclusion.right, ctxRB, (cb,), (('term', {'var': b}),))
    outLB = _imp_elim(_weaken(_iff_r(uz), ctxRB), exb)
    Lout = Proof('or_elim', L, ctxR, (hR, outLA, outLB))
    RtoL = Proof('imp_intro', Imp(R, L), ctxU, (Lout,))
    iff = Proof('iff_intro', Iff(L, R), ctxU, (LtoR, RtoL))
    spec = Proof('forall_intro', BinaryUnionSpec(V(U), V(a), V(b), 'z'), ctxU, (iff,))
    exU = Proof('exists_intro', body_b, ctxU, (spec,), (('term', {'var': U}),))
    afterU = Proof('exists_elim', body_b, ctxP, (up, exU), (('eigenvar', U),))
    afterP = Proof('exists_elim', body_b, ctx, (pab, afterU), (('eigenvar', P),))
    qb = Proof('forall_intro', goal.body, ctx, (afterP,))
    return Proof('forall_intro', goal, ctx, (qb,))

def _empty_equal(empty_unique_pf: Proof, e: str, f: str, pe: Proof, pf: Proof, ctx) -> Proof:
    q = _forall_elim(_forall_elim(_weaken(empty_unique_pf, ctx), e), f)
    conj = Proof('and_intro', q.conclusion.left, ctx, (_weaken(pe, ctx), _weaken(pf, ctx)))
    return _imp_elim(q, conj)

def _successor_equal(succ_unique_pf: Proof, x: str, s: str, t: str, ps: Proof, pt: Proof, ctx) -> Proof:
    q = _forall_elim(_forall_elim(_forall_elim(_weaken(succ_unique_pf, ctx), x), s), t)
    conj = Proof('and_intro', q.conclusion.left, ctx, (_weaken(ps, ctx), _weaken(pt, ctx)))
    return _imp_elim(q, conj)

def build_omega_exists(schema_index: int=0, empty_unique_pf: Proof | None=None, succ_unique_pf: Proof | None=None) -> Proof:
    empty_unique_pf = empty_unique_pf or build_empty_unique()
    succ_unique_pf = succ_unique_pf or build_successor_unique()
    goal = omega_exists_formula()
    ctx = ()
    inf = _ax('INFINITY', ctx)
    assert isinstance(inf.conclusion, Exists)
    I = 'I'
    specI = substitute(inf.conclusion.body, inf.conclusion.var, V(I))
    ctxI = (specI,)
    hI = _assume(specI, ctxI)
    sf = OMEGA_SEPARATION_SCHEMA.generated()
    sepax = Proof('axiom_schema', sf, ctxI, (), (('schema_index', schema_index),))
    sepi = _forall_elim(sepax, I)
    assert isinstance(sepi.conclusion, Exists)
    W = 'W'
    sepW = substitute(sepi.conclusion.body, sepi.conclusion.var, V(W))
    ctxW = ctxI + (sepW,)
    hW = _assume(sepW, ctxW)
    omegaW = substitute(goal.body, 'w', V(W))
    indW = omegaW.left
    minW = omegaW.right
    emptyI = _and_l(hI)
    emptyI = _weaken(emptyI, ctxW)
    assert isinstance(emptyI.conclusion, Exists)
    E = 'E'
    instE = substitute(emptyI.conclusion.body, emptyI.conclusion.var, V(E))
    ctxE = ctxW + (instE,)
    hE = _assume(instE, ctxE)
    EI = _and_l(hE)
    emptyE = _and_r(hE)
    sepE = _forall_elim(_weaken(hW, ctxE), E)
    predE = sepE.conclusion.right.right
    assert isinstance(predE, Forall)
    J = predE.var
    jind = predE.body.left
    ctxJ = ctxE + (jind,)
    hj = _assume(jind, ctxJ)
    jempty = _and_l(hj)
    assert isinstance(jempty.conclusion, Exists)
    F = 'F'
    instF = substitute(jempty.conclusion.body, jempty.conclusion.var, V(F))
    ctxF = ctxJ + (instF,)
    hF = _assume(instF, ctxF)
    FJ = _and_l(hF)
    emptyF = _and_r(hF)
    eqEF = _empty_equal(empty_unique_pf, E, F, _weaken(emptyE, ctxF), emptyF, ctxF)
    EJ = Proof('eq_subst', Mem(V(E), V(J)), ctxF, (eqEF, FJ), (('direction', 'rl'),))
    EJ_after = Proof('exists_elim', Mem(V(E), V(J)), ctxJ, (jempty, EJ), (('eigenvar', F),))
    impJ = Proof('imp_intro', predE.body, ctxE, (EJ_after,))
    predEpf = Proof('forall_intro', predE, ctxE, (impJ,))
    rhsE = Proof('and_intro', sepE.conclusion.right, ctxE, (EI, predEpf))
    EW = _imp_elim(_iff_r(sepE), rhsE)
    empty_member_W = indW.left
    pairE = Proof('and_intro', substitute(empty_member_W.body, empty_member_W.var, V(E)), ctxE, (EW, emptyE))
    exEmptyW = Proof('exists_intro', empty_member_W, ctxE, (pairE,), (('term', {'var': E}),))
    emptyW = Proof('exists_elim', empty_member_W, ctxW, (emptyI, exEmptyW), (('eigenvar', E),))
    closedW = indW.right
    assert isinstance(closedW, Forall)
    Y = closedW.var
    impY = closedW.body
    yW = impY.left
    ctxY = ctxW + (yW,)
    hyW = _assume(yW, ctxY)
    sepY = _forall_elim(_weaken(hW, ctxY), Y)
    rhsY = _imp_elim(_iff_l(sepY), hyW)
    yI = _and_l(rhsY)
    predY = _and_r(rhsY)
    closedI = _and_r(_weaken(hI, ctxY))
    cy = _forall_elim(closedI, Y)
    exS = _imp_elim(cy, yI)
    assert isinstance(exS.conclusion, Exists)
    S = 'S'
    instS = substitute(exS.conclusion.body, exS.conclusion.var, V(S))
    ctxS = ctxY + (instS,)
    hS = _assume(instS, ctxS)
    SI = _and_l(hS)
    succS = _and_r(hS)
    sepS = _forall_elim(_weaken(hW, ctxS), S)
    predS = sepS.conclusion.right.right
    assert isinstance(predS, Forall)
    J2 = predS.var
    jind2 = predS.body.left
    ctxJ2 = ctxS + (jind2,)
    hj2 = _assume(jind2, ctxJ2)
    predYJ = _forall_elim(_weaken(predY, ctxJ2), J2)
    yJ = _imp_elim(predYJ, hj2)
    closedJ = _and_r(hj2)
    jy = _forall_elim(closedJ, Y)
    exT = _imp_elim(jy, yJ)
    assert isinstance(exT.conclusion, Exists)
    T = 'T'
    instT = substitute(exT.conclusion.body, exT.conclusion.var, V(T))
    ctxT = ctxJ2 + (instT,)
    hT = _assume(instT, ctxT)
    TJ = _and_l(hT)
    succT = _and_r(hT)
    eqST = _successor_equal(succ_unique_pf, Y, S, T, _weaken(succS, ctxT), succT, ctxT)
    SJ = Proof('eq_subst', Mem(V(S), V(J2)), ctxT, (eqST, TJ), (('direction', 'rl'),))
    SJ_after = Proof('exists_elim', Mem(V(S), V(J2)), ctxJ2, (exT, SJ), (('eigenvar', T),))
    impJ2 = Proof('imp_intro', predS.body, ctxS, (SJ_after,))
    predSpf = Proof('forall_intro', predS, ctxS, (impJ2,))
    rhsS = Proof('and_intro', sepS.conclusion.right, ctxS, (SI, predSpf))
    SW = _imp_elim(_iff_r(sepS), rhsS)
    witnessS = Proof('and_intro', substitute(impY.right.body, impY.right.var, V(S)), ctxS, (SW, succS))
    exSuccW = Proof('exists_intro', impY.right, ctxS, (witnessS,), (('term', {'var': S}),))
    exSuccAfter = Proof('exists_elim', impY.right, ctxY, (exS, exSuccW), (('eigenvar', S),))
    impClosed = Proof('imp_intro', impY, ctxW, (exSuccAfter,))
    closedWpf = Proof('forall_intro', closedW, ctxW, (impClosed,))
    indWpf = Proof('and_intro', indW, ctxW, (emptyW, closedWpf))
    assert isinstance(minW, Forall)
    K = minW.var
    impK = minW.body
    kind = impK.left
    subsetWK = impK.right
    ctxK = ctxW + (kind,)
    hk = _assume(kind, ctxK)
    assert isinstance(subsetWK, Forall)
    X = subsetWK.var
    impx = subsetWK.body
    xW = impx.left
    ctxX = ctxK + (xW,)
    hx = _assume(xW, ctxX)
    sepX = _forall_elim(_weaken(hW, ctxX), X)
    rhsX = _imp_elim(_iff_l(sepX), hx)
    predX = _and_r(rhsX)
    predXK = _forall_elim(predX, K)
    xK = _imp_elim(predXK, _weaken(hk, ctxX))
    ix = Proof('imp_intro', impx, ctxK, (xK,))
    subsetpf = Proof('forall_intro', subsetWK, ctxK, (ix,))
    ik = Proof('imp_intro', impK, ctxW, (subsetpf,))
    minWpf = Proof('forall_intro', minW, ctxW, (ik,))
    omegaPf = Proof('and_intro', omegaW, ctxW, (indWpf, minWpf))
    exOmega = Proof('exists_intro', goal, ctxW, (omegaPf,), (('term', {'var': W}),))
    afterW = Proof('exists_elim', goal, ctxI, (sepi, exOmega), (('eigenvar', W),))
    return Proof('exists_elim', goal, ctx, (inf, afterW), (('eigenvar', I),))

def ordered_pair_power_bound_formula() -> Formula:
    u, p1, p2, x, y, q = map(V, ['u', 'p1', 'p2', 'x', 'y', 'q'])
    ante = And(PowerSetSpec(p1, u, 'a', 'b'), And(PowerSetSpec(p2, p1, 'c', 'd'), And(Mem(x, u), And(Mem(y, u), OrderedPairCode(q, x, y, 'e', 'f')))))
    return Forall('u', Forall('p1', Forall('p2', Forall('x', Forall('y', Forall('q', Imp(ante, Mem(q, p2))))))))

def build_ordered_pair_power_bound() -> Proof:
    goal = ordered_pair_power_bound_formula()
    ctx = ()
    u, p1, p2, x, y, q = map(V, ['u', 'p1', 'p2', 'x', 'y', 'q'])
    imp = goal.body.body.body.body.body.body
    ante = imp.left
    ctxA = (ante,)
    h = _assume(ante, ctxA)
    ps1 = _and_l(h)
    r1 = _and_r(h)
    ps2 = _and_l(r1)
    r2 = _and_r(r1)
    xu = _and_l(r2)
    r3 = _and_r(r2)
    yu = _and_l(r3)
    op = _and_r(r3)
    assert isinstance(op.conclusion, Exists)
    A = 'A'
    instA = substitute(op.conclusion.body, op.conclusion.var, V(A))
    ctx1 = ctxA + (instA,)
    hA = _assume(instA, ctx1)
    exB = hA
    assert isinstance(exB.conclusion, Exists)
    B = 'B'
    instB = substitute(exB.conclusion.body, exB.conclusion.var, V(B))
    ctx2 = ctx1 + (instB,)
    hB = _assume(instB, ctx2)
    singleA = _and_l(hB)
    tail = _and_r(hB)
    pairB = _and_l(tail)
    pairQ = _and_r(tail)
    ps1A = _forall_elim(_weaken(ps1, ctx2), A)
    subA = ps1A.conclusion.right
    assert isinstance(subA, Forall)
    z = subA.var
    iz = subA.body
    ctxz = ctx2 + (iz.left,)
    hz = _assume(iz.left, ctxz)
    sa = _forall_elim(_weaken(singleA, ctxz), z)
    eqzx = _imp_elim(_iff_l(sa), hz)
    xu_z = _weaken(xu, ctxz)
    zu = Proof('eq_subst', Mem(V(z), u), ctxz, (eqzx, xu_z), (('direction', 'rl'),))
    izpf = Proof('imp_intro', iz, ctx2, (zu,))
    subApf = Proof('forall_intro', subA, ctx2, (izpf,))
    AinP1 = _imp_elim(_iff_r(ps1A), subApf)
    ps1B = _forall_elim(_weaken(ps1, ctx2), B)
    subB = ps1B.conclusion.right
    z2 = subB.var
    iz2 = subB.body
    ctxzb = ctx2 + (iz2.left,)
    hzb = _assume(iz2.left, ctxzb)
    pbz = _forall_elim(_weaken(pairB, ctxzb), z2)
    disj = _imp_elim(_iff_l(pbz), hzb)
    l = disj.conclusion.left
    ctxl = ctxzb + (l,)
    hl = _assume(l, ctxl)
    zxu = Proof('eq_subst', Mem(V(z2), u), ctxl, (hl, _weaken(xu, ctxl)), (('direction', 'rl'),))
    rr = disj.conclusion.right
    ctxr = ctxzb + (rr,)
    hr = _assume(rr, ctxr)
    zyu = Proof('eq_subst', Mem(V(z2), u), ctxr, (hr, _weaken(yu, ctxr)), (('direction', 'rl'),))
    zu2 = Proof('or_elim', Mem(V(z2), u), ctxzb, (disj, zxu, zyu))
    iz2pf = Proof('imp_intro', iz2, ctx2, (zu2,))
    subBpf = Proof('forall_intro', subB, ctx2, (iz2pf,))
    BinP1 = _imp_elim(_iff_r(ps1B), subBpf)
    ps2q = _forall_elim(_weaken(ps2, ctx2), 'q')
    subQ = ps2q.conclusion.right
    z3 = subQ.var
    iz3 = subQ.body
    ctxq = ctx2 + (iz3.left,)
    hzq = _assume(iz3.left, ctxq)
    pqz = _forall_elim(_weaken(pairQ, ctxq), z3)
    disq = _imp_elim(_iff_l(pqz), hzq)
    la = disq.conclusion.left
    ctxqa = ctxq + (la,)
    hqa = _assume(la, ctxqa)
    A1 = _weaken(AinP1, ctxqa)
    qA = Proof('eq_subst', Mem(V(z3), p1), ctxqa, (hqa, A1), (('direction', 'rl'),))
    lb = disq.conclusion.right
    ctxqb = ctxq + (lb,)
    hqb = _assume(lb, ctxqb)
    B1 = _weaken(BinP1, ctxqb)
    qB = Proof('eq_subst', Mem(V(z3), p1), ctxqb, (hqb, B1), (('direction', 'rl'),))
    qp1 = Proof('or_elim', Mem(V(z3), p1), ctxq, (disq, qA, qB))
    iqp = Proof('imp_intro', iz3, ctx2, (qp1,))
    subQpf = Proof('forall_intro', subQ, ctx2, (iqp,))
    qP2 = _imp_elim(_iff_r(ps2q), subQpf)
    afterB = Proof('exists_elim', Mem(q, p2), ctx1, (exB, qP2), (('eigenvar', B),))
    afterA = Proof('exists_elim', Mem(q, p2), ctxA, (op, afterB), (('eigenvar', A),))
    ip = Proof('imp_intro', imp, ctx, (afterA,))
    cur = ip
    for target in [goal.body.body.body.body.body, goal.body.body.body.body, goal.body.body.body, goal.body.body, goal.body, goal]:
        cur = Proof('forall_intro', target, ctx, (cur,))
    return cur

def build_cartesian_product_exists(schema_index: int=1, binary_union_pf: Proof | None=None, bound_pf: Proof | None=None) -> Proof:
    binary_union_pf = binary_union_pf or build_binary_union_exists()
    bound_pf = bound_pf or build_ordered_pair_power_bound()
    goal = cartesian_product_exists_formula()
    ctx = ()
    a = 'a'
    b = 'b'
    body_b = goal.body.body
    bu = _forall_elim(_forall_elim(binary_union_pf, a), b)
    assert isinstance(bu.conclusion, Exists)
    U = 'U'
    specU = substitute(bu.conclusion.body, bu.conclusion.var, V(U))
    ctxU = (specU,)
    hU = _assume(specU, ctxU)
    ps = _ax('POWER_SET', ctxU)
    pu = _forall_elim(ps, U)
    assert isinstance(pu.conclusion, Exists)
    P1 = 'P1'
    specP1 = substitute(pu.conclusion.body, pu.conclusion.var, V(P1))
    ctxP1 = ctxU + (specP1,)
    hP1 = _assume(specP1, ctxP1)
    ps2 = _ax('POWER_SET', ctxP1)
    pp1 = _forall_elim(ps2, P1)
    assert isinstance(pp1.conclusion, Exists)
    P2 = 'P2'
    specP2 = substitute(pp1.conclusion.body, pp1.conclusion.var, V(P2))
    ctxP2 = ctxP1 + (specP2,)
    hP2 = _assume(specP2, ctxP2)
    sf = CARTESIAN_SEPARATION_SCHEMA.generated()
    sep = Proof('axiom_schema', sf, ctxP2, (), (('schema_index', schema_index),))
    sa = _forall_elim(sep, a)
    sab = _forall_elim(sa, b)
    sepP2 = _forall_elim(sab, P2)
    assert isinstance(sepP2.conclusion, Exists)
    C = 'C'
    specCsep = substitute(sepP2.conclusion.body, sepP2.conclusion.var, V(C))
    ctxC = ctxP2 + (specCsep,)
    hC = _assume(specCsep, ctxC)
    target = CartesianProductSpec(V(C), V(a), V(b), 'p')
    assert isinstance(target, Forall)
    p = target.var
    iffgoal = target.body
    L = iffgoal.left
    R = iffgoal.right
    sepp = _forall_elim(hC, p)
    ctxL = ctxC + (L,)
    hL = _assume(L, ctxL)
    rhs = _imp_elim(_weaken(_iff_l(sepp), ctxL), hL)
    rpred = _and_r(rhs)
    LtoR = Proof('imp_intro', Imp(L, R), ctxC, (rpred,))
    ctxR = ctxC + (R,)
    hR = _assume(R, ctxR)
    assert isinstance(R, Exists)
    X = 'X'
    instX = substitute(R.body, R.var, V(X))
    ctxX = ctxR + (instX,)
    hx = _assume(instX, ctxX)
    xA = _and_l(hx)
    exY = _and_r(hx)
    assert isinstance(exY.conclusion, Exists)
    Y = 'Y'
    instY = substitute(exY.conclusion.body, exY.conclusion.var, V(Y))
    ctxY = ctxX + (instY,)
    hy = _assume(instY, ctxY)
    yB = _and_l(hy)
    op = _and_r(hy)
    ux = _forall_elim(_weaken(hU, ctxY), X)
    orx = Proof('or_intro_left', ux.conclusion.right, ctxY, (_weaken(xA, ctxY),))
    xU = _imp_elim(_iff_r(ux), orx)
    uy = _forall_elim(_weaken(hU, ctxY), Y)
    ory = Proof('or_intro_right', uy.conclusion.right, ctxY, (_weaken(yB, ctxY),))
    yU = _imp_elim(_iff_r(uy), ory)
    qb = _weaken(bound_pf, ctxY)
    for nm in [U, P1, P2, X, Y, p]:
        qb = _forall_elim(qb, nm)
    ante = qb.conclusion.left
    c4 = Proof('and_intro', ante.right.right.right, ctxY, (_weaken(yU, ctxY), op))
    c3 = Proof('and_intro', ante.right.right, ctxY, (_weaken(xU, ctxY), c4))
    c2 = Proof('and_intro', ante.right, ctxY, (_weaken(hP2, ctxY), c3))
    c1 = Proof('and_intro', ante, ctxY, (_weaken(hP1, ctxY), c2))
    pP2 = _imp_elim(qb, c1)
    sep_rhs = Proof('and_intro', sepp.conclusion.right, ctxY, (pP2, _weaken(hR, ctxY)))
    pC = _imp_elim(_weaken(_iff_r(sepp), ctxY), sep_rhs)
    afterY = Proof('exists_elim', L, ctxX, (exY, pC), (('eigenvar', Y),))
    afterX = Proof('exists_elim', L, ctxR, (hR, afterY), (('eigenvar', X),))
    RtoL = Proof('imp_intro', Imp(R, L), ctxC, (afterX,))
    iff = Proof('iff_intro', iffgoal, ctxC, (LtoR, RtoL))
    targetpf = Proof('forall_intro', target, ctxC, (iff,))
    exC = Proof('exists_intro', body_b, ctxC, (targetpf,), (('term', {'var': C}),))
    afterC = Proof('exists_elim', body_b, ctxP2, (sepP2, exC), (('eigenvar', C),))
    afterP2 = Proof('exists_elim', body_b, ctxP1, (pp1, afterC), (('eigenvar', P2),))
    afterP1 = Proof('exists_elim', body_b, ctxU, (pu, afterP2), (('eigenvar', P1),))
    afterU = Proof('exists_elim', body_b, ctx, (bu, afterP1), (('eigenvar', U),))
    qbintro = Proof('forall_intro', goal.body, ctx, (afterU,))
    return Proof('forall_intro', goal, ctx, (qbintro,))

def singleton_identity_function_exists_formula() -> Formula:
    x = V('x')
    return Forall('x', Exists('d', Exists('f', And(SingletonSpec(V('d'), x, 'w'), FunctionGraphSpec(V('f'), V('d'), V('d'), 'p', 'a', 'b', 'b2')))))

def build_singleton_identity_function_exists(singleton_pf: Proof | None=None, ordered_pair_pf: Proof | None=None) -> Proof:
    singleton_pf = singleton_pf or build_singleton_exists()
    ordered_pair_pf = ordered_pair_pf or build_ordered_pair_code_exists(singleton_pf)
    goal = singleton_identity_function_exists_formula()
    ctx = ()
    x = 'x'
    body = goal.body
    sd = _forall_elim(singleton_pf, x)
    assert isinstance(sd.conclusion, Exists)
    D = 'D'
    specD = substitute(sd.conclusion.body, sd.conclusion.var, V(D))
    ctxD = (specD,)
    hD = _assume(specD, ctxD)
    opx = _forall_elim(_forall_elim(_weaken(ordered_pair_pf, ctxD), x), x)
    assert isinstance(opx.conclusion, Exists)
    P = 'P'
    specP = substitute(opx.conclusion.body, opx.conclusion.var, V(P))
    ctxP = ctxD + (specP,)
    hP = _assume(specP, ctxP)
    sf = _forall_elim(_weaken(singleton_pf, ctxP), P)
    assert isinstance(sf.conclusion, Exists)
    F = 'F'
    specF = substitute(sf.conclusion.body, sf.conclusion.var, V(F))
    ctxF = ctxP + (specF,)
    hF = _assume(specF, ctxF)
    fun = FunctionGraphSpec(V(F), V(D), V(D), 'p', 'a', 'b', 'b2')
    rel = fun.left
    total = fun.right.left
    unique = fun.right.right
    dx = _forall_elim(hD, x)
    rxx = Proof('eq_refl', Eq(V(x), V(x)), ctxF)
    xD = _imp_elim(_iff_r(_weaken(dx, ctxF)), rxx)
    fp = _forall_elim(hF, P)
    rpp = Proof('eq_refl', Eq(V(P), V(P)), ctxF)
    PF = _imp_elim(_iff_r(fp), rpp)
    q = rel.var
    impq = rel.body
    qF = impq.left
    ctxq = ctxF + (qF,)
    hq = _assume(qF, ctxq)
    fq = _forall_elim(_weaken(hF, ctxq), q)
    eq_qP = _imp_elim(_iff_l(fq), hq)
    op_q = Proof('eq_subst', OrderedPairCode(V(q), V(x), V(x), 'a0', 'b0'), ctxq, (eq_qP, _weaken(hP, ctxq)), (('direction', 'rl'),))
    innerY = Exists('b', And(Mem(V('b'), V(D)), OrderedPairCode(V(q), V(x), V('b'), 'a0', 'b0')))
    conjY = Proof('and_intro', substitute(innerY.body, 'b', V(x)), ctxq, (_weaken(xD, ctxq), op_q))
    exY = Proof('exists_intro', innerY, ctxq, (conjY,), (('term', {'var': x}),))
    outerX = impq.right
    conjX = Proof('and_intro', substitute(outerX.body, 'a', V(x)), ctxq, (_weaken(xD, ctxq), exY))
    exX = Proof('exists_intro', outerX, ctxq, (conjX,), (('term', {'var': x}),))
    iq = Proof('imp_intro', impq, ctxF, (exX,))
    relpf = Proof('forall_intro', rel, ctxF, (iq,))
    a = total.var
    ia = total.body
    aD = ia.left
    ctxa = ctxF + (aD,)
    ha = _assume(aD, ctxa)
    da = _forall_elim(_weaken(hD, ctxa), a)
    eq_ax = _imp_elim(_iff_l(da), ha)
    op_aa = Proof('eq_subst', OrderedPairCode(V(P), V(a), V(a), 'aa', 'bb'), ctxa, (eq_ax, _weaken(hP, ctxa)), (('direction', 'rl'),))
    pair_exists = Exists('p', And(Mem(V('p'), V(F)), OrderedPairCode(V('p'), V(a), V(a), 'aa', 'bb')))
    pair_conj = Proof('and_intro', substitute(pair_exists.body, 'p', V(P)), ctxa, (_weaken(PF, ctxa), op_aa))
    exPair = Proof('exists_intro', pair_exists, ctxa, (pair_conj,), (('term', {'var': P}),))
    out_exists = ia.right
    out_conj = Proof('and_intro', substitute(out_exists.body, 'b', V(a)), ctxa, (ha, exPair))
    exOut = Proof('exists_intro', out_exists, ctxa, (out_conj,), (('term', {'var': a}),))
    ita = Proof('imp_intro', ia, ctxF, (exOut,))
    totalpf = Proof('forall_intro', total, ctxF, (ita,))
    a = unique.var
    b = unique.body.var
    b2 = unique.body.body.var
    iu = unique.body.body.body
    ante = iu.left
    ctxu = ctxF + (ante,)
    hu = _assume(ante, ctxu)
    left = _and_l(hu)
    right = _and_r(hu)
    aD2 = _and_l(left)
    bD = _and_r(left)
    b2D = _and_l(right)
    db = _forall_elim(_weaken(hD, ctxu), b)
    eq_bx = _imp_elim(_iff_l(db), bD)
    db2 = _forall_elim(_weaken(hD, ctxu), b2)
    eq_b2x = _imp_elim(_iff_l(db2), b2D)
    eq_xb2 = Proof('eq_symm', Eq(V(x), V(b2)), ctxu, (eq_b2x,))
    eq_bb2 = Proof('eq_trans', Eq(V(b), V(b2)), ctxu, (eq_bx, eq_xb2))
    iupf = Proof('imp_intro', iu, ctxF, (eq_bb2,))
    q2 = Proof('forall_intro', unique.body.body, ctxF, (iupf,))
    q1 = Proof('forall_intro', unique.body, ctxF, (q2,))
    uniquepf = Proof('forall_intro', unique, ctxF, (q1,))
    rest = Proof('and_intro', fun.right, ctxF, (totalpf, uniquepf))
    funpf = Proof('and_intro', fun, ctxF, (relpf, rest))
    final_and = And(specD, fun)
    conj = Proof('and_intro', final_and, ctxF, (_weaken(hD, ctxF), funpf))
    body_at_D = substitute(body.body, 'd', V(D))
    exF = Proof('exists_intro', body_at_D, ctxF, (conj,), (('term', {'var': F}),))
    afterF = Proof('exists_elim', body_at_D, ctxP, (sf, exF), (('eigenvar', F),))
    afterP = Proof('exists_elim', body_at_D, ctxD, (opx, afterF), (('eigenvar', P),))
    exD = Proof('exists_intro', body, ctxD, (afterP,), (('term', {'var': D}),))
    afterD = Proof('exists_elim', body, ctx, (sd, exD), (('eigenvar', D),))
    return Proof('forall_intro', goal, ctx, (afterD,))

def build_pass004_math_library(schema_prefix: tuple[SchemaInstance, ...]=()) -> tuple[CertifiedStatement, ...]:
    offset = len(schema_prefix)
    schemas = tuple(schema_prefix) + PASS004_SCHEMA_INSTANCES
    k = ZFCKernel(schemas)
    records = list(PASS004_CORE_LIBRARY)
    extra = [('ZFC_BINARY_UNION_EXISTS', 'lemma', build_binary_union_exists()), ('ZFC_OMEGA_EXISTS', 'theorem', build_omega_exists(offset)), ('ZFC_ORDERED_PAIR_POWER_BOUND', 'lemma', build_ordered_pair_power_bound()), ('ZFC_CARTESIAN_PRODUCT_EXISTS', 'theorem', build_cartesian_product_exists(offset + 1)), ('ZFC_SINGLETON_IDENTITY_FUNCTION_EXISTS', 'proposition', build_singleton_identity_function_exists())]
    for name, kind, p in extra:
        kr = k.verify(p)
        if not kr.ok:
            raise ValueError(f'PASS004_MATH_KERNEL_REJECT:{name}:{kr.detail}')
        records.append(CertifiedStatement(p, name=name, kind=kind, source='PASS004_MATHEMATICS_LIBRARY'))
    return tuple(records)
PASS004_MATH_LIBRARY = build_pass004_math_library(())
from .semantic import NormalizedLibraryEntry

def _preverified_normalized(records):
    return tuple((NormalizedLibraryEntry(r.proof, r.identity, (r.name,) if r.name else (), (str(r.kind),) if r.kind else ()) for r in records))
PASS004_NORMALIZED_LIBRARY = _preverified_normalized(tuple(FOUNDATION_LIBRARY) + tuple(PASS004_MATH_LIBRARY))
