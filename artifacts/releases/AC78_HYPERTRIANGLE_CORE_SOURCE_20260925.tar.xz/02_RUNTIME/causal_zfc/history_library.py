from __future__ import annotations
from functools import reduce
from .logic import *
from .proof import *
from .axioms import SchemaInstance
from .kernel import ZFCKernel
from .semantic import CertifiedStatement, NormalizedLibraryEntry
from .setdefs import *
from .setdefs import _fresh_local
from .derived_library import _assume, _forall_elim, _and_l, _and_r, _imp_elim, _iff_l, _iff_r, _weaken
from .mathematics_library import OmegaSpec
from .arithmetic_library import GraphValueSpec, build_constant_function_exists, build_function_value_unique, build_ordered_pair_injective
from .recursion_library import PASS007_SCHEMA_INSTANCES, PASS007_FULL_LIBRARY, PASS007_NORMALIZED_LIBRARY, build_zero_not_successor, build_successor_injective, build_function_extend_fresh, build_adjoin_exists, AdjoinSpec, _adjoin_cases, _adjoin_mem_left, _adjoin_mem_eq, build_omega_every_element_zero_or_successor, build_omega_nonzero_unique_predecessor, build_omega_induction_subset, _preverified_pass006, _apply_rec_step

def _ands(*fs: Formula) -> Formula:
    if not fs:
        raise ValueError('empty and chain')
    out = fs[-1]
    for f in reversed(fs[:-1]):
        out = And(f, out)
    return out

def _pack_ands(formula: Formula, proofs: list[Proof], ctx) -> Proof:
    if len(proofs) == 1:
        if not equivalent(formula, proofs[0].conclusion):
            raise ValueError('pack leaf mismatch:' + repr(formula) + ' != ' + repr(proofs[0].conclusion))
        return _weaken(proofs[0], tuple(ctx)) if not ctx_equiv(proofs[0].context, tuple(ctx)) else proofs[0]
    if not isinstance(formula, And):
        raise ValueError('pack shape')
    left = _weaken(proofs[0], tuple(ctx)) if not ctx_equiv(proofs[0].context, tuple(ctx)) else proofs[0]
    right = _pack_ands(formula.right, proofs[1:], tuple(ctx))
    return Proof('and_intro', formula, tuple(ctx), (left, right))

def _unpack_ands(p: Proof, n: int) -> list[Proof]:
    out = []
    q = p
    for i in range(n - 1):
        out.append(_and_l(q))
        q = _and_r(q)
    out.append(q)
    return out

def _close_foralls(goal: Formula, core_proof: Proof) -> Proof:
    stack = []
    q = goal
    while isinstance(q, Forall):
        stack.append(q)
        q = q.body
    p = core_proof
    for f in reversed(stack):
        p = Proof('forall_intro', f, p.context, (p,))
    return p

def _fun_parts(fun: Proof, ctx):
    q = _weaken(fun, tuple(ctx))
    return (_and_l(q), _and_l(_and_r(q)), _and_r(_and_r(q)))

def _function_unique(fun: Proof, x: str, y: str, z: str, xd: Proof, yc: Proof, zc: Proof, gv1: Proof, gv2: Proof, ctx) -> Proof:
    _, _, uniq = _fun_parts(fun, ctx)
    q = uniq
    for nm in [x, y, z]:
        q = _forall_elim(q, nm)
    ante = q.conclusion.left
    l = _pack_ands(ante.left, [xd, yc], ctx)
    rr = _pack_ands(ante.right, [zc, gv1, gv2], ctx)
    allp = Proof('and_intro', ante, tuple(ctx), (l, rr))
    return _imp_elim(q, allp)

def _function_total(fun: Proof, x: str, xd: Proof, ctx) -> Proof:
    _, total, _ = _fun_parts(fun, ctx)
    q = _forall_elim(total, x)
    return _imp_elim(q, _weaken(xd, tuple(ctx)))

def _lift_graph_value(gv: Proof, graph_adjoin: Proof, oldf: str, newf: str, x: str, y: str, ctx) -> Proof:
    ex = _weaken(gv, tuple(ctx))
    assert isinstance(ex.conclusion, Exists)
    Q = 'Qlift_' + x + '_' + y
    inst = substitute(ex.conclusion.body, ex.conclusion.var, V(Q))
    ctxQ = tuple(ctx) + (inst,)
    hq = _assume(inst, ctxQ)
    qold = _and_l(hq)
    op = _and_r(hq)
    qnew = _adjoin_mem_left(_weaken(graph_adjoin, ctxQ), Q, qold, ctxQ)
    tgt = GraphValueSpec(V(newf), V(x), V(y), 'qq')
    body = substitute(tgt.body, tgt.var, V(Q))
    cb = Proof('and_intro', body, ctxQ, (qnew, op))
    ext = Proof('exists_intro', tgt, ctxQ, (cb,), (('term', {'var': Q}),))
    return Proof('exists_elim', tgt, tuple(ctx), (ex, ext), (('eigenvar', Q),))

def _fresh_graph_value(graph_adjoin: Proof, pair_spec: Proof, newf: str, s: str, y: str, pname: str, ctx) -> Proof:
    pnew = _adjoin_mem_eq(_weaken(graph_adjoin, ctx), pname, pname, Proof('eq_refl', Eq(V(pname), V(pname)), tuple(ctx)), tuple(ctx))
    tgt = GraphValueSpec(V(newf), V(s), V(y), 'qfresh')
    body = substitute(tgt.body, tgt.var, V(pname))
    cb = Proof('and_intro', body, tuple(ctx), (pnew, _weaken(pair_spec, tuple(ctx))))
    return Proof('exists_intro', tgt, tuple(ctx), (cb,), (('term', {'var': pname}),))

def HistoryDomainSpec(d: Term, w: Term, e: str='e', s: str='s', p: str='p') -> Formula:
    avoid = {d.name, w.name}
    e = _fresh_local(e, avoid)
    avoid.add(e)
    s = _fresh_local(s, avoid)
    avoid.add(s)
    p = _fresh_local(p, avoid)
    avoid.add(p)
    empty = Exists(e, And(Mem(V(e), d), EmptySpec(V(e), 'z')))
    pred = Forall(s, Imp(And(Mem(V(s), d), Not(EmptySpec(V(s), 'z2'))), Exists(p, And(Mem(V(p), d), SuccessorSpec(V(s), V(p), 'u')))))
    return _ands(SubsetSpec(d, w, 'q'), empty, pred)

def FiniteHistorySpec(h: Term, d: Term, w: Term, c: Term, a: Term, g: Term, n: str='n', s: str='s', x: str='x', y: str='y', z0: str='z0') -> Formula:
    dom = HistoryDomainSpec(d, w, 'e', 'sdom', 'pdom')
    fun = FunctionGraphSpec(h, d, c, 'ph', 'xh', 'yh', 'yh2')
    gfun = FunctionGraphSpec(g, c, c, 'pg0', 'xg0', 'yg0', 'yg20')
    initial = Forall(z0, Imp(And(Mem(V(z0), d), EmptySpec(V(z0), 'u0')), GraphValueSpec(h, V(z0), a, 'pi')))
    ante = _ands(Mem(V(n), d), Mem(V(s), d), SuccessorSpec(V(s), V(n), 'us'), GraphValueSpec(h, V(n), V(x), 'pn'), GraphValueSpec(g, V(x), V(y), 'pg'))
    step = Forall(n, Forall(s, Forall(x, Forall(y, Imp(ante, GraphValueSpec(h, V(s), V(y), 'ps'))))))
    return _ands(dom, fun, gfun, initial, step)

def HistoryReachSpec(n: Term, w: Term, c: Term, a: Term, g: Term) -> Formula:
    return Exists('dH', Exists('hH', And(FiniteHistorySpec(V('hH'), V('dH'), w, c, a, g), Mem(n, V('dH')))))

def finite_history_extension_formula() -> Formula:
    h, d, w, c, a, g, n, s, x, y = map(V, ['h', 'd', 'w', 'c', 'a', 'g', 'n', 's', 'x', 'y'])
    prem = _ands(FiniteHistorySpec(h, d, w, c, a, g), Mem(n, d), Mem(s, w), SuccessorSpec(s, n, 'u'), GraphValueSpec(h, n, x, 'q1'), Mem(y, c), GraphValueSpec(g, x, y, 'q2'), Not(Mem(s, d)))
    out = Exists('D', Exists('F', And(FiniteHistorySpec(V('F'), V('D'), w, c, a, g), Mem(s, V('D')))))
    q = Imp(prem, out)
    for nm in reversed(['h', 'd', 'w', 'c', 'a', 'g', 'n', 's', 'x', 'y']):
        q = Forall(nm, q)
    return q

def _history_parts(hist: Proof, ctx):
    q = _weaken(hist, tuple(ctx))
    ps = _unpack_ands(q, 5)
    return (ps[0], ps[1], ps[2], ps[3], ps[4])

def _domain_parts(dom: Proof, ctx):
    q = _weaken(dom, tuple(ctx))
    ps = _unpack_ands(q, 3)
    return (ps[0], ps[1], ps[2])

def _nonempty_from_successor(zero_not_succ: Proof, succ: Proof, s: str, n: str, ctx) -> Proof:
    target = Not(EmptySpec(V(s), 'z'))
    cs = tuple(ctx) + (target.left,)
    hemp = _assume(target.left, cs)
    zn = _weaken(zero_not_succ, cs)
    zn = _forall_elim(_forall_elim(zn, s), n)
    negsucc = _imp_elim(zn, hemp)
    bot = _imp_elim(negsucc, _weaken(succ, cs))
    return Proof('imp_intro', target, tuple(ctx), (bot,))

def _graph_value_codomain(fun: Proof, f: str, x: str, y: str, gv: Proof, opinj: Proof, ctx) -> Proof:
    rel, _, _ = _fun_parts(fun, ctx)
    ex = _weaken(gv, tuple(ctx))
    assert isinstance(ex.conclusion, Exists)
    P = 'Pcod_' + f + x + y
    inst = substitute(ex.conclusion.body, ex.conclusion.var, V(P))
    ctxP = tuple(ctx) + (inst,)
    hP = _assume(inst, ctxP)
    Pin = _and_l(hP)
    opPxy = _and_r(hP)
    qr = _forall_elim(_weaken(rel, ctxP), P)
    pairdata = _imp_elim(qr, Pin)
    assert isinstance(pairdata.conclusion, Exists)
    X = 'Xcod_' + f + x + y
    ix = substitute(pairdata.conclusion.body, pairdata.conclusion.var, V(X))
    ctxX = ctxP + (ix,)
    hX = _assume(ix, ctxX)
    exY = _and_r(hX)
    assert isinstance(exY.conclusion, Exists)
    Y = 'Ycod_' + f + x + y
    iy = substitute(exY.conclusion.body, exY.conclusion.var, V(Y))
    ctxY = ctxX + (iy,)
    hY = _assume(iy, ctxY)
    Yc = _and_l(hY)
    opPXY = _and_r(hY)
    inj = _weaken(opinj, ctxY)
    for nm in [P, x, y, X, Y]:
        inj = _forall_elim(inj, nm)
    ante = inj.conclusion.left
    both = Proof('and_intro', ante, ctxY, (_weaken(opPxy, ctxY), opPXY))
    eqs = _imp_elim(inj, both)
    eqyY = _and_r(eqs)
    yc = Proof('eq_subst', Mem(V(y), fun.conclusion.right.left.right.body.right.left if False else V('dummy')), ctxY) if False else None
    cod_term = None
    target = Mem(V(y), hY.conclusion.left.right)
    yc = Proof('eq_subst', target, ctxY, (eqyY, Yc), (('direction', 'rl'),))
    afterY = Proof('exists_elim', target, ctxX, (exY, yc), (('eigenvar', Y),))
    afterX = Proof('exists_elim', target, ctxP, (pairdata, afterY), (('eigenvar', X),))
    return Proof('exists_elim', target, tuple(ctx), (ex, afterX), (('eigenvar', P),))

def build_finite_history_extension(function_extend_pf: Proof | None=None, zero_not_succ_pf: Proof | None=None, succinj_pf: Proof | None=None, opinj_pf: Proof | None=None) -> Proof:
    function_extend_pf = function_extend_pf or build_function_extend_fresh()
    zero_not_succ_pf = zero_not_succ_pf or build_zero_not_successor()
    succinj_pf = succinj_pf or build_successor_injective()
    opinj_pf = opinj_pf or build_ordered_pair_injective()
    goal = finite_history_extension_formula()
    q = goal
    qs = []
    while isinstance(q, Forall):
        qs.append(q)
        q = q.body
    core = q
    prem = core.left
    target = core.right
    ctx0 = (prem,)
    hp = _assume(prem, ctx0)
    hist, nd, sw, succ, gvhn, yc, gvg, nsd = _unpack_ands(hp, 8)
    dom, fun, gfun, initial, step = _history_parts(hist, ctx0)
    subset, empty, pred = _domain_parts(dom, ctx0)
    fe = _weaken(function_extend_pf, ctx0)
    for nm in ['d', 'c', 'h', 's', 'y']:
        fe = _forall_elim(fe, nm)
    fprem = fe.conclusion.left
    rr = Proof('and_intro', fprem.right, ctx0, (_weaken(yc, ctx0), _weaken(nsd, ctx0)))
    fpa = Proof('and_intro', fprem, ctx0, (_weaken(fun, ctx0), rr))
    exD = _imp_elim(fe, fpa)
    assert isinstance(exD.conclusion, Exists)
    D = 'DHext'
    iD = substitute(exD.conclusion.body, exD.conclusion.var, V(D))
    ctxD = ctx0 + (iD,)
    hDpack = _assume(iD, ctxD)
    P = 'PHext'
    exP = hDpack
    assert isinstance(exP.conclusion, Exists)
    iP = substitute(exP.conclusion.body, exP.conclusion.var, V(P))
    ctxP = ctxD + (iP,)
    hPpack = _assume(iP, ctxP)
    F = 'FHext'
    exF = hPpack
    assert isinstance(exF.conclusion, Exists)
    iF = substitute(exF.conclusion.body, exF.conclusion.var, V(F))
    ctxF = ctxP + (iF,)
    hFpack = _assume(iF, ctxF)
    dspec = _and_l(hFpack)
    rest = _and_r(hFpack)
    pspec = _and_l(rest)
    rest2 = _and_r(rest)
    fspec = _and_l(rest2)
    Ffun = _and_r(rest2)
    newdom = HistoryDomainSpec(V(D), V('w'), 'e', 'sdom', 'pdom')
    newsubset = newdom.left
    z = newsubset.var
    iz = newsubset.body
    ctxz = ctxF + (iz.left,)
    hzD = _assume(iz.left, ctxz)
    cases = _adjoin_cases(_weaken(dspec, ctxz), z, hzD, ctxz)
    l = cases.conclusion.left
    ctxL = ctxz + (l,)
    hl = _assume(l, ctxL)
    os = _forall_elim(_weaken(subset, ctxL), z)
    zw = _imp_elim(os, hl)
    r = cases.conclusion.right
    ctxR = ctxz + (r,)
    hr = _assume(r, ctxR)
    swz = Proof('eq_subst', Mem(V(z), V('w')), ctxR, (hr, _weaken(sw, ctxR)), (('direction', 'rl'),))
    zW = Proof('or_elim', Mem(V(z), V('w')), ctxz, (cases, zw, swz))
    isub = Proof('imp_intro', iz, ctxF, (zW,))
    subpf = Proof('forall_intro', newsubset, ctxF, (isub,))
    newempty = newdom.right.left
    assert isinstance(empty.conclusion, Exists)
    E = 'EHext'
    ie = substitute(empty.conclusion.body, empty.conclusion.var, V(E))
    ctxE = ctxF + (ie,)
    he = _assume(ie, ctxE)
    Ed = _and_l(he)
    empE = _and_r(he)
    ED = _adjoin_mem_left(_weaken(dspec, ctxE), E, Ed, ctxE)
    neb = substitute(newempty.body, newempty.var, V(E))
    cb = Proof('and_intro', neb, ctxE, (ED, _weaken(empE, ctxE)))
    exeb = Proof('exists_intro', newempty, ctxE, (cb,), (('term', {'var': E}),))
    emptypf = Proof('exists_elim', newempty, ctxF, (_weaken(empty, ctxF), exeb), (('eigenvar', E),))
    newpred = newdom.right.right
    ss = newpred.var
    ipr = newpred.body
    ctxs = ctxF + (ipr.left,)
    hante = _assume(ipr.left, ctxs)
    sD = _and_l(hante)
    sne = _and_r(hante)
    dcases = _adjoin_cases(_weaken(dspec, ctxs), ss, sD, ctxs)
    dl = dcases.conclusion.left
    ctxDL = ctxs + (dl,)
    hdl = _assume(dl, ctxDL)
    qp = _forall_elim(_weaken(pred, ctxDL), ss)
    oldAnte = qp.conclusion.left
    oldA = Proof('and_intro', oldAnte, ctxDL, (hdl, _weaken(sne, ctxDL)))
    oldEx = _imp_elim(qp, oldA)
    assert isinstance(oldEx.conclusion, Exists)
    Rr = 'Rpred'
    ir = substitute(oldEx.conclusion.body, oldEx.conclusion.var, V(Rr))
    ctxRR = ctxDL + (ir,)
    hrp = _assume(ir, ctxRR)
    rd = _and_l(hrp)
    ssr = _and_r(hrp)
    rD = _adjoin_mem_left(_weaken(dspec, ctxRR), Rr, rd, ctxRR)
    nb = substitute(ipr.right.body, ipr.right.var, V(Rr))
    cnb = Proof('and_intro', nb, ctxRR, (rD, ssr))
    exnb = Proof('exists_intro', ipr.right, ctxRR, (cnb,), (('term', {'var': Rr}),))
    oldOut = Proof('exists_elim', ipr.right, ctxDL, (oldEx, exnb), (('eigenvar', Rr),))
    dr = dcases.conclusion.right
    ctxDR = ctxs + (dr,)
    hdr = _assume(dr, ctxDR)
    nD = _adjoin_mem_left(_weaken(dspec, ctxDR), 'n', _weaken(nd, ctxDR), ctxDR)
    succSS = Proof('eq_subst', SuccessorSpec(V(ss), V('n'), 'u'), ctxDR, (hdr, _weaken(succ, ctxDR)), (('direction', 'rl'),))
    nb2 = substitute(ipr.right.body, ipr.right.var, V('n'))
    cb2 = Proof('and_intro', nb2, ctxDR, (nD, succSS))
    ex2 = Proof('exists_intro', ipr.right, ctxDR, (cb2,), (('term', {'var': 'n'}),))
    predOut = Proof('or_elim', ipr.right, ctxs, (dcases, oldOut, ex2))
    ipred = Proof('imp_intro', ipr, ctxF, (predOut,))
    predpf = Proof('forall_intro', newpred, ctxF, (ipred,))
    newdompf = _pack_ands(newdom, [subpf, emptypf, predpf], ctxF)
    newhist = FiniteHistorySpec(V(F), V(D), V('w'), V('c'), V('a'), V('g'), 'nN', 'sN', 'xN', 'yN', 'zN')
    newparts = []
    newinitial = _unpack_ands(Proof('assumption', newhist, ctxF + (newhist,)), 5)[3].conclusion
    zi = newinitial.var
    ii = newinitial.body
    ctxi = ctxF + (ii.left,)
    hi = _assume(ii.left, ctxi)
    ziD = _and_l(hi)
    ziEmp = _and_r(hi)
    icases = _adjoin_cases(_weaken(dspec, ctxi), zi, ziD, ctxi)
    il = icases.conclusion.left
    ctxIL = ctxi + (il,)
    hil = _assume(il, ctxIL)
    oi = _forall_elim(_weaken(initial, ctxIL), zi)
    oante = oi.conclusion.left
    oa = Proof('and_intro', oante, ctxIL, (hil, _weaken(ziEmp, ctxIL)))
    oldgv = _imp_elim(oi, oa)
    lift = _lift_graph_value(oldgv, _weaken(fspec, ctxIL), 'h', F, zi, 'a', ctxIL)
    iright = icases.conclusion.right
    ctxIR = ctxi + (iright,)
    hir = _assume(iright, ctxIR)
    empS = Proof('eq_subst', EmptySpec(V('s'), 'zz'), ctxIR, (hir, _weaken(ziEmp, ctxIR)), (('direction', 'lr'),))
    zn = _weaken(zero_not_succ_pf, ctxIR)
    zn = _forall_elim(_forall_elim(zn, 's'), 'n')
    negsucc = _imp_elim(zn, empS)
    bot = _imp_elim(negsucc, _weaken(succ, ctxIR))
    impossible = Proof('bottom_elim', ii.right, ctxIR, (bot,))
    iout = Proof('or_elim', ii.right, ctxi, (icases, lift, impossible))
    iimp = Proof('imp_intro', ii, ctxF, (iout,))
    initpf = Proof('forall_intro', newinitial, ctxF, (iimp,))
    newstep = _unpack_ands(Proof('assumption', newhist, ctxF + (newhist,)), 5)[4].conclusion
    n2 = newstep.var
    s2 = newstep.body.var
    x2 = newstep.body.body.var
    y2 = newstep.body.body.body.var
    ist = newstep.body.body.body.body
    ctxst = ctxF + (ist.left,)
    ha = _assume(ist.left, ctxst)
    n2D, s2D, succ2, gvFn, gvG2 = _unpack_ands(ha, 5)
    y2c = _graph_value_codomain(_weaken(gfun, ctxst), 'g', x2, y2, gvG2, _weaken(opinj_pf, ctxst), ctxst)
    scases = _adjoin_cases(_weaken(dspec, ctxst), s2, s2D, ctxst)
    bL = scases.conclusion.left
    ctxBL = ctxst + (bL,)
    hs2d = _assume(bL, ctxBL)
    nonemp = _nonempty_from_successor(_weaken(zero_not_succ_pf, ctxBL), _weaken(succ2, ctxBL), s2, n2, ctxBL)
    qp2 = _forall_elim(_weaken(pred, ctxBL), s2)
    pa = Proof('and_intro', qp2.conclusion.left, ctxBL, (hs2d, nonemp))
    exr = _imp_elim(qp2, pa)
    assert isinstance(exr.conclusion, Exists)
    R2 = 'Rstep'
    iR2 = substitute(exr.conclusion.body, exr.conclusion.var, V(R2))
    ctxR2 = ctxBL + (iR2,)
    hR2 = _assume(iR2, ctxR2)
    R2d = _and_l(hR2)
    succsR = _and_r(hR2)
    si = _weaken(succinj_pf, ctxR2)
    si = _forall_elim(_forall_elim(_forall_elim(si, R2), n2), s2)
    eqRn = _imp_elim(si, Proof('and_intro', si.conclusion.left, ctxR2, (succsR, _weaken(succ2, ctxR2))))
    n2d = Proof('eq_subst', Mem(V(n2), V('d')), ctxR2, (eqRn, R2d), (('direction', 'lr'),))
    oldtot = _function_total(_weaken(fun, ctxR2), n2, n2d, ctxR2)
    assert isinstance(oldtot.conclusion, Exists)
    X0 = 'Xold'
    iX = substitute(oldtot.conclusion.body, oldtot.conclusion.var, V(X0))
    ctxX = ctxR2 + (iX,)
    hX = _assume(iX, ctxX)
    X0c = _and_l(hX)
    gvOldN = _and_r(hX)
    gvLiftN = _lift_graph_value(gvOldN, _weaken(fspec, ctxX), 'h', F, n2, X0, ctxX)
    x2c = _weaken(y2c, ctxX) if x2 == y2 else _graph_value_codomain(_weaken(Ffun, ctxX), F, n2, x2, _weaken(gvFn, ctxX), _weaken(opinj_pf, ctxX), ctxX)
    eqx = _function_unique(_weaken(Ffun, ctxX), n2, x2, X0, _weaken(n2D, ctxX), x2c, X0c, _weaken(gvFn, ctxX), gvLiftN, ctxX)
    gX0 = Proof('eq_subst', GraphValueSpec(V('g'), V(X0), V(y2), 'pgx'), ctxX, (eqx, _weaken(gvG2, ctxX)), (('direction', 'lr'),))
    oldstep = _weaken(step, ctxX)
    for nm in [n2, s2, X0, y2]:
        oldstep = _forall_elim(oldstep, nm)
    oante = oldstep.conclusion.left
    opack = _pack_ands(oante, [n2d, _weaken(hs2d, ctxX), _weaken(succ2, ctxX), gvOldN, gX0], ctxX)
    oldSVal = _imp_elim(oldstep, opack)
    newSVal = _lift_graph_value(oldSVal, _weaken(fspec, ctxX), 'h', F, s2, y2, ctxX)
    afterX = Proof('exists_elim', ist.right, ctxR2, (oldtot, newSVal), (('eigenvar', X0),))
    oldBranch = Proof('exists_elim', ist.right, ctxBL, (exr, afterX), (('eigenvar', R2),))
    bR = scases.conclusion.right
    ctxBR = ctxst + (bR,)
    hs2s = _assume(bR, ctxBR)
    succ_sn2 = Proof('eq_subst', SuccessorSpec(V('s'), V(n2), 'uu'), ctxBR, (hs2s, _weaken(succ2, ctxBR)), (('direction', 'lr'),))
    si2 = _weaken(succinj_pf, ctxBR)
    si2 = _forall_elim(si2, 'n')
    si2 = _forall_elim(si2, n2)
    si2 = _forall_elim(si2, 's')
    eqnn2 = _imp_elim(si2, Proof('and_intro', si2.conclusion.left, ctxBR, (_weaken(succ, ctxBR), succ_sn2)))
    n2d2 = Proof('eq_subst', Mem(V(n2), V('d')), ctxBR, (eqnn2, _weaken(nd, ctxBR)), (('direction', 'lr'),))
    oldtot2 = _function_total(_weaken(fun, ctxBR), n2, n2d2, ctxBR)
    assert isinstance(oldtot2.conclusion, Exists)
    X1 = 'Xfresh'
    iX1 = substitute(oldtot2.conclusion.body, oldtot2.conclusion.var, V(X1))
    ctxX1 = ctxBR + (iX1,)
    hX1 = _assume(iX1, ctxX1)
    X1c = _and_l(hX1)
    gvOld2 = _and_r(hX1)
    gvLift2 = _lift_graph_value(gvOld2, _weaken(fspec, ctxX1), 'h', F, n2, X1, ctxX1)
    x2c2 = _graph_value_codomain(_weaken(Ffun, ctxX1), F, n2, x2, _weaken(gvFn, ctxX1), _weaken(opinj_pf, ctxX1), ctxX1)
    eqx2 = _function_unique(_weaken(Ffun, ctxX1), n2, x2, X1, _weaken(n2D, ctxX1), x2c2, X1c, _weaken(gvFn, ctxX1), gvLift2, ctxX1)
    gvOldOriginal = Proof('eq_subst', GraphValueSpec(V('h'), V(n2), V('x'), 'qorig'), ctxX1, (_weaken(eqnn2, ctxX1), _weaken(gvhn, ctxX1)), (('direction', 'lr'),))
    xc = _graph_value_codomain(_weaken(fun, ctxX1), 'h', n2, 'x', gvOldOriginal, _weaken(opinj_pf, ctxX1), ctxX1)
    eqxorig = _function_unique(_weaken(fun, ctxX1), n2, 'x', X1, n2d2, xc, X1c, gvOldOriginal, gvOld2, ctxX1)
    gX1Y = Proof('eq_subst', GraphValueSpec(V('g'), V(X1), V('y'), 'ggy'), ctxX1, (eqxorig, _weaken(gvg, ctxX1)), (('direction', 'lr'),))
    gX1Y2 = Proof('eq_subst', GraphValueSpec(V('g'), V(X1), V(y2), 'ggy2'), ctxX1, (eqx2, _weaken(gvG2, ctxX1)), (('direction', 'lr'),))
    yc1 = _weaken(yc, ctxX1)
    y2c1 = _weaken(y2c, ctxX1)
    eqyy2 = _function_unique(_weaken(gfun, ctxX1), X1, 'y', y2, X1c, yc1, y2c1, gX1Y, gX1Y2, ctxX1)
    fresh = _fresh_graph_value(_weaken(fspec, ctxX1), _weaken(pspec, ctxX1), F, 's', 'y', P, ctxX1)
    fresh2 = Proof('eq_subst', GraphValueSpec(V(F), V('s'), V(y2), 'qf2'), ctxX1, (eqyy2, fresh), (('direction', 'lr'),))
    target2 = Proof('eq_subst', ist.right, ctxX1, (_weaken(hs2s, ctxX1), fresh2), (('direction', 'rl'),))
    afterX1 = Proof('exists_elim', ist.right, ctxBR, (oldtot2, target2), (('eigenvar', X1),))
    stepOut = Proof('or_elim', ist.right, ctxst, (scases, oldBranch, afterX1))
    istep = Proof('imp_intro', ist, ctxF, (stepOut,))
    qy = Proof('forall_intro', newstep.body.body.body, ctxF, (istep,))
    qx = Proof('forall_intro', newstep.body.body, ctxF, (qy,))
    qs2 = Proof('forall_intro', newstep.body, ctxF, (qx,))
    steppf = Proof('forall_intro', newstep, ctxF, (qs2,))
    newhistpf = _pack_ands(newhist, [newdompf, Ffun, _weaken(gfun, ctxF), initpf, steppf], ctxF)
    sDnew = _adjoin_mem_eq(_weaken(dspec, ctxF), 's', 's', Proof('eq_refl', Eq(V('s'), V('s')), ctxF), ctxF)
    tF = substitute(target.body, target.var, V(D))
    tFF = substitute(tF.body, tF.var, V(F))
    bodyOut = Proof('and_intro', tFF, ctxF, (newhistpf, sDnew))
    exFF = Proof('exists_intro', tF, ctxF, (bodyOut,), (('term', {'var': F}),))
    afterF = Proof('exists_elim', tF, ctxP, (exF, exFF), (('eigenvar', F),))
    exPP = Proof('exists_elim', tF, ctxD, (exP, afterF), (('eigenvar', P),))
    exDD = Proof('exists_intro', target, ctxD, (exPP,), (('term', {'var': D}),))
    afterD = Proof('exists_elim', target, ctx0, (exD, exDD), (('eigenvar', D),))
    imp = Proof('imp_intro', core, (), (afterD,))
    p = imp
    cur = goal
    forms = []
    while isinstance(cur, Forall):
        forms.append(cur)
        cur = cur.body
    for f in reversed(forms):
        p = Proof('forall_intro', f, (), (p,))
    return p

def _excluded_middle(phi: Formula, ctx) -> Proof:
    """Classical P or not P, derived from the existing reductio rule."""
    goal = Or(phi, Not(phi))
    ng = Not(goal)
    ctxn = tuple(ctx) + (ng,)
    hng = _assume(ng, ctxn)
    ctxp = ctxn + (phi,)
    hp = _assume(phi, ctxp)
    disj = Proof('or_intro_left', goal, ctxp, (hp,))
    bot1 = _imp_elim(_weaken(hng, ctxp), disj)
    nphi = Proof('imp_intro', Not(phi), ctxn, (bot1,))
    disj2 = Proof('or_intro_right', goal, ctxn, (nphi,))
    bot2 = _imp_elim(hng, disj2)
    return Proof('classical_reductio', goal, tuple(ctx), (bot2,))

def finite_history_zero_reach_formula() -> Formula:
    w, c, a, g = map(V, ['w', 'c', 'a', 'g'])
    base = And(OmegaSpec(w, 'j', 'k'), And(Mem(a, c), FunctionGraphSpec(g, c, c, 'pg', 'xg', 'yg', 'yg2')))
    out = Exists('zH', And(Mem(V('zH'), w), And(EmptySpec(V('zH'), 'ez'), HistoryReachSpec(V('zH'), w, c, a, g))))
    return Forall('w', Forall('c', Forall('a', Forall('g', Imp(base, out)))))

def build_finite_history_zero_reach(constant_function_pf: Proof | None=None, singleton_pf: Proof | None=None, zero_not_succ_pf: Proof | None=None) -> Proof:
    from .derived_library import build_singleton_exists
    constant_function_pf = constant_function_pf or build_constant_function_exists(4, 1)
    singleton_pf = singleton_pf or build_singleton_exists()
    zero_not_succ_pf = zero_not_succ_pf or build_zero_not_successor()
    goal = finite_history_zero_reach_formula()
    core = goal.body.body.body.body
    base = core.left
    target = core.right
    ctx0 = (base,)
    hb = _assume(base, ctx0)
    om = _and_l(hb)
    rr = _and_r(hb)
    ac = _and_l(rr)
    gfun = _and_r(rr)
    indw = _and_l(om)
    exz = _and_l(indw)
    assert isinstance(exz.conclusion, Exists)
    Z = 'ZH0'
    iz = substitute(exz.conclusion.body, exz.conclusion.var, V(Z))
    ctxZ = ctx0 + (iz,)
    hz = _assume(iz, ctxZ)
    Zw = _and_l(hz)
    emptyZ = _and_r(hz)
    sp = _forall_elim(_weaken(singleton_pf, ctxZ), Z)
    assert isinstance(sp.conclusion, Exists)
    D = 'DH0'
    iD = substitute(sp.conclusion.body, sp.conclusion.var, V(D))
    ctxD = ctxZ + (iD,)
    hD = _assume(iD, ctxD)
    cf = _weaken(constant_function_pf, ctxD)
    for nm in [D, 'c', 'a']:
        cf = _forall_elim(cf, nm)
    exH = _imp_elim(cf, _weaken(ac, ctxD))
    assert isinstance(exH.conclusion, Exists)
    H = 'HH0'
    iH = substitute(exH.conclusion.body, exH.conclusion.var, V(H))
    ctxH = ctxD + (iH,)
    hH = _assume(iH, ctxH)
    hfun = _and_l(hH)
    hvals = _and_r(hH)
    dom = HistoryDomainSpec(V(D), V('w'), 'e0', 'sd0', 'pd0')
    sub = dom.left
    q = sub.var
    iq = sub.body
    ctxq = ctxH + (iq.left,)
    hqD = _assume(iq.left, ctxq)
    sdq = _forall_elim(_weaken(hD, ctxq), q)
    eq_qZ = _imp_elim(_iff_l(sdq), hqD)
    qW = Proof('eq_subst', Mem(V(q), V('w')), ctxq, (eq_qZ, _weaken(Zw, ctxq)), (('direction', 'rl'),))
    isub = Proof('imp_intro', iq, ctxH, (qW,))
    subpf = Proof('forall_intro', sub, ctxH, (isub,))
    zmemiff = _forall_elim(_weaken(hD, ctxH), Z)
    eqzz = Proof('eq_refl', Eq(V(Z), V(Z)), ctxH)
    ZD = _imp_elim(_iff_r(zmemiff), eqzz)
    eg = dom.right.left
    egbody = substitute(eg.body, eg.var, V(Z))
    ceg = Proof('and_intro', egbody, ctxH, (ZD, _weaken(emptyZ, ctxH)))
    emptypf = Proof('exists_intro', eg, ctxH, (ceg,), (('term', {'var': Z}),))
    pred = dom.right.right
    s = pred.var
    ip = pred.body
    ctxs = ctxH + (ip.left,)
    ha = _assume(ip.left, ctxs)
    sD = _and_l(ha)
    sne = _and_r(ha)
    siff = _forall_elim(_weaken(hD, ctxs), s)
    eq_sZ = _imp_elim(_iff_l(siff), sD)
    emptyS = Proof('eq_subst', EmptySpec(V(s), 'ee'), ctxs, (eq_sZ, _weaken(emptyZ, ctxs)), (('direction', 'rl'),))
    bot = _imp_elim(sne, emptyS)
    exPred = Proof('bottom_elim', ip.right, ctxs, (bot,))
    ipp = Proof('imp_intro', ip, ctxH, (exPred,))
    predpf = Proof('forall_intro', pred, ctxH, (ipp,))
    dompf = _pack_ands(dom, [subpf, emptypf, predpf], ctxH)
    hist = FiniteHistorySpec(V(H), V(D), V('w'), V('c'), V('a'), V('g'))
    initial = _unpack_ands(Proof('assumption', hist, ctxH + (hist,)), 5)[3].conclusion
    z0 = initial.var
    ii = initial.body
    ctxi = ctxH + (ii.left,)
    hi = _assume(ii.left, ctxi)
    z0D = _and_l(hi)
    hv = _forall_elim(_weaken(hvals, ctxi), z0)
    gv0 = _imp_elim(hv, z0D)
    iip = Proof('imp_intro', ii, ctxH, (gv0,))
    initpf = Proof('forall_intro', initial, ctxH, (iip,))
    step = _unpack_ands(Proof('assumption', hist, ctxH + (hist,)), 5)[4].conclusion
    n = step.var
    s2 = step.body.var
    x = step.body.body.var
    y = step.body.body.body.var
    ist = step.body.body.body.body
    ctxst = ctxH + (ist.left,)
    hs = _assume(ist.left, ctxst)
    _, s2D, succ2, _, _ = _unpack_ands(hs, 5)
    sif2 = _forall_elim(_weaken(hD, ctxst), s2)
    eq_s2Z = _imp_elim(_iff_l(sif2), s2D)
    succZn = Proof('eq_subst', SuccessorSpec(V(Z), V(n), 'uu'), ctxst, (eq_s2Z, succ2), (('direction', 'lr'),))
    zn = _weaken(zero_not_succ_pf, ctxst)
    zn = _forall_elim(_forall_elim(zn, Z), n)
    neg = _imp_elim(zn, _weaken(emptyZ, ctxst))
    bot2 = _imp_elim(neg, succZn)
    gout = Proof('bottom_elim', ist.right, ctxst, (bot2,))
    istep = Proof('imp_intro', ist, ctxH, (gout,))
    qy = Proof('forall_intro', step.body.body.body, ctxH, (istep,))
    qx = Proof('forall_intro', step.body.body, ctxH, (qy,))
    qs = Proof('forall_intro', step.body, ctxH, (qx,))
    steppf = Proof('forall_intro', step, ctxH, (qs,))
    histpf = _pack_ands(hist, [dompf, hfun, _weaken(gfun, ctxH), initpf, steppf], ctxH)
    reach = HistoryReachSpec(V(Z), V('w'), V('c'), V('a'), V('g'))
    rhD = substitute(reach.body, reach.var, V(D))
    rhH = substitute(rhD.body, rhD.var, V(H))
    both = Proof('and_intro', rhH, ctxH, (histpf, ZD))
    exhh = Proof('exists_intro', rhD, ctxH, (both,), (('term', {'var': H}),))
    exdd = Proof('exists_intro', reach, ctxH, (exhh,), (('term', {'var': D}),))
    outZ = substitute(target.body, target.var, V(Z))
    tail = Proof('and_intro', outZ.right, ctxH, (_weaken(emptyZ, ctxH), exdd))
    outbody = Proof('and_intro', outZ, ctxH, (_weaken(Zw, ctxH), tail))
    exout = Proof('exists_intro', target, ctxH, (outbody,), (('term', {'var': Z}),))
    afterH = Proof('exists_elim', target, ctxD, (exH, exout), (('eigenvar', H),))
    afterD = Proof('exists_elim', target, ctxZ, (sp, afterH), (('eigenvar', D),))
    afterZ = Proof('exists_elim', target, ctx0, (exz, afterD), (('eigenvar', Z),))
    imp = Proof('imp_intro', core, (), (afterZ,))
    qg = Proof('forall_intro', goal.body.body.body, (), (imp,))
    qa = Proof('forall_intro', goal.body.body, (), (qg,))
    qc = Proof('forall_intro', goal.body, (), (qa,))
    return Proof('forall_intro', goal, (), (qc,))
REACH_SEPARATION_SCHEMA = SchemaInstance('SEPARATION', HistoryReachSpec(V('n'), V('w'), V('c'), V('a'), V('g')), source_var='n', parameters=('w', 'c', 'a', 'g'))
PASS008_SCHEMA_INSTANCES = tuple(PASS007_SCHEMA_INSTANCES) + (REACH_SEPARATION_SCHEMA,)

def omega_history_reach_formula() -> Formula:
    w, c, a, g = map(V, ['w', 'c', 'a', 'g'])
    base = And(OmegaSpec(w, 'j', 'k'), And(Mem(a, c), FunctionGraphSpec(g, c, c, 'pg', 'xg', 'yg', 'yg2')))
    body = Forall('n', Imp(Mem(V('n'), w), HistoryReachSpec(V('n'), w, c, a, g)))
    return Forall('w', Forall('c', Forall('a', Forall('g', Imp(base, body)))))

def build_omega_history_reach(reach_schema_index: int=7, zero_reach_pf: Proof | None=None, extension_pf: Proof | None=None, omega_induction_pf: Proof | None=None) -> Proof:
    zero_reach_pf = zero_reach_pf or build_finite_history_zero_reach()
    extension_pf = extension_pf or build_finite_history_extension()
    omega_induction_pf = omega_induction_pf or build_omega_induction_subset()
    goal = omega_history_reach_formula()
    core = goal.body.body.body.body
    base = core.left
    target = core.right
    ctx0 = (base,)
    hb = _assume(base, ctx0)
    om = _and_l(hb)
    rr = _and_r(hb)
    ac = _and_l(rr)
    gfun = _and_r(rr)
    sep = Proof('axiom_schema', REACH_SEPARATION_SCHEMA.generated(), ctx0, (), (('schema_index', reach_schema_index),))
    q = sep
    for nm in ['w', 'c', 'a', 'g', 'w']:
        q = _forall_elim(q, nm)
    assert isinstance(q.conclusion, Exists)
    E = 'Ereach'
    specE = substitute(q.conclusion.body, q.conclusion.var, V(E))
    ctxE = ctx0 + (specE,)
    hE = _assume(specE, ctxE)
    sub = SubsetSpec(V(E), V('w'), 'ns')
    nsub = sub.var
    isub = sub.body
    ctxn = ctxE + (isub.left,)
    hnE = _assume(isub.left, ctxn)
    sepn = _forall_elim(_weaken(hE, ctxn), nsub)
    rhsn = _imp_elim(_iff_l(sepn), hnE)
    nw = _and_l(rhsn)
    ii = Proof('imp_intro', isub, ctxE, (nw,))
    subpf = Proof('forall_intro', sub, ctxE, (ii,))
    zr = _weaken(zero_reach_pf, ctxE)
    for nm in ['w', 'c', 'a', 'g']:
        zr = _forall_elim(zr, nm)
    exz = _imp_elim(zr, _weaken(hb, ctxE))
    assert isinstance(exz.conclusion, Exists)
    Z = 'ZR'
    iz = substitute(exz.conclusion.body, exz.conclusion.var, V(Z))
    ctxZ = ctxE + (iz,)
    hz = _assume(iz, ctxZ)
    Zw = _and_l(hz)
    ztail = _and_r(hz)
    emptyZ = _and_l(ztail)
    reachZ = _and_r(ztail)
    sepZ = _forall_elim(_weaken(hE, ctxZ), Z)
    rhsZ = Proof('and_intro', sepZ.conclusion.right, ctxZ, (Zw, reachZ))
    ZE = _imp_elim(_iff_r(sepZ), rhsZ)
    baseGoal = Exists('e', And(Mem(V('e'), V(E)), EmptySpec(V('e'), 'z')))
    bz = substitute(baseGoal.body, baseGoal.var, V(Z))
    cb = Proof('and_intro', bz, ctxZ, (ZE, emptyZ))
    exb = Proof('exists_intro', baseGoal, ctxZ, (cb,), (('term', {'var': Z}),))
    basepf = Proof('exists_elim', baseGoal, ctxE, (exz, exb), (('eigenvar', Z),))
    closed = Forall('n', Imp(Mem(V('n'), V(E)), Exists('s', And(Mem(V('s'), V(E)), SuccessorSpec(V('s'), V('n'), 'u')))))
    n = closed.var
    ic = closed.body
    ctxN = ctxE + (ic.left,)
    hnE2 = _assume(ic.left, ctxN)
    sepN = _forall_elim(_weaken(hE, ctxN), n)
    rhsN = _imp_elim(_iff_l(sepN), hnE2)
    nW = _and_l(rhsN)
    reachN = _and_r(rhsN)
    wclosed = _and_r(_and_l(_weaken(om, ctxN)))
    qs = _forall_elim(wclosed, n)
    exs = _imp_elim(qs, nW)
    assert isinstance(exs.conclusion, Exists)
    S = 'SR'
    iS = substitute(exs.conclusion.body, exs.conclusion.var, V(S))
    ctxS = ctxN + (iS,)
    hS = _assume(iS, ctxS)
    SW = _and_l(hS)
    succSn = _and_r(hS)
    D = 'DR'
    iD = substitute(reachN.conclusion.body, reachN.conclusion.var, V(D))
    ctxD = ctxS + (iD,)
    hDpack = _assume(iD, ctxD)
    exH = hDpack
    assert isinstance(exH.conclusion, Exists)
    H = 'HR'
    iH = substitute(exH.conclusion.body, exH.conclusion.var, V(H))
    ctxH = ctxD + (iH,)
    hHpack = _assume(iH, ctxH)
    hist = _and_l(hHpack)
    nD = _and_r(hHpack)
    dom, fun, _, _, _ = _history_parts(hist, ctxH)
    memSD = Mem(V(S), V(D))
    em = _excluded_middle(memSD, ctxH)
    ctxL = ctxH + (memSD,)
    hSD = _assume(memSD, ctxL)
    reachS = HistoryReachSpec(V(S), V('w'), V('c'), V('a'), V('g'))
    rD = substitute(reachS.body, reachS.var, V(D))
    rH = substitute(rD.body, rD.var, V(H))
    rb = Proof('and_intro', rH, ctxL, (_weaken(hist, ctxL), hSD))
    reh = Proof('exists_intro', rD, ctxL, (rb,), (('term', {'var': H}),))
    reD = Proof('exists_intro', reachS, ctxL, (reh,), (('term', {'var': D}),))
    nmem = _weaken(nD, ctxH)
    totH = _function_total(fun, n, nmem, ctxH)
    assert isinstance(totH.conclusion, Exists)
    X = 'XR'
    ix = substitute(totH.conclusion.body, totH.conclusion.var, V(X))
    ctxX = ctxH + (ix,)
    hx = _assume(ix, ctxX)
    Xc = _and_l(hx)
    gvhn = _and_r(hx)
    gtot = _function_total(_weaken(gfun, ctxX), X, Xc, ctxX)
    assert isinstance(gtot.conclusion, Exists)
    Y = 'YR'
    iy = substitute(gtot.conclusion.body, gtot.conclusion.var, V(Y))
    ctxY = ctxX + (iy,)
    hy = _assume(iy, ctxY)
    Yc = _and_l(hy)
    gvg = _and_r(hy)
    ctxR = ctxY + (Not(memSD),)
    hnot = _assume(Not(memSD), ctxR)
    ext = _weaken(extension_pf, ctxR)
    for nm in [H, D, 'w', 'c', 'a', 'g', n, S, X, Y]:
        ext = _forall_elim(ext, nm)
    eprem = ext.conclusion.left
    epack = _pack_ands(eprem, [_weaken(hist, ctxR), _weaken(nD, ctxR), _weaken(SW, ctxR), _weaken(succSn, ctxR), _weaken(gvhn, ctxR), _weaken(Yc, ctxR), _weaken(gvg, ctxR), hnot], ctxR)
    extout = _imp_elim(ext, epack)
    assert equivalent(extout.conclusion, reachS) or isinstance(extout.conclusion, Exists)
    rext = extout
    rightY = Proof('weakening', reachS, ctxR, (rext,)) if not equivalent(rext.conclusion, reachS) else rext
    right_noY = Proof('exists_elim', reachS, ctxX + (Not(memSD),), (_weaken(gtot, ctxX + (Not(memSD),)), rightY), (('eigenvar', Y),))
    right_noX = Proof('exists_elim', reachS, ctxH + (Not(memSD),), (_weaken(totH, ctxH + (Not(memSD),)), right_noY), (('eigenvar', X),))
    leftR = _weaken(reD, ctxL)
    reachS_pf = Proof('or_elim', reachS, ctxH, (em, leftR, right_noX))
    sepS = _forall_elim(_weaken(hE, ctxH), S)
    rhsES = Proof('and_intro', sepS.conclusion.right, ctxH, (_weaken(SW, ctxH), reachS_pf))
    SE = _imp_elim(_iff_r(sepS), rhsES)
    outS = substitute(ic.right.body, ic.right.var, V(S))
    cbS = Proof('and_intro', outS, ctxH, (SE, _weaken(succSn, ctxH)))
    exSE = Proof('exists_intro', ic.right, ctxH, (cbS,), (('term', {'var': S}),))
    afterH = Proof('exists_elim', ic.right, ctxD, (exH, exSE), (('eigenvar', H),))
    afterD = Proof('exists_elim', ic.right, ctxS, (_weaken(reachN, ctxS), afterH), (('eigenvar', D),))
    afterS = Proof('exists_elim', ic.right, ctxN, (exs, afterD), (('eigenvar', S),))
    cip = Proof('imp_intro', ic, ctxE, (afterS,))
    closepf = Proof('forall_intro', closed, ctxE, (cip,))
    indE = InductiveSetSpec(V(E), 'e', 'n', 's', 'z')
    indpf = Proof('and_intro', indE, ctxE, (basepf, closepf))
    oi = _weaken(omega_induction_pf, ctxE)
    for nm in ['w', E]:
        oi = _forall_elim(oi, nm)
    ante = oi.conclusion.left
    rrI = Proof('and_intro', ante.right, ctxE, (subpf, indpf))
    allI = Proof('and_intro', ante, ctxE, (_weaken(om, ctxE), rrI))
    eqEw = _imp_elim(oi, allI)
    n2 = target.var
    it = target.body
    ctxT = ctxE + (it.left,)
    hnW = _assume(it.left, ctxT)
    nE = Proof('eq_subst', Mem(V(n2), V(E)), ctxT, (_weaken(eqEw, ctxT), hnW), (('direction', 'rl'),))
    spn = _forall_elim(_weaken(hE, ctxT), n2)
    rrn = _imp_elim(_iff_l(spn), nE)
    reach = _and_r(rrn)
    ip = Proof('imp_intro', it, ctxE, (reach,))
    targpf = Proof('forall_intro', target, ctxE, (ip,))
    afterE = Proof('exists_elim', target, ctx0, (q, targpf), (('eigenvar', E),))
    imp = Proof('imp_intro', core, (), (afterE,))
    qg = Proof('forall_intro', goal.body.body.body, (), (imp,))
    qa = Proof('forall_intro', goal.body.body, (), (qg,))
    qc = Proof('forall_intro', goal.body, (), (qa,))
    return Proof('forall_intro', goal, (), (qc,))

def HistoryAgreementAtSpec(n: Term, h: Term, d: Term, k: Term, e: Term, c: Term) -> Formula:
    from .recursion_library import CommonAtSpec
    return Imp(And(Mem(n, d), Mem(n, e)), CommonAtSpec(n, h, k, c, 'yhag'))
HISTORY_AGREEMENT_SEPARATION_SCHEMA = SchemaInstance('SEPARATION', HistoryAgreementAtSpec(V('n'), V('h'), V('d'), V('k'), V('e'), V('c')), source_var='n', parameters=('h', 'd', 'k', 'e', 'c'))
PASS008_SCHEMA_INSTANCES = tuple(PASS007_SCHEMA_INSTANCES) + (REACH_SEPARATION_SCHEMA, HISTORY_AGREEMENT_SEPARATION_SCHEMA)

def finite_history_compatibility_formula() -> Formula:
    from .recursion_library import CommonAtSpec
    w, c, a, g, h, d, k, e = map(V, ['w', 'c', 'a', 'g', 'h', 'd', 'k', 'e'])
    prem = _ands(OmegaSpec(w, 'j', 'kk'), Mem(a, c), FiniteHistorySpec(h, d, w, c, a, g), FiniteHistorySpec(k, e, w, c, a, g))
    target = Forall('n', Imp(And(Mem(V('n'), d), Mem(V('n'), e)), CommonAtSpec(V('n'), h, k, c, 'yco')))
    q = Imp(prem, target)
    for nm in reversed(['w', 'c', 'a', 'g', 'h', 'd', 'k', 'e']):
        q = Forall(nm, q)
    return q

def build_finite_history_compatibility(agreement_schema_index: int=8, omega_induction_pf: Proof | None=None, zero_not_succ_pf: Proof | None=None, succinj_pf: Proof | None=None) -> Proof:
    from .recursion_library import CommonAtSpec
    omega_induction_pf = omega_induction_pf or build_omega_induction_subset()
    zero_not_succ_pf = zero_not_succ_pf or build_zero_not_successor()
    succinj_pf = succinj_pf or build_successor_injective()
    goal = finite_history_compatibility_formula()
    q = goal
    forms = []
    while isinstance(q, Forall):
        forms.append(q)
        q = q.body
    core = q
    prem = core.left
    target = core.right
    ctx0 = (prem,)
    hp = _assume(prem, ctx0)
    om, ac, hist1, hist2 = _unpack_ands(hp, 4)
    dom1, fun1, gfun1, init1, step1 = _history_parts(hist1, ctx0)
    dom2, fun2, gfun2, init2, step2 = _history_parts(hist2, ctx0)
    sub1, _, pred1 = _domain_parts(dom1, ctx0)
    sub2, _, pred2 = _domain_parts(dom2, ctx0)
    sep = Proof('axiom_schema', HISTORY_AGREEMENT_SEPARATION_SCHEMA.generated(), ctx0, (), (('schema_index', agreement_schema_index),))
    sq = sep
    for nm in ['h', 'd', 'k', 'e', 'c', 'w']:
        sq = _forall_elim(sq, nm)
    assert isinstance(sq.conclusion, Exists)
    E = 'Ehistagree'
    iE = substitute(sq.conclusion.body, sq.conclusion.var, V(E))
    ctxE = ctx0 + (iE,)
    hE = _assume(iE, ctxE)
    subE = SubsetSpec(V(E), V('w'), 'na')
    na = subE.var
    isa = subE.body
    ctxA = ctxE + (isa.left,)
    hnE = _assume(isa.left, ctxA)
    sepa = _forall_elim(_weaken(hE, ctxA), na)
    rhsa = _imp_elim(_iff_l(sepa), hnE)
    nW = _and_l(rhsa)
    ia = Proof('imp_intro', isa, ctxE, (nW,))
    subEpf = Proof('forall_intro', subE, ctxE, (ia,))
    exz = _and_l(_and_l(_weaken(om, ctxE)))
    assert isinstance(exz.conclusion, Exists)
    Z = 'ZA'
    iz = substitute(exz.conclusion.body, exz.conclusion.var, V(Z))
    ctxZ = ctxE + (iz,)
    hz = _assume(iz, ctxZ)
    ZW = _and_l(hz)
    emptyZ = _and_r(hz)
    predZ = HistoryAgreementAtSpec(V(Z), V('h'), V('d'), V('k'), V('e'), V('c'))
    ctxP = ctxZ + (predZ.left,)
    hboth = _assume(predZ.left, ctxP)
    Zd = _and_l(hboth)
    Ze = _and_r(hboth)
    qi = _forall_elim(_weaken(init1, ctxP), Z)
    gv1 = _imp_elim(qi, Proof('and_intro', qi.conclusion.left, ctxP, (Zd, _weaken(emptyZ, ctxP))))
    qj = _forall_elim(_weaken(init2, ctxP), Z)
    gv2 = _imp_elim(qj, Proof('and_intro', qj.conclusion.left, ctxP, (Ze, _weaken(emptyZ, ctxP))))
    common = predZ.right
    ca = substitute(common.body, common.var, V('a'))
    pair = Proof('and_intro', ca.right, ctxP, (gv1, gv2))
    cab = Proof('and_intro', ca, ctxP, (_weaken(ac, ctxP), pair))
    excommon = Proof('exists_intro', common, ctxP, (cab,), (('term', {'var': 'a'}),))
    ipred = Proof('imp_intro', predZ, ctxZ, (excommon,))
    sepZ = _forall_elim(_weaken(hE, ctxZ), Z)
    rhsZ = Proof('and_intro', sepZ.conclusion.right, ctxZ, (ZW, ipred))
    ZE = _imp_elim(_iff_r(sepZ), rhsZ)
    baseGoal = Exists('z', And(Mem(V('z'), V(E)), EmptySpec(V('z'), 'zz')))
    bz = substitute(baseGoal.body, baseGoal.var, V(Z))
    cbz = Proof('and_intro', bz, ctxZ, (ZE, _weaken(emptyZ, ctxZ)))
    exb = Proof('exists_intro', baseGoal, ctxZ, (cbz,), (('term', {'var': Z}),))
    basepf = Proof('exists_elim', baseGoal, ctxE, (exz, exb), (('eigenvar', Z),))
    closed = Forall('nA', Imp(Mem(V('nA'), V(E)), Exists('sA', And(Mem(V('sA'), V(E)), SuccessorSpec(V('sA'), V('nA'), 'uA')))))
    n = closed.var
    ic = closed.body
    ctxN = ctxE + (ic.left,)
    hnE2 = _assume(ic.left, ctxN)
    sepN = _forall_elim(_weaken(hE, ctxN), n)
    rhsN = _imp_elim(_iff_l(sepN), hnE2)
    nW2 = _and_l(rhsN)
    agreeN = _and_r(rhsN)
    exs = _imp_elim(_forall_elim(_and_r(_and_l(_weaken(om, ctxN))), n), nW2)
    assert isinstance(exs.conclusion, Exists)
    S = 'SA'
    is_ = substitute(exs.conclusion.body, exs.conclusion.var, V(S))
    ctxS = ctxN + (is_,)
    hs = _assume(is_, ctxS)
    SW = _and_l(hs)
    succSn = _and_r(hs)
    predS = HistoryAgreementAtSpec(V(S), V('h'), V('d'), V('k'), V('e'), V('c'))
    ctxB = ctxS + (predS.left,)
    hSE = _assume(predS.left, ctxB)
    Sd = _and_l(hSE)
    Se = _and_r(hSE)
    nonemp = _nonempty_from_successor(_weaken(zero_not_succ_pf, ctxB), _weaken(succSn, ctxB), S, n, ctxB)
    qpd = _forall_elim(_weaken(pred1, ctxB), S)
    apd = Proof('and_intro', qpd.conclusion.left, ctxB, (Sd, nonemp))
    exPd = _imp_elim(qpd, apd)
    assert isinstance(exPd.conclusion, Exists)
    PD = 'PDA'
    iPD = substitute(exPd.conclusion.body, exPd.conclusion.var, V(PD))
    ctxPD = ctxB + (iPD,)
    hPD = _assume(iPD, ctxPD)
    PDd = _and_l(hPD)
    succSPD = _and_r(hPD)
    si = _weaken(succinj_pf, ctxPD)
    for nm in [PD, n, S]:
        si = _forall_elim(si, nm)
    eqPDn = _imp_elim(si, Proof('and_intro', si.conclusion.left, ctxPD, (succSPD, _weaken(succSn, ctxPD))))
    nd = Proof('eq_subst', Mem(V(n), V('d')), ctxPD, (eqPDn, PDd), (('direction', 'lr'),))
    qpe = _forall_elim(_weaken(pred2, ctxPD), S)
    ape = Proof('and_intro', qpe.conclusion.left, ctxPD, (_weaken(Se, ctxPD), _weaken(nonemp, ctxPD)))
    exPe = _imp_elim(qpe, ape)
    assert isinstance(exPe.conclusion, Exists)
    PE = 'PEA'
    iPE = substitute(exPe.conclusion.body, exPe.conclusion.var, V(PE))
    ctxPE = ctxPD + (iPE,)
    hPE = _assume(iPE, ctxPE)
    PEe = _and_l(hPE)
    succSPE = _and_r(hPE)
    si2 = _weaken(succinj_pf, ctxPE)
    for nm in [PE, n, S]:
        si2 = _forall_elim(si2, nm)
    eqPEn = _imp_elim(si2, Proof('and_intro', si2.conclusion.left, ctxPE, (succSPE, _weaken(succSn, ctxPE))))
    ne = Proof('eq_subst', Mem(V(n), V('e')), ctxPE, (eqPEn, PEe), (('direction', 'lr'),))
    agreeN2 = _weaken(agreeN, ctxPE)
    bothNE = Proof('and_intro', agreeN2.conclusion.left, ctxPE, (_weaken(nd, ctxPE), ne))
    commonN = _imp_elim(agreeN2, bothNE)
    assert isinstance(commonN.conclusion, Exists)
    X = 'Xagree'
    iX = substitute(commonN.conclusion.body, commonN.conclusion.var, V(X))
    ctxX = ctxPE + (iX,)
    hX = _assume(iX, ctxX)
    Xc = _and_l(hX)
    vals = _and_r(hX)
    gvHn = _and_l(vals)
    gvKn = _and_r(vals)
    exy = _function_total(_weaken(gfun1, ctxX), X, Xc, ctxX)
    assert isinstance(exy.conclusion, Exists)
    Y = 'Yagree'
    iY = substitute(exy.conclusion.body, exy.conclusion.var, V(Y))
    ctxY = ctxX + (iY,)
    hY = _assume(iY, ctxY)
    Yc = _and_l(hY)
    gvG = _and_r(hY)
    gvHs = _apply_rec_step(_weaken(step1, ctxY), n, S, X, Y, _weaken(nd, ctxY), _weaken(Sd, ctxY), _weaken(succSn, ctxY), _weaken(gvHn, ctxY), gvG, ctxY)
    gvKs = _apply_rec_step(_weaken(step2, ctxY), n, S, X, Y, _weaken(ne, ctxY), _weaken(Se, ctxY), _weaken(succSn, ctxY), _weaken(gvKn, ctxY), gvG, ctxY)
    commonS = predS.right
    iCY = substitute(commonS.body, commonS.var, V(Y))
    pairY = Proof('and_intro', iCY.right, ctxY, (gvHs, gvKs))
    bodyY = Proof('and_intro', iCY, ctxY, (Yc, pairY))
    exCY = Proof('exists_intro', commonS, ctxY, (bodyY,), (('term', {'var': Y}),))
    predSproofY = Proof('imp_intro', predS, ctxY[:-1] if False else ctxS, (exCY,)) if False else None
    afterY = Proof('exists_elim', commonS, ctxX, (exy, exCY), (('eigenvar', Y),))
    afterX = Proof('exists_elim', commonS, ctxPE, (commonN, afterY), (('eigenvar', X),))
    afterPE = Proof('exists_elim', commonS, ctxPD, (exPe, afterX), (('eigenvar', PE),))
    afterPD = Proof('exists_elim', commonS, ctxB, (exPd, afterPE), (('eigenvar', PD),))
    ipS = Proof('imp_intro', predS, ctxS, (afterPD,))
    sepS = _forall_elim(_weaken(hE, ctxS), S)
    rhsES = Proof('and_intro', sepS.conclusion.right, ctxS, (SW, ipS))
    SEin = _imp_elim(_iff_r(sepS), rhsES)
    outS = substitute(ic.right.body, ic.right.var, V(S))
    co = Proof('and_intro', outS, ctxS, (SEin, succSn))
    exout = Proof('exists_intro', ic.right, ctxS, (co,), (('term', {'var': S}),))
    afterS = Proof('exists_elim', ic.right, ctxN, (exs, exout), (('eigenvar', S),))
    iC = Proof('imp_intro', ic, ctxE, (afterS,))
    closepf = Proof('forall_intro', closed, ctxE, (iC,))
    indE = InductiveSetSpec(V(E), 'e', 'n', 's', 'z')
    indpf = Proof('and_intro', indE, ctxE, (basepf, closepf))
    oi = _weaken(omega_induction_pf, ctxE)
    for nm in ['w', E]:
        oi = _forall_elim(oi, nm)
    ai = oi.conclusion.left
    rrI = Proof('and_intro', ai.right, ctxE, (subEpf, indpf))
    allI = Proof('and_intro', ai, ctxE, (_weaken(om, ctxE), rrI))
    eqEw = _imp_elim(oi, allI)
    nt = target.var
    it = target.body
    ctxT = ctxE + (it.left,)
    hde = _assume(it.left, ctxT)
    ndt = _and_l(hde)
    net = _and_r(hde)
    qsub = _forall_elim(_weaken(sub1, ctxT), nt)
    ntW = _imp_elim(qsub, ndt)
    ntE = Proof('eq_subst', Mem(V(nt), V(E)), ctxT, (_weaken(eqEw, ctxT), ntW), (('direction', 'rl'),))
    sepT = _forall_elim(_weaken(hE, ctxT), nt)
    rhsT = _imp_elim(_iff_l(sepT), ntE)
    ag = _and_r(rhsT)
    commonT = _imp_elim(ag, hde)
    ipT = Proof('imp_intro', it, ctxE, (commonT,))
    targetpf = Proof('forall_intro', target, ctxE, (ipT,))
    afterE = Proof('exists_elim', target, ctx0, (sq, targetpf), (('eigenvar', E),))
    imp = Proof('imp_intro', core, (), (afterE,))
    p = imp
    for f in reversed(forms):
        p = Proof('forall_intro', f, (), (p,))
    return p

def _graph_value_domain(fun: Proof, f: str, x: str, y: str, gv: Proof, opinj: Proof, ctx) -> Proof:
    rel, _, _ = _fun_parts(fun, ctx)
    ex = _weaken(gv, tuple(ctx))
    assert isinstance(ex.conclusion, Exists)
    P = 'Pdom_' + f + x + y
    inst = substitute(ex.conclusion.body, ex.conclusion.var, V(P))
    ctxP = tuple(ctx) + (inst,)
    hP = _assume(inst, ctxP)
    Pin = _and_l(hP)
    opPxy = _and_r(hP)
    qr = _forall_elim(_weaken(rel, ctxP), P)
    pairdata = _imp_elim(qr, Pin)
    assert isinstance(pairdata.conclusion, Exists)
    X = 'Xdom_' + f + x + y
    ix = substitute(pairdata.conclusion.body, pairdata.conclusion.var, V(X))
    ctxX = ctxP + (ix,)
    hX = _assume(ix, ctxX)
    Xd = _and_l(hX)
    exY = _and_r(hX)
    assert isinstance(exY.conclusion, Exists)
    Y = 'Ydom_' + f + x + y
    iy = substitute(exY.conclusion.body, exY.conclusion.var, V(Y))
    ctxY = ctxX + (iy,)
    hY = _assume(iy, ctxY)
    opPXY = _and_r(hY)
    inj = _weaken(opinj, ctxY)
    for nm in [P, x, y, X, Y]:
        inj = _forall_elim(inj, nm)
    both = Proof('and_intro', inj.conclusion.left, ctxY, (_weaken(opPxy, ctxY), opPXY))
    eqs = _imp_elim(inj, both)
    eqxX = _and_l(eqs)
    target = Mem(V(x), hX.conclusion.left.right)
    xd = Proof('eq_subst', target, ctxY, (eqxX, _weaken(Xd, ctxY)), (('direction', 'rl'),))
    afterY = Proof('exists_elim', target, ctxX, (exY, xd), (('eigenvar', Y),))
    afterX = Proof('exists_elim', target, ctxP, (pairdata, afterY), (('eigenvar', X),))
    return Proof('exists_elim', target, tuple(ctx), (ex, afterX), (('eigenvar', P),))

def HistoryPairPredicate(p: Term, w: Term, c: Term, a: Term, g: Term) -> Formula:
    return Exists('dHP', Exists('hHP', And(FiniteHistorySpec(V('hHP'), V('dHP'), w, c, a, g), Mem(p, V('hHP')))))
GLOBAL_HISTORY_PAIR_SEPARATION_SCHEMA = SchemaInstance('SEPARATION', HistoryPairPredicate(V('p'), V('w'), V('c'), V('a'), V('g')), source_var='p', parameters=('w', 'c', 'a', 'g'))
PASS008_SCHEMA_INSTANCES = tuple(PASS007_SCHEMA_INSTANCES) + (REACH_SEPARATION_SCHEMA, HISTORY_AGREEMENT_SEPARATION_SCHEMA, GLOBAL_HISTORY_PAIR_SEPARATION_SCHEMA)

def _lift_history_value_to_global(sepF: Proof, cart: Proof, hist: Proof, H: str, D: str, F: str, n: str, y: str, nW: Proof, yC: Proof, gvH: Proof, ctx) -> Proof:
    """A graph value occurring in a finite history is a graph value of the separated global graph."""
    ex = _weaken(gvH, tuple(ctx))
    assert isinstance(ex.conclusion, Exists)
    P = 'Pglob_' + n + y
    iP = substitute(ex.conclusion.body, ex.conclusion.var, V(P))
    ctxP = tuple(ctx) + (iP,)
    hP = _assume(iP, ctxP)
    PinH = _and_l(hP)
    opP = _and_r(hP)
    cq = _forall_elim(_weaken(cart, ctxP), P)
    pred = cq.conclusion.right
    ix = substitute(pred.body, pred.var, V(n))
    ey = ix.right
    iy = substitute(ey.body, ey.var, V(y))
    cy = Proof('and_intro', iy, ctxP, (_weaken(yC, ctxP), opP))
    exy = Proof('exists_intro', ey, ctxP, (cy,), (('term', {'var': y}),))
    cx = Proof('and_intro', ix, ctxP, (_weaken(nW, ctxP), exy))
    ep = Proof('exists_intro', pred, ctxP, (cx,), (('term', {'var': n}),))
    PinC = _imp_elim(_iff_r(cq), ep)
    hp = HistoryPairPredicate(V(P), V('w'), V('c'), V('a'), V('g'))
    hd = substitute(hp.body, hp.var, V(D))
    hh = substitute(hd.body, hd.var, V(H))
    bh = Proof('and_intro', hh, ctxP, (_weaken(hist, ctxP), PinH))
    eh = Proof('exists_intro', hd, ctxP, (bh,), (('term', {'var': H}),))
    ed = Proof('exists_intro', hp, ctxP, (eh,), (('term', {'var': D}),))
    sf = _forall_elim(_weaken(sepF, ctxP), P)
    rhs = Proof('and_intro', sf.conclusion.right, ctxP, (PinC, ed))
    PinF = _imp_elim(_iff_r(sf), rhs)
    out = GraphValueSpec(V(F), V(n), V(y), 'qG')
    ob = substitute(out.body, out.var, V(P))
    cb = Proof('and_intro', ob, ctxP, (PinF, opP))
    eo = Proof('exists_intro', out, ctxP, (cb,), (('term', {'var': P}),))
    return Proof('exists_elim', out, tuple(ctx), (ex, eo), (('eigenvar', P),))

def build_omega_recursion_existence_from_histories(global_schema_index: int=9, reach_pf: Proof | None=None, compat_pf: Proof | None=None, cartesian_pf: Proof | None=None, empty_unique_pf: Proof | None=None, opinj_pf: Proof | None=None, zero_not_succ_pf: Proof | None=None, succinj_pf: Proof | None=None) -> Proof:
    from .recursion_library import omega_recursion_existence_formula, RecursionCandidateSpec, CommonAtSpec
    from .mathematics_library import build_cartesian_product_exists
    from .derived_library import build_empty_unique
    reach_pf = reach_pf or build_omega_history_reach()
    compat_pf = compat_pf or build_finite_history_compatibility()
    cartesian_pf = cartesian_pf or build_cartesian_product_exists(1)
    empty_unique_pf = empty_unique_pf or build_empty_unique()
    opinj_pf = opinj_pf or build_ordered_pair_injective()
    zero_not_succ_pf = zero_not_succ_pf or build_zero_not_successor()
    succinj_pf = succinj_pf or build_successor_injective()
    goal = omega_recursion_existence_formula()
    core = goal.body.body.body.body
    base = core.left
    target = core.right
    ctx0 = (base,)
    hb = _assume(base, ctx0)
    om = _and_l(hb)
    rr = _and_r(hb)
    ac = _and_l(rr)
    gfun = _and_r(rr)
    cp = _weaken(cartesian_pf, ctx0)
    cp = _forall_elim(_forall_elim(cp, 'w'), 'c')
    assert isinstance(cp.conclusion, Exists)
    C = 'WHC'
    iC = substitute(cp.conclusion.body, cp.conclusion.var, V(C))
    ctxC = ctx0 + (iC,)
    hC = _assume(iC, ctxC)
    sep = Proof('axiom_schema', GLOBAL_HISTORY_PAIR_SEPARATION_SCHEMA.generated(), ctxC, (), (('schema_index', global_schema_index),))
    sf = sep
    for nm in ['w', 'c', 'a', 'g', C]:
        sf = _forall_elim(sf, nm)
    assert isinstance(sf.conclusion, Exists)
    F = 'Fomega'
    iF = substitute(sf.conclusion.body, sf.conclusion.var, V(F))
    ctxF = ctxC + (iF,)
    hSep = _assume(iF, ctxF)
    fun = FunctionGraphSpec(V(F), V('w'), V('c'), 'pF', 'xF', 'yF', 'yF2')
    rel = fun.left
    p = rel.var
    ir = rel.body
    ctxP = ctxF + (ir.left,)
    hpF = _assume(ir.left, ctxP)
    sepP = _forall_elim(_weaken(hSep, ctxP), p)
    rhsP = _imp_elim(_iff_l(sepP), hpF)
    PinC = _and_l(rhsP)
    cartP = _forall_elim(_weaken(hC, ctxP), p)
    cartPred = _imp_elim(_iff_l(cartP), PinC)
    rip = Proof('imp_intro', ir, ctxF, (cartPred,))
    relpf = Proof('forall_intro', rel, ctxF, (rip,))
    total = fun.right.left
    n = total.var
    it = total.body
    ctxN = ctxF + (it.left,)
    nW = _assume(it.left, ctxN)
    rp = _weaken(reach_pf, ctxN)
    for nm in ['w', 'c', 'a', 'g']:
        rp = _forall_elim(rp, nm)
    rbase = rp.conclusion.left
    rb = Proof('and_intro', rbase, ctxN, (_weaken(om, ctxN), Proof('and_intro', rbase.right, ctxN, (_weaken(ac, ctxN), _weaken(gfun, ctxN))))) if False else _weaken(hb, ctxN)
    rall = _imp_elim(rp, rb)
    rn = _forall_elim(rall, n)
    reachN = _imp_elim(rn, nW)
    assert isinstance(reachN.conclusion, Exists)
    D = 'Dtot'
    iD = substitute(reachN.conclusion.body, reachN.conclusion.var, V(D))
    ctxD = ctxN + (iD,)
    hDpack = _assume(iD, ctxD)
    exH = hDpack
    assert isinstance(exH.conclusion, Exists)
    H = 'Htot'
    iH = substitute(exH.conclusion.body, exH.conclusion.var, V(H))
    ctxH = ctxD + (iH,)
    hh = _assume(iH, ctxH)
    hist = _and_l(hh)
    nD = _and_r(hh)
    _, hfun, _, _, _ = _history_parts(hist, ctxH)
    exy = _function_total(hfun, n, nD, ctxH)
    assert isinstance(exy.conclusion, Exists)
    Y = 'Ytot'
    iY = substitute(exy.conclusion.body, exy.conclusion.var, V(Y))
    ctxY = ctxH + (iY,)
    hy = _assume(iY, ctxY)
    Yc = _and_l(hy)
    gvH = _and_r(hy)
    gvF = _lift_history_value_to_global(_weaken(hSep, ctxY), _weaken(hC, ctxY), _weaken(hist, ctxY), H, D, F, n, Y, _weaken(nW, ctxY), Yc, gvH, ctxY)
    outY = it.right
    oy = substitute(outY.body, outY.var, V(Y))
    cy = Proof('and_intro', oy, ctxY, (Yc, gvF))
    eY = Proof('exists_intro', outY, ctxY, (cy,), (('term', {'var': Y}),))
    aY = Proof('exists_elim', outY, ctxH, (exy, eY), (('eigenvar', Y),))
    aH = Proof('exists_elim', outY, ctxD, (exH, aY), (('eigenvar', H),))
    aD = Proof('exists_elim', outY, ctxN, (reachN, aH), (('eigenvar', D),))
    ti = Proof('imp_intro', it, ctxF, (aD,))
    totalpf = Proof('forall_intro', total, ctxF, (ti,))
    unique = fun.right.right
    xn = unique.var
    yy = unique.body.var
    yy2 = unique.body.body.var
    iu = unique.body.body.body
    ctxU = ctxF + (iu.left,)
    hu = _assume(iu.left, ctxU)
    L = _and_l(hu)
    R = _and_r(hu)
    xW = _and_l(L)
    yC = _and_r(L)
    y2C = _and_l(R)
    pairgv = _and_r(R)
    gvF1 = _and_l(pairgv)
    gvF2 = _and_r(pairgv)
    P1 = 'PG1'
    iP1 = substitute(gvF1.conclusion.body, gvF1.conclusion.var, V(P1))
    ctxP1 = ctxU + (iP1,)
    hP1 = _assume(iP1, ctxP1)
    P1F = _and_l(hP1)
    op1 = _and_r(hP1)
    sep1 = _forall_elim(_weaken(hSep, ctxP1), P1)
    rhs1 = _imp_elim(_iff_l(sep1), P1F)
    hp1 = _and_r(rhs1)
    assert isinstance(hp1.conclusion, Exists)
    D1 = 'DG1'
    iD1 = substitute(hp1.conclusion.body, hp1.conclusion.var, V(D1))
    ctxD1 = ctxP1 + (iD1,)
    hd1 = _assume(iD1, ctxD1)
    exH1 = hd1
    H1 = 'HG1'
    iH1 = substitute(exH1.conclusion.body, exH1.conclusion.var, V(H1))
    ctxH1 = ctxD1 + (iH1,)
    hh1 = _assume(iH1, ctxH1)
    hist1 = _and_l(hh1)
    P1H = _and_r(hh1)
    gvH1Body = GraphValueSpec(V(H1), V(xn), V(yy), 'qhv1')
    b1 = substitute(gvH1Body.body, gvH1Body.var, V(P1))
    cb1 = Proof('and_intro', b1, ctxH1, (P1H, _weaken(op1, ctxH1)))
    gvH1 = Proof('exists_intro', gvH1Body, ctxH1, (cb1,), (('term', {'var': P1}),))
    _, hfun1, _, _, _ = _history_parts(hist1, ctxH1)
    xD1 = _graph_value_domain(hfun1, H1, xn, yy, gvH1, _weaken(opinj_pf, ctxH1), ctxH1)
    gvF2w = _weaken(gvF2, ctxH1)
    P2 = 'PG2'
    iP2 = substitute(gvF2w.conclusion.body, gvF2w.conclusion.var, V(P2))
    ctxP2 = ctxH1 + (iP2,)
    hP2 = _assume(iP2, ctxP2)
    P2F = _and_l(hP2)
    op2 = _and_r(hP2)
    sep2 = _forall_elim(_weaken(hSep, ctxP2), P2)
    rhs2 = _imp_elim(_iff_l(sep2), P2F)
    hp2 = _and_r(rhs2)
    assert isinstance(hp2.conclusion, Exists)
    D2 = 'DG2'
    iD2 = substitute(hp2.conclusion.body, hp2.conclusion.var, V(D2))
    ctxD2 = ctxP2 + (iD2,)
    hd2 = _assume(iD2, ctxD2)
    exH2 = hd2
    H2 = 'HG2'
    iH2 = substitute(exH2.conclusion.body, exH2.conclusion.var, V(H2))
    ctxH2 = ctxD2 + (iH2,)
    hh2 = _assume(iH2, ctxH2)
    hist2 = _and_l(hh2)
    P2H = _and_r(hh2)
    gvH2Body = GraphValueSpec(V(H2), V(xn), V(yy2), 'qhv2')
    b2 = substitute(gvH2Body.body, gvH2Body.var, V(P2))
    cb2 = Proof('and_intro', b2, ctxH2, (P2H, _weaken(op2, ctxH2)))
    gvH2 = Proof('exists_intro', gvH2Body, ctxH2, (cb2,), (('term', {'var': P2}),))
    _, hfun2, _, _, _ = _history_parts(hist2, ctxH2)
    xD2 = _graph_value_domain(hfun2, H2, xn, yy2, gvH2, _weaken(opinj_pf, ctxH2), ctxH2)
    comp = _weaken(compat_pf, ctxH2)
    for nm in ['w', 'c', 'a', 'g', H1, D1, H2, D2]:
        comp = _forall_elim(comp, nm)
    cprem = comp.conclusion.left
    cprempf = _pack_ands(cprem, [_weaken(om, ctxH2), _weaken(ac, ctxH2), _weaken(hist1, ctxH2), hist2], ctxH2)
    call = _imp_elim(comp, cprempf)
    cn = _forall_elim(call, xn)
    bothD = Proof('and_intro', cn.conclusion.left, ctxH2, (_weaken(xD1, ctxH2), xD2))
    common = _imp_elim(cn, bothD)
    assert isinstance(common.conclusion, Exists)
    Z = 'ZG'
    iZ = substitute(common.conclusion.body, common.conclusion.var, V(Z))
    ctxZ = ctxH2 + (iZ,)
    hz = _assume(iZ, ctxZ)
    Zc = _and_l(hz)
    vals = _and_r(hz)
    gvH1Z = _and_l(vals)
    gvH2Z = _and_r(vals)
    eqyZ = _function_unique(_weaken(hfun1, ctxZ), xn, yy, Z, _weaken(xD1, ctxZ), _weaken(yC, ctxZ), Zc, _weaken(gvH1, ctxZ), gvH1Z, ctxZ)
    eqy2Z = _function_unique(_weaken(hfun2, ctxZ), xn, yy2, Z, _weaken(xD2, ctxZ), _weaken(y2C, ctxZ), Zc, _weaken(gvH2, ctxZ), gvH2Z, ctxZ)
    eqZy2 = Proof('eq_symm', Eq(V(Z), V(yy2)), ctxZ, (eqy2Z,))
    eqyy2 = Proof('eq_trans', Eq(V(yy), V(yy2)), ctxZ, (eqyZ, eqZy2))
    aZ = Proof('exists_elim', Eq(V(yy), V(yy2)), ctxH2, (common, eqyy2), (('eigenvar', Z),))
    aH2 = Proof('exists_elim', Eq(V(yy), V(yy2)), ctxD2, (exH2, aZ), (('eigenvar', H2),))
    aD2 = Proof('exists_elim', Eq(V(yy), V(yy2)), ctxP2, (hp2, aH2), (('eigenvar', D2),))
    aP2 = Proof('exists_elim', Eq(V(yy), V(yy2)), ctxH1, (gvF2w, aD2), (('eigenvar', P2),))
    aH1 = Proof('exists_elim', Eq(V(yy), V(yy2)), ctxD1, (exH1, aP2), (('eigenvar', H1),))
    aD1 = Proof('exists_elim', Eq(V(yy), V(yy2)), ctxP1, (hp1, aH1), (('eigenvar', D1),))
    aP1 = Proof('exists_elim', Eq(V(yy), V(yy2)), ctxU, (gvF1, aD1), (('eigenvar', P1),))
    ui = Proof('imp_intro', iu, ctxF, (aP1,))
    qy2 = Proof('forall_intro', unique.body.body, ctxF, (ui,))
    qy = Proof('forall_intro', unique.body, ctxF, (qy2,))
    uniquepf = Proof('forall_intro', unique, ctxF, (qy,))
    rest = Proof('and_intro', fun.right, ctxF, (totalpf, uniquepf))
    funpf = Proof('and_intro', fun, ctxF, (relpf, rest))
    rec = RecursionCandidateSpec(V(F), V('w'), V('c'), V('a'), V('g'), 'zR', 'nR', 'sR', 'xR', 'yR')
    initial = rec.right.left
    z = initial.var
    ii = initial.body
    ctxI = ctxF + (ii.left,)
    emptyz = _assume(ii.left, ctxI)
    ex0 = _and_l(_and_l(_weaken(om, ctxI)))
    assert isinstance(ex0.conclusion, Exists)
    E0 = 'Eomega0'
    iE0 = substitute(ex0.conclusion.body, ex0.conclusion.var, V(E0))
    ctxE0 = ctxI + (iE0,)
    hE0 = _assume(iE0, ctxE0)
    E0w = _and_l(hE0)
    empE0 = _and_r(hE0)
    eu = _weaken(empty_unique_pf, ctxE0)
    for nm in [z, E0]:
        eu = _forall_elim(eu, nm)
    eqzE = _imp_elim(eu, Proof('and_intro', eu.conclusion.left, ctxE0, (_weaken(emptyz, ctxE0), empE0)))
    zW = Proof('eq_subst', Mem(V(z), V('w')), ctxE0, (eqzE, E0w), (('direction', 'rl'),))
    rp = _weaken(reach_pf, ctxE0)
    for nm in ['w', 'c', 'a', 'g']:
        rp = _forall_elim(rp, nm)
    rall = _imp_elim(rp, _weaken(hb, ctxE0))
    rz = _forall_elim(rall, z)
    reachz = _imp_elim(rz, zW)
    DI = 'DI'
    iDI = substitute(reachz.conclusion.body, reachz.conclusion.var, V(DI))
    ctxDI = ctxE0 + (iDI,)
    hd = _assume(iDI, ctxDI)
    exHI = hd
    HI = 'HI'
    iHI = substitute(exHI.conclusion.body, exHI.conclusion.var, V(HI))
    ctxHI = ctxDI + (iHI,)
    hhI = _assume(iHI, ctxHI)
    histI = _and_l(hhI)
    zDI = _and_r(hhI)
    _, _, _, initH, _ = _history_parts(histI, ctxHI)
    qinit = _forall_elim(initH, z)
    antei = qinit.conclusion.left
    pai = Proof('and_intro', antei, ctxHI, (zDI, _weaken(emptyz, ctxHI)))
    gvHa = _imp_elim(qinit, pai)
    gvFa = _lift_history_value_to_global(_weaken(hSep, ctxHI), _weaken(hC, ctxHI), histI, HI, DI, F, z, 'a', _weaken(zW, ctxHI), _weaken(ac, ctxHI), gvHa, ctxHI)
    aiH = Proof('exists_elim', ii.right, ctxDI, (exHI, gvFa), (('eigenvar', HI),))
    aiD = Proof('exists_elim', ii.right, ctxE0, (reachz, aiH), (('eigenvar', DI),))
    aiE = Proof('exists_elim', ii.right, ctxI, (ex0, aiD), (('eigenvar', E0),))
    iip = Proof('imp_intro', ii, ctxF, (aiE,))
    initpf = Proof('forall_intro', initial, ctxF, (iip,))
    step = rec.right.right
    nn = step.var
    ss = step.body.var
    xx = step.body.body.var
    yyv = step.body.body.body.var
    ist = step.body.body.body.body
    ctxS0 = ctxF + (ist.left,)
    hs0 = _assume(ist.left, ctxS0)
    nW0, sW0, succ0, gvFn, gvG = _unpack_ands(hs0, 5)
    xC = _graph_value_codomain(_weaken(funpf, ctxS0), F, nn, xx, gvFn, _weaken(opinj_pf, ctxS0), ctxS0)
    yC0 = _graph_value_codomain(_weaken(gfun, ctxS0), 'g', xx, yyv, gvG, _weaken(opinj_pf, ctxS0), ctxS0)
    PG = 'PstepG'
    iPG = substitute(gvFn.conclusion.body, gvFn.conclusion.var, V(PG))
    ctxPG = ctxS0 + (iPG,)
    hPG = _assume(iPG, ctxPG)
    PGF = _and_l(hPG)
    opPG = _and_r(hPG)
    sepPG = _forall_elim(_weaken(hSep, ctxPG), PG)
    rhPG = _imp_elim(_iff_l(sepPG), PGF)
    hpHist = _and_r(rhPG)
    DD = 'DstepG'
    iDD = substitute(hpHist.conclusion.body, hpHist.conclusion.var, V(DD))
    ctxDD = ctxPG + (iDD,)
    hDD = _assume(iDD, ctxDD)
    exHH = hDD
    HH = 'HstepG'
    iHH = substitute(exHH.conclusion.body, exHH.conclusion.var, V(HH))
    ctxHH = ctxDD + (iHH,)
    hHH = _assume(iHH, ctxHH)
    histN = _and_l(hHH)
    PGH = _and_r(hHH)
    gvHNbody = GraphValueSpec(V(HH), V(nn), V(xx), 'qsn')
    bHN = substitute(gvHNbody.body, gvHNbody.var, V(PG))
    cbHN = Proof('and_intro', bHN, ctxHH, (PGH, _weaken(opPG, ctxHH)))
    gvHN = Proof('exists_intro', gvHNbody, ctxHH, (cbHN,), (('term', {'var': PG}),))
    _, hfunN, _, _, _ = _history_parts(histN, ctxHH)
    nDD = _graph_value_domain(hfunN, HH, nn, xx, gvHN, _weaken(opinj_pf, ctxHH), ctxHH)
    rp2 = _weaken(reach_pf, ctxHH)
    for nm in ['w', 'c', 'a', 'g']:
        rp2 = _forall_elim(rp2, nm)
    rall2 = _imp_elim(rp2, _weaken(hb, ctxHH))
    rs = _forall_elim(rall2, ss)
    reachS = _imp_elim(rs, _weaken(sW0, ctxHH))
    EE = 'DsuccG'
    iEE = substitute(reachS.conclusion.body, reachS.conclusion.var, V(EE))
    ctxEE = ctxHH + (iEE,)
    hEE = _assume(iEE, ctxEE)
    exKK = hEE
    KK = 'HsuccG'
    iKK = substitute(exKK.conclusion.body, exKK.conclusion.var, V(KK))
    ctxKK = ctxEE + (iKK,)
    hKK = _assume(iKK, ctxKK)
    histS = _and_l(hKK)
    sEE = _and_r(hKK)
    domS, kfun, _, _, kstep = _history_parts(histS, ctxKK)
    _, _, predS = _domain_parts(domS, ctxKK)
    nonemp = _nonempty_from_successor(_weaken(zero_not_succ_pf, ctxKK), _weaken(succ0, ctxKK), ss, nn, ctxKK)
    qp = _forall_elim(predS, ss)
    pa = Proof('and_intro', qp.conclusion.left, ctxKK, (sEE, nonemp))
    exPred = _imp_elim(qp, pa)
    PP = 'PpredG'
    iPP = substitute(exPred.conclusion.body, exPred.conclusion.var, V(PP))
    ctxPP = ctxKK + (iPP,)
    hPP = _assume(iPP, ctxPP)
    PPe = _and_l(hPP)
    succSP = _and_r(hPP)
    sij = _weaken(succinj_pf, ctxPP)
    for nm in [PP, nn, ss]:
        sij = _forall_elim(sij, nm)
    eqPnn = _imp_elim(sij, Proof('and_intro', sij.conclusion.left, ctxPP, (succSP, _weaken(succ0, ctxPP))))
    nnEE = Proof('eq_subst', Mem(V(nn), V(EE)), ctxPP, (eqPnn, PPe), (('direction', 'lr'),))
    comp = _weaken(compat_pf, ctxPP)
    for nm in ['w', 'c', 'a', 'g', HH, DD, KK, EE]:
        comp = _forall_elim(comp, nm)
    cprem = comp.conclusion.left
    cprempf = _pack_ands(cprem, [_weaken(om, ctxPP), _weaken(ac, ctxPP), _weaken(histN, ctxPP), _weaken(histS, ctxPP)], ctxPP)
    caa = _imp_elim(comp, cprempf)
    cnn = _forall_elim(caa, nn)
    bc = Proof('and_intro', cnn.conclusion.left, ctxPP, (_weaken(nDD, ctxPP), nnEE))
    commonN = _imp_elim(cnn, bc)
    ZZ = 'ZstepG'
    iZZ = substitute(commonN.conclusion.body, commonN.conclusion.var, V(ZZ))
    ctxZZ = ctxPP + (iZZ,)
    hZZ = _assume(iZZ, ctxZZ)
    ZZc = _and_l(hZZ)
    vv = _and_r(hZZ)
    gvHNZ = _and_l(vv)
    gvKNZ = _and_r(vv)
    eqxZ = _function_unique(_weaken(hfunN, ctxZZ), nn, xx, ZZ, _weaken(nDD, ctxZZ), _weaken(xC, ctxZZ), ZZc, _weaken(gvHN, ctxZZ), gvHNZ, ctxZZ)
    gZy = Proof('eq_subst', GraphValueSpec(V('g'), V(ZZ), V(yyv), 'qgz'), ctxZZ, (eqxZ, _weaken(gvG, ctxZZ)), (('direction', 'lr'),))
    gvKsy = _apply_rec_step(_weaken(kstep, ctxZZ), nn, ss, ZZ, yyv, _weaken(nnEE, ctxZZ), _weaken(sEE, ctxZZ), _weaken(succ0, ctxZZ), gvKNZ, gZy, ctxZZ)
    gvFsy = _lift_history_value_to_global(_weaken(hSep, ctxZZ), _weaken(hC, ctxZZ), _weaken(histS, ctxZZ), KK, EE, F, ss, yyv, _weaken(sW0, ctxZZ), _weaken(yC0, ctxZZ), gvKsy, ctxZZ)
    aZZ = Proof('exists_elim', ist.right, ctxPP, (commonN, gvFsy), (('eigenvar', ZZ),))
    aPP = Proof('exists_elim', ist.right, ctxKK, (exPred, aZZ), (('eigenvar', PP),))
    aKK = Proof('exists_elim', ist.right, ctxEE, (exKK, aPP), (('eigenvar', KK),))
    aEE = Proof('exists_elim', ist.right, ctxHH, (reachS, aKK), (('eigenvar', EE),))
    aHH = Proof('exists_elim', ist.right, ctxDD, (exHH, aEE), (('eigenvar', HH),))
    aDD = Proof('exists_elim', ist.right, ctxPG, (hpHist, aHH), (('eigenvar', DD),))
    aPG = Proof('exists_elim', ist.right, ctxS0, (gvFn, aDD), (('eigenvar', PG),))
    isp = Proof('imp_intro', ist, ctxF, (aPG,))
    qyv = Proof('forall_intro', step.body.body.body, ctxF, (isp,))
    qxv = Proof('forall_intro', step.body.body, ctxF, (qyv,))
    qsv = Proof('forall_intro', step.body, ctxF, (qxv,))
    steppf = Proof('forall_intro', step, ctxF, (qsv,))
    recRest = Proof('and_intro', rec.right, ctxF, (initpf, steppf))
    recpf = Proof('and_intro', rec, ctxF, (funpf, recRest))
    exrec = Proof('exists_intro', target, ctxF, (recpf,), (('term', {'var': F}),))
    afterF = Proof('exists_elim', target, ctxC, (sf, exrec), (('eigenvar', F),))
    afterC = Proof('exists_elim', target, ctx0, (cp, afterF), (('eigenvar', C),))
    imp = Proof('imp_intro', core, (), (afterC,))
    qg = Proof('forall_intro', goal.body.body.body, (), (imp,))
    qa = Proof('forall_intro', goal.body.body, (), (qg,))
    qc = Proof('forall_intro', goal.body, (), (qa,))
    return Proof('forall_intro', goal, (), (qc,))

def omega_recursion_exists_unique_formula() -> Formula:
    """Full general recursion theorem on omega, existence plus uniqueness."""
    from .recursion_library import RecursionCandidateSpec
    w, c, a, g = map(V, ['w', 'c', 'a', 'g'])
    base = And(OmegaSpec(w, 'j', 'k'), And(Mem(a, c), FunctionGraphSpec(g, c, c, 'pg', 'xg', 'yg', 'yg2')))
    cand = RecursionCandidateSpec(V('f'), w, c, a, g, 'zf', 'nf', 'sf', 'xf', 'yf')
    unique = Forall('h', Imp(RecursionCandidateSpec(V('h'), w, c, a, g, 'zh', 'nh', 'sh', 'xh', 'yh'), Eq(V('h'), V('f'))))
    return Forall('w', Forall('c', Forall('a', Forall('g', Imp(base, Exists('f', And(cand, unique)))))))

def build_omega_recursion_exists_unique(existence_pf: Proof | None=None, unique_if_exists_pf: Proof | None=None) -> Proof:
    """Compose general existence with the already-certified uniqueness theorem."""
    from .recursion_library import build_omega_recursion_unique_if_exists
    existence_pf = existence_pf or build_omega_recursion_existence_from_histories()
    unique_if_exists_pf = unique_if_exists_pf or build_omega_recursion_unique_if_exists()
    goal = omega_recursion_exists_unique_formula()
    core = goal.body.body.body.body
    base = core.left
    target = core.right
    ctx = (base,)
    hb = _assume(base, ctx)
    ex = _weaken(existence_pf, ctx)
    for nm in ['w', 'c', 'a', 'g']:
        ex = _forall_elim(ex, nm)
    ex = _imp_elim(ex, hb)
    ui = _weaken(unique_if_exists_pf, ctx)
    for nm in ['w', 'c', 'a', 'g']:
        ui = _forall_elim(ui, nm)
    ui = _imp_elim(ui, hb)
    out = _imp_elim(ui, ex)
    if not equivalent(out.conclusion, target):
        raise ValueError('PASS008_EXISTS_UNIQUE_TARGET_MISMATCH')
    ip = Proof('imp_intro', core, (), (out,))
    qg = Proof('forall_intro', goal.body.body.body, (), (ip,))
    qa = Proof('forall_intro', goal.body.body, (), (qg,))
    qc = Proof('forall_intro', goal.body, (), (qa,))
    return Proof('forall_intro', goal, (), (qc,))

def build_pass008_library(schema_prefix: tuple[SchemaInstance, ...]=()) -> tuple[CertifiedStatement, ...]:
    """PASS008 cumulative library: finite histories + full general omega recursion."""
    offset = len(schema_prefix)
    schemas = tuple(schema_prefix) + PASS008_SCHEMA_INSTANCES
    k = ZFCKernel(schemas)
    base = list(PASS007_FULL_LIBRARY if not schema_prefix else build_pass007_library(schema_prefix))
    ext = build_finite_history_extension()
    zero = build_finite_history_zero_reach()
    reach = build_omega_history_reach(offset + 7, extension_pf=ext, zero_reach_pf=zero)
    compat = build_finite_history_compatibility(offset + 8)
    rex = build_omega_recursion_existence_from_histories(offset + 9, reach_pf=reach, compat_pf=compat)
    req = build_omega_recursion_exists_unique(rex)
    extras = [('ZFC_FINITE_HISTORY_EXTENSION', 'lemma', ext), ('ZFC_FINITE_HISTORY_ZERO_REACH', 'lemma', zero), ('ZFC_OMEGA_FINITE_HISTORY_REACH', 'theorem', reach), ('ZFC_FINITE_HISTORY_COMPATIBILITY', 'theorem', compat), ('ZFC_GENERAL_OMEGA_RECURSION_EXISTS', 'theorem', rex), ('ZFC_GENERAL_OMEGA_RECURSION_EXISTS_UNIQUE', 'corollary', req)]
    for name, kind, p in extras:
        kr = k.verify(p)
        if not kr.ok:
            raise ValueError(f'PASS008_KERNEL_REJECT:{name}:{kr.detail}')
        base.append(CertifiedStatement(p, name=name, kind=kind, source='PASS008_FINITE_HISTORY_RECURSION'))
    return tuple(base)

def _preverified_pass008(records):
    return tuple((NormalizedLibraryEntry(r.proof, r.identity, (r.name,) if r.name else (), (str(r.kind),) if r.kind else ()) for r in records))
