from __future__ import annotations
from .logic import *

def _fresh_local(base: str, avoid: set[str]) -> str:
    if base not in avoid:
        return base
    i = 0
    while f'{base}_{i}' in avoid:
        i += 1
    return f'{base}_{i}'

def EmptySpec(e: Term, z: str='z') -> Formula:
    z = _fresh_local(z, {e.name})
    return Forall(z, Not(Mem(V(z), e)))

def SingletonSpec(s: Term, x: Term, w: str='w') -> Formula:
    w = _fresh_local(w, {s.name, x.name})
    return Forall(w, Iff(Mem(V(w), s), Eq(V(w), x)))

def PairSpec(p: Term, x: Term, y: Term, w: str='w') -> Formula:
    w = _fresh_local(w, {p.name, x.name, y.name})
    return Forall(w, Iff(Mem(V(w), p), Or(Eq(V(w), x), Eq(V(w), y))))

def SubsetSpec(a: Term, b: Term, z: str='z') -> Formula:
    z = _fresh_local(z, {a.name, b.name})
    return Forall(z, Imp(Mem(V(z), a), Mem(V(z), b)))

def UnionSpec(u: Term, a: Term, z: str='z', w: str='w') -> Formula:
    z = _fresh_local(z, {u.name, a.name})
    w = _fresh_local(w, {u.name, a.name, z})
    return Forall(z, Iff(Mem(V(z), u), Exists(w, And(Mem(V(z), V(w)), Mem(V(w), a)))))

def PowerSetSpec(p: Term, a: Term, z: str='z', w: str='w') -> Formula:
    z = _fresh_local(z, {p.name, a.name})
    w = _fresh_local(w, {p.name, a.name, z})
    return Forall(z, Iff(Mem(V(z), p), Forall(w, Imp(Mem(V(w), V(z)), Mem(V(w), a)))))

def SuccessorSpec(s: Term, x: Term, z: str='z') -> Formula:
    z = _fresh_local(z, {s.name, x.name})
    return Forall(z, Iff(Mem(V(z), s), Or(Mem(V(z), x), Eq(V(z), x))))

def OrderedPairCode(p: Term, x: Term, y: Term, a: str='a', b: str='b') -> Formula:
    avoid = {p.name, x.name, y.name}
    a = _fresh_local(a, avoid)
    avoid.add(a)
    b = _fresh_local(b, avoid)
    avoid.add(b)
    u = _fresh_local('u', avoid | {a})
    avoid.add(u)
    v = _fresh_local('v', avoid | {b})
    avoid.add(v)
    q = _fresh_local('q', avoid | {p.name, a, b})
    return Exists(a, Exists(b, And(SingletonSpec(V(a), x, u), And(PairSpec(V(b), x, y, v), PairSpec(p, V(a), V(b), q)))))

def RelationGraphSpec(r: Term, dom: Term, cod: Term, p: str='p', x: str='x', y: str='y') -> Formula:
    avoid = {r.name, dom.name, cod.name}
    p = _fresh_local(p, avoid)
    avoid.add(p)
    x = _fresh_local(x, avoid)
    avoid.add(x)
    y = _fresh_local(y, avoid)
    avoid.add(y)
    return Forall(p, Imp(Mem(V(p), r), Exists(x, And(Mem(V(x), dom), Exists(y, And(Mem(V(y), cod), OrderedPairCode(V(p), V(x), V(y), 'a', 'b')))))))

def FunctionGraphSpec(f: Term, dom: Term, cod: Term, p: str='p', x: str='x', y: str='y', y2: str='y2') -> Formula:
    avoid = {f.name, dom.name, cod.name}
    p = _fresh_local(p, avoid)
    avoid.add(p)
    x = _fresh_local(x, avoid)
    avoid.add(x)
    y = _fresh_local(y, avoid)
    avoid.add(y)
    y2 = _fresh_local(y2, avoid)
    avoid.add(y2)
    rel = RelationGraphSpec(f, dom, cod, p, x, y)
    total = Forall(x, Imp(Mem(V(x), dom), Exists(y, And(Mem(V(y), cod), Exists(p, And(Mem(V(p), f), OrderedPairCode(V(p), V(x), V(y), 'a', 'b')))))))
    p2 = _fresh_local('p2', avoid | {p, x, y, y2})
    unique = Forall(x, Forall(y, Forall(y2, Imp(And(And(Mem(V(x), dom), Mem(V(y), cod)), And(Mem(V(y2), cod), And(Exists(p, And(Mem(V(p), f), OrderedPairCode(V(p), V(x), V(y), 'a', 'b'))), Exists(p2, And(Mem(V(p2), f), OrderedPairCode(V(p2), V(x), V(y2), 'c', 'd')))))), Eq(V(y), V(y2))))))
    return And(rel, And(total, unique))

def InductiveSetSpec(i: Term, e: str='e', y: str='y', s: str='s', z: str='z') -> Formula:
    avoid = {i.name}
    e = _fresh_local(e, avoid)
    avoid.add(e)
    y = _fresh_local(y, avoid)
    avoid.add(y)
    s = _fresh_local(s, avoid)
    avoid.add(s)
    z = _fresh_local(z, avoid)
    empty_member = Exists(e, And(Mem(V(e), i), EmptySpec(V(e), z)))
    closed = Forall(y, Imp(Mem(V(y), i), Exists(s, And(Mem(V(s), i), SuccessorSpec(V(s), V(y), z)))))
    return And(empty_member, closed)
