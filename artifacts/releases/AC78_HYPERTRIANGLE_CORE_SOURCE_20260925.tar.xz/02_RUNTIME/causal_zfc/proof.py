from __future__ import annotations
from dataclasses import dataclass
from typing import Any
import hashlib, json
from .logic import *

@dataclass(frozen=True)
class Proof:
    rule: str
    conclusion: Formula
    context: tuple[Formula, ...] = ()
    premises: tuple['Proof', ...] = ()
    data: tuple[tuple[str, Any], ...] = ()

    def d(self) -> dict[str, Any]:
        return dict(self.data)

    def to_obj(self) -> dict[str, Any]:
        return {'rule': self.rule, 'conclusion': formula_to_obj(self.conclusion), 'context': [formula_to_obj(x) for x in self.context], 'premises': [p.to_obj() for p in self.premises], 'data': {k: formula_to_obj(v) if isinstance(v, Formula) else v.to_obj() if isinstance(v, Term) else v for k, v in self.data}}

def proof_digest(p: Proof) -> str:
    raw = json.dumps(p.to_obj(), sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()
    return hashlib.sha256(raw).hexdigest()

def ctx_add(ctx: tuple[Formula, ...], f: Formula) -> tuple[Formula, ...]:
    return ctx + (f,)

def ctx_equiv(a: tuple[Formula, ...], b: tuple[Formula, ...]) -> bool:
    if len(a) != len(b):
        return False
    used = [False] * len(b)
    for x in a:
        ok = False
        for i, y in enumerate(b):
            if not used[i] and equivalent(x, y):
                used[i] = True
                ok = True
                break
        if not ok:
            return False
    return True

def ctx_subset_equiv(a: tuple[Formula, ...], b: tuple[Formula, ...]) -> bool:
    """Multiset inclusion a <= b modulo alpha-equivalence."""
    if len(a) > len(b):
        return False
    used = [False] * len(b)
    for x in a:
        ok = False
        for i, y in enumerate(b):
            if not used[i] and equivalent(x, y):
                used[i] = True
                ok = True
                break
        if not ok:
            return False
    return True

def proof_from_obj(o: dict[str, Any]) -> Proof:
    if not isinstance(o, dict):
        raise ValueError('proof must be object')
    allowed = {'rule', 'conclusion', 'context', 'premises', 'data'}
    if set(o) != allowed:
        raise ValueError('proof object fields mismatch')
    if not isinstance(o['rule'], str) or not isinstance(o['context'], list) or (not isinstance(o['premises'], list)) or (not isinstance(o['data'], dict)):
        raise ValueError('proof object field types')
    concl = formula_from_obj(o['conclusion'])
    ctx = tuple((formula_from_obj(x) for x in o['context']))
    prems = tuple((proof_from_obj(x) for x in o['premises']))
    data = tuple(sorted(o['data'].items(), key=lambda kv: kv[0]))
    return Proof(o['rule'], concl, ctx, prems, data)
