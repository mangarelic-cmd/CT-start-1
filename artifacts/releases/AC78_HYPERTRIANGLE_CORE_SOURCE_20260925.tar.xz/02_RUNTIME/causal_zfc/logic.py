from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Iterable
import hashlib, json

@dataclass(frozen=True)
class Term:
    name: str

    def to_obj(self):
        return {'var': self.name}

class Formula:
    pass

@dataclass(frozen=True)
class Prop(Formula):
    name: str

@dataclass(frozen=True)
class Bottom(Formula):
    pass

@dataclass(frozen=True)
class Eq(Formula):
    left: Term
    right: Term

@dataclass(frozen=True)
class Mem(Formula):
    left: Term
    right: Term

@dataclass(frozen=True)
class Imp(Formula):
    left: Formula
    right: Formula

@dataclass(frozen=True)
class And(Formula):
    left: Formula
    right: Formula

@dataclass(frozen=True)
class Or(Formula):
    left: Formula
    right: Formula

@dataclass(frozen=True)
class Iff(Formula):
    left: Formula
    right: Formula

@dataclass(frozen=True)
class Forall(Formula):
    var: str
    body: Formula

@dataclass(frozen=True)
class Exists(Formula):
    var: str
    body: Formula
FALSE = Bottom()

def Not(f: Formula) -> Formula:
    return Imp(f, FALSE)

def V(name: str) -> Term:
    return Term(name)

def formula_to_obj(f: Formula) -> Any:
    if isinstance(f, Prop):
        return {'prop': f.name}
    if isinstance(f, Bottom):
        return {'bottom': True}
    if isinstance(f, Eq):
        return {'eq': [f.left.to_obj(), f.right.to_obj()]}
    if isinstance(f, Mem):
        return {'mem': [f.left.to_obj(), f.right.to_obj()]}
    if isinstance(f, Imp):
        return {'imp': [formula_to_obj(f.left), formula_to_obj(f.right)]}
    if isinstance(f, And):
        return {'and': [formula_to_obj(f.left), formula_to_obj(f.right)]}
    if isinstance(f, Or):
        return {'or': [formula_to_obj(f.left), formula_to_obj(f.right)]}
    if isinstance(f, Iff):
        return {'iff': [formula_to_obj(f.left), formula_to_obj(f.right)]}
    if isinstance(f, Forall):
        return {'forall': [f.var, formula_to_obj(f.body)]}
    if isinstance(f, Exists):
        return {'exists': [f.var, formula_to_obj(f.body)]}
    raise TypeError(type(f))

def term_from_obj(o: Any) -> Term:
    if isinstance(o, dict) and set(o) == {'var'} and isinstance(o['var'], str):
        return Term(o['var'])
    raise ValueError(f'bad term: {o!r}')

def formula_from_obj(o: Any) -> Formula:
    if not isinstance(o, dict) or len(o) != 1:
        raise ValueError(f'bad formula: {o!r}')
    k, v = next(iter(o.items()))
    if k == 'prop' and isinstance(v, str):
        return Prop(v)
    if k == 'bottom' and v is True:
        return Bottom()
    if k in ('eq', 'mem') and isinstance(v, list) and (len(v) == 2):
        a, b = map(term_from_obj, v)
        return Eq(a, b) if k == 'eq' else Mem(a, b)
    if k in ('imp', 'and', 'or', 'iff') and isinstance(v, list) and (len(v) == 2):
        a, b = map(formula_from_obj, v)
        return {'imp': Imp, 'and': And, 'or': Or, 'iff': Iff}[k](a, b)
    if k in ('forall', 'exists') and isinstance(v, list) and (len(v) == 2) and isinstance(v[0], str):
        return (Forall if k == 'forall' else Exists)(v[0], formula_from_obj(v[1]))
    raise ValueError(f'bad formula op: {o!r}')

def free_vars(f: Formula) -> set[str]:
    if isinstance(f, Prop) or isinstance(f, Bottom):
        return set()
    if isinstance(f, (Eq, Mem)):
        return {f.left.name, f.right.name}
    if isinstance(f, (Imp, And, Or, Iff)):
        return free_vars(f.left) | free_vars(f.right)
    if isinstance(f, (Forall, Exists)):
        return free_vars(f.body) - {f.var}
    raise TypeError(type(f))

def all_vars(f: Formula) -> set[str]:
    if isinstance(f, Prop) or isinstance(f, Bottom):
        return set()
    if isinstance(f, (Eq, Mem)):
        return {f.left.name, f.right.name}
    if isinstance(f, (Imp, And, Or, Iff)):
        return all_vars(f.left) | all_vars(f.right)
    if isinstance(f, (Forall, Exists)):
        return {f.var} | all_vars(f.body)
    raise TypeError(type(f))

def _fresh(base: str, avoid: set[str]) -> str:
    if base not in avoid:
        return base
    i = 0
    while f'{base}_{i}' in avoid:
        i += 1
    return f'{base}_{i}'

def rename_bound(f: Formula, old: str, new: str) -> Formula:
    """Rename occurrences bound by the current binder old; nested rebinding of old is respected."""

    def rec(g: Formula, active: bool) -> Formula:
        if isinstance(g, Prop) or isinstance(g, Bottom):
            return g
        if isinstance(g, Eq):
            l = Term(new) if active and g.left.name == old else g.left
            r = Term(new) if active and g.right.name == old else g.right
            return Eq(l, r)
        if isinstance(g, Mem):
            l = Term(new) if active and g.left.name == old else g.left
            r = Term(new) if active and g.right.name == old else g.right
            return Mem(l, r)
        if isinstance(g, (Imp, And, Or, Iff)):
            return type(g)(rec(g.left, active), rec(g.right, active))
        if isinstance(g, (Forall, Exists)):
            if g.var == old:
                return type(g)(g.var, rec(g.body, False))
            return type(g)(g.var, rec(g.body, active))
        raise TypeError(type(g))
    return rec(f, True)

def substitute(f: Formula, var: str, replacement: Term) -> Formula:
    """Capture-avoiding substitution of free occurrences of var by replacement."""
    if isinstance(f, Prop) or isinstance(f, Bottom):
        return f
    if isinstance(f, Eq):
        return Eq(replacement if f.left.name == var else f.left, replacement if f.right.name == var else f.right)
    if isinstance(f, Mem):
        return Mem(replacement if f.left.name == var else f.left, replacement if f.right.name == var else f.right)
    if isinstance(f, (Imp, And, Or, Iff)):
        return type(f)(substitute(f.left, var, replacement), substitute(f.right, var, replacement))
    if isinstance(f, (Forall, Exists)):
        if f.var == var:
            return f
        body = f.body
        qvar = f.var
        if qvar == replacement.name and var in free_vars(body):
            avoid = all_vars(body) | {var, replacement.name}
            new = _fresh(qvar, avoid)
            body = rename_bound(body, qvar, new)
            qvar = new
        return type(f)(qvar, substitute(body, var, replacement))
    raise TypeError(type(f))

def alpha_key(f: Formula) -> Any:

    def term_key(t: Term, env: list[str]):
        for i, name in enumerate(reversed(env)):
            if t.name == name:
                return ['b', i]
        return ['f', t.name]

    def rec(g: Formula, env: list[str]):
        if isinstance(g, Prop):
            return ['prop', g.name]
        if isinstance(g, Bottom):
            return ['bottom']
        if isinstance(g, Eq):
            return ['eq', term_key(g.left, env), term_key(g.right, env)]
        if isinstance(g, Mem):
            return ['mem', term_key(g.left, env), term_key(g.right, env)]
        if isinstance(g, Imp):
            return ['imp', rec(g.left, env), rec(g.right, env)]
        if isinstance(g, And):
            return ['and', rec(g.left, env), rec(g.right, env)]
        if isinstance(g, Or):
            return ['or', rec(g.left, env), rec(g.right, env)]
        if isinstance(g, Iff):
            return ['iff', rec(g.left, env), rec(g.right, env)]
        if isinstance(g, Forall):
            return ['forall', rec(g.body, env + [g.var])]
        if isinstance(g, Exists):
            return ['exists', rec(g.body, env + [g.var])]
        raise TypeError(type(g))
    return rec(f, [])

def equivalent(a: Formula, b: Formula) -> bool:
    return alpha_key(a) == alpha_key(b)

def digest_formula(f: Formula) -> str:
    raw = json.dumps(alpha_key(f), sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()
    return hashlib.sha256(raw).hexdigest()

def pretty(f: Formula) -> str:
    if isinstance(f, Prop):
        return f.name
    if isinstance(f, Bottom):
        return '⊥'
    if isinstance(f, Eq):
        return f'{f.left.name}={f.right.name}'
    if isinstance(f, Mem):
        return f'{f.left.name}∈{f.right.name}'
    if isinstance(f, Imp):
        return f'({pretty(f.left)}→{pretty(f.right)})'
    if isinstance(f, And):
        return f'({pretty(f.left)}∧{pretty(f.right)})'
    if isinstance(f, Or):
        return f'({pretty(f.left)}∨{pretty(f.right)})'
    if isinstance(f, Iff):
        return f'({pretty(f.left)}↔{pretty(f.right)})'
    if isinstance(f, Forall):
        return f'∀{f.var}.{pretty(f.body)}'
    if isinstance(f, Exists):
        return f'∃{f.var}.{pretty(f.body)}'
    raise TypeError(type(f))
