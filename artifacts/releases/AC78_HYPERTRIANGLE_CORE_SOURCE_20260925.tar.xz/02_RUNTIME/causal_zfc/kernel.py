from __future__ import annotations
from dataclasses import dataclass
from .logic import *
from .proof import *
from .axioms import FIXED_AXIOMS, SchemaInstance

@dataclass(frozen=True)
class KernelResult:
    ok: bool
    code: str
    detail: str = ''

class ZFCKernel:
    """Small independent proof checker. It never searches and ignores theorem/lemma/proposition labels."""

    def __init__(self, schema_instances: tuple[SchemaInstance, ...]=()):
        self.schema_instances = schema_instances
        self._schema_formulas = [s.generated() for s in schema_instances]

    def verify(self, p: Proof) -> KernelResult:
        seen = set()
        try:
            self._verify(p, seen)
            return KernelResult(True, 'PASS')
        except ValueError as e:
            return KernelResult(False, 'REJECT', str(e))

    def _verify(self, p: Proof, seen: set[int]):
        oid = id(p)
        if oid in seen:
            raise ValueError('cyclic proof object')
        seen.add(oid)
        try:
            for q in p.premises:
                self._verify(q, seen)
            r = p.rule
            d = p.d()
            if r == 'assumption':
                if not any((equivalent(p.conclusion, x) for x in p.context)):
                    raise ValueError('assumption not in context')
                if p.premises:
                    raise ValueError('assumption has premises')
            elif r == 'axiom_fixed':
                aid = d.get('axiom_id')
                if aid not in FIXED_AXIOMS or not equivalent(p.conclusion, FIXED_AXIOMS[aid]):
                    raise ValueError('invalid fixed axiom')
                if p.premises:
                    raise ValueError('axiom node has premises')
            elif r == 'axiom_schema':
                idx = d.get('schema_index')
                if not isinstance(idx, int) or idx < 0 or idx >= len(self._schema_formulas):
                    raise ValueError('invalid schema index')
                if not equivalent(p.conclusion, self._schema_formulas[idx]):
                    raise ValueError('schema conclusion mismatch')
                if p.premises:
                    raise ValueError('schema axiom has premises')
            elif r == 'weakening':
                if len(p.premises) != 1:
                    raise ValueError('bad weakening arity')
                q = p.premises[0]
                if not equivalent(q.conclusion, p.conclusion):
                    raise ValueError('weakening conclusion mismatch')
                if not ctx_subset_equiv(q.context, p.context):
                    raise ValueError('weakening context not a superset')
            elif r == 'eq_refl':
                if not isinstance(p.conclusion, Eq) or p.conclusion.left != p.conclusion.right:
                    raise ValueError('bad equality reflexivity')
                if p.premises:
                    raise ValueError('eq_refl has premises')
            elif r == 'eq_symm':
                if len(p.premises) != 1 or not isinstance(p.premises[0].conclusion, Eq) or (not isinstance(p.conclusion, Eq)):
                    raise ValueError('bad eq_symm')
                q = p.premises[0]
                if not ctx_equiv(q.context, p.context):
                    raise ValueError('eq_symm context')
                if p.conclusion.left != q.conclusion.right or p.conclusion.right != q.conclusion.left:
                    raise ValueError('eq_symm formula')
            elif r == 'eq_trans':
                if len(p.premises) != 2 or not all((isinstance(q.conclusion, Eq) for q in p.premises)) or (not isinstance(p.conclusion, Eq)):
                    raise ValueError('bad eq_trans')
                a, b = p.premises
                if not ctx_equiv(a.context, p.context) or not ctx_equiv(b.context, p.context):
                    raise ValueError('eq_trans context')
                if a.conclusion.right != b.conclusion.left:
                    raise ValueError('eq_trans middle term')
                if p.conclusion.left != a.conclusion.left or p.conclusion.right != b.conclusion.right:
                    raise ValueError('eq_trans result')
            elif r == 'imp_intro':
                if len(p.premises) != 1 or not isinstance(p.conclusion, Imp):
                    raise ValueError('bad imp_intro arity/type')
                q = p.premises[0]
                expected = ctx_add(p.context, p.conclusion.left)
                if not ctx_equiv(q.context, expected) or not equivalent(q.conclusion, p.conclusion.right):
                    raise ValueError('imp_intro discharge mismatch')
            elif r == 'imp_elim':
                if len(p.premises) != 2:
                    raise ValueError('bad imp_elim arity')
                q1, q2 = p.premises
                if not ctx_equiv(q1.context, p.context) or not ctx_equiv(q2.context, p.context):
                    raise ValueError('imp_elim context mismatch')
                if not isinstance(q1.conclusion, Imp):
                    raise ValueError('imp_elim first premise not implication')
                if not equivalent(q1.conclusion.left, q2.conclusion) or not equivalent(q1.conclusion.right, p.conclusion):
                    raise ValueError('imp_elim formula mismatch')
            elif r == 'and_intro':
                if len(p.premises) != 2 or not isinstance(p.conclusion, And):
                    raise ValueError('bad and_intro')
                a, b = p.premises
                if not ctx_equiv(a.context, p.context) or not ctx_equiv(b.context, p.context):
                    raise ValueError('and_intro context')
                if not equivalent(a.conclusion, p.conclusion.left) or not equivalent(b.conclusion, p.conclusion.right):
                    raise ValueError('and_intro formula')
            elif r in ('and_elim_left', 'and_elim_right'):
                if len(p.premises) != 1:
                    raise ValueError('bad and_elim arity')
                q = p.premises[0]
                if not ctx_equiv(q.context, p.context) or not isinstance(q.conclusion, And):
                    raise ValueError('and_elim premise')
                target = q.conclusion.left if r.endswith('left') else q.conclusion.right
                if not equivalent(p.conclusion, target):
                    raise ValueError('and_elim target')
            elif r in ('or_intro_left', 'or_intro_right'):
                if len(p.premises) != 1 or not isinstance(p.conclusion, Or):
                    raise ValueError('bad or_intro')
                q = p.premises[0]
                if not ctx_equiv(q.context, p.context):
                    raise ValueError('or_intro context')
                target = p.conclusion.left if r.endswith('left') else p.conclusion.right
                if not equivalent(q.conclusion, target):
                    raise ValueError('or_intro target')
            elif r == 'or_elim':
                if len(p.premises) != 3:
                    raise ValueError('bad or_elim arity')
                disj, pl, pr = p.premises
                if not isinstance(disj.conclusion, Or) or not ctx_equiv(disj.context, p.context):
                    raise ValueError('or_elim disjunction')
                if not ctx_equiv(pl.context, ctx_add(p.context, disj.conclusion.left)):
                    raise ValueError('or_elim left context')
                if not ctx_equiv(pr.context, ctx_add(p.context, disj.conclusion.right)):
                    raise ValueError('or_elim right context')
                if not equivalent(pl.conclusion, p.conclusion) or not equivalent(pr.conclusion, p.conclusion):
                    raise ValueError('or_elim branch conclusion')
            elif r == 'iff_intro':
                if len(p.premises) != 2 or not isinstance(p.conclusion, Iff):
                    raise ValueError('bad iff_intro')
                a, b = p.premises
                if not ctx_equiv(a.context, p.context) or not ctx_equiv(b.context, p.context):
                    raise ValueError('iff_intro context')
                if not isinstance(a.conclusion, Imp) or not isinstance(b.conclusion, Imp):
                    raise ValueError('iff_intro premises')
                if not equivalent(a.conclusion.left, p.conclusion.left) or not equivalent(a.conclusion.right, p.conclusion.right):
                    raise ValueError('iff_intro forward')
                if not equivalent(b.conclusion.left, p.conclusion.right) or not equivalent(b.conclusion.right, p.conclusion.left):
                    raise ValueError('iff_intro reverse')
            elif r in ('iff_elim_left', 'iff_elim_right'):
                if len(p.premises) != 1:
                    raise ValueError('bad iff_elim arity')
                q = p.premises[0]
                if not ctx_equiv(q.context, p.context) or not isinstance(q.conclusion, Iff) or (not isinstance(p.conclusion, Imp)):
                    raise ValueError('iff_elim premise')
                expected = Imp(q.conclusion.left, q.conclusion.right) if r.endswith('left') else Imp(q.conclusion.right, q.conclusion.left)
                if not equivalent(p.conclusion, expected):
                    raise ValueError('iff_elim target')
            elif r == 'forall_intro':
                if len(p.premises) != 1 or not isinstance(p.conclusion, Forall):
                    raise ValueError('bad forall_intro')
                q = p.premises[0]
                x = p.conclusion.var
                if not ctx_equiv(q.context, p.context) or not equivalent(q.conclusion, p.conclusion.body):
                    raise ValueError('forall_intro premise')
                if any((x in free_vars(h) for h in p.context)):
                    raise ValueError('forall_intro eigenvariable occurs free in context')
            elif r == 'forall_elim':
                if len(p.premises) != 1:
                    raise ValueError('bad forall_elim arity')
                q = p.premises[0]
                t = d.get('term')
                if not isinstance(t, dict) or set(t) != {'var'}:
                    raise ValueError('forall_elim missing term')
                if not ctx_equiv(q.context, p.context) or not isinstance(q.conclusion, Forall):
                    raise ValueError('forall_elim premise')
                expected = substitute(q.conclusion.body, q.conclusion.var, V(t['var']))
                if not equivalent(p.conclusion, expected):
                    raise ValueError('forall_elim substitution mismatch')
            elif r == 'exists_intro':
                if len(p.premises) != 1 or not isinstance(p.conclusion, Exists):
                    raise ValueError('bad exists_intro')
                q = p.premises[0]
                t = d.get('term')
                if not isinstance(t, dict) or set(t) != {'var'}:
                    raise ValueError('exists_intro missing term')
                if not ctx_equiv(q.context, p.context):
                    raise ValueError('exists_intro context')
                expected = substitute(p.conclusion.body, p.conclusion.var, V(t['var']))
                if not equivalent(q.conclusion, expected):
                    raise ValueError('exists_intro witness mismatch')
            elif r == 'exists_elim':
                if len(p.premises) != 2:
                    raise ValueError('bad exists_elim arity')
                ex, branch = p.premises
                eigen = d.get('eigenvar')
                if not isinstance(ex.conclusion, Exists) or not isinstance(eigen, str):
                    raise ValueError('exists_elim premise/eigenvar')
                if not ctx_equiv(ex.context, p.context):
                    raise ValueError('exists_elim existential context')
                inst = substitute(ex.conclusion.body, ex.conclusion.var, V(eigen))
                if not ctx_equiv(branch.context, ctx_add(p.context, inst)):
                    raise ValueError('exists_elim branch context')
                if not equivalent(branch.conclusion, p.conclusion):
                    raise ValueError('exists_elim branch conclusion')
                if eigen in free_vars(p.conclusion) or any((eigen in free_vars(h) for h in p.context)):
                    raise ValueError('exists_elim eigenvariable escape')
            elif r == 'bottom_elim':
                if len(p.premises) != 1:
                    raise ValueError('bad bottom_elim arity')
                q = p.premises[0]
                if not isinstance(q.conclusion, Bottom) or not ctx_equiv(q.context, p.context):
                    raise ValueError('bottom_elim premise')
            elif r == 'classical_reductio':
                if len(p.premises) != 1:
                    raise ValueError('bad classical_reductio arity')
                q = p.premises[0]
                if not isinstance(q.conclusion, Bottom):
                    raise ValueError('classical_reductio needs bottom')
                if not ctx_equiv(q.context, ctx_add(p.context, Not(p.conclusion))):
                    raise ValueError('classical_reductio discharge mismatch')
            elif r == 'eq_subst':
                if len(p.premises) != 2:
                    raise ValueError('bad eq_subst arity')
                eqp, fp = p.premises
                if not ctx_equiv(eqp.context, p.context) or not ctx_equiv(fp.context, p.context):
                    raise ValueError('eq_subst context')
                if not isinstance(eqp.conclusion, Eq):
                    raise ValueError('eq_subst no equality')
                direction = d.get('direction', 'lr')
                if direction == 'lr':
                    src, tgt = (eqp.conclusion.left, eqp.conclusion.right)
                elif direction == 'rl':
                    src, tgt = (eqp.conclusion.right, eqp.conclusion.left)
                else:
                    raise ValueError('eq_subst direction')
                expected = substitute(fp.conclusion, src.name, tgt)
                if not equivalent(p.conclusion, expected):
                    raise ValueError('eq_subst result mismatch')
            else:
                raise ValueError(f'unknown rule {r}')
        finally:
            seen.remove(oid)
