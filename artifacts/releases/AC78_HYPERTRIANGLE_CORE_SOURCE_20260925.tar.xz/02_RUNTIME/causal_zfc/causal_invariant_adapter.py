from __future__ import annotations
from dataclasses import dataclass
import hashlib, json, re
from typing import Any
from .logic import Formula, Iff, equivalent, digest_formula, formula_from_obj
from .proof import Proof, proof_digest
from .kernel import ZFCKernel
from .semantic import CertifiedStatement, sequent_key
from .provider_adapter import certified_statement_from_provider
DECIMAL_LITERAL = re.compile('^[+-]?(?:\\d+\\.\\d*|\\d*\\.\\d+)(?:[eE][+-]?\\d+)?$')

def _reject_inexact(obj: Any, path: str='$') -> None:
    """Fail closed on approximate payloads used as causal-state evidence.

    Human display strings may live elsewhere. Evidence submitted through exact_metadata,
    coordinate_gauge, or metric_packet must contain no Python float or decimal literal.
    """
    if isinstance(obj, float):
        raise ValueError(f'FLOAT_FORBIDDEN::{path}')
    if isinstance(obj, str) and DECIMAL_LITERAL.match(obj.strip()):
        raise ValueError(f'DECIMAL_LITERAL_FORBIDDEN::{path}')
    if isinstance(obj, dict):
        for k, v in obj.items():
            _reject_inexact(v, f'{path}.{k}')
    elif isinstance(obj, (list, tuple)):
        for i, v in enumerate(obj):
            _reject_inexact(v, f'{path}[{i}]')

def _hash_obj(obj: Any) -> str:
    raw = json.dumps(obj, sort_keys=True, separators=(',', ':'), ensure_ascii=True).encode()
    return hashlib.sha256(raw).hexdigest()

@dataclass(frozen=True)
class VerifiedReceipt:
    role: str
    proof: Proof
    statement_identity: str
    conclusion_digest: str
    proof_digest: str
    source: str = ''

    def to_obj(self) -> dict[str, Any]:
        return {'role': self.role, 'statement_identity': self.statement_identity, 'conclusion_digest': self.conclusion_digest, 'proof_digest': self.proof_digest, 'source': self.source, 'kernel': 'PASS'}

def verify_provider_receipt(payload: dict[str, Any], kernel: ZFCKernel, role: str) -> VerifiedReceipt:
    rec = certified_statement_from_provider(payload)
    kr = kernel.verify(rec.proof)
    if not kr.ok:
        raise ValueError(f'KERNEL_REJECT::{role}::{kr.code}::{kr.detail}')
    return VerifiedReceipt(role=role, proof=rec.proof, statement_identity=sequent_key(rec.proof.context, rec.proof.conclusion), conclusion_digest=digest_formula(rec.proof.conclusion), proof_digest=proof_digest(rec.proof), source=rec.source)

def _state_fingerprint(carrier_id: str, state_id: str, invariants: list[VerifiedReceipt]) -> str:
    return _hash_obj({'carrier_id': carrier_id, 'state_id': state_id, 'invariant_conclusions': sorted((r.conclusion_digest for r in invariants))})

def analyze_causal_state_packet(packet: dict[str, Any], schema_instances=()) -> dict[str, Any]:
    """Verify causal-state evidence while keeping geometry and truth authority separate.

    Three independent gates are returned:
      STRUCTURAL_CLOSURE      -- required structural receipts are kernel-valid.
      STATE_SELECTOR_VERIFIED     -- selector is kernel-valid and carrier/state binding gates pass.
      FORMAL_PROOF_CLOSED     -- a target proof is kernel-valid and matches the declared target.

    No coordinate gauge can pay STATE_SELECTOR_VERIFIED. No geometry gate can pay formal truth.
    """
    if not isinstance(packet, dict):
        raise ValueError('causal state packet must be an object')
    if packet.get('schema') not in (None, 'CAUSAL_STATE_INVARIANT_PACKET_V1'):
        raise ValueError('unsupported causal state packet schema')
    for fld in ('exact_metadata', 'coordinate_gauge', 'metric_packet'):
        if fld in packet:
            _reject_inexact(packet[fld], f'$.{fld}')
    kernel = ZFCKernel(tuple(schema_instances))
    required_roles = tuple(packet.get('required_structural_roles', ()))
    structural_payloads = packet.get('structural_receipts', {}) or {}
    if not isinstance(structural_payloads, dict):
        raise ValueError('structural_receipts must be an object keyed by role')
    structural_verified: dict[str, VerifiedReceipt] = {}
    structural_errors: dict[str, str] = {}
    for role, payload in structural_payloads.items():
        try:
            structural_verified[str(role)] = verify_provider_receipt(payload, kernel, f'STRUCTURAL::{role}')
        except Exception as e:
            structural_errors[str(role)] = str(e)
    missing_roles = [r for r in required_roles if r not in structural_verified]
    structural_closure = bool(required_roles) and (not missing_roles) and (not structural_errors)
    selector_verified = None
    selector_error = None
    if packet.get('state_selector_receipt') is not None:
        try:
            selector_verified = verify_provider_receipt(packet['state_selector_receipt'], kernel, 'STATE_SELECTOR')
        except Exception as e:
            selector_error = str(e)
    role_binding = packet.get('typed_role_binding') is True
    normalized_carrier = packet.get('normalized_carrier') is True
    same_state_same_carrier = packet.get('same_state_same_carrier') is True
    selector_ok = bool(selector_verified and role_binding and normalized_carrier and same_state_same_carrier)
    formal_verified = None
    formal_error = None
    if packet.get('formal_target_receipt') is not None:
        try:
            formal_verified = verify_provider_receipt(packet['formal_target_receipt'], kernel, 'FORMAL_TARGET')
        except Exception as e:
            formal_error = str(e)
    declared_target_identity = packet.get('target_statement_identity')
    if formal_verified is not None and declared_target_identity is not None:
        formal_closed = formal_verified.statement_identity == declared_target_identity
    else:
        formal_closed = formal_verified is not None
    input_inv = output_inv = None
    invariant_errors: dict[str, str] = {}
    for fld, role in (('input_invariant_receipt', 'INPUT_INVARIANT'), ('output_invariant_receipt', 'OUTPUT_INVARIANT')):
        if packet.get(fld) is not None:
            try:
                rr = verify_provider_receipt(packet[fld], kernel, role)
                if fld.startswith('input'):
                    input_inv = rr
                else:
                    output_inv = rr
            except Exception as e:
                invariant_errors[fld] = str(e)
    state_invariants = list(structural_verified.values())
    if selector_verified:
        state_invariants.append(selector_verified)
    if input_inv:
        state_invariants.append(input_inv)
    if output_inv:
        state_invariants.append(output_inv)
    carrier_id = str(packet.get('carrier_id', 'UNBOUND_CARRIER'))
    state_id = str(packet.get('state_id', 'UNBOUND_STATE'))
    fingerprint = _state_fingerprint(carrier_id, state_id, state_invariants)
    selector_required = packet.get('selector_required') is True
    promotion_allowed = bool(formal_closed and (selector_ok if selector_required else True))
    return {'schema': 'CAUSAL_STATE_INVARIANT_ANALYSIS_V1', 'carrier_id': carrier_id, 'state_id': state_id, 'state_fingerprint': fingerprint, 'coordinate_gauge_used_for_state_identity': False, 'STRUCTURAL_CLOSURE': structural_closure, 'STATE_SELECTOR_VERIFIED': selector_ok, 'FORMAL_PROOF_CLOSED': formal_closed, 'promotion_allowed': promotion_allowed, 'selector_required': selector_required, 'typed_role_binding': role_binding, 'normalized_carrier': normalized_carrier, 'same_state_same_carrier': same_state_same_carrier, 'required_structural_roles': list(required_roles), 'missing_structural_roles': missing_roles, 'structural_receipts': {k: v.to_obj() for k, v in sorted(structural_verified.items())}, 'structural_errors': structural_errors, 'selector_receipt': selector_verified.to_obj() if selector_verified else None, 'selector_error': selector_error, 'formal_target_receipt': formal_verified.to_obj() if formal_verified else None, 'formal_error': formal_error, 'input_invariant_receipt': input_inv.to_obj() if input_inv else None, 'output_invariant_receipt': output_inv.to_obj() if output_inv else None, 'invariant_errors': invariant_errors, 'gauge_metadata_digest': _hash_obj(packet.get('coordinate_gauge', {})), 'truth_authority': 'ZFCKernel', 'geometry_verification_note': 0}

def bridge_causal_cells(cell1_packet: dict[str, Any], cell2_packet: dict[str, Any], bridge_receipt: dict[str, Any] | None=None, schema_instances=()) -> dict[str, Any]:
    """Bind CELL1 output invariant to CELL2 input invariant.

    Exact same sequent closes directly. Different invariants require a kernel-verified IFF proof.
    The bridge never compares decimal values or coordinate-gauge labels.
    """
    a = analyze_causal_state_packet(cell1_packet, schema_instances)
    b = analyze_causal_state_packet(cell2_packet, schema_instances)
    kernel = ZFCKernel(tuple(schema_instances))
    same_carrier = a['carrier_id'] == b['carrier_id']
    same_state_declared = cell1_packet.get('bridge_state_id', a['state_id']) == cell2_packet.get('bridge_state_id', b['state_id'])
    ao = a.get('output_invariant_receipt')
    bi = b.get('input_invariant_receipt')
    if ao is None or bi is None:
        return {'schema': 'CAUSAL_TWO_CELL_INVARIANT_BRIDGE_V1', 'status': 'MISSING_INVARIANT_RECEIPT', 'closed': False, 'same_carrier': same_carrier, 'same_bridge_state': same_state_declared, 'verification_note': 0}
    if not same_carrier or not same_state_declared:
        return {'schema': 'CAUSAL_TWO_CELL_INVARIANT_BRIDGE_V1', 'status': 'CARRIER_OR_STATE_MISMATCH', 'closed': False, 'same_carrier': same_carrier, 'same_bridge_state': same_state_declared, 'verification_note': 0}
    if ao['statement_identity'] == bi['statement_identity']:
        return {'schema': 'CAUSAL_TWO_CELL_INVARIANT_BRIDGE_V1', 'status': 'IDENTICAL_INVARIANT', 'closed': True, 'bridge_mode': 'SAME_FORMAL_SEQUENT', 'output_invariant_identity': ao['statement_identity'], 'input_invariant_identity': bi['statement_identity'], 'coordinate_gauge_compared': False, 'verification_note': 0}
    if bridge_receipt is None:
        return {'schema': 'CAUSAL_TWO_CELL_INVARIANT_BRIDGE_V1', 'status': 'BRIDGE_PROOF_REQUIRED', 'closed': False, 'output_invariant_identity': ao['statement_identity'], 'input_invariant_identity': bi['statement_identity'], 'coordinate_gauge_compared': False, 'verification_note': 0}
    vr = verify_provider_receipt(bridge_receipt, kernel, 'CELL1_TO_CELL2_BRIDGE')
    out_proof = verify_provider_receipt(cell1_packet['output_invariant_receipt'], kernel, 'OUTPUT_INVARIANT_RAW').proof
    in_proof = verify_provider_receipt(cell2_packet['input_invariant_receipt'], kernel, 'INPUT_INVARIANT_RAW').proof
    concl = vr.proof.conclusion
    iff_ok = isinstance(concl, Iff) and (equivalent(concl.left, out_proof.conclusion) and equivalent(concl.right, in_proof.conclusion) or (equivalent(concl.right, out_proof.conclusion) and equivalent(concl.left, in_proof.conclusion)))
    return {'schema': 'CAUSAL_TWO_CELL_INVARIANT_BRIDGE_V1', 'status': 'BRIDGE_PROOF_CERTIFIED' if iff_ok else 'BRIDGE_PROOF_WRONG_TARGET', 'closed': bool(iff_ok), 'bridge_mode': 'KERNEL_VERIFIED_IFF' if iff_ok else None, 'bridge_receipt': vr.to_obj(), 'output_invariant_identity': ao['statement_identity'], 'input_invariant_identity': bi['statement_identity'], 'coordinate_gauge_compared': False, 'verification_note': 0}

def causal_invariant_capability_registry() -> dict[str, Any]:
    return {'schema': 'CAUSAL_ZFC_CAUSAL_INVARIANT_CAPABILITY_REGISTRY_V1', 'version': '1.10', 'pass': 'PASS011_CAUSAL_INVARIANT', 'truth_authority': 'ZFCKernel', 'gates': ['STRUCTURAL_CLOSURE', 'STATE_SELECTOR_VERIFIED', 'FORMAL_PROOF_CLOSED'], 'state_identity_uses_coordinate_gauge': False, 'cell_bridge': 'OUTPUT_INVARIANT_TO_INPUT_INVARIANT', 'exact_only': True, 'float_decision': False, 'numeric_proximity_decision': False, 'golden_state_special_case': 'SUPPORTED_ONLY_BY_VERIFIED_SELECTOR_RECEIPT', 'equal_sin_gauge_is_selector': False, 'geometry_verification_note': 0}
