from __future__ import annotations
from dataclasses import dataclass
from .logic import *

@dataclass(frozen=True)
class SchemaInstance:
    schema: str
    predicate: Formula
    source_var: str = 'u'
    target_var: str = 'v'
    parameters: tuple[str, ...] = ()

    def generated(self) -> Formula:
        if self.schema == 'SEPARATION':
            return separation_instance(self.predicate, self.source_var, self.parameters)
        if self.schema == 'REPLACEMENT':
            return replacement_instance(self.predicate, self.source_var, self.target_var, self.parameters)
        raise ValueError(self.schema)

def extensionality() -> Formula:
    x, y, z = (V('x'), V('y'), V('z'))
    return Forall('x', Forall('y', Imp(Forall('z', Iff(Mem(z, x), Mem(z, y))), Eq(x, y))))

def pairing() -> Formula:
    x, y, z, w = (V('x'), V('y'), V('z'), V('w'))
    return Forall('x', Forall('y', Exists('z', Forall('w', Iff(Mem(w, z), Or(Eq(w, x), Eq(w, y)))))))

def union_axiom() -> Formula:
    x, y, z, w = (V('x'), V('y'), V('z'), V('w'))
    return Forall('x', Exists('y', Forall('z', Iff(Mem(z, y), Exists('w', And(Mem(z, w), Mem(w, x)))))))

def power_set() -> Formula:
    x, y, z, w = (V('x'), V('y'), V('z'), V('w'))
    subset = Forall('w', Imp(Mem(w, z), Mem(w, x)))
    return Forall('x', Exists('y', Forall('z', Iff(Mem(z, y), subset))))

def infinity() -> Formula:
    x, e, z, y, s = (V('x'), V('e'), V('z'), V('y'), V('s'))
    empty = And(Mem(e, x), Forall('z', Not(Mem(z, e))))
    succ_body = Forall('z', Iff(Mem(z, s), Or(Mem(z, y), Eq(z, y))))
    closed = Forall('y', Imp(Mem(y, x), Exists('s', And(Mem(s, x), succ_body))))
    return Exists('x', And(Exists('e', empty), closed))

def foundation() -> Formula:
    x, y, z = (V('x'), V('y'), V('z'))
    nonempty = Exists('y', Mem(y, x))
    minimal = Exists('y', And(Mem(y, x), Not(Exists('z', And(Mem(z, y), Mem(z, x))))))
    return Forall('x', Imp(nonempty, minimal))

def choice_disjoint_family() -> Formula:
    x, y, z, w, c, q = (V('x'), V('y'), V('z'), V('w'), V('c'), V('q'))
    nonempty = Forall('y', Imp(Mem(y, x), Exists('z', Mem(z, y))))
    disjoint = Forall('y', Forall('z', Imp(And(And(Mem(y, x), Mem(z, x)), Not(Eq(y, z))), Not(Exists('w', And(Mem(w, y), Mem(w, z)))))))
    unique_pick = Exists('z', And(And(Mem(z, y), Mem(z, c)), Forall('w', Imp(And(Mem(w, y), Mem(w, c)), Eq(w, z)))))
    choice = Exists('c', Forall('y', Imp(Mem(y, x), unique_pick)))
    return Forall('x', Imp(And(nonempty, disjoint), choice))
FIXED_AXIOMS = {'EXTENSIONALITY': extensionality(), 'PAIRING': pairing(), 'UNION': union_axiom(), 'POWER_SET': power_set(), 'INFINITY': infinity(), 'FOUNDATION': foundation(), 'CHOICE_DISJOINT_FAMILY': choice_disjoint_family()}

def _validate_schema_predicate(phi: Formula, allowed: set[str]):
    extra = free_vars(phi) - allowed
    if extra:
        raise ValueError(f'schema predicate has undeclared free vars: {sorted(extra)}')

def _fresh_many(phi: Formula, names: list[str]) -> dict[str, str]:
    avoid = all_vars(phi) | set(names)
    out = {}
    for base in names:
        n = base
        i = 0
        while n in avoid or n in out.values():
            n = f'{base}_{i}'
            i += 1
        out[base] = n
        avoid.add(n)
    return out

def separation_instance(phi: Formula, element_var: str='u', parameters: tuple[str, ...]=()) -> Formula:
    allowed = {element_var, *parameters}
    _validate_schema_predicate(phi, allowed)
    fresh = _fresh_many(phi, ['x', 'y'])
    x, y = (fresh['x'], fresh['y'])
    u = V(element_var)
    core = Forall(element_var, Iff(Mem(u, V(y)), And(Mem(u, V(x)), phi)))
    f = Forall(x, Exists(y, core))
    for p in reversed(parameters):
        f = Forall(p, f)
    return f

def replacement_instance(phi: Formula, source_var: str='u', target_var: str='v', parameters: tuple[str, ...]=()) -> Formula:
    allowed = {source_var, target_var, *parameters}
    _validate_schema_predicate(phi, allowed)
    fresh = _fresh_many(phi, ['x', 'y', 'w'])
    x, y, w = (fresh['x'], fresh['y'], fresh['w'])
    u, v = (V(source_var), V(target_var))
    phi_w = substitute(phi, target_var, V(w))
    functional = Forall(source_var, Forall(target_var, Forall(w, Imp(And(phi, phi_w), Eq(v, V(w))))))
    image = Forall(x, Exists(y, Forall(target_var, Iff(Mem(v, V(y)), Exists(source_var, And(Mem(u, V(x)), phi))))))
    f = Imp(functional, image)
    for p in reversed(parameters):
        f = Forall(p, f)
    return f
