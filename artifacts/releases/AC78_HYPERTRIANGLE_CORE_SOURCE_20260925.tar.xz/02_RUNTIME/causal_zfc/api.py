from __future__ import annotations
from .logic import formula_from_obj, pretty, digest_formula
from .axioms import SchemaInstance
from .synthesizer import CausalZFCSynthesizer
from .proof import proof_digest, proof_from_obj
from .semantic import CertifiedStatement, normalize_statement_kind, sequent_key
from .provider_adapter import certified_statement_from_provider

def run_request(req: dict) -> dict:
    goal = formula_from_obj(req['goal'])
    ctx = tuple((formula_from_obj(x) for x in req.get('context', [])))
    schemas = []
    for s in req.get('schema_instances', []):
        schemas.append(SchemaInstance(s['schema'], formula_from_obj(s['predicate']), s.get('source_var', 'u'), s.get('target_var', 'v'), tuple(s.get('parameters', []))))
    lib = []
    for item in req.get('proof_library', []):
        lib.append(CertifiedStatement(proof=proof_from_obj(item['proof']), name=item.get('name', ''), kind=item.get('kind', 'statement'), source=item.get('source', '')))
    for item in req.get('provider_statements', []):
        lib.append(certified_statement_from_provider(item))
    syn = CausalZFCSynthesizer(tuple(schemas), int(req.get('budget', 4000)), tuple(lib), int(req.get('max_depth', 18)), bool(req.get('foundation_library', False)), bool(req.get('mathematics_library', False)), bool(req.get('arithmetic_library', False)), bool(req.get('recursion_library', False)))
    r = syn.synthesize(goal, ctx)
    out = {'schema': 'CAUSAL_ZFC_SYNTHESIS_RESULT_V6', 'status': r.status, 'input_statement_kind': req.get('statement_kind', 'statement'), 'canonical_statement_kind': normalize_statement_kind(req.get('statement_kind')), 'statement_identity': sequent_key(ctx, goal), 'goal': pretty(goal), 'goal_digest': digest_formula(goal), 'explored': r.explored, 'sin1_frontier': r.sin1_frontier, 'sin2_frontier': r.sin2_frontier, 'cos_matches': r.cos_matches, 'proof_library_canonical_entries': r.library_entries, 'foundation_library_enabled': bool(req.get('foundation_library', False) or req.get('mathematics_library', False) or req.get('arithmetic_library', False) or req.get('recursion_library', False)), 'mathematics_library_enabled': bool(req.get('mathematics_library', False) or req.get('arithmetic_library', False) or req.get('recursion_library', False)), 'arithmetic_library_enabled': bool(req.get('arithmetic_library', False) or req.get('recursion_library', False)), 'recursion_library_enabled': bool(req.get('recursion_library', False)), 'scientific_credit': 'KERNEL_ONLY', 'residual': r.residual}
    if r.proof:
        out['proof'] = r.proof.to_obj()
        out['proof_digest'] = proof_digest(r.proof)
    return out
