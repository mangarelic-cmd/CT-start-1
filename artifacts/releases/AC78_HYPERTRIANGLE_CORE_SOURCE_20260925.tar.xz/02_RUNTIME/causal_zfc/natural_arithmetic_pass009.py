from __future__ import annotations
from .logic import *
from .proof import *
from .axioms import SchemaInstance
from .kernel import ZFCKernel
from .semantic import CertifiedStatement, NormalizedLibraryEntry
from .setdefs import *
from .setdefs import _fresh_local
from .derived_library import _assume, _forall_elim, _and_l, _and_r, _imp_elim, _iff_l, _iff_r, _weaken, build_empty_unique
from .mathematics_library import OmegaSpec, CartesianProductSpec, build_cartesian_product_exists, build_successor_unique, build_ordered_pair_code_exists
from .arithmetic_library import GraphValueSpec, build_ordered_pair_injective, _op_injective_instance
from .history_library import PASS008_SCHEMA_INSTANCES, build_omega_recursion_exists_unique
from .recursion_library import RecursionCandidateSpec

def SuccessorPairPredicate(p: Term, w: Term, x: str='x', y: str='y') -> Formula:
    avoid = {p.name, w.name}
    x = _fresh_local(x, avoid)
    avoid.add(x)
    y = _fresh_local(y, avoid)
    return Exists(x, And(Mem(V(x), w), Exists(y, And(Mem(V(y), w), And(SuccessorSpec(V(y), V(x), 'u'), OrderedPairCode(p, V(x), V(y), 'a', 'b'))))))

def SuccessorFunctionSpec(g: Term, w: Term, x: str='x', y: str='y') -> Formula:
    avoid = {g.name, w.name}
    x = _fresh_local(x, avoid)
    avoid.add(x)
    y = _fresh_local(y, avoid)
    fun = FunctionGraphSpec(g, w, w, 'p', 'xf', 'yf', 'yf2')
    exact = Forall(x, Forall(y, Imp(And(Mem(V(x), w), And(Mem(V(y), w), SuccessorSpec(V(y), V(x), 'u'))), GraphValueSpec(g, V(x), V(y), 'q'))))
    sound = Forall(x, Forall(y, Imp(GraphValueSpec(g, V(x), V(y), 'r'), SuccessorSpec(V(y), V(x), 'v'))))
    return And(fun, And(exact, sound))

def successor_function_exists_formula() -> Formula:
    return Forall('w', Imp(OmegaSpec(V('w'), 'j', 'k'), Exists('g', SuccessorFunctionSpec(V('g'), V('w'), 'x', 'y'))))
SUCCESSOR_GRAPH_SEPARATION_SCHEMA = SchemaInstance('SEPARATION', SuccessorPairPredicate(V('p'), V('w'), 'x', 'y'), source_var='p', parameters=('w',))
PASS009_SCHEMA_INSTANCES = tuple(PASS008_SCHEMA_INSTANCES) + (SUCCESSOR_GRAPH_SEPARATION_SCHEMA,)

def _pack_and3(a: Proof, b: Proof, c: Proof, goal: Formula, ctx) -> Proof:
    return Proof('and_intro', goal, ctx, (a, Proof('and_intro', goal.right, ctx, (b, c))))

def _successor_from_selected_pair(hSep: Proof, opinj: Proof, p: str, x: str, y: str, pInG: Proof, opPxy: Proof, ctx) -> Proof:
    """p in G and p=<x,y> -> SuccessorSpec(y,x), using the separation predicate."""
    sp = _forall_elim(_weaken(hSep, ctx), p)
    rhs = _imp_elim(_iff_l(sp), _weaken(pInG, ctx))
    pred = _and_r(rhs)
    assert isinstance(pred.conclusion, Exists)
    X = 'SX_' + p + x + y
    ix = substitute(pred.conclusion.body, pred.conclusion.var, V(X))
    ctxX = ctx + (ix,)
    hx = _assume(ix, ctxX)
    Xw = _and_l(hx)
    exY = _and_r(hx)
    assert isinstance(exY.conclusion, Exists)
    Y = 'SY_' + p + x + y
    iy = substitute(exY.conclusion.body, exY.conclusion.var, V(Y))
    ctxY = ctxX + (iy,)
    hy = _assume(iy, ctxY)
    Yw = _and_l(hy)
    rest = _and_r(hy)
    succYX = _and_l(rest)
    opPXY = _and_r(rest)
    inj = _op_injective_instance(_weaken(opinj, ctxY), p, x, y, X, Y, _weaken(opPxy, ctxY), opPXY, ctxY)
    eqxX = _and_l(inj)
    eqyY = _and_r(inj)
    s1 = Proof('eq_subst', substitute(succYX.conclusion, X, V(x)), ctxY, (eqxX, succYX), (('direction', 'rl'),))
    s2 = Proof('eq_subst', substitute(s1.conclusion, Y, V(y)), ctxY, (eqyY, s1), (('direction', 'rl'),))
    aY = Proof('exists_elim', s2.conclusion, ctxX, (exY, s2), (('eigenvar', Y),))
    return Proof('exists_elim', s2.conclusion, ctx, (pred, aY), (('eigenvar', X),))

def build_successor_function_exists(schema_index: int=10, cartesian_pf: Proof | None=None, ordered_pair_pf: Proof | None=None, opinj_pf: Proof | None=None, succ_unique_pf: Proof | None=None) -> Proof:
    cartesian_pf = cartesian_pf or build_cartesian_product_exists(1)
    ordered_pair_pf = ordered_pair_pf or build_ordered_pair_code_exists()
    opinj_pf = opinj_pf or build_ordered_pair_injective()
    succ_unique_pf = succ_unique_pf or build_successor_unique()
    goal = successor_function_exists_formula()
    core = goal.body
    om = core.left
    target = core.right
    ctx0 = (om,)
    hom = _assume(om, ctx0)
    cp = _weaken(cartesian_pf, ctx0)
    cp = _forall_elim(_forall_elim(cp, 'w'), 'w')
    assert isinstance(cp.conclusion, Exists)
    C = 'Csucc'
    iC = substitute(cp.conclusion.body, cp.conclusion.var, V(C))
    ctxC = ctx0 + (iC,)
    hC = _assume(iC, ctxC)
    sep = Proof('axiom_schema', SUCCESSOR_GRAPH_SEPARATION_SCHEMA.generated(), ctxC, (), (('schema_index', schema_index),))
    q = _forall_elim(_forall_elim(sep, 'w'), C)
    assert isinstance(q.conclusion, Exists)
    G = 'Gsucc'
    iG = substitute(q.conclusion.body, q.conclusion.var, V(G))
    ctxG = ctxC + (iG,)
    hSep = _assume(iG, ctxG)
    spec = SuccessorFunctionSpec(V(G), V('w'), 'x', 'y')
    fun = spec.left
    exact = spec.right.left
    sound = spec.right.right
    rel = fun.left
    p = rel.var
    ir = rel.body
    ctxP = ctxG + (ir.left,)
    hp = _assume(ir.left, ctxP)
    sp = _forall_elim(_weaken(hSep, ctxP), p)
    sr = _imp_elim(_iff_l(sp), hp)
    pC = _and_l(sr)
    cpP = _forall_elim(_weaken(hC, ctxP), p)
    cart = _imp_elim(_iff_l(cpP), pC)
    rip = Proof('imp_intro', ir, ctxG, (cart,))
    relpf = Proof('forall_intro', rel, ctxG, (rip,))
    total = fun.right.left
    x = total.var
    it = total.body
    ctxX = ctxG + (it.left,)
    xw = _assume(it.left, ctxX)
    closed = _and_r(_and_l(_weaken(hom, ctxX)))
    qs = _forall_elim(closed, x)
    exY = _imp_elim(qs, xw)
    assert isinstance(exY.conclusion, Exists)
    Y = 'YtotS'
    iY = substitute(exY.conclusion.body, exY.conclusion.var, V(Y))
    ctxY = ctxX + (iY,)
    hY = _assume(iY, ctxY)
    Yw = _and_l(hY)
    succYX = _and_r(hY)
    op = _weaken(ordered_pair_pf, ctxY)
    op = _forall_elim(_forall_elim(op, x), Y)
    assert isinstance(op.conclusion, Exists)
    P = 'PtotS'
    iP = substitute(op.conclusion.body, op.conclusion.var, V(P))
    ctxPair = ctxY + (iP,)
    hOP = _assume(iP, ctxPair)
    cpPair = _forall_elim(_weaken(hC, ctxPair), P)
    pred = cpPair.conclusion.right
    ix = substitute(pred.body, pred.var, V(x))
    ey = ix.right
    iy = substitute(ey.body, ey.var, V(Y))
    cy = Proof('and_intro', iy, ctxPair, (_weaken(Yw, ctxPair), hOP))
    eyy = Proof('exists_intro', ey, ctxPair, (cy,), (('term', {'var': Y}),))
    cx = Proof('and_intro', ix, ctxPair, (_weaken(xw, ctxPair), eyy))
    exx = Proof('exists_intro', pred, ctxPair, (cx,), (('term', {'var': x}),))
    PinC = _imp_elim(_iff_r(cpPair), exx)
    pr = SuccessorPairPredicate(V(P), V('w'), 'u', 'v')
    ipx = substitute(pr.body, pr.var, V(x))
    exv = ipx.right
    ivy = substitute(exv.body, exv.var, V(Y))
    tail = ivy.right
    ctail = Proof('and_intro', tail, ctxPair, (_weaken(succYX, ctxPair), hOP))
    cv = Proof('and_intro', ivy, ctxPair, (_weaken(Yw, ctxPair), ctail))
    ev = Proof('exists_intro', exv, ctxPair, (cv,), (('term', {'var': Y}),))
    cu = Proof('and_intro', ipx, ctxPair, (_weaken(xw, ctxPair), ev))
    eu = Proof('exists_intro', pr, ctxPair, (cu,), (('term', {'var': x}),))
    sPP = _forall_elim(_weaken(hSep, ctxPair), P)
    rhs = Proof('and_intro', sPP.conclusion.right, ctxPair, (PinC, eu))
    PinG = _imp_elim(_iff_r(sPP), rhs)
    gv = GraphValueSpec(V(G), V(x), V(Y), 'q')
    ig = substitute(gv.body, gv.var, V(P))
    cg = Proof('and_intro', ig, ctxPair, (PinG, hOP))
    eg = Proof('exists_intro', gv, ctxPair, (cg,), (('term', {'var': P}),))
    outY = it.right
    iyout = substitute(outY.body, outY.var, V(Y))
    cyout = Proof('and_intro', iyout, ctxPair, (_weaken(Yw, ctxPair), eg))
    eyout = Proof('exists_intro', outY, ctxPair, (cyout,), (('term', {'var': Y}),))
    aP = Proof('exists_elim', outY, ctxY, (op, eyout), (('eigenvar', P),))
    aY = Proof('exists_elim', outY, ctxX, (exY, aP), (('eigenvar', Y),))
    ti = Proof('imp_intro', it, ctxG, (aY,))
    totalpf = Proof('forall_intro', total, ctxG, (ti,))
    unique = fun.right.right
    ux = unique.var
    uy = unique.body.var
    uy2 = unique.body.body.var
    iu = unique.body.body.body
    ctxU = ctxG + (iu.left,)
    hu = _assume(iu.left, ctxU)
    L = _and_l(hu)
    R = _and_r(hu)
    xwU = _and_l(L)
    yw = _and_r(L)
    y2w = _and_l(R)
    both = _and_r(R)
    gv1 = _and_l(both)
    gv2 = _and_r(both)
    P1 = 'Psu1'
    i1 = substitute(gv1.conclusion.body, gv1.conclusion.var, V(P1))
    ctx1 = ctxU + (i1,)
    h1 = _assume(i1, ctx1)
    P1G = _and_l(h1)
    op1 = _and_r(h1)
    P2 = 'Psu2'
    gv2w = _weaken(gv2, ctx1)
    i2 = substitute(gv2w.conclusion.body, gv2w.conclusion.var, V(P2))
    ctx2 = ctx1 + (i2,)
    h2 = _assume(i2, ctx2)
    P2G = _and_l(h2)
    op2 = _and_r(h2)
    s1 = _successor_from_selected_pair(_weaken(hSep, ctx2), _weaken(opinj_pf, ctx2), P1, ux, uy, _weaken(P1G, ctx2), _weaken(op1, ctx2), ctx2)
    s2 = _successor_from_selected_pair(_weaken(hSep, ctx2), _weaken(opinj_pf, ctx2), P2, ux, uy2, P2G, op2, ctx2)
    su = _weaken(succ_unique_pf, ctx2)
    for nm in [ux, uy, uy2]:
        su = _forall_elim(su, nm)
    eq = _imp_elim(su, Proof('and_intro', su.conclusion.left, ctx2, (s1, s2)))
    a2 = Proof('exists_elim', Eq(V(uy), V(uy2)), ctx1, (gv2w, eq), (('eigenvar', P2),))
    a1 = Proof('exists_elim', Eq(V(uy), V(uy2)), ctxU, (gv1, a2), (('eigenvar', P1),))
    iup = Proof('imp_intro', iu, ctxG, (a1,))
    q2 = Proof('forall_intro', unique.body.body, ctxG, (iup,))
    q1 = Proof('forall_intro', unique.body, ctxG, (q2,))
    uniquepf = Proof('forall_intro', unique, ctxG, (q1,))
    funpf = Proof('and_intro', fun, ctxG, (relpf, Proof('and_intro', fun.right, ctxG, (totalpf, uniquepf))))
    xx = exact.var
    yy = exact.body.var
    ie = exact.body.body
    ctxE = ctxG + (ie.left,)
    he = _assume(ie.left, ctxE)
    xwE = _and_l(he)
    restE = _and_r(he)
    ywE = _and_l(restE)
    succE = _and_r(restE)
    tot = _forall_elim(_weaken(totalpf, ctxE), xx)
    exZ = _imp_elim(tot, xwE)
    assert isinstance(exZ.conclusion, Exists)
    Z = 'ZexactS'
    iZ = substitute(exZ.conclusion.body, exZ.conclusion.var, V(Z))
    ctxZ = ctxE + (iZ,)
    hZ = _assume(iZ, ctxZ)
    Zw = _and_l(hZ)
    gvZ = _and_r(hZ)
    Pz = 'PexactS'
    iPz = substitute(gvZ.conclusion.body, gvZ.conclusion.var, V(Pz))
    ctxPz = ctxZ + (iPz,)
    hpz = _assume(iPz, ctxPz)
    PzG = _and_l(hpz)
    opxz = _and_r(hpz)
    succZ = _successor_from_selected_pair(_weaken(hSep, ctxPz), _weaken(opinj_pf, ctxPz), Pz, xx, Z, PzG, opxz, ctxPz)
    su2 = _weaken(succ_unique_pf, ctxPz)
    for nm in [xx, Z, yy]:
        su2 = _forall_elim(su2, nm)
    eqZy = _imp_elim(su2, Proof('and_intro', su2.conclusion.left, ctxPz, (succZ, _weaken(succE, ctxPz))))
    gvY = Proof('eq_subst', GraphValueSpec(V(G), V(xx), V(yy), 'q'), ctxPz, (eqZy, _weaken(gvZ, ctxPz)), (('direction', 'lr'),))
    aPz = Proof('exists_elim', ie.right, ctxZ, (gvZ, gvY), (('eigenvar', Pz),))
    aZ = Proof('exists_elim', ie.right, ctxE, (exZ, aPz), (('eigenvar', Z),))
    eip = Proof('imp_intro', ie, ctxG, (aZ,))
    qyy = Proof('forall_intro', exact.body, ctxG, (eip,))
    exactpf = Proof('forall_intro', exact, ctxG, (qyy,))
    sx = sound.var
    sy = sound.body.var
    isnd = sound.body.body
    ctxS = ctxG + (isnd.left,)
    gvS = _assume(isnd.left, ctxS)
    PS = 'PsoundS'
    iPS = substitute(gvS.conclusion.body, gvS.conclusion.var, V(PS))
    ctxPS = ctxS + (iPS,)
    hPS = _assume(iPS, ctxPS)
    PSG = _and_l(hPS)
    opPS = _and_r(hPS)
    succSound = _successor_from_selected_pair(_weaken(hSep, ctxPS), _weaken(opinj_pf, ctxPS), PS, sx, sy, PSG, opPS, ctxPS)
    aPS = Proof('exists_elim', isnd.right, ctxS, (gvS, succSound), (('eigenvar', PS),))
    sip = Proof('imp_intro', isnd, ctxG, (aPS,))
    qsy = Proof('forall_intro', sound.body, ctxG, (sip,))
    soundpf = Proof('forall_intro', sound, ctxG, (qsy,))
    specpf = Proof('and_intro', spec, ctxG, (funpf, Proof('and_intro', spec.right, ctxG, (exactpf, soundpf))))
    exG = Proof('exists_intro', target, ctxG, (specpf,), (('term', {'var': G}),))
    afterG = Proof('exists_elim', target, ctxC, (q, exG), (('eigenvar', G),))
    afterC = Proof('exists_elim', target, ctx0, (cp, afterG), (('eigenvar', C),))
    imp = Proof('imp_intro', core, (), (afterC,))
    return Proof('forall_intro', goal, (), (imp,))

def AdditionSectionSpec(f: Term, w: Term, m: Term, g: Term) -> Formula:
    return And(SuccessorFunctionSpec(g, w, 'sx', 'sy'), RecursionCandidateSpec(f, w, w, m, g, 'z', 'n', 's', 'x', 'y'))

def addition_section_exists_unique_formula() -> Formula:
    base = And(OmegaSpec(V('w'), 'j', 'k'), Mem(V('m'), V('w')))
    cand = AdditionSectionSpec(V('f'), V('w'), V('m'), V('g'))
    uniq = Forall('h', Imp(RecursionCandidateSpec(V('h'), V('w'), V('w'), V('m'), V('g'), 'zh', 'nh', 'sh', 'xh', 'yh'), Eq(V('h'), V('f'))))
    return Forall('w', Forall('m', Imp(base, Exists('g', Exists('f', And(cand, uniq))))))

def build_addition_section_exists_unique(successor_pf: Proof | None=None, recursion_pf: Proof | None=None) -> Proof:
    successor_pf = successor_pf or build_successor_function_exists()
    recursion_pf = recursion_pf or build_omega_recursion_exists_unique()
    goal = addition_section_exists_unique_formula()
    core = goal.body.body
    base = core.left
    target = core.right
    ctx = (base,)
    hb = _assume(base, ctx)
    om = _and_l(hb)
    mw = _and_r(hb)
    sg = _weaken(successor_pf, ctx)
    sg = _forall_elim(sg, 'w')
    exG = _imp_elim(sg, om)
    assert isinstance(exG.conclusion, Exists)
    G = 'Gadd'
    iG = substitute(exG.conclusion.body, exG.conclusion.var, V(G))
    ctxG = ctx + (iG,)
    hG = _assume(iG, ctxG)
    gfun = _and_l(hG)
    rr = _weaken(recursion_pf, ctxG)
    for nm in ['w', 'w', 'm', G]:
        rr = _forall_elim(rr, nm)
    rbase = rr.conclusion.left
    rtail = Proof('and_intro', rbase.right, ctxG, (_weaken(mw, ctxG), gfun))
    rante = Proof('and_intro', rbase, ctxG, (_weaken(om, ctxG), rtail))
    exF = _imp_elim(rr, rante)
    assert isinstance(exF.conclusion, Exists)
    F = 'Fadd'
    iF = substitute(exF.conclusion.body, exF.conclusion.var, V(F))
    ctxF = ctxG + (iF,)
    hF = _assume(iF, ctxF)
    recF = _and_l(hF)
    uniq = _and_r(hF)
    cand = AdditionSectionSpec(V(F), V('w'), V('m'), V(G))
    cproof = Proof('and_intro', cand, ctxF, (_weaken(hG, ctxF), recF))
    tf = substitute(target.body, target.var, V(G))
    tff = substitute(tf.body, tf.var, V(F))
    both = Proof('and_intro', tff, ctxF, (cproof, uniq))
    exf = Proof('exists_intro', tf, ctxF, (both,), (('term', {'var': F}),))
    afterF = Proof('exists_elim', tf, ctxG, (exF, exf), (('eigenvar', F),))
    exg = Proof('exists_intro', target, ctxG, (afterF,), (('term', {'var': G}),))
    afterG = Proof('exists_elim', target, ctx, (exG, exg), (('eigenvar', G),))
    imp = Proof('imp_intro', core, (), (afterG,))
    qm = Proof('forall_intro', goal.body, (), (imp,))
    return Proof('forall_intro', goal, (), (qm,))

def multiplication_section_exists_unique_formula() -> Formula:
    base = And(OmegaSpec(V('w'), 'j', 'k'), Mem(V('m'), V('w')))
    addRec = RecursionCandidateSpec(V('add'), V('w'), V('w'), V('m'), V('g'), 'za', 'na', 'sa', 'xa', 'ya')
    mulRec = RecursionCandidateSpec(V('mul'), V('w'), V('w'), V('z0'), V('add'), 'zm', 'nm', 'sm', 'xm', 'ym')
    body = And(SuccessorFunctionSpec(V('g'), V('w'), 'sx', 'sy'), And(addRec, And(EmptySpec(V('z0'), 'ez'), And(Mem(V('z0'), V('w')), mulRec))))
    return Forall('w', Forall('m', Imp(base, Exists('g', Exists('add', Exists('z0', Exists('mul', body)))))))

def build_multiplication_section_exists(addition_pf: Proof | None=None, recursion_pf: Proof | None=None) -> Proof:
    addition_pf = addition_pf or build_addition_section_exists_unique()
    recursion_pf = recursion_pf or build_omega_recursion_exists_unique()
    goal = multiplication_section_exists_unique_formula()
    core = goal.body.body
    base = core.left
    target = core.right
    ctx = (base,)
    hb = _assume(base, ctx)
    om = _and_l(hb)
    mw = _and_r(hb)
    ap = _weaken(addition_pf, ctx)
    ap = _forall_elim(_forall_elim(ap, 'w'), 'm')
    exG = _imp_elim(ap, hb)
    assert isinstance(exG.conclusion, Exists)
    G = 'GmulA'
    iG = substitute(exG.conclusion.body, exG.conclusion.var, V(G))
    ctxG = ctx + (iG,)
    hGpack = _assume(iG, ctxG)
    exAdd = hGpack
    assert isinstance(exAdd.conclusion, Exists)
    A = 'AddM'
    iA = substitute(exAdd.conclusion.body, exAdd.conclusion.var, V(A))
    ctxA = ctxG + (iA,)
    hApack = _assume(iA, ctxA)
    addCand = _and_l(hApack)
    hSucc = _and_l(addCand)
    addRec = _and_r(addCand)
    addFun = _and_l(addRec)
    ex0 = _and_l(_and_l(_weaken(om, ctxA)))
    assert isinstance(ex0.conclusion, Exists)
    Z = 'Zmul'
    iZ = substitute(ex0.conclusion.body, ex0.conclusion.var, V(Z))
    ctxZ = ctxA + (iZ,)
    hZ = _assume(iZ, ctxZ)
    Zw = _and_l(hZ)
    emptyZ = _and_r(hZ)
    rp = _weaken(recursion_pf, ctxZ)
    for nm in ['w', 'w', Z, A]:
        rp = _forall_elim(rp, nm)
    rb = rp.conclusion.left
    rt = Proof('and_intro', rb.right, ctxZ, (_weaken(Zw, ctxZ), _weaken(addFun, ctxZ)))
    ra = Proof('and_intro', rb, ctxZ, (_weaken(om, ctxZ), rt))
    exM = _imp_elim(rp, ra)
    assert isinstance(exM.conclusion, Exists)
    M = 'MulM'
    iM = substitute(exM.conclusion.body, exM.conclusion.var, V(M))
    ctxM = ctxZ + (iM,)
    hMpack = _assume(iM, ctxM)
    mulRec = _and_l(hMpack)
    body = target.body.body.body.body
    inst = substitute(substitute(substitute(substitute(body, 'g', V(G)), 'add', V(A)), 'z0', V(Z)), 'mul', V(M))
    p1 = _weaken(hSucc, ctxM)
    p2 = _weaken(addRec, ctxM)
    p3 = _weaken(emptyZ, ctxM)
    p4 = _weaken(Zw, ctxM)
    p5 = mulRec
    tail0 = Proof('and_intro', inst.right.right.right, ctxM, (p4, p5))
    tail1 = Proof('and_intro', inst.right.right, ctxM, (p3, tail0))
    tail2 = Proof('and_intro', inst.right, ctxM, (p2, tail1))
    allb = Proof('and_intro', inst, ctxM, (p1, tail2))
    exm = Proof('exists_intro', substitute(substitute(substitute(target.body.body.body, 'g', V(G)), 'add', V(A)), 'z0', V(Z)), ctxM, (allb,), (('term', {'var': M}),))
    az = Proof('exists_elim', exm.conclusion, ctxA + (iZ,), (exM, exm), (('eigenvar', M),))
    tG = substitute(target.body, target.var, V(G))
    tA = substitute(tG.body, tG.var, V(A))
    tZ = substitute(tA.body, tA.var, V(Z))
    tM = substitute(tZ.body, tZ.var, V(M))
    em = Proof('exists_intro', tZ, ctxM, (allb,), (('term', {'var': M}),))
    aM = Proof('exists_elim', tZ, ctxZ, (exM, em), (('eigenvar', M),))
    ez = Proof('exists_intro', tA, ctxZ, (aM,), (('term', {'var': Z}),))
    aZ = Proof('exists_elim', tA, ctxA, (ex0, ez), (('eigenvar', Z),))
    ea = Proof('exists_intro', tG, ctxA, (aZ,), (('term', {'var': A}),))
    aA = Proof('exists_elim', tG, ctxG, (exAdd, ea), (('eigenvar', A),))
    eg = Proof('exists_intro', target, ctxG, (aA,), (('term', {'var': G}),))
    aG = Proof('exists_elim', target, ctx, (exG, eg), (('eigenvar', G),))
    imp = Proof('imp_intro', core, (), (aG,))
    qm = Proof('forall_intro', goal.body, (), (imp,))
    return Proof('forall_intro', goal, (), (qm,))

def exponentiation_section_exists_formula() -> Formula:
    base = And(OmegaSpec(V('w'), 'j', 'k'), Mem(V('m'), V('w')))
    addRec = RecursionCandidateSpec(V('add'), V('w'), V('w'), V('m'), V('g'), 'za', 'na', 'sa', 'xa', 'ya')
    mulRec = RecursionCandidateSpec(V('mul'), V('w'), V('w'), V('z0'), V('add'), 'zm', 'nm', 'sm', 'xm', 'ym')
    expRec = RecursionCandidateSpec(V('exp'), V('w'), V('w'), V('one'), V('mul'), 'ze', 'ne', 'se', 'xe', 'ye')
    body = And(SuccessorFunctionSpec(V('g'), V('w'), 'sx', 'sy'), And(addRec, And(EmptySpec(V('z0'), 'ez'), And(Mem(V('z0'), V('w')), And(mulRec, And(SuccessorSpec(V('one'), V('z0'), 'uo'), And(Mem(V('one'), V('w')), expRec)))))))
    return Forall('w', Forall('m', Imp(base, Exists('g', Exists('add', Exists('z0', Exists('mul', Exists('one', Exists('exp', body)))))))))

def build_exponentiation_section_exists(multiplication_pf: Proof | None=None, recursion_pf: Proof | None=None) -> Proof:
    multiplication_pf = multiplication_pf or build_multiplication_section_exists()
    recursion_pf = recursion_pf or build_omega_recursion_exists_unique()
    goal = exponentiation_section_exists_formula()
    core = goal.body.body
    base = core.left
    target = core.right
    ctx = (base,)
    hb = _assume(base, ctx)
    om = _and_l(hb)
    mp = _weaken(multiplication_pf, ctx)
    mp = _forall_elim(_forall_elim(mp, 'w'), 'm')
    exG = _imp_elim(mp, hb)
    assert isinstance(exG.conclusion, Exists)
    G = 'GexpA'
    iG = substitute(exG.conclusion.body, exG.conclusion.var, V(G))
    ctxG = ctx + (iG,)
    hg = _assume(iG, ctxG)
    exA = hg
    assert isinstance(exA.conclusion, Exists)
    A = 'AddE'
    iA = substitute(exA.conclusion.body, exA.conclusion.var, V(A))
    ctxA = ctxG + (iA,)
    ha = _assume(iA, ctxA)
    exZ = ha
    assert isinstance(exZ.conclusion, Exists)
    Z = 'ZeroE'
    iZ = substitute(exZ.conclusion.body, exZ.conclusion.var, V(Z))
    ctxZ = ctxA + (iZ,)
    hz = _assume(iZ, ctxZ)
    exM = hz
    assert isinstance(exM.conclusion, Exists)
    M = 'MulE'
    iM = substitute(exM.conclusion.body, exM.conclusion.var, V(M))
    ctxM = ctxZ + (iM,)
    hbody = _assume(iM, ctxM)
    hSucc = _and_l(hbody)
    r1 = _and_r(hbody)
    addRec = _and_l(r1)
    r2 = _and_r(r1)
    emptyZ = _and_l(r2)
    r3 = _and_r(r2)
    Zw = _and_l(r3)
    mulRec = _and_r(r3)
    mulFun = _and_l(mulRec)
    closed = _and_r(_and_l(_weaken(om, ctxM)))
    q1 = _forall_elim(closed, Z)
    exO = _imp_elim(q1, _weaken(Zw, ctxM))
    assert isinstance(exO.conclusion, Exists)
    O = 'OneE'
    iO = substitute(exO.conclusion.body, exO.conclusion.var, V(O))
    ctxO = ctxM + (iO,)
    ho = _assume(iO, ctxO)
    Ow = _and_l(ho)
    succOZ = _and_r(ho)
    rp = _weaken(recursion_pf, ctxO)
    for nm in ['w', 'w', O, M]:
        rp = _forall_elim(rp, nm)
    rb = rp.conclusion.left
    rt = Proof('and_intro', rb.right, ctxO, (_weaken(Ow, ctxO), _weaken(mulFun, ctxO)))
    ra = Proof('and_intro', rb, ctxO, (_weaken(om, ctxO), rt))
    exE = _imp_elim(rp, ra)
    assert isinstance(exE.conclusion, Exists)
    E = 'ExpE'
    iE = substitute(exE.conclusion.body, exE.conclusion.var, V(E))
    ctxE = ctxO + (iE,)
    he = _assume(iE, ctxE)
    expRec = _and_l(he)
    body = target.body.body.body.body.body.body
    inst = body
    for nm, val in [('g', G), ('add', A), ('z0', Z), ('mul', M), ('one', O), ('exp', E)]:
        inst = substitute(inst, nm, V(val))
    t6 = Proof('and_intro', inst.right.right.right.right.right, ctxE, (_weaken(Ow, ctxE), expRec))
    t5 = Proof('and_intro', inst.right.right.right.right, ctxE, (_weaken(succOZ, ctxE), t6))
    t4 = Proof('and_intro', inst.right.right.right, ctxE, (_weaken(mulRec, ctxE), t5))
    t3 = Proof('and_intro', inst.right.right, ctxE, (_weaken(Zw, ctxE), t4))
    t2 = Proof('and_intro', inst.right, ctxE, (_weaken(emptyZ, ctxE), t3))
    t_one = Proof('and_intro', inst.right.right.right.right.right.right, ctxE, (_weaken(Ow, ctxE), expRec))
    t_succ = Proof('and_intro', inst.right.right.right.right.right, ctxE, (_weaken(succOZ, ctxE), t_one))
    t_mul = Proof('and_intro', inst.right.right.right.right, ctxE, (_weaken(mulRec, ctxE), t_succ))
    t_memz = Proof('and_intro', inst.right.right.right, ctxE, (_weaken(Zw, ctxE), t_mul))
    t_empty = Proof('and_intro', inst.right.right, ctxE, (_weaken(emptyZ, ctxE), t_memz))
    t_add = Proof('and_intro', inst.right, ctxE, (_weaken(addRec, ctxE), t_empty))
    allb = Proof('and_intro', inst, ctxE, (_weaken(hSucc, ctxE), t_add))
    tG = substitute(target.body, target.var, V(G))
    tA = substitute(tG.body, tG.var, V(A))
    tZ = substitute(tA.body, tA.var, V(Z))
    tM = substitute(tZ.body, tZ.var, V(M))
    tO = substitute(tM.body, tM.var, V(O))
    eE = Proof('exists_intro', tO, ctxE, (allb,), (('term', {'var': E}),))
    aE = Proof('exists_elim', tO, ctxO, (exE, eE), (('eigenvar', E),))
    eO = Proof('exists_intro', tM, ctxO, (aE,), (('term', {'var': O}),))
    aO = Proof('exists_elim', tM, ctxM, (exO, eO), (('eigenvar', O),))
    eM = Proof('exists_intro', tZ, ctxM, (aO,), (('term', {'var': M}),))
    aM = Proof('exists_elim', tZ, ctxZ, (exM, eM), (('eigenvar', M),))
    eZ = Proof('exists_intro', tA, ctxZ, (aM,), (('term', {'var': Z}),))
    aZ = Proof('exists_elim', tA, ctxA, (exZ, eZ), (('eigenvar', Z),))
    eA = Proof('exists_intro', tG, ctxA, (aZ,), (('term', {'var': A}),))
    aA = Proof('exists_elim', tG, ctxG, (exA, eA), (('eigenvar', A),))
    eG = Proof('exists_intro', target, ctxG, (aA,), (('term', {'var': G}),))
    aG = Proof('exists_elim', target, ctx, (exG, eG), (('eigenvar', G),))
    imp = Proof('imp_intro', core, (), (aG,))
    qm = Proof('forall_intro', goal.body, (), (imp,))
    return Proof('forall_intro', goal, (), (qm,))

def build_pass009_arithmetic_library(schema_prefix: tuple[SchemaInstance, ...]=()) -> tuple[CertifiedStatement, ...]:
    from .history_library import build_pass008_library
    offset = len(schema_prefix)
    schemas = tuple(schema_prefix) + PASS009_SCHEMA_INSTANCES
    k = ZFCKernel(schemas)
    base = list(build_pass008_library(schema_prefix))
    rec = build_omega_recursion_exists_unique()
    succ = build_successor_function_exists(offset + 10)
    suq = build_successor_function_unique()
    add = build_addition_section_exists_unique(succ, rec)
    acan = build_addition_section_canonical(suq)
    mulmod = build_multiplication_from_addition(rec)
    expmod = build_exponentiation_from_multiplication(rec)
    laws = [build_addition_zero_law(), build_addition_successor_law(), build_multiplication_zero_law(), build_multiplication_successor_law(), build_exponentiation_zero_law(), build_exponentiation_successor_law()]
    extras = [('ZFC_OMEGA_SUCCESSOR_FUNCTION_EXISTS', 'theorem', succ), ('ZFC_OMEGA_SUCCESSOR_FUNCTION_UNIQUE', 'lemma', suq), ('ZFC_NATURAL_ADDITION_SECTION_EXISTS_UNIQUE', 'theorem', add), ('ZFC_NATURAL_ADDITION_SECTION_CANONICAL', 'corollary', acan), ('ZFC_NATURAL_MULTIPLICATION_FROM_ADDITION_EXISTS_UNIQUE', 'theorem', mulmod), ('ZFC_NATURAL_EXPONENTIATION_FROM_MULTIPLICATION_EXISTS_UNIQUE', 'theorem', expmod), ('ZFC_ADDITION_ZERO_LAW', 'lemma', laws[0]), ('ZFC_ADDITION_SUCCESSOR_LAW', 'lemma', laws[1]), ('ZFC_MULTIPLICATION_ZERO_LAW', 'lemma', laws[2]), ('ZFC_MULTIPLICATION_SUCCESSOR_LAW', 'lemma', laws[3]), ('ZFC_EXPONENTIATION_ZERO_LAW', 'lemma', laws[4]), ('ZFC_EXPONENTIATION_SUCCESSOR_LAW', 'lemma', laws[5])]
    for name, kind, p in extras:
        kr = k.verify(p)
        if not kr.ok:
            raise ValueError(f'PASS009_KERNEL_REJECT:{name}:{kr.detail}')
        base.append(CertifiedStatement(p, name=name, kind=kind, source='PASS009_NATURAL_ARITHMETIC'))
    return tuple(base)

def _preverified_pass009(records):
    return tuple((NormalizedLibraryEntry(r.proof, r.identity, (r.name,) if r.name else (), (str(r.kind),) if r.kind else ()) for r in records))

def multiplication_from_addition_formula() -> Formula:
    om = OmegaSpec(V('w'), 'j', 'k')
    addRec = RecursionCandidateSpec(V('add'), V('w'), V('w'), V('m'), V('g'), 'za', 'na', 'sa', 'xa', 'ya')
    prem = And(om, And(Mem(V('m'), V('w')), And(SuccessorFunctionSpec(V('g'), V('w'), 'sx', 'sy'), And(addRec, And(EmptySpec(V('z0'), 'ez'), Mem(V('z0'), V('w')))))))
    cand = RecursionCandidateSpec(V('mul'), V('w'), V('w'), V('z0'), V('add'), 'zm', 'nm', 'sm', 'xm', 'ym')
    uniq = Forall('h', Imp(RecursionCandidateSpec(V('h'), V('w'), V('w'), V('z0'), V('add'), 'zh', 'nh', 'sh', 'xh', 'yh'), Eq(V('h'), V('mul'))))
    return Forall('w', Forall('m', Forall('g', Forall('add', Forall('z0', Imp(prem, Exists('mul', And(cand, uniq))))))))

def build_multiplication_from_addition(recursion_pf: Proof | None=None) -> Proof:
    recursion_pf = recursion_pf or build_omega_recursion_exists_unique()
    goal = multiplication_from_addition_formula()
    core = goal.body.body.body.body.body
    prem = core.left
    target = core.right
    ctx = (prem,)
    hp = _assume(prem, ctx)
    om = _and_l(hp)
    r1 = _and_r(hp)
    mw = _and_l(r1)
    r2 = _and_r(r1)
    hSucc = _and_l(r2)
    r3 = _and_r(r2)
    addRec = _and_l(r3)
    zr = _and_r(r3)
    emptyZ = _and_l(zr)
    Zw = _and_r(zr)
    addFun = _and_l(addRec)
    rr = _weaken(recursion_pf, ctx)
    for nm in ['w', 'w', 'z0', 'add']:
        rr = _forall_elim(rr, nm)
    rb = rr.conclusion.left
    tail = Proof('and_intro', rb.right, ctx, (Zw, addFun))
    ante = Proof('and_intro', rb, ctx, (om, tail))
    out = _imp_elim(rr, ante)
    p = Proof('imp_intro', core, (), (out,))
    qz = Proof('forall_intro', goal.body.body.body.body, (), (p,))
    qa = Proof('forall_intro', goal.body.body.body, (), (qz,))
    qg = Proof('forall_intro', goal.body.body, (), (qa,))
    qm = Proof('forall_intro', goal.body, (), (qg,))
    return Proof('forall_intro', goal, (), (qm,))

def exponentiation_from_multiplication_formula() -> Formula:
    om = OmegaSpec(V('w'), 'j', 'k')
    addRec = RecursionCandidateSpec(V('add'), V('w'), V('w'), V('m'), V('g'), 'za', 'na', 'sa', 'xa', 'ya')
    mulRec = RecursionCandidateSpec(V('mul'), V('w'), V('w'), V('z0'), V('add'), 'zm', 'nm', 'sm', 'xm', 'ym')
    prem = And(om, And(Mem(V('m'), V('w')), And(SuccessorFunctionSpec(V('g'), V('w'), 'sx', 'sy'), And(addRec, And(EmptySpec(V('z0'), 'ez'), And(Mem(V('z0'), V('w')), And(mulRec, And(SuccessorSpec(V('one'), V('z0'), 'uo'), Mem(V('one'), V('w'))))))))))
    cand = RecursionCandidateSpec(V('exp'), V('w'), V('w'), V('one'), V('mul'), 'ze', 'ne', 'se', 'xe', 'ye')
    uniq = Forall('h', Imp(RecursionCandidateSpec(V('h'), V('w'), V('w'), V('one'), V('mul'), 'zh', 'nh', 'sh', 'xh', 'yh'), Eq(V('h'), V('exp'))))
    return Forall('w', Forall('m', Forall('g', Forall('add', Forall('z0', Forall('mul', Forall('one', Imp(prem, Exists('exp', And(cand, uniq))))))))))

def build_exponentiation_from_multiplication(recursion_pf: Proof | None=None) -> Proof:
    recursion_pf = recursion_pf or build_omega_recursion_exists_unique()
    goal = exponentiation_from_multiplication_formula()
    q = goal
    for _ in range(7):
        q = q.body
    core = q
    prem = core.left
    ctx = (prem,)
    hp = _assume(prem, ctx)
    om = _and_l(hp)
    r1 = _and_r(hp)
    mw = _and_l(r1)
    r2 = _and_r(r1)
    hSucc = _and_l(r2)
    r3 = _and_r(r2)
    addRec = _and_l(r3)
    r4 = _and_r(r3)
    emptyZ = _and_l(r4)
    r5 = _and_r(r4)
    Zw = _and_l(r5)
    r6 = _and_r(r5)
    mulRec = _and_l(r6)
    oneTail = _and_r(r6)
    succOne = _and_l(oneTail)
    oneW = _and_r(oneTail)
    mulFun = _and_l(mulRec)
    rr = _weaken(recursion_pf, ctx)
    for nm in ['w', 'w', 'one', 'mul']:
        rr = _forall_elim(rr, nm)
    rb = rr.conclusion.left
    tail = Proof('and_intro', rb.right, ctx, (oneW, mulFun))
    ante = Proof('and_intro', rb, ctx, (om, tail))
    out = _imp_elim(rr, ante)
    p = Proof('imp_intro', core, (), (out,))
    bodies = []
    z = goal
    while isinstance(z, Forall):
        bodies.append(z)
        z = z.body
    for b in reversed(bodies):
        p = Proof('forall_intro', b, (), (p,))
    return p

def successor_function_unique_formula() -> Formula:
    prem = And(OmegaSpec(V('w'), 'j', 'k'), And(SuccessorFunctionSpec(V('g'), V('w'), 'xg', 'yg'), SuccessorFunctionSpec(V('h'), V('w'), 'xh', 'yh')))
    return Forall('w', Forall('g', Forall('h', Imp(prem, Eq(V('g'), V('h'))))))

def build_successor_function_unique(function_ext_pf: Proof | None=None) -> Proof:
    from .recursion_library import CommonValueSpec, build_function_common_value_extensionality
    function_ext_pf = function_ext_pf or build_function_common_value_extensionality()
    goal = successor_function_unique_formula()
    core = goal.body.body.body
    prem = core.left
    ctx = (prem,)
    hp = _assume(prem, ctx)
    om = _and_l(hp)
    rest = _and_r(hp)
    sg = _and_l(rest)
    sh = _and_r(rest)
    gfun = _and_l(sg)
    hfun = _and_l(sh)
    gexact = _and_l(_and_r(sg))
    hexact = _and_l(_and_r(sh))
    cv = CommonValueSpec(V('g'), V('h'), V('w'), V('w'), 'x', 'y')
    x = cv.var
    ix = cv.body
    ctxX = ctx + (ix.left,)
    xw = _assume(ix.left, ctxX)
    closed = _and_r(_and_l(_weaken(om, ctxX)))
    qs = _forall_elim(closed, x)
    exY = _imp_elim(qs, xw)
    assert isinstance(exY.conclusion, Exists)
    Y = 'Ysuq'
    iY = substitute(exY.conclusion.body, exY.conclusion.var, V(Y))
    ctxY = ctxX + (iY,)
    hy = _assume(iY, ctxY)
    Yw = _and_l(hy)
    succ = _and_r(hy)

    def exact_value(exactpf: Proof) -> Proof:
        q = _weaken(exactpf, ctxY)
        q = _forall_elim(_forall_elim(q, x), Y)
        ante = q.conclusion.left
        r = Proof('and_intro', ante.right, ctxY, (_weaken(Yw, ctxY), _weaken(succ, ctxY)))
        a = Proof('and_intro', ante, ctxY, (_weaken(xw, ctxY), r))
        return _imp_elim(q, a)
    gvy = exact_value(gexact)
    hvy = exact_value(hexact)
    body = substitute(ix.right.body, ix.right.var, V(Y))
    pair = Proof('and_intro', body.right, ctxY, (gvy, hvy))
    cb = Proof('and_intro', body, ctxY, (_weaken(Yw, ctxY), pair))
    ey = Proof('exists_intro', ix.right, ctxY, (cb,), (('term', {'var': Y}),))
    aY = Proof('exists_elim', ix.right, ctxX, (exY, ey), (('eigenvar', Y),))
    iimp = Proof('imp_intro', ix, ctx, (aY,))
    cvpf = Proof('forall_intro', cv, ctx, (iimp,))
    fe = _weaken(function_ext_pf, ctx)
    for nm in ['g', 'h', 'w', 'w']:
        fe = _forall_elim(fe, nm)
    fante = fe.conclusion.left
    rr = Proof('and_intro', fante.right, ctx, (hfun, cvpf))
    aa = Proof('and_intro', fante, ctx, (gfun, rr))
    eq = _imp_elim(fe, aa)
    ip = Proof('imp_intro', core, (), (eq,))
    qh = Proof('forall_intro', goal.body.body, (), (ip,))
    qg = Proof('forall_intro', goal.body, (), (qh,))
    return Proof('forall_intro', goal, (), (qg,))

def addition_section_canonical_formula() -> Formula:
    om = OmegaSpec(V('w'), 'j', 'k')
    mw = Mem(V('m'), V('w'))
    sg = SuccessorFunctionSpec(V('g'), V('w'), 'xg', 'yg')
    rf = RecursionCandidateSpec(V('f'), V('w'), V('w'), V('m'), V('g'), 'zf', 'nf', 'sf', 'xf', 'yf')
    sg2 = SuccessorFunctionSpec(V('g2'), V('w'), 'x2', 'y2')
    rh = RecursionCandidateSpec(V('h'), V('w'), V('w'), V('m'), V('g2'), 'zh', 'nh', 'sh', 'xh', 'yh')
    prem = And(om, And(mw, And(sg, And(rf, And(sg2, rh)))))
    return Forall('w', Forall('m', Forall('g', Forall('f', Forall('g2', Forall('h', Imp(prem, Eq(V('f'), V('h')))))))))

def build_addition_section_canonical(succ_unique_pf: Proof | None=None, recursion_unique_pf: Proof | None=None) -> Proof:
    from .recursion_library import build_omega_recursion_uniqueness
    succ_unique_pf = succ_unique_pf or build_successor_function_unique()
    recursion_unique_pf = recursion_unique_pf or build_omega_recursion_uniqueness()
    goal = addition_section_canonical_formula()
    q = goal
    for _ in range(6):
        q = q.body
    core = q
    prem = core.left
    ctx = (prem,)
    hp = _assume(prem, ctx)
    om = _and_l(hp)
    r1 = _and_r(hp)
    mw = _and_l(r1)
    r2 = _and_r(r1)
    sg = _and_l(r2)
    r3 = _and_r(r2)
    rf = _and_l(r3)
    r4 = _and_r(r3)
    sg2 = _and_l(r4)
    rh = _and_r(r4)
    su = _weaken(succ_unique_pf, ctx)
    for nm in ['w', 'g', 'g2']:
        su = _forall_elim(su, nm)
    suprem = su.conclusion.left
    sub = Proof('and_intro', suprem.right, ctx, (sg, sg2))
    sua = Proof('and_intro', suprem, ctx, (om, sub))
    eqg = _imp_elim(su, sua)
    rhg_concl = substitute(rh.conclusion, 'g2', V('g'))
    rhg = Proof('eq_subst', rhg_concl, ctx, (eqg, rh), (('direction', 'rl'),))
    ru = _weaken(recursion_unique_pf, ctx)
    for nm in ['w', 'w', 'm', 'g', 'f', 'h']:
        ru = _forall_elim(ru, nm)
    rp = ru.conclusion.left
    tail = Proof('and_intro', rp.right.right.right, ctx, (rf, rhg))
    mid = Proof('and_intro', rp.right.right, ctx, (_and_l(sg), tail))
    rmid = Proof('and_intro', rp.right, ctx, (mw, mid))
    allp = Proof('and_intro', rp, ctx, (om, rmid))
    eq = _imp_elim(ru, allp)
    p = Proof('imp_intro', core, (), (eq,))
    bodies = []
    z = goal
    while isinstance(z, Forall):
        bodies.append(z)
        z = z.body
    for b in reversed(bodies):
        p = Proof('forall_intro', b, (), (p,))
    return p

def addition_zero_law_formula() -> Formula:
    rec = RecursionCandidateSpec(V('f'), V('w'), V('w'), V('m'), V('g'), 'z', 'n', 's', 'x', 'y')
    return Forall('f', Forall('w', Forall('m', Forall('g', Forall('z0', Imp(And(rec, EmptySpec(V('z0'), 'u0')), GraphValueSpec(V('f'), V('z0'), V('m'), 'p0')))))))

def build_addition_zero_law() -> Proof:
    goal = addition_zero_law_formula()
    q = goal
    for _ in range(5):
        q = q.body
    core = q
    prem = core.left
    ctx = (prem,)
    hp = _assume(prem, ctx)
    rec = _and_l(hp)
    emp = _and_r(hp)
    init = _and_l(_and_r(rec))
    qi = _forall_elim(init, 'z0')
    out = _imp_elim(qi, emp)
    p = Proof('imp_intro', core, (), (out,))
    bodies = []
    z = goal
    while isinstance(z, Forall):
        bodies.append(z)
        z = z.body
    for b in reversed(bodies):
        p = Proof('forall_intro', b, (), (p,))
    return p

def addition_successor_law_formula() -> Formula:
    rec = RecursionCandidateSpec(V('f'), V('w'), V('w'), V('m'), V('g'), 'z', 'n', 's', 'x', 'y')
    sg = SuccessorFunctionSpec(V('g'), V('w'), 'a', 'b')
    ante = And(rec, And(sg, And(Mem(V('n0'), V('w')), And(Mem(V('s0'), V('w')), And(SuccessorSpec(V('s0'), V('n0'), 'us'), And(GraphValueSpec(V('f'), V('n0'), V('x0'), 'pn'), And(Mem(V('y0'), V('w')), SuccessorSpec(V('y0'), V('x0'), 'uy'))))))))
    return Forall('f', Forall('w', Forall('m', Forall('g', Forall('n0', Forall('s0', Forall('x0', Forall('y0', Imp(ante, GraphValueSpec(V('f'), V('s0'), V('y0'), 'ps'))))))))))

def build_addition_successor_law() -> Proof:
    goal = addition_successor_law_formula()
    q = goal
    for _ in range(8):
        q = q.body
    core = q
    prem = core.left
    ctx = (prem,)
    hp = _assume(prem, ctx)
    rec = _and_l(hp)
    r1 = _and_r(hp)
    sg = _and_l(r1)
    r2 = _and_r(r1)
    nw = _and_l(r2)
    r3 = _and_r(r2)
    sw = _and_l(r3)
    r4 = _and_r(r3)
    succsn = _and_l(r4)
    r5 = _and_r(r4)
    gvfn = _and_l(r5)
    r6 = _and_r(r5)
    yw = _and_l(r6)
    succyx = _and_r(r6)
    exact = _and_l(_and_r(sg))
    qe = _forall_elim(_forall_elim(exact, 'x0'), 'y0')
    ea = qe.conclusion.left
    er = Proof('and_intro', ea.right, ctx, (yw, succyx))
    eall = Proof('and_intro', ea, ctx, ((_graph_value_domain_local := (Proof('eq_refl', Eq(V('dummy'), V('dummy')), ctx) if False else None)), er))
    gfun = _and_l(sg)
    total = _and_l(_and_r(gfun))
    qtot = _forall_elim(total, 'x0')
    from .history_library import _graph_value_codomain
    xw = _graph_value_codomain(_and_l(rec), 'f', 'n0', 'x0', gvfn, build_ordered_pair_injective(), ctx)
    exgy = _imp_elim(qtot, xw)
    assert isinstance(exgy.conclusion, Exists)
    Y = 'YaddLaw'
    iY = substitute(exgy.conclusion.body, exgy.conclusion.var, V(Y))
    ctxY = ctx + (iY,)
    hY = _assume(iY, ctxY)
    Yw = _and_l(hY)
    gvG = _and_r(hY)
    sound = _and_r(_and_r(_weaken(sg, ctxY)))
    qs = _forall_elim(_forall_elim(sound, 'x0'), Y)
    succYx = _imp_elim(qs, gvG)
    su = build_successor_unique()
    su = _weaken(su, ctxY)
    for nm in ['x0', Y, 'y0']:
        su = _forall_elim(su, nm)
    eqYy = _imp_elim(su, Proof('and_intro', su.conclusion.left, ctxY, (succYx, _weaken(succyx, ctxY))))
    gvGy = Proof('eq_subst', GraphValueSpec(V('g'), V('x0'), V('y0'), 'pg'), ctxY, (eqYy, gvG), (('direction', 'lr'),))
    step = _and_r(_and_r(_weaken(rec, ctxY)))
    qsrec = step
    for nm in ['n0', 's0', 'x0', 'y0']:
        qsrec = _forall_elim(qsrec, nm)
    a = qsrec.conclusion.left
    last = Proof('and_intro', a.right.right.right, ctxY, (_weaken(gvfn, ctxY), gvGy))
    c2 = Proof('and_intro', a.right.right, ctxY, (_weaken(succsn, ctxY), last))
    c1 = Proof('and_intro', a.right, ctxY, (_weaken(sw, ctxY), c2))
    aa = Proof('and_intro', a, ctxY, (_weaken(nw, ctxY), c1))
    out = _imp_elim(qsrec, aa)
    afterY = Proof('exists_elim', core.right, ctx, (exgy, out), (('eigenvar', Y),))
    p = Proof('imp_intro', core, (), (afterY,))
    bodies = []
    z = goal
    while isinstance(z, Forall):
        bodies.append(z)
        z = z.body
    for b in reversed(bodies):
        p = Proof('forall_intro', b, (), (p,))
    return p

def multiplication_zero_law_formula() -> Formula:
    rec = RecursionCandidateSpec(V('mul'), V('w'), V('w'), V('z0'), V('add'), 'z', 'n', 's', 'x', 'y')
    return Forall('mul', Forall('w', Forall('z0', Forall('add', Imp(And(rec, EmptySpec(V('z0'), 'u')), GraphValueSpec(V('mul'), V('z0'), V('z0'), 'p'))))))

def build_multiplication_zero_law() -> Proof:
    goal = multiplication_zero_law_formula()
    q = goal
    for _ in range(4):
        q = q.body
    core = q
    ctx = (core.left,)
    hp = _assume(core.left, ctx)
    rec = _and_l(hp)
    emp = _and_r(hp)
    init = _and_l(_and_r(rec))
    out = _imp_elim(_forall_elim(init, 'z0'), emp)
    p = Proof('imp_intro', core, (), (out,))
    bodies = []
    z = goal
    while isinstance(z, Forall):
        bodies.append(z)
        z = z.body
    for b in reversed(bodies):
        p = Proof('forall_intro', b, (), (p,))
    return p

def exponentiation_zero_law_formula() -> Formula:
    rec = RecursionCandidateSpec(V('exp'), V('w'), V('w'), V('one'), V('mul'), 'z', 'n', 's', 'x', 'y')
    return Forall('exp', Forall('w', Forall('one', Forall('mul', Forall('z0', Imp(And(rec, EmptySpec(V('z0'), 'u')), GraphValueSpec(V('exp'), V('z0'), V('one'), 'p')))))))

def build_exponentiation_zero_law() -> Proof:
    goal = exponentiation_zero_law_formula()
    q = goal
    for _ in range(5):
        q = q.body
    core = q
    ctx = (core.left,)
    hp = _assume(core.left, ctx)
    rec = _and_l(hp)
    emp = _and_r(hp)
    init = _and_l(_and_r(rec))
    out = _imp_elim(_forall_elim(init, 'z0'), emp)
    p = Proof('imp_intro', core, (), (out,))
    bodies = []
    z = goal
    while isinstance(z, Forall):
        bodies.append(z)
        z = z.body
    for b in reversed(bodies):
        p = Proof('forall_intro', b, (), (p,))
    return p

def multiplication_successor_law_formula() -> Formula:
    rec = RecursionCandidateSpec(V('mul'), V('w'), V('w'), V('z0'), V('add'), 'z', 'n', 's', 'x', 'y')
    ante = And(rec, And(Mem(V('n0'), V('w')), And(Mem(V('s0'), V('w')), And(SuccessorSpec(V('s0'), V('n0'), 'u'), And(GraphValueSpec(V('mul'), V('n0'), V('x0'), 'pn'), GraphValueSpec(V('add'), V('x0'), V('y0'), 'pg'))))))
    return Forall('mul', Forall('w', Forall('z0', Forall('add', Forall('n0', Forall('s0', Forall('x0', Forall('y0', Imp(ante, GraphValueSpec(V('mul'), V('s0'), V('y0'), 'ps'))))))))))

def build_multiplication_successor_law() -> Proof:
    goal = multiplication_successor_law_formula()
    q = goal
    for _ in range(8):
        q = q.body
    core = q
    ctx = (core.left,)
    hp = _assume(core.left, ctx)
    rec = _and_l(hp)
    r1 = _and_r(hp)
    nw = _and_l(r1)
    r2 = _and_r(r1)
    sw = _and_l(r2)
    r3 = _and_r(r2)
    succ = _and_l(r3)
    vals = _and_r(r3)
    gvf = _and_l(vals)
    gvg = _and_r(vals)
    step = _and_r(_and_r(rec))
    qs = step
    for nm in ['n0', 's0', 'x0', 'y0']:
        qs = _forall_elim(qs, nm)
    a = qs.conclusion.left
    last = Proof('and_intro', a.right.right.right, ctx, (gvf, gvg))
    c2 = Proof('and_intro', a.right.right, ctx, (succ, last))
    c1 = Proof('and_intro', a.right, ctx, (sw, c2))
    aa = Proof('and_intro', a, ctx, (nw, c1))
    out = _imp_elim(qs, aa)
    p = Proof('imp_intro', core, (), (out,))
    bodies = []
    z = goal
    while isinstance(z, Forall):
        bodies.append(z)
        z = z.body
    for b in reversed(bodies):
        p = Proof('forall_intro', b, (), (p,))
    return p

def exponentiation_successor_law_formula() -> Formula:
    rec = RecursionCandidateSpec(V('exp'), V('w'), V('w'), V('one'), V('mul'), 'z', 'n', 's', 'x', 'y')
    ante = And(rec, And(Mem(V('n0'), V('w')), And(Mem(V('s0'), V('w')), And(SuccessorSpec(V('s0'), V('n0'), 'u'), And(GraphValueSpec(V('exp'), V('n0'), V('x0'), 'pn'), GraphValueSpec(V('mul'), V('x0'), V('y0'), 'pg'))))))
    return Forall('exp', Forall('w', Forall('one', Forall('mul', Forall('n0', Forall('s0', Forall('x0', Forall('y0', Imp(ante, GraphValueSpec(V('exp'), V('s0'), V('y0'), 'ps'))))))))))

def build_exponentiation_successor_law() -> Proof:
    goal = exponentiation_successor_law_formula()
    q = goal
    for _ in range(8):
        q = q.body
    core = q
    ctx = (core.left,)
    hp = _assume(core.left, ctx)
    rec = _and_l(hp)
    r1 = _and_r(hp)
    nw = _and_l(r1)
    r2 = _and_r(r1)
    sw = _and_l(r2)
    r3 = _and_r(r2)
    succ = _and_l(r3)
    vals = _and_r(r3)
    gvf = _and_l(vals)
    gvg = _and_r(vals)
    step = _and_r(_and_r(rec))
    qs = step
    for nm in ['n0', 's0', 'x0', 'y0']:
        qs = _forall_elim(qs, nm)
    a = qs.conclusion.left
    last = Proof('and_intro', a.right.right.right, ctx, (gvf, gvg))
    c2 = Proof('and_intro', a.right.right, ctx, (succ, last))
    c1 = Proof('and_intro', a.right, ctx, (sw, c2))
    aa = Proof('and_intro', a, ctx, (nw, c1))
    out = _imp_elim(qs, aa)
    p = Proof('imp_intro', core, (), (out,))
    bodies = []
    z = goal
    while isinstance(z, Forall):
        bodies.append(z)
        z = z.body
    for b in reversed(bodies):
        p = Proof('forall_intro', b, (), (p,))
    return p
