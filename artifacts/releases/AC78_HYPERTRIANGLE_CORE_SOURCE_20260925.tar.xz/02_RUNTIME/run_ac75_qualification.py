from __future__ import annotations
import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver
from universal_constraint_compiler import UniversalConstraintLedger


def main():
    fixture=json.loads((ROOT/'04_FIXTURES'/'GOLD_STANDARD_724_RULES_CONSTRAINT_FIXTURE.json').read_text())
    seeds=[]
    for row in fixture['rules']:
        seeds.append(Node('PROBLEM',{
            'rule_id':str(row['rule_id']), 'rule_text':row['text'],
            'cake':'NORMATIVE_GOVERNANCE_RULE','plate':'SOFTWARE_AGENT_PROJECT_GOVERNANCE',
            'authority':'GOLD_STANDARD_DECLARED_RULESET'
        },context=('AC75','GOLD_STANDARD',str(row['rule_id']))))
    solver=SovereignSolver()
    # Core-only corpus pass: AC75 compiles the entire corpus before ALL-AUX dispatch.
    # max_calls=0 intentionally stops at the first ALL-AUX call after all 724 core routes are materialized.
    result=solver.solve_universal(seeds,max_waves=1,max_calls=0)
    receipts=[n for n in solver.engine.known.values() if n.kind=='CAUSAL_GRID_CONSTRAINT_RECEIPT']
    operators={}
    zero_credit=True
    for n in receipts:
        rule=n.payload.get('constraint_rule') or {}
        op=str(rule.get('operator'))
        operators[op]=operators.get(op,0)+1
        zero_credit = zero_credit and n.payload.get('truth_credit_added')==0 and n.payload.get('external_scientific_truth_certified') is False

    # Small end-to-end ALL-AUX smoke over representative rules, proving the new carrier coexists with the 99 mechanisms.
    smoke_solver=SovereignSolver()
    smoke=smoke_solver.solve_universal(seeds[:8],max_waves=1,max_calls=5000)

    # Independent conflict/precedence negative control.
    led=UniversalConstraintLedger(); base={'kind':'UNIVERSAL_CONSTRAINT_RULE','scope':'S','condition':None,'target':'T','constraint_key':'K'}
    led.register({**base,'rule_id':'LOW','operator':'REQUIRE','precedence':1})
    high=led.register({**base,'rule_id':'HIGH','operator':'PROHIBIT','precedence':10})
    led2=UniversalConstraintLedger(); led2.register({**base,'rule_id':'A','operator':'REQUIRE'})
    open_conflict=led2.register({**base,'rule_id':'B','operator':'PROHIBIT'})

    checks={
        'all_724_constraint_receipts':len(receipts)==724,
        'all_724_auto_extracted':result.get('causal_grid_auto_extracted_count')==724,
        'zero_auto_unresolved':result.get('causal_grid_auto_unresolved_count')==0,
        'all_724_constraint_compiled':result.get('causal_grid_constraint_compiled_count')==724,
        'all_724_structural_closed':result.get('causal_grid_constraint_closed_count')==724,
        'no_constraint_open':result.get('causal_grid_constraint_open_count')==0,
        'root_not_falsely_certified':not result.get('solution_certified') and not result.get('formal_proof_verified'),
        'rule_carrier_adds_zero_truth_credit':zero_credit,
        'math_all_aux_registry_preserved':result.get('active_mechanism_count')==99 and smoke.get('active_mechanism_count')==99,
        'representative_rules_survive_full_all_aux_smoke':smoke.get('execution_calls',0)>=8*99,
        'explicit_precedence_resolves':high.get('status')=='ACTIVE' and high.get('overrides')==['LOW'],
        'missing_precedence_stays_open':open_conflict.get('status')=='CONFLICT_OPEN',
        'world_flags_active':bool((result.get('world') or {}).get('ac75_universal_constraint_carrier')) and bool((result.get('world') or {}).get('causal_grid_no_invented_metric')),
    }
    out={
        'schema':'AC75_UNIVERSAL_CONSTRAINT_CARRIER_QUALIFICATION_V1',
        'source_fixture_schema':fixture.get('schema'),'rule_count':len(fixture['rules']),
        'checks':checks,'check_count':len(checks),'pass_count':sum(bool(x) for x in checks.values()),'pass':all(checks.values()),
        'solver_summary':{
            'schema':result.get('schema'),'run_state':result.get('run_state'),'execution_calls':result.get('execution_calls'),
            'known_node_count':result.get('known_node_count'),'constraint_receipts':len(receipts),
            'auto_extracted':result.get('causal_grid_auto_extracted_count'),'auto_unresolved':result.get('causal_grid_auto_unresolved_count'),
            'constraint_compiled':result.get('causal_grid_constraint_compiled_count'),'constraint_closed':result.get('causal_grid_constraint_closed_count'),
            'constraint_open':result.get('causal_grid_constraint_open_count'),'constraint_semantic_residues':result.get('causal_grid_constraint_semantic_residue_count'),'constraint_ledger':result.get('causal_grid_constraint_ledger_counters'),
            'active_mechanisms':result.get('active_mechanism_count'),'solution_certified':result.get('solution_certified'),
            'formal_proof_verified':result.get('formal_proof_verified')
        },
        'all_aux_smoke_summary':{'seed_count':8,'execution_calls':smoke.get('execution_calls'),'run_state':smoke.get('run_state'),'active_mechanisms':smoke.get('active_mechanism_count'),'constraint_receipts':smoke.get('causal_grid_constraint_receipt_count')},
        'operator_histogram':dict(sorted(operators.items())),
        'negative_controls':{'explicit_precedence':high,'missing_precedence':open_conflict},
    }
    print(json.dumps(out,indent=2,ensure_ascii=False))

if __name__=='__main__': main()
