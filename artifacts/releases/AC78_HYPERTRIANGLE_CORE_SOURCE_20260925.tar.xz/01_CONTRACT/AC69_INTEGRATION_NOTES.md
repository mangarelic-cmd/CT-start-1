# AC69 Causal Grid Core integration

AC69 promotes the CP015/CP016 CAKE/PLATE + typed route/grid logic from an optional research mechanism to a pre-AUX core service.

Pipeline:

ROOT -> CAUSAL_GRID_CORE -> ALL AUX -> CORRELATION -> ROUTER -> RETURN

The core is non-blocking. Untyped nodes generate typing currents while the original node continues through full discovery. Metric coordinates remain symbolic unless grounded weights are supplied. Structural mirrors are never promoted to causal inverses without a domain-specific certificate.
