# SOLUTION CAUSALE — PROTOCOLE MAÎTRE DE RÉSOLUTION DE PROBLÈMES
## Texte de démarrage à lire avant toute nouvelle recherche ou reprise de recherche

**Version de méthode : 20 septembre 2026**  
**Statut : doctrine opérationnelle de travail — à appliquer avant toute analyse du problème particulier**  
**But : empêcher le retour aux erreurs de méthode déjà identifiées pendant les recherches Collatz, Mahler/Lehmer et les mises à jour AC.**

---

# 0. INSTRUCTION PRIORITAIRE À L’ASSISTANT

Lis ce document **entièrement avant de commencer la recherche**.

Ne repars pas automatiquement dans une méthode classique séquentielle du type :

```text
problème
→ choisir une piste
→ sous-problème
→ sous-sous-problème
→ blocage
→ inventer une autre piste
```

La méthode de la Solution causale est différente.

La règle centrale est :

```text
OBJET / QUESTION SOUVERAINE
→ ÉTAT ACTUEL COMPLET
→ Δ COMPLET VERS L’ÉTAT FERMÉ
→ TOUTES LES AUX / TOUS LES OUTILS / TOUTES LES REPRÉSENTATIONS
→ CORRÉLATION ET RECOMBINAISON
→ TRAJET CAUSAL
→ SIN1
→ SIN2 PAR QUADRATURE / RETOUR
→ COS / FERMETURE
→ RETURN AU MÊME OBJET SOUVERAIN
→ REMESURE
→ REBOUCLAGE SI RÉSIDU
```

Tout résultat négatif, toute impasse locale, toute sortie inutilisable immédiatement, toute route réfutée et toute représentation abandonnée doivent être conservés dans **la peau du problème**. Rien de causalement appris n’est jeté.

Le système doit rester **universel au niveau sémantique**, pas seulement au niveau du routage logiciel.

Le nombre d’AUX ou de mécanismes n’est **jamais codé en dur dans cette méthode**. Il a changé au cours des versions AC. Toujours inspecter le registre de la version courante et utiliser **toutes les AUX réellement disponibles**.

---

# 1. LA QUESTION SOUVERAINE NE CHANGE JAMAIS

Une erreur répétée dans les recherches précédentes a été de laisser un sous-problème remplacer le problème.

C’est interdit.

Si la question est `Q`, alors `Q` reste l’objet souverain jusqu’au retour final :

```text
Q_current
→ transformations
→ routes
→ enfants
→ preuves locales
→ exclusions
→ coordonnées
→ Q_return
```

Un enfant n’est jamais la nouvelle racine.

Exemple abstrait incorrect :

```text
Q → A → B → C
et ensuite :
« le problème est maintenant C »
```

Correct :

```text
Q reste souverain.

A, B, C sont :
- des facteurs du Δ de Q ;
- des représentations de Q ;
- des routes dans Q ;
- des obligations locales de Q ;
- ou des informations ajoutées à la peau de Q.

Leurs résultats retournent toujours à Q.
```

Cette règle empêche la dérive où la recherche finit par résoudre parfaitement un objet qui n’est plus l’énoncé initial.

---

# 2. LE Δ COMPLET : DÉFINITION À NE PLUS CONFONDRE

Le Δ d’un objet n’est pas « le prochain petit truc à faire ».

Le Δ complet est :

\[
\boxed{
\Delta_{\mathrm{FULL}}(Q)
=
Q_{\mathrm{closed}}
-
Q_{\mathrm{current}}
}
\]

Autrement dit :

```text
FULL_DELTA(Q)
=
tout ce qui sépare encore
l’état actuel complet de Q
de son état fermé complet.
```

Si l’état actuel vaut conceptuellement 2 et l’état fermé 4, le Δ est 2. On ne choisit pas arbitrairement 0,2 sous prétexte que c’est plus facile à attaquer.

## 2.1 Les sous-obligations ne remplacent jamais le FULL_DELTA

Le FULL_DELTA peut être factorisé :

```text
FULL_DELTA(Q)
=
D1 ∧ D2 ∧ D3 ∧ ... ∧ Dn
```

Mais `D1`, `D2`, etc. restent des composantes du **même Δ complet**.

Si une composante est construite :

```text
D1 = acquis
```

alors elle devient une **supply** du même objet Q.

On ne dit pas :

```text
Q → D1 → D1a → D1b
donc le problème est maintenant D1b.
```

On dit :

```text
Q garde son identité
CURRENT_STATE(Q) s’enrichit de D1
FULL_DELTA(Q) est remesuré
les composantes réellement restantes sont attaquées
```

## 2.2 Ne pas confondre FULL_DELTA et « minimal delta »

Le « minimal delta » au sens de **plus petit pas local possible** n’est pas le Δ demandé par la Solution causale.

Quand l’utilisateur demande **le delta de l’objet**, il demande le **delta maximal de la solution minimale** :

\[
\boxed{
\Delta_Q^\star
=
\Phi_{\mathrm{solution\,première}}(Q)
-
\Phi_{\mathrm{current}}(Q)
}
\]

où \(\Phi_{\mathrm{solution\,première}}(Q)\) désigne le **premier champ de solution causalement admissible** pour la question souveraine \(Q\).

Autrement dit :

```text
DELTA demandé
≠ plus petit mouvement disponible
≠ prochaine micro-correction
≠ plus petit sous-problème
≠ minimal_delta du scheduler

DELTA demandé
= déplacement COMPLET nécessaire
  pour que l’équation / l’objet courant
  rejoigne le PREMIER CHAMP DE SOLUTION du problème.
```

C’est pour cela qu’il est appelé ici :

```text
DELTA MAXIMAL DE LA SOLUTION MINIMALE
```

- **solution minimale** = première solution / premier champ de solution admissible rencontré par la structure causale du problème ;
- **delta maximal** = déplacement total et complet nécessaire pour atteindre ce champ, en conservant toutes les dimensions nécessaires du déplacement ;
- ce « maximal » ne signifie pas « choisir la solution la plus lointaine » : il signifie **ne pas tronquer le déplacement total en petits pas artificiels**.

Exemple conceptuel :

```text
état actuel = 2
premier champ de solution = 4

FULL DELTA = 4 - 2 = 2
```

Il serait faux de demander successivement :

```text
0,1
puis 0,1
puis 0,2
...
```

et d’appeler chacun de ces petits pas « le delta du problème ».

Ces valeurs peuvent devenir des composantes, projections ou étapes d’exécution, mais le **delta souverain reste 2** tant que le champ de solution première n’est pas rejoint.

## 2.3 Comment déterminer ce delta

Le delta ne doit pas être deviné manuellement à partir d’un seul module.

Il est normalement reconstruit par la géométrie et la totalité du dispositif causal, notamment par combinaison de :

```text
QUESTION / SIN1
→ PRIME GRID / adresse de solution
→ TEMPORAL / position et ordre causal
→ CAUSAL SPACE / carrier
→ BABEL / BORGES / WHEEL si actifs
→ projections de toutes les AUX
→ équations / invariants / bornes / relations
→ triangulation 2SIN1COS
→ localisation du premier champ de solution
→ FULL DELTA
```

Prime Grid et Temporal ont ici un rôle central :

- **Prime Grid** aide à localiser l’adresse / la cellule / la direction du champ de solution première ;
- **Temporal** fixe l’ordre, la phase, le retour et la position causale de cette solution dans la trajectoire ;
- **la formule complète du problème et toutes les AUX** fournissent les coordonnées, contraintes et invariants nécessaires pour que le déplacement soit celui du problème réel, et non une distance inventée.

La règle pratique est donc :

```text
NE PAS demander :
« quel est le plus petit pas que je peux faire maintenant ? »

DEMANDER :
« quel est le déplacement complet qui amène l’état actuel
au premier champ de solution causalement admissible ? »
```

Puis seulement :

```text
FULL DELTA
→ décomposition en composantes si nécessaire
→ toutes les AUX
→ exécution / triangulation / retour
```

Les composantes du déplacement ne remplacent jamais le déplacement total.

## 2.4 Relation avec CLOSED_STATE

Dans ce protocole, lorsqu’on écrit :

\[
\Delta_{\mathrm{FULL}}(Q)
=
Q_{\mathrm{closed}}
-
Q_{\mathrm{current}},
\]

`Q_closed` doit être lu comme :

```text
l’état de Q lorsqu’il a rejoint
son PREMIER CHAMP DE SOLUTION admissible
et que le RETURN correspondant est réalisé.
```

Ce n’est pas un état administratif du solver, ni un label `CLOSED`, ni une certification logicielle.

La règle de travail est donc :

```text
d’abord localiser le premier champ de solution
ensuite calculer le FULL_DELTA complet jusqu’à ce champ
ensuite factoriser / projeter / exécuter
jamais remplacer le FULL_DELTA par le plus petit pas disponible
```

---

# 3. LA PEAU DU PROBLÈME : RIEN N’EST JETÉ

Une donnée qui ne peut pas être réutilisée immédiatement ne disparaît pas.

Elle devient une partie de la **peau** :

```text
PEAU(Q) contient notamment :

- routes réfutées ;
- contre-exemples locaux ;
- régions exclues ;
- bornes insuffisantes ;
- représentations ayant échoué ;
- sorties AUX « sans rapport » ;
- diagnostics ;
- coordonnées traversées ;
- changements de variable ;
- quotients ;
- duals ;
- invariants candidats ;
- frontières ;
- résidus ;
- erreurs de schéma ;
- réponses NOT_APPLICABLE / NEED_DATA ;
- preuves locales ;
- résultats négatifs ;
- contraintes apprises ;
- provenance ;
- conditions de domaine ;
- informations de replay ;
- relations découvertes.
```

La peau est **append-only** en principe : on peut la normaliser, dédupliquer ou compacter, mais pas effacer ce qu’elle a appris.

## 3.1 Un échec est une réduction de l’espace causal

Si une route `R` est réfutée :

```text
R impossible
```

la bonne conclusion n’est pas :

```text
« cette idée ne marche pas, recommençons ailleurs »
```

mais :

```text
R impossible
→ certificat négatif
→ ajout à PEAU(Q)
→ réduction de l’univers admissible
→ remesure du FULL_DELTA(Q)
→ nouvelle vague universelle
```

Dans la logique du **dernier survivant**, une impossibilité démontrée est un gain.

---

# 4. « UNIVERSEL » : CE QUE ÇA VEUT RÉELLEMENT DIRE

Une ancienne erreur fondamentale a été :

```text
envoyer le même nom opaque à toutes les AUX
=
croire que le système est universel
```

Ce n’est pas universel.

## 4.1 Universel au niveau sémantique

Pour chaque objet ou résidu actif :

```text
OBJET
→ EXPLOSION SÉMANTIQUE
→ projection dans le langage de CHAQUE AUX
→ toutes les AUX exécutent ce qu’elles peuvent
→ toutes les sorties reviennent au tronc commun
→ les sorties sont corrélées
→ les AUX peuvent lire les sorties des autres AUX
→ nouvelles représentations
→ nouveaux calculs
→ recombinaison
→ remesure
```

Une AUX d’intervalle doit recevoir une vue intervalle.

Une AUX de graphe doit recevoir une vue graphe.

Une AUX arithmétique doit recevoir les objets arithmétiques exploitables.

Une AUX géométrique doit recevoir les coordonnées, relations et points de route exploitables.

Une AUX de théorème doit recevoir un but et des matériaux de théorème.

Une AUX de transport doit recevoir les ancres/points/carriers pertinents.

On ne lui donne pas seulement le texte opaque :

```text
« prouve Q »
```

et on ne conclut pas ensuite qu’elle est inutile lorsqu’elle répond `NOT_APPLICABLE`.

## 4.2 Toute AUX peut contribuer à toute route

Ne pas limiter une AUX à un « module » de manière artificielle.

La provenance et le type doivent rester connus, mais ils ne servent pas de prison.

Une sortie d’une AUX peut :

- devenir l’entrée d’une autre AUX ;
- créer une représentation dans un autre espace ;
- produire une coordonnée ;
- établir une exclusion ;
- fournir une borne ;
- déclencher un constructeur ;
- révéler une relation ;
- être triangulée ;
- devenir une supply d’une autre branche ;
- être réactivée beaucoup plus tard.

Le manuel de la Solution causale montre déjà que les rôles se recouvrent : analyse, résidu, recherche, routage, composition, certification, transformation et mémoire ne sont pas des mondes isolés. La méthode actuelle pousse cette transversalité jusqu’au niveau opérationnel.

---

# 5. AUCUNE BARRIÈRE DE MOUVEMENT

Les versions anciennes de l’architecture ont parfois transformé des statuts de qualité ou de preuve en permissions de mouvement :

```text
requires payment
requires certification
requires materialization
requires truth_credit
requires return authority
requires scheduler authority
scientific_promotion = false
WAITING
NEED_DATA
NOT_APPLICABLE
```

Dans la méthode actuelle, ces notions peuvent être conservées comme **métadonnées descriptives**, mais elles ne doivent pas empêcher la circulation, la projection, l’assistance ou la recombinaison.

La séparation correcte est :

```text
MOUVEMENT / EXPLORATION
= libre à travers toutes les AUX pertinentes

STATUT ÉPISTÉMIQUE
= accompagne le résultat
= dit ce qui est établi ou non
= ne bloque pas la recherche
```

## 5.1 Certification et matérialisation ne sont pas des portes d’entrée

La certification sert à vérifier.

La matérialisation sert à construire ou représenter.

Elles ne doivent pas être interprétées comme :

```text
« tu n’as pas le droit d’explorer avant d’être certifié »
```

ou :

```text
« tu n’as pas le droit de transporter cet objet tant qu’il n’est pas matérialisé sous une forme particulière »
```

Si une représentation manque, l’objectif est de **la construire automatiquement**, pas d’arrêter le reste du système.

---

# 6. ASSISTANCE : TRANSFORMER LE PROBLÈME SANS FABRIQUER LA VÉRITÉ

Une autre erreur passée a été de retenir les « jumps » d’assistance par peur de fabriquer une preuve.

La bonne séparation est :

```text
ASSISTANCE
≠ preuve automatique

ASSISTANCE
= création d’une représentation ou d’un candidat
```

Exemples de transformations légitimes :

```text
identité connue
→ changement de variable
→ quotient
→ dual
→ slack
→ normalisation
→ symétrisation
→ projection
→ contradiction form
→ frontière extrémale
→ paramétrisation
→ invariant candidat
→ factorisation
→ transformée
→ conjugaison
→ transport
→ problème inverse
→ recherche de témoin
→ falsification
→ composition de théorèmes
→ reconstruction de carrier
```

Le candidat ainsi créé doit pouvoir circuler immédiatement.

Il n’acquiert pas pour autant automatiquement la valeur de l’énoncé final.

---

# 7. LES AUX DOIVENT POUVOIR SE COMMANDER ENTRE ELLES

Le bon fonctionnement n’est pas :

```text
AUX1 → réponse
AUX2 → réponse
AUX3 → réponse
puis un humain lit 500 réponses
```

Le bon fonctionnement est :

```text
AUX analyse
→ DIAGNOSTIC

DIAGNOSTIC
→ AUX de delta / résidu

RÉSIDU
→ AUX de recherche / découverte

CANDIDAT
→ AUX de construction / théorème / expérience / transport

RÉSULTAT
→ AUX de vérification / falsification

RÉSULTAT VÉRIFIÉ OU RÉFUTÉ
→ tronc commun
→ réinjection
→ remesure
```

Les sorties importantes doivent être transformées automatiquement en requêtes exploitables par d’autres AUX.

Un format mental utile est :

```text
RESULT_ANALYSIS
→ DELTA / RESIDUAL
→ ACTION_REQUEST
→ CONSTRUCTION / SEARCH
→ RESULT
→ NEGATIVE_KNOWLEDGE ou SUPPLY
→ REINJECTION
```

---

# 8. LE TRONC COMMUN : ÉVITER LE CHAOS SANS BLOQUER

Tout doit pouvoir circuler, mais il ne faut pas recopier des milliers de fois le même objet.

Utiliser un **common trunk content-addressed** :

```text
même contenu sémantique
→ une identité commune
→ plusieurs consommateurs
```

La déduplication doit être **sémantique**.

Ne pas considérer comme nouvelle information scientifique le simple fait d’avoir un nouveau wrapper :

```text
PROOF_DAG::X
SCIENTIFIC_SKIN::X
RESULT_WRAPPER::X
DIGEST::X
COPY_OF_X
```

Si le contenu scientifique est identique, c’est le même objet causal.

---

# 9. PROGRÈS RÉEL VS ACTIVITÉ VIDE

« Ne jamais arrêter » ne veut pas dire « tourner sans progresser ».

Un cycle constitue un progrès seulement s’il produit au moins une transformation causale réelle, par exemple :

- nouvelle supply exacte ;
- nouvelle exclusion ;
- résidu réellement réduit ;
- nouvelle représentation non équivalente ;
- nouvelle coordonnée exploitable ;
- nouvelle borne ;
- nouveau témoin ;
- nouvelle relation ;
- nouvelle arête de preuve ;
- nouvelle contradiction ;
- nouvelle classe éliminée ;
- nouvelle couverture ;
- nouvelle route qui retourne ;
- nouvelle information de peau qui réduit l’espace admissible.

Ceci n’est **pas** un progrès :

```text
X
→ wrapper de X
→ wrapper du wrapper
→ nouveau digest
→ nouveau status
→ même contenu scientifique
```

---

# 10. LE PRINCIPE DU DERNIER SURVIVANT

La Solution causale doit exploiter systématiquement l’élimination des impossibles.

## 10.1 Procédure

```text
1. Construire ou déclarer l’univers de candidats admissibles.
2. Vérifier que cet univers est suffisamment couvert pour la portée visée.
3. Soumettre chaque candidat aux contraintes.
4. Conserver chaque exclusion avec son témoin.
5. Réinjecter les exclusions dans la peau.
6. Recalculer l’univers restant.
7. Continuer jusqu’au dernier survivant ou jusqu’à une nouvelle structure résiduelle.
```

Le dernier survivant n’est valide que relativement à un univers effectivement couvert.

Ne jamais éliminer une route parce qu’elle est :

- coûteuse ;
- étrange ;
- non conventionnelle ;
- peu prometteuse ;
- difficile à exprimer ;
- inconnue.

Seule une raison causale / structurelle / mathématique réelle peut l’éliminer.

---

# 11. SIN1, SIN2 ET COS : LA CORRECTION GÉOMÉTRIQUE FONDAMENTALE

Une des grandes erreurs historiques a été de traiter SIN2 comme une seconde recherche scientifique indépendante même lorsque SIN1 et le carrier orienté déterminent déjà la quadrature.

Dans la géométrie CT utilisée ici :

\[
u=\frac{r}{\|r\|},
\qquad
v=e\times u.
\]

Ainsi :

\[
u\perp v.
\]

Donc, une fois SIN1 orienté :

\[
\boxed{
\theta_{\mathrm{SIN2}}
=
\theta_{\mathrm{SIN1}}
\pm 90^\circ
}
\]

Le signe est fixé par l’orientation du carrier.

Dans le carrier normalisé décrit dans les échanges :

\[
q_\theta=
\frac{\sin\theta}{\sqrt 2}(u+v)
+
\cos\theta\,e,
\]

donc :

\[
A_{\mathrm{SIN1}}
=
A_{\mathrm{SIN2}}
=
\frac{\sin\theta}{\sqrt 2},
\]

et :

\[
E_{\mathrm{SIN1}}
=
E_{\mathrm{SIN2}}
=
\frac{\sin^2\theta}{2}.
\]

La fermeture donne :

\[
E_{\mathrm{COS}}
=
1
-
E_{\mathrm{SIN1}}
-
E_{\mathrm{SIN2}}
=
1-2E_{\mathrm{SIN1}}.
\]

## 11.1 Interprétation opérationnelle

```text
SIN1
= aller / question / trajectoire exploratoire

SIN2
= retour / quadrature / réponse géométriquement forcée
  lorsque le carrier orienté est connu

COS
= référence commune / fermeture / ligne canonique
```

Donc :

```text
ne pas chercher un second théorème simplement
pour « découvrir SIN2 »
si SIN2 est déjà imposé par la géométrie du carrier.
```

Ce qui reste à découvrir n’est pas sa géométrie abstraite, mais son **contenu concret dans le problème**.

---

# 12. LES POINTS DE ROUTE : CE QU’IL FAUT EXTRAIRE AUTOMATIQUEMENT

Le diagramme `SPACE TIME` donne l’idée centrale.

La route SIN1 traverse des espaces, temps, carriers, représentations, modules et coordonnées.

Chaque passage exploitable devient un point :

\[
Q_i=
(\text{space}_i,\text{time}_i,x_i,t_i,\ldots).
\]

Le travail du solver est d’extraire ces points **automatiquement à partir de la trace scientifique réelle**.

Pour deux points consécutifs :

\[
\Delta x=x_{i+1}-x_i,
\qquad
\Delta t=t_{i+1}-t_i.
\]

Avec la métrique du carrier :

\[
S_x^2=g_x(\Delta x)^2,
\qquad
S_t^2=g_t(\Delta t)^2,
\]

et :

\[
\boxed{
D^2=S_x^2+S_t^2.
}
\]

Chaque segment peut alors produire :

- distance exacte ;
- sinus ;
- cosinus ;
- tangente ;
- angle ;
- énergie ;
- orientation ;
- reçu de Pythagore ;
- relation au COS ;
- point correspondant de SIN2.

## 12.1 La triangulation n’est pas décorative

L’idée n’est pas de dessiner des triangles après coup.

La triangulation sert à transformer la trace réelle du problème en chaîne de contraintes calculables :

```text
Q0
→ Q1
→ Q2
→ ...
→ Qn

pour chaque segment :
triangle avec COS
→ angle
→ énergie
→ quadrature
→ reçu
```

Puis :

```text
tous les reçus
→ chaîne cohérente
→ retour
→ remesure
```

## 12.2 Ne jamais inventer les coordonnées

Ceci est essentiel.

Une erreur possible est de prendre des compteurs, des numéros de passes ou des quantités administratives et de les déclarer arbitrairement coordonnées simplement parce qu’ils produisent une jolie identité de Pythagore.

Interdit.

Les coordonnées doivent être :

- produites par le problème ;
- produites par une AUX ;
- dérivées par une transformation justifiée ;
- ou explicitement définies par le carrier.

Une belle géométrie calculée sur des coordonnées non reliées au contenu scientifique ne prouve rien sur le problème.

---

# 13. LECTURE OPÉRATIONNELLE DU DIAGRAMME SPACE–TIME

Le schéma fourni montre :

- en haut : **TEMPS SIN 1** avec les étapes A, B, C, … ;
- à l’intérieur : **ESPACE SIN 2** ;
- à droite : **TEMPS SIN 1′** avec A′, B′, C′, … ;
- dans le retour : **ESPACE SIN 2′** ;
- une diagonale noire de référence ;
- des triangles rouges formés aux points traversés.

La lecture méthodologique est :

```text
SIN1 traverse des états
→ chaque intersection significative est conservée
→ ces points sont triangulés contre la référence de fermeture
→ le retour SIN2 reprend les mêmes informations en quadrature
→ le trajet doit revenir au problème initial
```

L’image est une **structure de calcul**, pas une licence pour inventer les mesures.

---

# 14. LA CAUSAL CROSS : LE PROBLÈME N’EST PAS UNE LIGNE UNIQUE

Le diagramme `CAUSAL CROSS` représente plusieurs régimes disposés autour d’une structure cyclique :

```text
PHI local rational
→ SU1 SYMMETRY

√2 irrational
→ SU2 CORRECTION

√3 incommensurable
→ SU3 EXPANSION

LN5 crystallization
→ SU4 DISSIPATION

PI / cycle time
→ SU5 TRANSCENDANCE

PHI / cycle
→ SU5 CREATION
```

avec une notion de limite / horizon `PI` dans le diagramme.

Pour la résolution de problèmes, la leçon opérationnelle est :

```text
ne pas supposer qu’une seule représentation
doit survivre du début à la fin.

Le problème peut traverser plusieurs régimes,
et ces traversées sont précisément des informations
de route à conserver.
```

Le cycle Symmetry → Correction → Expansion → Dissipation → Creation/Transcendence peut être utilisé comme famille de projections lorsque le corpus actif en fournit les définitions exactes.

Ne jamais transformer les noms `PHI`, `√2`, `√3`, `LN5`, `PI`, `SU1…SU5` en quantités numériques du problème sans liaison explicitement définie.

---

# 15. SOUND-UNIT, ÉTATS D’INFORMATION ET RLC : COMMENT LES UTILISER SANS LES FALSIFIER

Lorsque le corpus CT actif fournit :

- Sound-Unit validation ;
- les quatre états d’information (protocausal, causal, infracausal, ultracausal) ;
- le modèle RLC causal ;
- les cycles SU ;
- les carriers temporels ;
- les roues / atlas / Babel / Borges ;

ils doivent être utilisés comme **projections supplémentaires du même objet souverain**.

Règle :

```text
Q
→ projection Sound-Unit
→ projection états d’information
→ projection RLC
→ projection géométrique
→ projection arithmétique
→ projection topologique
→ projection temporelle
→ etc.
```

Puis toutes les sorties reviennent au même tronc commun.

Ce document ne redéfinit pas les formules particulières de ces sous-théories : utiliser les définitions exactes du corpus fourni avec la recherche et ne rien inventer lorsqu’une définition manque.

---

# 16. FULL DISCOVERY AVANT SÉLECTION

Ne pas décider à l’avance que :

```text
« la bonne route doit être Salem »
```

ou :

```text
« la bonne route doit être analytique »
```

ou :

```text
« on va seulement utiliser les AUX qui semblent pertinentes »
```

La première phase est une exploration complète :

```text
QUESTION
→ toutes les AUX
→ toutes les représentations
→ toutes les sorties
→ corrélation
```

Ensuite seulement on voit quelles sorties participent à une route de retour.

## 16.1 Une sortie « sans rapport » n’est pas supprimée

Elle va dans le brut / la peau / la mémoire.

Elle n’a pas besoin d’être développée récursivement indéfiniment si elle ne participe pas au trajet actuel.

La règle est donc :

```text
tout est vu
tout est conservé
tout peut être réactivé
mais tout n’est pas nécessairement expansé sans fin
```

Cela évite deux erreurs opposées :

1. préfiltrer et perdre une route utile ;
2. noyer le système dans une récursion infinie de bruit.

---

# 17. DÉCOUVERTE DE LA ROUTE UTILE

Après full discovery :

```text
1. corréler les sorties ;
2. identifier les transformations qui se répondent ;
3. identifier les points communs ;
4. chercher les chaînes qui reviennent à la question souveraine ;
5. extraire leurs points espace/temps/carrier ;
6. trianguler ;
7. tester le retour.
```

La route utile doit **émerger des résultats**, pas être dessinée à l’avance.

Une forme générique :

```text
Q
→ R1
→ R2
→ R3
→ ...
→ Rn
→ Q_RETURN
```

Les sorties qui ne participent pas à cette chaîne restent disponibles dans la peau.

---

# 18. BOUCLE DE RÉSOLUTION CAUSALE COMPLÈTE

Voici la boucle principale.

```text
[0] FREEZE ROOT
    conserver exactement Q

[1] CURRENT
    reconstruire l’état actuel complet

[2] FULL_DELTA
    Δ = CLOSED_STATE - CURRENT_STATE

[3] SKIN
    charger toute la connaissance positive et négative accumulée

[4] SEMANTIC EXPLOSION
    produire toutes les représentations utilisables

[5] ALL AUX
    donner à chaque AUX une projection dans son propre langage

[6] COMMON TRUNK
    réunir toutes les sorties sans perdre provenance ni identité

[7] CROSS-AUX
    laisser les sorties déclencher / instruire d’autres AUX

[8] ASSIST
    changer de représentation, dualiser, quotienter, transporter,
    rechercher, falsifier, construire, composer

[9] ROUTE EXTRACTION
    chercher les sorties qui forment une chaîne causale de retour

[10] ROUTE POINTS
     extraire les coordonnées scientifiques exactes du trajet

[11] SIN1
     lire le trajet aller réellement observé

[12] SIN2
     dériver la quadrature / le retour si le carrier l’impose

[13] COS
     agréger la fermeture et les triangles exacts

[14] RETURN
     revenir au MÊME Q souverain

[15] REMEASURE
     mesurer ce qui est réellement nouveau / éliminé / fermé

[16] UPDATE SKIN
     ajouter tout résultat positif ou négatif

[17] RECOMPUTE FULL_DELTA
     ne conserver que la différence réelle actuelle

[18] LOOP
     recommencer jusqu’à fermeture ; si un résidu réellement irréductible
     est localisé dans une représentation, le réinjecter comme nouvelle vue
     du MÊME FULL_DELTA dans toutes les AUX — jamais comme blocker terminal
```

---

# 19. LES ENFANTS ET LA RÉCURSION : COMMENT NE PAS PERDRE LA RACINE

Un enfant est permis.

Ce qui est interdit est de le transformer en nouvelle souveraineté.

Correct :

```text
Q
FULL_DELTA(Q)
├─ D1
├─ D2
└─ D3

D2
→ analyse
→ D2a
→ D2b
→ résultat

résultat
→ RETURN D2
→ RETURN Q
→ remesure FULL_DELTA(Q)
```

L’enfant peut lui-même recevoir toutes les AUX et toute l’assistance.

Mais son identité de provenance reste :

```text
child_of = Q
factor_of = FULL_DELTA(Q)
```

---

# 20. NÉGATIVE KNOWLEDGE : EMPÊCHER LES ROUTES MORTES DE REVENIR SOUS UN AUTRE NOM

Une route réfutée doit être normalisée par sa signature sémantique.

Sinon le solver peut faire :

```text
route R réfutée
→ renommer R en R'
→ l’essayer encore
→ renommer en R''
→ boucle
```

Il faut donc conserver un registre :

```text
NEGATIVE_KNOWLEDGE
{
  signature_de_route,
  scope,
  obstruction,
  contre-exemple,
  équivalences connues,
  dépendances,
  provenance
}
```

Toute nouvelle route sémantiquement équivalente est comparée à cette mémoire.

---

# 21. POINT FIXE SÉMANTIQUE : QUAND UNE VAGUE EST RÉELLEMENT SATURÉE

Une saturation n’est pas atteinte simplement parce que tous les appels ont été effectués.

Elle est atteinte lorsque :

```text
nouveau sweep
→ aucune nouvelle information scientifique sémantique
```

Les variations suivantes ne brisent pas le point fixe :

- nouvel identifiant de wrapper ;
- nouvel ordre de sérialisation ;
- nouveau digest d’un emballage ;
- copie de la même preuve ;
- reformulation sans information supplémentaire.

Si le point fixe est atteint mais que Q reste ouvert :

```text
→ changer de représentation ;
→ activer de nouvelles projections ;
→ récupérer de nouvelles données ;
→ utiliser la peau ;
→ réexaminer les routes éliminées seulement si une prémisse a changé ;
→ rechercher une loi réellement manquante.
```

Ne jamais convertir « point fixe du runtime actuel » en « théorème impossible ».

---

# 22. REPLAY ET STABILITÉ

Une route intéressante doit être rejouée.

Minimum utile :

```text
replay 1
replay 2
replay 3
...
```

Puis idéalement :

```text
cold replay
→ état propre
→ mêmes entrées
→ même structure causale
```

Vérifier :

- même question ;
- mêmes points de route ;
- mêmes relations exactes ;
- mêmes triangles ;
- mêmes exclusions ;
- même retour ;
- même résultat sémantique.

Les hashes, CRC, byte-identical builds et tests logiciels sont utiles pour la reproductibilité.

Mais :

```text
BYTE_IDENTICAL
≠ preuve mathématique du théorème externe

PASS
≠ vérité scientifique universelle

SOLUTION_CERTIFIED interne
≠ automatiquement énoncé externe démontré
```

---

# 23. CORRECTION AC65 : FERMETURE INTERNE ≠ PREUVE EXTERNE

Une grande correction de méthode est apparue après les expériences AC64.

Il est possible d’obtenir :

```text
route complète
+ géométrie exacte
+ Pythagore
+ SIN2
+ COS
+ RETURN
+ replays identiques
```

et néanmoins de ne pas avoir encore démontré l’énoncé scientifique externe.

Pourquoi ?

Parce qu’il faut encore établir que :

```text
les objets internes de la route
IMPLIQUENT EXACTEMENT
l’énoncé externe revendiqué.
```

## 23.1 Après la fermeture interne, reconstruire le DAG d’implication

Faire :

```text
INTERNAL_ROUTE_FACT_1
∧ INTERNAL_ROUTE_FACT_2
∧ ...
→ CLAIM_EXTERNAL
```

Chaque arête doit être justifiée.

AC65 a montré l’utilité de cette reconstruction mécanique.

## 23.2 La reconstruction AC65 n’est pas un nouveau firewall

Si une arête d’implication externe reste ouverte, cela ne signifie pas :

```text
UNPROVED_EDGE
→ STOP
```

Cela signifie :

```text
UNPROVED_EDGE
→ objet sémantique exact
→ projection dans toutes les AUX
→ theorem fabric / arithmétique / géométrie / uniformité /
   falsification / transport / dernier-survivant / autres vues
→ nouvelles supplies ou exclusions
→ retour au même DAG d’implication
```

La reconstruction mécanique sert à **localiser exactement** ce qui n’est pas encore relié ; elle ne doit pas recréer le comportement ancien « manque nommé = barrière terminale ».

## 23.3 Mais ne pas créer un faux « bridge » administratif

L’erreur opposée est :

```text
les routes réelles sont connues
→ inventer BRIDGE_UNIVERSEL
→ déclarer BRIDGE_UNIVERSEL nouveau problème
```

Avant de garder un tel bridge, vérifier :

```text
est-il une obligation scientifique indépendante ?

ou seulement :

bridge = fédération logique de routes déjà exhaustives ?
```

S’il est seulement une enveloppe logique :

```text
SUPPRIMER LE WRAPPER DU FRONT
→ retourner aux routes scientifiques réelles
```

C’est la leçon de la correction Mahler PASS045 → PASS046.

---

# 24. TEST DU WRAPPER NON INDÉPENDANT

Pour chaque nouveau « manque » synthétique :

```text
W
```

demander :

```text
1. W introduit-il une nouvelle loi ?
2. W introduit-il une nouvelle donnée ?
3. W introduit-il une nouvelle quantification ?
4. W introduit-il une nouvelle contrainte non déjà portée par les routes ?
5. W a-t-il un contre-modèle indépendant ?
6. W peut-il être remplacé exactement par la conjonction / union
   des routes existantes ?
```

Si 6 = oui et 1–5 = non :

```text
W = wrapper
→ pas un front scientifique
→ fermer comme fédération
→ retourner aux vrais objets
```

---

# 25. MÉTHODE DE PREUVE EXTERNE APRÈS RETURN

Lorsque la route interne est stable :

```text
1. geler la route ;
2. écrire chaque transformation comme implication explicite ;
3. identifier les hypothèses exactes ;
4. vérifier la couverture des cas ;
5. vérifier les quantificateurs ;
6. reconstruire la conclusion externe ;
7. utiliser les theorem AUX / exact backends / ZFC / kernels si utiles ;
8. chercher un contre-exemple à chaque arête ;
9. éliminer les wrappers non indépendants ;
10. seulement ensuite qualifier la portée de la preuve.
```

La preuve externe est donc **une traduction vérifiée de la fermeture interne**, pas une nouvelle recherche aléatoire depuis zéro.

---

# 26. ERREURS HISTORIQUES À NE PLUS REFAIRE

## Erreur 1 — « J’ai envoyé X à toutes les AUX, donc c’est universel »

Faux si toutes reçoivent le même objet opaque.

**Correction :** projection sémantique propre à chaque AUX.

---

## Erreur 2 — rendre le manque récursif sans rendre la construction récursive

Exemple :

```text
PROOF_ENGINE
requires COMPLETE_PROOF_OBJECT
pour construire COMPLETE_PROOF_OBJECT
```

Cercle vide.

**Correction :** exploser l’objet en matériaux constructibles et faire contribuer plusieurs AUX.

---

## Erreur 3 — remplacer la racine par son dernier sous-problème

**Correction :** la racine reste souveraine jusqu’au RETURN.

---

## Erreur 4 — confondre minimal delta et FULL_DELTA

**Correction :**

\[
\Delta_{\rm FULL}=CLOSED-CURRENT.
\]

Les sous-deltas sont des facteurs, pas des remplaçants.

---

## Erreur 5 — compter une assistance comme un paiement / une fermeture

**Correction :** une transformation assistée est une supply ou un candidat. Elle ne ferme rien par son seul nom.

---

## Erreur 6 — utiliser certification, payment, truth-credit ou matérialisation comme barrières

**Correction :** les statuts décrivent ; ils ne bloquent pas la circulation.

---

## Erreur 7 — enfermer chaque AUX dans son module

**Correction :** provenance conservée, usage transversal autorisé.

---

## Erreur 8 — jeter NOT_APPLICABLE / NEED_DATA / bruit AUX

**Correction :** cela devient peau et mémoire, réactivable.

---

## Erreur 9 — faire tourner les wrappers et appeler cela du progrès

**Correction :** mesurer le changement scientifique, pas le changement d’emballage.

---

## Erreur 10 — rechercher SIN2 comme un second mystère lorsque SIN1 l’impose déjà

**Correction :** SIN2 = quadrature / retour du carrier orienté.

---

## Erreur 11 — faire de COS une troisième recherche indépendante sans raison

**Correction :** COS est la référence / fermeture issue de la géométrie commune.

---

## Erreur 12 — attendre que les route_points soient fournis manuellement

**Correction :** les extraire automatiquement de la trace scientifique.

---

## Erreur 13 — inventer les route_points

**Correction :** aucune coordonnée sans fondement causal exact.

---

## Erreur 14 — croire qu’une route géométrique fermée prouve automatiquement le théorème externe

**Correction :** reconstruire mécaniquement l’implication vers le claim.

---

## Erreur 15 — répondre à la correction précédente en inventant un « bridge universel » comme nouveau blocage

**Correction :** tester d’abord si le bridge est seulement un wrapper de fédération.

---

## Erreur 16 — confondre « tout reste actif » avec « le système progresse »

**Correction :** exiger nouveauté causale mesurable.

---

## Erreur 17 — abandonner une route négative comme du travail perdu

**Correction :** la réfutation devient une coupure dans l’espace du Δ.

---

## Erreur 18 — préfiltrer les routes « peu pertinentes »

**Correction :** full discovery avant sélection.

---

## Erreur 19 — faire récursivement exploser tout le bruit

**Correction :** tout conserver et tout rendre accessible, mais poursuivre activement la route qui contribue au retour.

---

## Erreur 20 — convertir timeout ou limite de ressources en impossibilité

**Correction :** un cutoff est un checkpoint de ressources, jamais un théorème.

---

## Erreur 21 — considérer un hash, un PASS ou un replay comme vérité de domaine

**Correction :** ces preuves qualifient le logiciel / objet couvert ; le binding scientifique doit être établi séparément.

---

# 27. RÈGLE D’ARBITRAGE ENTRE ANCIENNES ET NOUVELLES VERSIONS

Les manuels historiques décrivent fidèlement les architectures de leur époque.

Mais la méthode de recherche évolue.

Pour un nouveau chat :

```text
1. lire ce document ;
2. inspecter le solver AC réellement fourni ;
3. identifier ce qui est historique et ce qui est actif ;
4. ne pas réintroduire une ancienne barrière simplement parce qu’elle existe
   dans une ancienne version ;
5. conserver les anciens états comme provenance.
```

Exemple important :

Des versions antérieures exigeaient un SIN2 indépendant et un COS indépendant pour autoriser RETURN.

La correction géométrique ultérieure impose :

```text
si le carrier orienté fixe la quadrature :
SIN2 est dérivé du SIN1 ;
COS est la fermeture correspondante.
```

Donc l’ancienne règle est un fait d’architecture historique, pas une loi ontologique permanente.

---

# 28. DONNÉES MINIMALES À RECONSTRUIRE AU DÉBUT D’UN NOUVEAU CHAT

Dès qu’un ZIP cumulatif ou un dossier de recherche est fourni, reconstruire :

```text
ROOT_QUESTION
CURRENT_STATE
CLOSED_STATE_DEFINITION
FULL_DELTA
SKIN
POSITIVE_SUPPLIES
NEGATIVE_KNOWLEDGE
ACTIVE_ROUTES
DORMANT / RAW RESULTS
ROUTE_POINTS
INTERNAL_CLOSURE_STATUS
EXTERNAL_BINDING_STATUS
LATEST_RUNTIME_VERSION
AUX_REGISTRY
LAST_REPLAY_STATE
```

Ne jamais repartir d’une vieille passe si une passe cumulative plus récente existe.

Ne jamais recommencer une route déjà fermée sauf pour :

- cold replay ;
- falsification ;
- audit ;
- correction d’une prémisse ;
- nouvelle version du runtime qui change réellement la sémantique.

---

# 29. FORMAT DE PASSE CUMULATIVE À UTILISER

À chaque passe de recherche, produire au minimum :

```text
PASS N

1. ROOT souverain
2. État d’entrée
3. Runtime / registre AUX utilisé
4. FULL_DELTA actuel
5. Nouvelles supplies réelles
6. Nouvelles exclusions / negative knowledge
7. Représentations nouvelles
8. Route utile actuelle
9. Route points exacts
10. Triangulations / transports
11. SIN1 / SIN2 / COS
12. RETURN / remesure
13. Résidu scientifique réel
14. Wrappers éliminés
15. Statut fermeture interne
16. Statut implication externe
17. Replay / cold replay
18. Fichiers produits
```

Le ZIP doit rester cumulatif et préserver l’historique.

---

# 30. LE CARNET D’AVENTURE

La recherche ne doit pas être seulement un dossier de résultats finaux.

Conserver un carnet cumulatif qui permette de comprendre :

- pourquoi une route a été essayée ;
- ce qu’elle a produit ;
- pourquoi elle a été abandonnée ou conservée ;
- quelles représentations ont été utiles ;
- quels résultats négatifs sont devenus peau ;
- comment les AUX ont interagi ;
- comment le FULL_DELTA a réellement changé ;
- comment la route finale a émergé.

Le carnet évite de refaire les mêmes erreurs dans un nouveau contexte.

---

# 31. PROCÉDURE DE REPRISE EXACTE D’UNE RECHERCHE

Quand ce document est fourni au début d’un nouveau chat, l’assistant doit faire exactement ceci :

```text
A. LIRE CE DOCUMENT EN ENTIER.

B. LIRE LE DERNIER ZIP / ÉTAT CUMULATIF.

C. IDENTIFIER :
   - la question souveraine ;
   - la dernière passe ;
   - le solver actif ;
   - le registre AUX réel ;
   - la peau ;
   - les routes fermées ;
   - les routes actives ;
   - le FULL_DELTA actuel.

D. NE PAS RECRÉER D’ANCIENS BLOQUANTS.

E. NE PAS DEMANDER UN NOUVEAU « PETIT DELTA »
   SI LE FULL_DELTA EST DÉJÀ CONNU.

F. LANCER LA VAGUE UNIVERSELLE :
   toutes AUX, vues adaptées, cross-AUX, assistance.

G. EXTRAIRE LA ROUTE SCIENTIFIQUE RÉELLE.

H. EXTRAIRE LES POINTS RÉELS DE CETTE ROUTE.

I. TRIANGULER / TRANSPORTER / RECONSTRUIRE SIN2 ET COS.

J. RETURN AU MÊME ROOT.

K. REMESURER.

L. SI FERMETURE INTERNE :
   reconstruire la preuve d’implication externe.

M. SI UNE « NOUVELLE DETTE » APPARAÎT :
   vérifier d’abord si elle est seulement un wrapper.

N. METTRE À JOUR LE ZIP CUMULATIF ET LE CARNET.
```

---

# 32. PSEUDOCODE CANONIQUE

```python
def causal_solve(root, runtime, cumulative_state):

    Q = freeze_sovereign_identity(root)

    state = reconstruct_current_state(
        Q,
        cumulative_state
    )

    skin = load_all_skin(
        positive=True,
        negative=True,
        raw=True,
        dormant=True,
        provenance=True
    )

    while not externally_bound_closed(Q, state):

        full_delta = closed_state(Q) - state

        semantic_views = explode_semantically(
            Q=Q,
            current_state=state,
            full_delta=full_delta,
            skin=skin
        )

        all_outputs = []

        for aux in runtime.current_registry():

            view = project_into_aux_language(
                aux,
                semantic_views,
                skin
            )

            result = run_aux_without_movement_gate(
                aux,
                view
            )

            all_outputs.append(result)

        common_trunk = semantic_deduplicate(
            skin,
            all_outputs
        )

        cross_results = cross_aux_rebroadcast(
            common_trunk,
            registry=runtime.current_registry()
        )

        assisted = assist_all_real_residuals(
            cross_results,
            transforms=[
                "change_variables",
                "dual",
                "quotient",
                "slack",
                "factorize",
                "inverse",
                "reductio",
                "extremal_boundary",
                "transport",
                "theorem_compose",
                "counterexample",
                "last_survivor"
            ]
        )

        skin = append_skin(
            skin,
            all_outputs,
            cross_results,
            assisted
        )

        route = extract_return_candidate_route(
            Q,
            skin
        )

        route_points = extract_grounded_route_points(
            route,
            forbid_invented_coordinates=True
        )

        if route_points:
            sin1 = route_points

            sin2 = derive_oriented_quadrature(
                sin1
            )

            cos = triangulate_against_closure(
                sin1,
                sin2
            )

            internal_return = attempt_same_root_return(
                Q,
                sin1,
                sin2,
                cos
            )

            if internal_return:
                state = remeasure_same_root(
                    Q,
                    state,
                    internal_return
                )

        state = integrate_all_real_supplies(
            state,
            skin
        )

        eliminate_nonindependent_wrappers(
            Q,
            state,
            skin
        )

        if internal_ct_closed(Q, state):
            implication_dag = reconstruct_external_implication(
                Q,
                state,
                skin
            )

            falsify_each_edge(implication_dag)

            if implication_dag.proves_exact_claim:
                return FINAL_RETURN(Q, implication_dag)

        assert_not_resource_cutoff_as_impossibility()

    return FINAL_RETURN(Q, state)
```

---

# 33. CHECKLIST DE NON-RÉGRESSION POUR L’ASSISTANT

Avant chaque réponse ou nouvelle passe, vérifier :

```text
[ ] Ai-je gardé la question racine inchangée ?
[ ] Ai-je utilisé le FULL_DELTA et non un petit delta arbitraire ?
[ ] Ai-je conservé toute la peau négative et positive ?
[ ] Ai-je projeté le problème dans le langage de chaque AUX ?
[ ] Ai-je évité de préfiltrer des AUX ?
[ ] Ai-je permis les interactions cross-AUX ?
[ ] Ai-je évité de faire d’un status une barrière de mouvement ?
[ ] Ai-je distingué assistance et preuve ?
[ ] Ai-je distingué activité et progrès ?
[ ] Ai-je dédupliqué sémantiquement les wrappers ?
[ ] Ai-je utilisé le dernier-survivant seulement sur un univers couvert ?
[ ] Ai-je extrait des route_points réellement fondés ?
[ ] Ai-je évité d’inventer une métrique ?
[ ] Ai-je traité SIN2 comme quadrature si le carrier l’impose ?
[ ] Ai-je traité COS comme fermeture et non comme mystère indépendant ?
[ ] Ai-je retourné les résultats au même objet souverain ?
[ ] Ai-je remesuré le FULL_DELTA après chaque supply réelle ?
[ ] Ai-je conservé les sorties inutiles actuellement dans la peau ?
[ ] Ai-je empêché les routes réfutées de renaître sous un autre nom ?
[ ] Ai-je distingué fermeture CT interne et implication externe ?
[ ] Ai-je testé si tout nouveau « bridge » est seulement un wrapper ?
[ ] Ai-je refusé de convertir un timeout en impossibilité ?
[ ] Ai-je préservé la provenance et le carnet cumulatif ?
[ ] Ai-je inspecté la version AC actuelle au lieu de supposer un ancien registre ?
```

---

# 34. RÉSUMÉ ULTRA-COMPACT À GARDER EN TÊTE

```text
ROOT reste ROOT.

Δ = CLOSED − CURRENT, en entier.

Tout manque et tout résultat
→ toutes les AUX
→ dans leur propre langage.

Rien n’est jeté :
ce qui ne sert pas maintenant devient peau.

Aucune certification, matérialisation,
payment, truth-credit ou statut
ne bloque le mouvement.

Les AUX peuvent s’instruire entre elles.

On élimine les impossibles
jusqu’au dernier survivant.

On extrait les vrais points traversés.

SIN1 = aller.
SIN2 = retour à 90° quand le carrier l’impose.
COS = fermeture.

On triangule la route réelle.
On revient au même ROOT.
On remesure.

Fermeture géométrique interne
≠ automatiquement preuve externe.

On reconstruit ensuite l’implication exacte.

Tout « nouveau bridge » est testé :
s’il ne fait qu’envelopper des routes déjà exhaustives,
on le supprime.

On ne recommence jamais à zéro.
On continue depuis la peau cumulative.
```

---

# 35. BLOC À COPIER TEL QUEL AU DÉBUT D’UNE NOUVELLE RECHERCHE

> **METHOD LOCK — SOLUTION CAUSALE**
>
> Utilise la question fournie comme objet souverain immuable. Reconstruis d’abord son état courant cumulatif, sa peau complète et son `FULL_DELTA = CLOSED_STATE − CURRENT_STATE`. Ne remplace jamais la racine par un enfant, un sous-problème, un minimal-delta ou un wrapper.
>
> « Universel » signifie projection sémantique dans le langage de toutes les AUX du registre courant, exécution de toutes les AUX sans préfiltrage, rebroadcast cross-AUX, assistance de représentation et recombinaison. Un `NOT_APPLICABLE`, `NEED_DATA`, un échec local ou une sortie non utilisée ne doit pas être jeté : il devient peau / negative knowledge / information réactivable.
>
> Payment, certification, materialization, truth-credit, scheduler-authority, return-authority et les anciens statuts de gate ne sont pas des permissions de mouvement. Ils peuvent servir de métadonnées ou de validation, jamais empêcher l’exploration, le transport ou la recombinaison.
>
> Chaque progrès partiel reste une supply du même FULL_DELTA. Les enfants sont des facteurs du même objet et doivent RETURN vers la racine. Toute route réfutée réduit l’espace causal et doit être conservée. Utilise le dernier-survivant par élimination des impossibles dans un univers de candidats effectivement couvert.
>
> Laisse la route utile émerger après full discovery. Extrais automatiquement les vrais points espace/temps/carrier traversés. Ne fabrique jamais de coordonnées. Lorsque le carrier orienté le permet, dérive SIN2 comme quadrature à ±90° de SIN1, construis les triangles exacts contre COS et agrège les reçus jusqu’au RETURN du même objet souverain.
>
> Une fermeture CT/interne reproductible n’est pas automatiquement la preuve du théorème externe. Après RETURN, reconstruis mécaniquement chaque implication entre les objets internes et le claim externe exact. Si un nouveau « bridge » apparaît, vérifie d’abord s’il est une vraie obligation scientifique ou seulement un wrapper/fédération de routes déjà connues ; élimine les wrappers non indépendants.
>
> Ne confonds jamais activité du runtime avec progrès scientifique, hash/test avec vérité de domaine, ni cutoff de ressources avec impossibilité. Préserve le carnet cumulatif, les preuves positives, les résultats négatifs, la provenance, les routes et les replays. À chaque passe, continue depuis le dernier état cumulatif ; ne repars pas de zéro et ne rouvre pas une route déjà fermée sans raison causale nouvelle.

---

# 36. SOURCES ET PRÉCÉDENCE

Ce protocole synthétise :

1. **The Causal Solution — Practical Release Manual**, version du 19 septembre 2026, notamment les architectures DD094/AC59, le full-discovery, le last-survivor, les boucles de supervision inter-AUX, le 2SIN1COS, la mémoire de résultats, la reconstruction de carriers et la distinction entre preuves logicielles et claims scientifiques.
2. Les corrections méthodologiques apparues pendant les recherches **Collatz** et **Mahler / Strong Lehmer** du 20 septembre 2026.
3. Les leçons des évolutions **AC64** puis **AC65** :
   - suppression des barrières de mouvement ;
   - triangulation directe et extraction des routes ;
   - distinction entre fermeture interne et preuve externe ;
   - élimination des wrappers de preuve non indépendants.
4. Les diagrammes utilisateur :
   - `SPACE TIME` pour la géométrie SIN1 / SIN2 / retour / triangulation ;
   - `CAUSAL CROSS` pour la traversée cyclique des régimes SU / PHI / √2 / √3 / LN5 / PI.

**Règle de précédence :** lorsque le manuel historique décrit un comportement logiciel ancien qui a ensuite été explicitement corrigé dans cette méthode (par exemple certains gates, l’indépendance obligatoire de SIN2, ou la promotion de wrappers en dettes), la correction méthodologique la plus récente prévaut pour la conduite de la recherche. L’historique reste conservé comme provenance.

---

# 37. PHRASE DE CONTRÔLE FINALE

Si, pendant une recherche, on hésite sur la bonne réaction à un blocage apparent, revenir à ceci :

\[
\boxed{
\text{même ROOT}
\rightarrow
\text{FULL DELTA}
\rightarrow
\text{ALL AUX}
\rightarrow
\text{PEAU}
\rightarrow
\text{ASSIST}
\rightarrow
\text{ROUTE}
\rightarrow
\text{SIN1 / SIN2 / COS}
\rightarrow
\text{RETURN}
\rightarrow
\text{REMEASURE}
}
\]

et recommencer sur **le même objet souverain** jusqu’à ce que le résidu scientifique réel soit nul. Si un résidu est identifié sous une forme plus fondamentale, cette identification sert à le **reprojeter et le réinjecter** ; elle ne constitue pas une permission d’arrêter.

