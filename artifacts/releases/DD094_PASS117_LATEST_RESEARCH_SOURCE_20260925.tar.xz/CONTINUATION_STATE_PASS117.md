# CONTINUATION STATE — PASS117

## Closed this pass

- `REACT_REAL_PSEUDO_ONE_HALO_COMPILER`
- `REACT_E_PARAMETER_COMPILER`
- `REACT_MASSLESS_REACTION_ALGEBRA_COMPILER`
- `REACT_KSTAR_MATCHING_ALGEBRA_CONTRACT`

## Previous owner status

`REACT_HALO_REACTION_ASSEMBLY_WITH_STANDARD_PSEUDO_BASELINE`

is reduced to one missing physical ingredient rather than declared complete.

## Last Survivor

`CANONICAL_RICCI_REACT_ONE_LOOP_SPT_REAL_PSEUDO_COMPILER`

Required output:

- `P_SPT_real(k0,z)`;
- `P_SPT_pseudo(k0,z)`;
- preferably the full one-loop `P(k,z)` tables required by the reaction implementation;
- exact use of PASS102 linear response plus PASS109/PASS112 `gamma2/gamma3`;
- no `q^2=lambda` substitution inside the finite-torus dynamics before the continuum reaction interface.

## Next pass

PASS118: implement the one-loop density/velocity kernel evolution/integration and close `kstar`. Then assemble the physical reaction and move to `FINITE_TORUS_TO_ISOTROPIC_PK_COMPRESSION_CERTIFICATE`.

## Claim ceiling

No physical `R_NL`, nonlinear CT spectrum, rank, or `mhat^2` yet.
