#!/usr/bin/env python3
from pathlib import Path
import sys,json,collections,argparse
ROOT=Path(__file__).resolve().parents[2]
ACROOT=ROOT/'runtime'/'AC77'/'SC_SOLVER_AC77_PERIODIC_CARTESIAN_THEOREM_METROLOGY_CORE_20260922'
sys.path.insert(0,str(ACROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver
BASE=[
 'FINITE_DISCRETE_TORUS_E1','Q_LAMBDA_FIREWALL_CERTIFICATE','PASS041_COMPLETED_ACTION_FAMILY',
 'PASS041_ACTION_DERIVATIVES_TO_QUARTIC_ORDER','FINITE_TORUS_RAW_SCALAR_QUADRATIC_CUBIC_VERTEX_COMPILER',
 'SPHERICAL_COLLAPSE_KINEMATIC_REDUCTION','NONLINEAR_METRIC_PROJECTION_FIREWALL',
 'CANONICAL_RICCI_EVOLVING_GAUGE_REDUCED_LINEAR_MODE_SOLVER','FINITE_TORUS_VARIATIONAL_METRIC_STENCIL_CONTRACT',
 'REACT_NONLINEAR_POISSON_QS_SCOPE_CONTRACT','CANONICAL_RICCI_FIXED_BACKGROUND_QS_CURVATURE_LIFT',
 'REACT_GAMMA2_NORMALIZATION_CONTRACT','CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA2_COMPILER',
 'PASS109_MINIMAL_VARIATIONAL_CUBIC_METRIC_PROJECTION_CANDIDATE','REACT_GAMMA3_NORMALIZATION_CONTRACT',
 'FINITE_TORUS_CUBIC_STENCIL_NONUNIQUENESS_WITNESS','PASS109_LINEAR_CONSTRAINT_VARIATIONAL_SYMMETRIZATION',
 'FINITE_TORUS_ACTION_LEVEL_CUBIC_NONUNIQUENESS_CERTIFICATE',
 'PASS086_STRICT_MINIMAL_FINITE_TORUS_ACTION_PULLBACK_RULE',
 'PASS041_TO_FINITE_TORUS_FULL_NONLINEAR_DISCRETE_ACTION_COMPLETION_RULE',
 'CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA3_COMPILER'
]
def seed(pid,statement,target,requires=(),supplies=(),**kw):
 p=dict(problem_id=pid,statement=statement,target=target,requires=list(requires),supplies=BASE+list(supplies),ground_binding=True);p.update(kw);return Node('PROBLEM',p,context=('DELTA_CDM_PASS112',pid))
FORCE='ACTION_DERIVED_NONPERTURBATIVE_SPHERICAL_FORCE_LAW'
seeds=[
 seed('P112_COMPLETION','Reconcile PASS111 with the already-selected PASS086 minimal local branch by materializing the strict syntax-directed PASS041-to-finite-torus pullback: sitewise local products, PASS087 D+/D-, PASS109 H/Gamma, no new lattice-only monomial or nonlinear coupling unless a separate branch is explicitly activated.','PASS041_TO_FINITE_TORUS_FULL_NONLINEAR_DISCRETE_ACTION_COMPLETION_RULE',(),('PASS086_STRICT_MINIMAL_FINITE_TORUS_ACTION_PULLBACK_RULE','PASS041_TO_FINITE_TORUS_FULL_NONLINEAR_DISCRETE_ACTION_COMPLETION_RULE'),proof_object={'type':'lineage_reconciliation_and_structural_induction','receipt':'receipts/PASS112/PASS112_STRICT_MINIMAL_ACTION_PULLBACK_RULE.json'},uniformity_verified=True,boundaries={'PASS111_larger_regulator_nonuniqueness_retained':True,'no_silent_new_lattice_operator':True}),
 seed('P112_GAMMA3','Promote the deterministic PASS110 ReACT-QS gamma3 compiler only inside the selected strict minimal PASS041 finite-torus completion; do not claim universal regulator independence or a physical numerical gamma3 from manufactured parameters.','CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA3_COMPILER',(),('CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA3_COMPILER',),proof_object={'type':'branch_scoped_gamma3_compiler_closure','receipt':'receipts/PASS112/PASS112_STRICT_MINIMAL_ACTION_PULLBACK_RULE.json'},uniformity_verified=True,boundaries={'branch_scoped_only':True,'physical_numeric_gamma3_not_claimed':True}),
 seed('P112_FORCE','Derive the nonperturbative spherical gravitational force source from the same completed PASS041 finite-torus action, rather than extrapolating the perturbative gamma2/gamma3 series beyond its order.','CANONICAL_RICCI_SPHERICAL_COLLAPSE_FORCE_TRAJECTORY_COMPILER',(FORCE,),(),boundaries={'gamma2_gamma3_not_assumed_sufficient_for_full_collapse':True,'same_action_no_new_screening_function':True}),
 seed('P112_NONLINEAR','Close the nonlinear reaction packet only after the action-derived nonperturbative spherical force and virial ingredients are available.','CT_NONLINEAR_HIGHER_ORDER_POISSON_AND_COLLAPSE_COMPILER',('CANONICAL_RICCI_SPHERICAL_COLLAPSE_FORCE_TRAJECTORY_COMPILER','CANONICAL_RICCI_VIRIAL_REACTION_INGREDIENT_COMPILER'),(),boundaries={'no_phenomenological_delta_nl':True}),
]
world={'project':'DELTA_CDM_PASS112','available_evidence_tokens':BASE,'external_scientific_truth_certified':False,'finite_discrete_torus':True,'strict_minimal_action_pullback_rule_closed':True,'react_qs_gamma3_compiler_closed':True,'physical_gamma3_numeric_value_claimed':False,'action_derived_nonperturbative_spherical_force_closed':False,'virial_reaction_closed':False,'physical_forward33_closed':False,'physical_rank_closed':False,'physical_mhat2_closed':False}
def run(recursive=False):
 s=SovereignSolver();r=s.solve_universal(seeds,world=world,max_waves=2 if recursive else 1,max_calls=32000 if recursive else 15000,stable_waves=1)
 known=list(s.engine.known.values());counts=r.get('mechanism_execution_counts') or {};by={p.payload['problem_id']:collections.Counter() for p in seeds};front=[]
 for n in known:
  if len(n.context)>=2 and n.context[0]=='DELTA_CDM_PASS112':
   pid=n.context[1]
   if pid in by:by[pid][str(n.payload.get('status') or n.kind)]+=1
   st=str(n.payload.get('status') or '')
   if st in {'NEED_DATA','WAITING','OPEN','INVALID','PARTIAL','MISSING_CARRIER'} and n.kind not in {'AUX_OBSERVATION','MECHANISM_OBSERVATION'}:
    front.append({'problem_id':pid,'kind':n.kind,'status':st,'requires':n.payload.get('requires'),'unresolved_requirements':n.payload.get('unresolved_requirements'),'mechanism':n.payload.get('mechanism'),'statement':n.payload.get('statement')})
 out={'schema':'DELTA_CDM_PASS112_AC77_AUDIT_V1','mode':'recursive' if recursive else 'direct','solver_version':r.get('version'),'run_state':r.get('run_state'),'active_mechanism_count':r.get('active_mechanism_count'),'mechanisms_touched':sum(1 for v in counts.values() if v),'execution_calls':r.get('execution_calls'),'known_node_count':r.get('known_node_count'),'open_residual_count':r.get('open_residual_count'),'periodic_cartesian_receipt_count':r.get('periodic_cartesian_receipt_count'),'solution_certified':r.get('solution_certified'),'formal_proof_verified':r.get('formal_proof_verified'),'problem_status_counters':{k:dict(v) for k,v in by.items()},'declared_seed_requirements':{p.payload['problem_id']:p.payload.get('requires',[]) for p in seeds},'frontier_nonpass_count':len(front),'frontier_nonpass':front,'mechanism_execution_counts':counts}
 name='AC77_PASS112_RECURSIVE_AUDIT.json' if recursive else 'AC77_PASS112_DIRECT_AUDIT.json';(ROOT/'receipts/PASS112'/name).write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');(ROOT/'receipts/PASS112/PASS112_SEED_REGISTRY.json').write_text(json.dumps([n.to_dict() for n in seeds],indent=2,ensure_ascii=False)+'\n');return out
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--recursive',action='store_true');a=ap.parse_args();o=run(a.recursive);print(json.dumps({k:o[k] for k in ['mode','solver_version','run_state','active_mechanism_count','mechanisms_touched','execution_calls','known_node_count','open_residual_count','solution_certified','formal_proof_verified','declared_seed_requirements']},indent=2))
