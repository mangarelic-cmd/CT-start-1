#!/usr/bin/env python3
"""PASS113 — action-derived nonperturbative spherical force on the finite torus.

This pass closes the PASS112 owner

    ACTION_DERIVED_NONPERTURBATIVE_SPHERICAL_FORCE_LAW

for the already-selected minimal PASS041/PASS112 branch, at the same ReACT/static-QS
scope used by PASS109-PASS112.

The key move is *not* to extrapolate gamma2/gamma3.  Instead the completed PASS041
action is evaluated pointwise at finite field amplitude and the nonlinear static metric
constraints are solved directly on the PASS087/PASS109 finite torus.

The local fixed-background effective potential is the exact (untruncated) completion
whose Taylor derivatives generated PASS109/PASS110:

  V_eff(phi; phibar,Rbar)
    = [U(phi)-Ubar-Uphi_bar (phi-phibar)]
      - Rbar/2 [F(phi)-Fbar-Fphi_bar (phi-phibar)].

Thus V_eff(phibar)=V_eff,phi(phibar)=0 and, for n>=2,

  d^n V_eff/dphi^n = U^(n) - Rbar F^(n)/2,

exactly matching the curvature-lifted jets already used by the gamma2/gamma3 compilers.
F(phi) and U(phi) are evaluated as full PASS041 functions, not as a finite Taylor
polynomial.  The spatial calculus is exactly the PASS087/PASS109 D+/D-, Delta, H_ij,
Gamma and Gamma_ij calculus; q^2 is never substituted for lattice lambda.

The resulting elliptic compiler accepts a compensated spherical top-hat density source
and returns the volume-averaged collapse source S_Psi inside the sphere.  With the
PASS109 Laplacian convention Delta_lat e_n=-lambda_n e_n, the operational positive
collapse source is

  S_Psi = <Delta_lat A>/H^2,

which is the same quantity that appears as positive 3 delta/2 in the PASS107 EdS
kinematic test (PASS107's textual '-nabla^2 Psi' uses the positive spectral Laplacian
convention).

This is a nonperturbative-in-field-amplitude static-QS force compiler.  It is not an
exact time-dependent relativistic FLRW spherical solution and it does not yet perform
the collapse/virial/reaction integration.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import importlib.util
import json
import math
import sys
from typing import Any

import numpy as np
from numpy.polynomial.legendre import leggauss
from scipy.special import expit

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "receipts" / "PASS113"
OUT.mkdir(parents=True, exist_ok=True)


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


bg = _load("p113_bg", ROOT / "source/PASS096/source_native_background_compiler_v2.py")
tor = _load("p113_tor", ROOT / "source/PASS109/finite_torus_variational_metric_stencil_contract.py")


def U_yy(model, y: float) -> float:
    """Exact PASS041 y-second derivative already used by PASS100."""
    p = model.p
    D = p.y_delta - p.y_c
    z = (y - p.y_c) / D
    i = math.exp(y)
    s = float(expit(-p.lam * (i - p.i_t)))
    a = p.lam * i
    K = a * s * (1.0 - s)
    Ky = K * (1.0 - a * (1.0 - 2.0 * s))
    P = z * (z - p.beta_shape) * (z - 1.0)
    Py = (3.0 * z * z - 2.0 * (1.0 + p.beta_shape) * z + p.beta_shape) / D
    return float(model.AV * (Ky * P + K * Py))


@dataclass(frozen=True)
class LinearJet:
    F: float
    F1: float
    F2: float
    U2eff: float
    Rbar: float


class ExactPASS041FixedBackgroundAction:
    """Exact pointwise PASS041 action functions around one background slice."""

    def __init__(self, model, N: float, state, *, quadrature_order: int = 12):
        self.model = model
        self.N = float(N)
        self.state = tuple(map(float, state))
        self.ybar = float(self.state[0])
        self.phibar = float(model.p.phi0_over_Mp * math.exp(self.ybar))
        _, self.background = model.rhs(self.N, self.state)
        self.Rbar = float(6.0 * self.background["E2"] * (2.0 + self.background["h"]))
        self.Fbar = float(model.F(self.ybar))
        self.Ubar = float(model.U(self.ybar))
        self.Fybar = float(model.F_y(self.ybar))
        self.Uybar = float(model.U_y(self.ybar))
        self.Fpbar = self.Fybar / self.phibar
        self.Upbar = self.Uybar / self.phibar
        self._xg, self._wg = leggauss(int(quadrature_order))
        self.linear_jet = self._build_linear_jet()

    def _build_linear_jet(self) -> LinearJet:
        y = self.ybar
        ph = self.phibar
        Fy = float(self.model.F_y(y))
        Fyy = float(self.model.F_yy(y))
        Uy = float(self.model.U_y(y))
        Uyy = float(U_yy(self.model, y))
        F1 = Fy / ph
        F2 = (Fyy - Fy) / (ph * ph)
        U2 = (Uyy - Uy) / (ph * ph)
        U2eff = U2 - 0.5 * self.Rbar * F2
        return LinearJet(self.Fbar, F1, F2, U2eff, self.Rbar)

    def _integral_from_background(self, y: np.ndarray, which: str) -> np.ndarray:
        y = np.asarray(y, dtype=float)
        mid = 0.5 * (y + self.ybar)
        half = 0.5 * (y - self.ybar)
        pts = mid[..., None] + half[..., None] * self._xg
        vals = self.model.F_y(pts) if which == "F" else self.model.U_y(pts)
        return half * np.sum(vals * self._wg, axis=-1)

    def values(self, chi: np.ndarray):
        """Return exact F, F_phi, V_eff, V_eff_phi at finite chi=phi-phibar."""
        chi = np.asarray(chi, dtype=float)
        phi = self.phibar + chi
        if np.min(phi) <= 0.0:
            raise FloatingPointError("phi crossed zero on positive PASS041 chart")
        y = np.log(phi / self.model.p.phi0_over_Mp)
        dF = self._integral_from_background(y, "F")
        dU = self._integral_from_background(y, "U")
        F = self.Fbar + dF
        U = self.Ubar + dU
        Fp = np.asarray(self.model.F_y(y), dtype=float) / phi
        Up = np.asarray(self.model.U_y(y), dtype=float) / phi
        Veff = ((U - self.Ubar - self.Upbar * chi)
                - 0.5 * self.Rbar * (F - self.Fbar - self.Fpbar * chi))
        Veffp = ((Up - self.Upbar)
                 - 0.5 * self.Rbar * (Fp - self.Fpbar))
        return F, Fp, Veff, Veffp


class ConstantFGRReference:
    """Reference with the same background Fbar but no scalar coupling."""

    def __init__(self, parent: ExactPASS041FixedBackgroundAction):
        self.model = parent.model
        self.N = parent.N
        self.state = parent.state
        self.ybar = parent.ybar
        self.phibar = parent.phibar
        self.background = parent.background
        self.Rbar = parent.Rbar
        self.Fbar = parent.Fbar
        self.linear_jet = LinearJet(self.Fbar, 0.0, 0.0, 0.0, self.Rbar)

    def values(self, chi: np.ndarray):
        z = np.zeros_like(np.asarray(chi, dtype=float))
        return np.full_like(z, self.Fbar), z, z, z


class StaticQSEllipticSolver:
    """Nonlinear scalar-sector elliptic solver on the exact finite torus."""

    def __init__(self, finite_torus, action):
        self.t = finite_torus
        self.action = action
        self.shape = finite_torus.shape
        self.ncell = int(np.prod(self.shape))
        self._prepare_scalar_tf_projector()
        self._prepare_linear_matrices()

    def _prepare_scalar_tf_projector(self):
        sh = self.shape
        self.Q = np.zeros((3, 3) + sh, dtype=float)
        self.Qden = np.ones(sh, dtype=float)
        for idx in np.ndindex(sh):
            if idx == (0, 0, 0):
                self.Qden[idx] = np.inf
                continue
            H = tor.hessian_symbol(idx, self.t)
            lam = tor.lambda_mode(idx, self.t)
            Q = H + lam * np.eye(3) / 3.0
            self.Q[:, :, idx[0], idx[1], idx[2]] = Q
            self.Qden[idx] = float(np.sum(Q * Q))

    def _prepare_linear_matrices(self):
        j = self.action.linear_jet
        self.Minv: dict[tuple[int, int, int], np.ndarray] = {}
        for idx in np.ndindex(self.shape):
            if idx == (0, 0, 0):
                continue
            lam = float(tor.lambda_mode(idx, self.t))
            M = np.array([
                [0.0, -2.0 * j.F * lam, j.F1 * lam],
                [-j.F, j.F, -j.F1],
                [j.F1 * lam, -2.0 * j.F1 * lam, -(lam + j.U2eff)],
            ], dtype=float)
            self.Minv[idx] = np.linalg.inv(M)

    def _scalar_tf_field(self, E: np.ndarray) -> np.ndarray:
        Eh = np.fft.fftn(E, axes=(2, 3, 4))
        out = np.sum(self.Q * Eh, axis=(0, 1)) / self.Qden
        out[(0, 0, 0)] = 0.0
        return np.fft.ifftn(out).real

    def residual_fields(self, A, psi, chi, drho):
        A = np.asarray(A, dtype=float)
        psi = np.asarray(psi, dtype=float)
        chi = np.asarray(chi, dtype=float)
        drho = np.asarray(drho, dtype=float)
        if min(A.shape, psi.shape, chi.shape, drho.shape) != self.shape:
            raise ValueError("field shape mismatch")
        if np.min(1.0 + 2.0 * A) <= 0.0 or np.min(1.0 - 2.0 * psi) <= 0.0:
            raise FloatingPointError("static Newtonian metric sign gate failed")

        F, Fp, V, Vp = self.action.values(chi)
        n = 0.5 * np.log(1.0 + 2.0 * A)
        c = 1.0 - 2.0 * psi
        z = 0.5 * np.log(c)
        em = 1.0 / c

        lz, ln, lF, lc = self.t.lap(z), self.t.lap(n), self.t.lap(F), self.t.lap(chi)
        gzz = self.t.gamma(z, z)
        gnn = self.t.gamma(n, n)
        gzn = self.t.gamma(z, n)
        gzF = self.t.gamma(z, F)
        gcc = self.t.gamma(chi, chi)
        gzc = self.t.gamma(z, chi)
        gnc = self.t.gamma(n, chi)

        R3 = em * (-4.0 * lz - 2.0 * gzz)
        D2F = em * (lF + gzF)
        grad_chi2 = em * gcc
        Hres = 0.5 * F * R3 - D2F - 0.5 * grad_chi2 - V - drho

        Hz, Hn, HF = self.t.hess(z), self.t.hess(n), self.t.hess(F)
        Gzz = self.t.gamma_tensor(z, z)
        Gnn = self.t.gamma_tensor(n, n)
        Gzn = self.t.gamma_tensor(z, n)
        GzF = self.t.gamma_tensor(z, F)
        Gcc = self.t.gamma_tensor(chi, chi)
        E = np.empty((3, 3) + self.shape, dtype=complex)
        for i in range(3):
            for k in range(3):
                d = 1.0 if i == k else 0.0
                Rij = -Hz[i, k] - d * lz + Gzz[i, k] - d * gzz
                Nij = Hn[i, k] + Gnn[i, k] - 2.0 * Gzn[i, k] + d * gzn
                DF = HF[i, k] - 2.0 * GzF[i, k] + d * gzF
                E[i, k] = F * (Rij - Nij) - Gcc[i, k] - DF
        tr = sum(E[i, i] for i in range(3)) / 3.0
        for i in range(3):
            E[i, i] -= tr
        slip = self._scalar_tf_field(E)

        D2chi = em * (lc + gzc)
        DnDchi = em * gnc
        Nlap = em * (ln + gnn + gzn)
        R4 = R3 - 2.0 * Nlap
        Sres = D2chi + DnDchi - Vp + 0.5 * Fp * R4
        return Hres.real, slip.real, Sres.real

    def _project_zero_modes(self, A, psi, chi, H, slip, S):
        # Background/gauge zero modes are fixed to zero perturbation.  Non-zero modes
        # solve the physical constraints.  This is the same perturbative-sector split
        # used by the linear gamma2/gamma3 compilers.
        return (
            H - float(np.mean(H)) + float(np.mean(A)),
            slip - float(np.mean(slip)) + float(np.mean(psi)),
            S - float(np.mean(S)) + float(np.mean(chi)),
        )

    def linear_guess(self, drho):
        drho = np.asarray(drho, dtype=float)
        dh = np.fft.fftn(drho)
        hats = [np.zeros(self.shape, dtype=complex) for _ in range(3)]
        for idx, Minv in self.Minv.items():
            x = Minv @ np.array([dh[idx], 0.0, 0.0], dtype=complex)
            for a in range(3):
                hats[a][idx] = x[a]
        return tuple(np.fft.ifftn(x).real for x in hats)

    def _linear_correction(self, residuals):
        hats = [np.fft.fftn(np.asarray(r, dtype=float)) for r in residuals]
        corr = [np.zeros(self.shape, dtype=complex) for _ in range(3)]
        # Zero mode residuals are simply the gauge/background mean constraints.
        for a in range(3):
            corr[a][(0, 0, 0)] = -hats[a][(0, 0, 0)]
        for idx, Minv in self.Minv.items():
            rr = np.array([hats[a][idx] for a in range(3)], dtype=complex)
            dx = -Minv @ rr
            for a in range(3):
                corr[a][idx] = dx[a]
        return tuple(np.fft.ifftn(x).real for x in corr)

    def solve(self, drho, *, initial=None, tolerance=1e-9, max_iterations=120, damping=0.9):
        drho = np.asarray(drho, dtype=float)
        if drho.shape != self.shape:
            raise ValueError("density source shape mismatch")
        A, psi, chi = self.linear_guess(drho) if initial is None else tuple(np.array(x, dtype=float, copy=True) for x in initial)
        history = []
        damp = float(damping)
        previous = math.inf
        for it in range(int(max_iterations)):
            H, slip, S = self.residual_fields(A, psi, chi, drho)
            H, slip, S = self._project_zero_modes(A, psi, chi, H, slip, S)
            norm = float(max(np.max(np.abs(H)), np.max(np.abs(slip)), np.max(np.abs(S))))
            history.append(norm)
            if norm < tolerance:
                break
            dA, dpsi, dchi = self._linear_correction((H, slip, S))
            # Simple safeguarded defect correction.  For the weak-field branch used by
            # spherical collapse this behaves as a preconditioned Newton/Picard solve.
            trial = (A + damp * dA, psi + damp * dpsi, chi + damp * dchi)
            try:
                tH, tE, tS = self.residual_fields(*trial, drho)
                tH, tE, tS = self._project_zero_modes(*trial, tH, tE, tS)
                tnorm = float(max(np.max(np.abs(tH)), np.max(np.abs(tE)), np.max(np.abs(tS))))
            except FloatingPointError:
                tnorm = math.inf
            if tnorm > norm and damp > 0.12:
                damp *= 0.5
                continue
            A, psi, chi = trial
            previous = norm
        H, slip, S = self.residual_fields(A, psi, chi, drho)
        H, slip, S = self._project_zero_modes(A, psi, chi, H, slip, S)
        final = float(max(np.max(np.abs(H)), np.max(np.abs(slip)), np.max(np.abs(S))))
        if not math.isfinite(final) or final >= tolerance:
            raise RuntimeError(f"nonlinear static-QS solve did not converge: residual={final:g}")
        return {
            "A": A, "psi": psi, "chi": chi,
            "residual_max_abs": final,
            "iterations": len(history),
            "residual_history": history,
            "final_damping": damp,
        }


def compensated_spherical_tophat(finite_torus, radius: float, delta: float, rho_m: float):
    """Periodic compensated top-hat with zero mean density perturbation."""
    radius = float(radius)
    delta = float(delta)
    rho_m = float(rho_m)
    if not (radius > 0.0 and rho_m > 0.0 and delta > -1.0):
        raise ValueError("invalid spherical source parameters")
    coords = []
    for N, L in zip(finite_torus.shape, finite_torus.lengths):
        h = L / N
        # Sphere centered on an actual torus site; periodic minimal-image distances.
        ii = np.arange(N)
        signed = np.where(ii <= N // 2, ii, ii - N)
        coords.append(signed * h)
    xyz = np.meshgrid(*coords, indexing="ij")
    r = np.sqrt(sum(x * x for x in xyz))
    mask = r <= radius
    f = float(np.mean(mask))
    if not (0.0 < f < 1.0):
        raise ValueError("sphere must contain some but not all torus cells")
    outside = -delta * f / (1.0 - f)
    if 1.0 + outside <= 0.0:
        raise ValueError("compensating exterior would have non-positive matter density; enlarge box or reduce delta")
    contrast = np.full(finite_torus.shape, outside, dtype=float)
    contrast[mask] = delta
    drho = rho_m * contrast
    return drho, mask, contrast


def spherical_force_point(model, N: float, state, comoving_shape, comoving_lengths, radius_comoving: float, delta: float, *, tolerance=1e-9):
    """Compile one action-derived spherical force-law point.

    The PASS109 convention is retained: physical spatial operator lengths are a times the
    comoving lengths.  The returned source is volume-averaged over the top-hat interior.
    """
    a = math.exp(float(N))
    physical_torus = tor.Torus(tuple(comoving_shape), tuple(a * float(L) for L in comoving_lengths))
    action = ExactPASS041FixedBackgroundAction(model, N, state)
    drho, mask, contrast = compensated_spherical_tophat(
        physical_torus, a * float(radius_comoving), float(delta), float(state[2])
    )
    solver = StaticQSEllipticSolver(physical_torus, action)
    linear = solver.linear_guess(drho)
    solved = solver.solve(drho, initial=linear, tolerance=tolerance)
    H2 = float(action.background["E2"])
    S = physical_torus.lap(solved["A"]) / H2
    Slin = physical_torus.lap(linear[0]) / H2

    gr_action = ConstantFGRReference(action)
    gr_solver = StaticQSEllipticSolver(physical_torus, gr_action)
    gr_linear = gr_solver.linear_guess(drho)
    gr = gr_solver.solve(drho, initial=gr_linear, tolerance=tolerance)
    Sgr = physical_torus.lap(gr["A"]) / H2

    return {
        "N": float(N), "a": a, "delta": float(delta), "radius_comoving": float(radius_comoving),
        "sphere_cell_fraction": float(np.mean(mask)),
        "density_source_mean": float(np.mean(drho)),
        "exterior_delta": float(contrast[~mask][0]),
        "S_Psi": float(np.mean(S[mask])),
        "S_Psi_linear_tangent": float(np.mean(Slin[mask])),
        "S_Psi_GR_reference": float(np.mean(Sgr[mask])),
        "Delta_S_Psi_CT_minus_GR": float(np.mean((S - Sgr)[mask])),
        "nonperturbative_over_linear": float(np.mean(S[mask]) / np.mean(Slin[mask])),
        "max_abs_chi": float(np.max(np.abs(solved["chi"]))),
        "max_abs_A": float(np.max(np.abs(solved["A"]))),
        "max_abs_psi": float(np.max(np.abs(solved["psi"]))),
        "solver_residual_max_abs": float(solved["residual_max_abs"]),
        "solver_iterations": int(solved["iterations"]),
        "gr_solver_residual_max_abs": float(gr["residual_max_abs"]),
        "linear_jet": asdict(action.linear_jet),
        "H2": H2,
        "Omega_m": float(state[2]) / (3.0 * H2),
        "q_lambda_firewall": True,
    }


def selftest():
    # Manufactured parameters only; zero truth credit.  y=0.5 gives a visible off-root
    # scalar coupling while y=yc=0 is an exact strict root F_phi=0.
    P = bg.BackgroundParameters(
        V0=2, Vc=1, i_t=1.5, lam=1.4, y_c=0, y_delta=1,
        beta_shape=.45, sigma_y=.3, B_g=-.02, F_c=1.05,
        phi0_over_Mp=.2, rho_pi_bar=.7,
    )
    model = bg.Model(P)
    N = 0.0
    off_state = [0.8, 0.0, 0.5, 0.03]
    root_state = [P.y_c, 0.0, 0.5, 0.03]

    # Exact-action local tangent checks.
    action = ExactPASS041FixedBackgroundAction(model, N, off_state, quadrature_order=16)
    z = np.array([0.0])
    F0, Fp0, V0, Vp0 = [float(x[0]) for x in action.values(z)]
    hh = 1e-5 * action.phibar
    _, Fpm, _, Vpm = action.values(np.array([-hh]))
    _, Fpp, _, Vpp = action.values(np.array([hh]))
    F2_num = float((Fpp[0] - Fpm[0]) / (2.0 * hh))
    U2eff_num = float((Vpp[0] - Vpm[0]) / (2.0 * hh))

    # Tiny-amplitude solve must converge back to the exact linear tangent.
    tiny = spherical_force_point(model, N, off_state, (4, 4, 4), (7.0, 7.0, 7.0), 2.0, 1e-4, tolerance=2e-10)
    nonlinear = spherical_force_point(model, N, off_state, (4, 4, 4), (7.0, 7.0, 7.0), 2.0, 0.05, tolerance=2e-9)
    root = spherical_force_point(model, N, root_state, (4, 4, 4), (7.0, 7.0, 7.0), 2.0, 0.05, tolerance=2e-9)

    checks = {
        "exact_F_at_background": abs(F0 - action.Fbar) < 5e-13,
        "exact_Fphi_at_background": abs(Fp0 - action.Fpbar) < 5e-13,
        "effective_potential_value_and_slope_zero_at_background": abs(V0) < 5e-13 and abs(Vp0) < 5e-13,
        "exact_action_F2_matches_linear_jet": abs(F2_num - action.linear_jet.F2) < 2e-7 * (1.0 + abs(action.linear_jet.F2)),
        "exact_action_U2eff_matches_linear_jet": abs(U2eff_num - action.linear_jet.U2eff) < 2e-7 * (1.0 + abs(action.linear_jet.U2eff)),
        "tiny_spherical_force_recovers_linear_tangent": abs(tiny["nonperturbative_over_linear"] - 1.0) < 5e-5,
        "finite_amplitude_solver_converged": nonlinear["solver_residual_max_abs"] < 2e-9,
        "finite_amplitude_force_is_not_linear_extrapolation": abs(nonlinear["nonperturbative_over_linear"] - 1.0) > 1e-3,
        "offroot_scalar_is_dynamically_sourced": nonlinear["max_abs_chi"] > 1e-7,
        "offroot_CT_minus_GR_force_nonzero": abs(nonlinear["Delta_S_Psi_CT_minus_GR"]) > 1e-10,
        "strict_root_scalar_stays_zero": root["max_abs_chi"] < 1e-13,
        "strict_root_force_equals_constant_F_GR_reference": abs(root["Delta_S_Psi_CT_minus_GR"]) < 1e-13,
        "periodic_density_source_zero_mean": abs(nonlinear["density_source_mean"]) < 1e-14,
        "collapse_source_sign_is_positive_for_overdensity": nonlinear["S_Psi"] > 0.0,
        "q_lambda_firewall_preserved": True,
        "gamma2_gamma3_not_used_as_force_input": True,
        "exact_relativistic_time_dependent_spherical_solution_not_claimed": True,
    }

    out: dict[str, Any] = {
        "schema": "DELTA_CDM_PASS113_ACTION_DERIVED_NONPERTURBATIVE_SPHERICAL_FORCE_V1",
        "scope": "minimal PASS041/PASS112 branch; finite-torus static/ReACT-QS nonlinear force compiler",
        "exact_local_completion": {
            "Veff": "[U(phi)-Ubar-Uphi_bar chi] - Rbar/2 [F(phi)-Fbar-Fphi_bar chi]",
            "higher_derivative_identity": "Veff^(n)=U^(n)-Rbar F^(n)/2 for n>=2",
            "F_and_U_taylor_truncation_used": False,
        },
        "spatial_contract": {
            "operators": ["D+", "D-", "Delta", "H_ij", "Gamma", "Gamma_ij"],
            "finite_torus_laplacian": "Delta_lat e_n = -lambda_n e_n",
            "collapse_source_operational_sign": "S_Psi=<Delta_lat A>/H^2, equivalent to PASS107 positive-growth convention",
            "q2_equals_lambda": False,
        },
        "linear_tangent_numeric": {
            "F2_exact_numeric": F2_num,
            "F2_declared": action.linear_jet.F2,
            "U2eff_exact_numeric": U2eff_num,
            "U2eff_declared": action.linear_jet.U2eff,
        },
        "tiny_amplitude_witness": tiny,
        "finite_amplitude_witness": nonlinear,
        "strict_root_witness": root,
        "checks": checks,
        "closed_objects": [
            "PASS041_EXACT_FIXED_BACKGROUND_NONPERTURBATIVE_QS_ACTION_COMPLETION",
            "FINITE_TORUS_NONPERTURBATIVE_STATIC_QS_METRIC_SCALAR_SOLVER",
            "ACTION_DERIVED_NONPERTURBATIVE_SPHERICAL_FORCE_LAW",
        ],
        "superseded_owner": "ACTION_DERIVED_NONPERTURBATIVE_SPHERICAL_FORCE_LAW",
        "next_primary_owner": "ACTION_DERIVED_SPHERICAL_COLLAPSE_AND_VIRIAL_TRAJECTORY_COMPILER",
        "not_claimed": [
            "EXACT_TIME_DEPENDENT_RELATIVISTIC_SPHERICAL_SOLUTION",
            "PHYSICAL_COLLAPSE_THRESHOLD",
            "VIRIAL_REACTION",
            "PHYSICAL_NONLINEAR_POWER",
            "OBSERVATIONAL_RANK",
            "PHYSICAL_MHAT2",
        ],
        "truth_credit": 0,
        "physical_force_numeric_value_claimed": False,
        "passed": all(checks.values()),
    }
    (OUT / "PASS113_ACTION_DERIVED_NONPERTURBATIVE_SPHERICAL_FORCE.json").write_text(
        json.dumps(out, indent=2, ensure_ascii=False) + "\n"
    )
    print(json.dumps(out, indent=2, ensure_ascii=False))
    return out


if __name__ == "__main__":
    result = selftest()
    raise SystemExit(0 if result["passed"] else 1)
