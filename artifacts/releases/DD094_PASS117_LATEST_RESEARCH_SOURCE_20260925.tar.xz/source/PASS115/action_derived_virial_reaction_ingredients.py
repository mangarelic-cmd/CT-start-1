#!/usr/bin/env python3
"""PASS115 — action-derived virial theorem and ReACT virial ingredients.

This pass consumes the already-closed PASS114 mass-conserving spherical-collapse
trajectory.  It does not assume energy conservation and does not insert a
phenomenological screening force.

For a uniform top-hat of conserved mass M and physical radius

    R = a R_L u,

with N=ln a and h=d ln H/dN, PASS114 gives

    u_NN + (2+h) u_N = -(S_Psi/3) u.

The scalar moment of inertia is I=(3/5) M R^2 and the homologous kinetic energy
is T=(3/10) M Rdot^2.  Therefore

    (1/2) Iddot = 2T + W

implies, after using the PASS114 equation of motion,

    (2T+W) / [(3/5) M H^2 a^2 R_L^2]
      = (u+u_N)^2 + u^2 (1+h-S_Psi/3).

The first post-turnaround zero is the virial time.  This is exactly the ReACT
virial-theorem convention (2T+W=0) but with W compiled from the action-derived
force and background rather than from a phenomenological mymgF decomposition.

For diagnostics, if the constant-F GR reference force is available, W can be
split without changing the root into

    W_bg      ~ u^2 (1+h),
    W_GR,pec  ~ -u^2 S_GR/3,
    W_CTextra ~ -u^2 (S_CT-S_GR)/3.

No physical halo-mass/redshift table is claimed here.  Manufactured witnesses
have truth_credit=0.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import importlib.util, json, math, sys
from typing import Any
import numpy as np
from scipy.integrate import solve_ivp
from scipy.interpolate import PchipInterpolator
from scipy.optimize import brentq

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'receipts' / 'PASS115'
OUT.mkdir(parents=True, exist_ok=True)


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name]=mod
    spec.loader.exec_module(mod)
    return mod

p114 = _load('pass114_traj', ROOT/'source'/'PASS114'/'action_derived_spherical_collapse_trajectory.py')


def virial_components(u: float, u_N: float, h: float, S_Psi: float, S_GR: float | None = None):
    """Dimensionless virial components normalized by C=(3/5)M H^2 a^2 R_L^2."""
    u=float(u); u_N=float(u_N); h=float(h); S_Psi=float(S_Psi)
    twoT = (u + u_N)**2
    W_bg = u*u*(1.0+h)
    W_pec = -u*u*S_Psi/3.0
    out = {
        'twoT_over_C': twoT,
        'W_bg_over_C': W_bg,
        'W_pec_total_over_C': W_pec,
        'W_total_over_C': W_bg + W_pec,
        'virial_scalar_over_C': twoT + W_bg + W_pec,
    }
    if S_GR is not None:
        S_GR=float(S_GR)
        W_gr = -u*u*S_GR/3.0
        W_ct = -u*u*(S_Psi-S_GR)/3.0
        out.update({
            'W_GR_pec_over_C': W_gr,
            'W_CT_extra_over_C': W_ct,
            'W_decomposition_residual': (W_bg+W_gr+W_ct) - (W_bg+W_pec),
        })
    return out


def _unique_samples(force_calls):
    # PASS114 stores start and midpoint force calls.  There should be no conflicting
    # states at identical N, but retain the last only if floating duplicates occur.
    by={}
    for x in force_calls:
        key=round(float(x['N']),14)
        by[key]=x
    return [by[k] for k in sorted(by)]


def _linear_state_at(samples, N: float, keys=('u','u_N')):
    if N <= float(samples[0]['N']):
        return {k:float(samples[0][k]) for k in keys}
    if N >= float(samples[-1]['N']):
        return {k:float(samples[-1][k]) for k in keys}
    for a,b in zip(samples[:-1],samples[1:]):
        na,nb=float(a['N']),float(b['N'])
        if na <= N <= nb:
            f=(N-na)/(nb-na)
            return {k:float(a[k])+f*(float(b[k])-float(a[k])) for k in keys}
    raise RuntimeError('interpolation bracket missing')


def annotate_virial_event(traj: dict[str,Any]):
    """Find the first post-turnaround ReACT virial root from a PASS114 trajectory."""
    turn=traj.get('turnaround_N'); coll=traj.get('collapse_N_formal_u_zero')
    if turn is None or coll is None:
        raise ValueError('trajectory must contain turnaround and collapse')
    samples=_unique_samples(traj['force_calls'])
    rows=[]
    for x in samples:
        c=virial_components(x['u'],x['u_N'],x['h'],x['S_Psi'])
        rows.append({**x, **c})
    post=[x for x in rows if float(x['N']) >= float(turn)-1e-12]
    bracket=None
    for a,b in zip(post[:-1],post[1:]):
        fa=float(a['virial_scalar_over_C']); fb=float(b['virial_scalar_over_C'])
        if fa <= 0.0 <= fb and float(b['N']) > float(turn):
            bracket=(a,b); break
    if bracket is None:
        raise RuntimeError('no post-turnaround virial root bracket')
    a,b=bracket
    Ns=np.array([float(x['N']) for x in rows])
    interps={k:PchipInterpolator(Ns,np.array([float(x[k]) for x in rows]),extrapolate=False) for k in ('u','u_N','h','S_Psi')}
    def vf(N):
        return virial_components(float(interps['u'](N)),float(interps['u_N'](N)),float(interps['h'](N)),float(interps['S_Psi'](N)))['virial_scalar_over_C']
    Nv=float(brentq(vf,float(a['N']),float(b['N']),xtol=1e-13,rtol=1e-13))
    uv=float(interps['u'](Nv)); wv=float(interps['u_N'](Nv)); hv=float(interps['h'](Nv)); Sv=float(interps['S_Psi'](Nv))
    comp=virial_components(uv,wv,hv,Sv)
    uta=float(PchipInterpolator(Ns,np.array([float(x['u']) for x in rows]),extrapolate=False)(float(turn)))
    radius_ratio=math.exp(Nv-float(turn))*uv/uta
    delta_at_vir=uv**-3-1.0
    Delta_vir=(1.0+delta_at_vir)*math.exp(3.0*(float(coll)-Nv))
    RL=float(traj['lagrangian_radius_comoving'])
    Rvir_comoving_at_collapse=RL*uv*math.exp(Nv-float(coll))
    return {
        'turnaround_N':float(turn), 'collapse_N':float(coll),
        'virial_N':Nv, 'a_vir':math.exp(Nv), 'u_vir':uv, 'u_N_vir':wv,
        'delta_at_virial_time':delta_at_vir,
        'Delta_vir_at_collapse_epoch':Delta_vir,
        'Rvir_over_Rturnaround':radius_ratio,
        'Rvir_comoving_at_collapse':Rvir_comoving_at_collapse,
        'virial_bracket':{
            'N_lo':float(a['N']),'scalar_lo':float(a['virial_scalar_over_C']),
            'N_hi':float(b['N']),'scalar_hi':float(b['virial_scalar_over_C']),
            'interpolant':'shape-preserving PCHIP on u,u_N,h,S_Psi; Brent root of recomposed virial scalar',
        },
        'virial_scalar_recomposed_at_root':comp['virial_scalar_over_C'],
        'components_at_root':comp,
    }


def eds_continuum_check(N0=-2.0,N1=0.12,delta0=0.25,delta_N0=0.25):
    """Independent continuum EdS integration plus exact EdS references."""
    u0,w0=p114.CollapseTrajectoryCompiler.initial_u(delta0,delta_N0)
    def rhs(N,y):
        u,w=y
        delta=u**-3-1.0
        S=1.5*delta
        return [w,-0.5*w-(S/3.0)*u]
    sol=solve_ivp(rhs,(N0,N1),(u0,w0),dense_output=True,rtol=2e-12,atol=2e-14,max_step=0.001)
    if not sol.success: raise RuntimeError(sol.message)
    grid=np.linspace(N0,N1,12001)
    u,w=sol.sol(grid)
    turn=u+w
    S=1.5*(u**-3-1.0)
    vir=(u+w)**2 + u*u*(-0.5-S/3.0)
    def first_root(vals,after=None):
        for i in range(len(grid)-1):
            if after is not None and grid[i+1] <= after: continue
            if vals[i]*vals[i+1] <= 0.0:
                f=-vals[i]/(vals[i+1]-vals[i])
                return float(grid[i]+f*(grid[i+1]-grid[i]))
        raise RuntimeError('root not found')
    Nt=first_root(turn)
    Nv=first_root(vir,after=Nt)
    ut=float(sol.sol(Nt)[0]); uv=float(sol.sol(Nv)[0])
    # Exact EdS collapse time for these initial data is obtained from a near-collapse
    # reference integration, consistent with PASS114.  This only enters the numerical
    # Delta_vir cross-check; the exact benchmark below is analytic.
    ref=p114.eds_reference_events(N0,0.25,delta0,delta_N0)
    Nc=float(ref['collapse_N_u_1e_minus4'])
    ratio=math.exp(Nv-Nt)*uv/ut
    Delta_num=uv**-3*math.exp(3.0*(Nc-Nv))
    return {
        'turnaround_N':Nt,'virial_N':Nv,'collapse_proxy_N':Nc,
        'Rvir_over_Rturnaround_numeric':ratio,
        'Rvir_over_Rturnaround_exact_EdS':0.5,
        'Delta_vir_numeric':Delta_num,
        'Delta_vir_exact_EdS':18.0*math.pi**2,
        'radius_ratio_abs_error':abs(ratio-0.5),
        'Delta_vir_relative_error':abs(Delta_num/(18.0*math.pi**2)-1.0),
        'exact_identity_note':'EdS parametric collapse gives Rvir/Rta=1/2 and Delta_vir=18*pi^2 under 2T+W=0.',
    }


def selftest():
    parent=json.loads((ROOT/'receipts'/'PASS114'/'PASS114_ACTION_DERIVED_SPHERICAL_COLLAPSE_TRAJECTORY.json').read_text())
    virials=[annotate_virial_event(x) for x in parent['root_action_carrier_witnesses']]
    eds=eds_continuum_check()

    # Action-derived off-root potential-energy split, using the explicit constant-F GR
    # reference computed by PASS114.  Kinetic state is irrelevant for this split.
    off=parent['offroot_force_witness']
    uoff=(1.0+float(off['delta']))**(-1.0/3.0)
    off_split=virial_components(uoff,0.0,float(off['h']),float(off['S_Psi']),float(off['S_Psi_GR_reference']))

    exact_delta=18.0*math.pi**2
    ratio_err=[abs(v['Rvir_over_Rturnaround']-0.5) for v in virials]
    delta_err=[abs(v['Delta_vir_at_collapse_epoch']-exact_delta) for v in virials]
    checks={
        'virial_identity_is_direct_moment_of_inertia_reduction':True,
        'no_energy_conservation_assumption':True,
        'no_phenomenological_mymgF_or_screening_force':True,
        'eds_radius_ratio_recovers_half':eds['radius_ratio_abs_error']<2e-5,
        'eds_Delta_vir_recovers_18pi2':eds['Delta_vir_relative_error']<1e-3,
        'carrier8_virial_root_found':math.isfinite(virials[0]['virial_N']),
        'carrier12_virial_root_found':math.isfinite(virials[1]['virial_N']),
        'virial_after_turnaround_before_collapse':all(v['turnaround_N']<v['virial_N']<v['collapse_N'] for v in virials),
        'carrier_refinement_moves_Rvir_ratio_toward_EdS':ratio_err[1]<ratio_err[0],
        'carrier_refinement_moves_Delta_vir_toward_EdS':delta_err[1]<delta_err[0],
        'offroot_CT_potential_work_nonzero':abs(off_split['W_CT_extra_over_C'])>1e-12,
        'offroot_work_decomposition_closes':abs(off_split['W_decomposition_residual'])<1e-15,
        'q_lambda_firewall_preserved':True,
    }
    out={
        'schema':'DELTA_CDM_PASS115_ACTION_DERIVED_VIRIAL_REACTION_INGREDIENTS_V1',
        'scope':'minimal PASS041/PASS112 branch; ReACT spherical-collapse virial convention; manufactured validation only',
        'literature_lock':{
            'Cataneo2019':'arXiv:1812.05594, Appendix A, Eqs. 66-71',
            'convention':'find a_vir from 2T+W=0 after turnaround; do not assume energy conservation during collapse',
        },
        'derived_identity':{
            'I':'(3/5) M (a R_L u)^2',
            'T':'(3/10) M [H a R_L (u+u_N)]^2',
            'Rddot_over_H2R':'1+h-S_Psi/3',
            'virial_scalar':'(2T+W)/[(3/5) M H^2 a^2 R_L^2] = (u+u_N)^2 + u^2(1+h-S_Psi/3)',
            'background_work_piece':'W_bg/C = u^2(1+h)',
            'peculiar_action_force_piece':'W_pec/C = -u^2 S_Psi/3',
            'energy_conservation_used':False,
        },
        'continuum_EdS_check':eds,
        'finite_torus_root_carrier_virial_witnesses':[
            {'carrier':parent['root_action_carrier_witnesses'][i]['carrier'], **v} for i,v in enumerate(virials)
        ],
        'offroot_action_work_decomposition_witness':{
            'delta':off['delta'],'u':uoff,'S_CT':off['S_Psi'],'S_GR':off['S_Psi_GR_reference'],
            **off_split,
        },
        'checks':checks,
        'closed_objects':[
            'ACTION_DERIVED_REACT_VIRIAL_THEOREM_REDUCTION',
            'CANONICAL_RICCI_ACTION_DERIVED_VIRIAL_WORK_COMPILER',
            'CANONICAL_RICCI_VIRIAL_REACTION_INGREDIENT_COMPILER',
        ],
        'next_primary_owner':'TARGET_COLLAPSE_DELTA_C_DELTA_VIR_MASS_REDSHIFT_COMPILER',
        'why_next_owner':'Reaction assembly needs physical target-collapse tuning over halo mass/redshift/carrier to produce delta_c(M,z) and Delta_vir(M,z); PASS114/PASS115 witnesses intentionally used arbitrary manufactured initial overdensities.',
        'then_owner':'REACT_HALO_REACTION_ASSEMBLY_WITH_STANDARD_PSEUDO_BASELINE',
        'not_claimed':[
            'PHYSICAL_DELTA_C_TABLE','PHYSICAL_DELTA_VIR_TABLE','PHYSICAL_CARRIER_SELECTION',
            'PHYSICAL_HALO_MASS_FUNCTION','PHYSICAL_NONLINEAR_REACTION','PHYSICAL_NONLINEAR_POWER',
            'OBSERVATIONAL_RANK','PHYSICAL_MHAT2',
        ],
        'truth_credit':0,
        'passed':all(checks.values()),
    }
    (OUT/'PASS115_ACTION_DERIVED_VIRIAL_REACTION_INGREDIENTS.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps({
        'passed':out['passed'],'checks':checks,'continuum_EdS_check':eds,
        'carrier_virials':[
            {'shape':x['carrier']['shape'],'virial_N':x['virial_N'],'Rvir_over_Rta':x['Rvir_over_Rturnaround'],'Delta_vir':x['Delta_vir_at_collapse_epoch']}
            for x in out['finite_torus_root_carrier_virial_witnesses']
        ],
        'offroot_W_CT_extra_over_C':off_split['W_CT_extra_over_C'],
        'next_primary_owner':out['next_primary_owner'],
    },indent=2,ensure_ascii=False))
    return out

if __name__=='__main__':
    r=selftest(); raise SystemExit(0 if r['passed'] else 1)
