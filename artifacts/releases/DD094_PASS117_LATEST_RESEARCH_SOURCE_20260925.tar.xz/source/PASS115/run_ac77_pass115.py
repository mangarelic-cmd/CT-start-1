#!/usr/bin/env python3
from pathlib import Path
import sys, json, collections, argparse
ROOT=Path(__file__).resolve().parents[2]
ACROOT=ROOT/'runtime'/'AC77'/'SC_SOLVER_AC77_PERIODIC_CARTESIAN_THEOREM_METROLOGY_CORE_20260922'
sys.path.insert(0,str(ACROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver

BASE=[
 'FINITE_DISCRETE_TORUS_E1','Q_LAMBDA_FIREWALL_CERTIFICATE','PASS041_COMPLETED_ACTION_FAMILY',
 'PASS041_ACTION_DERIVATIVES_TO_QUARTIC_ORDER','FINITE_TORUS_RAW_SCALAR_QUADRATIC_CUBIC_VERTEX_COMPILER',
 'SPHERICAL_COLLAPSE_KINEMATIC_REDUCTION','NONLINEAR_METRIC_PROJECTION_FIREWALL',
 'CANONICAL_RICCI_EVOLVING_GAUGE_REDUCED_LINEAR_MODE_SOLVER','FINITE_TORUS_VARIATIONAL_METRIC_STENCIL_CONTRACT',
 'REACT_NONLINEAR_POISSON_QS_SCOPE_CONTRACT','CANONICAL_RICCI_FIXED_BACKGROUND_QS_CURVATURE_LIFT',
 'REACT_GAMMA2_NORMALIZATION_CONTRACT','CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA2_COMPILER',
 'PASS109_MINIMAL_VARIATIONAL_CUBIC_METRIC_PROJECTION_CANDIDATE','REACT_GAMMA3_NORMALIZATION_CONTRACT',
 'FINITE_TORUS_CUBIC_STENCIL_NONUNIQUENESS_WITNESS','PASS109_LINEAR_CONSTRAINT_VARIATIONAL_SYMMETRIZATION',
 'FINITE_TORUS_ACTION_LEVEL_CUBIC_NONUNIQUENESS_CERTIFICATE',
 'PASS086_STRICT_MINIMAL_FINITE_TORUS_ACTION_PULLBACK_RULE',
 'PASS041_TO_FINITE_TORUS_FULL_NONLINEAR_DISCRETE_ACTION_COMPLETION_RULE',
 'CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA3_COMPILER',
 'PASS041_EXACT_FIXED_BACKGROUND_NONPERTURBATIVE_QS_ACTION_COMPLETION',
 'FINITE_TORUS_NONPERTURBATIVE_STATIC_QS_METRIC_SCALAR_SOLVER',
 'ACTION_DERIVED_NONPERTURBATIVE_SPHERICAL_FORCE_LAW',
 'FINITE_TORUS_EXACT_VOLUME_SPHERICAL_MATTER_PROJECTION',
 'SPHERICAL_COLLAPSE_MASS_COORDINATE_REDUCTION',
 'ACTION_DERIVED_SPHERICAL_COLLAPSE_TRAJECTORY_EXECUTION',
 'CANONICAL_RICCI_SPHERICAL_COLLAPSE_FORCE_TRAJECTORY_COMPILER',
 'ACTION_DERIVED_REACT_VIRIAL_THEOREM_REDUCTION',
 'CANONICAL_RICCI_ACTION_DERIVED_VIRIAL_WORK_COMPILER',
 'CANONICAL_RICCI_VIRIAL_REACTION_INGREDIENT_COMPILER',
]

def seed(pid,statement,target,requires=(),supplies=(),**kw):
 p=dict(problem_id=pid,statement=statement,target=target,requires=list(requires),supplies=BASE+list(supplies),ground_binding=True);p.update(kw);return Node('PROBLEM',p,context=('DELTA_CDM_PASS115',pid))

TABLE='TARGET_COLLAPSE_DELTA_C_DELTA_VIR_MASS_REDSHIFT_COMPILER'
REACTION='REACT_HALO_REACTION_ASSEMBLY_WITH_STANDARD_PSEUDO_BASELINE'
seeds=[
 seed('P115_VIRIAL',
      'Compile the ReACT virial root 2T+W=0 directly from the PASS114 action-derived collapse trajectory using the exact moment-of-inertia identity, without assuming energy conservation or inserting mymgF.',
      'CANONICAL_RICCI_VIRIAL_REACTION_INGREDIENT_COMPILER',(),
      ('ACTION_DERIVED_REACT_VIRIAL_THEOREM_REDUCTION','CANONICAL_RICCI_ACTION_DERIVED_VIRIAL_WORK_COMPILER','CANONICAL_RICCI_VIRIAL_REACTION_INGREDIENT_COMPILER'),
      proof_object={'type':'action_derived_react_virial_work_compiler','receipt':'receipts/PASS115/PASS115_ACTION_DERIVED_VIRIAL_REACTION_INGREDIENTS.json'},
      uniformity_verified=True,
      boundaries={'energy_conservation_not_assumed':True,'no_phenomenological_screening':True,'physical_mass_redshift_table_not_claimed':True}),
 seed('P115_TARGET_TABLE',
      'For each independently admissible carrier, halo Lagrangian scale and target collapse redshift, tune the initial overdensity to the requested collapse epoch and compile the corresponding linearly extrapolated delta_c(M,z) and action-derived Delta_vir(M,z).',
      TABLE,(TABLE,),(),
      boundaries={'virial_mechanics_closed':True,'target_collapse_tuning_required':True,'mass_redshift_grid_required':True,'carrier_profile_required':True}),
 seed('P115_REACTION',
      'Assemble the ReACT halo reaction only after the physical target-collapse delta_c and Delta_vir tables are available, using the standard pseudo baseline rather than a free nonlinear CT residual.',
      REACTION,(TABLE,),(),
      boundaries={'standard_pseudo_baseline':True,'no_free_Delta_NL_field':True,'physical_target_table_required':True}),
]
world={
 'project':'DELTA_CDM_PASS115','available_evidence_tokens':BASE,'external_scientific_truth_certified':False,
 'finite_discrete_torus':True,'spherical_collapse_trajectory_closed':True,'action_derived_virial_closed':True,
 'target_collapse_mass_redshift_table_closed':False,'nonlinear_reaction_closed':False,
 'physical_forward33_closed':False,'physical_rank_closed':False,'physical_mhat2_closed':False,
}

def run(recursive=False):
 s=SovereignSolver();r=s.solve_universal(seeds,world=world,max_waves=2 if recursive else 1,max_calls=32000 if recursive else 15000,stable_waves=1)
 known=list(s.engine.known.values());counts=r.get('mechanism_execution_counts') or {};by={p.payload['problem_id']:collections.Counter() for p in seeds};front=[]
 for n in known:
  if len(n.context)>=2 and n.context[0]=='DELTA_CDM_PASS115':
   pid=n.context[1]
   if pid in by:by[pid][str(n.payload.get('status') or n.kind)]+=1
   st=str(n.payload.get('status') or '')
   if st in {'NEED_DATA','WAITING','OPEN','INVALID','PARTIAL','MISSING_CARRIER'} and n.kind not in {'AUX_OBSERVATION','MECHANISM_OBSERVATION'}:
    front.append({'problem_id':pid,'kind':n.kind,'status':st,'requires':n.payload.get('requires'),'unresolved_requirements':n.payload.get('unresolved_requirements'),'mechanism':n.payload.get('mechanism'),'statement':n.payload.get('statement')})
 out={'schema':'DELTA_CDM_PASS115_AC77_AUDIT_V1','mode':'recursive' if recursive else 'direct','solver_version':r.get('version'),'run_state':r.get('run_state'),'active_mechanism_count':r.get('active_mechanism_count'),'mechanisms_touched':sum(1 for v in counts.values() if v),'execution_calls':r.get('execution_calls'),'known_node_count':r.get('known_node_count'),'open_residual_count':r.get('open_residual_count'),'periodic_cartesian_receipt_count':r.get('periodic_cartesian_receipt_count'),'solution_certified':r.get('solution_certified'),'formal_proof_verified':r.get('formal_proof_verified'),'problem_status_counters':{k:dict(v) for k,v in by.items()},'declared_seed_requirements':{p.payload['problem_id']:p.payload.get('requires',[]) for p in seeds},'frontier_nonpass_count':len(front),'frontier_nonpass':front,'mechanism_execution_counts':counts}
 name='AC77_PASS115_RECURSIVE_AUDIT.json' if recursive else 'AC77_PASS115_DIRECT_AUDIT.json';(ROOT/'receipts/PASS115'/name).write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');(ROOT/'receipts/PASS115/PASS115_SEED_REGISTRY.json').write_text(json.dumps([n.to_dict() for n in seeds],indent=2,ensure_ascii=False)+'\n');return out

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--recursive',action='store_true');a=ap.parse_args();o=run(a.recursive);print(json.dumps({k:o[k] for k in ['mode','solver_version','run_state','active_mechanism_count','mechanisms_touched','execution_calls','known_node_count','open_residual_count','solution_certified','formal_proof_verified','declared_seed_requirements']},indent=2))
