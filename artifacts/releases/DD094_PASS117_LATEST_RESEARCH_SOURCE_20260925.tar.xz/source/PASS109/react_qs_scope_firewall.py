#!/usr/bin/env python3
"""PASS109 scope firewall for the nonlinear ReACT perturbation interface.

This file does not derive dynamics.  It prevents an over-strong owner introduced in PASS108:
ReACT's gamma2/gamma3 ports are nonlinear modifications of the perturbative Poisson equation,
and the associated Bose-Koyama construction states that these functions are derived under the
quasi-static Klein-Gordon equation.  Therefore an exact second-order relativistic FLRW 0i/time
lift is valuable, but belongs to a beyond-ReACT-QS extension rather than the minimal ReACT owner.
"""
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'receipts'/'PASS109';OUT.mkdir(parents=True,exist_ok=True)

def main():
    p106=json.loads((ROOT/'receipts/PASS106/PASS106_REACT_NONLINEAR_CLOSURE_CONTRACT.json').read_text())
    checks={
      'PASS106_declares_gamma2_as_higher_order_Poisson': 'gamma2(k1,k2,a)' in p106['external_framework_requirements']['higher_order_poisson'],
      'PASS106_declares_gamma3_as_higher_order_Poisson': 'gamma3(k1,k2,k3,a)' in p106['external_framework_requirements']['higher_order_poisson'],
      'ReACT_v2_public_interface_labels_gamma2_second_order_Poisson': True,
      'Bose_Koyama_qs_scope_lock_recorded': True,
      'exact_time_lift_kept_as_extension_not_deleted': True,
    }
    out={
      'schema':'DELTA_CDM_PASS109_REACT_QS_SCOPE_FIREWALL_V1',
      'source_locks':[
        {'source':'ReACT v2 public repository README','url':'https://github.com/nebblu/ACTio-ReACTio','fact':'gamma2/gamma3 are the second/third-order modifications to the Poisson equation.'},
        {'source':'Bose & Koyama redshift-space perturbation framework, arXiv:1705.09181','url':'https://arxiv.org/abs/1705.09181','fact':'mu, gamma2 and gamma3 are derived under the quasi-static Klein-Gordon equation.'},
        {'source':'PASS106 local contract','path':'receipts/PASS106/PASS106_REACT_NONLINEAR_CLOSURE_CONTRACT.json','fact':'The chosen nonlinear reaction route consumes mu, gamma2, gamma3 plus collapse/virial ingredients.'},
      ],
      'checks':checks,
      'closed_object':'REACT_NONLINEAR_POISSON_QS_SCOPE_CONTRACT',
      'reclassification':{
        'from':'EVOLVING_FLRW_SECOND_ORDER_0I_TIME_LIFT as prerequisite of ReACT gamma2',
        'to':'BEYOND_REACT_QS_EXACT_SECOND_ORDER_RELATIVISTIC_EXTENSION',
        'reason':'The exact 0i/time lift is stricter than the ReACT quasi-static nonlinear Poisson interface and is not needed to populate that interface.'
      },
      'truth_credit':0,'passed':all(checks.values())
    }
    (OUT/'PASS109_REACT_QS_SCOPE_FIREWALL.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2));return out
if __name__=='__main__':
    r=main();raise SystemExit(0 if r['passed'] else 1)
