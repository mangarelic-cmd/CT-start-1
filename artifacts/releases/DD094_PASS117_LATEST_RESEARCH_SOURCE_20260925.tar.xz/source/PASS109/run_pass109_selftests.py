#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,json,os
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'receipts'/'PASS109';OUT.mkdir(parents=True,exist_ok=True)
scripts=['finite_torus_variational_metric_stencil_contract.py','react_qs_scope_firewall.py','canonical_ricci_react_qs_gamma2_compiler.py']
rows=[]
env=dict(os.environ);env['PYTHONDONTWRITEBYTECODE']='1'
for s in scripts:
 r=subprocess.run([sys.executable,str(ROOT/'source/PASS109'/s)],cwd=ROOT,capture_output=True,text=True,env=env)
 rows.append({'script':s,'returncode':r.returncode,'stdout_tail':r.stdout[-7000:],'stderr_tail':r.stderr[-2500:]})
out={'schema':'DELTA_CDM_PASS109_SELFTEST_SUMMARY_V1','tests':rows,'passed':all(r['returncode']==0 for r in rows),'truth_credit':0}
(OUT/'PASS109_SELFTEST_SUMMARY.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['passed'] else 1)
