#!/usr/bin/env python3
from pathlib import Path
import sys,json,collections,argparse
ROOT=Path(__file__).resolve().parents[2]
ACROOT=ROOT/'runtime'/'AC77'/'SC_SOLVER_AC77_PERIODIC_CARTESIAN_THEOREM_METROLOGY_CORE_20260922'
sys.path.insert(0,str(ACROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver
BASE=[
 'FINITE_DISCRETE_TORUS_E1','Q_LAMBDA_FIREWALL_CERTIFICATE','PASS041_COMPLETED_ACTION_FAMILY',
 'PASS041_ACTION_DERIVATIVES_TO_QUARTIC_ORDER','FINITE_TORUS_RAW_SCALAR_QUADRATIC_CUBIC_VERTEX_COMPILER',
 'SPHERICAL_COLLAPSE_KINEMATIC_REDUCTION','NONLINEAR_METRIC_PROJECTION_FIREWALL',
 'CANONICAL_RICCI_EVOLVING_GAUGE_REDUCED_LINEAR_MODE_SOLVER',
 'CONTINUUM_STATIC_QS_SECOND_ORDER_CANONICAL_RICCI_METRIC_FORCE_PROJECTOR',
 'FINITE_TORUS_TRACELESS_HESSIAN_FIREWALL',
 'FINITE_TORUS_VARIATIONAL_METRIC_STENCIL_CONTRACT','REACT_NONLINEAR_POISSON_QS_SCOPE_CONTRACT',
 'CANONICAL_RICCI_FIXED_BACKGROUND_QS_CURVATURE_LIFT','REACT_GAMMA2_NORMALIZATION_CONTRACT',
 'CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA2_COMPILER'
]
def seed(pid,statement,target,requires=(),supplies=(),**kw):
 p=dict(problem_id=pid,statement=statement,target=target,requires=list(requires),supplies=BASE+list(supplies),ground_binding=True);p.update(kw);return Node('PROBLEM',p,context=('DELTA_CDM_PASS109',pid))
seeds=[
 seed('P109_HESSIAN','Lift the already-declared PASS087 forward/backward variational calculus to the unique minimal symmetric self-adjoint tensor Hessian whose trace is exactly the PASS087 Laplacian.','FINITE_TORUS_VARIATIONAL_METRIC_STENCIL_CONTRACT',(),('FINITE_TORUS_VARIATIONAL_METRIC_STENCIL_CONTRACT',),proof_object={'type':'variational_operator_identity_and_fourier_symbol','receipt':'receipts/PASS109/PASS109_FINITE_TORUS_VARIATIONAL_METRIC_STENCIL_CONTRACT.json'},uniformity_verified=True,boundaries={'q_lambda_firewall':True}),
 seed('P109_SCOPE','Lock the chosen ReACT nonlinear perturbation interface to its quasi-static nonlinear-Poisson scope and reclassify the exact second-order FLRW 0i/time lift as a stricter beyond-ReACT extension rather than a gamma2 prerequisite.','REACT_NONLINEAR_POISSON_QS_SCOPE_CONTRACT',(),('REACT_NONLINEAR_POISSON_QS_SCOPE_CONTRACT',),proof_object={'type':'external_interface_scope_lock','receipt':'receipts/PASS109/PASS109_REACT_QS_SCOPE_FIREWALL.json'},uniformity_verified=True),
 seed('P109_GAMMA2','Compile the action-derived quadratic modified force on the exact variational finite torus, include the fixed-background FLRW curvature jet, and normalize it to the ReACT quasi-static gamma2 convention without free gamma2 parameters.','CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA2_COMPILER',(),('CANONICAL_RICCI_FIXED_BACKGROUND_QS_CURVATURE_LIFT','REACT_GAMMA2_NORMALIZATION_CONTRACT','CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA2_COMPILER'),proof_object={'type':'constructive_finite_torus_gamma2_compiler','receipt':'receipts/PASS109/PASS109_CANONICAL_RICCI_REACT_QS_GAMMA2_COMPILER.json'},uniformity_verified=True,boundaries={'no_free_gamma2':True,'exact_relativistic_second_order_not_claimed':True,'q_lambda_firewall':True}),
 seed('P109_GAMMA3','Extend the same PASS041 action and PASS109 variational torus calculus through cubic metric/scalar projection and normalize the resulting modified force to the ReACT gamma3 convention.','CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA3_COMPILER',('THIRD_ORDER_CANONICAL_RICCI_METRIC_CONSTRAINTS',),(),boundaries={'no_free_gamma3':True,'same_action':True,'q_lambda_firewall':True}),
 seed('P109_NONLINEAR','Construct the nonlinear reaction and spherical-collapse/virial force only after the action-derived ReACT-QS gamma3 compiler closes.','CT_NONLINEAR_HIGHER_ORDER_POISSON_AND_COLLAPSE_COMPILER',('CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA3_COMPILER',),(),boundaries={'no_phenomenological_delta_nl':True}),
]
world={'project':'DELTA_CDM_PASS109','available_evidence_tokens':BASE,'external_scientific_truth_certified':False,'finite_discrete_torus':True,
'variational_metric_stencil_closed':True,'react_qs_scope_closed':True,'fixed_background_qs_curvature_lift_closed':True,
'react_qs_gamma2_compiler_closed':True,'exact_second_order_relativistic_flrw_extension_closed':False,
'react_qs_gamma3_compiler_closed':False,'physical_forward33_closed':False,'physical_rank_closed':False,'physical_mhat2_closed':False}
def run(recursive=False):
 s=SovereignSolver(); r=s.solve_universal(seeds,world=world,max_waves=2 if recursive else 1,max_calls=32000 if recursive else 15000,stable_waves=1)
 known=list(s.engine.known.values());counts=r.get('mechanism_execution_counts') or {};by={p.payload['problem_id']:collections.Counter() for p in seeds};front=[]
 for n in known:
  if len(n.context)>=2 and n.context[0]=='DELTA_CDM_PASS109':
   pid=n.context[1]
   if pid in by:by[pid][str(n.payload.get('status') or n.kind)]+=1
   st=str(n.payload.get('status') or '')
   if st in {'NEED_DATA','WAITING','OPEN','INVALID','PARTIAL','MISSING_CARRIER'} and n.kind not in {'AUX_OBSERVATION','MECHANISM_OBSERVATION'}:
    front.append({'problem_id':pid,'kind':n.kind,'status':st,'requires':n.payload.get('requires'),'unresolved_requirements':n.payload.get('unresolved_requirements'),'mechanism':n.payload.get('mechanism'),'statement':n.payload.get('statement')})
 out={'schema':'DELTA_CDM_PASS109_AC77_AUDIT_V1','mode':'recursive' if recursive else 'direct','solver_version':r.get('version'),'run_state':r.get('run_state'),'active_mechanism_count':r.get('active_mechanism_count'),'mechanisms_touched':sum(1 for v in counts.values() if v),'execution_calls':r.get('execution_calls'),'known_node_count':r.get('known_node_count'),'open_residual_count':r.get('open_residual_count'),'periodic_cartesian_receipt_count':r.get('periodic_cartesian_receipt_count'),'solution_certified':r.get('solution_certified'),'formal_proof_verified':r.get('formal_proof_verified'),'problem_status_counters':{k:dict(v) for k,v in by.items()},'declared_seed_requirements':{p.payload['problem_id']:p.payload.get('requires',[]) for p in seeds},'frontier_nonpass_count':len(front),'frontier_nonpass':front,'mechanism_execution_counts':counts}
 name='AC77_PASS109_RECURSIVE_AUDIT.json' if recursive else 'AC77_PASS109_DIRECT_AUDIT.json';(ROOT/'receipts/PASS109'/name).write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');return out
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--recursive',action='store_true');a=ap.parse_args();o=run(a.recursive)
 (ROOT/'receipts/PASS109/PASS109_SEED_REGISTRY.json').write_text(json.dumps([n.to_dict() for n in seeds],indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({k:o[k] for k in ['mode','solver_version','run_state','active_mechanism_count','mechanisms_touched','execution_calls','known_node_count','open_residual_count','periodic_cartesian_receipt_count','solution_certified','formal_proof_verified','declared_seed_requirements']},indent=2))
