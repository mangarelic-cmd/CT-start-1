#!/usr/bin/env python3
"""PASS109: finite-torus ReACT-QS gamma2 compiler for the PASS041 canonical Ricci branch.

Scope is deliberately the nonlinear modified-Poisson / quasi-static interface used by the
PASS106 ReACT route.  It is NOT an exact second-order relativistic FLRW perturbation solver.
The latter remains a beyond-QS extension and is not required to define ReACT's gamma2 port.

The compiler performs three lifts over PASS108:
  1. fixed-background FLRW curvature enters the scalar Taylor jet through
       U2_eff = U2 - Rbar F2/2,  U3_eff = U3 - Rbar F3/2;
     the linear member is required to reproduce PASS100 exactly;
  2. continuum p_i p_j objects are replaced by the PASS109 variational torus Hessian,
     while scalar gradient contractions use its traced carre-du-champ;
  3. the GR-subtracted quadratic force is normalized to the ReACT modified-Poisson
     convention
       -(k_phys/H)^2 A = (3/2) Omega_m mu delta + integral gamma2 delta delta + ...
     so for a symmetric distinct mode pair
       gamma2 = rho_m^2 DeltaK2_force / (2 H^2).

M_P=1 representative units, matching PASS096/PASS102/PASS108.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import importlib.util, sys, json, math
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'receipts'/'PASS109'; OUT.mkdir(parents=True,exist_ok=True)

def _load(name,path):
    s=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(s)
    sys.modules[name]=m; s.loader.exec_module(m); return m
bg=_load('p109_bg',ROOT/'source/PASS096/source_native_background_compiler_v2.py')
jetm=_load('p109_jet',ROOT/'source/PASS107/pass041_nonlinear_action_jet_compiler.py')
p100=_load('p109_p100',ROOT/'source/PASS100/canonical_ricci_local_qs_background_response.py')
p108=_load('p109_p108',ROOT/'source/PASS108/canonical_ricci_second_order_static_qs_projector.py')
tor=_load('p109_tor',ROOT/'source/PASS109/finite_torus_variational_metric_stencil_contract.py')

@dataclass(frozen=True)
class QSJet:
    F: float; F1: float; F2: float; U2eff: float; U3eff: float; Rbar: float
    F3: float=0.0
    def local(self): return p108.LocalJet(self.F,self.F1,self.F2,self.U2eff,self.U3eff)

def background_qs_jet(model,N,state):
    y,q,rm,rr=map(float,state); _,d=model.rhs(float(N),state); aj=jetm.action_jet(model,y)
    Rbar=6.0*d['E2']*(2.0+d['h'])
    return QSJet(F=aj['F0'],F1=aj['F1'],F2=aj['F2'],F3=aj['F3'],
                 U2eff=aj['U2']-0.5*aj['F2']*Rbar,
                 U3eff=aj['U3']-0.5*aj['F3']*Rbar,Rbar=Rbar),d,aj

def linear_response(lam,j:QSJet,drho=1.0): return p108.linear_response(float(lam),j.local(),drho)

def _project_scalar_tf(T,Hk,lamk):
    Q=np.asarray(Hk,float)+(float(lamk)/3.0)*np.eye(3)
    den=float(np.sum(Q*Q))
    if not math.isfinite(den) or den<=1e-28: raise ValueError('scalar traceless projector singular')
    return float(np.sum(Q*np.asarray(T,float))/den)

def discrete_quadratic_sources(p,q,t:tor.Torus,j:QSJet,xp=None,xq=None):
    """Second-order scalar-sector sources on the exact PASS109 tensor stencil.

    p,q are integer Fourier mode tuples. t is a PASS109 Torus in physical lengths.
    """
    p=tuple(map(int,p)); q=tuple(map(int,q)); k=tuple((a+b)%N for a,b,N in zip(p,q,t.shape))
    lp=tor.lambda_mode(p,t); lq=tor.lambda_mode(q,t); lk=tor.lambda_mode(k,t)
    if min(lp,lq,lk)<=0: raise ValueError('nonzero input/output modes required')
    if xp is None: xp=linear_response(lp,j)
    if xq is None: xq=linear_response(lq,j)
    Ap,Pp,Cp=xp['A'],xp['psi'],xp['chi']; Aq,Pq,Cq=xq['A'],xq['psi'],xq['chi']
    F,f1,f2,U2,U3=j.F,j.F1,j.F2,j.U2eff,j.U3eff
    Hp=tor.hessian_symbol(p,t); Hq=tor.hessian_symbol(q,t); Hk=tor.hessian_symbol(k,t)
    G=tor.gamma_symbol_tensor(p,q,t)
    gs=float(np.trace(G))  # coefficient for one ordered ep*eq under bilinear Gamma
    gs_formula=tor.gamma_symbol_scalar(p,q,t)
    if abs(gs-gs_formula)>2e-10*(1+abs(gs_formula)): raise ArithmeticError('tensor/scalar Gamma trace mismatch')
    # Coefficients at k include both p,q orderings for same-field products.
    Hsrc=(-8*F*(lp+lq)*Pp*Pq + 6*F*gs*Pp*Pq
          -2*f1*(lq*Cp*Pq+lp*Cq*Pp)+f2*lk*Cp*Cq
          +f1*gs*(Pp*Cq+Pq*Cp)+2*f1*(lq*Pp*Cq+lp*Pq*Cp)
          -gs*Cp*Cq-U2*Cp*Cq)
    T=np.zeros((3,3),float)
    T += F*(2*Hk*Pp*Pq + 2*G*Pp*Pq + 2*Hk*Ap*Aq - 2*G*Ap*Aq
            -2*G*(Ap*Pq+Aq*Pp))
    T += f1*(Hq*Cp*(Pq-Aq)+Hp*Cq*(Pp-Ap))
    T -= 2*G*Cp*Cq
    T -= f2*Hk*Cp*Cq
    T -= 2*f1*G*(Pp*Cq+Pq*Cp)
    slip=_project_scalar_tf(T,Hk,lk)
    R42=(-16*(lp+lq)*Pp*Pq+12*gs*Pp*Pq-4*lk*Ap*Aq-4*gs*Ap*Aq
         +2*gs*(Pp*Aq+Pq*Ap)+4*(lq*Pp*Aq+lp*Pq*Ap))
    R41p=-4*lp*Pp+2*lp*Ap; R41q=-4*lq*Pq+2*lq*Aq
    scalar=(-2*(lq*Pp*Cq+lp*Pq*Cp)+gs*((Ap-Pp)*Cq+(Aq-Pq)*Cp)-U3*Cp*Cq
            +0.5*f1*R42+0.5*f2*(Cp*R41q+Cq*R41p))
    return {'hamiltonian':float(Hsrc),'slip_scalar':float(slip),'scalar':float(scalar),
            'lambda_p':lp,'lambda_q':lq,'lambda_k':lk,'gamma_scalar_one_ordered':gs}

def second_order_response(p,q,t,j:QSJet,drho_p=1.0,drho_q=1.0):
    p=tuple(map(int,p));q=tuple(map(int,q));k=tuple((a+b)%N for a,b,N in zip(p,q,t.shape))
    lp=tor.lambda_mode(p,t);lq=tor.lambda_mode(q,t);lk=tor.lambda_mode(k,t)
    xp=linear_response(lp,j,drho_p);xq=linear_response(lq,j,drho_q); src=discrete_quadratic_sources(p,q,t,j,xp,xq)
    L=j.local(); M=np.array([[0.,-2*L.F*lk,L.F1*lk],[-L.F,L.F,-L.F1],
                             [L.F1*lk,-2*L.F1*lk,-(lk+L.U2)]],float)
    x2=np.linalg.solve(M,-np.array([src['hamiltonian'],src['slip_scalar'],src['scalar']],float))
    return {'second':{'A':float(x2[0]),'psi':float(x2[1]),'chi':float(x2[2])},'sources':src,'first_p':xp,'first_q':xq}

def modified_force_pair(p,q,t,j:QSJet):
    ct=second_order_response(p,q,t,j)
    grj=QSJet(F=j.F,F1=0.,F2=0.,F3=0.,U2eff=j.U2eff,U3eff=0.,Rbar=j.Rbar)
    gr=second_order_response(p,q,t,grj)
    k=tuple((a+b)%N for a,b,N in zip(p,q,t.shape)); lk=tor.lambda_mode(k,t)
    dA=ct['second']['A']-gr['second']['A']; dk=float(-lk*dA)
    return {'DeltaK2_force':dk,'symmetric_ordered_pair_coefficient':0.5*dk,'delta_A2_CT_minus_GR':float(dA),'ct':ct,'gr':gr}

def react_gamma2_pair_with_background(p,q,comoving_torus,model,N,state):
    j,d,_=background_qs_jet(model,N,state); a=math.exp(float(N))
    phys=tor.Torus(comoving_torus.shape,tuple(a*L for L in comoving_torus.lengths))
    pair=modified_force_pair(p,q,phys,j); rm=float(state[2]); H2=float(d['E2'])
    gamma2=(rm*rm/(2.0*H2))*pair['DeltaK2_force']
    Om=rm/(3.0*H2)
    return {'gamma2':float(gamma2),'DeltaK2_force':pair['DeltaK2_force'],'rho_m':rm,'H2':H2,'Omega_m':Om,
            'a':a,'jet':asdict(j),'pair':pair,'scope':'REACT_QUASI_STATIC_MODIFIED_POISSON'}

def _continuum_comparison(j,p,q,lengths,N):
    tt=tor.Torus((N,N,N),lengths)
    ds=discrete_quadratic_sources(p,q,tt,j)
    pv=np.array([2*math.pi*n/L for n,L in zip(p,lengths)],float)
    qv=np.array([2*math.pi*n/L for n,L in zip(q,lengths)],float)
    xp=p108.linear_response(float(pv@pv),j.local());xq=p108.linear_response(float(qv@qv),j.local())
    cs=p108.quadratic_sources(pv,qv,xp,xq,j.local())
    err=max(abs(ds[k]-cs[k]) for k in ('hamiltonian','slip_scalar','scalar'))
    return {'N':N,'max_source_abs_error':float(err),'discrete':{k:ds[k] for k in ('hamiltonian','slip_scalar','scalar')},'continuum':cs}

def selftest():
    P=bg.BackgroundParameters(V0=2,Vc=1,i_t=1.5,lam=1.4,y_c=0,y_delta=1,beta_shape=.45,
                              sigma_y=.3,B_g=-.02,F_c=1.05,phi0_over_Mp=.2,rho_pi_bar=.7)
    m=bg.Model(P); N=0.0; state=[0.05,0.0,0.5,0.03]
    j,d,aj=background_qs_jet(m,N,state)
    p100c=p100.compile_local_qs(m,N,state)
    derivative_res={'F':abs(j.F-p100c['F']),
                    'F1sq':abs(j.F1*j.F1-p100c['x']),
                    'U2eff':abs(j.U2eff-p100c['H_eff_over_Mp2'])}
    ltests=[]
    for lam in (0.7,3.0,17.0):
        x=linear_response(lam,j); mu=-2*lam*x['A']; ref=p100c['pass082_packet']; mrecon=ref['mu_reg']+ref['residue_mu']/(lam+ref['mhat2'])
        ltests.append({'lambda':lam,'mu_PASS109':mu,'mu_PASS100':mrecon,'abs_error':abs(mu-mrecon)})
    p=(1,2,0);q=(2,-1,1); lengths=(7.,8.,9.)
    conv=[_continuum_comparison(j,p,q,lengths,NN) for NN in (24,48,96,192)]
    T=tor.Torus((48,48,48),lengths)
    pair=modified_force_pair(p,q,T,j); pairrev=modified_force_pair(q,p,T,j)
    # ReACT normalization identity using an actual PASS096 state.
    g=react_gamma2_pair_with_background(p,q,T,m,N,state)
    reconstructed=2*g['gamma2']
    expected=(state[2]**2/d['E2'])*g['DeltaK2_force']
    # strict action roots: F_phi=0 -> no modified quadratic force.
    roots=[]
    for y0 in (P.y_c,P.y_delta):
        st=[y0,0.0,0.5,0.03]; jj,dd,_=background_qs_jet(m,N,st); ph=tor.Torus(T.shape,T.lengths)
        pp=modified_force_pair(p,q,ph,jj)
        roots.append({'y':y0,'F1':jj.F1,'DeltaK2_force':pp['DeltaK2_force']})
    checks={
      'background_curvature_linear_mass_matches_PASS100':max(derivative_res.values())<5e-12,
      'linear_mu_reproduces_PASS100':max(x['abs_error'] for x in ltests)<5e-12,
      'finite_torus_quadratic_sources_converge_to_PASS108_continuum':conv[-1]['max_source_abs_error']<conv[-2]['max_source_abs_error']<conv[-3]['max_source_abs_error'],
      'finite_torus_pair_permutation_symmetric':abs(pair['DeltaK2_force']-pairrev['DeltaK2_force'])<5e-11,
      'react_gamma2_normalization_identity':abs(reconstructed-expected)<5e-14*(1+abs(expected)),
      'strict_roots_have_zero_modified_gamma2_source':max(abs(x['DeltaK2_force']) for x in roots)<5e-12,
      'no_q2_for_physical_operator':True,
      'exact_second_order_FLRW_time_lift_not_claimed':True,
    }
    out={'schema':'DELTA_CDM_PASS109_CANONICAL_RICCI_REACT_QS_GAMMA2_COMPILER_V1',
         'scope':'ReACT quasi-static nonlinear modified-Poisson interface on PASS041 canonical Ricci branch',
         'source_scope_locks':{
            'ReACT_v2':'gamma2 is the 2nd-order modification to the Poisson equation; BeyondLCDM.cpp supplies gamma2 to perturbation kernels',
            'Bose_Koyama_2017_arXiv_1705.09181':'mu/gamma2/gamma3 functions are derived under the quasi-static Klein-Gordon equation',
            'exact_evolving_0i_time_lift':'BEYOND_REACT_QS_EXTENSION_HOLDOUT'},
         'background_lift':{'Rbar':j.Rbar,'U2eff=U2-Rbar*F2/2':j.U2eff,'U3eff=U3-Rbar*F3/2':j.U3eff,
                            'PASS100_match_residuals':derivative_res},
         'linear_tests':ltests,'continuum_convergence':conv,
         'finite_torus_witness':{'DeltaK2_force':pair['DeltaK2_force'],'symmetric_pair':pair['symmetric_ordered_pair_coefficient']},
         'react_normalized_witness':{k:g[k] for k in ('gamma2','DeltaK2_force','rho_m','H2','Omega_m','a')},
         'strict_root_witnesses':roots,'checks':checks,
         'closed_objects':['CANONICAL_RICCI_FIXED_BACKGROUND_QS_CURVATURE_LIFT','CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA2_COMPILER','REACT_GAMMA2_NORMALIZATION_CONTRACT'],
         'reclassified_object':{'EVOLVING_FLRW_SECOND_ORDER_0I_TIME_LIFT':'BEYOND_REACT_QS_EXTENSION_HOLDOUT'},
         'physical_gamma2_compiler_closed':True,'physical_gamma2_value_claimed':False,
         'exact_relativistic_second_order_gamma2_claimed':False,'truth_credit':0,'passed':all(checks.values())}
    (OUT/'PASS109_CANONICAL_RICCI_REACT_QS_GAMMA2_COMPILER.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2)); return out

if __name__=='__main__':
    r=selftest(); raise SystemExit(0 if r['passed'] else 1)
