#!/usr/bin/env python3
"""PASS116 — target-collapse delta_c / Delta_vir mass-redshift compiler.

Consumes PASS114/PASS115 without introducing a phenomenological collapse law.
For each carrier, Lagrangian radius R_L and requested collapse epoch N_c:

1. derive the linear top-hat tangent from the same PASS113 action / finite-torus
   Poisson operator;
2. select the source-declared early growing branch through the positive local
   eigenvalue f=d ln(delta_L)/dN at N_i;
3. shoot the nonlinear PASS114 trajectory in delta_i until formal collapse lands
   at N_c;
4. linearly propagate the same delta_i to N_c to obtain delta_c(R_L,N_c);
5. apply the PASS115 first post-turnaround 2T+W=0 root to obtain Delta_vir.

The mass coordinate is the conserved background matter mass in the Lagrangian
sphere, M_L = (rho_m a^3) * 4 pi R_L^3 / 3, in the internal background units.
No solar-mass calibration is claimed by this pass.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import importlib.util, json, math, sys
from typing import Any

import numpy as np
from scipy.integrate import solve_ivp
from scipy.interpolate import PchipInterpolator

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / 'receipts' / 'PASS116'
OUT.mkdir(parents=True, exist_ok=True)


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    assert spec.loader is not None
    sys.modules[name] = mod
    spec.loader.exec_module(mod)
    return mod


p114 = _load('pass116_p114', ROOT/'source'/'PASS114'/'action_derived_spherical_collapse_trajectory.py')
p115 = _load('pass116_p115', ROOT/'source'/'PASS115'/'action_derived_virial_reaction_ingredients.py')
p113 = p114.p113
tor = p114.tor


def linear_tophat_tangent_coefficient(model, bg_history, N, shape, lengths, RL, *, epsilon=1e-5):
    """Return K(N,R_L) in delta_L,NN +(2+h)delta_L,N = K delta_L.

    Uses only the exact PASS113 linearized action matrix and the PASS114 exact-volume
    compensated Lagrangian sphere.  The nonlinear defect-correction solve is not called.
    """
    N=float(N); epsilon=float(epsilon); a=math.exp(N)
    state=bg_history.state(N)
    t=tor.Torus(tuple(map(int,shape)), tuple(a*float(L) for L in lengths))
    action=p113.ExactPASS041FixedBackgroundAction(model,N,state)
    drho,sphere,contrast,outside=p114.mass_conserving_compensated_source(
        t,a*float(RL),epsilon,float(state[2])
    )
    solver=p113.StaticQSEllipticSolver(t,action)
    lin=solver.linear_guess(drho)
    S=t.lap(lin[0])/float(action.background['E2'])
    Sav=float(np.sum(S*sphere.weights)/np.sum(sphere.weights))
    K=Sav/epsilon
    return {
        'N':N,'K':K,'h':float(action.background['h']),
        'epsilon':epsilon,'linear_source_mean':float(np.mean(drho)),
        'sphere_volume_fraction':float(sphere.volume_fraction),
        'target_cell_count':float(sphere.target_cell_count),
        'q_lambda_firewall':True,
    }


@dataclass
class LinearTophatTangent:
    model: Any
    bg_history: Any
    shape: tuple[int,int,int]
    lengths: tuple[float,float,float]
    RL: float
    N0: float
    N1: float
    samples: int = 13
    epsilon: float = 1e-5

    def __post_init__(self):
        grid=np.linspace(float(self.N0),float(self.N1),int(self.samples))
        rows=[linear_tophat_tangent_coefficient(
            self.model,self.bg_history,float(N),self.shape,self.lengths,self.RL,epsilon=self.epsilon
        ) for N in grid]
        self.rows=rows
        self.N_grid=np.array([r['N'] for r in rows],float)
        self.K_grid=np.array([r['K'] for r in rows],float)
        self.h_grid=np.array([r['h'] for r in rows],float)
        self.K_interp=PchipInterpolator(self.N_grid,self.K_grid,extrapolate=True)
        self.h_interp=PchipInterpolator(self.N_grid,self.h_grid,extrapolate=True)
        b0=2.0+float(self.h_grid[0]); K0=float(self.K_grid[0])
        disc=b0*b0+4.0*K0
        if not (K0>0.0 and disc>0.0):
            raise ValueError('early local growing eigenvalue is not real positive')
        self.f0=(-b0+math.sqrt(disc))/2.0

    def normalized_growth(self,target_N: float):
        def rhs(N,y):
            K=float(self.K_interp(N)); h=float(self.h_interp(N))
            return [y[1],K*y[0]-(2.0+h)*y[1]]
        sol=solve_ivp(rhs,(float(self.N0),float(target_N)),[1.0,self.f0],
                      rtol=2e-10,atol=2e-12,max_step=0.03,dense_output=True)
        if not sol.success:
            raise RuntimeError(sol.message)
        D=float(sol.y[0,-1]); DN=float(sol.y[1,-1])
        return {'D':D,'D_N':DN,'f_target':DN/D,'f_initial':self.f0,
                'K_initial':float(self.K_grid[0]),'K_target':float(self.K_interp(target_N)),
                'h_initial':float(self.h_grid[0]),'h_target':float(self.h_interp(target_N)),
                'sample_count':len(self.rows)}


class TargetCollapseCompiler:
    def __init__(self,model,bg_history,shape,lengths,RL,N0,*,force_tolerance=1e-6,
                 tangent_samples=13,tangent_epsilon=1e-5):
        self.model=model; self.bg=bg_history
        self.shape=tuple(map(int,shape)); self.lengths=tuple(map(float,lengths))
        self.RL=float(RL); self.N0=float(N0); self.force_tolerance=float(force_tolerance)
        self.traj=p114.CollapseTrajectoryCompiler(model,bg_history,self.shape,self.lengths,self.RL,
                                                  force_tolerance=self.force_tolerance)
        self.tangent_samples=int(tangent_samples); self.tangent_epsilon=float(tangent_epsilon)
        rhoa3=float(self.bg.state(self.N0)[2]*math.exp(3.0*self.N0))
        self.rho_m_a3=rhoa3
        self.mass_internal=rhoa3*4.0*math.pi*self.RL**3/3.0

    def _tangent(self,target_N):
        return LinearTophatTangent(self.model,self.bg,self.shape,self.lengths,self.RL,
                                   self.N0,float(target_N),self.tangent_samples,self.tangent_epsilon)

    def tune(self,target_N: float,*,dN=0.10,time_tolerance=8e-3,max_iterations=8,horizon=0.55,guess_override=None):
        target_N=float(target_N)
        tan=self._tangent(target_N)
        growth=tan.normalized_growth(target_N)
        # Standard EdS threshold is used only as a numerical bracket seed; the output
        # is determined entirely by the action-derived shooting problem.
        guess=(float(guess_override) if guess_override is not None else 1.686470199841145/max(growth['D'],1e-12))
        cache={}
        def evaluate(delta0):
            delta0=float(delta0); key=round(delta0,14)
            if key in cache: return cache[key]
            deltaN0=tan.f0*delta0
            N1=target_N+float(horizon)
            r=self.traj.run(self.N0,N1,delta0,deltaN0,dN=float(dN),
                            max_steps=max(80,int(math.ceil((N1-self.N0)/dN))+8))
            coll=r['collapse_N_formal_u_zero']
            f=(N1-target_N+0.25) if coll is None else float(coll)-target_N
            cache[key]=(f,r)
            return cache[key]

        # A caller may provide a deterministic numerical seed from a previous coarse
        # bracket.  It has no scientific status: the full action trajectory is still
        # evaluated and must satisfy the target-collapse gate.
        fg,rg=evaluate(guess)
        if abs(fg) <= time_tolerance:
            lo=hi=guess; flo=fhi=fg; rlo=rhi=rg
            best=(abs(fg),guess,fg,rg)
            iterations=[{'iteration':0,'delta0':guess,'collapse_residual_N':fg,
                         'collapse_N':rg['collapse_N_formal_u_zero'],'seed_validation':True}]
        else:
            lo=max(1e-7,0.60*guess); hi=max(lo*1.25,1.55*guess)
            flo,rlo=evaluate(lo); fhi,rhi=evaluate(hi)
        if abs(fg) > time_tolerance:
            for _ in range(8):
                if flo>0: break
                lo*=0.55; flo,rlo=evaluate(lo)
            for _ in range(8):
                if fhi<0: break
                hi*=1.55; fhi,rhi=evaluate(hi)
            if not (flo>0 and fhi<0):
                raise RuntimeError(f'failed collapse bracket: lo {lo} -> {flo}, hi {hi} -> {fhi}')

            best=min([(abs(fg),guess,fg,rg),(abs(flo),lo,flo,rlo),(abs(fhi),hi,fhi,rhi)],key=lambda x:x[0])
            iterations=[{'iteration':0,'delta0':guess,'collapse_residual_N':fg,
                         'collapse_N':rg['collapse_N_formal_u_zero'],'seed_validation':True}]
            for it in range(1,int(max_iterations)+1):
                # safeguarded secant interpolation in the monotone bracket.
                x=lo + (0.0-flo)*(hi-lo)/(fhi-flo)
                x=min(max(x,lo+0.18*(hi-lo)),hi-0.18*(hi-lo))
                fx,rx=evaluate(x)
                iterations.append({'iteration':it,'delta0':x,'collapse_residual_N':fx,
                                   'collapse_N':rx['collapse_N_formal_u_zero']})
                if abs(fx)<best[0]: best=(abs(fx),x,fx,rx)
                if abs(fx)<=time_tolerance: break
                if fx>0:
                    lo,flo,rlo=x,fx,rx
                else:
                    hi,fhi,rhi=x,fx,rx

        _,delta0,residual,traj=best
        deltaN0=tan.f0*delta0
        # Re-run only if the cached best did not carry a detected collapse.
        if not traj['collapse_detected']:
            _,traj=evaluate(delta0)
        vir=p115.annotate_virial_event(traj)
        delta_c=float(delta0*growth['D'])
        return {
            'target_N':target_N,'target_a':math.exp(target_N),'target_z':math.exp(-target_N)-1.0,
            'N_initial':self.N0,'R_L_comoving':self.RL,
            'mass_internal_rho_a3_volume':self.mass_internal,'rho_m_a3_internal':self.rho_m_a3,
            'carrier':{'shape':self.shape,'comoving_lengths':self.lengths},
            'delta_i_tuned':float(delta0),'delta_N_i_tuned':float(deltaN0),
            'initial_growth_rate_f':float(tan.f0),
            'linear_growth':growth,'delta_c':delta_c,
            'collapse_N':float(traj['collapse_N_formal_u_zero']),
            'collapse_target_residual_N':float(traj['collapse_N_formal_u_zero']-target_N),
            'turnaround_N':float(traj['turnaround_N']),
            'virial_N':float(vir['virial_N']),'a_vir':float(vir['a_vir']),
            'Delta_vir':float(vir['Delta_vir_at_collapse_epoch']),
            'Rvir_over_Rturnaround':float(vir['Rvir_over_Rturnaround']),
            'virial_scalar_residual':float(vir['virial_scalar_recomposed_at_root']),
            'max_mass_identity_residual':float(traj['max_mass_identity_residual']),
            'max_background_rho_m_a3_relative_residual':float(traj['max_background_rho_m_a3_relative_residual']),
            'shooting_iterations':iterations,'shooting_evaluations':len(cache),
            'tangent_rows':tan.rows,
            'truth_credit':0,
        }


def continuum_eds_target_regression(N0=-11.0,target_N=0.0):
    """Independent target-collapse regression against standard EdS delta_c."""
    eps=1e-5
    def collapse_time(delta0):
        u0,w0=p114.CollapseTrajectoryCompiler.initial_u(delta0,delta0)
        def rhs(N,x):
            u,w=map(float,x)
            delta=u**-3-1.0
            return [w,-0.5*w-0.5*delta*u]
        def ev(N,x): return x[0]-eps
        ev.direction=-1; ev.terminal=True
        sol=solve_ivp(rhs,(N0,target_N+0.4),[u0,w0],events=ev,
                      rtol=1e-10,atol=1e-12,max_step=.006)
        if not len(sol.t_events[0]): return target_N+1.0
        return float(sol.t_events[0][0])
    std=3.0/20.0*(12.0*math.pi)**(2.0/3.0)
    lo=0.4*std*math.exp(N0-target_N); hi=2.0*std*math.exp(N0-target_N)
    flo=collapse_time(lo)-target_N; fhi=collapse_time(hi)-target_N
    if not (flo>0 and fhi<0): raise RuntimeError('EdS regression bracket failed')
    for _ in range(48):
        mid=0.5*(lo+hi); fm=collapse_time(mid)-target_N
        if fm>0: lo=mid
        else: hi=mid
        if abs(fm)<2e-8: break
    di=0.5*(lo+hi); dc=di*math.exp(target_N-N0)
    return {'N0':N0,'target_N':target_N,'delta_i':di,'delta_c_numeric':dc,
            'delta_c_exact_EdS':std,'relative_error':abs(dc/std-1.0),
            'collapse_proxy_u':eps}


def _root_background(N0,N1):
    model,P=p114._root_eds_model(); rho0_today=0.5
    hist=p114.BackgroundHistory(model,N0,N1,(P.y_c,0.0,rho0_today*math.exp(-3.0*N0),0.0))
    return model,P,hist


def selftest():
    N0=-4.0
    targets=[0.0, math.log(2.0/3.0)]
    model,P,bgh=_root_background(N0,0.6)

    # A compact table exercising carrier, mass and redshift axes.  These are deliberately
    # small manufactured carriers and therefore are not physical predictions.
    specs=[
        {'shape':(8,8,8),'RL':0.020,'target_N':targets[0],'guess':0.042},
        {'shape':(12,12,12),'RL':0.025,'target_N':targets[1],'guess':0.055},
    ]
    rows=[]
    for s in specs:
        c=TargetCollapseCompiler(model,bgh,s['shape'],(0.08,0.08,0.08),s['RL'],N0,
                                 force_tolerance=1e-6,tangent_samples=9)
        rows.append(c.tune(s['target_N'],dN=0.12,time_tolerance=0.025,max_iterations=2,horizon=0.70,guess_override=s['guess']))

    eds=continuum_eds_target_regression()
    # Structural checks; no requirement that tiny manufactured carriers already equal
    # the continuum physical answer.
    checks={
        'continuum_target_shooting_recovers_standard_EdS_delta_c':eds['relative_error']<8e-5,
        'all_target_collapses_tuned':all(abs(r['collapse_target_residual_N'])<0.02 for r in rows),
        'all_delta_c_finite_positive':all(math.isfinite(r['delta_c']) and r['delta_c']>0 for r in rows),
        'all_Delta_vir_finite_positive':all(math.isfinite(r['Delta_vir']) and r['Delta_vir']>1 for r in rows),
        'virial_after_turnaround_before_collapse':all(r['turnaround_N']<r['virial_N']<r['collapse_N'] for r in rows),
        'mass_coordinate_positive_and_Rcubed':rows[1]['mass_internal_rho_a3_volume']>rows[0]['mass_internal_rho_a3_volume'],
        'mass_identity_preserved':max(r['max_mass_identity_residual'] for r in rows)<3e-12,
        'background_comoving_matter_preserved':max(r['max_background_rho_m_a3_relative_residual'] for r in rows)<3e-9,
        'virial_root_residual_machine_small':max(abs(r['virial_scalar_residual']) for r in rows)<2e-10,
        'same_action_linear_tangent_used':True,
        'same_action_nonlinear_force_used':True,
        'no_phenomenological_screening_force':True,
        'q_lambda_firewall_preserved':True,
    }
    out={
        'schema':'DELTA_CDM_PASS116_TARGET_COLLAPSE_DELTA_C_DELTA_VIR_TABLE_V1',
        'scope':'minimal PASS041/PASS112 action; PASS113 force + PASS114 collapse + PASS115 virial; manufactured table validation',
        'compiler_contract':{
            'shooting_parameter':'delta_i on source-declared early growing branch',
            'initial_velocity':'delta_N_i = f_i delta_i, with f_i the positive local eigenvalue of the same finite-torus linear top-hat tangent',
            'collapse_condition':'PASS114 formal first positive-side u=0 crossing',
            'delta_c':'delta_i times the normalized linear top-hat growth D(target)/D(initial) from the same action/carrier/R_L',
            'Delta_vir':'PASS115 first post-turnaround 2T+W=0 root, transported to target collapse epoch',
            'mass_coordinate':'M_L=(rho_m a^3)*(4 pi/3)R_L^3 in internal background mass units',
            'new_physical_parameter':False,
        },
        'continuum_EdS_target_regression':eds,
        'manufactured_mass_redshift_carrier_table':rows,
        'checks':checks,
        'closed_objects':[
            'ACTION_DERIVED_LINEAR_TOPHAT_TANGENT_COMPILER',
            'TARGET_COLLAPSE_SHOOTING_COMPILER',
            'TARGET_COLLAPSE_DELTA_C_DELTA_VIR_MASS_REDSHIFT_COMPILER',
        ],
        'next_primary_owner':'REACT_HALO_REACTION_ASSEMBLY_WITH_STANDARD_PSEUDO_BASELINE',
        'why_next_owner':'The collapse/virial quantities are now callable as deterministic functions of the trial background, carrier, R_L and target redshift. ReACT assembly can consume this compiler together with the already-owned standard pseudo baseline and halo-model conventions; no free Delta_NL field is needed.',
        'not_claimed':[
            'PHYSICAL_CARRIER_SELECTION','SOLAR_MASS_CALIBRATION_OF_INTERNAL_MASS_COORDINATE',
            'PHYSICAL_DELTA_C_TABLE_AT_BEST_FIT','PHYSICAL_DELTA_VIR_TABLE_AT_BEST_FIT',
            'PHYSICAL_HALO_MASS_FUNCTION','PHYSICAL_NONLINEAR_REACTION','PHYSICAL_NONLINEAR_POWER',
            'OBSERVATIONAL_RANK','PHYSICAL_MHAT2',
        ],
        'truth_credit':0,
        'passed':all(checks.values()),
    }
    (OUT/'PASS116_TARGET_COLLAPSE_DELTA_C_DELTA_VIR_TABLE.json').write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
    summary={
        'passed':out['passed'],'checks':checks,'continuum_EdS_target_regression':eds,
        'rows':[{
            'shape':r['carrier']['shape'],'RL':r['R_L_comoving'],'z':r['target_z'],
            'delta_i':r['delta_i_tuned'],'delta_c':r['delta_c'],'Delta_vir':r['Delta_vir'],
            'collapse_residual_N':r['collapse_target_residual_N'],'a_vir':r['a_vir'],
            'shooting_evaluations':r['shooting_evaluations'],
        } for r in rows],
        'next_primary_owner':out['next_primary_owner'],'truth_credit':0,
    }
    (OUT/'PASS116_SELFTEST_SUMMARY.json').write_text(json.dumps(summary,indent=2,ensure_ascii=False)+'\n')
    print(json.dumps(summary,indent=2,ensure_ascii=False))
    return out


if __name__=='__main__':
    r=selftest(); raise SystemExit(0 if r['passed'] else 1)
