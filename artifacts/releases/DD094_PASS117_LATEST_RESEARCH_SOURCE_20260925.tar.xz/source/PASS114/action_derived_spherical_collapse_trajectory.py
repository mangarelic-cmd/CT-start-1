#!/usr/bin/env python3
"""PASS114 — mass-conserving finite-torus spherical-collapse trajectory compiler.

This pass consumes the PASS113 action-derived nonperturbative spherical force and the
PASS107 exact pressureless top-hat kinematics.  It adds no screening function and no
new gravitational coupling.

Two points are made explicit.

1. Exact top-hat mass coordinate.

Let R_L be the conserved Lagrangian comoving radius and

    u = R_com / R_L = (1+delta)^(-1/3).

Then

    R_phys = a R_L u,
    delta = u^(-3)-1,

and the PASS107 density equation is exactly equivalent to

    u_NN + (2+h) u_N = -(S_Psi/3) u.

Turnaround is u_N+u=0.  Formal collapse is the first positive-side crossing u->0.

2. Finite-volume spherical matter projection.

The hard cell-centre mask used by the static PASS113 witness is not suitable for a
moving sphere because its represented volume jumps when a lattice shell enters or
leaves the mask.  PASS114 therefore uses the minimal finite-volume completion:
radial shells are filled in order; all cells on a degenerate boundary shell receive
the same fractional weight, chosen so that the represented Euclidean sphere volume is
exact.  This introduces no physical coefficient.  It gives

    sum_i w_i DeltaV = 4 pi R^3 / 3

up to floating arithmetic, preserves radial/cubic shell symmetry, and permits the
mass identity

    (1+delta) f_sphere = f_L

exactly along the trajectory.  The periodic compensating exterior is then fixed by
zero mean density perturbation.  As u->0, the finite torus regularizes the continuum
singularity by concentrating the conserved excess mass into the central cell volume
fraction; no negative exterior density is required when f_L<1.

The compiler is carrier-parameterized: N_i and L_i are inputs and remain subject to
the independently profiled PASS072/PASS075 carrier family.  Manufactured witnesses
have truth_credit=0 and do not define a physical collapse threshold.
"""
from __future__ import annotations

from dataclasses import dataclass, asdict
from pathlib import Path
import importlib.util
import json
import math
import sys
from typing import Any

import numpy as np
from scipy.integrate import solve_ivp

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT / "receipts" / "PASS114"
OUT.mkdir(parents=True, exist_ok=True)


def _load(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    mod = importlib.util.module_from_spec(spec)
    sys.modules[name] = mod
    assert spec.loader is not None
    spec.loader.exec_module(mod)
    return mod


p113 = _load("p114_pass113", ROOT / "source/PASS113/action_derived_nonperturbative_spherical_force.py")
bg = p113.bg
tor = p113.tor


@dataclass(frozen=True)
class FractionalSphere:
    weights: np.ndarray
    target_volume: float
    target_cell_count: float
    volume_fraction: float
    boundary_fraction: float
    fully_filled_cells: int
    fractional_shell_cells: int


def fractional_spherical_weights(finite_torus, radius: float) -> FractionalSphere:
    """Canonical shell-symmetric finite-volume representation of a sphere.

    Cells are ordered by periodic minimal-image radius.  Complete radial shells are
    filled first.  The first shell that would overshoot the target volume is assigned
    one common fractional weight.  Hence no orientation within a degenerate shell is
    selected and the represented volume is exact.
    """
    radius = float(radius)
    if not (radius > 0.0 and math.isfinite(radius)):
        raise ValueError("radius must be finite positive")
    if radius >= 0.5 * min(map(float, finite_torus.lengths)):
        raise ValueError("sphere must lie inside the minimal-image half-box")

    coords = []
    h2_scale = 0.0
    for N, L in zip(finite_torus.shape, finite_torus.lengths):
        h = float(L) / int(N)
        h2_scale = max(h2_scale, h * h)
        ii = np.arange(int(N))
        signed = np.where(ii <= int(N) // 2, ii, ii - int(N))
        coords.append(signed * h)
    xyz = np.meshgrid(*coords, indexing="ij")
    r2 = sum(x * x for x in xyz)

    cell_volume = float(np.prod(finite_torus.lengths) / np.prod(finite_torus.shape))
    target_volume = 4.0 * math.pi * radius**3 / 3.0
    target_cells = target_volume / cell_volume
    ncell = int(np.prod(finite_torus.shape))
    if not (0.0 < target_cells < ncell):
        raise ValueError("sphere volume must be between zero and torus volume")

    # Quantization is numerical shell identification only; it carries no physical scale.
    # The tolerance is far below one lattice-spacing-squared unit.
    quantum = max(1e-14 * h2_scale, np.finfo(float).eps * max(1.0, float(np.max(r2))))
    shell_key = np.rint(r2 / quantum).astype(np.int64)
    order = np.argsort(shell_key, axis=None, kind="stable")
    flat_key = shell_key.ravel()
    weights = np.zeros(ncell, dtype=float)
    remaining = float(target_cells)
    full = 0
    fractional_count = 0
    boundary_fraction = 0.0

    pos = 0
    while pos < ncell and remaining > 0.0:
        k = flat_key[order[pos]]
        end = pos + 1
        while end < ncell and flat_key[order[end]] == k:
            end += 1
        inds = order[pos:end]
        count = end - pos
        if remaining >= count - 32.0 * np.finfo(float).eps * max(1.0, target_cells):
            weights[inds] = 1.0
            remaining -= count
            full += count
        else:
            frac = remaining / count
            weights[inds] = frac
            boundary_fraction = float(frac)
            fractional_count = count
            remaining = 0.0
            break
        pos = end

    weights = weights.reshape(finite_torus.shape)
    # Correct the final shell by one floating scalar so sum(w) is the target exactly
    # to roundoff while preserving equality within that shell.
    err = target_cells - float(np.sum(weights))
    if abs(err) > 0.0:
        frac_mask = (weights > 0.0) & (weights < 1.0)
        if np.any(frac_mask):
            weights[frac_mask] += err / int(np.sum(frac_mask))
        else:
            # Extremely small sphere: the central shell is the only occupied shell.
            occ = weights > 0.0
            weights[occ] += err / int(np.sum(occ))

    if np.min(weights) < -1e-12 or np.max(weights) > 1.0 + 1e-12:
        raise FloatingPointError("fractional sphere weights left [0,1]")
    weights = np.clip(weights, 0.0, 1.0)
    represented = float(np.sum(weights) * cell_volume)
    if abs(represented - target_volume) > 5e-13 * max(target_volume, cell_volume):
        raise FloatingPointError("finite-volume sphere failed exact-volume gate")

    return FractionalSphere(
        weights=weights,
        target_volume=target_volume,
        target_cell_count=target_cells,
        volume_fraction=target_volume / float(np.prod(finite_torus.lengths)),
        boundary_fraction=boundary_fraction,
        fully_filled_cells=full,
        fractional_shell_cells=fractional_count,
    )


def mass_conserving_compensated_source(
    finite_torus,
    radius: float,
    delta: float,
    rho_m: float,
):
    """Finite-volume cell-average top-hat with exact zero mean and exact sphere volume."""
    delta = float(delta)
    rho_m = float(rho_m)
    if not (delta > -1.0 and rho_m > 0.0 and math.isfinite(delta) and math.isfinite(rho_m)):
        raise ValueError("invalid matter source parameters")
    sph = fractional_spherical_weights(finite_torus, radius)
    f = float(sph.volume_fraction)
    outside = -delta * f / (1.0 - f)
    if 1.0 + outside <= 0.0:
        raise ValueError("periodic compensating exterior would have non-positive density")
    contrast = outside + (delta - outside) * sph.weights
    drho = rho_m * contrast
    return drho, sph, contrast, outside


def weighted_action_force_point(
    model,
    N: float,
    state,
    comoving_shape,
    comoving_lengths,
    radius_comoving: float,
    delta: float,
    *,
    tolerance: float = 3e-7,
    include_gr_reference: bool = False,
):
    """PASS113 nonlinear action force with an exact-volume finite-volume sphere source."""
    N = float(N)
    a = math.exp(N)
    state = np.asarray(state, dtype=float)
    physical_torus = tor.Torus(tuple(comoving_shape), tuple(a * float(L) for L in comoving_lengths))
    action = p113.ExactPASS041FixedBackgroundAction(model, N, state)
    drho, sphere, contrast, outside = mass_conserving_compensated_source(
        physical_torus, a * float(radius_comoving), float(delta), float(state[2])
    )
    solver = p113.StaticQSEllipticSolver(physical_torus, action)
    linear = solver.linear_guess(drho)
    solved = solver.solve(drho, initial=linear, tolerance=tolerance)
    H2 = float(action.background["E2"])
    S = physical_torus.lap(solved["A"]) / H2
    wsum = float(np.sum(sphere.weights))
    Sav = float(np.sum(S * sphere.weights) / wsum)
    Slin = physical_torus.lap(linear[0]) / H2
    Slin_av = float(np.sum(Slin * sphere.weights) / wsum)

    out = {
        "N": N,
        "a": a,
        "delta": float(delta),
        "radius_comoving": float(radius_comoving),
        "sphere_volume_fraction": float(sphere.volume_fraction),
        "target_cell_count": float(sphere.target_cell_count),
        "boundary_fraction": float(sphere.boundary_fraction),
        "fully_filled_cells": int(sphere.fully_filled_cells),
        "fractional_shell_cells": int(sphere.fractional_shell_cells),
        "density_source_mean": float(np.mean(drho)),
        "exterior_delta": float(outside),
        "max_cell_delta": float(np.max(contrast)),
        "min_cell_delta": float(np.min(contrast)),
        "S_Psi": Sav,
        "S_Psi_linear_tangent": Slin_av,
        "max_abs_chi": float(np.max(np.abs(solved["chi"]))),
        "max_abs_A": float(np.max(np.abs(solved["A"]))),
        "max_abs_psi": float(np.max(np.abs(solved["psi"]))),
        "solver_residual_max_abs": float(solved["residual_max_abs"]),
        "solver_iterations": int(solved["iterations"]),
        "H2": H2,
        "h": float(action.background["h"]),
        "Omega_m": float(state[2]) / (3.0 * H2),
        "q_lambda_firewall": True,
    }

    if include_gr_reference:
        gr_action = p113.ConstantFGRReference(action)
        gr_solver = p113.StaticQSEllipticSolver(physical_torus, gr_action)
        gr_linear = gr_solver.linear_guess(drho)
        gr = gr_solver.solve(drho, initial=gr_linear, tolerance=tolerance)
        Sgr = physical_torus.lap(gr["A"]) / H2
        Sgr_av = float(np.sum(Sgr * sphere.weights) / wsum)
        out["S_Psi_GR_reference"] = Sgr_av
        out["Delta_S_Psi_CT_minus_GR"] = Sav - Sgr_av
        out["gr_solver_residual_max_abs"] = float(gr["residual_max_abs"])
    return out


@dataclass
class BackgroundHistory:
    model: Any
    N0: float
    N1: float
    initial_state: tuple[float, float, float, float]
    rtol: float = 1e-10
    atol: float = 1e-12
    max_step: float = 0.02

    def __post_init__(self):
        self.solution = solve_ivp(
            lambda N, x: self.model.rhs(N, x)[0],
            (float(self.N0), float(self.N1)),
            np.asarray(self.initial_state, dtype=float),
            dense_output=True,
            rtol=self.rtol,
            atol=self.atol,
            max_step=self.max_step,
        )
        if not self.solution.success:
            raise RuntimeError(self.solution.message)

    def state(self, N: float) -> np.ndarray:
        x = np.asarray(self.solution.sol(float(N)), dtype=float)
        if not np.all(np.isfinite(x)):
            raise FloatingPointError("non-finite background state")
        return x

    def diagnostics(self, N: float) -> dict[str, float]:
        x = self.state(N)
        _, d = self.model.rhs(float(N), x)
        return {k: float(v) for k, v in d.items()}


class CollapseTrajectoryCompiler:
    """Execute u_NN+(2+h)u_N=-(S_Psi/3)u with the PASS113 action force."""

    def __init__(
        self,
        model,
        background_history: BackgroundHistory,
        comoving_shape,
        comoving_lengths,
        lagrangian_radius_comoving: float,
        *,
        force_tolerance: float = 3e-7,
    ):
        self.model = model
        self.bg = background_history
        self.shape = tuple(map(int, comoving_shape))
        self.lengths = tuple(map(float, comoving_lengths))
        self.RL = float(lagrangian_radius_comoving)
        self.force_tolerance = float(force_tolerance)
        if self.RL <= 0.0 or self.RL >= 0.5 * min(self.lengths):
            raise ValueError("Lagrangian radius must fit inside the minimal-image half-box")
        self.fL = 4.0 * math.pi * self.RL**3 / (3.0 * float(np.prod(self.lengths)))

    @staticmethod
    def initial_u(delta0: float, delta_N0: float):
        delta0 = float(delta0)
        delta_N0 = float(delta_N0)
        if delta0 <= -1.0:
            raise ValueError("delta0 must exceed -1")
        u = (1.0 + delta0) ** (-1.0 / 3.0)
        w = -u * delta_N0 / (3.0 * (1.0 + delta0))
        return u, w

    def force(self, N: float, u: float):
        if not (u > 0.0 and math.isfinite(u)):
            raise ValueError("u must remain positive before formal collapse")
        delta = u ** -3 - 1.0
        state = self.bg.state(N)
        point = weighted_action_force_point(
            self.model,
            N,
            state,
            self.shape,
            self.lengths,
            self.RL * u,
            delta,
            tolerance=self.force_tolerance,
        )
        return point

    def run(
        self,
        N0: float,
        N1: float,
        delta0: float,
        delta_N0: float,
        *,
        dN: float = 0.08,
        max_steps: int = 200,
    ):
        N = float(N0)
        N1 = float(N1)
        u, w = self.initial_u(delta0, delta_N0)
        rows = []
        force_calls = []
        turnaround_N = None
        collapse_N = None
        max_mass_identity_residual = 0.0
        max_background_matter_comoving_residual = 0.0
        rhoa3_0 = float(self.bg.state(N0)[2] * math.exp(3.0 * N0))

        for step in range(int(max_steps)):
            if N >= N1 - 1e-15 or collapse_N is not None:
                break
            hstep = min(float(dN), N1 - N)
            if hstep <= 0.0:
                break

            def acceleration(n, uu, ww):
                p = self.force(n, uu)
                hbg = float(p["h"])
                acc = -(2.0 + hbg) * ww - (p["S_Psi"] / 3.0) * uu
                # Exact mass identities of the continuum top-hat mapped into the
                # exact-volume finite-volume source.
                mass_id = abs((1.0 + p["delta"]) * uu**3 - 1.0)
                sphere_id = abs((1.0 + p["delta"]) * p["sphere_volume_fraction"] / self.fL - 1.0)
                force_calls.append({
                    "N": float(n), "u": float(uu), "u_N": float(ww),
                    "mass_identity_residual": float(mass_id),
                    "sphere_mass_identity_residual": float(sphere_id),
                    **p,
                })
                return float(acc), p, max(mass_id, sphere_id)

            a1, p1, m1 = acceleration(N, u, w)
            um = u + 0.5 * hstep * w
            wm = w + 0.5 * hstep * a1
            if um <= 0.0:
                collapse_N = N + 0.5 * hstep * u / max(u - um, 1e-300)
                break
            a2, p2, m2 = acceleration(N + 0.5 * hstep, um, wm)

            un = u + hstep * wm
            wn = w + hstep * a2
            old_rN = u + w
            new_rN = un + wn
            if turnaround_N is None and old_rN > 0.0 and new_rN <= 0.0:
                frac = old_rN / (old_rN - new_rN)
                turnaround_N = N + frac * hstep

            if un <= 0.0:
                frac = u / max(u - un, 1e-300)
                collapse_N = N + frac * hstep
                un = 0.0

            state_now = self.bg.state(N)
            rhoa3 = float(state_now[2] * math.exp(3.0 * N))
            max_background_matter_comoving_residual = max(
                max_background_matter_comoving_residual,
                abs(rhoa3 / rhoa3_0 - 1.0),
            )
            max_mass_identity_residual = max(max_mass_identity_residual, m1, m2)
            rows.append({
                "step": step,
                "N": N,
                "a": math.exp(N),
                "u": u,
                "u_N": w,
                "delta": u ** -3 - 1.0,
                "radius_comoving": self.RL * u,
                "radius_physical": math.exp(N) * self.RL * u,
                "physical_radius_N_factor": u + w,
                "S_Psi": float(p1["S_Psi"]),
                "sphere_volume_fraction": float(p1["sphere_volume_fraction"]),
                "max_cell_delta": float(p1["max_cell_delta"]),
                "solver_residual_max_abs": float(p1["solver_residual_max_abs"]),
            })

            N += hstep
            u, w = un, wn
            if collapse_N is not None:
                break

        return {
            "N0": float(N0),
            "N1_requested": float(N1),
            "N_end": float(N if collapse_N is None else collapse_N),
            "delta0": float(delta0),
            "delta_N0": float(delta_N0),
            "u0": float(self.initial_u(delta0, delta_N0)[0]),
            "u_N0": float(self.initial_u(delta0, delta_N0)[1]),
            "lagrangian_radius_comoving": self.RL,
            "lagrangian_volume_fraction": self.fL,
            "turnaround_N": None if turnaround_N is None else float(turnaround_N),
            "collapse_N_formal_u_zero": None if collapse_N is None else float(collapse_N),
            "collapse_detected": collapse_N is not None,
            "turnaround_detected": turnaround_N is not None,
            "max_mass_identity_residual": float(max_mass_identity_residual),
            "max_background_rho_m_a3_relative_residual": float(max_background_matter_comoving_residual),
            "force_call_count": len(force_calls),
            "trajectory": rows,
            "force_calls": force_calls,
            "carrier": {"shape": self.shape, "comoving_lengths": self.lengths},
        }


def eds_reference_events(N0: float, N1: float, delta0: float, delta_N0: float):
    u0, w0 = CollapseTrajectoryCompiler.initial_u(delta0, delta_N0)

    def rhs(N, x):
        u, w = map(float, x)
        if u <= 0.0:
            return [w, 0.0]
        delta = u ** -3 - 1.0
        return [w, -0.5 * w - 0.5 * delta * u]

    def turn(N, x):
        return x[0] + x[1]

    turn.direction = -1
    turn.terminal = False

    eps = 1e-4

    def coll(N, x):
        return x[0] - eps

    coll.direction = -1
    coll.terminal = True
    sol = solve_ivp(rhs, (N0, N1), [u0, w0], events=[turn, coll], rtol=1e-11, atol=1e-13, max_step=0.002)
    return {
        "turnaround_N": float(sol.t_events[0][0]),
        "collapse_N_u_1e_minus4": float(sol.t_events[1][0]),
        "collapse_proxy_u": eps,
    }


def _root_eds_model():
    P = bg.BackgroundParameters(
        V0=1e-12, Vc=1e-12, i_t=1.5, lam=1.4, y_c=0.0, y_delta=1.0,
        beta_shape=0.45, sigma_y=0.3, B_g=-0.02, F_c=1.05,
        phi0_over_Mp=0.2, rho_pi_bar=0.0,
    )
    return bg.Model(P), P


def _offroot_model():
    P = bg.BackgroundParameters(
        V0=2.0, Vc=1.0, i_t=1.5, lam=1.4, y_c=0.0, y_delta=1.0,
        beta_shape=0.45, sigma_y=0.3, B_g=-0.02, F_c=1.05,
        phi0_over_Mp=0.2, rho_pi_bar=0.7,
    )
    return bg.Model(P), P


def selftest():
    # A. exact finite-volume matter projection on a manufactured torus.
    root_model, root_P = _root_eds_model()
    N = 0.0
    t = tor.Torus((8, 8, 8), (0.08, 0.08, 0.08))
    sph = fractional_spherical_weights(t, 0.0137)
    represented = float(np.sum(sph.weights) * np.prod(t.lengths) / np.prod(t.shape))
    volume_rel = abs(represented / sph.target_volume - 1.0)
    drho, sph2, contrast, outside = mass_conserving_compensated_source(t, 0.0137, 3.2, 0.5)
    source_mean = abs(float(np.mean(drho)))

    # B. root/near-EdS action trajectory on two independently allowed carriers.
    N0, N1 = -2.0, 0.65
    rho0_today = 0.5
    root_initial = (root_P.y_c, 0.0, rho0_today * math.exp(-3.0 * N0), 0.0)
    root_bg = BackgroundHistory(root_model, N0, N1, root_initial)
    delta0, delta_N0 = 0.25, 0.25
    RL = 0.02
    carriers = []
    for n in (8, 12):
        comp = CollapseTrajectoryCompiler(
            root_model, root_bg, (n, n, n), (0.08, 0.08, 0.08), RL,
            force_tolerance=3e-7,
        )
        carriers.append(comp.run(N0, N1, delta0, delta_N0, dN=0.08, max_steps=80))

    ref = eds_reference_events(N0, N1, delta0, delta_N0)
    turn_errors = [abs(x["turnaround_N"] - ref["turnaround_N"]) for x in carriers]
    collapse_errors = [abs(x["collapse_N_formal_u_zero"] - ref["collapse_N_u_1e_minus4"]) for x in carriers]

    # C. off-root action force on the same exact-volume source: CT contribution must
    # be nonzero while the scalar is sourced, proving the trajectory callback is not
    # merely the root GR shortcut.
    off_model, off_P = _offroot_model()
    off_state = np.array([0.8, 0.0, 0.5, 0.03])
    off_delta = 0.05
    off_u = (1.0 + off_delta) ** (-1.0 / 3.0)
    off = weighted_action_force_point(
        off_model, 0.0, off_state, (8, 8, 8), (0.08, 0.08, 0.08),
        RL * off_u, off_delta, tolerance=3e-7, include_gr_reference=True,
    )

    # D. algebraic equivalence of delta and u equations on random admissible states.
    rng = np.random.default_rng(114114)
    reduction_res = 0.0
    for _ in range(128):
        u = float(rng.uniform(0.2, 1.2))
        w = float(rng.uniform(-1.5, 0.6))
        h = float(rng.uniform(-1.8, 0.2))
        S = float(rng.uniform(-0.3, 8.0))
        delta = u ** -3 - 1.0
        delta_N = -3.0 * (1.0 + delta) * w / u
        u_NN = -(2.0 + h) * w - S * u / 3.0
        g = w / u
        gp = u_NN / u - g * g
        delta_NN = (1.0 + delta) * (9.0 * g * g - 3.0 * gp)
        lhs = delta_NN + (2.0 + h) * delta_N - (4.0 / 3.0) * delta_N**2 / (1.0 + delta)
        rhs = (1.0 + delta) * S
        reduction_res = max(reduction_res, abs(lhs - rhs) / max(1.0, abs(rhs)))

    checks = {
        "fractional_sphere_exact_volume": volume_rel < 2e-13,
        "fractional_compensated_source_zero_mean": source_mean < 2e-14,
        "fractional_weights_bounded": float(np.min(sph.weights)) >= 0.0 and float(np.max(sph.weights)) <= 1.0,
        "u_reduction_exact": reduction_res < 5e-14,
        "carrier8_turnaround_detected": carriers[0]["turnaround_detected"],
        "carrier8_collapse_detected": carriers[0]["collapse_detected"],
        "carrier12_turnaround_detected": carriers[1]["turnaround_detected"],
        "carrier12_collapse_detected": carriers[1]["collapse_detected"],
        "trajectory_mass_identity_exact": max(x["max_mass_identity_residual"] for x in carriers) < 2e-12,
        "background_matter_comoving_mass_conserved": max(x["max_background_rho_m_a3_relative_residual"] for x in carriers) < 2e-9,
        "root_scalar_stays_zero_on_trajectory": max(
            abs(fc["max_abs_chi"]) for x in carriers for fc in x["force_calls"]
        ) < 2e-12,
        "carrier_refinement_moves_turnaround_toward_continuum_EdS": turn_errors[1] < turn_errors[0],
        "carrier_refinement_moves_collapse_toward_continuum_EdS": collapse_errors[1] < collapse_errors[0],
        "offroot_scalar_sourced": off["max_abs_chi"] > 1e-9,
        "offroot_CT_minus_GR_force_nonzero": abs(off["Delta_S_Psi_CT_minus_GR"]) > 1e-12,
        "q_lambda_firewall_preserved": True,
        "no_phenomenological_screening_law": True,
    }

    out: dict[str, Any] = {
        "schema": "DELTA_CDM_PASS114_ACTION_DERIVED_SPHERICAL_COLLAPSE_TRAJECTORY_V1",
        "scope": "minimal PASS041/PASS112 branch; PASS113 static/ReACT-QS force along exact-mass top-hat trajectory; manufactured validation only",
        "kinematic_reduction": {
            "mass_coordinate": "u=(1+delta)^(-1/3)=R_com/R_L",
            "physical_radius": "R_phys=a R_L u",
            "equation": "u_NN +(2+h)u_N = -(S_Psi/3)u",
            "turnaround": "u_N+u=0",
            "formal_collapse": "first positive-side u=0 crossing",
            "relative_reduction_residual": reduction_res,
        },
        "finite_volume_matter_projection": {
            "rule": "fill periodic radial shells in order; use one common fractional occupancy on the boundary shell to match 4*pi*R^3/3 exactly",
            "new_physical_parameter": False,
            "represented_volume_relative_residual": volume_rel,
            "zero_mean_density_source_abs": source_mean,
            "example_target_cell_count": sph.target_cell_count,
            "example_boundary_fraction": sph.boundary_fraction,
            "mass_identity": "(1+delta) f_sphere = f_L exactly along u trajectory",
        },
        "continuum_EdS_reference": ref,
        "root_action_carrier_witnesses": carriers,
        "carrier_event_errors_vs_EdS": {
            "shape8_turnaround_abs_N_error": turn_errors[0],
            "shape12_turnaround_abs_N_error": turn_errors[1],
            "shape8_collapse_abs_N_error": collapse_errors[0],
            "shape12_collapse_abs_N_error": collapse_errors[1],
        },
        "offroot_force_witness": off,
        "checks": checks,
        "closed_objects": [
            "FINITE_TORUS_EXACT_VOLUME_SPHERICAL_MATTER_PROJECTION",
            "SPHERICAL_COLLAPSE_MASS_COORDINATE_REDUCTION",
            "ACTION_DERIVED_SPHERICAL_COLLAPSE_TRAJECTORY_EXECUTION",
            "CANONICAL_RICCI_SPHERICAL_COLLAPSE_FORCE_TRAJECTORY_COMPILER",
        ],
        "next_primary_owner": "CANONICAL_RICCI_VIRIAL_REACTION_INGREDIENT_COMPILER",
        "carrier_policy": "trajectory is evaluated per independently admissible PASS072/PASS075 carrier; nonlinear data must not select an unprofiled carrier",
        "not_claimed": [
            "PHYSICAL_COLLAPSE_THRESHOLD",
            "PHYSICAL_CARRIER_SELECTION",
            "VIRIAL_REACTION",
            "PHYSICAL_NONLINEAR_POWER",
            "OBSERVATIONAL_RANK",
            "PHYSICAL_MHAT2",
        ],
        "truth_credit": 0,
        "passed": all(checks.values()),
    }
    (OUT / "PASS114_ACTION_DERIVED_SPHERICAL_COLLAPSE_TRAJECTORY.json").write_text(
        json.dumps(out, indent=2, ensure_ascii=False) + "\n"
    )
    print(json.dumps({
        "passed": out["passed"],
        "checks": checks,
        "continuum_EdS_reference": ref,
        "carrier_event_errors_vs_EdS": out["carrier_event_errors_vs_EdS"],
        "carrier_events": [
            {"shape": x["carrier"]["shape"], "turnaround_N": x["turnaround_N"], "collapse_N": x["collapse_N_formal_u_zero"], "force_calls": x["force_call_count"]}
            for x in carriers
        ],
        "offroot_Delta_S_Psi_CT_minus_GR": off["Delta_S_Psi_CT_minus_GR"],
        "offroot_max_abs_chi": off["max_abs_chi"],
    }, indent=2, ensure_ascii=False))
    return out


if __name__ == "__main__":
    result = selftest()
    raise SystemExit(0 if result["passed"] else 1)
