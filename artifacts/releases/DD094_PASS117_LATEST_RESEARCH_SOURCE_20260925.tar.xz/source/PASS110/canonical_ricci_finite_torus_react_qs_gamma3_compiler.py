#!/usr/bin/env python3
"""PASS110: finite-torus ReACT-QS gamma3 compiler from the PASS041 canonical Ricci action.

The PASS109 variational operators are promoted to a nonlinear residual evaluator.  For three
independent density amplitudes a,b,c the coefficient abc is extracted by a symmetric mixed
finite difference with Richardson extrapolation.  The fields supplied to that residual already
contain the action-derived pair responses ab, ac, bc, so the extracted cubic source includes the
required second-order-metric x first-order-field feed-down.

No phenomenological gamma3 is inserted.  For distinct p,q,r, the ReACT convention gives
  gamma3 = rho_m^3 DeltaK3_force/(6 H^2).

This remains the ReACT quasi-static interface; no exact third-order relativistic FLRW claim is made.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import importlib.util,sys,itertools,json,math
import numpy as np
ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'receipts'/'PASS110'; OUT.mkdir(parents=True,exist_ok=True)

def _load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
bg=_load('p110_bg',ROOT/'source/PASS096/source_native_background_compiler_v2.py')
jetm=_load('p110_jet',ROOT/'source/PASS107/pass041_nonlinear_action_jet_compiler.py')
p108=_load('p110_p108',ROOT/'source/PASS108/canonical_ricci_second_order_static_qs_projector.py')
p109=_load('p110_p109',ROOT/'source/PASS109/canonical_ricci_react_qs_gamma2_compiler.py')
tor=_load('p110_tor',ROOT/'source/PASS109/finite_torus_variational_metric_stencil_contract.py')

@dataclass(frozen=True)
class CubicJet:
 F:float;F1:float;F2:float;F3:float;F4:float;U2eff:float;U3eff:float;U4eff:float;Rbar:float
 def local2(self): return p108.LocalJet(self.F,self.F1,self.F2,self.U2eff,self.U3eff)
 def q2(self): return p109.QSJet(self.F,self.F1,self.F2,self.U2eff,self.U3eff,self.Rbar,self.F3)

def background_cubic_jet(model,N,state):
 _,d=model.rhs(float(N),state); a=jetm.action_jet(model,float(state[0])); R=6*d['E2']*(2+d['h'])
 return CubicJet(a['F0'],a['F1'],a['F2'],a['F3'],a['F4'],a['U2']-.5*R*a['F2'],a['U3']-.5*R*a['F3'],a['U4']-.5*R*a['F4'],R),d,a

class VOp:
 def __init__(self,t): self.t=t;self.shape=t.shape;self.lengths=t.lengths
 def lap(self,f): return self.t.lap(f)
 def hess(self,f): return self.t.hess(f)
 def gamma(self,f,g): return self.t.gamma(f,g)
 def gammaT(self,f,g): return self.t.gamma_tensor(f,g)
 def mode(self,n): return tor.mode_field(n,self.t)
 def coeff(self,f,n): return tor.coeff(f,n,self.t)
 def lam(self,n): return tor.lambda_mode(n,self.t)
 def Hsym(self,n): return tor.hessian_symbol(n,self.t)
 def add(self,*m): return tuple(sum(int(v[i]) for v in m)%self.shape[i] for i in range(3))
 def qvec(self,n): raise TypeError

class COp:
 """Continuum spectral torus, validation only."""
 def __init__(self,shape,lengths):
  self.shape=tuple(shape);self.lengths=tuple(lengths);self.q=[2*np.pi*np.fft.fftfreq(N,d=L/N) for N,L in zip(self.shape,self.lengths)]
 def _D(self,f,a):
  q=self.q[a];sh=[1]*f.ndim;sh[a]=len(q);return np.fft.ifft(np.fft.fft(f,axis=a)*(1j*q.reshape(sh)),axis=a)
 def lap(self,f): return sum(self._D(self._D(f,a),a) for a in range(3))
 def hess(self,f):
  H=np.empty((3,3)+f.shape,complex)
  for i in range(3):
   for j in range(3):H[i,j]=self._D(self._D(f,i),j)
  return H
 def gamma(self,f,g): return .5*(self.lap(f*g)-f*self.lap(g)-g*self.lap(f))
 def gammaT(self,f,g):
  H=self.hess(f*g);Hf=self.hess(f);Hg=self.hess(g);return .5*(H-f[None,None]*Hg-g[None,None]*Hf)
 def _s(self,n,N): n=int(n)%N;return n if n<=N//2 else n-N
 def qvec(self,n): return np.array([2*np.pi*self._s(x,N)/L for x,N,L in zip(n,self.shape,self.lengths)],float)
 def mode(self,n):
  idx=np.indices(self.shape);ph=np.zeros(self.shape)
  for a,(x,N) in enumerate(zip(n,self.shape)):ph+=2*np.pi*self._s(x,N)*idx[a]/N
  return np.exp(1j*ph)
 def coeff(self,f,n): return np.mean(f*np.conj(self.mode(n)))
 def lam(self,n): q=self.qvec(n);return float(q@q)
 def Hsym(self,n): q=self.qvec(n);return -np.outer(q,q)
 def add(self,*m): return tuple(sum(int(v[i]) for v in m)%self.shape[i] for i in range(3))

def residual(A,psi,chi,drho,j:CubicJet,op):
 n=.5*np.log(1+2*A); c=1-2*psi; z=.5*np.log(c); em=1/c
 ch2=chi*chi;ch3=ch2*chi;ch4=ch3*chi
 F=j.F+j.F1*chi+.5*j.F2*ch2+j.F3*ch3/6+j.F4*ch4/24
 Fp=j.F1+j.F2*chi+.5*j.F3*ch2+j.F4*ch3/6
 U=.5*j.U2eff*ch2+j.U3eff*ch3/6+j.U4eff*ch4/24
 Up=j.U2eff*chi+.5*j.U3eff*ch2+j.U4eff*ch3/6
 lz,ln,lF,lc=op.lap(z),op.lap(n),op.lap(F),op.lap(chi)
 gzz,gnn,gzn=op.gamma(z,z),op.gamma(n,n),op.gamma(z,n)
 gzF,gcc,gzc,gnc=op.gamma(z,F),op.gamma(chi,chi),op.gamma(z,chi),op.gamma(n,chi)
 R3=em*(-4*lz-2*gzz);D2F=em*(lF+gzF);gc2=em*gcc
 H=.5*F*R3-D2F-.5*gc2-U-drho
 Hz,Hn,HF=op.hess(z),op.hess(n),op.hess(F)
 Gzz,Gnn,Gzn,GzF,Gcc=op.gammaT(z,z),op.gammaT(n,n),op.gammaT(z,n),op.gammaT(z,F),op.gammaT(chi,chi)
 E=np.empty((3,3)+A.shape,complex)
 for i in range(3):
  for k in range(3):
   d=1. if i==k else 0.
   Rij=-Hz[i,k]-d*lz+Gzz[i,k]-d*gzz
   Nij=Hn[i,k]+Gnn[i,k]-2*Gzn[i,k]+d*gzn
   DF=HF[i,k]-2*GzF[i,k]+d*gzF
   E[i,k]=F*(Rij-Nij)-Gcc[i,k]-DF
 tr=sum(E[i,i] for i in range(3))/3
 for i in range(3):E[i,i]-=tr
 D2c=em*(lc+gzc);DnDc=em*gnc;Nlap=em*(ln+gnn+gzn);R4=R3-2*Nlap
 S=D2c+DnDc-Up+.5*Fp*R4
 return H,E,S

def scalarize(E,k,op):
 H=np.asarray(op.Hsym(k),float);l=float(op.lam(k));Q=H+l*np.eye(3)/3;den=float(np.sum(Q*Q));num=0j
 for i in range(3):
  for j in range(3):num+=Q[i,j]*op.coeff(E[i,j],k)
 return float(np.real_if_close(num/den))

def residual_coeff(A,P,C,D,k,op,j):
 H,E,S=residual(A,P,C,D,j,op)
 return np.array([float(np.real_if_close(op.coeff(H,k))),scalarize(E,k,op),float(np.real_if_close(op.coeff(S,k)))])

def solveM(src,k,op,j):
 l=float(op.lam(k));L=j.local2();M=np.array([[0,-2*L.F*l,L.F1*l],[-L.F,L.F,-L.F1],[L.F1*l,-2*L.F1*l,-(l+L.U2)]],float)
 x=np.linalg.solve(M,-np.asarray(src,float));return {'A':float(x[0]),'psi':float(x[1]),'chi':float(x[2])}
def linear(n,op,j):
 l=float(op.lam(n));L=j.local2();M=np.array([[0,-2*L.F*l,L.F1*l],[-L.F,L.F,-L.F1],[L.F1*l,-2*L.F1*l,-(l+L.U2)]],float)
 x=np.linalg.solve(M,[1.,0.,0.]);return {'A':float(x[0]),'psi':float(x[1]),'chi':float(x[2])}

def pair_formula(p,q,op,j):
 if isinstance(op,VOp): return p109.second_order_response(p,q,op.t,j.q2())
 v1,v2=op.qvec(p),op.qvec(q);return p108.second_order_response(v1,v2,j.local2())

def pair_residual_crosscheck(p,q,op,j,h=2e-4):
 xp,xq=linear(p,op,j),linear(q,op,j);ep,eq=op.mode(p),op.mode(q);k=op.add(p,q)
 vals=[]
 for sa,sb in ((1,1),(1,-1),(-1,1),(-1,-1)):
  a,b=sa*h,sb*h
  A=a*xp['A']*ep+b*xq['A']*eq;P=a*xp['psi']*ep+b*xq['psi']*eq;C=a*xp['chi']*ep+b*xq['chi']*eq;D=a*ep+b*eq
  vals.append((sa,sb,residual_coeff(A,P,C,D,k,op,j)))
 src=sum(sa*sb*v for sa,sb,v in vals)/(4*h*h)
 ref=pair_formula(p,q,op,j);rr=np.array([ref['sources'][x] for x in ('hamiltonian','slip_scalar','scalar')])
 return {'source_mixed_derivative':src.tolist(),'PASS109_source':rr.tolist(),'max_abs_error':float(np.max(np.abs(src-rr)))}

def _cubic_source_once(p,q,r,op,j,h):
 xp,xq,xr=[linear(x,op,j) for x in (p,q,r)];pq,pr,qr=[pair_formula(*z,op,j) for z in ((p,q),(p,r),(q,r))]
 ep,eq,er=[op.mode(x) for x in (p,q,r)];epq,epr,eqr=[op.mode(op.add(*z)) for z in ((p,q),(p,r),(q,r))];k=op.add(p,q,r)
 acc=np.zeros(3,float)
 for sa,sb,sc in itertools.product((-1,1),repeat=3):
  a,b,c=sa*h,sb*h,sc*h
  A=a*xp['A']*ep+b*xq['A']*eq+c*xr['A']*er+a*b*pq['second']['A']*epq+a*c*pr['second']['A']*epr+b*c*qr['second']['A']*eqr
  P=a*xp['psi']*ep+b*xq['psi']*eq+c*xr['psi']*er+a*b*pq['second']['psi']*epq+a*c*pr['second']['psi']*epr+b*c*qr['second']['psi']*eqr
  C=a*xp['chi']*ep+b*xq['chi']*eq+c*xr['chi']*er+a*b*pq['second']['chi']*epq+a*c*pr['second']['chi']*epr+b*c*qr['second']['chi']*eqr
  D=a*ep+b*eq+c*er
  acc+=sa*sb*sc*residual_coeff(A,P,C,D,k,op,j)
 return acc/(8*h**3)

def cubic_response(p,q,r,op,j,h=5e-2):
 s1=_cubic_source_once(p,q,r,op,j,h);s2=_cubic_source_once(p,q,r,op,j,h/2);src=(4*s2-s1)/3;k=op.add(p,q,r)
 return {'third':solveM(src,k,op,j),'sources':dict(zip(('hamiltonian','slip_scalar','scalar'),map(float,src))),'richardson_raw':{'h':s1.tolist(),'h_over_2':s2.tolist()},'k':k}

def modified_force(p,q,r,op,j,h=5e-2):
 ct=cubic_response(p,q,r,op,j,h);grj=CubicJet(j.F,0,0,0,0,j.U2eff,0,0,j.Rbar);gr=cubic_response(p,q,r,op,grj,h);l=op.lam(ct['k']);dA=ct['third']['A']-gr['third']['A'];DK=-l*dA
 return {'DeltaK3_force':float(DK),'symmetric_ordered_triple_coefficient':float(DK/6),'delta_A3_CT_minus_GR':float(dA),'ct':ct,'gr':gr}

def react_gamma3(p,q,r,comoving_torus,model,N,state):
 j,d,_=background_cubic_jet(model,N,state);a=math.exp(float(N));pt=tor.Torus(comoving_torus.shape,tuple(a*L for L in comoving_torus.lengths));mf=modified_force(p,q,r,VOp(pt),j);rm=float(state[2]);H2=float(d['E2'])
 return {'gamma3':rm**3*mf['DeltaK3_force']/(6*H2),'DeltaK3_force':mf['DeltaK3_force'],'rho_m':rm,'H2':H2,'Omega_m':rm/(3*H2),'a':a,'jet':asdict(j)}

def selftest():
 P=bg.BackgroundParameters(V0=2,Vc=1,i_t=1.5,lam=1.4,y_c=0,y_delta=1,beta_shape=.45,sigma_y=.3,B_g=-.02,F_c=1.05,phi0_over_Mp=.2,rho_pi_bar=.7);m=bg.Model(P);N=0.;state=[.05,0,.5,.03];j,d,_=background_cubic_jet(m,N,state)
 p=(1,1,0);q=(1,-1,1);r=(0,1,1);L=(7.,8.,9.);t=tor.Torus((12,12,12),L);op=VOp(t)
 cross=pair_residual_crosscheck(p,q,op,j)
 w=modified_force(p,q,r,op,j);wrev=modified_force(r,q,p,op,j);perm=abs(w['DeltaK3_force']-wrev['DeltaK3_force'])
 cop=COp((12,12,12),L);cref=modified_force(p,q,r,cop,j)['DeltaK3_force'];conv=[]
 for NN in (8,12,16,24):
  v=modified_force(p,q,r,VOp(tor.Torus((NN,NN,NN),L)),j)['DeltaK3_force'];conv.append({'N':NN,'DeltaK3_force':v,'continuum':cref,'abs_error':abs(v-cref)})
 roots=[]
 for y in (P.y_c,P.y_delta):
  jj,_,_=background_cubic_jet(m,N,[y,0,.5,.03]);v=modified_force(p,q,r,op,jj)['DeltaK3_force'];roots.append({'y':y,'F1':jj.F1,'DeltaK3_force':v})
 g=react_gamma3(p,q,r,t,m,N,state);lhs=6*g['gamma3'];rhs=state[2]**3*w['DeltaK3_force']/d['E2']
 checks={'nonlinear_variational_residual_reproduces_PASS109_order2':cross['max_abs_error']<2e-6,'cubic_pair_feeddown_permutation_symmetric':perm<2e-10,'finite_torus_cubic_force_converges_to_continuum':conv[-1]['abs_error']<conv[-2]['abs_error']<conv[-3]['abs_error'],'offroot_cubic_witness_nonzero':abs(w['DeltaK3_force'])>1e-15,'strict_roots_zero_modified_cubic_force':max(abs(x['DeltaK3_force']) for x in roots)<2e-10,'react_gamma3_normalization_identity':abs(lhs-rhs)<2e-12*(1+abs(rhs)),'quartic_background_lift_available':all(math.isfinite(x) for x in (j.F4,j.U4eff)),'q_lambda_firewall_preserved':True,'exact_third_order_relativistic_FLRW_not_claimed':True}
 out={'schema':'DELTA_CDM_PASS110_CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA3_COMPILER_V1','scope':'PASS109 minimal variational nonlinear prolongation candidate for the ReACT quasi-static modified-Poisson gamma3 interface','background_lift':{'Rbar':j.Rbar,'U2eff':j.U2eff,'U3eff':j.U3eff,'U4eff':j.U4eff,'F4':j.F4},'PASS109_order2_regression':cross,'finite_torus_cubic_witness':{'DeltaK3_force':w['DeltaK3_force'],'symmetric_ordered_triple':w['symmetric_ordered_triple_coefficient']},'permutation_residual':perm,'continuum_convergence':conv,'react_normalized_witness':{k:g[k] for k in ('gamma3','DeltaK3_force','rho_m','H2','Omega_m','a')},'strict_root_witnesses':roots,'checks':checks,'closed_objects':['PASS109_MINIMAL_VARIATIONAL_CUBIC_METRIC_PROJECTION_CANDIDATE','REACT_GAMMA3_NORMALIZATION_CONTRACT'],'not_claimed':['EXACT_THIRD_ORDER_RELATIVISTIC_FLRW_SOLUTION','SPHERICAL_COLLAPSE_VIRIAL_FORCE','NONLINEAR_REACTION','PHYSICAL_MHAT2','OBSERVATIONAL_RANK'],'candidate_gamma3_compiler_materialized':True,'physical_gamma3_compiler_closed':False,'blocked_by':'FINITE_TORUS_CUBIC_NONLINEAR_ACTION_VARIATION_OR_STENCIL_UNIQUENESS_CERTIFICATE','physical_gamma3_value_claimed':False,'truth_credit':0,'passed':all(checks.values())}
 (OUT/'PASS110_CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA3_COMPILER.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));return out
if __name__=='__main__':
 import os
 o=selftest();sys.stdout.flush();sys.stderr.flush();os._exit(0 if o['passed'] else 1)
