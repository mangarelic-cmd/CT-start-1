#!/usr/bin/env python3
"""PASS110 constructive cubic-stencil non-uniqueness witness.

PASS109 fixes Delta, H_ij and Gamma through quadratic order.  That does not by itself forbid
higher-order lattice counterterms which start at cubic order and vanish in the continuum.
This script constructs one such symmetric root-safe family and shows that it changes the finite-N
cubic force while leaving all PASS109 order <=2 statements untouched.
"""
from pathlib import Path
import json,math,numpy as np
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'receipts'/'PASS110';OUT.mkdir(parents=True,exist_ok=True)
L=(7.,8.,9.); p=(1,1,0);q=(1,-1,1);r=(0,1,1)
F,F1,U2=1.2,.3,.8

def lam(n,N): return sum(4/(LL/N)**2*math.sin(math.pi*(int(x)%N)/N)**2 for x,LL in zip(n,L))
def add(*m,N): return tuple(sum(x[i] for x in m)%N for i in range(3))
def gam(a,b,N): return .5*(lam(a,N)+lam(b,N)-lam(add(a,b,N=N),N))
def lin(n,N):
 l=lam(n,N);M=np.array([[0,-2*F*l,F1*l],[-F,F,-F1],[F1*l,-2*F1*l,-(l+U2)]],float);x=np.linalg.solve(M,[1.,0.,0.]);return x
def row(N):
 xp,xq,xr=[lin(x,N) for x in (p,q,r)];k=add(p,q,r,N=N);lk=lam(k,N);h2=sum((LL/N)**2 for LL in L)/3
 # One admissible cubic-only scalar completion. alpha multiplies this term.
 # It is permutation symmetric, proportional to F1 (root-safe), and O(h^2) in the continuum.
 dH=h2*F1*lk*(xp[2]*gam(q,r,N)*xq[1]*xr[1]+xq[2]*gam(p,r,N)*xp[1]*xr[1]+xr[2]*gam(p,q,N)*xp[1]*xq[1])/3
 M=np.array([[0,-2*F*lk,F1*lk],[-F,F,-F1],[F1*lk,-2*F1*lk,-(lk+U2)]],float)
 dx=np.linalg.solve(M,-np.array([dH,0.,0.]));dK=-lk*dx[0]
 return {'N':N,'mean_h2':h2,'alpha1_added_cubic_H_source':float(dH),'alpha1_DeltaK3_shift':float(dK)}
rows=[row(N) for N in (16,24,32,48,64)]
checks={'strictly_cubic_so_PASS109_order1_order2_unchanged':True,'permutation_symmetric_by_construction':True,'root_safe_factor_Fphi':True,'finite_N_gamma3_shift_nonzero':all(abs(x['alpha1_DeltaK3_shift'])>0 for x in rows),'continuum_shift_decays':all(abs(rows[i+1]['alpha1_DeltaK3_shift'])<abs(rows[i]['alpha1_DeltaK3_shift']) for i in range(len(rows)-1))}
out={'schema':'DELTA_CDM_PASS110_FINITE_TORUS_CUBIC_STENCIL_UNIQUENESS_FIREWALL_V1','statement':'PASS109 Delta/H/Gamma and all order<=2 tests do not uniquely fix the finite-torus cubic nonlinear metric completion. A discrete-action variation or equivalent cubic-stencil uniqueness certificate is required before the minimal-prolongation gamma3 candidate can be promoted to the physical finite-torus compiler.','completion_family':'R_alpha = R_minimal + alpha * hbar^2 * F_phi * lambda_k * sym[chi_p Gamma(q,r) psi_q psi_r] in the cubic Hamiltonian source','witness_rows':rows,'checks':checks,'candidate_status':'MINIMAL_PASS109_VARIATIONAL_PROLONGATION_MATERIALIZED','closed_object':'FINITE_TORUS_CUBIC_STENCIL_NONUNIQUENESS_WITNESS','blocked_object':'CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA3_COMPILER','new_owner':'FINITE_TORUS_CUBIC_NONLINEAR_ACTION_VARIATION_OR_STENCIL_UNIQUENESS_CERTIFICATE','truth_credit':0,'passed':all(checks.values())}
(OUT/'PASS110_FINITE_TORUS_CUBIC_STENCIL_UNIQUENESS_FIREWALL.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2))
