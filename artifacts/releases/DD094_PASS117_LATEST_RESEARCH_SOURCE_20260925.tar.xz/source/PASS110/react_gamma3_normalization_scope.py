#!/usr/bin/env python3
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'receipts'/'PASS110'; OUT.mkdir(parents=True,exist_ok=True)
out={
 'schema':'DELTA_CDM_PASS110_REACT_GAMMA3_NORMALIZATION_SCOPE_V1',
 'external_scope_sources':[
  {'source':'Bose & Koyama, arXiv:1606.02520v2, eqs. (7)-(8)','url':'https://arxiv.org/abs/1606.02520','lock':'-(k/aH)^2 Phi = (3/2) Omega_m mu delta + S, with S containing symmetric gamma2*delta*delta and gamma3*delta*delta*delta convolutions.'},
  {'source':'ACTio-ReACTio BeyondLCDM.cpp at commit a36dda02db6b537a4ddcc7bf044c446c10a58373','url':'https://github.com/nebblu/ACTio-ReACTio/blob/a36dda02db6b537a4ddcc7bf044c446c10a58373/reactions/src/BeyondLCDM.cpp','lock':'gamma2 and gamma3 are the code ports used by the perturbation-kernel evolution.'}
 ],
 'distinct_mode_combinatorics':{
  'gamma2':'two permutations -> gamma2 = rho_m^2 DeltaK2/(2 H^2)',
  'gamma3':'six permutations -> gamma3 = rho_m^3 DeltaK3/(6 H^2)'
 },
 'scope':'ReACT quasi-static nonlinear Poisson interface only',
 'closed_object':'REACT_GAMMA3_NORMALIZATION_CONTRACT',
 'truth_credit':0,'passed':True}
(OUT/'PASS110_REACT_GAMMA3_NORMALIZATION_SCOPE.json').write_text(json.dumps(out,indent=2)+'\n')
print(json.dumps(out,indent=2))
