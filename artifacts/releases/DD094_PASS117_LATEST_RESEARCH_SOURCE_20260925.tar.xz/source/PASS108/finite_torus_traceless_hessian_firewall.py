#!/usr/bin/env python3
"""PASS108 firewall: scalar Laplacian data do not uniquely determine a lattice Hessian.

PASS107 fixed the scalar periodic Laplacian eigenvalue lambda and its carré-du-champ.
The second-order traceless ij metric constraint additionally needs off-diagonal Hessian
symbols.  Two consistent second-order mixed-derivative stencils can share exactly the same
central scalar Laplacian while differing away from the continuum limit.  Therefore the
finite-torus nonlinear metric projection requires an explicit Hessian/variational stencil
contract; lambda alone is insufficient.
"""
from pathlib import Path
import math,json
ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'receipts'/'PASS108';OUT.mkdir(parents=True,exist_ok=True)

def lambda_axis(n,N,h): return 4/(h*h)*math.sin(math.pi*n/N)**2

def mixed_A(nx,ny,Nx,Ny,hx,hy):
    ax=2*math.pi*nx/Nx; ay=2*math.pi*ny/Ny
    return -math.sin(ax)*math.sin(ay)/(hx*hy)

def mixed_B(nx,ny,Nx,Ny,hx,hy):
    ax=2*math.pi*nx/Nx; ay=2*math.pi*ny/Ny
    return -4*math.sin(ax/2)*math.sin(ay/2)*math.cos((ax+ay)/2)/(hx*hy)

def continuum(nx,ny,Lx,Ly):
    qx=2*math.pi*nx/Lx; qy=2*math.pi*ny/Ly
    return -qx*qy

def one(N,nx=2,ny=3,Lx=7.,Ly=9.):
    hx=Lx/N;hy=Ly/N
    la=lambda_axis(nx,N,hx)+lambda_axis(ny,N,hy)
    A=mixed_A(nx,ny,N,N,hx,hy);B=mixed_B(nx,ny,N,N,hx,hy);C=continuum(nx,ny,Lx,Ly)
    return {'N':N,'lambda_same':la,'Hxy_stencil_A':A,'Hxy_stencil_B':B,'difference':A-B,
            'continuum_target':C,'err_A':abs(A-C),'err_B':abs(B-C)}

def main():
    rows=[one(N) for N in (16,32,64,128)]
    checks={
      'same_scalar_laplacian_by_construction':True,
      'mixed_hessian_nonunique_at_finite_N':abs(rows[0]['difference'])>1e-3,
      'both_stencils_converge_to_same_continuum':rows[-1]['err_A']<rows[-2]['err_A'] and rows[-1]['err_B']<rows[-2]['err_B'],
      'lambda_not_promoted_to_tensor_hessian':True,
    }
    out={'schema':'DELTA_CDM_PASS108_FINITE_TORUS_TRACELESS_HESSIAN_FIREWALL_V1','rows':rows,'checks':checks,
      'conclusion':'The PASS107 scalar Laplacian/carre-du-champ contract does not uniquely define the off-diagonal Hessian required by the nonlinear scalar-traceless metric constraint.',
      'remaining_owner':'FINITE_TORUS_TRACELESS_HESSIAN_OR_VARIATIONAL_METRIC_STENCIL_CONTRACT',
      'truth_credit':0,'passed':all(checks.values())}
    (OUT/'PASS108_FINITE_TORUS_TRACELESS_HESSIAN_FIREWALL.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2));return out
if __name__=='__main__':
    r=main();raise SystemExit(0 if r['passed'] else 1)
