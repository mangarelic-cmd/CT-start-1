#!/usr/bin/env python3
from pathlib import Path
import sys,json,collections,argparse
ROOT=Path(__file__).resolve().parents[2]
ACROOT=ROOT/'runtime'/'AC77'/'SC_SOLVER_AC77_PERIODIC_CARTESIAN_THEOREM_METROLOGY_CORE_20260922'
sys.path.insert(0,str(ACROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver
BASE=[
 'FINITE_DISCRETE_TORUS_E1','Q_LAMBDA_FIREWALL_CERTIFICATE','PASS041_COMPLETED_ACTION_FAMILY',
 'PASS041_ACTION_DERIVATIVES_TO_QUARTIC_ORDER','FINITE_TORUS_RAW_SCALAR_QUADRATIC_CUBIC_VERTEX_COMPILER',
 'SPHERICAL_COLLAPSE_KINEMATIC_REDUCTION','NONLINEAR_METRIC_PROJECTION_FIREWALL',
 'CANONICAL_RICCI_EVOLVING_GAUGE_REDUCED_LINEAR_MODE_SOLVER'
]
def seed(pid,statement,target,requires=(),supplies=(),**kw):
 p=dict(problem_id=pid,statement=statement,target=target,requires=list(requires),supplies=BASE+list(supplies),ground_binding=True);p.update(kw);return Node('PROBLEM',p,context=('DELTA_CDM_PASS108',pid))
seeds=[
 seed('P108_QS2','Derive and independently validate the continuum static-QS second-order Hamiltonian, scalar-traceless metric and scalar-field sources of the canonical PASS041 F(phi)R branch; solve them through the same linear operator as PASS100.','CONTINUUM_STATIC_QS_SECOND_ORDER_CANONICAL_RICCI_METRIC_FORCE_PROJECTOR',(),('CONTINUUM_STATIC_QS_SECOND_ORDER_CANONICAL_RICCI_METRIC_FORCE_PROJECTOR',),proof_object={'type':'exact_covariant_residual_expansion','receipt':'receipts/PASS108/PASS108_SECOND_ORDER_STATIC_QS_METRIC_PROJECTOR.json'},uniformity_verified=True),
 seed('P108_HESSIAN_FIREWALL','Prove that the scalar finite-torus Laplacian eigenvalue/carre-du-champ contract does not uniquely define the off-diagonal traceless Hessian required by the nonlinear metric constraint.','FINITE_TORUS_TRACELESS_HESSIAN_FIREWALL',(),('FINITE_TORUS_TRACELESS_HESSIAN_FIREWALL',),proof_object={'type':'two_stencil_same_laplacian_witness','receipt':'receipts/PASS108/PASS108_FINITE_TORUS_TRACELESS_HESSIAN_FIREWALL.json'},uniformity_verified=True,boundaries={'q_lambda_firewall':True}),
 seed('P108_GAMMA2','Lift the closed static-QS second-order force projector onto the evolving FLRW background and the selected finite-torus tensor discretization, then normalize it into the physical modified-Poisson gamma2 convention.','CANONICAL_RICCI_PHYSICAL_GAMMA2',('EVOLVING_FLRW_SECOND_ORDER_0I_TIME_LIFT','FINITE_TORUS_TRACELESS_HESSIAN_OR_VARIATIONAL_METRIC_STENCIL_CONTRACT'),(),boundaries={'static_qs_not_full_evolving_gamma2':True,'q_lambda_firewall':True,'no_free_gamma2':True}),
 seed('P108_GAMMA3','Derive the third-order metric projection only after physical gamma2 and the second-order lift are fixed.','CANONICAL_RICCI_PHYSICAL_GAMMA3',('CANONICAL_RICCI_PHYSICAL_GAMMA2','THIRD_ORDER_CANONICAL_RICCI_METRIC_CONSTRAINTS'),(),boundaries={'no_free_gamma3':True}),
 seed('P108_NONLINEAR','Construct the nonlinear reaction and physical spherical-collapse force only after physical gamma2/gamma3 are closed.','CT_NONLINEAR_HIGHER_ORDER_POISSON_AND_COLLAPSE_COMPILER',('CANONICAL_RICCI_PHYSICAL_GAMMA2','CANONICAL_RICCI_PHYSICAL_GAMMA3'),(),boundaries={'no_phenomenological_delta_nl':True}),
]
world={'project':'DELTA_CDM_PASS108','available_evidence_tokens':BASE,'external_scientific_truth_certified':False,'finite_discrete_torus':True,
'continuum_static_qs_second_order_metric_projector_closed':True,'finite_torus_hessian_firewall_closed':True,
'evolving_flrw_second_order_time_lift_closed':False,'finite_torus_traceless_hessian_contract_closed':False,
'physical_gamma2_closed':False,'physical_gamma3_closed':False,'physical_forward33_closed':False,'physical_rank_closed':False,'physical_mhat2_closed':False}
def run(recursive=False):
 s=SovereignSolver(); r=s.solve_universal(seeds,world=world,max_waves=2 if recursive else 1,max_calls=32000 if recursive else 15000,stable_waves=1)
 known=list(s.engine.known.values());counts=r.get('mechanism_execution_counts') or {};by={p.payload['problem_id']:collections.Counter() for p in seeds};front=[]
 for n in known:
  if len(n.context)>=2 and n.context[0]=='DELTA_CDM_PASS108':
   pid=n.context[1]
   if pid in by:by[pid][str(n.payload.get('status') or n.kind)]+=1
   st=str(n.payload.get('status') or '')
   if st in {'NEED_DATA','WAITING','OPEN','INVALID','PARTIAL','MISSING_CARRIER'} and n.kind not in {'AUX_OBSERVATION','MECHANISM_OBSERVATION'}:
    front.append({'problem_id':pid,'kind':n.kind,'status':st,'requires':n.payload.get('requires'),'unresolved_requirements':n.payload.get('unresolved_requirements'),'mechanism':n.payload.get('mechanism'),'statement':n.payload.get('statement')})
 out={'schema':'DELTA_CDM_PASS108_AC77_AUDIT_V1','mode':'recursive' if recursive else 'direct','solver_version':r.get('version'),'run_state':r.get('run_state'),'active_mechanism_count':r.get('active_mechanism_count'),'mechanisms_touched':sum(1 for v in counts.values() if v),'execution_calls':r.get('execution_calls'),'known_node_count':r.get('known_node_count'),'open_residual_count':r.get('open_residual_count'),'periodic_cartesian_receipt_count':r.get('periodic_cartesian_receipt_count'),'solution_certified':r.get('solution_certified'),'formal_proof_verified':r.get('formal_proof_verified'),'problem_status_counters':{k:dict(v) for k,v in by.items()},'declared_seed_requirements':{p.payload['problem_id']:p.payload.get('requires',[]) for p in seeds},'frontier_nonpass_count':len(front),'frontier_nonpass':front,'mechanism_execution_counts':counts}
 name='AC77_PASS108_RECURSIVE_AUDIT.json' if recursive else 'AC77_PASS108_DIRECT_AUDIT.json';(ROOT/'receipts/PASS108'/name).write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');return out
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--recursive',action='store_true');a=ap.parse_args();o=run(a.recursive)
 (ROOT/'receipts/PASS108/PASS108_SEED_REGISTRY.json').write_text(json.dumps([n.to_dict() for n in seeds],indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({k:o[k] for k in ['mode','solver_version','run_state','active_mechanism_count','mechanisms_touched','execution_calls','known_node_count','open_residual_count','periodic_cartesian_receipt_count','solution_certified','formal_proof_verified','declared_seed_requirements']},indent=2))
