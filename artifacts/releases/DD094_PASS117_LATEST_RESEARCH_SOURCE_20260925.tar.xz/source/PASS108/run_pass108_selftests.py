#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,json
ROOT=Path(__file__).resolve().parents[2];OUT=ROOT/'receipts'/'PASS108';OUT.mkdir(parents=True,exist_ok=True)
scripts=['canonical_ricci_second_order_static_qs_projector.py','finite_torus_traceless_hessian_firewall.py']
rows=[]
for s in scripts:
 r=subprocess.run([sys.executable,str(ROOT/'source/PASS108'/s)],cwd=ROOT,capture_output=True,text=True)
 rows.append({'script':s,'returncode':r.returncode,'stdout_tail':r.stdout[-6000:],'stderr_tail':r.stderr[-2000:]})
out={'schema':'DELTA_CDM_PASS108_SELFTEST_SUMMARY_V1','tests':rows,'passed':all(r['returncode']==0 for r in rows),'truth_credit':0}
(OUT/'PASS108_SELFTEST_SUMMARY.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['passed'] else 1)
