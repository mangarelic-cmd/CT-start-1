#!/usr/bin/env python3
"""PASS108: second-order static-QS metric projector for the canonical PASS041 Jordan branch.

The module derives the quadratic Hamiltonian, scalar-traceless metric and scalar-field
sources directly from

    S = ∫sqrt(-g)[F(phi) R/2 - (∂phi)^2/2 - U(phi)] + S_m

on a static Newtonian-gauge slice

    ds^2 = -(1+2A)dt^2 + (1-2psi) delta_ij dx^i dx^j.

It is deliberately scoped to the continuum static/quasi-static slice.  It does NOT promote
the result to the evolving-FLRW ReACT gamma2 and does NOT choose a finite-lattice
traceless-Hessian stencil.  Those are explicit remaining lifts.

M_P=1 representative units.  Matter enters through delta-rho.  At a stationary local
background U_phi=0, the exact static equations used for the independent residual test are

  F R3/2 = delta-rho + (D phi)^2/2 + U + D^2 F,
  [F(R3_ij - N^-1 D_i D_j N) - phi_i phi_j - D_i D_j F]^TF = 0,
  Box phi - U_phi + F_phi R4/2 = 0.

The linear operator reproduces PASS100's canonical-Ricci local-QS mu exactly.
"""
from __future__ import annotations
from dataclasses import dataclass, asdict
from pathlib import Path
import importlib.util, sys, math, json
import numpy as np

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'receipts'/'PASS108'; OUT.mkdir(parents=True,exist_ok=True)

def _load(name,path):
    s=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(s)
    sys.modules[name]=m; s.loader.exec_module(m); return m
jetmod=_load('pass107_jet_pass108',ROOT/'source/PASS107/pass041_nonlinear_action_jet_compiler.py')
bgmod=_load('pass096_bg_pass108',ROOT/'source/PASS096/source_native_background_compiler_v2.py')

@dataclass(frozen=True)
class LocalJet:
    F: float
    F1: float
    F2: float
    U2: float
    U3: float
    def validate(self):
        vals=(self.F,self.F1,self.F2,self.U2,self.U3)
        if not all(math.isfinite(float(x)) for x in vals): raise ValueError('nonfinite local jet')
        if self.F<=0: raise ValueError('F must be positive')


def linear_response(k2:float,j:LocalJet,delta_rho:float=1.0):
    """Solve the exact static-QS linear 00/slip/scalar constraints.

    Unknown order is [A, psi, chi].  The equations are
      -2F k2 psi + F1 k2 chi = delta_rho,
       F(psi-A) - F1 chi = 0,
       F1 k2 A - 2F1 k2 psi - (k2+U2)chi = 0.
    """
    j.validate(); k2=float(k2)
    if not (math.isfinite(k2) and k2>0): raise ValueError('k2 must be positive')
    M=np.array([[0.,-2*j.F*k2,j.F1*k2],[-j.F,j.F,-j.F1],[j.F1*k2,-2*j.F1*k2,-(k2+j.U2)]],float)
    x=np.linalg.solve(M,np.array([float(delta_rho),0.,0.]))
    return {'A':float(x[0]),'psi':float(x[1]),'chi':float(x[2])}

def pass100_mu(k2:float,j:LocalJet):
    K=1+3*j.F1*j.F1/(2*j.F)
    m2=j.U2/K
    sinf=j.F1*j.F1/(2*j.F+3*j.F1*j.F1)
    return (1/j.F)*(1+sinf*k2/(k2+m2))

def _scalarize_tf(T,k):
    k=np.asarray(k,float); k2=float(k@k)
    P=np.outer(k,k)/k2-np.eye(3)/3
    return float(np.real_if_close(-3*np.sum(P*T)/(2*k2)))

def _hess_product(fp,fq,gp,gq,k):
    c=fp*gq+fq*gp; k=np.asarray(k,float)
    return -np.outer(k,k)*c

def _grad_outer(fp,fq,gp,gq,p,q):
    p=np.asarray(p,float); q=np.asarray(q,float)
    return -(np.outer(p,q)*fp*gq+np.outer(q,p)*fq*gp)

def quadratic_sources(p,q,xp,xq,j:LocalJet):
    """Quadratic source at output k=p+q from first-order p and q modes.

    Returns the source added to the same linear [00, scalar-TF, scalar] operator.
    The product convention includes both p,q and q,p orderings for distinct modes.
    """
    j.validate(); p=np.asarray(p,float); q=np.asarray(q,float); k=p+q
    p2=float(p@p); q2=float(q@q); k2=float(k@k); pd=float(p@q)
    if k2<=0: raise ValueError('zero output mode excluded')
    Ap,Pp,Cp=xp['A'],xp['psi'],xp['chi']; Aq,Pq,Cq=xq['A'],xq['psi'],xq['chi']
    F,f1,f2,U2,U3=j.F,j.F1,j.F2,j.U2,j.U3
    # Hamiltonian source from exact static constraint.
    H=(-8*F*(p2+q2)*Pp*Pq-6*F*pd*Pp*Pq
       -2*f1*(q2*Cp*Pq+p2*Cq*Pp)+f2*k2*Cp*Cq
       -f1*pd*(Pp*Cq+Pq*Cp)+2*f1*(q2*Pp*Cq+p2*Pq*Cp)
       +pd*Cp*Cq-U2*Cp*Cq)
    # Scalar projection of the traceless ij constraint.
    T=np.zeros((3,3),float)
    T += F*(_hess_product(Pp,Pq,Pp,Pq,k)+_grad_outer(Pp,Pq,Pp,Pq,p,q)
            +_hess_product(Ap,Aq,Ap,Aq,k)-_grad_outer(Ap,Aq,Ap,Aq,p,q)
            -(_grad_outer(Ap,Aq,Pp,Pq,p,q)+_grad_outer(Pp,Pq,Ap,Aq,p,q)))
    # F1 chi (psi-A)_ij: Hessian acts only on (psi-A), not on the full product.
    T += f1*(-np.outer(q,q)*Cp*(Pq-Aq)-np.outer(p,p)*Cq*(Pp-Ap))
    T -= _grad_outer(Cp,Cq,Cp,Cq,p,q)
    T -= 0.5*f2*_hess_product(Cp,Cq,Cp,Cq,k)
    T -= f1*(_grad_outer(Pp,Pq,Cp,Cq,p,q)+_grad_outer(Cp,Cq,Pp,Pq,p,q))
    slip=_scalarize_tf(T,k)
    # Four-dimensional Ricci scalar quadratic source on the static slice.
    R42=(-16*(p2+q2)*Pp*Pq-12*pd*Pp*Pq-4*k2*Ap*Aq+4*pd*Ap*Aq
         -2*pd*(Pp*Aq+Pq*Ap)+4*(q2*Pp*Aq+p2*Pq*Ap))
    R41p=-4*p2*Pp+2*p2*Ap
    R41q=-4*q2*Pq+2*q2*Aq
    scalar=(-2*(q2*Pp*Cq+p2*Pq*Cp)
            -pd*((Ap-Pp)*Cq+(Aq-Pq)*Cp)-U3*Cp*Cq
            +0.5*f1*R42+0.5*f2*(Cp*R41q+Cq*R41p))
    return {'hamiltonian':float(H),'slip_scalar':float(slip),'scalar':float(scalar)}

def second_order_response(p,q,j:LocalJet,delta_rho_p=1.0,delta_rho_q=1.0):
    p=np.asarray(p,float);q=np.asarray(q,float);k=p+q;k2=float(k@k)
    xp=linear_response(float(p@p),j,delta_rho_p); xq=linear_response(float(q@q),j,delta_rho_q)
    src=quadratic_sources(p,q,xp,xq,j)
    M=np.array([[0.,-2*j.F*k2,j.F1*k2],[-j.F,j.F,-j.F1],[j.F1*k2,-2*j.F1*k2,-(k2+j.U2)]],float)
    rhs=-np.array([src['hamiltonian'],src['slip_scalar'],src['scalar']],float)
    x2=np.linalg.solve(M,rhs)
    return {'p':p.tolist(),'q':q.tolist(),'k':k.tolist(),'first_p':xp,'first_q':xq,
            'second':{'A':float(x2[0]),'psi':float(x2[1]),'chi':float(x2[2])},'sources':src}

def modified_force_pair_kernel(p,q,j:LocalJet):
    """GR-subtracted quadratic force coefficient on the local static-QS slice.

    Convention: delta-rho_p=delta-rho_q=1 and total perturbation is epsilon(ep+eq).
    The output coefficient at p+q is expanded as A=epsilon A1+epsilon^2 A2+...
    We report
        DeltaK2 = -|p+q|^2 [A2_CT-A2_GR]
    and the ordered-pair symmetric coefficient DeltaK2/2.

    This is an operational modified-force pair kernel, NOT yet the cosmological ReACT
    gamma2: density/Hubble normalization, evolving-FLRW lift and finite-torus tensor
    discretization remain explicit gates.
    """
    ct=second_order_response(p,q,j)
    grj=LocalJet(F=j.F,F1=0.,F2=0.,U2=j.U2,U3=0.)
    gr=second_order_response(p,q,grj)
    k=np.asarray(p,float)+np.asarray(q,float);k2=float(k@k)
    dA=ct['second']['A']-gr['second']['A']
    return {'delta_A2_CT_minus_GR':float(dA),'DeltaK2_force':float(-k2*dA),
            'symmetric_ordered_pair_coefficient':float(-0.5*k2*dA),'ct':ct,'gr_reference':gr}

# ---------- independent exact static-residual validation ----------
def _mode(n,N):
    idx=np.indices((N,N,N)); phase=np.zeros((N,N,N),float)
    for ax,nn in enumerate(n): phase += 2*np.pi*int(nn)*idx[ax]/N
    return np.exp(1j*phase)
def _D(f,axis):
    N=f.shape[axis]; kval=2*np.pi*np.fft.fftfreq(N,d=2*np.pi/N)
    shape=[1]*f.ndim;shape[axis]=N
    return np.fft.ifft(np.fft.fft(f,axis=axis)*(1j*kval.reshape(shape)),axis=axis)
def _grad(f): return [_D(f,i) for i in range(3)]
def _hess(f): return [[_D(_D(f,i),j) for j in range(3)] for i in range(3)]
def _lap(f): return sum(_D(_D(f,i),i) for i in range(3))
def _dot(a,b): return sum(x*y for x,y in zip(a,b))
def _coeff(f,n): return np.mean(f*np.conj(_mode(n,f.shape[0])))

def exact_static_residual(A,psi,chi,drho,j:LocalJet):
    Nl=np.sqrt(1+2*A); n=np.log(Nl); c=1-2*psi; zeta=.5*np.log(c); em2z=1/c
    F=j.F+j.F1*chi+.5*j.F2*chi**2
    Fphi=j.F1+j.F2*chi
    U=.5*j.U2*chi**2+(j.U3/6)*chi**3
    Uphi=j.U2*chi+.5*j.U3*chi**2
    gz,gn,gF,gc=_grad(zeta),_grad(n),_grad(F),_grad(chi)
    hz,hn,hF=_hess(zeta),_hess(n),_hess(F)
    lz,ln,lF,lc=_lap(zeta),_lap(n),_lap(F),_lap(chi)
    gz2,gn2,gzgn=_dot(gz,gz),_dot(gn,gn),_dot(gz,gn)
    R3=em2z*(-4*lz-2*gz2)
    D2F=em2z*(lF+_dot(gz,gF)); gradchi2=em2z*_dot(gc,gc)
    H=F*.5*R3-D2F-.5*gradchi2-U-drho
    shape=A.shape; E=np.empty((3,3)+shape,dtype=complex)
    Rij=np.empty_like(E); Nij=np.empty_like(E); DFij=np.empty_like(E)
    zF=_dot(gz,gF)
    for a in range(3):
      for b in range(3):
        dij=1. if a==b else 0.
        Rij[a,b]=-hz[a][b]-dij*lz+gz[a]*gz[b]-dij*gz2
        Nij[a,b]=hn[a][b]+gn[a]*gn[b]-gz[b]*gn[a]-gz[a]*gn[b]+dij*gzgn
        DFij[a,b]=hF[a][b]-gz[b]*gF[a]-gz[a]*gF[b]+dij*zF
        E[a,b]=F*(Rij[a,b]-Nij[a,b])-gc[a]*gc[b]-DFij[a,b]
    tr=sum(E[a,a] for a in range(3))/3
    for a in range(3): E[a,a]-=tr
    D2phi=em2z*(lc+_dot(gz,gc)); DnDphi=em2z*_dot(gn,gc)
    Nlap=em2z*(ln+gn2+gzgn); R4=R3-2*Nlap
    scalar=D2phi+DnDphi-Uphi+.5*Fphi*R4
    return H,E,scalar

def exact_source_validation(j:LocalJet,p=(1,2,0),q=(2,-1,1),N=24,eps=1e-3):
    p=np.asarray(p,int);q=np.asarray(q,int);k=p+q
    xp=linear_response(float(p@p),j);xq=linear_response(float(q@q),j)
    ep,eq=_mode(p,N),_mode(q,N)
    A1=xp['A']*ep+xq['A']*eq; P1=xp['psi']*ep+xq['psi']*eq; C1=xp['chi']*ep+xq['chi']*eq; D1=ep+eq
    vals=[]
    for sign in (1.,-1.):
        H,E,S=exact_static_residual(sign*eps*A1,sign*eps*P1,sign*eps*C1,sign*eps*D1,j)
        Hk=_coeff(H,k); Tk=np.zeros((3,3),complex)
        for a in range(3):
          for b in range(3): Tk[a,b]=_coeff(E[a,b],k)
        Sk=_scalarize_tf(Tk,k); Phik=_coeff(S,k)
        vals.append((Hk,Sk,Phik))
    c2=np.array([(vals[0][i]+vals[1][i])/(2*eps**2) for i in range(3)],complex)
    src=quadratic_sources(p,q,xp,xq,j)
    pred=np.array([src['hamiltonian'],src['slip_scalar'],src['scalar']],complex)
    err=np.abs(c2-pred)
    return {'exact_extracted':[float(np.real(x)) for x in c2], 'formula':[float(np.real(x)) for x in pred],
            'absolute_errors':[float(x) for x in err], 'max_absolute_error':float(np.max(err))}

def _barrier_jet():
    p=bgmod.BackgroundParameters(V0=2,Vc=1,i_t=1.5,lam=1.4,y_c=0,y_delta=1,beta_shape=.45,
                                 sigma_y=.3,B_g=-.02,F_c=1.05,phi0_over_Mp=.8,rho_pi_bar=.7)
    m=bgmod.Model(p); yb=p.y_c+p.beta_shape*(p.y_delta-p.y_c); a=jetmod.action_jet(m,yb)
    return LocalJet(F=a['F0'],F1=a['F1'],F2=a['F2'],U2=a['U2'],U3=a['U3']),a

def selftest():
    j=LocalJet(1.2,.3,.07,.8,-.4)
    lin=[]
    for k2 in (2.3,10.,41.):
        x=linear_response(k2,j); mu=-2*k2*x['A']
        lin.append({'k2':k2,'mu_solver':mu,'mu_PASS100_formula':pass100_mu(k2,j),'abs_error':abs(mu-pass100_mu(k2,j))})
    val=exact_source_validation(j)
    p=np.array([1.,2.,0.]);q=np.array([2.,-1.,1.])
    pair=modified_force_pair_kernel(p,q,j)
    rootj=LocalJet(1.2,0.,.07,.8,-.4); rootpair=modified_force_pair_kernel(p,q,rootj)
    perm=modified_force_pair_kernel(q,p,j)
    bj,raw=_barrier_jet(); barrier=modified_force_pair_kernel(p,q,bj)
    checks={
      'linear_mu_matches_PASS100':max(r['abs_error'] for r in lin)<3e-14,
      'quadratic_sources_match_independent_exact_covariant_residual':val['max_absolute_error']<5e-9,
      'pair_kernel_permutation_symmetric':abs(pair['DeltaK2_force']-perm['DeltaK2_force'])<1e-12,
      'strict_root_Fphi_zero_has_no_MG_quadratic_force':abs(rootpair['DeltaK2_force'])<1e-13,
      'offroot_witness_nonzero':abs(pair['DeltaK2_force'])>1e-5,
      'PASS041_barrier_is_stationary_Uphi':abs(raw['U1'])<1e-14,
      'PASS041_barrier_local_pair_compiles':math.isfinite(barrier['DeltaK2_force']),
    }
    out={'schema':'DELTA_CDM_PASS108_SECOND_ORDER_STATIC_QS_METRIC_PROJECTOR_V1','scope':'continuum static-QS stationary local slice',
      'checks':checks,'linear_tests':lin,'independent_quadratic_source_validation':val,
      'generic_offroot_pair':{'p':p.tolist(),'q':q.tolist(),'DeltaK2_force':pair['DeltaK2_force'],'symmetric_pair':pair['symmetric_ordered_pair_coefficient']},
      'strict_root_pair':{'DeltaK2_force':rootpair['DeltaK2_force']},
      'PASS041_barrier_witness':{'jet':asdict(bj),'DeltaK2_force':barrier['DeltaK2_force'],'symmetric_pair':barrier['symmetric_ordered_pair_coefficient']},
      'closed_object':'CONTINUUM_STATIC_QS_SECOND_ORDER_CANONICAL_RICCI_METRIC_FORCE_PROJECTOR',
      'not_claimed':['EVOLVING_FLRW_SECOND_ORDER_0I_TIME_LIFT','FINITE_TORUS_TRACELESS_HESSIAN_DISCRETIZATION','REACT_GAMMA2_PHYSICAL_NORMALIZATION'],
      'truth_credit':0,'physical_gamma2_claimed':False,'passed':all(checks.values())}
    (OUT/'PASS108_SECOND_ORDER_STATIC_QS_METRIC_PROJECTOR.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2));return out

if __name__=='__main__':
    r=selftest(); raise SystemExit(0 if r['passed'] else 1)
