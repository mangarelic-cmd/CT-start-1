#!/usr/bin/env python3
from pathlib import Path
import sys,json,collections,argparse
ROOT=Path(__file__).resolve().parents[2]
ACROOT=ROOT/'runtime'/'AC77'/'SC_SOLVER_AC77_PERIODIC_CARTESIAN_THEOREM_METROLOGY_CORE_20260922'
sys.path.insert(0,str(ACROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver
BASE=[
 'FINITE_DISCRETE_TORUS_E1','Q_LAMBDA_FIREWALL_CERTIFICATE','PASS041_COMPLETED_ACTION_FAMILY',
 'PASS041_ACTION_DERIVATIVES_TO_QUARTIC_ORDER','FINITE_TORUS_RAW_SCALAR_QUADRATIC_CUBIC_VERTEX_COMPILER',
 'SPHERICAL_COLLAPSE_KINEMATIC_REDUCTION','NONLINEAR_METRIC_PROJECTION_FIREWALL',
 'CANONICAL_RICCI_EVOLVING_GAUGE_REDUCED_LINEAR_MODE_SOLVER','FINITE_TORUS_VARIATIONAL_METRIC_STENCIL_CONTRACT',
 'REACT_NONLINEAR_POISSON_QS_SCOPE_CONTRACT','CANONICAL_RICCI_FIXED_BACKGROUND_QS_CURVATURE_LIFT',
 'REACT_GAMMA2_NORMALIZATION_CONTRACT','CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA2_COMPILER',
 'PASS109_MINIMAL_VARIATIONAL_CUBIC_METRIC_PROJECTION_CANDIDATE','REACT_GAMMA3_NORMALIZATION_CONTRACT',
 'FINITE_TORUS_CUBIC_STENCIL_NONUNIQUENESS_WITNESS','PASS109_LINEAR_CONSTRAINT_VARIATIONAL_SYMMETRIZATION',
 'FINITE_TORUS_ACTION_LEVEL_CUBIC_NONUNIQUENESS_CERTIFICATE'
]
def seed(pid,statement,target,requires=(),supplies=(),**kw):
 p=dict(problem_id=pid,statement=statement,target=target,requires=list(requires),supplies=BASE+list(supplies),ground_binding=True);p.update(kw);return Node('PROBLEM',p,context=('DELTA_CDM_PASS111',pid))
OWNER='PASS041_TO_FINITE_TORUS_FULL_NONLINEAR_DISCRETE_ACTION_COMPLETION_RULE_OR_GAMMA3_REGULATOR_INDEPENDENCE_THEOREM'
seeds=[
 seed('P111_ACTION_VARIATIONALITY','Verify the PASS109 linear constraint matrix is the Hessian of a row-normalized reduced variational system and construct an explicit quartic finite-torus action counterterm that leaves every linear/quadratic equation unchanged but shifts cubic gamma3.','FINITE_TORUS_ACTION_LEVEL_CUBIC_NONUNIQUENESS_CERTIFICATE',(),('PASS109_LINEAR_CONSTRAINT_VARIATIONAL_SYMMETRIZATION','FINITE_TORUS_ACTION_LEVEL_CUBIC_NONUNIQUENESS_CERTIFICATE'),proof_object={'type':'constructive_action_level_nonuniqueness','receipt':'receipts/PASS111/PASS111_FINITE_TORUS_ACTION_LEVEL_CUBIC_NONUNIQUENESS.json'},uniformity_verified=True,boundaries={'physical_gamma3_not_promoted':True,'q_lambda_firewall':True}),
 seed('P111_GAMMA3','Promote a unique finite-torus ReACT-QS gamma3 only after the continuum PASS041 action is supplied with a full nonlinear discrete-action completion rule, or after gamma3 is proved independent of all admissible finite-grid completions.','CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA3_COMPILER',(OWNER,),(),boundaries={'no_hidden_irrelevant_lattice_operator':True,'lower_order_action_matching_insufficient':True}),
 seed('P111_COLLAPSE','Derive the nonperturbative spherical force only after physical gamma3 is fixed by the full discrete-action contract.','CANONICAL_RICCI_SPHERICAL_COLLAPSE_FORCE_TRAJECTORY_COMPILER',('CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA3_COMPILER','ACTION_DERIVED_NONPERTURBATIVE_SPHERICAL_FORCE_LAW'),(),boundaries={'gamma2_gamma3_not_assumed_sufficient_for_full_collapse':True}),
 seed('P111_NONLINEAR','Close the nonlinear reaction packet only after gamma3, collapse and virial ingredients are physical rather than regulator-selected.','CT_NONLINEAR_HIGHER_ORDER_POISSON_AND_COLLAPSE_COMPILER',('CANONICAL_RICCI_SPHERICAL_COLLAPSE_FORCE_TRAJECTORY_COMPILER','CANONICAL_RICCI_VIRIAL_REACTION_INGREDIENT_COMPILER'),(),boundaries={'no_phenomenological_delta_nl':True}),
]
world={'project':'DELTA_CDM_PASS111','available_evidence_tokens':BASE,'external_scientific_truth_certified':False,'finite_discrete_torus':True,'action_level_cubic_nonuniqueness_closed':True,'full_nonlinear_discrete_action_completion_rule_closed':False,'react_qs_gamma3_compiler_closed':False,'physical_spherical_collapse_closed':False,'virial_reaction_closed':False,'physical_forward33_closed':False,'physical_rank_closed':False,'physical_mhat2_closed':False}
def run(recursive=False):
 s=SovereignSolver();r=s.solve_universal(seeds,world=world,max_waves=2 if recursive else 1,max_calls=32000 if recursive else 15000,stable_waves=1)
 known=list(s.engine.known.values());counts=r.get('mechanism_execution_counts') or {};by={p.payload['problem_id']:collections.Counter() for p in seeds};front=[]
 for n in known:
  if len(n.context)>=2 and n.context[0]=='DELTA_CDM_PASS111':
   pid=n.context[1]
   if pid in by:by[pid][str(n.payload.get('status') or n.kind)]+=1
   st=str(n.payload.get('status') or '')
   if st in {'NEED_DATA','WAITING','OPEN','INVALID','PARTIAL','MISSING_CARRIER'} and n.kind not in {'AUX_OBSERVATION','MECHANISM_OBSERVATION'}:
    front.append({'problem_id':pid,'kind':n.kind,'status':st,'requires':n.payload.get('requires'),'unresolved_requirements':n.payload.get('unresolved_requirements'),'mechanism':n.payload.get('mechanism'),'statement':n.payload.get('statement')})
 out={'schema':'DELTA_CDM_PASS111_AC77_AUDIT_V1','mode':'recursive' if recursive else 'direct','solver_version':r.get('version'),'run_state':r.get('run_state'),'active_mechanism_count':r.get('active_mechanism_count'),'mechanisms_touched':sum(1 for v in counts.values() if v),'execution_calls':r.get('execution_calls'),'known_node_count':r.get('known_node_count'),'open_residual_count':r.get('open_residual_count'),'periodic_cartesian_receipt_count':r.get('periodic_cartesian_receipt_count'),'solution_certified':r.get('solution_certified'),'formal_proof_verified':r.get('formal_proof_verified'),'problem_status_counters':{k:dict(v) for k,v in by.items()},'declared_seed_requirements':{p.payload['problem_id']:p.payload.get('requires',[]) for p in seeds},'frontier_nonpass_count':len(front),'frontier_nonpass':front,'mechanism_execution_counts':counts}
 name='AC77_PASS111_RECURSIVE_AUDIT.json' if recursive else 'AC77_PASS111_DIRECT_AUDIT.json';(ROOT/'receipts/PASS111'/name).write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');(ROOT/'receipts/PASS111/PASS111_SEED_REGISTRY.json').write_text(json.dumps([n.to_dict() for n in seeds],indent=2,ensure_ascii=False)+'\n');return out
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--recursive',action='store_true');a=ap.parse_args();o=run(a.recursive);print(json.dumps({k:o[k] for k in ['mode','solver_version','run_state','active_mechanism_count','mechanisms_touched','execution_calls','known_node_count','open_residual_count','solution_certified','formal_proof_verified','declared_seed_requirements']},indent=2))
