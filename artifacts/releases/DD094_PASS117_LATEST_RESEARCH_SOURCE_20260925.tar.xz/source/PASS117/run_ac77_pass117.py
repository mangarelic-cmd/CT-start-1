#!/usr/bin/env python3
from pathlib import Path
import sys,json,collections,argparse
ROOT=Path(__file__).resolve().parents[2]
ACROOT=ROOT/'runtime'/'AC77'/'SC_SOLVER_AC77_PERIODIC_CARTESIAN_THEOREM_METROLOGY_CORE_20260922'
sys.path.insert(0,str(ACROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver

BASE=[
 'FINITE_DISCRETE_TORUS_E1','Q_LAMBDA_FIREWALL_CERTIFICATE','PASS041_COMPLETED_ACTION_FAMILY',
 'CANONICAL_RICCI_EVOLVING_GAUGE_REDUCED_LINEAR_MODE_SOLVER','CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA2_COMPILER',
 'CANONICAL_RICCI_FINITE_TORUS_REACT_QS_GAMMA3_COMPILER','ACTION_DERIVED_NONPERTURBATIVE_SPHERICAL_FORCE_LAW',
 'ACTION_DERIVED_SPHERICAL_COLLAPSE_TRAJECTORY_EXECUTION','CANONICAL_RICCI_VIRIAL_REACTION_INGREDIENT_COMPILER',
 'TARGET_COLLAPSE_DELTA_C_DELTA_VIR_MASS_REDSHIFT_COMPILER','MAPAR_STANDARD_GR_BASELINE_EVALUATOR_CONTRACT',
 'NONLINEAR_REACTION_EXACT_FACTORIZATION','CARRIER_FAMILY_PROFILE_PROTOCOL',
 'REACT_REAL_PSEUDO_ONE_HALO_COMPILER','REACT_E_PARAMETER_COMPILER','REACT_MASSLESS_REACTION_ALGEBRA_COMPILER',
 'REACT_KSTAR_MATCHING_ALGEBRA_CONTRACT'
]

def seed(pid,statement,target,requires=(),supplies=(),**kw):
 p=dict(problem_id=pid,statement=statement,target=target,requires=list(requires),supplies=BASE+list(supplies),ground_binding=True);p.update(kw);return Node('PROBLEM',p,context=('DELTA_CDM_PASS117',pid))

ONELOOP='CANONICAL_RICCI_REACT_ONE_LOOP_SPT_REAL_PSEUDO_COMPILER'
REACTION='REACT_HALO_REACTION_ASSEMBLY_WITH_STANDARD_PSEUDO_BASELINE'
COMPRESSION='FINITE_TORUS_TO_ISOTROPIC_PK_COMPRESSION_CERTIFICATE'
seeds=[
 seed('P117_HALO',
      'Compile ReACT real/pseudo one-halo terms, Sheth-Tormen abundance, NFW profiles, E parameter and the massless-neutrino reaction algebra from delta_c(M,z), Delta_vir(M,z), standard linear power and background mass density.',
      'REACT_REAL_PSEUDO_ONE_HALO_COMPILER',(),
      ('REACT_REAL_PSEUDO_ONE_HALO_COMPILER','REACT_E_PARAMETER_COMPILER','REACT_MASSLESS_REACTION_ALGEBRA_COMPILER','REACT_KSTAR_MATCHING_ALGEBRA_CONTRACT'),
      proof_object={'type':'react_halo_reaction_assembly','receipt':'receipts/PASS117/PASS117_REACT_HALO_REACTION_ASSEMBLY.json'},
      uniformity_verified=True,
      boundaries={'truth_credit_zero_manufactured_test':True,'no_free_Delta_NL':True,'kstar_not_invented':True}),
 seed('P117_ONELOOP',
      'Compile the physical real and pseudo one-loop SPT spectra at the ReACT matching scale from the closed PASS102 linear response and action-derived gamma2/gamma3 kernels, preserving the finite-torus q/lambda firewall until the declared continuum reaction interface.',
      ONELOOP,(ONELOOP,),(),
      boundaries={'gamma2_closed':True,'gamma3_closed':True,'loop_integration_not_yet_materialized':True}),
 seed('P117_REACTION',
      'Close the physical ReACT halo reaction only after the one-loop SPT matching compiler fixes kstar; all one-halo and E pieces are already compiled in PASS117.',
      REACTION,(ONELOOP,REACTION),(),
      boundaries={'halo_assembly_compiled':True,'standard_pseudo_baseline_contract_present':True,'no_free_Delta_NL_field':True}),
 seed('P117_COMPRESSION',
      'After physical nonlinear reaction closure, compress exact finite-torus power into the isotropic P(k,z) packet required by the MaPar continuum projection without substituting q^2 for lambda.',
      COMPRESSION,(REACTION,COMPRESSION),(),
      boundaries={'q_lambda_firewall':True,'reaction_must_precede_physical_compression':True}),
]
world={
 'project':'DELTA_CDM_PASS117','available_evidence_tokens':BASE,'external_scientific_truth_certified':False,
 'finite_discrete_torus':True,'target_collapse_compiler_closed':True,'virial_closed':True,
 'react_one_halo_compiler_closed':True,'react_E_compiler_closed':True,'react_kstar_algebra_closed':True,
 'one_loop_spt_real_pseudo_compiler_closed':False,'nonlinear_reaction_closed':False,
 'finite_torus_isotropic_pk_compression_certificate_present':False,
 'physical_forward33_closed':False,'physical_rank_closed':False,'physical_mhat2_closed':False,
}

def run(recursive=False):
 s=SovereignSolver();r=s.solve_universal(seeds,world=world,max_waves=2 if recursive else 1,max_calls=32000 if recursive else 15000,stable_waves=1)
 known=list(s.engine.known.values());counts=r.get('mechanism_execution_counts') or {};by={p.payload['problem_id']:collections.Counter() for p in seeds};front=[]
 for n in known:
  if len(n.context)>=2 and n.context[0]=='DELTA_CDM_PASS117':
   pid=n.context[1]
   if pid in by:by[pid][str(n.payload.get('status') or n.kind)]+=1
   st=str(n.payload.get('status') or '')
   if st in {'NEED_DATA','WAITING','OPEN','INVALID','PARTIAL','MISSING_CARRIER'} and n.kind not in {'AUX_OBSERVATION','MECHANISM_OBSERVATION'}:
    front.append({'problem_id':pid,'kind':n.kind,'status':st,'requires':n.payload.get('requires'),'unresolved_requirements':n.payload.get('unresolved_requirements'),'mechanism':n.payload.get('mechanism'),'statement':n.payload.get('statement')})
 out={'schema':'DELTA_CDM_PASS117_AC77_AUDIT_V1','mode':'recursive' if recursive else 'direct','solver_version':r.get('version'),'run_state':r.get('run_state'),'active_mechanism_count':r.get('active_mechanism_count'),'mechanisms_touched':sum(1 for v in counts.values() if v),'execution_calls':r.get('execution_calls'),'known_node_count':r.get('known_node_count'),'open_residual_count':r.get('open_residual_count'),'periodic_cartesian_receipt_count':r.get('periodic_cartesian_receipt_count'),'solution_certified':r.get('solution_certified'),'formal_proof_verified':r.get('formal_proof_verified'),'problem_status_counters':{k:dict(v) for k,v in by.items()},'declared_seed_requirements':{p.payload['problem_id']:p.payload.get('requires',[]) for p in seeds},'frontier_nonpass_count':len(front),'frontier_nonpass':front,'mechanism_execution_counts':counts}
 name='AC77_PASS117_RECURSIVE_AUDIT.json' if recursive else 'AC77_PASS117_DIRECT_AUDIT.json'
 (ROOT/'receipts/PASS117'/name).write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n')
 (ROOT/'receipts/PASS117/PASS117_SEED_REGISTRY.json').write_text(json.dumps([n.to_dict() for n in seeds],indent=2,ensure_ascii=False)+'\n')
 return out

if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--recursive',action='store_true');a=ap.parse_args();o=run(a.recursive)
 print(json.dumps({k:o[k] for k in ['mode','solver_version','run_state','active_mechanism_count','mechanisms_touched','execution_calls','known_node_count','open_residual_count','solution_certified','formal_proof_verified','declared_seed_requirements']},indent=2))
