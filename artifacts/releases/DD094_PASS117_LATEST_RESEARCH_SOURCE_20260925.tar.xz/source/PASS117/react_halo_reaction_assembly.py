#!/usr/bin/env python3
"""PASS117 — ReACT halo-reaction assembly and exact owner reduction.

This pass implements the halo-model pieces of the massless-neutrino ReACT branch
using the conventions source-locked to ACTio-ReACTio commit
`a36dda02db6b537a4ddcc7bf044c446c10a58373`.

It deliberately does NOT invent the real/pseudo 1-loop SPT spectra required to
fix k_star.  Instead it closes:

  delta_c(M,z), Delta_vir(M,z), P_L(k,z)
      -> sigma(M), ST abundance, NFW profile, P_1h_real/pseudo
      -> E = P_1h_real(k_e)/P_1h_pseudo(k_e)
      -> exact ReACT algebra conditional on P_SPT_real/pseudo(k0)

and reduces the remaining physical owner to the one-loop SPT compiler fed by
PASS102 + PASS109 gamma2 + PASS112 gamma3.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import json, math
import numpy as np
from scipy.interpolate import PchipInterpolator
from scipy.special import sici

ROOT = Path(__file__).resolve().parents[2]
OUT = ROOT/'receipts'/'PASS117'; OUT.mkdir(parents=True, exist_ok=True)

SOURCE_LOCK = {
    'repository':'nebblu/ACTio-ReACTio',
    'commit':'a36dda02db6b537a4ddcc7bf044c446c10a58373',
    'HALO_cpp':'https://github.com/nebblu/ACTio-ReACTio/blob/a36dda02db6b537a4ddcc7bf044c446c10a58373/reactions/src/HALO.cpp',
    'HALO_h':'https://github.com/nebblu/ACTio-ReACTio/blob/a36dda02db6b537a4ddcc7bf044c446c10a58373/reactions/src/HALO.h',
    'massless_neutrino_reaction':'R=[((1-E)exp(-k/kstar)+E) P_L_real + P_1h_real]/[P_L_pseudo+P_1h_pseudo]',
    'E_scale_hMpc':0.01,
    'kstar_match_scale_hMpc':0.06,
    'react_mass_log10_range':[5.0,20.0],
}

# ReACT / Sheth-Tormen constants mirrored from HALO.cpp.
ST_Q=0.75
ST_P=0.3
ST_A=1.0/3.056/1.012
C0=9.0
C_ALPHA=0.13
K_E=0.01
K0=0.06


def top_hat_W(x):
    x=np.asarray(x,float)
    out=np.ones_like(x)
    m=np.abs(x)>1e-6
    xm=x[m]
    out[m]=3.0*(np.sin(xm)-xm*np.cos(xm))/xm**3
    if np.any(~m):
        xx=x[~m]
        out[~m]=1.0-xx*xx/10.0+xx**4/280.0
    return out


def sigma_of_R(k, pk, R):
    k=np.asarray(k,float); pk=np.asarray(pk,float)
    if np.any(k<=0) or np.any(pk<0): raise ValueError('k>0 and P>=0 required')
    order=np.argsort(k); k=k[order]; pk=pk[order]
    W=top_hat_W(k*float(R))
    integ=k**3*pk*W**2/(2.0*np.pi**2)
    return math.sqrt(max(0.0,float(np.trapezoid(integ,x=np.log(k)))))


def lagrangian_radius(M,rho_bar):
    M=np.asarray(M,float)
    return (3.0*M/(4.0*np.pi*float(rho_bar)))**(1.0/3.0)


def nfw_u(k, Rvir, c):
    k=np.asarray(k,float)
    Rvir=float(Rvir); c=float(c)
    if Rvir<=0 or c<=0: raise ValueError('Rvir,c must be positive')
    rs=Rvir/c
    x=k*rs
    norm=math.log1p(c)-c/(1.0+c)
    out=np.ones_like(x)
    m=np.abs(x)>1e-9
    xm=x[m]
    si1,ci1=sici((1.0+c)*xm); si0,ci0=sici(xm)
    out[m]=(np.sin(xm)*(si1-si0) - np.sin(c*xm)/((1.0+c)*xm) + np.cos(xm)*(ci1-ci0))/norm
    return out


@dataclass
class HaloTable:
    mass: np.ndarray
    delta_c: np.ndarray
    Delta_vir: np.ndarray
    sigma: np.ndarray
    rho_bar: float
    a: float
    g_de: float=1.0

    def __post_init__(self):
        self.mass=np.asarray(self.mass,float); self.delta_c=np.asarray(self.delta_c,float)
        self.Delta_vir=np.asarray(self.Delta_vir,float); self.sigma=np.asarray(self.sigma,float)
        n=len(self.mass)
        if not all(len(x)==n for x in (self.delta_c,self.Delta_vir,self.sigma)): raise ValueError('table length mismatch')
        if n<8 or np.any(np.diff(self.mass)<=0) or np.any(self.sigma<=0) or np.any(self.Delta_vir<=0): raise ValueError('invalid halo table')
        self.lnM=np.log(self.mass)
        self.nu=self.delta_c/self.sigma
        self.dnu_dlnM=np.gradient(self.nu,self.lnM,edge_order=2)
        # ReACT ST number density per d ln M.
        v2=self.nu**2
        vf=ST_A*np.sqrt(2.0/np.pi*ST_Q*v2)*(1.0+(ST_Q*v2)**(-ST_P))*np.exp(-ST_Q*v2/2.0)
        self.dn_dlnM=(float(self.rho_bar)/self.mass)*vf/self.nu*self.dnu_dlnM
        # Numerical finite-grid protection only; negative values signal a bad table.
        if np.min(self.dn_dlnM)<-1e-12*np.max(np.abs(self.dn_dlnM)):
            raise ValueError('non-monotone nu gives materially negative halo abundance')
        self.dn_dlnM=np.maximum(self.dn_dlnM,0.0)
        self.Rvir=(3.0*self.mass/(4.0*np.pi*float(self.rho_bar)*self.Delta_vir))**(1.0/3.0)
        self.cvir=self._concentration()

    def _concentration(self):
        # Match ReACT c = g_de * 9 * a * (M/M*)^-0.13.  For mass-dependent
        # delta_c, M* is solved separately for each halo from sigma(M*)=delta_c(M).
        log_sigma=np.log(self.sigma)
        # sigma normally decreases with M; interpolate log M as a function of log sigma.
        ord=np.argsort(log_sigma)
        inv=PchipInterpolator(log_sigma[ord],self.lnM[ord],extrapolate=False)
        out=[]
        lo,hi=float(np.min(log_sigma)),float(np.max(log_sigma))
        for M,dc in zip(self.mass,self.delta_c):
            lsd=math.log(float(dc))
            if lo<=lsd<=hi and np.isfinite(inv(lsd)):
                lmstar=float(inv(lsd))
            else:
                # Same role as ReACT's guarded concentration fallback: keep the
                # compiler finite but expose fallback count in the receipt.
                lmstar=float(self.lnM[0] if lsd>hi else self.lnM[-1])
            out.append(float(self.g_de)*C0*float(self.a)*math.exp(-C_ALPHA*(math.log(float(M))-lmstar)))
        return np.asarray(out,float)

    def one_halo(self,k):
        k=np.atleast_1d(np.asarray(k,float))
        vals=[]
        for kval in k:
            u=np.array([nfw_u(np.array([kval]),rv,c)[0] for rv,c in zip(self.Rvir,self.cvir)])
            integrand=(self.mass/float(self.rho_bar))**2*self.dn_dlnM*u*u
            vals.append(float(np.trapezoid(integrand,x=self.lnM)))
        return np.asarray(vals,float)


def table_from_pk(mass,delta_c,Delta_vir,k,pk,rho_bar,a,g_de=1.0):
    mass=np.asarray(mass,float)
    R=lagrangian_radius(mass,rho_bar)
    sig=np.array([sigma_of_R(k,pk,r) for r in R])
    return HaloTable(mass,delta_c,Delta_vir,sig,float(rho_bar),float(a),float(g_de))


def E_from_one_halo(real: HaloTable,pseudo: HaloTable,k_e=K_E):
    pr=float(real.one_halo([k_e])[0]); pp=float(pseudo.one_halo([k_e])[0])
    if pp<=0: raise ValueError('pseudo one-halo at k_e must be positive')
    return pr/pp,pr,pp


def kstar_from_spt_match(*,P_L_real_k0,P_L_pseudo_k0,P_spt_real_k0,P_spt_pseudo_k0,
                         P1h_real_k0,P1h_pseudo_k0,E,k0=K0):
    """Massless-neutrino reduction of ACTio-ReACTio react_init_nu.

    P_spt_* are the full 1-loop SPT terms BEFORE adding the one-halo term on
    the real side.  The returned match reproduces the source reaction at k0.
    """
    vals=[P_L_real_k0,P_L_pseudo_k0,P_spt_real_k0,P_spt_pseudo_k0,P1h_real_k0,P1h_pseudo_k0]
    if not all(np.isfinite(vals)) or min(vals)<0: raise ValueError('finite nonnegative powers required')
    if abs(1.0-E)<1e-10:
        return {'kstar':1.0,'argument':1.0,'gr_like_fallback':True,'reason':'E approximately 1; kstar is algebraically irrelevant'}
    rspt=(P_spt_real_k0+P1h_real_k0)/(P_spt_pseudo_k0+P1h_pseudo_k0)
    den=(1.0-E)*P_L_real_k0
    arg=((P_L_pseudo_k0+P1h_pseudo_k0)*rspt-(E*P_L_real_k0+P1h_real_k0))/den
    if not (0.001<=arg<=1.0):
        return {'kstar':1.0,'argument':float(arg),'gr_like_fallback':True,'reason':'ACTio-ReACTio source guard argument outside [0.001,1]'}
    ks=-float(k0)/math.log(float(arg))
    pref=((1.0-E)*math.exp(-float(k0)/ks)+E)
    rhm=(pref*P_L_real_k0+P1h_real_k0)/(P_L_pseudo_k0+P1h_pseudo_k0)
    return {'kstar':ks,'argument':float(arg),'gr_like_fallback':False,'rspt_k0':float(rspt),'rhm_k0':float(rhm),'match_abs_residual':abs(float(rhm-rspt))}


def reaction_massless(k,P_L_real,P_L_pseudo,P1h_real,P1h_pseudo,E,kstar):
    k=np.asarray(k,float); P_L_real=np.asarray(P_L_real,float); P_L_pseudo=np.asarray(P_L_pseudo,float)
    P1h_real=np.asarray(P1h_real,float); P1h_pseudo=np.asarray(P1h_pseudo,float)
    pref=(1.0-float(E))*np.exp(-k/float(kstar))+float(E)
    return (pref*P_L_real+P1h_real)/(P_L_pseudo+P1h_pseudo)


def audit():
    # Manufactured standard-sector carrier: no physical truth credit.
    k=np.logspace(-3,1,1200)
    # Smooth, positive spectrum with enough UV falloff for stable sigma integrals.
    PL=2.0e4*(k/0.15)**0.96/(1.0+(k/0.22)**2.4)**1.45*np.exp(-(k/15.0)**2)
    mass=np.logspace(10,15,96)
    rho=8.325e10  # arbitrary internal mass-density unit for this witness
    a=2.0/3.0
    dc_p=np.full_like(mass,1.68647)
    dv_p=np.full_like(mass,178.0)
    # Mild action-derived-like scale dependence for a manufactured real branch.
    x=np.log10(mass/1e12)
    dc_r=dc_p*(1.0+0.018*np.tanh(x/2.0))
    dv_r=dv_p*(1.0+0.055*np.exp(-0.5*(x/1.8)**2))
    pseudo=table_from_pk(mass,dc_p,dv_p,k,PL,rho,a)
    real=table_from_pk(mass,dc_r,dv_r,k,PL,rho,a)

    # GR identity regression: same table on both sides -> one-halo equality, E=1, R=1.
    p1hp=pseudo.one_halo(k)
    Egr,_,_=E_from_one_halo(pseudo,pseudo)
    Rgr=reaction_massless(k,PL,PL,p1hp,p1hp,Egr,1.0)
    grerr=float(np.max(np.abs(Rgr-1.0)))

    p1hr=real.one_halo(k)
    E,pe_r,pe_p=E_from_one_halo(real,pseudo)
    # Interpolate the witness powers at k0.
    def at(arr,kk): return float(np.interp(kk,k,arr))
    pl0=at(PL,K0); r1=at(p1hr,K0); p1=at(p1hp,K0)
    target_kstar=0.18
    target_R0=((1.0-E)*math.exp(-K0/target_kstar)+E)*pl0+r1
    target_R0/=pl0+p1
    Pspt_p=1.035*pl0
    # Construct a consistent real SPT witness so the source matching must recover target_kstar.
    Pspt_r=target_R0*(Pspt_p+p1)-r1
    km=kstar_from_spt_match(P_L_real_k0=pl0,P_L_pseudo_k0=pl0,
                            P_spt_real_k0=Pspt_r,P_spt_pseudo_k0=Pspt_p,
                            P1h_real_k0=r1,P1h_pseudo_k0=p1,E=E,k0=K0)
    R=reaction_massless(k,PL,PL,p1hr,p1hp,E,km['kstar'])
    kstar_err=abs(km['kstar']-target_kstar)
    # Exact nonlinear factorization check against a manufactured pseudo nonlinear baseline.
    Pnl_p=PL*(1.0+0.35*(k/0.7)**2/(1.0+(k/0.7)**2))
    Pnl_ct=R*Pnl_p
    delta_nl=np.log((Pnl_ct/PL)/(Pnl_p/PL))
    recon=Pnl_p*np.exp(delta_nl)
    fact_err=float(np.max(np.abs(recon-Pnl_ct)/np.maximum(np.abs(Pnl_ct),1e-30)))

    # Mass/normalization diagnostics.
    mfr=float(np.trapezoid(real.dn_dlnM*real.mass/rho,x=real.lnM))
    mfp=float(np.trapezoid(pseudo.dn_dlnM*pseudo.mass/rho,x=pseudo.lnM))
    out={
      'schema':'DELTA_CDM_PASS117_REACT_HALO_REACTION_ASSEMBLY_V1',
      'source_lock':SOURCE_LOCK,
      'closed_objects':[
        'REACT_REAL_PSEUDO_ONE_HALO_COMPILER',
        'REACT_E_PARAMETER_COMPILER',
        'REACT_MASSLESS_REACTION_ALGEBRA_COMPILER',
        'REACT_KSTAR_MATCHING_ALGEBRA_CONTRACT'],
      'not_closed_object':'CANONICAL_RICCI_REACT_ONE_LOOP_SPT_REAL_PSEUDO_COMPILER',
      'owner_reduction':{
        'previous_owner':'REACT_HALO_REACTION_ASSEMBLY_WITH_STANDARD_PSEUDO_BASELINE',
        'status':'REDUCED_NOT_FULLY_CLOSED',
        'last_survivor':'CANONICAL_RICCI_REACT_ONE_LOOP_SPT_REAL_PSEUDO_COMPILER',
        'reason':'All halo and reaction algebra is executable, but physical k_star requires the real and pseudo one-loop SPT spectra at k0=0.06 h/Mpc. PASS109/PASS112 supply gamma2/gamma3; their loop integration into P_SPT has not yet been compiled.'},
      'manufactured_witness':{
        'mass_grid_count':int(len(mass)),'k_grid_count':int(len(k)),
        'GR_identity_max_abs':grerr,
        'E_modified':float(E),'P1h_real_ke':float(pe_r),'P1h_pseudo_ke':float(pe_p),
        'target_kstar':target_kstar,'recovered_kstar':float(km['kstar']),
        'kstar_abs_error':float(kstar_err),'kstar_match_abs_residual':float(km.get('match_abs_residual',0.0)),
        'reaction_min':float(np.min(R)),'reaction_max':float(np.max(R)),
        'factorization_max_relative_error':fact_err,
        'mass_fraction_real_over_grid':mfr,'mass_fraction_pseudo_over_grid':mfp,
        'finite_positive':bool(np.all(np.isfinite(R)) and np.all(R>0))},
      'claim_ceiling':{
        'physical_baseline_instantiated':False,'physical_delta_c_table_instantiated':False,
        'physical_one_loop_SPT_compiled':False,'physical_kstar_claimed':False,
        'physical_reaction_claimed':False,'physical_mhat2_claimed':False},
      'truth_credit':0,
      'passed':bool(grerr<1e-12 and kstar_err<2e-12 and fact_err<1e-12 and np.all(np.isfinite(R)) and np.all(R>0))}
    (OUT/'PASS117_REACT_HALO_REACTION_ASSEMBLY.json').write_text(json.dumps(out,indent=2)+'\n')
    (ROOT/'references'/'PASS117'/'ACTIO_REACTIO_SOURCE_LOCK.json').write_text(json.dumps(SOURCE_LOCK,indent=2)+'\n')
    print(json.dumps(out,indent=2))
    return out

if __name__=='__main__':
    o=audit(); raise SystemExit(0 if o['passed'] else 1)
