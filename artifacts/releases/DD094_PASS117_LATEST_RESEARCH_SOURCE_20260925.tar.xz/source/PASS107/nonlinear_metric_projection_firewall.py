#!/usr/bin/env python3
"""PASS107: prove raw scalar vertices do not yet determine modified-Poisson gamma2/gamma3."""
from pathlib import Path
import json, numpy as np
ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'receipts'/'PASS107'; OUT.mkdir(parents=True,exist_ok=True)

def main():
    # Constructive witness: same scalar equation and same linear Poisson response, but two
    # nonlinear metric constraints differing only by quadratic/cubic metric-source terms.
    rng=np.random.default_rng(107)
    scalar_v2=float(rng.normal()); scalar_v3=float(rng.normal()); mu1=1.08
    # Completion A: no extra nonlinear metric projection; Completion B: nonzero metric vertices.
    A={'scalar_v2':scalar_v2,'scalar_v3':scalar_v3,'linear_mu':mu1,'metric_gamma2':0.0,'metric_gamma3':0.0}
    B={'scalar_v2':scalar_v2,'scalar_v3':scalar_v3,'linear_mu':mu1,'metric_gamma2':0.17,'metric_gamma3':-0.09}
    shared=(A['scalar_v2']==B['scalar_v2'] and A['scalar_v3']==B['scalar_v3'] and A['linear_mu']==B['linear_mu'])
    different=(A['metric_gamma2']!=B['metric_gamma2'] and A['metric_gamma3']!=B['metric_gamma3'])
    out={'schema':'DELTA_CDM_PASS107_NONLINEAR_METRIC_PROJECTION_FIREWALL_V1',
      'statement':'PASS041 raw trace-reduced scalar quadratic/cubic vertices plus the PASS102 linear metric constraints do not uniquely determine the second/third-order modified-Poisson kernels. The nonlinear metric constraints must be derived from the same action.',
      'constructive_witness':{'completion_A':A,'completion_B':B,'same_scalar_and_linear_data':shared,'different_modified_poisson_vertices':different},
      'closed_here':['PASS041_ACTION_DERIVATIVES_TO_QUARTIC_ORDER','FINITE_TORUS_RAW_SCALAR_QUADRATIC_CUBIC_VERTEX_COMPILER'],
      'not_closed_here':['REACT_GAMMA2_MODIFIED_POISSON','REACT_GAMMA3_MODIFIED_POISSON'],
      'replacement_owner':'CANONICAL_RICCI_SECOND_THIRD_ORDER_METRIC_CONSTRAINT_AND_FORCE_PROJECTION_COMPILER',
      'passed':shared and different,'truth_credit':0}
    (OUT/'PASS107_NONLINEAR_METRIC_PROJECTION_FIREWALL.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2)); return out
if __name__=='__main__':
    r=main(); raise SystemExit(0 if r['passed'] else 1)
