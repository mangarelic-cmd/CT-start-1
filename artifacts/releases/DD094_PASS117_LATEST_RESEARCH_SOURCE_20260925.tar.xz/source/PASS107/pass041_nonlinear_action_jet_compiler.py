#!/usr/bin/env python3
"""PASS107: quartic action-jet + trace-reduced static-QS scalar source compiler.

This module derives higher-order *raw scalar-source* vertices from the same PASS041
canonical Jordan-frame action used by PASS102.  It deliberately does NOT label these
raw scalar vertices as the ReACT modified-Poisson gamma2/gamma3; the nonlinear metric
constraint projection remains a separate owner.

M_P=1 representative units follow PASS096/PASS102.
"""
from __future__ import annotations
from dataclasses import dataclass
from pathlib import Path
import importlib.util, sys, math, json
import numpy as np
import sympy as sp
import mpmath as mp

ROOT=Path(__file__).resolve().parents[2]
OUT=ROOT/'receipts'/'PASS107'; OUT.mkdir(parents=True,exist_ok=True)

def _load(name,path):
    s=importlib.util.spec_from_file_location(name,path); m=importlib.util.module_from_spec(s)
    sys.modules[name]=m; s.loader.exec_module(m); return m
bg=_load('pass096_bg_pass107',ROOT/'source/PASS096/source_native_background_compiler_v2.py')
BackgroundParameters=bg.BackgroundParameters; BackgroundModel=bg.Model

# -------- symbolic y-derivative kernels of PASS041 --------
y,yc,yd,beta,sig,Bg,lam,it,AV=sp.symbols('y yc yd beta sig Bg lam it AV', real=True)
D=yd-yc; z=(y-yc)/D
# logistic source kernel; exp form is used only to differentiate symbolically
ie=sp.exp(y); s=1/(1+sp.exp(lam*(ie-it)))
KV=lam*ie*s*(1-s)
P3=z*(z-beta)*(z-1)
Uy=AV*KV*P3
Fy=Bg*sp.exp(-sp.Rational(1,2)*((y-yd)/sig)**2)*(y-yc)*(y-yd)
# Need y derivatives through fourth y derivative of U and F, which yields field-space
# derivatives through fourth order because D_phi = phi^-1 D_y.
Uyd=[sp.diff(Uy,y,n) for n in range(4)]  # Uy,Uyy,Uyyy,Uyyyy
Fyd=[sp.diff(Fy,y,n) for n in range(4)]  # Fy,Fyy,Fyyy,Fyyyy
_UL=[sp.lambdify((y,yc,yd,beta,lam,it,AV),e,'numpy') for e in Uyd]
_FL=[sp.lambdify((y,yc,yd,sig,Bg),e,'numpy') for e in Fyd]

def _field_derivatives_from_y(phi, d1,d2,d3,d4):
    """Return field derivatives f',f'',f''',f'''' from y derivatives f_y..f_yyyy."""
    return (
      d1/phi,
      (d2-d1)/phi**2,
      (d3-3*d2+2*d1)/phi**3,
      (d4-6*d3+11*d2-6*d1)/phi**4,
    )

def action_jet(model:BackgroundModel, y0:float):
    p=model.p; phi=p.phi0_over_Mp*math.exp(float(y0))
    argsU=(y0,p.y_c,p.y_delta,p.beta_shape,p.lam,p.i_t,model.AV)
    argsF=(y0,p.y_c,p.y_delta,p.sigma_y,p.B_g)
    uy=[float(f(*argsU)) for f in _UL]
    fy=[float(f(*argsF)) for f in _FL]
    F0=float(model.F(y0)); U0=float(model.U(y0))
    F1,F2,F3,F4=_field_derivatives_from_y(phi,*fy)
    U1,U2,U3,U4=_field_derivatives_from_y(phi,*uy)
    return dict(y=float(y0),phi=phi,F0=F0,F1=F1,F2=F2,F3=F3,F4=F4,
                U0=U0,U1=U1,U2=U2,U3=U3,U4=U4,
                Fy=fy[0],Fyy=fy[1],Fyyy=fy[2],Fyyyy=fy[3],
                Uy=uy[0],Uyy=uy[1],Uyyy=uy[2],Uyyyy=uy[3])

# -------- generic Taylor compiler around phi_bar --------
x,dT,Y,T0=sp.symbols('x dT Y T0')
F0,F1,F2,F3,F4=sp.symbols('F0 F1 F2 F3 F4')
U0,U1,U2,U3,U4=sp.symbols('U0 U1 U2 U3 U4')
Fser=F0+F1*x+F2*x**2/2+F3*x**3/6+F4*x**4/24
User=U0+U1*x+U2*x**2/2+U3*x**3/6+U4*x**4/24
fp=sp.diff(Fser,x); fpp=sp.diff(Fser,x,2); up=sp.diff(User,x)
K=1+3*fp**2/(2*Fser)
A=fp/(2*Fser)
B=fp*(1+3*fpp)/(2*Fser)
C=2*fp/Fser
Q=(up+A*(T0+dT)-B*Y-C*User)/K
# Coefficients required through cubic total perturbative order with Y=O(x^2), dT=O(delta).
q0=sp.expand(Q.subs({dT:0,Y:0})).series(x,0,4).removeO()
R=sp.diff(Q,dT).subs({dT:0,Y:0}).series(x,0,3).removeO()
G=sp.diff(Q,Y).subs({dT:0,Y:0}).series(x,0,2).removeO()
_COEFFS=[
    sp.expand(q0).coeff(x,i) for i in range(4)
] + [sp.expand(R).coeff(x,i) for i in range(3)] + [sp.expand(G).coeff(x,i) for i in range(2)]
_ARGS=(F0,F1,F2,F3,F4,U0,U1,U2,U3,U4,T0)
_CF=sp.lambdify(_ARGS,_COEFFS,'numpy')

def static_trace_reduced_vertex_coefficients(jet:dict, Tbar:float):
    a=[jet[k] for k in ['F0','F1','F2','F3','F4','U0','U1','U2','U3','U4']]+[float(Tbar)]
    c=list(map(float,_CF(*a)))
    return {
      'Q0':c[0], 'Q1_linear_mass_source':c[1],
      'q2_chi2':c[2], 'q3_chi3':c[3],
      'r0_dT':c[4], 'r1_chi_dT':c[5], 'r2_chi2_dT':c[6],
      'g0_grad2':c[7], 'g1_chi_grad2':c[8],
      'interpretation':{
        'quadratic_scalar_RHS':'q2*chi^2 + r1*chi*dT + g0*Gamma(chi,chi)',
        'cubic_scalar_RHS':'q3*chi^3 + r2*chi^2*dT + g1*chi*Gamma(chi,chi)',
        'not_yet_modified_poisson_gamma':'Nonlinear metric/lapse/shift constraints must still be projected.'
      }
    }

def _mp_field_jet(model,y0):
    """Independent high-precision differentiation in the physical phi coordinate."""
    p=model.p; mp.mp.dps=70
    ph0=mp.mpf(str(p.phi0_over_Mp))*mp.e**mp.mpf(str(y0))
    phi0=mp.mpf(str(p.phi0_over_Mp)); yc0=mp.mpf(str(p.y_c)); yd0=mp.mpf(str(p.y_delta))
    sig0=mp.mpf(str(p.sigma_y)); Bg0=mp.mpf(str(p.B_g)); beta0=mp.mpf(str(p.beta_shape))
    lam0=mp.mpf(str(p.lam)); it0=mp.mpf(str(p.i_t)); AV0=mp.mpf(str(model.AV)); D0=yd0-yc0
    def yof(ph): return mp.log(ph/phi0)
    def Fy_mp(yy):
        a=yy-yc0; b=yy-yd0
        return Bg0*mp.e**(-mp.mpf('0.5')*(b/sig0)**2)*a*b
    def Uy_mp(yy):
        ii=mp.e**yy; ss=1/(1+mp.e**(lam0*(ii-it0))); K=lam0*ii*ss*(1-ss); zz=(yy-yc0)/D0
        return AV0*K*zz*(zz-beta0)*(zz-1)
    Fphi=lambda ph: Fy_mp(yof(ph))/ph
    Uphi=lambda ph: Uy_mp(yof(ph))/ph
    return {
      'F':[float(mp.diff(Fphi,ph0,n)) for n in range(4)],
      'U':[float(mp.diff(Uphi,ph0,n)) for n in range(4)],
    }

def selftest():
    p=BackgroundParameters(V0=2,Vc=1,i_t=1.5,lam=1.4,y_c=0,y_delta=1,beta_shape=.45,sigma_y=.3,B_g=-.02,F_c=1.05,phi0_over_Mp=.8,rho_pi_bar=.7)
    m=BackgroundModel(p); y0=.37; j=action_jet(m,y0); fd=_mp_field_jet(m,y0)
    # Fourth derivatives are most sensitive; use a relative tolerance appropriate for independent polyfit differentiation.
    errs={}
    for pre in ['F','U']:
        exact=[j[f'{pre}{n}'] for n in range(1,5)]
        num=fd[pre]
        errs[pre]=[abs(a-b)/(1+abs(a)) for a,b in zip(exact,num)]
    c=static_trace_reduced_vertex_coefficients(j,Tbar=-.5)
    finite=all(math.isfinite(float(v)) for k,v in c.items() if isinstance(v,(float,int)))
    checks={
      'field_jet_F_derivatives_independent_mp':bool(max(errs['F'])<2e-11),
      'field_jet_U_derivatives_independent_mp':bool(max(errs['U'])<2e-11),
      'vertex_coefficients_finite':bool(finite),
      'quartic_action_jet_available':bool(all(k in j for k in ['F4','U4'])),
      'no_react_gamma_promotion':True,
    }
    out={'schema':'DELTA_CDM_PASS107_ACTION_JET_SELFTEST_V1','checks':checks,'relative_errors':errs,'action_jet':j,'raw_vertex_coefficients':c,'passed':all(checks.values()),'truth_credit':0,'physical_gamma2_claimed':False,'physical_gamma3_claimed':False}
    (OUT/'PASS107_ACTION_JET_SELFTEST.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2)); return out
if __name__=='__main__':
    r=selftest(); raise SystemExit(0 if r['passed'] else 1)
