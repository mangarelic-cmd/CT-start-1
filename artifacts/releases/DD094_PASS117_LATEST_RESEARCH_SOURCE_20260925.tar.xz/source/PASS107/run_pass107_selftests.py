#!/usr/bin/env python3
from pathlib import Path
import subprocess,sys,json
ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'receipts'/'PASS107'; OUT.mkdir(parents=True,exist_ok=True)
scripts=['pass041_nonlinear_action_jet_compiler.py','finite_torus_nonlinear_scalar_vertices.py','nonlinear_metric_projection_firewall.py','spherical_collapse_kinematic_reduction.py']
rows=[]
for s in scripts:
 r=subprocess.run([sys.executable,str(ROOT/'source/PASS107'/s)],cwd=ROOT,capture_output=True,text=True)
 rows.append({'script':s,'returncode':r.returncode,'stdout_tail':r.stdout[-5000:],'stderr_tail':r.stderr[-2000:]})
out={'schema':'DELTA_CDM_PASS107_SELFTEST_SUMMARY_V1','tests':rows,'passed':all(r['returncode']==0 for r in rows),'truth_credit':0}
(OUT/'PASS107_SELFTEST_SUMMARY.json').write_text(json.dumps(out,indent=2)+'\n');print(json.dumps(out,indent=2));raise SystemExit(0 if out['passed'] else 1)
