#!/usr/bin/env python3
from pathlib import Path
import sys,json,collections,argparse
ROOT=Path(__file__).resolve().parents[2]
ACROOT=ROOT/'runtime'/'AC77'/'SC_SOLVER_AC77_PERIODIC_CARTESIAN_THEOREM_METROLOGY_CORE_20260922'
sys.path.insert(0,str(ACROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver
BASE=[
 'FINITE_DISCRETE_TORUS_E1','Q_LAMBDA_FIREWALL_CERTIFICATE','PASS041_COMPLETED_ACTION_FAMILY',
 'CANONICAL_RICCI_EVOLVING_GAUGE_REDUCED_LINEAR_MODE_SOLVER','REACT_STYLE_NONLINEAR_CLOSURE_INPUT_REDUCTION',
 'MAPAR_LINEAR33_RESTRICTED_SUPPORT_CERTIFICATE','CURRENT_CORPUS_DELTA_NL_NONIDENTIFIABILITY_CERTIFICATE'
]
def seed(pid,statement,target,requires=(),supplies=(),**kw):
 p=dict(problem_id=pid,statement=statement,target=target,requires=list(requires),supplies=BASE+list(supplies),ground_binding=True);p.update(kw);return Node('PROBLEM',p,context=('DELTA_CDM_PASS107',pid))
seeds=[
 seed('P107_JET','Derive the PASS041 F and U field-space action jet through fourth order and the trace-reduced static-QS raw scalar Taylor coefficients without adding parameters.','PASS041_ACTION_DERIVATIVES_TO_QUARTIC_ORDER',(),('PASS041_ACTION_DERIVATIVES_TO_QUARTIC_ORDER',),proof_object={'type':'high_precision_action_jet_selftest','receipt':'receipts/PASS107/PASS107_ACTION_JET_SELFTEST.json'},uniformity_verified=True),
 seed('P107_TORUS_VERTEX','Compile the quadratic/cubic raw scalar-source vertices on the finite torus using the exact carré-du-champ Gamma(p,q)=1/2(lambda_p+lambda_q-lambda_pq), preserving q^2 != lambda.','FINITE_TORUS_RAW_SCALAR_QUADRATIC_CUBIC_VERTEX_COMPILER',(),('FINITE_TORUS_RAW_SCALAR_QUADRATIC_CUBIC_VERTEX_COMPILER',),proof_object={'type':'direct_graph_laplacian_identity','receipt':'receipts/PASS107/PASS107_FINITE_TORUS_NONLINEAR_SCALAR_VERTEX_SELFTEST.json'},uniformity_verified=True,boundaries={'q_lambda_firewall':True}),
 seed('P107_COLLAPSE_KIN','Close the exact pressureless spherical/top-hat density kinematics conditional on a nonlinear gravitational force source.','SPHERICAL_COLLAPSE_KINEMATIC_REDUCTION',(),('SPHERICAL_COLLAPSE_KINEMATIC_REDUCTION',),proof_object={'type':'EdS_growth_and_force_nonidentifiability','receipt':'receipts/PASS107/PASS107_SPHERICAL_COLLAPSE_KINEMATIC_REDUCTION.json'},uniformity_verified=True),
 seed('P107_FIREWALL','Forbid promotion of raw scalar vertices into ReACT modified-Poisson gamma2/gamma3 until the second/third-order metric constraints are derived.','NONLINEAR_METRIC_PROJECTION_FIREWALL',(),('NONLINEAR_METRIC_PROJECTION_FIREWALL',),proof_object={'type':'constructive_two_completion_witness','receipt':'receipts/PASS107/PASS107_NONLINEAR_METRIC_PROJECTION_FIREWALL.json'},uniformity_verified=True),
 seed('P107_METRIC_NL','Derive the second- and third-order lapse/shift/metric constraints of the same canonical PASS041 F(phi)R action and project the closed raw scalar vertices into physical modified-Poisson gamma2/gamma3 and the spherical-collapse force.','CANONICAL_RICCI_SECOND_THIRD_ORDER_METRIC_CONSTRAINT_AND_FORCE_PROJECTION_COMPILER',('SECOND_ORDER_CANONICAL_RICCI_METRIC_CONSTRAINTS','THIRD_ORDER_CANONICAL_RICCI_METRIC_CONSTRAINTS'),(),boundaries={'same_action_no_new_free_parameters':True,'raw_scalar_vertex_not_gamma':True,'q_lambda_firewall':True}),
 seed('P107_NONLINEAR','Construct the nonlinear reaction only after physical modified-Poisson gamma2/gamma3 and collapse force are available.','CT_NONLINEAR_HIGHER_ORDER_POISSON_AND_COLLAPSE_COMPILER',('CANONICAL_RICCI_SECOND_THIRD_ORDER_METRIC_CONSTRAINT_AND_FORCE_PROJECTION_COMPILER',),(),boundaries={'no_phenomenological_delta_nl':True}),
 seed('P107_FORWARD','Execute the continuum MaPar forward only after nonlinear closure and finite-torus compression are certified.','MAPAR_CONTINUUM_COMPRESSED_FORWARD_33',('CT_NONLINEAR_HIGHER_ORDER_POISSON_AND_COLLAPSE_COMPILER','FINITE_TORUS_TO_ISOTROPIC_PK_COMPRESSION_CERTIFICATE','MAPAR_CLASS_GR_BASELINE_NUMERIC_EXECUTION'),(),boundaries={'q_lambda_firewall':True}),
]
world={'project':'DELTA_CDM_PASS107','available_evidence_tokens':BASE,'external_scientific_truth_certified':False,'finite_discrete_torus':True,'pass041_quartic_action_jet_closed':True,'finite_torus_raw_scalar_vertices_closed':True,'spherical_collapse_kinematics_closed':True,'nonlinear_metric_projection_closed':False,'react_gamma2_closed':False,'react_gamma3_closed':False,'ct_spherical_collapse_force_closed':False,'physical_forward33_closed':False,'physical_rank_closed':False,'physical_mhat2_closed':False}
def run(recursive=False):
 s=SovereignSolver(); r=s.solve_universal(seeds,world=world,max_waves=2 if recursive else 1,max_calls=32000 if recursive else 15000,stable_waves=1)
 known=list(s.engine.known.values());counts=r.get('mechanism_execution_counts') or {};by={p.payload['problem_id']:collections.Counter() for p in seeds};front=[]
 for n in known:
  if len(n.context)>=2 and n.context[0]=='DELTA_CDM_PASS107':
   pid=n.context[1]
   if pid in by:by[pid][str(n.payload.get('status') or n.kind)]+=1
   st=str(n.payload.get('status') or '')
   if st in {'NEED_DATA','WAITING','OPEN','INVALID','PARTIAL','MISSING_CARRIER'} and n.kind not in {'AUX_OBSERVATION','MECHANISM_OBSERVATION'}:
    front.append({'problem_id':pid,'kind':n.kind,'status':st,'requires':n.payload.get('requires'),'unresolved_requirements':n.payload.get('unresolved_requirements'),'mechanism':n.payload.get('mechanism'),'statement':n.payload.get('statement')})
 out={'schema':'DELTA_CDM_PASS107_AC77_AUDIT_V1','mode':'recursive' if recursive else 'direct','solver_version':r.get('version'),'run_state':r.get('run_state'),'active_mechanism_count':r.get('active_mechanism_count'),'mechanisms_touched':sum(1 for v in counts.values() if v),'execution_calls':r.get('execution_calls'),'known_node_count':r.get('known_node_count'),'open_residual_count':r.get('open_residual_count'),'periodic_cartesian_receipt_count':r.get('periodic_cartesian_receipt_count'),'solution_certified':r.get('solution_certified'),'formal_proof_verified':r.get('formal_proof_verified'),'problem_status_counters':{k:dict(v) for k,v in by.items()},'declared_seed_requirements':{p.payload['problem_id']:p.payload.get('requires',[]) for p in seeds},'frontier_nonpass_count':len(front),'frontier_nonpass':front,'mechanism_execution_counts':counts}
 name='AC77_PASS107_RECURSIVE_AUDIT.json' if recursive else 'AC77_PASS107_DIRECT_AUDIT.json';(ROOT/'receipts/PASS107'/name).write_text(json.dumps(out,indent=2,ensure_ascii=False)+'\n');return out
if __name__=='__main__':
 ap=argparse.ArgumentParser();ap.add_argument('--recursive',action='store_true');a=ap.parse_args();o=run(a.recursive)
 (ROOT/'receipts/PASS107/PASS107_SEED_REGISTRY.json').write_text(json.dumps([n.to_dict() for n in seeds],indent=2,ensure_ascii=False)+'\n')
 print(json.dumps({k:o[k] for k in ['mode','solver_version','run_state','active_mechanism_count','mechanisms_touched','execution_calls','known_node_count','open_residual_count','periodic_cartesian_receipt_count','solution_certified','formal_proof_verified','declared_seed_requirements']},indent=2))
