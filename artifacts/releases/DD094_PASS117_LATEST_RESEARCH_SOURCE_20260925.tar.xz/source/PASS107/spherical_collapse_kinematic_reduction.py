#!/usr/bin/env python3
"""PASS107 exact dust top-hat kinematic reduction conditional on nonlinear force."""
from pathlib import Path
import json, math
import numpy as np
from scipy.integrate import solve_ivp
ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'receipts'/'PASS107'; OUT.mkdir(parents=True,exist_ok=True)

def collapse_rhs(N,x,Omega_m,h,force_source):
    # Exact pressureless continuity+Euler density equation in N=ln a:
    # delta'' +(2+h)delta' -(4/3)delta'^2/(1+delta) = (1+delta)*S_Psi,
    # where S_Psi=-nabla^2 Psi/(a^2 H^2).  force_source returns S_Psi.
    d,v=map(float,x)
    if d<=-1: raise FloatingPointError('density contrast crossed -1')
    S=float(force_source(N,d))
    return np.array([v, -(2+h(N))*v + (4.0/3.0)*v*v/(1+d) + (1+d)*S])

def eds_force(N,d): return 1.5*d

def main():
    # In EdS, h=-3/2 and Omega_m=1. For a tiny overdensity the growing solution is delta~a.
    h=lambda N:-1.5; Om=lambda N:1.0
    N0=-8.; N1=-4.; d0=1e-6; v0=d0
    sol=solve_ivp(lambda N,x:collapse_rhs(N,x,Om,h,eds_force),(N0,N1),[d0,v0],rtol=1e-10,atol=1e-13,max_step=.01)
    dg=d0*math.exp(N1-N0); d1=float(sol.y[0,-1]); linear_rel=abs(d1-dg)/dg
    # Nonlinear force non-identifiability witness: same linearization at delta=0, different collapse beyond linear order.
    fA=lambda N,d:1.5*d
    fB=lambda N,d:1.5*d*(1+0.2*d/(1+d))
    y0=[.05,.05]
    a=solve_ivp(lambda N,x:collapse_rhs(N,x,Om,h,fA),(-3,-1),y0,max_step=.005,rtol=1e-9,atol=1e-11)
    b=solve_ivp(lambda N,x:collapse_rhs(N,x,Om,h,fB),(-3,-1),y0,max_step=.005,rtol=1e-9,atol=1e-11)
    sep=abs(float(a.y[0,-1]-b.y[0,-1]))
    out={'schema':'DELTA_CDM_PASS107_SPHERICAL_COLLAPSE_KINEMATIC_REDUCTION_V1',
      'equation':'delta_NN +(2+h) delta_N -(4/3) delta_N^2/(1+delta) = (1+delta) S_Psi, S_Psi=-nabla^2 Psi/(a^2 H^2)',
      'closed':'Pressureless top-hat kinematics once the nonlinear force source S_Psi is supplied.',
      'remaining_force_owner':'CANONICAL_RICCI_SECOND_THIRD_ORDER_METRIC_CONSTRAINT_AND_FORCE_PROJECTION_COMPILER',
      'tests':{'EdS_small_delta_growth_relative_error':linear_rel,'same_linear_force_different_nonlinear_collapse_separation':sep},
      'passed':linear_rel<2e-4 and sep>1e-4,'truth_credit':0,'physical_collapse_claimed':False}
    (OUT/'PASS107_SPHERICAL_COLLAPSE_KINEMATIC_REDUCTION.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2)); return out
if __name__=='__main__':
    r=main(); raise SystemExit(0 if r['passed'] else 1)
