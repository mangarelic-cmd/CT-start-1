#!/usr/bin/env python3
"""PASS107 exact finite-torus carré-du-champ vertices for the PASS041 scalar source."""
from __future__ import annotations
from pathlib import Path
import importlib.util,sys,math,json
import numpy as np
ROOT=Path(__file__).resolve().parents[2]; OUT=ROOT/'receipts'/'PASS107'; OUT.mkdir(parents=True,exist_ok=True)

def _load(name,path):
 s=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(s);sys.modules[name]=m;s.loader.exec_module(m);return m
jetmod=_load('pass107_jet',ROOT/'source/PASS107/pass041_nonlinear_action_jet_compiler.py')
bg=_load('pass096_bg_pass107_vertex',ROOT/'source/PASS096/source_native_background_compiler_v2.py')

class RectangularTorus:
    def __init__(self,N,h):
        self.N=tuple(map(int,N)); self.h=tuple(map(float,h))
        if len(self.N)!=len(self.h) or any(n<4 for n in self.N) or any(x<=0 for x in self.h): raise ValueError('bad torus')
    def add(self,a,b): return tuple((int(x)+int(y))%n for x,y,n in zip(a,b,self.N))
    def lam(self,nvec):
        return sum(4.0/(hh*hh)*math.sin(math.pi*(int(nn)%NN)/NN)**2 for nn,NN,hh in zip(nvec,self.N,self.h))
    def gamma(self,a,b):
        # Carré-du-champ for Delta e_n = -lambda_n e_n: Gamma(f,g)=1/2[Delta(fg)-fDelta g-gDelta f].
        return 0.5*(self.lam(a)+self.lam(b)-self.lam(self.add(a,b)))

def symmetric_raw_vertices(coeff,torus,modes,a=1.0):
    """Return raw scalar-source V2/V3, not modified-Poisson ReACT gamma2/gamma3."""
    if len(modes)!=3: raise ValueError('need three modes for V3 witness')
    p,q,r=modes
    Gpq=torus.gamma(p,q)/(a*a); Gpr=torus.gamma(p,r)/(a*a); Gqr=torus.gamma(q,r)/(a*a)
    V2=coeff['q2_chi2']+coeff['g0_grad2']*Gpq
    V3=coeff['q3_chi3']+coeff['g1_chi_grad2']*(Gpq+Gpr+Gqr)/3.0
    return {'V2_chichi':V2,'V3_chichichi':V3,'Gamma_pq_over_a2':Gpq,'Gamma_pr_over_a2':Gpr,'Gamma_qr_over_a2':Gqr}

def direct_graph_gamma_check(torus,a,b):
    # Direct edge-form identity at x=0 using complex Fourier modes.
    dims=torus.N; idx=np.indices(dims)
    def mode(n):
      phase=np.zeros(dims,float)
      for ax,(nn,NN) in enumerate(zip(n,dims)): phase += 2*np.pi*(nn%NN)*idx[ax]/NN
      return np.exp(1j*phase)
    fa,fb=mode(a),mode(b)
    def Delta(f):
      z=np.zeros_like(f,dtype=complex)
      for ax,hh in enumerate(torus.h): z+=(np.roll(f,1,axis=ax)+np.roll(f,-1,axis=ax)-2*f)/(hh*hh)
      return z
    G=.5*(Delta(fa*fb)-fa*Delta(fb)-fb*Delta(fa))
    target=torus.gamma(a,b)*fa*fb
    return float(np.max(np.abs(G-target)))

def selftest():
    p=bg.BackgroundParameters(V0=2,Vc=1,i_t=1.5,lam=1.4,y_c=0,y_delta=1,beta_shape=.45,sigma_y=.3,B_g=-.02,F_c=1.05,phi0_over_Mp=.8,rho_pi_bar=.7)
    m=bg.Model(p); j=jetmod.action_jet(m,.37); c=jetmod.static_trace_reduced_vertex_coefficients(j,-.5)
    t=RectangularTorus((10,12,14),(.23,.19,.17)); modes=((1,2,1),(2,1,3),(1,3,2))
    v=symmetric_raw_vertices(c,t,modes,a=.7); gres=direct_graph_gamma_check(t,modes[0],modes[1])
    # Continuum limit check: Gamma -> -q1.q2 for fixed low integer modes as N grows at fixed box lengths.
    def cont_err(N):
      L=(9.,10.,11.); h=tuple(Li/N for Li in L); tt=RectangularTorus((N,N,N),h)
      a,b=modes[0],modes[1]
      qa=np.array([2*np.pi*x/Li for x,Li in zip(a,L)]); qb=np.array([2*np.pi*x/Li for x,Li in zip(b,L)])
      return abs(tt.gamma(a,b)+float(qa@qb))
    e32,e64,e128=map(cont_err,(32,64,128))
    checks={'graph_carre_du_champ_identity':gres<2e-11,'continuum_convergence':e128<e64<e32,'vertices_finite':all(math.isfinite(float(x)) for x in v.values()),'q2_lambda_not_identified':True}
    out={'schema':'DELTA_CDM_PASS107_FINITE_TORUS_NONLINEAR_SCALAR_VERTEX_SELFTEST_V1','checks':checks,'graph_identity_residual':gres,'continuum_errors':{'N32':e32,'N64':e64,'N128':e128},'raw_vertices':v,'passed':all(checks.values()),'truth_credit':0,'modified_poisson_gamma2_claimed':False,'modified_poisson_gamma3_claimed':False}
    (OUT/'PASS107_FINITE_TORUS_NONLINEAR_SCALAR_VERTEX_SELFTEST.json').write_text(json.dumps(out,indent=2)+'\n')
    print(json.dumps(out,indent=2)); return out
if __name__=='__main__':
    r=selftest(); raise SystemExit(0 if r['passed'] else 1)
