# DELTA_CDM — AC77 PASS117

PASS117 attacks the PASS116 owner

`REACT_HALO_REACTION_ASSEMBLY_WITH_STANDARD_PSEUDO_BASELINE`

and reduces it to the one missing physical subcompiler rather than inventing a nonlinear residual field or a matching scale.

## 1. Source-locked ReACT branch

The halo/reaction conventions are locked to ACTio-ReACTio commit
`a36dda02db6b537a4ddcc7bf044c446c10a58373`, specifically `HALO.cpp` and `HALO.h`.
For the massless-neutrino branch the reaction is

`R(k) = {[(1-E) exp(-k/kstar)+E] P_L,real(k) + P_1h,real(k)} / {P_L,pseudo(k)+P_1h,pseudo(k)}`.

The source constants are

- `k_e = 0.01 h/Mpc` for `E`;
- `k_0 = 0.06 h/Mpc` for the `kstar` 1-loop matching condition;
- ReACT halo integration nominally spans `5 <= log10(M/[M_sun/h]) <= 20`.

## 2. Halo assembly closed as a compiler

`source/PASS117/react_halo_reaction_assembly.py` implements:

- spherical-top-hat `sigma(M)` from a supplied standard linear spectrum;
- Sheth-Tormen abundance with the ReACT constants `q=0.75`, `p=0.3`, `A=(3.056*1.012)^-1`;
- virial radius from supplied `Delta_vir(M,z)`;
- ReACT concentration convention `c = g_de 9 a (M/Mstar)^-0.13`;
- normalized Fourier NFW profile;
- real and pseudo one-halo terms;
- `E = P_1h,real(k_e)/P_1h,pseudo(k_e)`;
- the exact massless-neutrino reaction algebra;
- the exact algebraic `kstar` matching rule once the real/pseudo 1-loop SPT values at `k_0` are supplied.

No `Delta_NL(k,z)` field is introduced.

## 3. Manufactured regressions

All values in this section have `truth_credit=0`; they validate the compiler only.

### GR identity

Identical real and pseudo halo tables give

`max |R_GR(k)-1| = 0`.

### kstar recovery

A witness constructed with target

`kstar = 0.18`

is recovered as

`kstar = 0.1799999999999878`,

with absolute error

`1.2184697695261093e-14`.

The explicit reaction-at-`k0` matching residual is

`1.1102230246251565e-16`.

### Nonlinear factorization

The PASS105 identity reconstructed from the assembled reaction has maximum relative residual

`2.398111013984662e-16`.

The manufactured modified reaction remains finite and positive over the test grid:

`0.9908509297474808 <= R(k) <= 1.0216291370463932`.

## 4. What remains open

PASS117 shows that `kstar` cannot honestly be generated from the halo terms alone.
ACTio-ReACTio fixes it by matching the halo reaction at `k0=0.06 h/Mpc` to the real and pseudo **1-loop SPT spectra**.

The project already has:

- PASS102 exact evolving linear response;
- PASS109 action-derived `gamma2`;
- PASS112 action-derived `gamma3` on the selected minimal torus branch.

What is not yet materialized is the actual loop integration that maps these kernels into

`P_SPT,real(k,z)` and `P_SPT,pseudo(k,z)`.

Therefore the previous owner is **reduced, not falsely declared fully closed**.

## 5. Closed objects

PASS117 closes:

`REACT_REAL_PSEUDO_ONE_HALO_COMPILER`

`REACT_E_PARAMETER_COMPILER`

`REACT_MASSLESS_REACTION_ALGEBRA_COMPILER`

`REACT_KSTAR_MATCHING_ALGEBRA_CONTRACT`

## 6. New Last Survivor

The immediate owner is now

`CANONICAL_RICCI_REACT_ONE_LOOP_SPT_REAL_PSEUDO_COMPILER`.

PASS118 must compile the real and pseudo 1-loop spectra from the closed linear response and `gamma2/gamma3`, evaluate them at the ReACT matching scale, and thereby determine physical `kstar`.

Once paid:

`PASS116 collapse tables`
`-> PASS117 halo terms + E`
`-> PASS118 one-loop SPT + kstar`
`-> physical ReACT reaction`
`-> finite-torus to isotropic P(k,z) compression`
`-> PASS105 MaPar 33-point likelihood`
`-> J_8D -> rank_obs -> mhat^2`.

## 7. Claim ceiling

PASS117 does not claim a physical nonlinear reaction, a physical `kstar`, a physical halo table, a physical CLASS baseline instance, an observational rank, or a physical `mhat^2`.

The standard-sector CLASS/pseudo baseline remains deterministic bookkeeping already isolated by PASS105, not a CT coupling.

## 8. AC77

Direct:

- `99/99` mechanisms touched;
- `792` execution calls;
- `solution_certified = false`;
- `formal_proof_verified = false`.

Recursive:

- `99/99` mechanisms touched;
- `9108` execution calls;
- `solution_certified = false`;
- `formal_proof_verified = false`.

The AC77 execution modified 56 cached `.pyc` files; all were restored from PASS116 before package sealing.
