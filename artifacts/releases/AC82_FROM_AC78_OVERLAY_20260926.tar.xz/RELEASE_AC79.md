# AC79 — Progress-aware fixed-point Solver

AC79 is the control-layer successor to AC78 HyperTriangle Memory Integration Core. It preserves the AC78 scientific/provider surface and changes the stopping semantics of recursive ALL-AUX analysis.

## Problem fixed
AC78 could keep generating OPEN wrapper currents, return wrappers, and descendant obligations even when no new scientific supply, proof, refutation, material object, or better obligation state appeared. Wrapper novelty was therefore able to masquerade as progress until a resource checkpoint stopped the run.

## AC79 rule
A new OPEN object is **not** scientific progress. Progress is credited only when at least one of the following changes:
- a context-compatible supply becomes available;
- a verified proof or refutation appears;
- a reusable material/provider/carrier/relation object appears;
- an unresolved sovereign obligation descends to a strictly better scientific obligation rank.

Administrative resume metadata, scheduler iterations, repeated OPEN envelopes, and parent-return provenance do not create progress credit.

## Stop conditions
AC79 stops normally when:
1. every still-open sovereign root requirement has reached a terminal scientific leaf without an exact supply;
2. a complete ALL-AUX wave changes no meaningful scientific state;
3. the exact progress/frontier state repeats; or
4. a non-adjacent scientific state cycle is detected.

`max_calls` and `max_waves` remain emergency backstops, not the intended stopping mechanism.

## Many-case mode
`SovereignSolver.solve_individual_then_global(...)` terminalizes each independent case in a fresh solver state, compresses each result into a terminal receipt, and only then performs one complete global ALL-AUX wave. Another global wave is permitted only after a genuinely new exact supply or constraint is materialized.

## Preserved capabilities
- AC77 Periodic Cartesian theorem metrology / PASS053-PASS054 distance interface;
- AC78 frozen HyperTriangle provider v1.0.0 and its memory core;
- 99 ALL-AUX mechanisms;
- `HYPERCUBE_COORDINATE_SEARCH` in the 99-mechanism registry;
- Causal Cartesian Plane, AC75 universal constraints, AC76 semantic unifier, theorem fabric and inherited AUX surface.

No theorem-truth or physical-truth credit is added by the new stopping logic.
