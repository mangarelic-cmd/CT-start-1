import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver


def _open(tid, extra=None):
    p={'status':'OPEN','statement':tid,'theorem_id':tid,'scientific_focus':True,'sovereign_focus':True,
       'requires':[f'DISAMBIGUATING_CONSTRAINT::{tid}::MACRO_ADDRESS']}
    if extra: p.update(extra)
    return Node('PROBLEM',p,context=('AC81',tid))

def test_ac81_world_contract_preserves_ac78_and_ac77():
    s=SovereignSolver(); w=s._prepare_world({})
    assert w['context_version']==82
    assert w['ac81_sovereign_root_progress_stop'] is True
    assert w['ac81_bounded_enrichment_for_resolved_input'] is True
    assert w['ac78_hypertriangle_memory_integration_core'] is True
    assert w['ac77_periodic_cartesian_theorem_metrology_core'] is True
    assert w['active_mechanism_count']==99

def test_ac81_root_open_enriched_case_stops_before_resource_ceiling():
    q4=[0.1,-0.2,0.3,-0.4]
    h=SovereignSolver().hypertriangle({'mode':'b4_state','payload':{'axis_ids':['Q1','Q2','Q3','Q4'],'values':q4,
        'contracts':{'common_scale_certified':True,'axis_independence_certified':True,'b4_comparable':True}}})
    n=_open('ENRICHED',{'q4_coordinate':q4,'hypertriangle_q4_receipt':h.get('receipt',h),
        'relations':{'nearest_pass054':[['T2',0.3],['T3',0.4]],'pair_count':6903}})
    r=SovereignSolver().solve_universal([n],max_waves=64,max_calls=5000,fixed_point_patience=1)
    assert r['run_state']=='FIXED_POINT_ROOT_NO_PROGRESS'
    assert r['execution_calls']<5000
    assert r['fixed_point_receipt']['resource_limit_hit'] is False

def test_ac81_resolved_input_gets_one_bounded_enrichment_wave():
    n=Node('PROBLEM',{'status':'PASS','statement':'RESOLVED','scientific_focus':True,'sovereign_focus':True,
        'q4_coordinate':[0.2,0.1,-0.3,0.4]},context=('AC81','RESOLVED'))
    r=SovereignSolver().solve_universal([n],max_waves=64,max_calls=5000,fixed_point_patience=1)
    assert r['run_state']=='COMPLETE_BOUNDED_ENRICHMENT'
    assert r['execution_calls']<5000
    assert r['fixed_point_receipt']['resource_limit_hit'] is False

def test_ac81_individual_then_global_is_bounded_for_mixed_cases():
    cases=[_open(f'T{i}') for i in range(4)]
    cases += [Node('PROBLEM',{'status':'PASS','statement':f'R{i}','theorem_id':f'R{i}','scientific_focus':True,'sovereign_focus':True},context=('AC81',f'R{i}')) for i in range(2)]
    req=[f'DISAMBIGUATING_CONSTRAINT::T{i}::MACRO_ADDRESS' for i in range(4)]
    groups=[{'id':f'T{i}','status':'OPEN','requires':[req[i]],'ground_binding':True} for i in range(4)]
    groups += [{'id':f'R{i}','status':'PASS','requires':[],'ground_binding':True} for i in range(2)]
    g=Node('COLLECTIVE_CURRENT',{'status':'OPEN','statement':'GLOBAL','scientific_focus':True,'sovereign_focus':True,
        'requires':req,'summary':{'groups':groups},'ground_binding':True,'relations':{'pair_count':15}},context=('AC81','GLOBAL'))
    r=SovereignSolver().solve_individual_then_global(cases,g,per_case_max_calls=5000,global_max_calls=5000)
    assert r['schema']=='AC82_INDIVIDUAL_THEN_GLOBAL_V1'
    assert r['case_count']==6
    assert all(not x['run_state'].startswith('RESOURCE_') for x in r['individual'])
    assert r['global']['execution_calls']<5000

def test_ac81_same_open_case_is_deterministic_and_no_wheel():
    outs=[]
    for _ in range(2):
        r=SovereignSolver().solve_universal([_open('DETERMINISTIC')],max_waves=64,max_calls=5000,fixed_point_patience=1)
        outs.append((r['run_state'],r['execution_calls'],r['fixed_point_receipt']['root_requirements']))
    assert outs[0]==outs[1]
