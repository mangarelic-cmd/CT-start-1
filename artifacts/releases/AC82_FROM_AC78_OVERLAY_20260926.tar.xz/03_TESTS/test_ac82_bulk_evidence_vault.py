import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver

def test_ac82_bulk_relation_vault_exact_query_and_compaction():
    pairs=[{'a':f'T{i:03d}','b':f'T{i+1:03d}','d':i/10,'e':(i/10)**2} for i in range(1,401)]
    seed=Node('COLLECTIVE_CURRENT',{'status':'OPEN','statement':'BULK','scientific_focus':True,'sovereign_focus':True,
        'requires':['DISAMBIGUATING_CONSTRAINT::BULK'],'relations':{'provider':'TEST_PROVIDER','pair_count':len(pairs),'pairs':pairs},
        'summary':{'groups':[{'id':'BULK','status':'OPEN','requires':['DISAMBIGUATING_CONSTRAINT::BULK'],'ground_binding':True}]},'ground_binding':True},context=('AC82','BULK'))
    s=SovereignSolver(); compact=s._compact_bulk_seed_payloads([seed],threshold=256)
    c=[n for n in compact if n.kind=='COLLECTIVE_CURRENT'][0]
    assert 'pairs' not in c.payload['relations']
    bid=c.payload['relations']['relation_bank_id']
    assert s.bulk_relation_query(bid)['pair_count']==400
    assert s.bulk_relation_query(bid,'T001','T002')['d']==0.1
    assert s.bulk_relation_query(bid,'T002','T001')['d']==0.1

def test_ac82_bulk_global_wave_finishes_before_backstop():
    pairs=[{'a':f'T{i:03d}','b':f'T{j:03d}','d':float(i+j),'e':float((i+j)**2)} for i in range(1,40) for j in range(i+1,41)]
    req=['DISAMBIGUATING_CONSTRAINT::GLOBAL']
    seed=Node('COLLECTIVE_CURRENT',{'status':'OPEN','statement':'GLOBAL_BULK','scientific_focus':True,'sovereign_focus':True,
        'requires':req,'relations':{'provider':'TEST_PROVIDER','pair_count':len(pairs),'pairs':pairs},
        'summary':{'groups':[{'id':'GLOBAL','status':'OPEN','requires':req,'ground_binding':True}]},'ground_binding':True},context=('AC82','GLOBAL'))
    s=SovereignSolver(); r=s.solve_universal([seed],max_waves=16,max_calls=5000,fixed_point_patience=1)
    assert r['run_state']=='FIXED_POINT_ROOT_NO_PROGRESS'
    assert r['execution_calls']<5000
    assert r['bulk_relation_bank_count']==1
    assert r['bulk_relation_pair_count']==len(pairs)
    assert r['fixed_point_receipt']['resource_limit_hit'] is False
