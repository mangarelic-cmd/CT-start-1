import sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT/'02_RUNTIME'))
from all_everything_wave_engine import Node
from sovereign_solver import SovereignSolver
from progress_fixed_point_guard import progress_snapshot


def test_ac79_world_contract_and_backstop_semantics():
    s=SovereignSolver(); w=s._prepare_world({})
    assert w['context_version']==82
    assert w['ac79_progress_aware_fixed_point_guard'] is True
    assert w['ac79_resource_limits_are_backstops_not_stop_rules'] is True
    assert w['ac78_hypertriangle_memory_integration_core'] is True
    assert w['ac77_periodic_cartesian_theorem_metrology_core'] is True


def test_ac79_repeated_open_problem_stops_at_fixed_point_before_call_budget():
    s=SovereignSolver()
    n=Node('PROBLEM',{
        'status':'OPEN','statement':'AC79_FIXED_POINT_SMOKE','scientific_focus':True,'sovereign_focus':True,
        'requires':['DISAMBIGUATING_CONSTRAINT::AC79_FIXED_POINT_SMOKE']
    },context=('AC79','FIXED_POINT'))
    r=s.solve_universal([n],max_waves=50,max_calls=50000,fixed_point_patience=1)
    assert r['run_state'] in {'FIXED_POINT_OPEN_FRONTIER','FIXED_POINT_STATE_CYCLE','FIXED_POINT_TERMINAL_LEAF','FIXED_POINT_ROOT_NO_PROGRESS'}
    assert r['execution_calls'] < 50000
    assert r['fixed_point_receipt'] is not None
    assert r['fixed_point_receipt']['resource_limit_hit'] is False


def test_ac79_progress_snapshot_ignores_parent_resume_wrapper_metadata():
    s=SovereignSolver()
    a=Node('SCIENTIFIC_CURRENT',{'status':'OPEN','statement':'X','requires':['DISAMBIGUATING_CONSTRAINT::X']},context=('C',))
    b=Node('SCIENTIFIC_CURRENT',{'status':'OPEN','statement':'X','requires':['DISAMBIGUATING_CONSTRAINT::X'],
                                 'resume_after_child_return':True,'child_return_receipt':'abc'},context=('C',))
    s.engine.publish(a); snap1=progress_snapshot(s.engine.known)
    s.engine.publish(b); snap2=progress_snapshot(s.engine.known)
    assert snap1['digest']==snap2['digest']


def test_ac79_direct_ac78_hypertriangle_and_ac77_periodic_apis_preserved():
    s=SovereignSolver()
    h=s.hypertriangle({'mode':'memory_144_init','payload':{}})
    assert h['provider']=='HYPERTRIANGLE_SOLVER_AUX' and h['version']=='1.0.0'
    p=s.periodic_cartesian({'operation':'coherent_distance','source_theorem_id':'T003','target_theorem_id':'T072'})
    assert p.get('ok') is True


def test_ac79_individual_then_global_orchestrator_is_finite_and_native():
    cases=[]
    for tid in ('T_A','T_B'):
        cases.append(Node('PROBLEM',{'status':'OPEN','statement':tid,'theorem_id':tid,
            'scientific_focus':True,'sovereign_focus':True,
            'requires':[f'DISAMBIGUATING_CONSTRAINT::{tid}']},context=('BATCH',tid)))
    global_seed=Node('COLLECTIVE_CURRENT',{'status':'OPEN','statement':'BATCH_GLOBAL','scientific_focus':True,
        'sovereign_focus':True,'requires':['DISAMBIGUATING_CONSTRAINT::T_A','DISAMBIGUATING_CONSTRAINT::T_B'],
        'summary':{'groups':[{'id':'T_A','status':'OPEN'},{'id':'T_B','status':'OPEN'}]},'ground_binding':True},context=())
    r=SovereignSolver().solve_individual_then_global(cases,global_seed,per_case_max_calls=5000,global_max_calls=5000)
    assert r['case_count']==2
    assert all(x['run_state'].startswith('FIXED_POINT') for x in r['individual'])
    assert r['global']['execution_calls'] <= 5000
    assert r['method'].startswith('ALL_CASES_TO_TERMINAL_LOCAL_STATE')
